# 여성 테마 정의 (상의=삼각 컵 끈 연결, 하의=마이크로 비키니 고정)
def _FB(c): return f"a minimal {c} micro bikini bottom of one tiny low-rise opaque triangle on thin side strings tied at the hips, the small opaque piece fully covering her"
def _FT(c): return f"a tiny {c} micro-bikini top of two small opaque triangle cups on thin strings tied at the neck and back, fully covering her bust"
def _T(acc, ct, cb=None):
    return f"wearing {acc}, {_FT(ct)}, and {_FB(cb or ct)}, her stomach fully visible"
FTHEMES = {
 "군인": _T("a tilted olive-green military beret with a brass badge and two silver dog-tag chains around her neck", "camouflage-pattern"),
 "소방관": _T("a red-and-yellow firefighter helmet with a clear visor pushed up and yellow reflective-striped cuffs on both wrists", "glossy red"),
 "해적": _T("a black tricorn pirate hat with a white skull emblem, a red bandana knotted at her neck and black leather wrist cuffs with gold studs", "black leather"),
 "카우보이": _T("a brown leather cowboy hat, a red bandana knotted at her neck and a silver sheriff star pinned on a thin leather neck strap", "brown leather"),
 "복서": _T("glossy red boxing gloves and a gold-edged white waistband strap across her hips", "red satin"),
 "닌자": _T("a black ninja headband with a polished steel plate across her forehead, black fingerless wrist wraps and a red sash tied at one hip", "black"),
 "서퍼": "wearing a shark-tooth necklace, " + _FT("neon-orange") + ", and " + _FB("neon-orange") + ", soaked and clinging, water streaming down her whole body in glistening rivulets with countless droplets clinging to her skin, her hair soaking wet and slicked",
 "산타": _T("a red velvet Santa hat with a white fur trim and pom-pom and white fur cuffs on both wrists", "red velvet"),
 "악마": _T("a pair of small curved black horns on her head, a thin pointed devil tail and a black leather collar", "glossy black leather"),
 "천사": _T("a thin golden halo floating above her head and a pair of large white feathered angel wings attached at her back", "white satin"),
 "뱀파이어": _T("a long black cape lined in red silk, fastened at her neck and hanging open down her back, leaving the front of her body bare", "black satin"),
 "경찰관": _T("a black police cap with a silver badge and steel handcuffs hanging from one hip string", "black leather"),
 "간호사": _T("a white nurse cap with a small red cross and a stethoscope draped around her neck", "white glossy vinyl"),
 "바니걸": _T("a black satin bunny-ear headband, a black satin collar with a white bow tie, white wrist cuffs and a small fluffy white tail at the back", "black satin"),
 "마녀": _T("a tall pointed black witch hat with a deep purple band and a thin purple ribbon choker", "deep purple satin"),
 "메이드": _T("a white ruffled lace maid headband, a black lace choker with a small bow and white lace wrist cuffs", "black satin"),
}
