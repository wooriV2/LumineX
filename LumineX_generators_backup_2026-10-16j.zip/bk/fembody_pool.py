POOL["V-taper physique"] = "an extraordinarily tall and powerful athletic woman, far beyond any real person; wide capped boulder-like shoulders, a broad flaring back and lats forming a dramatic V-taper, defined muscular arms, a firm chest, a deeply defined six-pack abdomen on a very narrow waist, round firm hips and strong muscular thighs with a visible quad sweep and defined calves; hard clean muscle under glowing skin, not bulky like a bodybuilder, not thin; her arms, hands, legs and feet stay in correct proportion to each other"
KO["V-taper physique"] = "V자 피지크"; KO["amazoness"] = "아마조네스"; KO["toned bombshell"] = "토운드 밤쉘"
_CURVY = ["legendary bust", "curved bust", "siren bust hourglass", "glamour hourglass", "hourglass bombshell", "black glamour", "apex siren", "violin hip hourglass", "latina curves", "Brazilian booty glam"]
_ATH = ["V-taper physique", "amazoness", "toned bombshell"]
for _k in _CURVY + _ATH: assert _k in POOL, _k
FEMBODY = _CURVY * 3 + _ATH * 7
