# -*- coding: utf-8 -*-
# 인형 관절 재질(BJD·마리오네트·마네킹·분라쿠) 솔로 샘플 — Material Mix 틀 그대로(전 축 기본 랜덤), 재질 문장만 교체
import re, random, sys, collections
sys.path.insert(0, "../bg")
src = open("gen_matmix_bundle.py", encoding="utf-8").read()
exec(src[:src.index("for n in range(1, 6):")])
V = lambda nm, desc, solid, nmw, base, acc, fin, tag: (nm, desc, solid, nmw, base, acc, fin, tag)
DOLL = [
 V("porcelain", "smooth matte white bisque porcelain ball-jointed doll", "bisque porcelain", "bisque porcelain",
   "BLAZING flawless matte pale-white bisque porcelain across the full torso both legs neck to ankle",
   "VIVID bright cobalt-blue ball joints standing out sharply against the white, faint painted blush on every knuckle, elbow and knee", "soft matte bisque", "도자기 BJD"),
 V("resin", "satin pale mint-green resin ball-jointed doll", "cast resin", "cast resin",
   "BLAZING smooth satin pale mint-green resin across the full torso both legs neck to ankle",
   "VIVID deep wine-red ball joints standing out sharply against the mint-green, dark elastic cord glimpsed inside every joint gap", "soft satin-gloss", "레진 BJD"),
 V("wooden", "carved honey-beech wooden marionette", "carved beechwood", "carved beechwood",
   "BLAZING warm honey-gold beechwood grain across the full torso both legs neck to ankle",
   "VIVID bright teal-blue painted ball joints standing out sharply against the honey-gold wood, thin taut strings running from her head, shoulders, elbows, wrists, hips and knees straight up out of the top of the frame", "hand-waxed satin", "마리오네트"),
 V("wooden", "pale lacquered wooden artist's mannequin", "lacquered wood", "lacquered wood",
   "BLAZING smooth pale birch-blonde lacquered wood across the full torso both legs neck to ankle",
   "VIVID dark walnut-brown ball joints standing out sharply against the pale wood, each with a steel pivot screw, and a thin black seam down the spine", "smooth lacquered satin", "목각 마네킹"),
 V("ceramic", "glazed ivory ceramic ball-jointed doll mended with gold", "glazed ceramic", "glazed ceramic",
   "BLAZING glossy ivory-white glaze across the full torso both legs neck to ankle",
   "VIVID glossy emerald-green lacquer ball joints standing out sharply against the ivory, bright gold kintsugi seams zigzagging across every segment", "high-gloss glazed", "킨츠기 BJD"),
 V("gofun", "white gofun-painted wooden Japanese bunraku puppet", "gofun-painted wood", "gofun-painted wood",
   "BLAZING chalk-white gofun shell paint across the full torso both legs neck to ankle",
   "VIVID vermilion-red painted joints and thin black silk cords tied around every wrist, elbow and knee", "soft matte shell-white", "분라쿠 인형"),
]
NEWV["doll"] = DOLL
_orig_nv = person_nv
def person_nv(label, key, phys, age, pose, eth):
    if key != "doll": return _orig_nv(label, key, phys, age, pose, eth)
    nm, desc, solid, nmw, base, acc, fin, tag = CUR_VAR[(label, key)]
    pn, pd = phys; p = f"{label}: " if label else ""
    mat = (f"full body {desc} body fused directly to her own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, this is a solid {solid} doll body curving to follow her body's true three-dimensional shape, divided into smooth fitted {nm} segments, and at her neck, shoulders, elbows, wrists, hips, knees and ankles every segment ends in a round exposed ball joint seated in its socket with a thin dark gap and its own small shadow, nothing lying flat. Dense fitted segments — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    feat, seg, info = face(eth); skin = eth[1]
    hl = HEEL_ if HEELMODE[0] == "forty" else HEEL_REL
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of the same {nmw}, each with {hl}, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, made of the same {nmw} with a high polish."
    fc = f"{p}Face: her face and ears are NOT part of the doll body — they are real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair()} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    return "\n".join([body, shoe, nails, jw, fc]), info
rg = random.Random(int(sys.argv[1]) if len(sys.argv) > 1 else 20261013)
out = ["# 레진 BJD 솔로 (민트그린 몸 · 와인레드 관절)\n",
       "체형·인종·나이·포즈·헤어·네일·주얼리·배경·힐은 Material Mix와 같은 기본 랜덤입니다. 번호별로 정상/이상만 알려주세요. 이상이면 어떤 점인지 한 줄만요(예: 관절이 몸과 같은 색임, 얼굴도 인형이 됨).\n"]
lens = []
SEL=[1]
for i, v in enumerate([DOLL[k] for k in SEL], 1):
    for attempt in range(300):
        n = 1
        physs = [rg.choices(BIG5, W5)[0]]
        CUR_VAR.clear(); CUR_VAR[(None, "doll")] = v
        ages = [rg.choice(AGES)]; poses = [rg.choice(POSES)]; eths = rg.sample(ETH, 1)
        bid, wx = BGL.pick(rg, 1)
        scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
        ns2["JR"].seed(rg.randrange(10**9))
        t, infos = build3(["doll"], [v], physs, ages, poses, eths, scene)
        t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as her.", 1)
        if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t): continue
        break
    else: raise SystemExit("fail")
    wc = len(t.split()); lens.append(wc)
    hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
    out.append(f"## {i}. {v[7]} 솔로 · 체형 {physs[0][0]} · 인종 {eths[0][0]} · {infos[0]} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko}\n\n```\n{t}\n```\n")
    print(i, v[7], wc)
open(O + "LumineX_DollJoint_ResinSolo_1.md", "w", encoding="utf-8").write("\n".join(out))
print(min(lens), max(lens), O)
