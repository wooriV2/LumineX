# -*- coding: utf-8 -*-
import re, random, sys
_s = open("mk_doll3.py", encoding="utf-8").read()
exec(_s[:_s.index("rg = random.Random(")])
rg = random.Random(int(sys.argv[1]) if len(sys.argv) > 1 else 20261017)
V = lambda nm, desc, solid, nmw, base, acc, fin, tag: (nm, desc, solid, nmw, base, acc, fin, tag)
EDIBLE = {
 "choc": V("chocolate", "glossy tempered dark chocolate", "chocolate", "chocolate", "BLAZING deep glossy dark-chocolate brown across the full torso both legs neck to ankle", "VIVID creamy white-chocolate drizzle lines and tiny gold-leaf flecks across the surface", "mirror-glossy tempered", "다크 초콜릿"),
 "honey": V("honeycomb", "golden honey-filled honeycomb", "honeycomb wax and honey", "honeycomb wax", "BLAZING hexagonal wax cells brimming with glowing golden honey across the full torso both legs neck to ankle", "VIVID deeper amber pools of honey shimmering inside every cell", "wet glossy", "벌집 꿀"),
 "candy": V("candy", "melting swirled hard candy", "hard candy", "hard candy", "BLAZING candy-red and cream-white swirled stripes of glossy molten sugar across the full torso both legs neck to ankle", "VIVID clear sugar-glass edges glinting along the swirls and tiny rainbow sprinkles caught in the sticky surface", "high-gloss sticky", "녹은 사탕"),
 "jelly": V("jelly", "wobbling raspberry gelatin jelly", "jelly", "jelly", "BLAZING glossy translucent raspberry-red jelly across the full torso both legs neck to ankle", "VIVID tiny suspended fruit slices and air bubbles glowing inside the body", "wet glossy", "라즈베리 젤리"),
 "icecream": V("ice cream", "soft-serve strawberry and vanilla ice cream", "ice cream", "ice cream", "BLAZING pale pink strawberry and cream-white vanilla swirls across the full torso both legs neck to ankle", "VIVID colorful sprinkles and thick chocolate sauce swirls across the surface", "glossy melting", "딸기 바닐라 아이스크림"),
 "cake": V("buttercream", "pastel buttercream-frosted cake", "frosted cake", "pastel sugar paste", "BLAZING smooth pastel pink buttercream frosting across the full torso both legs neck to ankle", "VIVID piped white rosettes, pearl-white sugar beads and tiny macarons set along the body", "soft matte frosted", "버터크림 케이크"),
}

CLAUSE = {
 "choc": "thick molten rivulets of it streaming down her body in glossy ribbons and pooling in shining puddles around her feet",
 "honey": "thick golden honey streaming from the cells down her body in long glossy strands and pooling in shining puddles around her feet",
 "candy": "thick glossy sugar syrup in red and white swirls slowly stretching and dripping down her body in long sticky strands and pooling in shining puddles around her feet",
 "jelly": "soft and wobbling, light glowing through the translucent body so that suspended fruit slices and bubbles show inside",
 "icecream": "soft scoops and swirls slowly melting, thick creamy drips running down her body and pooling in puddles around her feet",
 "cake": "thick piped frosting standing out in deep sculpted relief, with golden sponge cake layers showing at the cut edges",
}
RIGID = re.compile(r"this is solid (.*?) curving to follow her body's true three-dimensional shape, divided into dozens of fitted .*? sections, each joint standing in a thin raised ridge catching its own bright glint and casting its own small shadow, nothing lying flat\. Dense fitted sections — ", re.S)

TRANSL = {"honey", "candy", "jelly"}
EPAT = ["fine edible gold-leaf flecks scattered across the surface", "thin glossy drizzle lines tracing every curve of her body", "tiny sugar pearls pressed along the surface"]
for k, v in EDIBLE.items(): NEWV[k] = [v]
_prev_nv = person_nv
def person_nv(label, key, phys, age, pose, eth):
    if key not in EDIBLE: return _prev_nv(label, key, phys, age, pose, eth)
    global PAT
    old = PAT; PAT = EPAT
    try: t, info = _orig_nv(label, key, phys, age, pose, eth)
    finally: PAT = old
    t, nsub = RIGID.subn(lambda m: f"this is real {m.group(1)} curving to follow her body's true three-dimensional shape, {CLAUSE[key]}, nothing lying flat. Dense surface — ", t, 1); assert nsub == 1
    if key in TRANSL: t = t.replace("completely opaque", "richly saturated in colour", 1)
    return t, info
out = ["# 녹은 사탕 샘플 1개 — 초콜릿 · 벌집 꿀 · 스트라이프 캔디 · 젤리 · 아이스크림 · 버터크림 케이크\n",
       "Material Mix와 같은 기본 랜덤입니다. 번호별로 정상/이상만 알려주세요. 이상이면 한 줄만요(예: 몸이 재질로 안 덮임, 얼굴도 재질이 됨, 재질 질감이 안 나옴).\n"]
for i, (k, v) in enumerate([("candy", EDIBLE["candy"])], 1):
    for attempt in range(300):
        physs = [rg.choices(BIG5, W5)[0]]
        CUR_VAR.clear(); CUR_VAR[(None, k)] = v
        ages = [rg.choice(AGES)]; poses = [rg.choice(POSES)]; eths = rg.sample(ETH, 1)
        bid, wx = BGL.pick(rg, 1)
        scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
        ns2["JR"].seed(rg.randrange(10**9))
        t, infos = build3([k], [v], physs, ages, poses, eths, scene)
        t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as her.", 1)
        if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t): continue
        break
    else: raise SystemExit("fail")
    hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
    out.append(f"## {i}. {v[7]} 솔로 · 체형 {physs[0][0]} · 인종 {eths[0][0]} · {infos[0]} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko}\n\n```\n{t}\n```\n")
    print(i, v[7], len(t.split()))
open(O + "LumineX_Edible_CandyMelt_1.md", "w", encoding="utf-8").write("\n".join(out))
