import re,random,json,collections,sys
g=open('gen_fs2.py',encoding='utf-8').read()
exec(g[:g.index('if __name__=="__main__":')])
m=open('mk_group4.py',encoding='utf-8').read()
exec(m[m.index('END="'):m.index('TEXT.update')])
cnt_old={"러시안 립 과장":6,"러시안 립 초과장":6,"러시안 립 초과장+1":6,"러시안 립 판타지 한계":6,"러시안 립 초초과장":6,"러시안 립 극한":6,"체리 립":8,"키홀 퓨트 +1":8,"큐피드 보우":6,"립 플립":5,"립 리프트":5}
cnt_new={"덕 립 극한":9,"드롭 립 극한":9,"바르도 립 극한":9,"와이드 립 극한":9,"오 립 극한":8,"고양이 입 극한":8}
LIP3=[(n,t,cnt_old[n]) for n,t,c in LIP]+[(n,NEWLIP[n],c) for n,c in cnt_new.items()]
assert sum(c for n,t,c in LIP3)==120
rr=random.Random(20261014)
jobs=[]
for name,text,c in EYE2: jobs+=[("eye",name,text)]*c
for name,text,c in LIP3: jobs+=[("lip",name,text)]*c
for name,fn,c in ARCH: jobs+=[("arch",name,fn)]*c
print(len(jobs))
tusk_flag=False
out=[]
for i,(kind,name,text) in enumerate(jobs,1):
    out.append(build2(i,kind,name,text,rr))
json.dump(out,open(OUT+'la_facesculpt_300_bundle_v2.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
print(collections.Counter(x["meta"]["star"] for x in out if x["meta"]["kind"]=="lip"))
print(collections.Counter(x["meta"]["piercing"] for x in out))
print(collections.Counter(len(x["meta"]["addons"]) for x in out))
print(collections.Counter(x["meta"]["ear_mode"] for x in out), collections.Counter(x["meta"]["ear_holes"] for x in out))
w=[len(x["prompt"].split()) for x in out]; print(min(w),max(w),sum(w)/len(w))
ks=[x["key"] for x in out]; print(len(set(ks)),ks[0],ks[-1])
print("korean",sum(1 for x in out if re.search(r"[가-힣]",x["prompt"])), "tusk",sum(1 for x in out if x["meta"]["tusk"]))
