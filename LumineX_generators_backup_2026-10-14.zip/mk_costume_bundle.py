import json, collections
exec(open('mk_cloth_bundle.py', encoding='utf-8').read().split("rg = random.Random(20267002)")[0], globals())
O_ = "/mnt/user-data/outputs/"
COST = json.load(open('cost_pool.json', encoding='utf-8'))
POSES = [p for p in POSES if "arms crossed under her bust" not in p and "framing the face" not in p]
THIN = {"curvy petite", "wide hip narrow"}
MUSC = ["amazoness", "powerlifter bombshell", "heavy muscle", "muscular hourglass BBW", "amazon bombshell", "powerlifter"]
BUSTB = ["legendary bust", "curved bust"]
HIPB = ["super hourglass", "hourglass bombshell", "glamour hourglass", "black glamour", "Brazilian booty glam", "latina curves", "Nubian booty builder", "super glamour", "Polynesian goddess"]
BIGB = ["BBW bombshell", "hourglass SSBBW", "USSBBW"]
REST = [b[0] for b in BODIES22 if b[0] not in THIN]
GRP = {}
for k in ("여전사", "경찰관", "해적", "레이싱 퀸", "닌자", "복서", "군인"): GRP[k] = MUSC
for k in ("간호사", "의사", "선생", "메이드", "마녀", "승무원", "소방관", "뱀파이어"): GRP[k] = BUSTB
for k in ("바니걸", "악마", "천사", "카우걸", "치어리더", "산타", "인어", "벨리 댄서", "여왕", "이집트 여왕", "요정", "훌라", "서퍼"): GRP[k] = HIPB
GRP["훌라"] = ["Polynesian goddess"]
assert set(GRP) == set(COST), set(COST) ^ set(GRP)
NAMES = {1: "solo", 2: "duo", 3: "trio", 4: "quartet", 5: "quintet"}; KOCNT = {1: "솔로", 2: "듀오", 3: "트리오", 4: "쿼르텟", 5: "퀸텟"}
rg = random.Random(20267501); rr.seed(20267501); ns2["JR"].seed(20267501)
SEEN = set()
def eth_for(bname):
    lk = D.BODY_LINK.get(bname)
    return rg.sample([e for e in ETH if e[0] in lk], 1)[0] if lk else rg.sample(ETH, 1)[0]
def body_for(cname):
    r = rg.random()
    if r < 0.60: return rg.choice(GRP[cname])
    if r < 0.75: return rg.choice(BIGB)
    return rg.choice(REST)
def post(t):
    t = t.replace("Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle.", "Extreme macro detail on the fabric texture, the skin and the shadows.")
    return t.replace("no props or statues made of the same material as any of them.", "no props or statues.").replace("no props or statues made of the same material as her.", "no props or statues.")
def gen(entries, bodyfns, bgs_list):
    """entries: [(nmw,text)] 길이 n, bodyfns: 각 인물의 체형 선택 함수, bgs_list: 허용 배경(or None)"""
    n = len(entries)
    for attempt in range(3000):
        CUR_VAR.clear(); kinds = []; picks = []
        for idx, (nmw, text) in enumerate(entries):
            CUR_VAR[(None if n == 1 else f"#{idx+1}", "clothp")] = dict(text=text, nmw=nmw); kinds.append("clothp"); picks.append(None)
        names = []
        while len(names) < n:
            c = bodyfns[len(names)]()
            if c not in names: names.append(c)
        physs = [phys_of(BODY[c], n == 1) for c in names]
        ages = [rg.choice(AGES) for _ in range(n)]
        if n == 1: poses = [rg.choice(SEAT) if (names[0] in EXTREME and rg.random() < 0.7) else rg.choice(POSES)]
        else: poses = [rg.choice(POSES) for _ in range(n)]
        eths = [eth_for(c) for c in names]
        bid, wx = BGL.pick(rg, n)
        al = [b for b in bgs_list if b]
        if any(BGL.BG[bid][2] not in a for a in al): continue
        scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty" if (n > 1 or rg.random() < 0.55) else "relative"
        ns2["JR"].seed(rg.randrange(10**9))
        t, infos = build3(kinds, picks, physs, ages, poses, eths if n > 1 else [eths[0]], scene) if n > 1 else build3(kinds, picks, physs, ages, poses, [eths[0]], scene)
        t = post(t)
        if not chk(t) or t in SEEN or re.search(r"\b(foil|lens|sticker|doll)\b", t, re.I): continue
        if "Pattern density" in t: continue
        if t.count("forty inches") != (n if HEELMODE[0] == "forty" else 0) or t.count("Jewelry:") != n: continue
        SEEN.add(t)
        mks = [mk_clean(i.replace("메이크업 ", "", 1).split(" · ")[0]) for i in infos]
        asp = re.search(r"(\d+:\d+) aspect ratio", t)
        return dict(t=t, n=n, bodies=names, eths=[e[0] for e in eths], poses=poses, bid=bid, wx=wx, heel=HEELMODE[0], mk=mks, asp=asp.group(1) if asp else None)
    raise SystemExit("fail gen")
out = []
def add(r, pref, series, cat, k, outfits, fmt, labels=None):
    n = r["n"]
    pose = pose_ko(r["poses"][0]) if n == 1 else ""
    title = " · ".join(x for x in [f"{series} {KOCNT[n]} #{k:03d}", r["bodies"][0] if n == 1 else agg(r["bodies"]), agg(labels or outfits), pose, BGL.BG[r["bid"]][2], agg(r["mk"])] if x)
    meta = {"group_size": n, "aspect_ratio": r["asp"], "format": fmt, "family": series, "outfit": outfits[0] if n == 1 else outfits, "physiques": r["bodies"], "ethnicity": r["eths"], "poses": r["poses"],
            "background": r["bid"], "weather": r["wx"][0] if r["wx"] else None, "heel_mode": r["heel"], "jewelry": True}
    out.append({"key": f"{pref}{NAMES[n]}_{k:03d}", "category": cat, "title": title, "prompt": r["t"], "meta": meta})
CAT_C = "🏺 Living Artifact · Costume Formula"; CAT_G = "🏺 Living Artifact · Outfit Group Formula"
# 코스튬 솔로 28종 × 5
solo = [c for c in COST for _ in range(5)]; rg.shuffle(solo)
for k, c in enumerate(solo, 1):
    add(gen([COST[c]], [lambda c=c: body_for(c)], [None]), "la_costume_", "Costume", CAT_C, k, [c], "costume")
# 코스튬 그룹
for n, cnt in ((2, 25), (3, 20), (4, 15), (5, 15)):
    for k in range(1, cnt + 1):
        cs = rg.sample(list(COST), n)
        add(gen([COST[c] for c in cs], [lambda c=c: body_for(c) for c in cs], [None] * n), "la_costume_", "Costume", CAT_C, k, cs, "costume")
# 의상 그룹 (체형 특화 제한이 없는 패밀리만)
POOLC = {}
for pref, series, ck, ents in FAM:
    for (ko, nmw, text, bgs, bodies) in ents:
        if bodies is not None: continue
        POOLC.setdefault(f"{series}:{ko}", (nmw, text, bgs))
SERKO = {"Slit": "슬릿 미니", "UltraMini": "초미니 슬릿", "Belt": "벨트", "Band": "스카프·퍼 띠", "Bandeau": "밴도", "Bikini": "비키니", "Latex": "라텍스 캣슈트", "Mesh": "메시 보디수트", "Cutout": "컷아웃", "Plunge": "딥 플런지"}
SER = sorted({k.split(":")[0] for k in POOLC})
for n, cnt in ((2, 30), (3, 25), (4, 20), (5, 20)):
    for k in range(1, cnt + 1):
        sers = rg.sample(SER, n); ks = [rg.choice([x for x in POOLC if x.startswith(s + ":")]) for s in sers]
        add(gen([POOLC[x][:2] for x in ks], [lambda: rg.choice(REST) for _ in ks], [POOLC[x][2] for x in ks]), "la_clothes_", "OutfitGroup", CAT_G, k, [x.split(":", 1)[1] for x in ks], "outfit-group", [SERKO[x.split(":")[0]] for x in ks])
assert len({p["key"] for p in out}) == len(out) and len({p["prompt"] for p in out}) == len(out)
json.dump(out, open(O_ + "la_costume_310_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(out)); print(collections.Counter(p["category"] for p in out)); print(collections.Counter(p["meta"]["group_size"] for p in out))
