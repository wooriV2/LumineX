import re,random,sys
sys.path.insert(0,'.')
_G5=open('mk_group5.py',encoding='utf-8').read()
exec(_G5[:_G5.index("R=_r.Random(20261013)")])
f6=open('gen_fs6.py',encoding='utf-8').read()
exec(f6[f6.index('TAILO='):f6.index('jobs=[]')])      # SW, S1, B1, CX
g3=_G5[_G5.index("def group3"):_G5.index("BGN=")]
def sub(a,b,count=1):
    global g3
    assert g3.count(a)>=1,a[:60]
    g3=g3.replace(a,b) if count==0 else g3.replace(a,b,count)
sub("def group3(seed,spec,mode,ear,h,bgname):","def group5(seed,spec,mode,bgname):")
sub("    fas=rr.sample(range(len(FORMS)),n)\n","    fas=rr.sample(range(len(FORMS)),n)\n    EARS,HS,METS=pick_ears(rr,n)\n")
sub("    for (kind,name),nat,fa in zip(spec,nats,fas):\n","    for pi,((kind,name),nat,fa) in enumerate(zip(spec,nats,fas)):\n        ear=EARS[pi]; h=HS[pi]\n")
# per-person ear metal sentence + label
sub("                p=ear_person(p,ear,h,fa,rr)\n","                p=ear_person(p,ear,h,fa,rr)\n                p=add_metal(p,ear,METS[pi])\n")
# keep the realism sentence in 4-5 person prompts (the shortened weights list still goes)
sub('''                    s_=s_.replace(" Her whole face, ears and neck are real living flesh with real pores and fine skin grain, real living eyes with bright catchlights and genuine depth, individual hair strands catching the light.","")\n''',"                    pass\n")
sub('''                if ear!="earring": l=l.replace("2구멍",f"{h}구멍")
                else: l=re.sub(r"귀 추 \\d+개/귀 2구멍","대형 귀걸이 "+FORMLAB[fa],l)''','''                if ear!="earring": l=l.replace("2구멍",f"{h}구멍")
                else: l=re.sub(r"귀 추 \\d+개/귀 2구멍","대형 귀걸이 "+FORMLAB[fa],l)
                l=l+" · 귀 "+{"iron":"철 추","mix":"혼합 금속 추","one":"단일 금속 추("+KOR.get(METS[pi] or "","")+")","earring":"대형 귀걸이"}[ear]''')
sub('''    hang="the long earrings" if ear=="earring" else "the weights"''','''    hang="the long earrings" if all(e=="earring" for e in EARS) else ("the weights" if all(e!="earring" for e in EARS) else "the weights and the long earrings")''')
# ear paragraphs
a=g3.index('    if ear=="earring":\n        earp=')
b=g3.index('    ratio=')
g3=g3[:a]+'''    wearers=[e for e in EARS if e!="earring"]; earpl=[e for e in EARS if e=="earring"]
    W={4:"four",6:"six"}[nw]; parts_e=[]
    if wearers:
        share_w=HW2.format(col=COL2[nw]).replace("On each ear the two iron rings each carry","On each ear of every woman the two iron rings each carry")
        for a_,b_ in [("hanging side by side on chains of different lengths","hanging side by side, each weight on its own thick chain of heavy links of the same metal as the weight, the chains of different lengths"),("reaching down along her neck to her collarbones","reaching down along the neck to the collarbones"),("hangs just past her jaw; the lobe does not sag, droop, collapse or hang down to her shoulder, her head stays upright, and","hangs just past the jaw; no lobe sags, droops, collapses or hangs down to the shoulder, every head stays upright, and")]:
            assert a_ in share_w,a_; share_w=share_w.replace(a_,b_)
        w_=share_ear(share_w,nw,"iron",2,rr)
        w_,n1=COLS_RE2.subn(f"On each ear of every woman who wears weights, all {W} weights hang from her iron rings in staggered columns",w_); assert n1==1
        k_="an enormous, dense, completely solid, squat, blunt lump of rough black cast iron"; assert k_ in w_
        w_=w_.replace(k_,"a massive, dense, solid, squat, blunt lump of rough, matte, unpolished heavy metal, in the metal named in her own paragraph")
        k2_="Because the load is shared between two openings,"; assert k2_ in w_
        w_=w_.replace(k2_,"Because the load is carried by her iron rings,")
        parts_e.append("Ear weights"+(", for the women who wear weights in their lobes" if earpl else "")+": "+w_)
    if earpl:
        parts_e.append("Earrings: "+("each woman's large earrings hang freely in the air down to the level of her collarbone and no lower" if not wearers else "the large earrings of the women who wear them hang freely in the air down to the level of the collarbone and no lower")+", and no earring of one woman hangs in front of another woman's face.")
    earp="\\n\\n".join(parts_e)
'''+g3[b:]
sub('''    pend="the hanging pieces of one never hang" if ear=="earring" else "the weights of one never hang"''','''    pend="the hanging pieces of one never hang"''')
sub('''    assert not re.search(r"two iron rings|two openings|two columns",t) or h==2\n''',"")
COLS_RE2=re.compile(r"On each ear of every woman the two iron rings each carry their own column of weights, the two columns holding [^,]*? weights, hanging side by side")
def pick_ears(rr,n):
    modes=["iron","mix","one","earring"]
    e=rr.sample(modes,n) if n<=4 else rr.sample(modes,4)+[rr.choice(modes)]
    rr.shuffle(e)
    hs=[rr.choices([1,2,3],[75,161,64])[0] for _ in e]
    ms=[]; used=set()
    for x in e:
        if x=="one":
            m=rr.choice([k for k in METALS if k not in used and not (k=="iron" and "iron" in e)] or ["gold"]); used.add(m); ms.append(m)
        else: ms.append(None)
    return e,hs,ms
def add_metal(p,ear,m):
    if ear=="mix": return p.rstrip()+" Her ear weights are each a different shape and a different metal among gold, bronze, iron, tin, brass, silver, copper and lead."
    if ear=="one": return p.rstrip()+f" Her ear weights are all {SHORTM[m]}, each a different shape."
    return p
exec(g3)
WT_RE=re.compile(r" All the ear weights hang from the bottoms of [^,]*,.*?(?= The face and ear jewelry)",re.S)
BIG_RE=re.compile(r"; its size does NOT shrink.*?unmistakably heavy, ",re.S)
def real2(t):
    t,nB=re.subn(re.escape(S1)+r'\.?',lambda m:B1,t)
    def fix(m):
        p=m.group(0)
        if re.search(r"Bratz|Barbie|succubus|mermaid siren",p):
            for a,b in SW: p=p.replace(a,b)
            p=p.replace("..",".")
        else:
            for a,b in CX: p=p.replace(a,b)
        return p
    return re.sub(r"(?<=\n\n#\d: ).*?(?=\n\n#\d )",fix,t,flags=re.S),nB
def shorten(t):
    t,k=WT_RE.subn("",t)
    t,k2=BIG_RE.subn("; the last weight is as big and heavy-looking as the first, each chain pulled bar-straight and taut, ",t)
    return t,k,k2
def sample(R,n):
    spec=draw_spec(R,n); bg=R.choice(BGN)
    haslip=any(k=="lip" for k,_ in spec)
    mode="q45" if (n==4 and haslip and R.random()<0.5) else "front"
    for tr in range(400):
        try: t,labs,dup=group5(R.randrange(10**7),spec,mode,bg)
        except AssertionError: continue
        mk=[l.split(" · ")[4] for l in labs if "유형 고유 메이크업" not in l]
        if len(set(mk))<len(mk) or sum(x=="메이크업 없음" for x in mk)>1: continue
        if dup and dup.split()[0].lower() not in("had","that"): continue
        break
    else: raise SystemExit("fail")
    return spec,bg,mode,t,labs
if __name__=="__main__":
    R=random.Random(20261023)
    for n in (2,3,4,5):
        spec,bg,mode,t,labs=sample(R,n)
        t0=len(t.split()); t,nB=real2(t); t,k,k2=shorten(t); t=re.sub(r"  +"," ",t)
        print(n,t0,len(t.split()),"B1",nB,"wt",k,"big",k2,mode,[l.split(" · ")[-1] for l in labs])
