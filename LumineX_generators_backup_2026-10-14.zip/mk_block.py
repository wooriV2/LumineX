# -*- coding: utf-8 -*-
# 블록 조립(장난감 조립 블록) 샘플 — mk_new_bundles 틀, 전 축 기본 랜덤
_src = open("mk_new_bundles.py", encoding="utf-8").read()
exec(_src[:_src.index('if __name__')])
BT = ("body built from thousands of small interlocking glossy plastic bricks stacked in staggered rows, the bricks stepping in tiny stair-like layers along her curves so the whole figure still follows her body's true three-dimensional shape, a regular grid of round cylindrical studs clearly visible on every upward-facing brick surface, thin dark seams between every brick, nothing lying flat. Dense brick surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
def blk(nm, desc, base, acc, tag, kind):
    return dict(kind=kind, tag=tag, desc=desc, solid="toy-brick", nm=nm, nmw="plastic toy bricks", base=base, acc=acc, fin="glossy hard plastic")
BLOCKS = [
 blk("brick", "classic multicolour interlocking plastic toy-brick sculpture",
     "BLAZING bold blocks of vivid red, sunny yellow, bright blue and white bricks across the full torso both legs neck to ankle",
     "VIVID a few bright green and orange bricks mixed among them, and glossy highlights catching on every round stud", "원색 블록 조립", "block_primary"),
 blk("brick", "single-colour interlocking plastic toy-brick sculpture",
     "BLAZING glossy turquoise-blue bricks across the full torso both legs neck to ankle",
     "VIVID a scattering of pure white bricks forming bold stripes along her sides, and glossy highlights catching on every round stud", "터키석 단색 블록 조립", "block_mono"),
]
def mat_blk(v): return HEAD.format(desc=v["desc"], solid=v["solid"]) + BT.format(base=v["base"], acc=v["acc"], fin=v["fin"]), v["nmw"], "part of the brick figure"
def chk(t): return not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t) and "navel" not in t.lower()
rg = random.Random(20261114); rr.seed(20261114); ns2["JR"].seed(20261114)
o1 = ["# 블록 조립 샘플 2개 — 원색 · 터키석 단색\n", "Material Mix와 같은 기본 랜덤입니다(체형·나이·포즈·인종·배경·힐·네일·주얼리). 번호별로 정상/이상만 알려주세요. 이상이면 한 줄만요.\n"]
for i, v in enumerate(BLOCKS, 1):
    for _ in range(500):
        phys = rg.choices(BIG5, W5)[0]; age = rg.choice(AGES); pose = rg.choice(POSES); eth = rg.sample(ETH, 1)[0]
        bid, wx = BGL.pick(rg, 1); scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
        ns2["JR"].seed(rg.randrange(10**9))
        mat, nmw, part = mat_blk(v)
        body, info = assemble(mat, nmw, part, phys, age, pose, eth)
        env = f"{scene}, bright and evenly lit, shadows soft, the whole floor and surroundings clearly visible and in focus, NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as her."
        tail = f"Background: {env} ONE woman only. Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
        t = f"Professional fashion photograph, full body shot. ONE woman standing.\n\n{body}\n\n{tail}{CAM} 8K portrait {ASP[1]} aspect ratio."
        if chk(t): break
    hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
    o1.append(f"## {i}. {v['tag']} 솔로 · 체형 {phys[0]} · 인종 {eth[0]} · {info} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko}\n\n```\n{t}\n```\n")
    print(i, len(t.split()), "forty" in t)
open(O + "LumineX_Block_Sample_2.md", "w", encoding="utf-8").write("\n".join(o1))
