import re,random
s=open('mk_file8.py',encoding='utf-8').read()
exec(s[:s.index('OUTS=[]')])
def make_base(rr,nat,grp,expr,style,N):
    for tr in range(80):
        try: return G.make(random.Random(rr.randrange(10**9)),nat,grp,expr,style=style,slots=["pierce"],pier_level="P25")
        except AssertionError: continue
    raise SystemExit("gen fail")
NOLENS=re.compile(r"the eyes are in very large coloured doll-eye contact lenses with a glossy shine and a big iris, both eyes the same, with a round natural pupil and bright catchlights")
NAT="한국"
ITEMS=["옆트임 극한(3배)","옆트임 최극한(4배)","양쪽 트임 6배+큰 눈","양쪽 트임 8배+거대한 눈"]
# find a seed whose base is Korean
for seed in range(1,400):
    r2=random.Random(seed)
    try: t,lab,lt,nw=base(r2,25,("tmp","brow","bri"),False,"",8,style0="NONE")
    except AssertionError: continue
    if lab.startswith(NAT): break
print("seed",seed,lab)
OUTS=[]
for name in ITEMS:
    text=TX[name]
    text=LINER.sub(PLAIN,text) if LINER.search(text) else re.sub(r"a razor-sharp black (?:eyeliner|liner) follows the entire shape and ends in a[^;]*;",PLAIN,text)
    assert "liner" not in text.replace("no eyeliner",""), name
    assert NOLENS.search(text), name
    if name.startswith("양쪽 트임 6배"):
        k="the small pink inner corners reaching almost to the sides of her nose bridge,"; assert k in text
        text=text.replace(k,k+" so the gap between the two inner corners is less than a third of the width of one eye, with only a very narrow strip of nose bridge between the eyes, far closer together than in a normal face,")
    if name.startswith("양쪽 트임 8배"):
        k="the small pink inner corners clearly visible on either side of the nose bridge,"; assert k in text
        text=text.replace(k,k+" so the gap between the two inner corners is only about the width of a fingertip, a very narrow strip of nose bridge between the eyes, far closer together than in a normal face,")
    text=NOLENS.sub("natural dark brown eyes with a big iris, a round natural pupil and bright catchlights, with no contact lenses at all",text)
    r2=random.Random(seed)
    t,lab,lt,nw=base(r2,25,("tmp","brow","bri"),False,"",8,style0="NONE")
    sj=subj(t); jaw=r2.choice(JAWS); nose=r2.choice(NOSES)
    star=f"her eyes are the star of her face (the shape and size described here override the eyes of her makeup, and she wears no eyeshadow, no eyeliner and no contact lenses at all): {text}"
    add=f" Her face has been surgically sculpted far beyond her natural look, and these changes override her natural features: {star}; her nose: {nose[1]}; her jawline and chin: {jaw[1]}. Every feature is exaggerated but beautiful, balanced and refined, in harmony with the rest of her face, never distorted, never grotesque."
    t=t.replace(sj,sj+add)
    t,lab2=finish(t,"iron",nw,r2,lab+f" · 귀 추 {nw}개/귀 2구멍",None)
    t=re.sub(r"  +"," ",t)
    assert not re.search(r"[가-힣]",t) and "{" not in t
    assert not re.search(r"contact lens",re.sub(r"no contact lenses at all","",t)), re.findall(r"[^.]{0,80}contact lens[^.]{0,60}",re.sub(r"no contact lenses at all","",t))[:2]
    OUTS.append((f"{name} · 렌즈 없음 · 같은 인물·같은 틀 · "+lab2,t)); print(len(OUTS),len(t.split()))
o=["# LumineX — 트임 눈 크기 비교 v2 (4개, 렌즈 없음, 양쪽 트임에 안쪽 눈 간격 추가)\n","- 1 옆트임 3배, 2 옆트임 4배, 3 양쪽 트임 6배, 4 양쪽 트임 8배. 인물·메이크업(없음, 아이섀도·아이라이너 없음)·피어싱·귀 추를 모두 같게 두고 눈 문장만 바꿨습니다. 정상/이상 번호만 알려주세요.\n"]
for i,(title,p) in enumerate(OUTS,1): o.append(f"## {i}. {title}\n\n```\n{p}\n```\n")
open(OUT+'LumineX_CanthusSize_Compare_4_v2.md','w',encoding='utf-8').write("\n".join(o))
