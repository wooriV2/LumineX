import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
from cover_lib import SAFE
IRON="rough black cast iron with a hammered, pitted, matte surface"
HEAVY="Every weight is an enormous, dense, completely solid, squat, blunt lump of rough black cast iron, as big as a fist, with no thin parts, no arms and no hollow parts, crushingly and unmistakably heavy; every chain is thick and pulled bar-straight and taut by the load."
SK="The skin around the piece is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
def mk(size,dsc):
    return ("Piercings: Exactly one piercing in total, a single large healed hole through the middle of the lower lip, and nowhere else: a thick round plate of "+IRON+f" {size} is set into this hole like a plate in a socket, its flat face turned toward the viewer, and the pierced lower lip is stretched around it, wrapping the whole rim of the plate as a thin, smooth, taut ribbon of real lip skin in her natural lip colour, so the lip is clearly seen holding the plate all the way round; the plate does not cover the rest of her mouth: her upper lip, her teeth line and the corners of her mouth stay fully bare and visible above it, and her chin below it stays visible. Three separate massive solid weights hang from the bottom edge of the plate on thick chains of heavy black iron links, one cube-shaped block, one cannonball and one ingot block, at different lengths down past her chin onto her chest. "+HEAVY+" "+SK+" Everything else on her face and ears is completely free of piercings. All jewelry is real blackened cast iron,"+SAFE)
V=[("A — 지름 입 너비 정도","as wide as her mouth"),("B — 더 작게, 손가락 세 개 너비","as wide as three of her fingers laid side by side")]
NA=[("한국","20대","도도한"),("일본","20대","군림하는")]
o=["# LumineX — 립 플레이트 재작성 2개 (아랫입술에 구멍을 뚫고 플레이트를 끼워 입술이 감싼 표현)\n","- A는 지름이 입 너비 정도, B는 손가락 세 개 너비. 윗입술·입꼬리·턱이 보이게 하고, 입술 살이 플레이트 가장자리를 한 바퀴 감싸는 표현. 쇠뭉치 3개는 플레이트 아래에서 가슴까지.","- 정상/이상(+ 입술이 플레이트를 감쌌는지, 윗입술이 보이는지)만 번호로 알려주세요.\n"]
for i,((lab,sz),(nat,grp,ex)) in enumerate(zip(V,NA),1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(63000+i*100+tr),nat,grp,ex,style="NONE",slots=["pierce"],pier_level="P3"); break
        except AssertionError: continue
    else: raise SystemExit(i)
    old=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    t=re.sub(r'\n\nJewelry:[^\n]*','',t.replace(old,mk(sz,lab)))
    t,nn=re.subn(r'down to the base of her neck and the tops of her collarbones, the frame cutting off there','down to the middle of her chest, the frame cutting off there, so the chains and weights fully hang in view',t,count=1); assert nn==1
    t=t.replace("\n\nLighting:","\n\nHair: her hair is swept back behind both ears, leaving both ears, her jawline and her neck fully visible.\n\nLighting:",1)
    assert not re.search(r"[가-힣]",t)
    o.append(f"## {lab} — {title}\n\n```\n{t}\n```\n")
open('/mnt/user-data/outputs/LumineX_LipPlate_2.md','w',encoding='utf-8').write("\n".join(o)); print("ok")
