import sys,re,random,copy
sys.path.insert(0,'.')
import cjk_face_lib as C
import gen_cjk_v2 as G
for x in [f for f in G.F if f["meta"]["piercing"]=="P150"]:
    y=copy.deepcopy(x); y["meta"]["piercing"]="P200"; p=y["prompt"]
    p=p.replace("about one hundred and fifty","about two hundred").replace("ten fine","twelve fine")
    y["prompt"]=p; y["key"]=x["key"]+"_p200"; G.F.append(y)
MAT_FANCY=("All jewelry is real, made of many different materials and colours mixed piece by piece — yellow gold, silver, rose gold and platinum, glossy enamel in red, blue, green, yellow, pink, turquoise and purple patterned with stripes, polka dots, checks, filigree and mosaic inlay, and large cut rainbow gemstones (diamond, ruby, sapphire, emerald, amethyst, opal, topaz and pearl) — ")
MAT_CUTE=("All jewelry is real, made of pastel enamel in baby pink, mint, lavender, baby blue and butter yellow, white pearls, pastel gemstones (rose quartz, aquamarine, amethyst, citrine) and polished gold, cute and playful — ")
SHAPES={"수수":["round","triangle","square","pentagon","hexagon","diamond-lozenge","oval"],
        "화려":["round","triangle","square","pentagon","hexagon","star","heart","infinity-symbol","teardrop"],
        "귀여움":["heart","star","four-leaf clover","butterfly","flower","bow","round"]}
COLS={"화려":["red","cobalt-blue","emerald-green","sunshine-yellow","hot-pink","turquoise","violet","orange"],"귀여움":["baby-pink","mint","lavender","baby-blue","butter-yellow","peach"]}
GEMS={"화려":["ruby","sapphire","emerald","amethyst","opal","topaz","diamond","pearl"],"귀여움":["pearl","rose quartz","aquamarine","moonstone","citrine"]}
SIZE="Size is maximal in every version: each piece is as large as physically possible, far bigger than real-life jewelry, bold enough to be seen at a glance."
CENTRE={"P3":2,"P5":2,"P8":3,"P15":3,"P25":3,"P50":4,"P100":5,"P150":6,"P200":7}
NUM={3:"three",5:"five",8:"eight",15:"fifteen"}
def shp(sh): return "round O-ring" if sh=="round" else f"{sh}-shaped frame"
def mat(vibe,rr,metal):
    if vibe=="수수": return f"polished {metal} with a huge clear diamond"
    c=rr.choice(COLS[vibe]); g=rr.choice(GEMS[vibe])
    pat=rr.choice(["stripes","polka dots","checks","filigree"]) if vibe=="화려" else rr.choice(["tiny polka dots","a pearl rim","tiny hearts","a glossy sheen"])
    return f"glossy {c} enamel with {pat} and a large {g}"
def piece(kind,side,sh,vibe,rr,metal):
    m=mat(vibe,rr,metal); S=shp(sh)
    if kind=="ear_giant": return f"a gigantic {S.replace(' frame','')} drop earring on the {side} ear, as wide as her palm and as long as her hand, in {m}, with a waterfall of shaped drops hanging below it to her collarbone and shoulder"
    if kind=="ear_drop": return f"one long {S.replace(' frame','')} drop earring on the {side} ear hanging to her shoulder, in {m}"
    if kind=="ear_o": return f"a large classic round O-ring hoop in the {side} lobe, in {m}"
    if kind=="ear_up": return f"a medium classic round O-ring high on the {side} ear, in {m}"
    if kind=="ear_shape": return f"a large {S} in the {side} ear, in {m}"
    if kind=="nostril": return f"a classic round hoop wrapping snugly around the {side} nostril wing, in {m}"
    if kind=="brow": return f"a thick long bar ending in two large gemstone ends through the outer end of the {side} eyebrow, in {m}"
    if kind=="lip": return f"a large classic round O-ring through the lower lip's edge on the {side}, in {m}"
    if kind=="labret": return f"a big {sh.replace('round','round gem')}-shaped gem labret stud beneath the lower lip, in {m}"
    if kind=="c_bridge": return f"a {S} bar piece through the bridge of the nose, well below the eyes, in {m}"
    if kind=="c_tip": return f"a {sh.replace('round','round gem')}-shaped gem stud at the tip of the nose, in {m}"
    if kind=="c_sept": return f"a large {S} septum piece hanging from the middle of the nose, in {m}"
def plan_low(P,vibe,rr):
    s=lambda: rr.choice(["left","right"]); a=s(); b="right" if a=="left" else "left"
    big="ear_giant" if vibe=="화려" else ("ear_drop" if vibe=="귀여움" else "ear_o")
    if P=="P3": L=[("c_sept",""),("c_bridge","")]+[(big,a)]
    elif P=="P5": L=[("c_sept",""),("c_tip","")]+[(big,a),("ear_shape",a),("nostril",b)]; L=L[:5]
    elif P=="P8": L=[("c_bridge",""),("c_tip",""),("c_sept",""),(big,a),("ear_shape",a),("ear_up",a),("nostril",b),("brow",b)]
    else: L=[("c_bridge",""),("c_tip",""),("c_sept",""),(big,a),("ear_o",a),("ear_shape",a),("ear_up",a),("ear_shape",a),("ear_o",b),("nostril",a),("nostril",b),("brow",b),("brow",b),("lip",a),("labret","")]
    return L
def lowpp(P,vibe,rr,metal):
    shs=list(SHAPES[vibe]); rr.shuffle(shs); L=plan_low(P,vibe,rr); pcs=[]
    for i,(k,sd) in enumerate(L): pcs.append(piece(k,sd,shs[i%len(shs)],vibe,rr,metal))
    n=int(P[1:])
    body=f"Exactly {NUM[n]} piercings in total, asymmetric and spread over different parts of the face so each one is its own bold focal point — the nose centreline carries the septum and other nose-centre pieces in different shapes, the ears carry classic round O-rings with a few in other shapes, the nostril carries only a classic hoop wrapping the nostril wing, and the rest of the face and the other ear stay bare: "+"; ".join(pcs)+". "
    if n<=8: body+="No other piercing anywhere. "
    mt={"화려":MAT_FANCY,"귀여움":MAT_CUTE}.get(vibe, f"All jewelry is real {metal} set with huge clear diamonds, a simple one-colour palette — ")
    return "Piercings: "+body+"Every piece is an oversized showpiece, far bigger than real-life jewelry and clearly visible at a glance. "+mt+"sitting in real, calm, healthy skin — no redness, no swelling, no irritation — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes."
def post(t,P,vibe,rr):
    t,n=re.subn(r'down to the base of her neck and the tops of her collarbones, the frame cutting off there','down to her collarbones and the tops of her shoulders, the frame cutting off there, so the long earrings fully hang in view',t,count=1); assert n==1
    pp=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    lvl=int(P[1:]); metal=rr.choice(["yellow gold","silver","rose gold"])
    show=("Jewelry showcase: the piercings and jewelry are the unmistakable star of the image, big, striking and a feast for the eye; every gemstone flashes a hard bright glint, her hair is swept back behind her ears, and nothing covers her eyes, her face or her piercings, with every piece clear of the eyes by at least a finger's width.")
    if lvl<=15:
        t=t.replace(pp,lowpp(P,vibe,rr,metal))
        return t.replace("\n\nLighting:","\n\n"+show+"\n\nLighting:",1)
    if vibe!="수수":
        t,n=re.subn(r'All jewelry is real [^,]+?(?: \([^)]*\))?, sitting',(MAT_FANCY if vibe=="화려" else MAT_CUTE)+'sitting',t,count=1); assert n==1
    shs=list(SHAPES[vibe]); rr.shuffle(shs); N=CENTRE[P]
    cen=", ".join(shs[:N]) if N<=len(shs) else ", ".join(shs)
    ears=", ".join(shs[:3])
    st={"수수":"in polished metal set with huge clear gemstones, a simple one-colour palette but with enormous, imposing pieces","화려":"in glossy multicoloured enamel patterned with stripes, polka dots, checks and filigree, set with large rainbow gemstones","귀여움":"in pastel enamel with pearls and pastel gemstones, cute and playful"}[vibe]
    drop={"수수":"one long plain drop earring on each ear hanging to the shoulders","화려":"a gigantic chandelier earring as wide as her palm and as long as her hand on each ear, hanging to the shoulders","귀여움":"a long pastel drop earring of dangling hearts and stars on each ear, hanging to the shoulders"}[vibe]
    look=(f"Piercing look: {st}. Down the centreline of her nose runs a column of exactly {N} piercings, one under another, made up of the septum ring and the nose-bridge and nose-tip pieces already named above plus enough extra pieces to reach {N}, every one in a different shape ({cen}); all the bridge pieces sit well below the eyes. "
          f"The nostril rings are only classic round hoops wrapping snugly around the nostril wing, with no shaped frames on the nostrils. The ear pieces are mostly large classic round O-ring hoops, bold and clearly visible, with several in other shapes ({ears}), plus {drop}. "+SIZE)
    return t.replace("\n\nLighting:","\n\n"+look+"\n\n"+show+"\n\nLighting:",1)
# (style, slots) per level and vibe
DARK={"수수":"립온리 블랙","화려":"비주얼계 블랙립","귀여움":"블러드 립"}
PL={"P3":{"수수":("NONE",["pierce"]),"화려":("NONE",["pierce","lens"]),"귀여움":("아마갸루",["pierce","sticker"])},
 "P5":{"수수":("글래스 스킨",["pierce"]),"화려":("NONE",["pierce","sticker"]),"귀여움":("아마갸루",["pierce","sticker"])},
 "P8":{"수수":("NONE",["pierce","henna"]),"화려":("강남언니",["pierce","lens"]),"귀여움":("아마갸루",["pierce","sticker"])},
 "P15":{"수수":("NONE",["pierce"]),"화려":("NONE",["pierce","sticker","lens"]),"귀여움":("아마갸루",["pierce","sticker"])},
 "P25":{"수수":("글래스 스킨",["pierce"]),"화려":("NONE",["pierce","lens"]),"귀여움":("아마갸루",["pierce","sticker"])}}
for P in ["P50","P100","P150","P200"]:
    PL[P]={"수수":(DARK["수수"],["pierce"]),"화려":(DARK["화려"] if P!="P200" else "뱀파이어 다크",["pierce","lens"]),"귀여움":(DARK["귀여움"],["pierce"])}
EXV={"수수":["도도한","고혹적인","냉혹한"],"화려":["섹시한","카리스마 있는","군림하는"],"귀여움":["귀여운","발랄한","몽환적인"]}
NA=[("한국","20대"),("일본","아이돌"),("중국","30대"),("한국","아이돌"),("일본","20대"),("중국","20대")]
o=["# LumineX — 피어싱 개수 단계별(P3~P200) × 분위기(수수·화려·귀여움) 27개 — 코 가운데 다단 + 콧볼 훅 + 귀는 O링 기본에 모양 섞기\n",
 "- 코 피어싱은 '코 가운데 줄'로 바꿈: 개수 단계에 따라 2·2·3·3·3·4·5·6·7개(P3·5·8·15·25·50·100·150·200)를 위아래로 쌓고 동그라미·삼각·사각·5각·6각 등 서로 다른 모양. 콧볼은 콧볼을 감싸는 평범한 O링만.",
 "- 귀는 기본 큰 O링 + 일부만 다른 모양, 초대형/긴 귀걸이 병행. 수수 = 한 가지 금속 + 큰 투명 보석, 화려 = 다색 에나멜·무늬·무지개 보석, 귀여움 = 파스텔·진주·하트/별/클로버/나비. 모든 단계 크기는 최대.",
 "- P3~P15는 개수를 정확히 지정하고 비대칭 분산, P25 이상은 검증된 원문 위에 문단 추가. P50 이상은 기존 규칙대로 어두운 메이크업(블랙립·레드립) 위에서만, 스티커·헤나·렌즈 포인트는 낮은 단계 위주.",
 "- 정상/이상(+ 코 가운데 모양·개수, 콧볼 O링, 귀 O링+모양)만 번호로 알려주세요.\n"]
k=0
for P in PL:
    for vibe in ["수수","화려","귀여움"]:
        sty,slots=PL[P][vibe]; nat,grp=NA[k%6]; ex=EXV[vibe][k%3]; k+=1
        for tr in range(40):
            try: t,title,meta=G.make(random.Random(11000+k*100+tr),nat,grp,ex,style=sty,slots=slots,pier_level=P); break
            except AssertionError: continue
        else: raise SystemExit("fail "+P+vibe)
        t=post(t,P,vibe,random.Random(13000+k)); assert not re.search(r"[가-힣]",t)
        o.append(f"## {P}-{vibe} — {title}\n\n```\n{t}\n```\n"); print(P,vibe,len(t.split()))
open('/mnt/user-data/outputs/LumineX_PierceLadder_v3_P3toP200_x27.md','w',encoding='utf-8').write("\n".join(o))
