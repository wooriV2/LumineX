import re,random
src=open('gen_facesculpt.py',encoding='utf-8').read(); src=src[:src.index("rr=random.Random(20261013)")]
ns={}; exec(compile(src,'gf','exec'),ns)
lib=ns['ns']; HW2=lib['HW2']; COL2=lib['COL2']; w=lib['w']; SAFE=lib['SAFE']
exec(open('ear_styles.py',encoding='utf-8').read())
G=ns['G']; para2=ns['para2']; HENNA=ns['HENNA']; STICK=ns['STICK']; BOTH=ns['BOTH']; OUT=ns['OUT']
TH=ns['TH']; EX=ns['EX']; pick_style=ns['pick_style']; make_base=ns['make_base']
FR=lib['FR']; FR_OLD=lib['FR_OLD']
BODYS="hourglass physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — most dramatic hourglass ratio ever, simultaneously maximum enormous bust AND maximum enormous hips both flaring to absolute impossible extremes while the waist is cinched to impossible minimum, "
DEPTH="Piercing depth: every bar and surface bar is embedded in the skin — its middle runs beneath the skin so only its two end studs show on the surface, the skin between them faintly raised over the hidden bar, with a small warm shadow at each end and nothing lying on top of the skin like a sticker. Every ring passes through a small healed opening in the skin, the skin visible through the loop, and every stud sits through the skin with its back hidden. Where a bar, ring or stud goes through the ear, the lip, the nostril or the brow, it passes through the real tissue with the skin wrapping snugly around it."
HAIR="Hair: her hair is swept back behind both ears, leaving both ears, her jawline and her neck fully visible so every hanging piece is in clear view."
LIGHT="Lighting: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. A soft frontal light on her face and ears, so the glints on every piece of metal read clearly against her skin; a thin cool rim light along the hair and shoulders. 2:3 vertical 8K portrait."
THEMES={
"punk":("The pieces on her face are punk in style: instead of plain studs and rings, the small pieces are safety-pin shaped bars, sharp cone-spike studs and chunky chain-link rings.","The face and ear jewelry is real blackened steel and chrome silver, spiked and studded, with no gemstones","펑크(안전핀·가시 스터드)"),
"marine":("The pieces on her face are inspired by the sea: instead of plain studs and rings, the small pieces are round pearl studs, tiny scallop-shell and starfish charms and rings strung with small coral beads.","The face and ear jewelry is real pale gold and silver set with white pearls, mother-of-pearl and pink coral","해양(진주·조개·산호)")}
CHAINS="Fine chains link the pieces: from the upper ear hoop on each side a delicate chain swags across the cheek to the ring around the nostril wing on the same side, passing well below the eye and clear of the lips, and one more fine chain hangs in a soft curve under the jaw from one ear to the other; the chains are thin enough that every piece and her whole face stay clearly visible."
def base(rr,N,zero,minimal,deco,nw,mode="front",theme=None,chains=False,expr0=None,hdr=None,style0=None):
    nat=rr.choice(list(G.NATS)); grp=rr.choice(["아이돌","20대","30대"]); expr=rr.choice(EX[grp]); v=rr.choice(["수수","화려","귀여움"])
    if expr0: grp="20대"; expr=expr0
    style=style0 or pick_style(rr,N,None)
    t,title,meta=make_base(rr,nat,grp,expr,style,N)
    metal,gems=TH[v]
    pp=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    new,tot=para2(N,nw,metal,gems,deco,random.Random(rr.randrange(10**9)),None,None,zero,minimal)
    lab_t=""
    if theme:
        s,tail,lab_t=THEMES[theme]
        new=new.replace("The left and right sides are balanced.",s+" The left and right sides are balanced.",1)
        old=f"The face and ear jewelry is real {metal} set with {gems}"; assert old in new
        new=new.replace(old,tail)
    if chains:
        assert "The left and right sides are balanced." in new
        new=new.replace("The left and right sides are balanced.",CHAINS+" The left and right sides are balanced.",1)
    t=re.sub(r'\n\nJewelry:[^\n]*','',t.replace(pp,new))
    sj=[x for x in t.split("\n\n") if x.startswith("Subject:")][0]
    sj2=sj.replace(BODYS,"").replace(". Real pores and fine skin grain on her skin, a soft sheen of natural oils, large eyes with bright real catchlights, full lips, ",", ")
    sj2=re.sub(r" — a photograph of a real (\w+) woman's face \(.*?\), not an illustration"," — a photograph of a real \\1 woman's face, not an illustration",sj2)
    t=t.replace(sj,sj2)
    t,n=re.subn(re.escape(FR_OLD),FR["sh"],t,count=1); assert n==1
    t=t.replace("\n\nLighting:","\n\n"+HAIR+"\n\nLighting:",1)
    mk=("메이크업 "+(meta.get("makeup_label") or "없음")) if style!="NONE" else "메이크업 없음"
    lab=f"{nat} · {grp} · {expr} · {mk} · P{N}({v})"
    return t,lab,lab_t,nw
def pack(i,t):
    assert not re.search(r"[가-힣]",t) and "{" not in t
    d=re.search(r"\b(\w+) \1\b",t)
    return d
