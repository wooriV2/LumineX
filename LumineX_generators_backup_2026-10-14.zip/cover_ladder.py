import sys,re,random,math
sys.path.insert(0,'.')
import gen_cjk_v2 as G
SAFE=" sitting in real, calm, healthy skin — no redness, no swelling, no irritation — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes."
ON=["zero","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen"]
TN=["","","twenty","thirty","forty","fifty","sixty","seventy","eighty","ninety"]
def w(n):
    if n<20: return ON[n]
    if n<100: return TN[n//10]+("-"+ON[n%10] if n%10 else "")
    return ON[n//100]+" hundred"+(" and "+w(n%100) if n%100 else "")
# counts per level: singles, pairs total (L+R)
LV={"P25":dict(sep=1,nos=2,bri=1,brow=2,ul=1,ll=2,chin=1,ear=8,fh=2,tmp=2,chk=4),
    "P50":dict(sep=1,nos=4,bri=2,brow=4,ul=2,ll=4,chin=2,ear=16,fh=5,tmp=4,chk=8),
    "P100":dict(sep=2,nos=6,bri=3,brow=10,ul=4,ll=8,chin=4,ear=32,fh=10,tmp=8,chk=16),
    "P150":dict(sep=3,nos=8,bri=3,brow=14,ul=6,ll=10,chin=6,ear=60,fh=12,tmp=12,chk=20),
    "P200":dict(sep=4,nos=8,bri=4,brow=16,ul=8,ll=14,chin=8,ear=80,fh=16,tmp=16,chk=26)}
def ear_txt(n):
    if n<=4: return f"{w(n)} pieces: a big hoop in the lobe"+(" and smaller rings and studs up the rim" if n>1 else "")
    a,b,c=max(1,round(n*.2)),max(1,round(n*.4)),max(1,round(n*.25)); d=max(0,n-a-b-c)
    return f"{w(n)} pieces: {w(a)} graduated hoops down the lobe, {w(b)} rings and studs along the helix rim, {w(c)} studs and small bars across the upper cartilage"+(f" and {w(d)} pieces in the conch and tragus" if d else "")
def split(total,bal):
    if bal: return total//2,total-total//2
    L=max(1,round(total*.75)) if total>1 else total; return L,total-L
def build_para(P,bal,metal,gems):
    c=LV[P]; seg=[]
    seg.append(("a single large " if c["sep"]==1 else f"{w(c['sep'])} separate ")+"septum ring"+("" if c["sep"]==1 else "s")+" of different sizes and shapes (round, triangle, square, pentagon, hexagon) through the thin soft wall between the nostrils, hanging below the tip of the nose")
    L,R=split(c["nos"],bal); seg.append(f"{w(L)} small ring"+("s" if L>1 else "")+f" wrapping snugly around the left nostril wing and {w(R)} around the right")
    seg.append(f"{w(c['bri'])} straight bar"+("s" if c['bri']>1 else "")+" across the bridge of the nose, stacked from just below the inner ends of the brows (well clear of the eyes) down to the middle of the nose, each with a gem cap at both ends")
    L,R=split(c["brow"],bal); seg.append(f"{w(L)} small bar"+("s" if L>1 else "")+f" and ring{'s' if L>1 else ''} through the left eyebrow and {w(R)} through the right, all on the brow bone above the eyes and never on the eyelids")
    seg.append(f"{w(c['ul'])} small hoop"+("s" if c['ul']>1 else "")+" or stud"+("s" if c['ul']>1 else "")+" along the edge of the upper lip")
    seg.append(f"{w(c['ll'])} small hoop"+("s" if c['ll']>1 else "")+" and stud"+("s" if c['ll']>1 else "")+" across the lower lip's edge")
    seg.append(f"{w(c['chin'])} small ring"+("s" if c['chin']>1 else "")+" and stud"+("s" if c['chin']>1 else "")+" on the chin")
    L,R=split(c["ear"],bal); seg.append(f"on the left ear {ear_txt(L)}, and on the right ear {ear_txt(R)}, the biggest hoops hanging clear of the neck down to the shoulders")
    seg.append(f"{w(c['fh'])} small stud"+("s" if c['fh']>1 else "")+" across the forehead above the brows in even rows, well above the eyebrows")
    L,R=split(c["tmp"],bal); seg.append(f"{w(L)} small stud"+("s" if L>1 else "")+f" on the left temple bone and {w(R)} on the right, well clear of the eyes")
    L,R=split(c["chk"],bal); seg.append(f"{w(L)} small stud"+("s" if L>1 else "")+f" along the left cheekbone and {w(R)} along the right, well clear of the eyes")
    tot=sum(c.values()); n=int(P[1:])
    dens=("The piercings are packed so densely that the rows touch and overlap, leaving only hairline gaps of bare skin between them, until the face reads as a single armour of metal; the eyes and eyelids stay clear. " if n>=100 else "The pieces are spread over the whole face in clear rows so every one reads individually, with bare skin between them; the eyes and eyelids stay clear. ")
    bal_txt=("The left and right sides are balanced and mirrored. " if bal else f"The arrangement is deliberately unbalanced: the left side of the face and the left ear carry about three quarters of the paired pieces while the right side carries far fewer, so the left side reads as the heavy side. ")
    return (f"Piercings: A face fully covered with real piercings, about {w(n)} in total, spread over every area so that no area is empty: "+"; ".join(seg)+". "+bal_txt+dens+f"All jewelry is real {metal} set with {gems},"+SAFE)
NA=[("한국","20대","도도한"),("일본","아이돌","섹시한"),("중국","20대","고혹적인"),("한국","아이돌","군림하는"),("일본","30대","카리스마 있는"),("중국","30대","냉혹한"),("한국","20대","발랄한"),("일본","20대","도도한"),("중국","아이돌","섹시한"),("한국","30대","고혹적인")]
SU=("yellow gold","clear diamonds, a simple one-colour palette","수수 단색"); HW=("mixed gold, silver and rose gold","glossy multicoloured enamel and rainbow gemstones","화려 다색")
o=["# LumineX — 얼굴 전체 채우기 단계별(P25~P200) × 균형/언밸런스 10개\n","- 3차 방식: 11개 부위(코 사이·콧볼·브리지·눈썹·윗입술·아랫입술·턱·귀·이마·관자·광대)를 빈 곳 없이 채우고, 총 개수만 단계에 맞게 비율 축소.","- 균형 = 좌우 대칭, 언밸런스 = 왼쪽에 쌍 부위 약 3/4 집중. 수수 단색/화려 다색은 번호마다 번갈아 배정. 메이크업 없음, 머리는 뒤로 넘김.","- 정상/이상(+ 빈 부위 없이 섞였는지, 언밸런스 느낌이 나는지)만 번호로 알려주세요. P3~P15는 결과 보고 이어서 만듭니다.\n"]
k=0
for P in LV:
    for bal in (True,False):
        vibe=(SU if (k%2==0)==(P in("P25","P100","P200")) else HW)
        # alternate so balanced/unbalanced get both vibes across levels
        nat,grp,ex=NA[k]; k+=1
        for tr in range(40):
            try: t,title,meta=G.make(random.Random(31000+k*100+tr),nat,grp,ex,style="NONE",slots=["pierce"],pier_level="P150" if int(P[1:])>=100 else "P50"); break
            except AssertionError: continue
        pp=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
        t=re.sub(r'\n\nJewelry:[^\n]*','',t.replace(pp,build_para(P,bal,vibe[0],vibe[1])))
        t=t.replace("\n\nLighting:","\n\nHair: her hair is swept back behind both ears and away from her forehead and temples, leaving her whole face, ears and neck fully visible.\n\nLighting:",1)
        assert not re.search(r"[가-힣]",t)
        o.append(f"## {P}-{'균형' if bal else '언밸런스'}-{vibe[2]} — {title}\n\n```\n{t}\n```\n"); print(P,bal,vibe[2],len(t.split()))
open('/mnt/user-data/outputs/LumineX_FaceCover_Ladder_P25toP200_10.md','w',encoding='utf-8').write("\n".join(o))
