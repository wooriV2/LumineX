import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
from cover_lib import SAFE
SK="The skin around every piece is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
def mk(mat,rmat):
    return ("Piercings: Exactly six piercings in total, five on the nose and one in the lower lip, and nowhere else: first, a single thick, solid, sharp tusk of "+mat+" as thick as her thumb in the middle passes straight through the lower part of the septum, the thin soft wall between the nostrils, and sweeps out sideways just beneath her nostril wings, past their outer edges to about the middle of her cheeks, in a smooth boar-tusk curve, its two ends rising gently upward and tapering to needle-sharp points, the tips ending well below her eyes at the height of her nostrils; the tusk sits clearly above her upper lip and does not touch or cover her lips. From the exact middle of the tusk a thick iron connector ring hangs down, and from it a short, thick chain of a few heavy black iron links drops straight down in front of her closed mouth and is fastened to a thick iron ring through the middle of her lower lip's edge, a plain round ring as wide as a large coin. From this lip ring a thick, heavy chain of black iron links continues straight down in front of her chin, carrying one massive solid weight of rough black cast iron with a hammered, pitted, matte surface, a squat solid cube-shaped block as big as a fist, which hangs below her chin onto her neck and looks crushingly heavy; the whole chain is thin enough that both halves of her lips stay clearly visible on either side of it, and the weight pulls it bar-straight and taut. Second, two thick round rings of "+rmat+" through the septum, stacked one above the other directly above the tusk with a small gap of bare skin between them, each ring about as wide as the base of her nose, the tusk and the rings clearly separate. Third, one classic round hoop of "+rmat+" as wide as a large coin wrapping snugly around each nostril wing, sitting above the tusk. "+SK+" Her eyebrows, chin and ears carry no piercing at all. All jewelry is real "+rmat+", except the connector ring, the lip ring, the chains and the weight, which are blackened cast iron,"+SAFE)
V=[("상아·뼈","creamy ivory-white carved bone with fine natural grain and a smooth polished surface","creamy ivory-white carved bone"),
   ("흑요석","glossy black volcanic obsidian glass with razor-sharp tapering edges and bright specular reflections","glossy black obsidian glass"),
   ("은","bright polished sterling silver with a mirror finish and a slender sharp taper","bright polished sterling silver"),
   ("금","polished solid yellow gold with a warm mirror finish and a slender sharp taper","polished solid yellow gold")]
NA=[("한국","20대","도도한"),("일본","아이돌","군림하는"),("중국","20대","섹시한"),("한국","30대","냉혹한")]
o=["# LumineX — 코 엄니 + 코 사이 링 2 + 콧볼 훅 2 + 가운데 연결 고리·쇠뭉치 추 (상아·금 2종, 피어싱 6개)\n","- 구성: 엄니 가운데 연결 고리 → 짧은 사슬 → 아랫입술 링 1개 → 굵은 사슬 → 턱 아래 목에 걸리는 큐브 추. 코는 연결까지만, 추는 입술 링에서 내려감.","- 엄니는 콧볼 바로 아래로 뺨 중간까지(지난번 크기), 그 위에 코 사이 링 2개(간격을 두고 쌓음), 콧볼은 감싸는 동그란 훅. 엄니·링은 같은 소재. 입술·눈썹·턱·귀는 비움.","- 정상/이상(+ 엄니·코 사이 링 2·콧볼 훅이 각각 구분돼 보이는지)만 번호로 알려주세요.\n"]
for i,((lab,mat,rmat),(nat,grp,ex)) in enumerate(zip([V[0],V[3]],NA),1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(70000+i*100+tr),nat,grp,ex,style="NONE",slots=["pierce"],pier_level="P3"); break
        except AssertionError: continue
    else: raise SystemExit(i)
    old=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    t=re.sub(r'\n\nJewelry:[^\n]*','',t.replace(old,mk(mat,rmat)))
    t,nn=re.subn(r'down to the base of her neck and the tops of her collarbones, the frame cutting off there','down to the middle of her chest, the frame cutting off there, so the weight fully hangs in view',t,count=1); assert nn==1
    t=t.replace("\n\nLighting:","\n\nHair: her hair is swept back behind both ears, leaving both ears, her jawline and her neck fully visible.\n\nLighting:",1)
    assert not re.search(r"[가-힣]",t)
    o.append(f"## {i}. {lab} — {title}\n\n```\n{t}\n```\n")
open('/mnt/user-data/outputs/LumineX_SeptumTusk_LipWeight_2.md','w',encoding='utf-8').write("\n".join(o)); print("ok")
