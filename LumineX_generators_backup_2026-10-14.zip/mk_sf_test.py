import re,random
ns2={}
g=open('gen_fs2.py',encoding='utf-8').read()
exec(compile(g[:g.index('if __name__=="__main__":')],'gfs2','exec'),ns2)
m=open('mk_group4.py',encoding='utf-8').read()
exec(m[m.index('END="'):m.index('TEXT.update')],ns2)
ns2['tusk_flag']=False
OUT=ns2['OUT']
cjk=open('cjk_face_lib.py',encoding='utf-8').read()
HAIRS=sorted(set(re.findall(r'"((?:[^"]*?(?:hair|bob|bun|waves|lob|ponytail|braid|bangs|updo|twin|pigtail)[^"]*?))"',cjk)),key=len,reverse=True)
SILV=["long silver-white hair in soft waves swept to one side","a sleek silver-grey bob with soft layers","a polished silver low bun with a few loose strands","long straight silver hair with a side part"]
AGE_RE=re.compile(r"\b(?:early|mid|late) (?:20s|30s)\b")
def to_age(t,age,silver,k0=0):
    t=AGE_RE.sub(age,t)
    t=re.sub(r"\b(?:Early|Mid|Late) (?:20s|30s)\.",age.capitalize()+".",t)
    if silver:
        for h in HAIRS:
            if h in t: t=t.replace(h,SILV[k0%4],1); break
        else: raise SystemExit("no hair phrase")
    return t
R=random.Random(20261015)
TEXT_E={n:t for n,t,c in ns2['EYE2']}; TEXT_L={n:t for n,t,c in ns2['LIP']}; TEXT_L.update(ns2['NEWLIP'])
ARCHF={n:f for n,f,c in ns2['ARCH']}
JOBS=[("eye","사이렌 눈 +1",TEXT_E,"early 50s",True),("eye","애교살 초극대",TEXT_E,"late 40s",True),
      ("lip","러시안 립 초과장",TEXT_L,"mid 40s",True),("lip","덕 립 극한",TEXT_L,"early 50s",True),
      ("arch","바비 인형(금발)",None,"early 50s",False),("arch","서큐버스",None,"late 40s",False)]
o=["# LumineX — 실버폭스 버전 시험 6개 (눈 2 · 입술 2 · 인형/유형 2)\n","- 단일 컷, 번들과 같은 랜덤 틀에서 나이만 40대 후반~50대 초반으로 바꿈(프롬프트 길이 변화 없음, 추가 문장 없음). 눈·입술 주인공은 은발로 통일. 5·6번 유형(바비·서큐버스)은 정체성인 머리·외형을 유지하고 나이만 바꿈 — 인형 같은 외모가 나이 든 얼굴에서도 읽히는지 확인용.","- 1·2 눈: 사이렌 눈 +1(50대 초반) · 애교살 초극대(40대 후반) / 3·4 입술: 러시안 립 초과장(40대 중반) · 덕 립 극한(50대 초반) / 5·6 유형: 바비 인형(금발, 50대 초반) · 서큐버스(40대 후반).","- 정상/이상 번호와, 입술·눈·인형 외모가 나이에도 읽히는지 번호별로 알려주세요.\n"]
for i,(kind,name,TX,age,silver) in enumerate(JOBS,1):
    if kind=="arch": it=ns2['build2'](i,kind,name,ARCHF[name],R)
    else: it=ns2['build2'](i,kind,name,TX[name],R)
    t=to_age(it["prompt"],age,silver,i)
    if kind=="arch": t=re.sub(r"\bmid 20s\b",age,t)
    assert not re.search(r"[가-힣]",t)
    left=re.findall(r"\b(?:early|mid|late) [0-9]+s",t,flags=re.I)
    o.append(f"## {i}. {name} · {age}{' · 은발' if silver else ''} · {it['title']}\n\n```\n{t}\n```\n"); print(i,name,len(t.split()),left)
open(OUT+'LumineX_Silverfox_Test_6.md','w',encoding='utf-8').write("\n".join(o))
