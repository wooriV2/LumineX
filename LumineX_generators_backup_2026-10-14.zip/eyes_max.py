import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
from cover_lib import SAFE
HEAD="Professional fashion photograph, close-up beauty portrait. ONE woman, facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp. Mid 20s."
HEAD_W=HEAD.replace("down to the base of her neck and the tops of her collarbones, the frame cutting off there","down to her collarbones and the tops of her shoulders, the frame cutting off there, so the earrings fully hang in view")
TAIL=" Every feature is exaggerated but beautiful, balanced and refined, in harmony with the rest of her face, never distorted, never grotesque. Real skin fine grain and a soft sheen of natural oils on her face, ears and neck, individual hair strands catching the light — a photograph of a real woman, not an illustration, not a render."
SK="The skin around every piece is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
IRON="rough black cast iron with a hammered, pitted, matte surface"
def sub(txt): return "Subject: "+txt+TAIL



def eyesub(face,eyes,brows,rest):
    return sub("A real photograph of a strikingly beautiful adult woman, mid 20s, "+face+" Her eyes are the star of her face: "+eyes+" "+brows+" "+rest+" Looking straight into the camera.")
def pier(mat,desc,col):
    return ("Piercings: Exactly six piercings in total, symmetrical: on each ear a large "+desc+" hoop in the lobe and two matching studs up the rim. Each piece is large and clearly visible, and nothing else on the face is pierced. "+SK+" All jewelry is real "+mat+","+SAFE)
V=[("옆트임 극한 — 중국 · 눈 길이 3배·눈꼬리가 관자를 지나 헤어라인 옆까지 · 골드+제이드 피어싱 6",
    eyesub("a Chinese woman with luminous porcelain skin and long straight glossy black hair swept behind her ears.","the ultimate extreme eyes, beyond any real surgery but still beautiful: the outer corners of both eyes are stretched far past her temples to the side of her head near the hairline, and the inner corners are fully opened with the small pink inner corner visible, so each eye opening is about three times its natural length, an extremely long, narrow, razor-sharp almond shape spanning almost the entire width of her face on each side, showing a huge amount of iris and white; a razor-sharp black eyeliner follows the entire shape and ends in a very long, sharp point beside the hairline; the eyes are in very large dark-brown doll-eye contact lenses with a glossy shine and a big iris, both eyes the same, with a round natural pupil and bright catchlights.","Slim, high, sharply arched dark brows that follow the long eyes.","Soft rose lips, a straight refined nose and a slim V-line jaw. A cold, otherworldly gaze."),
    pier("polished yellow gold set with green jade","gold with green jade",1)),
   ("옆트임 최극한 — 한국 · 눈 길이 4배·눈꼬리가 머리 옆면까지 닿는 상상형 · 은+아쿠아 피어싱 6",
    eyesub("a Korean woman with luminous fair skin and long sleek dark-brown hair swept behind her ears.","pure fantasy eyes, impossibly long but elegantly beautiful: the outer corners of both eyes sweep far beyond her temples to the very side of her head above her ears, and the inner corners are fully opened with the small pink inner corner visible, so each eye opening is about four times its natural length, an extremely long, thin, razor-sharp almond shape like a long blade spanning the whole width of her face, showing a huge amount of iris and white; a razor-sharp black liner follows the entire shape and ends in a very long, fine point at the side of her head; the eyes are in very large silver-grey doll-eye contact lenses with a glossy shine and a big iris, both eyes the same, with a round natural pupil and bright catchlights.","Slim, high, sharply arched dark brows that follow the long eyes.","Soft rose lips, a straight refined nose and a slim V-line jaw. An icy, alien, mesmerising gaze."),
    pier("polished sterling silver set with pale aqua gems","silver with a pale aqua gem",1))]
o=["# LumineX — 옆트임 극한 2단계 + 애니 돌 아이 (정면)\n","- 옆트임: 극한(길이 3배, 눈꼬리가 헤어라인 옆까지), 최극한(길이 4배, 머리 옆면까지 닿는 상상형). 앞의 극단(2배)·초극단(2.5배)에 이은 단계. 3번은 이전에 만든 애니 돌 아이 재수록.","- 정상/이상(+ 눈이 얼마나 길게 나오는지)만 번호로 알려주세요.\n"]
for i,(lab,sj,p) in enumerate(V,1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(94000+i*100+tr),"한국","20대","도도한",style="NONE",slots=["pierce"],pier_level="P5"); break
        except AssertionError: continue
    else: raise SystemExit(i)
    ps=t.split("\n\n")
    depth=[x for x in ps if x.startswith("Piercing depth:")][0]; light=[x for x in ps if x.startswith("Lighting:")][0]
    new="\n\n".join([HEAD,sj,p,depth,light]); assert not re.search(r"[가-힣]",new)
    o.append(f"## {i}. {lab}\n\n```\n{new}\n```\n")
open('/mnt/user-data/outputs/LumineX_Eyes_CanthusMax_AnimeEye_3.md','w',encoding='utf-8').write("\n".join(o)); print("ok")
