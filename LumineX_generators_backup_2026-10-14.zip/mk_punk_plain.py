import re,random
exec(open('new_lib.py',encoding='utf-8').read())
rr=random.Random(909)
for tr in range(80):
    r2=random.Random(rr.randrange(10**9))
    try:
        nw=8; deco=r2.choice(["",HENNA,STICK,BOTH])
        t,lab,lt,nw=base(r2,50,("tmp","brow","bri"),False,deco,nw,theme="punk")
        a=t.index("All the ear weights hang from the bottoms of these two iron rings"); hw=HW2.format(col=COL2[nw]); b=t.index(hw)+len(hw)
        t=t[:a].rstrip()+t[b:]
        assert SEG_OLD in t
        t=t.replace(SEG_OLD,"each opening holding its own large classic round hoop earring of a moderate size, a plain metal ring with nothing hanging from it")
        t=t.replace("so the weights fully hang in view","so both ears are fully in view").replace("(not counting the hanging weights)","")
        t=t.replace(", while the hanging weights are always black cast iron,",",")
        t=t.replace("every hanging piece is in clear view","every piece is in clear view")
    except AssertionError: continue
    if re.search(r"[가-힣]",t) or re.search(r"\b(\w+) \1\b",t): continue
    break
else: raise SystemExit("fail")
assert "weight" not in t.lower(), [m.start() for m in re.finditer("weight",t.lower())]
title=f"펑크 테마 팩 + 기본 귀걸이(추 없음) · {lab}"
open(OUT+'LumineX_Punk_PlainEarrings_1.md','w',encoding='utf-8').write(f"# LumineX — 펑크 테마 샘플 (귀는 기본 귀걸이만, 추 없음)\n\n- 정상/이상만 알려주세요.\n\n## 1. {title}\n\n```\n{t}\n```\n")
print(len(t.split())); i=t.index("Piercings:"); print(t[i:i+2600])
