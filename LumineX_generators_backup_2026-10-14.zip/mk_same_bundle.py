import re,random,sys,json,collections
sys.path.insert(0,'.')
exec(open('mk_group_v2.py',encoding='utf-8').read().split('if __name__=="__main__":')[0])
CAT="🏺 Living Artifact · Face Sculpt Same-Type Group Formula"
BAR=["바비 인형(금발)","바비 인형(갈색 머리)","바비 인형(핑크 머리)"]
EYEN=[n for n,c in EYEP]; LIPN=[n for n,c in LIPP if not n.startswith("러시안")]; RU=[n for n,c in LIPP if n.startswith("러시안")]
KINDS4=lambda R:[R.choice(BAR),"브랫츠 돌","서큐버스","인어 세이렌"]
def sp_arch(nm): return lambda R,n:[("arch",nm)]*n
def sp_bar(R,n): return [("arch",x) for x in (R.sample(BAR,2) if n==2 else R.sample(BAR,3))]
def sp_eye(R,n): return [("eye",x) for x in R.sample(EYEN,n)]
def sp_lip(R,n): return [("lip",x) for x in R.sample(LIPN,n)]
def sp_ru(R,n): return [("lip",x) for x in R.sample(RU,n)]
def sp_mixa(R,n): return [("arch",x) for x in R.sample(KINDS4(R),n)]
def sp_mixs(R,n):
    k=KINDS4(R); a={2:1,3:2,4:2,5:3}[n]; arch=[("arch",x) for x in R.sample(k,a)]
    if n==5: st=[("eye",R.choice(EYEN)),("lip",R.choice(LIPN+RU))]
    else:
        pool=[("eye",R.choice(EYEN)),("lip",R.choice(LIPN+RU))]; st=R.sample(pool,n-a) if n-a<=2 else pool
    s=arch+st; R.shuffle(s); return s
# (label, spec function, mode, {n:count})
PLAN=[("바비만",sp_bar,"front",{2:8,3:8}),
      ("브랫츠만",sp_arch("브랫츠 돌"),"front",{2:6,3:6,4:6,5:4}),
      ("서큐버스만",sp_arch("서큐버스"),"front",{2:6,3:6,4:6,5:4}),
      ("인어 세이렌만",sp_arch("인어 세이렌"),"front",{2:6,3:6,4:6,5:4}),
      ("눈 주인공 자매",sp_eye,"front",{2:5,3:5,4:5,5:3}),
      ("입술 주인공 자매",sp_lip,"q45",{2:5,3:5,4:5,5:3}),
      ("러시안 립 자매",sp_ru,"q45",{2:4,3:4,4:4,5:2}),
      ("유형 섞기",sp_mixa,"front",{2:5,3:5,4:5}),
      ("유형+부위 섞기",sp_mixs,"front",{2:4,3:4,4:4,5:3})]
RATIO={2:"4:3",3:"3:2",4:"16:9",5:"16:9"}
def sigb(p):
    a=re.search(r"with ([\w -]+) streaks",p); b=re.search(r"in (?:vivid )?([\w -]+?) (?:doll-eye|big-iris) contact lenses",p); return (a.group(1) if a else None,b.group(1) if b else None)
HAIR_RE=re.compile(r"long straight ([\w -]+?) hair|hair in ([\w -]+?) falling")
def ok(t,labs,spec,dup):
    if dup and dup.split()[0].lower() not in("had","that"): return False
    ps=re.findall(r"(?<=\n\n#\d: ).*?(?=\n\n#\d )",t,re.S)
    mk=[l.split(" · ")[4] for l in labs if "유형 고유 메이크업" not in l]
    if len(set(mk))<len(mk) or sum(x=="메이크업 없음" for x in mk)>1: return False
    for nm,rx in (("브랫츠 돌",None),("서큐버스",HAIR_RE),("인어 세이렌",HAIR_RE)):
        idx=[i for i,(k,x) in enumerate(spec) if x==nm]
        if len(idx)<2: continue
        if nm=="브랫츠 돌":
            b=[sigb(ps[i]) for i in idx]
            if len(set(x[0] for x in b))<len(b) or len(set(x[1] for x in b))<len(b): return False
        else:
            h=[]
            for i in idx:
                m=HAIR_RE.search(ps[i]); h.append(m.groups() if m else None)
            if None in h or len(set(h))<min(len(h),4 if nm=="서큐버스" else 5): return False
    pl=[l.split(" · ")[5] for l in labs]
    if all(re.match(r"P\d+\(",x) for x in pl) and len(spec)>=3 and len(set(pl))<3: return False
    return True
R=random.Random(20261029)
jobs=[(lab,fn,mode,n) for lab,fn,mode,cnt in PLAN for n,c in cnt.items() for _ in range(c)]
out=[]
for i,(lab,fn,mode,n) in enumerate(jobs,1):
    for tr in range(8000):
        spec=fn(R,n); bg=R.choice(BGN)
        try: t,labs,dup=group5(R.randrange(10**7),spec,mode,bg)
        except AssertionError: continue
        if ok(t,labs,spec,dup): break
    else: raise SystemExit(("fail",i,lab,n))
    t,nB=real2(t); t,k,k2=shorten(t); t=re.sub(r"  +"," ",t)
    assert not re.search(r"[가-힣]",t) and "{" not in t
    ears=[l.split(" · 귀 ")[-1] for l in labs]
    title=f"Face Sculpt Same-Type #{i:03d} ({lab} {n}인 · "+" + ".join(nm for kk,nm in spec)+" · "+("45도" if mode!="front" else "정면")+f" · 배경 {bg} · 귀 "+" / ".join(ears)+")"
    out.append(dict(key=f"la_facesculpt_same_{i:03d}",category=CAT,title=title,prompt=t,
      meta=dict(group_size=n,aspect_ratio=RATIO[n]+" horizontal",format="face-sculpt-same-type",group_type=lab,kinds=[kk for kk,nm in spec],stars=[nm for kk,nm in spec],angle=("45deg" if mode!="front" else "front"),background=bg,ear_modes=ears,persons=labs)))
    if i%20==0: print(i,file=sys.stderr)
N=len(out)
json.dump(out,open(OUT+f'la_facesculpt_same_{N}_bundle.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
print(N,len(set(x["key"] for x in out)))
print(collections.Counter(x["meta"]["group_type"] for x in out))
for n in (2,3,4,5):
    w=[len(x["prompt"].split()) for x in out if x["meta"]["group_size"]==n]; print(n,len(w),min(w),max(w),round(sum(w)/len(w)))
print("korean",sum(1 for x in out if re.search(r"[가-힣]",x["prompt"])))
print("ears all distinct (n<5):",sum(1 for x in out if x["meta"]["group_size"]<5 and len(set(e.split("(")[0] for e in x["meta"]["ear_modes"]))==x["meta"]["group_size"]),"/",sum(1 for x in out if x["meta"]["group_size"]<5))
print(max(len(x["prompt"].split()) for x in out))
