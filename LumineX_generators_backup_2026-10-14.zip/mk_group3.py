import re,random
s=open('mk_group2.py',encoding='utf-8').read()
exec(s[:s.index('CFG=[')])           # person(), TEXT, HW2, COL2 ... (original group() is replaced below)
exec(open('ear_styles.py',encoding='utf-8').read())   # METALS, SHAPES, FORMS, FORMLAB, SEG_OLD
# ---- canthus fixes (same as the single-cut bundle)
LINER_RE=re.compile(r"a razor-sharp black (?:eyeliner|liner) follows the (?:whole extended|entire) shape and ends in ([^;]*);")
COLOUR_RE=re.compile(r"a razor-sharp eyeliner in the colour of her makeup follows the entire shape and ends in [^;]*;")
PLAIN="the outline of each eye is crisp and clean, defined only by her natural dark lashes and the edge of her lids, with no eyeshadow and no eyeliner;"
INNER6="the inner corners are cut open far toward the bridge of her nose, the small pink inner corners reaching almost to the sides of her nose bridge,"
INNER8="the inner corners are cut open so far that they almost meet at the root of her nose, the small pink inner corners clearly visible on either side of the nose bridge,"
INNEW="the inner corners are fully opened with the small pink inner corners clearly visible,"
for n in list(TEXT):
    if "트임" in n:
        t=TEXT[n]; assert LINER_RE.search(t),n
        t=LINER_RE.sub(lambda m:"a razor-sharp eyeliner in the colour of her makeup follows the entire shape and ends in "+m.group(1)+";",t)
        if n.startswith("양쪽 트임 6배"): assert INNER6 in t; t=t.replace(INNER6,INNEW)
        if n.startswith("양쪽 트임 8배"): assert INNER8 in t; t=t.replace(INNER8,INNEW)
        TEXT[n]=t
A_OLD="two separate large healed openings in the earlobe, one below the other with a clear gap of bare skin between them, each opening holding its own very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel,"
A_NEW={1:"one large healed opening in the earlobe holding a very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel,",
       3:"three separate large healed openings in the earlobe, one below another with a clear gap of bare skin between each, each opening holding its own very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel,"}
LOBE_RE=re.compile(r"Because the load is shared between two openings, each earlobe is stretched[^;]*; no lobe sags, droops, collapses or hangs down to the shoulder, every head stays upright, and")
LOBE={1:"Because all the load is carried by one opening, the weight gently pulls each earlobe down a little into a slightly elongated, soft, healthy loop of skin, only a small natural droop that is just enough to show how heavy the weights are; no lobe stretches long, tears or collapses or hangs down to the neck or shoulder, every head stays upright, and",
      2:"Because the load is shared between two openings, the weight gently pulls each earlobe down a little into a slightly elongated, soft, healthy loop of skin, only a small natural droop that is just enough to show how heavy the weights are; no lobe stretches long, tears or collapses or hangs down to the neck or shoulder, every head stays upright, and",
      3:"Because the load is shared between three openings, the weight pulls each earlobe down only very slightly into a soft, healthy loop of skin, a barely noticeable natural droop that is just enough to show the weights are heavy; no lobe stretches long, tears or collapses or hangs down to the neck or shoulder, every head stays upright, and"}
COLS_RE=re.compile(r"On each ear of every woman the two iron rings each carry their own column of weights, the two columns holding [^,]*? weights, hanging side by side")
def ear_person(p,mode,h,fa,rr):
    """personal piercing paragraph"""
    if mode in("iron","mix","one"):
        p=p.replace(A_OLD.rstrip(",")+";",A_OLD+";")
        assert A_OLD in p
        if h!=2: p=p.replace(A_OLD,A_NEW[h])
        if h==1: p=p.replace("and above them sit","and above it sit")
        if h==1: p=p.replace("these two iron rings","this iron ring")
        if h==3: p=p.replace("these two iron rings","these three iron rings")
        if mode=="mix": p=p.replace("separate massive solid weights, each of a different shape:","separate massive solid weights, each of a different shape and a different metal:")
        if mode in("mix","one"): p=p.replace(", while the hanging weights are always black cast iron","")
        p=p.replace("as big as a fist or larger","at least as big as her whole fist and clearly larger than her earlobe")
        p=p.replace(",;",";")
    else:
        assert SEG_OLD in p
        p=p.replace(SEG_OLD,f"the lower opening holding {FORMS[fa]}, and the upper opening holding a large classic round hoop earring")
        p=p.replace("(not counting the hanging weights)","(not counting the hanging drops)")
        k="All the ear weights hang from the bottoms of these two iron rings"
        if k in p: p=p[:p.index(k)].rstrip()
    return p
def share_ear(share_w,nw,mode,h,rr):
    assert LOBE_RE.search(share_w), share_w[-700:]
    w=LOBE_RE.sub(LOBE[h],share_w)
    if h==1:
        w,n=COLS_RE.subn("On each ear of every woman the single iron ring carries all the weights, hanging in a staggered cluster",w); assert n==1
    elif h==3:
        w,n=COLS_RE.subn("On each ear of every woman the three iron rings share the weights between them in uneven numbers, each ring carrying its own column of weights, hanging side by side",w); assert n==1
    w=w.replace("as big as a fist or larger","at least as big as her whole fist and clearly larger than her earlobe")
    k="reaching down along the neck to the collarbones"; assert k in w
    w=w.replace(k,"hanging freely in the air, clear of the neck and shoulders, with even the longest chain and its weight ending no lower than the level of the collarbones")
    if mode in("mix","one"):
        if mode=="mix":
            met="rough, matte, unpolished heavy metal in mixed materials, each weight a different shape and each in a different metal among gold, bronze, iron, tin, brass, silver, copper and lead"
        else:
            m=rr.choice(list(METALS)); met="rough, matte, unpolished "+METALS[m][1]+", each weight a different shape"
        k2="an enormous, dense, completely solid, squat, blunt lump of rough black cast iron"; assert k2 in w
        w=w.replace(k2,"a massive, dense, solid lump of "+met)
        k3="each weight on its own thick chain of heavy black iron links"; assert k3 in w
        w=w.replace(k3,"each weight on its own thick heavy chain of the same metal as the weight")
    return w
BGSG=[b for b in [("순흑 기본",None),
("스튜디오 짙은 남색","A plain seamless deep midnight-navy backdrop, nothing else in frame, no texture, no gradient. The background colours are cool, mid-to-dark tones clearly different from their skin tones, never beige, peach, orange or brown, and never bright."),
("스튜디오 짙은 청록","A plain seamless deep teal backdrop, nothing else in frame, no texture, no gradient. The background colours are cool, mid-to-dark tones clearly different from their skin tones, never beige, peach, orange or brown, and never bright."),
("실내 청록 벨벳 라운지","The background is a dim lounge with deep teal velvet walls and a few soft blurred lamps in muted blue-green, out of focus with a shallow depth of field, with no objects and no other people in the background, and the background is darker and softer than their faces so that their faces and the metal are the brightest, sharpest part of the image. The background colours are cool, mid-to-dark tones clearly different from their skin tones, never beige, peach, orange or brown, and never bright."),
("실외 푸른 시간대 호숫가","The background is a lakeside at blue hour, a blurred dark navy lake and distant hills under a deep indigo sky, out of focus with a shallow depth of field, with no objects and no other people in the background, and the background is darker and softer than their faces so that their faces and the metal are the brightest, sharpest part of the image. The background colours are cool, mid-to-dark tones clearly different from their skin tones, never beige, peach, orange or brown, and never bright."),
("실외 비 오는 밤 청록·남색 네온","The background is a city street at night in the rain, blurred neon signs and car lights in teal and deep blue, out of focus with a shallow depth of field, with no objects and no other people in the background, and the background is darker and softer than their faces so that their faces and the metal are the brightest, sharpest part of the image. The background colours are cool, mid-to-dark tones clearly different from their skin tones, never beige, peach, orange or brown, and never bright."),
("실외 안개 낀 숲","The background is a misty forest at dusk, soft blurred dark-green trees fading into pale fog, out of focus with a shallow depth of field, with no objects and no other people in the background, and the background is darker and softer than their faces so that their faces and the metal are the brightest, sharpest part of the image. The background colours are cool, mid-to-dark tones clearly different from their skin tones, never beige, peach, orange or brown, and never bright.")] ]
BGD=dict(BGSG)
def group3(seed,spec,mode,ear,h,bgname):
    rr=random.Random(seed); n=len(spec); nw=6 if n==2 else 4; NP=12 if n==2 else 10
    nats=rr.sample(list(G.NATS),n); subs=[];prs=[];labs=[]
    fas=rr.sample(range(len(FORMS)),n)
    for (kind,name),nat,fa in zip(spec,nats,fas):
        for tr in range(60):
            try:
                s_,p,l=person(random.Random(rr.randrange(10**9)),nat,kind,name,nw,NP)
                if "트임" in name and "메이크업 없음" in l:
                    s_,c=COLOUR_RE.subn(PLAIN,s_); s_=s_.replace("while the colours of her eyeshadow and liner follow her makeup","and she wears no eyeshadow and no eyeliner at all")
                p=ear_person(p,ear,h,fa,rr)
                if ear!="earring": l=l.replace("2구멍",f"{h}구멍")
                else: l=re.sub(r"귀 추 \d+개/귀 2구멍","대형 귀걸이 "+FORMLAB[fa],l)
            except AssertionError: continue
            if re.search(r"[가-힣]",s_+p) or "{" in s_+p: continue
            break
        else: raise SystemExit(("fail",name))
        if mode=="front": s_=s_.replace("in this three-quarter view","in this frontal view")
        subs.append(s_);prs.append(p);labs.append(l)
    cnt={2:"TWO",3:"THREE"}[n]; tw={2:"both",3:"all three"}[n]
    hang="the long earrings" if ear=="earring" else "the weights"
    if mode=="front":
        hd=f"Professional fashion photograph, close-up beauty portrait. {cnt} women standing close together, shoulders touching, each facing the camera straight on in a perfectly frontal portrait, heads level, both ears of every woman clearly visible on either side of her face, framed tightly from the very top of their heads down to the line of their shoulders, the frame cutting off just below them, so {hang} fully hang in view. Every face is large and sharp. All of them stand together in one single shared scene, in one row in front of the same continuous background, and this is one single photograph taken with one camera at one moment, not a collage: the women overlap slightly in depth and the background runs unbroken behind all of them."
        lit="A soft frontal light on all the faces and ears, so the makeup and the glints on every piece of metal read clearly"
    else:
        hd=f"Professional fashion photograph, close-up beauty portrait. {cnt} women standing close together, shoulders touching, {tw} with their heads turned about forty-five degrees to their left in a three-quarter view, their eyes still looking straight into the camera, one ear and the turned cheek of every woman clearly visible, and from this angle the full projection of every woman's lips from her face is clearly visible, framed tightly from the very top of their heads down to the line of their shoulders, the frame cutting off just below them, so {hang} fully hang in view. Every face is large and sharp. All of them stand together in one single shared scene, in one row in front of the same continuous background, and this is one single photograph taken with one camera at one moment, not a collage: the women overlap slightly in depth and the background runs unbroken behind all of them."
        lit="A soft key light from the front and slightly to the side on all the faces, so the makeup and the glints on every piece of metal read clearly"
    body=[]
    for i,(s_,p) in enumerate(zip(subs,prs),1):
        body.append(f"#{i}: {s_}"); body.append(f"#{i} {p}")
    if ear=="earring":
        earp="Earrings: each woman's large earrings hang freely in the air down to the level of her collarbone and no lower, and no earring of one woman hangs in front of another woman's face."
    else:
        share_w=HW2.format(col=COL2[nw]).replace("On each ear the two iron rings each carry","On each ear of every woman the two iron rings each carry")
        for a,b in [("hanging side by side on chains of different lengths","hanging side by side, each weight on its own thick chain of heavy black iron links, the chains of different lengths"),("reaching down along her neck to her collarbones","reaching down along the neck to the collarbones"),("hangs just past her jaw; the lobe does not sag, droop, collapse or hang down to her shoulder, her head stays upright, and","hangs just past the jaw; no lobe sags, droops, collapses or hangs down to the shoulder, every head stays upright, and")]:
            assert a in share_w,a; share_w=share_w.replace(a,b)
        earp="Ear weights: "+share_ear(share_w,nw,ear,h,rr)
    ratio={2:"4:3 horizontal",3:"3:2 horizontal"}[n]
    depth="Piercing depth: every bar is embedded in the skin so only its two end studs show on the surface; every ring passes through a small healed opening in the skin, the skin visible through the loop, and every stud sits through the skin with its back hidden, all of them passing through the real tissue with the skin wrapping snugly around them."
    bgt=BGD[bgname]
    if bgt is None:
        pose_bg="They all share one single continuous pitch-black background behind them, with no separate panels, no split screen, no borders and no different backgrounds behind different women."
        light_bg="MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient."
    else:
        pose_bg="They all share one single continuous background behind them, the same one for all of them, with no separate panels, no split screen, no borders and no different backgrounds behind different women."
        light_bg=bgt
    pend="the hanging pieces of one never hang" if ear=="earring" else "the weights of one never hang"
    parts=[hd]+body+[earp,
      "All piercings: Each woman wears only the piercings named in her own paragraph, in those places and nowhere else; on every woman the eyes, eyelids and eyebrows stay completely clear. All jewelry is real metal, sitting in real, calm, healthy skin — no redness, no swelling, no irritation — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes.",
      depth,
      "Hair: every woman's hair is swept back behind both ears, leaving both ears, jawlines and necks fully visible so every hanging piece is in clear view.",
      f"Pose: each woman stands upright, arms relaxed at her sides, heads level, shoulder to shoulder and close enough that their shoulders and upper arms touch or slightly overlap in depth, leaning very slightly toward each other, so that {pend} in front of another and each woman's hanging pieces stay in front of her own shoulder. {pose_bg} There is no dividing line between the women, and no different light, colour or background on different women.",
      f"Lighting: {light_bg} One single light setup lights everyone from the same direction with the same colour, so the shadows and highlights match on every woman. {lit}; a thin cool rim light along the hair and shoulders. {ratio} 8K."]
    t="\n\n".join(parts); t=re.sub(r"catching the light\s+Her face","catching the light. Her face",t); t=re.sub(r"  +"," ",t)
    assert not re.search(r"[가-힣]",t) and "{" not in t
    assert not re.search(r"two iron rings|two openings|two columns",t) or h==2
    d=re.search(r"\b(\w+) \1\b",t)
    return t,labs,(d.group(0) if d else None)
CFG=[
 ("듀오",301,[("eye","사이렌 눈 +1"),("eye","후디드 아이 +1")],"front","iron",2,"순흑 기본"),
 ("듀오",302,[("lip","러시안 립 초과장"),("arch","서큐버스")],"q45","mix",3,"실내 청록 벨벳 라운지"),
 ("듀오",303,[("eye","양쪽 트임 6배+큰 눈"),("lip","체리 립")],"front","earring",2,"스튜디오 짙은 남색"),
 ("듀오",304,[("arch","바비 인형(금발)"),("eye","애교살 초극대")],"front","one",1,"실외 푸른 시간대 호숫가"),
 ("듀오",305,[("lip","키홀 퓨트 +1"),("eye","도 아이 +1")],"q45","mix",2,"스튜디오 짙은 청록"),
 ("트리오",311,[("eye","도 아이 +1"),("lip","러시안 립 극한"),("arch","브랫츠 돌")],"q45","iron",3,"순흑 기본"),
 ("트리오",312,[("eye","후디드 아이 +1"),("eye","애교살 초극대"),("eye","양쪽 트임 8배+거대한 눈")],"front","mix",2,"실내 청록 벨벳 라운지"),
 ("트리오",313,[("lip","러시안 립 과장"),("lip","체리 립"),("lip","키홀 퓨트 +1")],"q45","earring",2,"순흑 기본"),
 ("트리오",314,[("arch","서큐버스"),("arch","인어 세이렌"),("arch","바비 인형(갈색 머리)")],"front","one",1,"실외 비 오는 밤 청록·남색 네온"),
 ("트리오",315,[("eye","사이렌 눈 +1"),("lip","러시안 립 초과장+1"),("arch","브랫츠 돌")],"front","mix",3,"실외 안개 낀 숲"),
]
o=["# LumineX — Face Sculpt 듀오·트리오 샘플 10개 v5 (듀오 5 · 트리오 5, 입술 강조가 든 조에 45도 포함)\n",
"- v5 변경: 입술 강조가 든 조(2·5·6·8번)는 전원이 머리를 45도 돌린 3/4 구도로 만들었습니다(눈은 카메라 정면 응시, 입술의 돌출이 보이는 각도). 나머지는 정면입니다.",
"- v4(한 공간 수정) 유지: v3에서 인물이 서로 다른 공간에서 찍은 사진처럼 나뉘어 보인다는 지적을 반영했습니다: 인물을 어깨가 닿을 만큼 붙여 세우고(깊이로 살짝 겹침), 한 대의 카메라로 한 순간에 찍은 한 장의 사진이라고 명시했으며, 전원에게 같은 방향·같은 색의 조명 하나를 쓰고 사이에 경계선이나 다른 조명·배경이 없다고 적었습니다.",
"- 반영: 귀 스타일(철 추·혼합 금속 추·단일 금속 추·대형 귀걸이), 귀 구멍 1~3개, 추 크기·처짐·쇄골 높이 규칙, 트임 눈 라이너 수정(메이크업 색 따름 / 메이크업 없음이면 라이너 없음), 배경 규칙(전원이 같은 배경 하나, 차갑고 중간~어두운 색의 아웃포커스 또는 스튜디오 색). 물건 추가 축(눈썹 대용·슬롯·테마)은 길이 때문에 이번엔 뺐습니다.",
"- 정상/이상 번호만 알려주세요.\n"]
for i,(nm,seed,spec,mode,ear,h,bg) in enumerate(CFG,1):
    for tr in range(60):
        try: t,labs,dup=group3(seed*100+tr,spec,mode,ear,h,bg)
        except AssertionError as e: continue
        if dup and dup.split()[0].lower() not in("had","that"): continue
        break
    else: raise SystemExit(("fail",i))
    names=" + ".join(n for k,n in spec)
    earlab={"iron":"철 추","mix":"혼합 금속 추","one":"단일 금속 추","earring":"대형 귀걸이"}[ear]
    o.append(f"## {i}. {nm} · {names}"+(" (45도)" if mode!="front" else " (정면)")+f" · {earlab}"+("" if ear=="earring" else f" · 귀 구멍 {h}개")+f" · 배경 {bg}")
    for j,l in enumerate(labs,1): o.append(f"- #{j}: {l}")
    o.append("\n```\n"+t+"\n```\n")
    print(i,nm,len(t.split()),dup)
open(OUT+'LumineX_FaceSculpt_DuoTrio_v5_10.md','w',encoding='utf-8').write("\n".join(o))
