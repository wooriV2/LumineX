import re,random
exec(open('new_lib.py',encoding='utf-8').read())
FORE_PEND="A forehead pendant: a fine gold chain runs along the centre parting of her hair and ends in a teardrop gem pendant resting at the middle of her forehead."
NOSE_EAR="A nose-to-ear chain: a fine chain swags from the ring on her left nostril wing across the cheek, well below the eye and clear of the lips, up to a hook at the top of her left ear."
BEADS="A forehead bead band: a row of large turquoise and coral beads is strung across the top of her forehead along the hairline like a headband, with a round ornament set with a large gem at its centre."
def subj(t): return [x for x in t.split("\n\n") if x.startswith("Subject:")][0]
def subj_add(t,txt):
    s=subj(t); k=" Her whole face, ears and neck are real living flesh"; assert k in s
    return t.replace(s,s.replace(k," "+txt+k,1))
def slots(t,txts):
    k="The left and right sides are balanced."; assert k in t
    return t.replace(k," ".join(txts)+" "+k,1)
def skin(t,txt):
    s=subj(t); s2,n=re.subn(r"adult (Korean|Chinese|Japanese) woman — .*?, (early|mid|late) (\d0s)",lambda m:f"adult woman — {txt}, {m.group(2)} {m.group(3)}",s,count=1); assert n==1
    return t.replace(s,s2)
def light(t,bg,key,rim):
    a="MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient."
    assert a in t; t=t.replace(a,bg)
    b="A soft frontal light on her face and ears, so the glints on every piece of metal read clearly against her skin; a thin cool rim light along the hair and shoulders."
    assert b in t; return t.replace(b,key+" "+rim)
def finish(t,mode,nw,rr,lab,force=None):
    global FORCE
    FORCE=force
    return apply_ear(t,mode,nw,random.Random(rr.randrange(10**9)),w,HW2,COL2,None,lab)

THEMES["bright"]=("Every piece on her face is bright and light-coloured, so that it gleams clearly against her deep skin: small polished gold and mirror-silver studs, rings and bars, and tiny clear diamonds and pearls.","The face and ear jewelry is real polished bright yellow gold and mirror silver set with clear diamonds, white pearls and icy pale gems, every piece light and gleaming","밝은 금속·보석")

A_OLD="two separate large healed openings in the earlobe, one below the other with a clear gap of bare skin between them, each opening holding its own very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel,"
def holes(t,h,lab):
    if h==2: return t,lab+" · 귀 구멍 2개"
    assert A_OLD in t
    if h==1:
        t=t.replace(A_OLD,"one large healed opening in the earlobe holding a very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel,")
        t=t.replace("these two iron rings","this iron ring")
        t,n=re.subn(r"On each ear the two iron rings each carry their own column of weights, the two columns holding [^,]*? weights, hanging side by side","On each ear the single iron ring carries all the weights, hanging in a staggered cluster",t); assert n==1
        t=t.replace("Because the load is shared between two openings,","Because all the load is carried by one opening,")
    else:
        t=t.replace(A_OLD,"three separate large healed openings in the earlobe, one below another with a clear gap of bare skin between each, each opening holding its own very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel,")
        t=t.replace("these two iron rings","these three iron rings")
        t,n=re.subn(r"On each ear the two iron rings each carry their own column of weights, the two columns holding [^,]*? weights, hanging side by side","On each ear the three iron rings share the weights between them in uneven numbers, each ring carrying its own column of weights, hanging side by side",t); assert n==1
        t=t.replace("Because the load is shared between two openings, the weight gently pulls each earlobe down a little into a slightly elongated, soft, healthy loop of skin, only a small natural droop that is just enough to show how heavy the weights are;","Because the load is shared between three openings, the weight pulls each earlobe down only very slightly into a soft, healthy loop of skin, a barely noticeable natural droop that is just enough to show the weights are heavy;")
        assert "shared between three openings" in t
    assert not re.search(r"two iron rings|two openings|two columns",t)
    return t,lab+f" · 귀 구멍 {h}개"
METALS0=dict(METALS)
BRIGHT={"gold":("polished bright yellow gold with a hammered, gleaming surface","gold"),"silver":("bright polished mirror silver with a gleaming hammered surface","silver"),"tin":("bright polished chrome-silver with a gleaming hammered surface","tin"),"brass":("bright polished golden brass with a gleaming surface","brass")}
def brighten(t):
    t=t.replace("rough and matte and unpolished with no shine","bright, polished and gleaming")
    t=t.replace("rough, matte, unpolished heavy metal in mixed materials (lead, tin, gold, silver, bronze, copper, brass and iron)","bright polished heavy metal in mixed materials (gold, silver, chrome-silver and brass)")
    t=t.replace("rough, matte, unpolished ","bright, polished ")
    t=t.replace("black cast-iron","bright polished gold").replace("black cast iron","bright polished gold").replace("blackened steel","polished bright silver").replace("heavy black iron links","heavy bright metal links")
    t=re.sub(r"\biron (rings?)\b",r"gold \1",t)
    return t
rr=random.Random(7373)
OUTS=[]
def make(title,N,zero,minimal,mode,build_fn=None,force=None,expr0=None,theme=None,style0=None,bright=False,h=2):
    global METALS
    for tr in range(100):
        r2=random.Random(rr.randrange(10**9))
        try:
            nw=r2.choice([8,9,10]); deco=r2.choice(["",HENNA,STICK,BOTH])
            t,lab,lt,nw=base(r2,N,zero,minimal,deco,nw,theme=theme,expr0=expr0,style0=style0)
            if build_fn: t=build_fn(t)
            if bright: METALS=BRIGHT
            try: t,lab2=finish(t,mode,nw,r2,lab+f" · 귀 추 {nw}개/귀 2구멍",force)
            finally: METALS=METALS0
            if bright: t=brighten(t)
            t,lab2=holes(t,h,lab2)
        except AssertionError as e: continue
        if re.search(r"[가-힣]",t) or (re.search(r"\b(\w+) \1\b",t) and re.search(r"\b(\w+) \1\b",t).group(1).lower() not in("had","that")): continue
        if bright and re.search(r"blackened|black cast|bronze|copper|\blead\b|\biron\b|pitted|tarnished|dark (silver|brass)",t): continue
        OUTS.append((title+" · "+lab2+(" · "+lt if lt else ""),t)); print(len(OUTS),len(t.split())); return
    raise SystemExit(("fail",title))
Z=("tmp","brow","bri")
BW="She has no eyebrows at all: "

COOL=" The background colours are cool, mid-to-dark tones clearly different from her skin tone, never beige, peach, orange or brown, and never bright."
def bg(t,desc,key,rim):
    return light(t,"The background is "+desc+", out of focus with a shallow depth of field, with no objects and no people in the background, and the background is darker and softer than her face so that her face and the metal are the brightest, sharpest part of the image."+COOL,key,rim)
HEN=lambda t:subj_add(t,BW+"her brow bones are bare skin, painted in place of brows with a delicate reddish-brown henna pattern of tiny curling vines and dots following the line of each brow.")
make("귀 구멍 1개 · 무거운 추 (철)",25,Z,False,"iron",h=1)
make("귀 구멍 3개 · 무거운 추 (혼합 금속)",25,Z,False,"mix",h=3)
make("귀 구멍 3개 · 무거운 추 (철)",25,Z,False,"iron",h=3)
def mk2(t,f,desc,key,rim): return bg(HEN(t),desc,key,rim)
make("헤나 눈썹 + 실내 짙은 청록 벨벳 라운지 · 구멍 2개",25,Z,False,"mix",lambda t:mk2(t,0,"a dim lounge with deep teal velvet walls and a few soft blurred lamps in muted blue-green","A soft cool frontal light on her face and ears, so the glints on every piece of metal read clearly against her skin;","a thin pale teal rim light along the hair and shoulders."),h=2)
make("헤나 눈썹 + 실외 푸른 시간대 호숫가 · 구멍 3개",25,Z,False,"iron",lambda t:mk2(t,0,"a lakeside at blue hour, a blurred dark navy lake and distant hills under a deep indigo sky","A soft cool frontal light on her face and ears, so the glints on every piece of metal read clearly against her skin;","a thin cool blue rim light along the hair and shoulders."),h=3)
make("헤나 눈썹 + 실외 비 오는 밤 청록·남색 네온 · 구멍 1개",25,Z,False,"mix",lambda t:mk2(t,0,"a city street at night in the rain, blurred neon signs and car lights in teal and deep blue","A soft frontal light on her face and ears, so the glints on every piece of metal read clearly against her skin;","a thin teal and blue neon rim light along the hair and shoulders."),h=1)
o=["# LumineX — 새 축 시험 샘플 파일 4 (6개)\n","- 1~3 귀 구멍 수 변주(1개·3개·3개, 추 총 개수만 고정, 처짐은 자연스럽게), 4~6 헤나 눈썹 + 새 배경 규칙(차갑고 중간~어두운 색, 피부톤과 다른 색, 아웃포커스) + 구멍 수 랜덤.","- 정상/이상 번호만 알려주세요.\n"]
for i,(title,p) in enumerate(OUTS,1): o.append(f"## {i}. {title}\n\n```\n{p}\n```\n")
open(OUT+'LumineX_NewAxes_Test_File4.md','w',encoding='utf-8').write("\n".join(o))
