import re,random
src=open('mk_group5.py',encoding='utf-8').read()
exec(src[:src.index("R=_r.Random(20261013)")])
TAILO="Real skin fine grain and a soft sheen of natural oils on her face, ears and neck, individual hair strands catching the light"
TAILN="Her whole face, ears and neck are real living flesh with real pores and fine skin grain and a soft sheen of natural oils, individual hair strands catching the light"
SW=[("A strikingly beautiful, seductive adult woman","A striking, seductive adult woman"),("A strikingly beautiful adult Western woman","A striking adult Western woman"),("A strikingly beautiful adult woman","A striking adult woman"),
("with the glamorous Y2K 'Bratz doll' face brought to life: warm golden-tan skin with a high-gloss, airbrushed, glossy finish and","with the glamorous Y2K 'Bratz' glam look: warm golden-tan skin with real visible pores and"),
("with the face of a living Barbie doll pushed to its extreme — flawless, poreless porcelain-smooth skin with","with a Barbie-pink glam look pushed to its extreme — fair skin with real visible pores and"),
("extra-large doll eyes","extra-large eyes"),("doll-eye contact lenses","big-iris contact lenses"),
("; it reads as the most perfect, most doll-like adult woman's face imaginable","."),
("smooth, flawless, pale skin with","pale skin with real visible pores and"),("in luminous blood-red","in blood-red"),
("dewy, wet-looking, glowing skin as if","dewy skin with real visible pores as if"),("in luminous violet","in violet"),("luminous ",""),
(TAILO,TAILN),("a photograph of a real woman, not","a photograph of a real woman's face, not")]
S1="Her whole face, ears and neck are real living flesh with real pores and fine skin grain, real living eyes with bright catchlights and genuine depth, individual hair strands catching the light"
B1="Her whole face, ears and neck are real living skin with visible pores and faint peach-fuzz hairs, slightly asymmetrical, never airbrushed and never smooth like plastic, real wet catchlights in the eyes, individual hair strands catching the light."
def real(t,names):
    t=re.sub(re.escape(S1)+r'\.?',B1,t)
    # apply only inside archetype paragraphs
    def fix(m):
        p=m.group(0)
        if not re.search(r"Bratz|Barbie|succubus|mermaid siren",p): return p
        for a,b in SW: p=p.replace(a,b)
        return p.replace("..",".")
    return re.sub(r"(?<=\n\n#\d: ).*?(?=\n\n#\d )",fix,t,flags=re.S)
SPECS=[[("arch","브랫츠 돌"),("arch","바비 인형(금발)"),("lip","체리 립")],
       [("arch","서큐버스"),("arch","인어 세이렌"),("eye",EYEP[0][0])],
       [("arch","브랫츠 돌"),("eye",EYEP[1][0]),("lip","키홀 퓨트 +1")]]
o=["# LumineX — 유형 인물 사실감 구조 적용 트리오 3개\n","- 유형 문단(브랫츠·바비·서큐버스·인어)만 교체: 'doll'·'airbrushed'·'high-gloss'·'poreless'·'luminous' 같은 장난감/그림 단어를 빼고 'real visible pores'를 넣었고, 끝 문장을 'Her whole face, ears and neck are real living flesh with real pores…' 구조로 바꿨습니다(글자 수 약 +10단어). 일반 인물 문단은 그대로.","- 정상/이상은 번호로, 이상이면 '고무 느낌'인지 한 줄만 알려주세요.\n"]
R=random.Random(20261018)
for i,spec in enumerate(SPECS,1):
    ear=R.choices(["iron","mix","one","earring"],[25,35,15,15])[0]; h=R.choices([1,2,3],[75,161,64])[0]; bg=R.choice(BGN)
    for tr in range(300):
        try: t,labs,dup=group3(R.randrange(10**7),spec,"front",ear,h,bg)
        except AssertionError: continue
        mk=[l.split(" · ")[4] for l in labs if "유형 고유 메이크업" not in l]
        if len(set(mk))<len(mk) or sum(m=="메이크업 없음" for m in mk)>1: continue
        break
    t0=t; t=real(t,spec)
    assert t!=t0 and not re.search(r"[가-힣]",t)
    for m in re.finditer(r"(?<=\n\n#\d: ).*?(?=\n\n#\d )",t,re.S):
        if re.search(r"Bratz|Barbie|succubus|mermaid siren",m.group(0)): assert not re.search(r"doll|airbrushed|poreless|high-gloss|\\bluminous",m.group(0)),[m.group(0)[max(0,x.start()-60):x.end()+30] for x in re.finditer(r"doll|airbrushed|poreless|high-gloss|\\bluminous",m.group(0))]
    o.append(f"## {i}. 3인 · "+" + ".join(nm for k,nm in spec)+f" · ear {ear} {h}")
    for j,l in enumerate(labs,1): o.append(f"- #{j}: {l}")
    o.append("\n```\n"+t+"\n```\n"); print(i,len(t0.split()),len(t.split()))
open(OUT+'LumineX_ArchReal_Trio_3.md','w',encoding='utf-8').write("\n".join(o))
