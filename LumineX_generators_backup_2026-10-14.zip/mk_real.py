import re,random
src=open('mk_group5.py',encoding='utf-8').read()
exec(src[:src.index("R=_r.Random(20261013)")])
GROUP=dict(globals())
ns2={}
g=open('gen_fs2.py',encoding='utf-8').read()
exec(compile(g[:g.index('if __name__=="__main__":')],'gfs2','exec'),ns2)
m=open('mk_group4.py',encoding='utf-8').read()
exec(m[m.index('END="'):m.index('TEXT.update')],ns2)
CAM="Shot on an 85mm lens with natural skin texture preserved, no beauty retouching, no skin smoothing and no plastic or airbrushed look."
REAL="Realism: every woman's face, ears and neck are real living flesh with real pores, fine vellus hair and subtle natural skin texture, real living eyes with genuine depth and bright catchlights, and individual strands of hair catching the light — a photograph of real women, not a render."
REPS=[("luminous fair porcelain complexion","fair complexion"),("clear glass-skin glow","healthy natural glow"),("smooth dewy skin","natural dewy skin with fine pores"),("doll-eye contact lenses","big-iris contact lenses")]
def soften(t):
    for a,b in REPS: t=t.replace(a,b)
    return t
def boost_group(t):
    t=soften(t)
    assert "\n\nHair:" in t
    t=t.replace("\n\nHair:","\n\n"+REAL+"\n\nHair:",1)
    t,n=re.subn(r"( )([0-9]+:[0-9]+ horizontal 8K\.?)\s*$",r" "+CAM+r" \2",t); assert n==1
    return t
def boost_single(t):
    t=soften(t)
    t,n=re.subn(r"( )([0-9]+:[0-9]+ [a-z ]*8K[a-z ]*\.?)\s*$",r" "+CAM+r" \2",t); assert n==1,t[-200:]
    return t
R=random.Random(20261014)
o=["# LumineX — 실사 보강 시험 3개 (솔로 1 · 트리오 1 · 5인 1)\n","- 보강 내용: ① 인형·유리 같은 피부 표현 완화(도자기 피부→피부, 유리 피부 광택→자연스러운 광택, 인형 렌즈→큰 홍채 렌즈; 유형 고유 문구와 주인공 부위 문구는 그대로) ② 그룹 공통부에 실사 문단 1개(모공·잔털·눈의 깊이) ③ 조명 끝에 카메라 문장(85mm, 자연 피부 질감, 보정·매끈 처리·플라스틱 느낌 없음). 극단 표현은 그대로.","- 비교는 이전에 받은 같은 종류 샘플(솔로·트리오·5인)과 해 주세요. 정상/이상과 함께 \"실사 쪽으로 나아졌다/그대로/더 나빠졌다\"만 번호별로 알려주세요.\n"]
# solo
name=R.choice(["사이렌 눈 +1","도 아이 +1","후디드 아이 +1","애교살 초극대"]); 
ns2['tusk_flag']=False
TEXT_E={n:t for n,t,c in ns2['EYE2']}
it=ns2['build2'](1,'eye',name,TEXT_E[name],R)
ts=boost_single(it["prompt"])
assert not re.search(r"[가-힣]",ts)
o.append(f"## 1. 솔로 · {it['title']}\n\n```\n{ts}\n```\n"); print(1,len(ts.split()))
for idx,n in ((2,3),(3,5)):
    G3=GROUP['group3']
    while True:
        spec=GROUP['draw_spec'](R,n)
        ear=R.choices(["iron","mix","one","earring"],[25,35,15,15])[0]; h=R.choices([1,2,3],[75,161,64])[0]; bg=R.choice(GROUP['BGN'])
        for tr in range(300):
            try: t,labs,dup=G3(R.randrange(10**7),spec,"front",ear,h,bg)
            except AssertionError: continue
            mk=[l.split(" · ")[4] for l in labs if "유형 고유 메이크업" not in l]
            if len(set(mk))<len(mk) or sum(x=="메이크업 없음" for x in mk)>1: continue
            if dup and dup.split()[0].lower() not in("had","that"): continue
            break
        else: continue
        break
    tb=boost_group(t); assert not re.search(r"[가-힣]",tb)
    earlab={"iron":"철 추","mix":"혼합 금속 추","one":"단일 금속 추","earring":"대형 귀걸이"}[ear]
    o.append(f"## {idx}. {n}인 · "+" + ".join(nm for k,nm in spec)+f" (정면) · {earlab}"+("" if ear=="earring" else f" · 귀 구멍 {h}개")+f" · 배경 {bg}")
    for j,l in enumerate(labs,1): o.append(f"- #{j}: {l}")
    o.append("\n```\n"+tb+"\n```\n"); print(idx,len(tb.split()))
open(OUT+'LumineX_RealismBoost_3.md','w',encoding='utf-8').write("\n".join(o))
