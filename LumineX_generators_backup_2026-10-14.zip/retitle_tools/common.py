import re
CNT = {"Solo": "솔로", "Duo": "듀오"}
POSE_RULES = [
 (r"^seated.*(bench)", "벤치 앉기"), (r"^seated.*(stool)", "스툴 앉기"), (r"^seated.*(chair|armchair)", "의자 앉기"),
 (r"^seated.*(steps|stairs|flight)", "계단 앉기"), (r"^seated.*(ledge|wall)", "턱 앉기"), (r"^seated", "앉기"),
 (r"kneeling on one knee", "한쪽 무릎 꿇기"), (r"kneeling on both", "양 무릎 꿇기"), (r"^reclining", "기대어 눕기"),
 (r"walking away", "뒤돌아 걷기"), (r"walk|stride", "걷기"), (r"leaning", "기대기"),
 (r"back fully|^back to the camera|^back three|back three", "뒷모습"), (r"hip pop", "힙 팝"),
 (r"profile", "옆모습"), (r"hands pressed together", "기도 자세"), (r"arms raised|raised above her head|raised overhead", "양팔 들기"),
 (r"sweeping her hair|hair streaming", "머리 넘기기"), (r"framing (her own |the )?face", "얼굴 감싸기"),
 (r"jump", "점프"), (r"lung", "런지"), (r"arms crossed", "팔짱"), (r"clasped behind her head", "손 깍지"),
 (r"s-curve", "S라인"), (r"hands? on (her|the) (hips|waist)|on her hips|fists pressing", "손 허리"),
 (r"three-quarter", "3/4 각도"), (r"one hand on her waist", "손 허리")]
def pose_ko(p):
    q = p.lower()
    for rx, ko in POSE_RULES:
        if re.search(rx, q): return ko
    return "서 있기"
def uniq(L):
    o = []
    for x in L:
        if x and x not in o: o.append(x)
    return o
def agg(L):
    u = uniq(L)
    if len(u) <= 2: return " / ".join(u)
    return f"{u[0]} 외 {len(u)-1}"
def mk_clean(s):
    s = s.strip()
    for _ in range(3):
        s = re.sub(r"\s*(아주 강함|강함|강화|포인트|\d단계)\s*$", "", s)
        s = re.sub(r"\((강화|포인트|강함)\)$", "", s).strip()
    return s
def parse(title):
    head, _, rest = title.partition(" (")
    rest = rest.rstrip(")")
    return head, [x.strip() for x in re.split(r" · | ‖ ", rest) if x.strip()]
def strip_par(s): return re.sub(r"\(.*?\)", "", s).strip()
def bg_clean(s):
    s = strip_par(s)
    return re.sub(r"^(실내|실외) ", "", s)
def join(parts): return " · ".join(x for x in parts if x)
