PREFIX3 = ("la_automaton_", "la_edible_", "la_dolljoint_", "la_nebula_", "la_lava_", "la_brick_")
OLD3 = re.compile(r"^(Automaton|Edible|DollJoint|Nebula|Lava|Brick) (Solo|Duo) #\d+ \(")
def retitle3(d):
    t = d["title"]; m = d["meta"]
    head, items = parse(t)
    for k, v in CNT.items(): head = re.sub(rf"\b{k}\b", v, head)
    body = agg(m.get("physiques") or [])
    if m.get("variants"): mat = " + ".join(v.split(" · ")[0] for v in m["variants"])
    else: mat = (m.get("variant") or "").replace(" · ", " ")
    pose = ""
    if (m.get("group_size") or 1) == 1:
        ps = re.findall(r"Pose: ([^.\n—]*)", d["prompt"])
        pose = pose_ko(ps[0]) if ps else ""
    bg = next((strip_par(x[3:]) for x in items if x.startswith("배경 ")), "")
    mk = agg([mk_clean(x[5:]) for x in items if x.startswith("메이크업 ")])
    return join([head, body, mat, pose, bg, mk])
