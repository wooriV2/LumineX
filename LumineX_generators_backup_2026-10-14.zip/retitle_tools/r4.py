OLD4 = re.compile(r"^Face Sculpt( Silverfox| Mixed-Age| Group| Same-Type)? #\d+ \(")
AGE_POS = {"early": "초", "mid": "중", "late": "후"}
def age_ko(s):
    m = re.match(r"^(.*?)\((early|mid|late) (\d+)s\)$", s)
    if m:
        base, pos, n = m.groups()
        if re.search(r"\d+대", base): return base.strip()
        return f"{base.strip()} {n}대 {AGE_POS[pos]}"
    s2 = strip_par(s) or s
    return "원래 나이" if s2 == "유형" else s2
def ear_short(x):
    if x.startswith("대형 귀걸이 "): return x[len("대형 귀걸이 "):]
    if x.startswith("귀걸이+"): return "귀걸이+추 " + re.sub(r"^귀걸이\+혼합 금속 추 \d+개\s*", "", x)
    if x.startswith("혼합 금속 추"): return "귀 금속 추"
    if x.startswith("귀 추"): return "귀 철 추"
    return x
def ear_label(forms):
    has_w = any("추" in x for x in forms); has_e = any("추" not in x for x in forms)
    return "추+귀걸이" if (has_w and has_e) else ("추" if has_w else "귀걸이")
def stars_txt(stars, n):
    parts = [s.strip() for s in stars]
    if len(set(parts)) == 1 and n >= 2 and "(" not in parts[0]: return ""
    pre = {p.split("(")[0].strip() for p in parts}
    if len(pre) == 1 and all("(" in p for p in parts): parts = [re.search(r"\((.*)\)", p).group(1) for p in parts]
    return " + ".join(parts) if len(parts) <= 3 else " + ".join(parts[:3]) + f" 외 {len(parts)-3}"
def retitle4(d):
    t = d["title"]; m = d["meta"]; fmt = m.get("format")
    head, items = parse(t)
    if fmt == "face-sculpt":
        series = head.split(" #")[0]; num = head.split(" #")[1]
        nat, age, expr, star = items[0], age_ko(items[1]), items[2], items[3]
        jaw = next((x for x in items[4:] if re.search(r"턱$|^V라인$|베이비 페이스$", x)), "")
        mk = next((("메이크업 없음" if x == "메이크업 없음" else mk_clean(x[5:])) for x in items if x.startswith("메이크업 ")), "")
        if not mk and any(x == "유형 고유 메이크업" for x in items): mk = "유형 고유 메이크업"
        pc = next((x for x in items if re.match(r"^P\d+$", x)), "")
        ear = next((ear_short(x) for x in items if re.match(r"^(대형 귀걸이 |혼합 금속 추|귀 추|귀걸이\+)", x)), "")
        bg = next((bg_clean(x[3:]) for x in items if x.startswith("배경 ")), "")
        return join([f"{series} #{num}", f"{nat} {age}", expr, star, jaw, mk, pc, ear, bg])
    series, num = head.split(" #")
    bg = next((bg_clean(x[3:]) for x in items if x.startswith("배경 ")), "")
    ears = next((x[2:] for x in items if x.startswith("귀 ")), "")
    forms = [re.sub(r"\(.*?\)", "", e).strip() for e in ears.split(" / ")] if ears else []
    el = ("귀 " + ear_label(forms)) if forms else ""
    if fmt == "face-sculpt-group":
        n = items[0]; stars = items[1]
        sp = [x.strip() for x in stars.split(" + ")]
        return join([f"{series} {n} #{num}", stars_txt(sp, len(sp)), el, bg])
    gt = items[0]; mm = re.match(r"^(.*?)\s*(\d+인)$", gt); gname, n = mm.group(1), mm.group(2)
    sp = [x.strip() for x in items[1].split(" + ")]
    return join([f"{series.replace('Same-Type', '동종')} {n} #{num}", gname, stars_txt(sp, len(sp)), el, bg])
