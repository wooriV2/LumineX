import json,re,collections,sys
exec(open('common.py',encoding='utf-8').read()); exec(open('r3.py',encoding='utf-8').read()); exec(open('r4.py',encoding='utf-8').read())
O="/mnt/user-data/outputs/"
B3=["la_automaton_60_bundle.json","la_edible_60_bundle.json","la_dolljoint_60_bundle.json","la_dolljoint_duo_30_bundle.json","la_nebula_60_bundle.json","la_lava_60_bundle.json","la_brick_60_bundle.json"]
B4=["la_facesculpt_300_bundle_v2.json","la_facesculpt_grp_140_bundle.json","la_facesculpt_mix_300_bundle.json","la_facesculpt_same_162_bundle.json","la_facesculpt_sf_300_bundle.json"]
for grp,fs,fn,old in (("3",B3,retitle3,OLD3),("4",B4,retitle4,OLD4)):
    tot=0; L=[]; bad=0
    for f in fs:
        d=json.load(open(O+f,encoding='utf-8')); ls=[]
        for x in d:
            assert old.match(x['title']), x['title']
            n=fn(x); ls.append(len(n)); L.append(len(n)); tot+=1
            if not n or ' · ·' in n or n.endswith('·') or re.search(r'[A-Za-z]{3,} \d',n) and False: bad+=1; print('BAD',x['key'],n)
            assert not old.match(n)
        print(f, len(d), "avg", round(sum(ls)/len(ls)), "max", max(ls)); print("   ", fn(d[0]))
    print("GROUP",grp,tot,"avg",round(sum(L)/len(L)),"max",max(L),"bad",bad)
