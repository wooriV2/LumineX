common=open('common.py',encoding='utf-8').read()
r3=open('r3.py',encoding='utf-8').read(); r4=open('r4.py',encoding='utf-8').read()
MAIN='''
def main():
    dry = "--dry" in sys.argv; undo = "--undo" in sys.argv
    here = os.path.dirname(os.path.abspath(__file__))
    pdir = os.path.join(here, "..", "presets"); bpath = os.path.join(here, BACKUP_NAME)
    old = json.load(open(bpath, encoding="utf-8")) if os.path.exists(bpath) else {}
    if undo:
        n = 0
        for key, title in old.items():
            path = os.path.join(pdir, key + ".json")
            if not os.path.exists(path): continue
            d = json.load(open(path, encoding="utf-8"))
            if d.get("title") != title:
                d["title"] = title; json.dump(d, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=2); n += 1
        print(f"되돌림 {n}개 (백업 {len(old)}개 기준)"); return
    changed = skipped = failed = 0; byhead = {}; lens = []; samples = []; fails = []
    for path in sorted(glob.glob(os.path.join(pdir, "la_*.json"))):
        key = os.path.basename(path)[:-5]
        if not key.startswith(PREFIXES): continue
        d = json.load(open(path, encoding="utf-8")); t = d.get("title", "")
        if not OLD.match(t): skipped += 1; continue
        try: new = RETITLE(d)
        except Exception as e: failed += 1; fails.append(f"{key}: {e!r}"); continue
        if not new or new == t: skipped += 1; continue
        changed += 1; lens.append(len(new)); h = t.split(" #")[0]; byhead[h] = byhead.get(h, 0) + 1
        if len(samples) < 4 and (changed % 97 == 1 or changed == 1): samples.append((t, new))
        if not dry:
            old.setdefault(key, t); d["title"] = new
            json.dump(d, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    if not dry and changed: json.dump(old, open(bpath, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(("[DRY] " if dry else "") + f"제목 변경 {changed}개 / 건너뜀 {skipped}개 / 해석 실패 {failed}개")
    for h in sorted(byhead): print(f"  {h}: {byhead[h]}개")
    if lens: print(f"  새 제목 길이: 평균 {sum(lens)//len(lens)}자 / 최대 {max(lens)}자")
    for a, b in samples[:3]: print("  전:", a, "\\n  후:", b)
    for f in fails[:5]: print("  실패:", f)

if __name__ == "__main__":
    main()
'''
H3='''# -*- coding: utf-8 -*-
r"""
제목 규칙(시리즈 인원 #번호 · 체형 · 재질 · (솔로만 포즈) · 배경 · 메이크업)을 빠뜨린 새 번들 390개의 제목만 교체합니다.
프롬프트·키·카테고리·메타는 건드리지 않습니다. 이미 새 제목이면 건너뜁니다. (여러 번 실행해도 안전)

대상: la_automaton_ / la_edible_ / la_dolljoint_(솔로 60 + 듀오 30) / la_nebula_ / la_lava_ / la_brick_  (합계 390개)

사용법 (PowerShell, 레포 루트에서):
  $env:PYTHONUTF8="1"
  python preset_builders\\patch_la_retitle_3.py --dry     # 수정 없이 개수와 예시 확인
  python preset_builders\\patch_la_retitle_3.py           # 실제 수정 (옛 제목은 preset_builders\\retitle3_old_titles_backup.json 에 저장)
  python preset_builders\\patch_la_retitle_3.py --undo    # 되돌리기 (백업 기준)
"""
import glob, json, os, sys, re
'''
H4='''# -*- coding: utf-8 -*-
r"""
Face Sculpt 5종 1,202개의 제목을 얼굴 컷용 틀로 교체합니다. 프롬프트·키·카테고리·메타는 건드리지 않습니다.
  틀(1인): 시리즈 #번호 · 국가 나이 · 표정 · 눈·입술 대표 축 · 턱 · 메이크업 · 피어싱 · 귀 · 배경
  틀(그룹): 시리즈 N인 #번호 · 대표 축들 · 귀 · 배경
제목에서 빠지는 항목(프롬프트·메타에는 그대로 있음): 코, 정면/각도, 눈썹 대용, 헤나, 스티커, 렌즈, 테마·슬롯·치아·피부톤, 메이크업 꼬리표
이미 새 제목이면 건너뜁니다. (여러 번 실행해도 안전)

대상: la_facesculpt_ (기본 300 / Group 140 / Mixed-Age 300 / Same-Type 162 / Silverfox 300 = 1,202개)

사용법 (PowerShell, 레포 루트에서):
  $env:PYTHONUTF8="1"
  python preset_builders\\patch_la_retitle_4.py --dry     # 수정 없이 개수와 예시 확인
  python preset_builders\\patch_la_retitle_4.py           # 실제 수정 (옛 제목은 preset_builders\\retitle4_old_titles_backup.json 에 저장)
  python preset_builders\\patch_la_retitle_4.py --undo    # 되돌리기 (백업 기준)
"""
import glob, json, os, sys, re
'''
open('/mnt/user-data/outputs/patch_la_retitle_3.py','w',encoding='utf-8').write(H3+common+"\n"+r3+'\nPREFIXES = PREFIX3; OLD = OLD3; RETITLE = retitle3; BACKUP_NAME = "retitle3_old_titles_backup.json"\n'+MAIN)
open('/mnt/user-data/outputs/patch_la_retitle_4.py','w',encoding='utf-8').write(H4+common+"\n"+r4+'\nPREFIXES = ("la_facesculpt_",); OLD = OLD4; RETITLE = retitle4; BACKUP_NAME = "retitle4_old_titles_backup.json"\n'+MAIN)
