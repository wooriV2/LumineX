import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
from cover_lib import SAFE
IRON="rough black cast iron with a hammered, pitted, matte surface"
SK="The skin around the piece is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
def mk(size):
    return ("Piercings: Exactly one piercing in total, a single large healed hole through the middle of the lower lip, and nowhere else: a thick round plate of "+IRON+f" {size} is set into this hole like a plate seated in a socket, its flat face turned toward the viewer. The pierced lower lip is stretched into a thick, plump, rounded ring of soft real lip flesh in her natural lip colour that wraps the entire rim of the plate all the way around, like a collar, the plate's edge sunk into a groove inside this ring of lip so that no metal edge is visible and the lip is clearly seen holding the plate on all sides; the stretched lip makes the lower part of her mouth pouty and drawn forward. The plate is small enough to leave her upper lip, her teeth line, the corners of her mouth and her chin fully bare and visible. Nothing hangs from the plate. "+SK+" Everything else on her face and ears is completely free of piercings. All jewelry is real blackened cast iron,"+SAFE)
V=[("C — 손가락 두 개 너비","as wide as two of her fingers laid side by side"),("D — 큰 동전 크기","as wide as a large coin")]
NA=[("한국","20대","도도한"),("일본","20대","군림하는")]
o=["# LumineX — 립 플레이트 v2 (추 없음, 더 작게) 2개\n","- 추·사슬 제거, 플레이트를 더 작게(C 손가락 두 개 너비, D 큰 동전 크기). 입술 살이 두툼한 고리처럼 플레이트 테두리를 한 바퀴 감싸고 금속 가장자리는 안 보이게 묘사.","- 정상/이상(+ 입술이 플레이트를 감쌌는지)만 번호로 알려주세요.\n"]
for i,((lab,sz),(nat,grp,ex)) in enumerate(zip(V,NA),1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(64000+i*100+tr),nat,grp,ex,style="NONE",slots=["pierce"],pier_level="P3"); break
        except AssertionError: continue
    else: raise SystemExit(i)
    old=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    t=re.sub(r'\n\nJewelry:[^\n]*','',t.replace(old,mk(sz)))
    assert not re.search(r"[가-힣]",t)
    o.append(f"## {lab} — {title}\n\n```\n{t}\n```\n")
open('/mnt/user-data/outputs/LumineX_LipPlate_v2_2.md','w',encoding='utf-8').write("\n".join(o)); print("ok")
