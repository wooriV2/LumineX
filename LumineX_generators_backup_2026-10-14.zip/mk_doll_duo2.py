# -*- coding: utf-8 -*-
import re, random, sys
_s = open("mk_doll3.py", encoding="utf-8").read()
exec(_s[:_s.index("rg = random.Random(")])
rg = random.Random(int(sys.argv[1]) if len(sys.argv) > 1 else 20261016)
PLANS = [["doll", "doll"]] * 3
PAIRS = [(2, 1), (2, 3), (1, 0)]
out = ["# 인형 관절 듀오 2차 3개 — 마리오네트(청록 관절)+레진 BJD · 마리오네트+목각 마네킹 · 레진 BJD+도자기 BJD\n",
       "인형끼리만 구성했습니다. 번호별로 정상/이상만 알려주세요. 이상이면 한 줄만요(예: 한 명이 인형이 아님, 팔·다리가 실사임).\n"]
def nm(k, p):
    if k == "doll": return p[7]
    if k == "jade": return "옥 " + p[7]
    return ("목재 " if k == "wood" else "석재 ") + p[0]
for i, kinds in enumerate(PLANS, 1):
    n = len(kinds)
    for attempt in range(300):
        dv = [DOLL[j] for j in PAIRS[i-1]]
        CUR_VAR.clear(); picks = []; di = 0
        for idx, k in enumerate(kinds):
            lab = f"#{idx+1}"
            if k == "doll": v = dv[di]; di += 1; CUR_VAR[(lab, k)] = v; picks.append(v)
            elif k == "wood": picks.append(rg.choice(WOODS))
            elif k == "stone": picks.append(rg.choice(STONES))
            else: v = rg.choice(NEWV[k]); CUR_VAR[(lab, k)] = v; picks.append(v)
        physs = []
        while len(physs) < n:
            c = rg.choices(BIG5, W5)[0]
            if c not in physs: physs.append(c)
        ages = [rg.choice(AGES) for _ in range(n)]; poses = [rg.choice(POSES) for _ in range(n)]; eths = rg.sample(ETH, n)
        bid, wx = BGL.pick(rg, n)
        scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty"
        ns2["JR"].seed(rg.randrange(10**9))
        t, infos = build3(list(kinds), picks, physs, ages, poses, eths, scene)
        t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as any of them.", 1)
        if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t): continue
        break
    else: raise SystemExit("fail")
    mats = " / ".join(nm(k, p) for k, p in zip(kinds, picks))
    out.append(f"## {i}. {'듀오' if n == 2 else '트리오'} · {mats} · 체형 {', '.join(x[0] for x in physs)} · 인종 {', '.join(e[0] for e in eths)} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · 힐 40인치\n\n```\n{t}\n```\n")
    print(i, mats, len(t.split()))
open(O + "LumineX_DollJoint_Duo_v2_3.md", "w", encoding="utf-8").write("\n".join(out))
