import re,random,json,sys
src=open('gen_facesculpt.py',encoding='utf-8').read()
src=src[:src.index("rr=random.Random(20261013)")]
ns={}; exec(compile(src,'gf','exec'),ns)
lib=ns['ns']
COL2=lib['COL2']; COL2.update({4:'2 and 2',6:'3 and 3'})
HW2=lib['HW2']; SAFE=lib['SAFE']
G=ns['G']; para2=ns['para2']; HENNA=ns['HENNA']; STICK=ns['STICK']; BOTH=ns['BOTH']; OUT=ns['OUT']
NOSES=ns['NOSES']; JAWS=ns['JAWS']; TH=ns['TH']; EX=ns['EX']; NOSES=ns['NOSES']
pick_style=ns['pick_style']; make_base=ns['make_base']
TEXT={}
for n,t,c in ns['EYEITEMS']+ns['CAN']+ns['LIPITEMS']: TEXT[n]=t
ARCHF={n:f for n,f,c in ns['ARCH']}
def person(rr,nat,kind,name,nw):
    grp=rr.choice(["아이돌","20대","30대"]); expr=rr.choice(EX[grp]); v=rr.choice(["수수","화려","귀여움"])
    jaw=rr.choice(JAWS); nose=rr.choice(NOSES)
    N=25; zero=(); minimal=False
    minimal=True; deco=rr.choice(["",HENNA])
    style=pick_style(rr,N,None)
    t,title,meta=make_base(rr,nat,grp,expr,style,N)
    metal,gems=TH[v]
    pp=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    new,tot=para2(N,nw,metal,gems,deco,random.Random(rr.randrange(10**9)),None,None,zero,minimal)
    # shared parts out of the personal paragraph
    hw=HW2.format(col=COL2[nw]); assert hw in new
    new=new.replace(" "+hw,"").replace(hw,"")
    assert new.endswith(SAFE); new=new[:-len(SAFE)].rstrip().rstrip(",")+"."
    new=new.replace(" Her lips, nose, eyebrows, chin, forehead, temples and cheeks carry no piercing at all, so the shape of her lips stays completely clear and unobstructed.","").replace(" above the forehead studs,","").replace(" on its own thick chain of heavy black iron links","")
    sj=[x for x in t.split("\n\n") if x.startswith("Subject:")][0]
    BODYS="hourglass physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — most dramatic hourglass ratio ever, simultaneously maximum enormous bust AND maximum enormous hips both flaring to absolute impossible extremes while the waist is cinched to impossible minimum, "
    sj=sj.replace(BODYS,"").replace(". Real pores and fine skin grain on her skin, a soft sheen of natural oils, large eyes with bright real catchlights, full lips, ",", ")
    sj=re.sub(r" — a photograph of a real (\w+) woman's face \(.*?\), not an illustration"," — a photograph of a real \\1 woman's face, not an illustration",sj)
    sj=sj.replace("catching the light  Her face","catching the light. Her face")
    if kind=="arch":
        sj2=ARCHF[name](rr); mk="유형 고유 메이크업"
    else:
        text=ns['lensfix'](TEXT[name]) if kind=='eye' else TEXT[name]
        if kind=="eye":
            star_s=f"her eyes are the star of her face (the shape, size and lenses described here override the eyes of her makeup, while the colours of her eyeshadow and liner follow her makeup): {text.format(lens='coloured') if '{lens}' in text else text}"
        else:
            star_s=f"her lips are the star of her face (the shape, size and projection described here override the lips of her makeup, while the lip colour and finish follow her makeup and ignore any lip colour named here): {text}"
        nz=nose if name!="애니 돌 아이 실사형" else NOSES[0]
        add=f" Her face has been surgically sculpted far beyond her natural look, and these changes override her natural features: {star_s}. Every feature is exaggerated but beautiful, balanced and refined, in harmony with the rest of her face, never distorted, never grotesque."
        sj2=sj+add; mk=("메이크업 "+(meta.get("makeup_label") or "없음")) if style!="NONE" else "메이크업 없음"
    sj2=re.sub(r"^Subject: A real photograph of an? ","A ",sj2); assert not sj2.startswith("Subject")
    lab=f"{nat} · {grp} · {expr} · {name} · {mk} · "+("귀만 피어싱")+f" · 귀 추 {nw}개/귀 2구멍"+(" · 헤나" if "Henna" in deco else "")+(" · 스티커" if "Stickers" in deco else "")
    if kind!="arch" and meta.get("lens"): lab+=" · 렌즈 "+meta["lens"]
    return sj2,new,lab
def group(seed,spec,mode="front"):
    rr=random.Random(seed); n=len(spec); nw=6 if n==2 else 4
    nats=rr.sample(list(G.NATS),n); subs=[];prs=[];labs=[];tmp=None
    for (kind,name),nat in zip(spec,nats):
        for tr in range(40):
            try:
                s,p,l=person(random.Random(rr.randrange(10**9)),nat,kind,name,nw)
            except AssertionError: continue
            if re.search(r"[가-힣]",s+p) or "{" in s+p: continue
            break
        else: raise SystemExit(("fail",name))
        if mode=="front": s=s.replace("in this three-quarter view","in this frontal view")
        subs.append(s);prs.append(p);labs.append(l)
    cnt={2:"TWO",3:"THREE"}[n]; tw={2:"both",3:"all three"}[n]
    if mode=="front":
        hd=f"Professional fashion photograph, close-up beauty portrait. {cnt} women side by side, each facing the camera straight on in a perfectly frontal portrait, heads level, both ears of every woman clearly visible on either side of her face, framed tightly from the very top of their heads down to the line of their shoulders, the frame cutting off just below them, so the weights fully hang in view. Every face is large and sharp."
        lit="A soft frontal light on all the faces and ears, so the makeup and the glints on every piece of metal read clearly"
    else:
        hd=f"Professional fashion photograph, close-up beauty portrait. {cnt} women side by side, {tw} with their heads turned about forty-five degrees to their left in a three-quarter view, their eyes still looking straight into the camera, one ear and the turned cheek of every woman clearly visible, and from this angle the full projection of every woman's lips from her face is clearly visible, framed tightly from the very top of their heads down to the line of their shoulders, the frame cutting off just below them, so the weights fully hang in view. Every face is large and sharp."
        lit="A soft key light from the front and slightly to the side on all the faces, so the makeup and the glints on every piece of metal read clearly"
    pw=" ".join(["#%d: %s"%(i+1,s) if False else "" for i,s in enumerate(subs)])
    body=[]
    for i,(s,p) in enumerate(zip(subs,prs),1):
        body.append(f"#{i}: {s}")
        body.append(f"#{i} {p}")
    share_w=HW2.format(col=COL2[nw])
    share_w=share_w.replace("On each ear the two iron rings each carry","On each ear of every woman the two iron rings each carry")
    for a,b in [("hanging side by side on chains of different lengths","hanging side by side, each weight on its own thick chain of heavy black iron links, the chains of different lengths"),("reaching down along her neck to her collarbones","reaching down along the neck to the collarbones"),("hangs just past her jaw; the lobe does not sag, droop, collapse or hang down to her shoulder, her head stays upright, and","hangs just past the jaw; no lobe sags, droops, collapses or hangs down to the shoulder, every head stays upright, and")]:
        assert a in share_w,a; share_w=share_w.replace(a,b)
    ratio={2:"4:3 horizontal",3:"3:2 horizontal"}[n]
    dep=open(OUT+'LumineX_FaceSculpt_Sample_6.md',encoding='utf-8').read()
    depth="Piercing depth: every bar is embedded in the skin so only its two end studs show on the surface; every ring passes through a small healed opening in the skin, the skin visible through the loop, and every stud sits through the skin with its back hidden, all of them passing through the real tissue with the skin wrapping snugly around them."
    parts=[hd]+body+["Ear weights: "+share_w,
      "All piercings: Only the ears of every woman are pierced, and nowhere else on any face: no lips, nose, eyebrows, chin, forehead, temples or cheeks carry any piercing at all, so every lip, nose and eye stays completely clear and unobstructed. All jewelry is real metal, sitting in real, calm, healthy skin — no redness, no swelling, no irritation — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes.",
      depth,
      "Hair: every woman's hair is swept back behind both ears, leaving both ears, jawlines and necks fully visible so every hanging piece is in clear view.",
      "Pose: each woman stands upright, arms relaxed at her sides, heads level, shoulder to shoulder with a small gap between neighbours, so that the weights of one never hang in front of another. Generous spacing so every face reads clearly.",
      f"Lighting: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. {lit}; a thin cool rim light along the hair and shoulders. {ratio} 8K."]
    t="\n\n".join(parts); t=re.sub(r"catching the light\s+Her face","catching the light. Her face",t)
    assert not re.search(r"[가-힣]",t) and "{" not in t
    d=re.search(r"\b(\w+) \1\b",t);
    return t,labs,(d.group(0) if d else None)
CFG=[
 ("듀오",101,[("eye","사이렌 눈 +1"),("eye","애교살 초극대")],"front"),
 ("듀오",102,[("lip","러시안 립 초과장"),("eye","후디드 아이 +1")],"front"),
 ("듀오",103,[("arch","바비 인형(금발)"),("arch","서큐버스")],"front"),
 ("트리오",104,[("eye","도 아이 +1"),("lip","러시안 립 극한"),("arch","브랫츠 돌")],"front"),
 ("트리오",105,[("eye","옆트임 최극한(4배)"),("eye","애교살 초극대"),("eye","양쪽 트임 8배+거대한 눈")],"front"),
 ("트리오",106,[("lip","러시안 립 과장"),("lip","체리 립"),("lip","키홀 퓨트 +1")],"q45"),
]
o=["# LumineX — Face Sculpt 듀오·트리오 확인 샘플 6개 (듀오 3 · 트리오 3)\n",
"- 구성: 인물마다 얼굴 특징 주인공 1개씩, 피어싱은 전원 귀만(눈·입·코 주변 피어싱 없음), 귀 추는 듀오 6개/귀(3+3)·트리오 4개/귀(2+2), 엄니 제외, 단일 컷보다 문단을 줄여 듀오 약 1,500~1,800단어·트리오 약 2,200~2,500단어입니다(트리오는 이전 통과 한도 1,920보다 깁니다).",
"- 1~5는 정면, 6은 인물 전원 45도(립 3종). 정상/이상 번호만 알려주세요.\n"]
for i,(nm,seed,spec,mode) in enumerate(CFG,1):
    for tr in range(30):
        t,labs,dup=group(seed*100+tr,spec,mode)
        if dup and dup.split()[0].lower() not in ("had","that"): continue
        break
    names=" + ".join(n for k,n in spec)
    o.append(f"## {i}. {nm} · {names}"+(" (45도)" if mode!="front" else " (정면)"))
    for j,l in enumerate(labs,1): o.append(f"- #{j}: {l}")
    o.append("\n```\n"+t+"\n```\n")
    print(i,nm,len(t.split()),dup)
open(OUT+'LumineX_FaceSculpt_DuoTrio_Sample_6.md','w',encoding='utf-8').write("\n".join(o))
