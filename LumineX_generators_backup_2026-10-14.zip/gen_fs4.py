import re,random,json,collections,sys
g=open('gen_fs2.py',encoding='utf-8').read()
exec(g[:g.index('if __name__=="__main__":')])
m=open('mk_group4.py',encoding='utf-8').read()
exec(m[m.index('END="'):m.index('TEXT.update')])
cnt_old={"러시안 립 과장":6,"러시안 립 초과장":6,"러시안 립 초과장+1":6,"러시안 립 판타지 한계":6,"러시안 립 초초과장":6,"러시안 립 극한":6,"체리 립":8,"키홀 퓨트 +1":8,"큐피드 보우":6,"립 플립":5,"립 리프트":5}
cnt_new={"덕 립 극한":9,"드롭 립 극한":9,"바르도 립 극한":9,"와이드 립 극한":9,"오 립 극한":8,"고양이 입 극한":8}
LIP3=[(n,t,cnt_old[n]) for n,t,c in LIP]+[(n,NEWLIP[n],c) for n,c in cnt_new.items()]
assert sum(c for n,t,c in LIP3)==120
rr=random.Random(20261014)
TAILO="Real skin fine grain and a soft sheen of natural oils on her face, ears and neck, individual hair strands catching the light"
TAILN="Her whole face, ears and neck are real living flesh with real pores and fine skin grain and a soft sheen of natural oils, individual hair strands catching the light"
SW=[("A strikingly beautiful, seductive adult woman","A striking, seductive adult woman"),("A strikingly beautiful adult Western woman","A striking adult Western woman"),("A strikingly beautiful adult woman","A striking adult woman"),
("with the glamorous Y2K 'Bratz doll' face brought to life: warm golden-tan skin with a high-gloss, airbrushed, glossy finish and","with the glamorous Y2K 'Bratz' glam look: warm golden-tan skin with real visible pores and"),
("with the face of a living Barbie doll pushed to its extreme — flawless, poreless porcelain-smooth skin with","with a Barbie-pink glam look pushed to its extreme — fair skin with real visible pores and"),
("extra-large doll eyes","extra-large eyes"),("doll-eye contact lenses","big-iris contact lenses"),
("; it reads as the most perfect, most doll-like adult woman's face imaginable","."),
("smooth, flawless, pale skin with","pale skin with real visible pores and"),("in luminous blood-red","in blood-red"),
("dewy, wet-looking, glowing skin as if","dewy skin with real visible pores as if"),("in luminous violet","in violet"),("luminous ",""),
(TAILO,TAILN),("a photograph of a real woman, not","a photograph of a real woman's face, not")]

jobs=[]
for name,text,c in EYE2: jobs+=[("eye",name,text)]*c
for name,text,c in LIP3: jobs+=[("lip",name,text)]*c
for name,fn,c in ARCH: jobs+=[("arch",name,fn)]*c
print(len(jobs))
tusk_flag=False
out=[]
for i,(kind,name,text) in enumerate(jobs,1):
    it=build2(i,kind,name,text,rr)
    if kind=='arch':
        for a,b in SW: it['prompt']=it['prompt'].replace(a,b)
        it['prompt']=it['prompt'].replace('..','.')
    out.append(it)
json.dump(out,open(OUT+'la_facesculpt_300_bundle_v3cand.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
print(collections.Counter(x["meta"]["star"] for x in out if x["meta"]["kind"]=="lip"))
print(collections.Counter(x["meta"]["piercing"] for x in out))
print(collections.Counter(len(x["meta"]["addons"]) for x in out))
print(collections.Counter(x["meta"]["ear_mode"] for x in out), collections.Counter(x["meta"]["ear_holes"] for x in out))
w=[len(x["prompt"].split()) for x in out]; print(min(w),max(w),sum(w)/len(w))
ks=[x["key"] for x in out]; print(len(set(ks)),ks[0],ks[-1])
print("korean",sum(1 for x in out if re.search(r"[가-힣]",x["prompt"])), "tusk",sum(1 for x in out if x["meta"]["tusk"]))
