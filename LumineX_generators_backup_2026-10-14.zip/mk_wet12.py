# -*- coding: utf-8 -*-
# 신규 영역 4종 샘플(각 2개): 우주·성운 / 용암·마그마 / 털실·펠트 / 수묵·서예 — mk_new_bundles 틀, 전 축 기본 랜덤
_src = open("mk_new_bundles.py", encoding="utf-8").read()
exec(_src[:_src.index('if __name__')])
LEAD = "body curving to follow her body's true three-dimensional shape, "
T_WET = LEAD + "a continuous glossy wet-look coating over her entire body, thick sheets and streams of liquid running down every curve in glistening rivulets, countless beads and droplets clinging to the surface and dripping from her chin, fingertips, hips and knees, razor-sharp bright specular highlights along every curve, nothing lying flat. Dense wet surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
def V(tag, desc, solid, nmw, T, base, acc, fin): return dict(tag=tag, desc=desc, solid=solid, nmw=nmw, T=T, base=base, acc=acc, fin=fin)
VS = [
 V("젖은 광택 · 브론즈 오일", "oil-drenched glistening bronze", "wet-look", "glistening wet bronze", T_WET,
   "BLAZING deep metallic bronze-gold pigment across the full torso both legs neck to ankle, drenched in thick clear body oil",
   "VIVID golden oil streaming in long slow rivulets and heavy oil droplets hanging from every curve", "mirror-wet glossy"),
 V("젖은 광택 · 샤워 크림슨", "shower-drenched glistening crimson", "wet-look", "glistening wet crimson", T_WET,
   "BLAZING saturated crimson-red pigment across the full torso both legs neck to ankle, soaked under a running shower",
   "VIVID streams of clear water cascading from above in sheets and bright round water beads clinging everywhere, with a fine mist of spray in the air", "mirror-wet glossy"),
 V("젖은 광택 · 빗속 블랙", "rain-drenched glistening jet-black", "wet-look", "glistening wet black", T_WET,
   "BLAZING deep jet-black pigment across the full torso both legs neck to ankle, soaked by pouring rain",
   "VIVID silver rain streaking down in bright lines, white highlights glittering on every water bead and rivulet, and splashes bursting around her feet", "mirror-wet glossy"),
]
def chk(t): return not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t) and "navel" not in t.lower()
import sys
sys.path.insert(0, "../master")
import mdefs as D
_g = open("../master/gen_extreme.py", encoding="utf-8").read()
exec(_g[_g.index("B_INS = ("):_g.index("PAINT_S")])
_SEATS = _g[_g.index("SEAT = ["):_g.index("for _p in SEAT")]
exec(_SEATS)
def _bod(i, ext):
    n, d = D.BODIES[i][0], D.BODIES[i][1]
    return (n, d + "; " + B_INS.format(edge=", her body so wide that her hips nearly touch the left and right edges of the frame")) if ext else (n, d)
PHYS3 = [_bod(9, False), _bod(15, False), _bod(10, False), _bod(12, True), _bod(2, False)]
VD = [
 V("1 샴페인 스프레이 · 버건디", "champagne-drenched glistening burgundy", "wet-look", "glistening wet burgundy", T_WET,
   "BLAZING deep burgundy-wine pigment across the full torso both legs neck to ankle, drenched in fizzing champagne",
   "VIVID golden champagne spraying in a fizzing arc over her and streaming down her body in sparkling rivulets, tiny bubbles and foam bursting on the surface and droplets sparkling in the air", "mirror-wet glossy"),
 V("2 안개·이슬 · 에메랄드", "mist-and-dew-covered glistening deep emerald", "wet-look", "glistening wet emerald", T_WET,
   "BLAZING deep emerald-green pigment across the full torso both legs neck to ankle, beaded with cool morning dew",
   "VIVID a fine cool mist drifting around her, countless tiny dew droplets beading across every surface and catching the light, and a few heavy drops sliding down in thin trails", "dewy glossy"),
 V("3 얼음 녹은 물 · 코발트", "ice-meltwater-drenched glistening cobalt", "wet-look", "glistening wet cobalt", T_WET,
   "BLAZING cobalt-blue pigment across the full torso both legs neck to ankle, streaming with ice-cold meltwater",
   "VIVID ice-cold meltwater running down in clear streams, tiny ice chips and crystals clinging to the surface, frost glittering at the edges and a cold mist rising around her", "mirror-wet glossy"),
 V("4 우유 · 블랙", "milk-drenched glistening jet-black", "wet-look", "glistening wet black", T_WET,
   "BLAZING deep jet-black pigment across the full torso both legs neck to ankle, poured over with thick creamy milk",
   "VIVID thick creamy white milk pouring over her in glossy ribbons, streaming down every curve in smooth sheets and pooling in white puddles around her feet", "creamy glossy"),
 V("5 꿀 · 미드나이트 블루", "honey-drenched glistening midnight-blue", "wet-look", "glistening wet navy", T_WET,
   "BLAZING deep midnight-blue pigment across the full torso both legs neck to ankle, poured over with thick golden honey",
   "VIVID thick golden honey pouring over her in slow glossy strands, streaming down every curve and pooling in golden puddles around her feet", "sticky glossy"),
]
G0 = face.__globals__["G"]; _orig_pm = G0.pick_makeup
import mk_newmakeup as NM
NM.extend(G0)
VARS = [
 V("젖은 광택 · 이레즈미 잉어 폭포 · 샤워", "shower-drenched glistening koi waterfall irezumi", "wet-look", "glistening wet inked", T_WET,
   "bold black ink outlines — BLAZING DEEP CRIMSON koi formations ascending the full torso both legs neck to ankle, VIVID SILVER water-spray detail filling every gap, soaked under a running shower",
   VS[1]["acc"], "mirror-wet glossy"),
 V("젖은 광택 · UV네온 해파리 · 빗속", "rain-drenched glistening jellyfish UV neon bodypaint", "wet-look", "glistening wet neon", T_WET,
   "BLAZING ELECTRIC CYAN jellyfish-bell formations across the full torso both legs neck to ankle, VIVID MAGENTA tentacle-trail detail filling every gap, soaked by pouring rain",
   VS[2]["acc"], "mirror-wet glossy"),
 V("젖은 광택 · 모로칸 젤리주 타일 · 오일", "oil-drenched glistening Moroccan zellige tile bodypaint", "wet-look", "glistening wet glazed", T_WET,
   "Moroccan zellige tile mosaic — a deep cobalt ground with interlocking white, terracotta and gold motifs, wide gold bands following every deep crease, dense interlocking star-and-cross motifs filling the space between bands, covering her whole body below the jaw, drenched in thick clear body oil",
   VS[0]["acc"], "mirror-wet glossy"),
]
NSTY = ["x", "y", "z"]
ALLOWED = [['강남언니', '인스타글램', '홍콩풍', '구풍'], ['걸크러시', '코갸루', '글래스 스킨', '만바'], ['오네에갸루', '웨이쉰', '강남언니', '인스타글램', '구풍']]
rg = random.Random(20261127); rr.seed(20261127); ns2["JR"].seed(20261127)
o1 = ["# 젖은 광택(wet-look) × 다른 바디페인팅 3종 — 이레즈미 · UV네온 · 전통 공예 타일\n", "Material Mix와 같은 기본 랜덤입니다(체형·나이·포즈·인종·배경·힐·네일·주얼리). 번호별로 정상/이상만 알려주세요. 이상이면 한 줄만요.\n"]
for i, v in enumerate(VARS, 1):
    for _ in range(500):
        phys = rg.choice(PHYS3); age = rg.choice(AGES); pose = rg.choice(SEAT) if (phys[0] in ('USSBBW', 'hourglass SSBBW') and rg.random() < 0.7) else rg.choice(POSES); eth = rg.sample(ETH, 1)[0]
        bid, wx = BGL.pick(rg, 1)
        OKB = None
        while (OKB and BGL.BG[bid][2] not in OKB) or (i == 2 and (not BGL.BG[bid][4] or BGL.BG[bid][2] in ('겨울 눈 광장', '겨울 설원', '얼음 동굴'))): bid, wx = BGL.pick(rg, 1)
        scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
        ns2["JR"].seed(rg.randrange(10**9))
        mat = HEAD.format(desc=v["desc"], solid=v["solid"]) + v["T"].format(base=v["base"], acc=v["acc"], fin=v["fin"])
        G0.pick_makeup = (lambda _r, style=None, _a=ALLOWED[i - 1]: _orig_pm(_r, style=_r.choice(_a)))
        body, info = assemble(mat, v["nmw"], "part of the figure", phys, age, pose, eth)
        env = f"{scene}, bright and evenly lit, shadows soft, the whole floor and surroundings clearly visible and in focus, NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as her."
        tail = f"Background: {env} ONE woman only. Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
        t = f"Professional fashion photograph, full body shot. ONE woman standing.\n\n{body}\n\n{tail}{CAM} 8K portrait {ASP[1]} aspect ratio."
        if chk(t): break
    hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
    o1.append(f"## {i}. {v['tag']} 솔로 · 체형 {phys[0]} · 인종 {eth[0]} · {info} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko}\n\n```\n{t}\n```\n")
    print(i, len(t.split()), t.count("forty inches"))
open(O + "LumineX_WetLook_Paint3.md", "w", encoding="utf-8").write("\n".join(o1))
