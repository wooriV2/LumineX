# -*- coding: utf-8 -*-
"""수조 5인 시험(짧은 방식): B 프레임 힙컷 2개 + A 듀얼바디 전신 1개. 수위 100/50/25/0 + 1명 추가(100/50/25 중 랜덤), 내용물 5종 서로 다르게."""
import sys, re, os
sys.argv = ['x']
import gen_trio_mix2 as G
import gen_trio_mix as T, mdefs as D
import gen_hipframe_tank2 as G2
H = G2.H; rr = T.rr; rr.seed(int(os.environ.get('SEED', '8484')))
G.SHORTMODE = True; G2.SHORT = True
KO = {"full": "가득", "p50": "50%", "p25": "25%", "empty": "비움"}
THIN = ["a few very thin, hairline black vertical lines, widely spaced about a hand's width apart, never thick, never bold, never dense",
        "a few very thin, hairline black horizontal lines, widely spaced about a hand's width apart, never thick, never bold, never dense",
        "a sparse grid of very thin hairline black lines in large squares, widely spaced, never thick, never bold, never dense"]
NOTE = "Every woman below is built exactly like #1 in everything not restated for her (same vessel construction, glass finish, boundary line, water behaviour, physique and pose); only her water level, water colour, contents and glass tint differ."
KEEP = ("continuous hollow", "seals shut", "directly on the floor", "flat, deliberately cut cross-section")
def dedupe(t):
    seen = set(); out = []
    for ln in t.split("\n"):
        parts = re.split(r"(?<=\.) ", ln); keep = []
        for p in parts:
            key = re.sub(r"^#\d+:? ", "", p).strip()
            if len(key) > 90 and key in seen and not any(k in key for k in KEEP): continue
            if len(key) > 90: seen.add(key)
            keep.append(p)
        out.append(" ".join(keep))
    return re.sub(r"\n{3,}", "\n\n", "\n".join(out))
G.ARMPIT = True; G.DBTYPE = 'tank'; G.DBFILL = None
G.HAIRNOTE = "Any hair hanging behind a body is plainly visible through the empty glass, and the few thin lines of the wall bend slightly as they are seen through the thin glass of every body."
indoor = [k for k, v in D.BGL.BG.items() if not v[4]][:1]
res = []
for kind, n in (("B", 2), ("B", 3), ("A", 2), ("A", 3)):
    w = list(H.WORLDS); rr.shuffle(w); w = w[:n]; ti = rr.sample(H.TINTS, n)
    if kind == "B":
        p = [100, 0] if n == 2 else [100, 50, 0]; rr.shuffle(p); wcn = rr.sample(G2.WATERC, n)
        t0, key, back = G2.make(n, p, w, [x[0] for x in ti], wcn)
        t = dedupe(t0)
        if n == 3: t = t.replace("\n\n#1:", "\n\n" + NOTE + "\n\n#1:", 1)
        lab = ", ".join(f"#{i+1} {pp}%" + (f"({H.WORLDS[x][0]}, {c} 물)" if pp else "(내용물 없음)") + f" · 유리 {tt[1]}" for i, (pp, x, tt, c) in enumerate(zip(p, w, ti, wcn)))
    else:
        fl = ["full", "empty"] if n == 2 else ["full", "p50", "empty"]; rr.shuffle(fl); wc = rr.sample(list(T.WATERS), n)
        G.SCENE_OVERRIDE = "a bright studio with a huge plain white backdrop wall marked with " + rr.choice(THIN) + ", and a pale polished floor"
        G.DBFILLS[:] = fl; G.DBTIERS[:] = [("L3", "L3")] * n; G.DBWATERS[:] = wc; G.DBTINTS[:] = [x[0] for x in ti]; G.DBWORLDS[:] = w; G.USED_MATS.clear(); G.URKINDS[:] = []
        t0, _ = G.build(["db"] * n, None, "demi", ("L3", "L3"), wc[0], indoor[0])
        t = dedupe(t0)
        if n == 3 and "\n\n#1:" in t: t = t.replace("\n\n#1:", "\n\n" + NOTE + "\n\n#1:", 1)
        lab = ", ".join(f"#{i+1} {KO[f]}" + (f"({H.WORLDS[x][0]}, {c} 물)" if f != "empty" else "(내용물 없음)") + f" · 유리 {tt[1]}" for i, (f, x, tt, c) in enumerate(zip(fl, w, ti, wc)))
    print(kind, n, len(t0.split()), "->", len(t.split()))
    res.append((kind, n, t, lab))
L = ["# LumineX — 등록 전 확인 시험: 수조 2·3인 짧은 버전 (프레임 힙컷 2개 + 듀얼바디 전신 2개, 세로 4:5)\n",
     "- 1번 = 프레임 힙컷 2인(100/0), 2번 = 프레임 힙컷 3인(100/50/0), 3번 = 듀얼바디 전신 2인(가득/비움), 4번 = 듀얼바디 전신 3인(가득/50%/비움).",
     "- 4·5인에서 성공한 짧은 방식 그대로입니다. 정상/이상만 번호로 알려주세요.\n"]
for i, (kind, n, t, lab) in enumerate(res, 1):
    L.append(f"## {i}번 — {'프레임 힙컷' if kind == 'B' else '듀얼바디 전신'} {n}인\n\n구성: {lab}\n\n```\n{t}\n```\n")
open('/mnt/user-data/outputs/LumineX_TankFill_Check_2_3.md', 'w', encoding='utf-8').write("\n".join(L))
