# -*- coding: utf-8 -*-
# 목재·석재 단독 포뮬러 600: 목재 300 + 석재 300, 각 소재 솔로·듀오·트리오·4인·5인 60개. 부피 큰 체형, 얼굴 문장 없음.
import re, json, random, collections
O = "/mnt/user-data/outputs/"
s = open("gen_woodstone_groups6.py", encoding="utf-8").read(); ns = {}
exec(s[:s.index("NUM = {")], ns)
HAIRS, POSES, AGES, check, BIG = ns["HAIRS"], ns["POSES"], ns["AGES"], ns["check"], ns["BIG"]
PH0 = ns["PH0"]
BIG = BIG + [PH0[6]]  # hourglass bombshell 추가 (5인 중복 방지)
WOODS = ns["WOODS"] + [
 ("koa", "golden-brown koa", "BLAZING golden-brown koa grain across the full torso both legs neck to ankle", "VIVID dark curly figure running between the carved sections"),
 ("bocote", "golden bocote", "BLAZING golden bocote grain across the full torso both legs neck to ankle", "VIVID dark brown swirling lines running between the carved sections"),
 ("cocobolo", "orange-red cocobolo", "BLAZING orange-red cocobolo grain across the full torso both legs neck to ankle", "VIVID black streaks running between the carved sections"),
 ("macassar ebony", "striped macassar ebony", "BLAZING glossy black-and-brown striped macassar ebony grain across the full torso both legs neck to ankle", "VIVID golden-tan stripes running between the carved sections"),
 ("lacewood", "silvery-gold lacewood", "BLAZING silvery-gold lacewood grain across the full torso both legs neck to ankle", "VIVID copper flecks running between the carved sections"),
 ("birdseye maple", "pale golden birdseye maple", "BLAZING pale golden birdseye maple grain across the full torso both legs neck to ankle", "VIVID tiny dark eye-like dots dotting the carved sections"),
 ("African blackwood", "jet-black African blackwood", "BLAZING deep jet-black African blackwood grain across the full torso both legs neck to ankle", "VIVID faint dark-brown lines running between the carved sections"),
 ("teak", "warm golden teak", "BLAZING warm golden-brown teak grain across the full torso both legs neck to ankle", "VIVID dark amber streaks running between the carved sections")]
STONES = ns["STONES"] + [
 ("agate", "polished banded agate", "BLAZING warm caramel and white banded agate surface across the full torso both legs neck to ankle", "VIVID concentric rust-red bands flowing through every section"),
 ("travertine", "polished travertine", "BLAZING warm cream travertine surface across the full torso both legs neck to ankle", "VIVID tan and brown horizontal banding flowing through every section"),
 ("moonstone", "polished moonstone", "BLAZING milky pearl-white moonstone surface across the full torso both legs neck to ankle", "VIVID blue adularescent shimmer flowing through every section"),
 ("azurite", "polished azurite", "BLAZING deep midnight-blue azurite surface across the full torso both legs neck to ankle", "VIVID green malachite swirls flowing through every section"),
 ("unakite", "polished unakite", "BLAZING olive-green unakite surface across the full torso both legs neck to ankle", "VIVID salmon-pink speckles flowing through every section"),
 ("rhodochrosite", "polished rhodochrosite", "BLAZING rose-pink rhodochrosite surface across the full torso both legs neck to ankle", "VIVID white concentric banding flowing through every section"),
 ("chrysoprase", "polished chrysoprase", "BLAZING apple-green chrysoprase surface across the full torso both legs neck to ankle", "VIVID pale mint veins flowing through every section"),
 ("larimar", "polished larimar", "BLAZING aqua-blue larimar surface across the full torso both legs neck to ankle", "VIVID white cloud-like veins flowing through every section")]
SETS = ["a bright white-walled modern gallery hall with a polished pale floor and a full-height doorway standing open beside her, flooded with soft natural daylight from tall windows",
        "a sunlit open-air stone terrace at midday with a pale paved floor, a waist-high balustrade, potted palms and a full-height wooden door behind her, bright blue sky overhead",
        "a bright airy glass-roofed atrium with a pale polished floor, a wide staircase with standard-height steps and tall potted trees, filled with soft white daylight",
        "a sunny seaside promenade of pale paving stones with a waist-high white railing, a lamp post and a row of normal-height park benches, bright blue sky and soft sea light",
        "a sunlit white-washed courtyard with a pale tiled floor, an arched doorway at normal height, low stone steps and a tall olive tree, bright midday light",
        "a bright minimalist loft studio with pale concrete floors, tall factory windows, a standard door and a row of normal chairs, soft daylight from one side",
        "a sunny city plaza of light paving with a low fountain edge, a street lamp and standard-height shop doors behind her, clear daylight sky",
        "a bright grand hall with a pale marble floor, tall columns, standard-height arched doors and soft golden daylight through high windows"]
SETKO = ["갤러리", "야외 테라스", "아트리움", "바닷가 산책로", "하얀 안뜰", "미니멀 로프트", "도시 광장", "대리석 홀"]
NUM = {1: "ONE", 2: "TWO", 3: "THREE", 4: "FOUR", 5: "FIVE"}; ASP = {1: "2:3", 2: "3:4", 3: "4:5", 4: "4:5", 5: "5:4"}
TYPEN = {1: "solo", 2: "duo", 3: "trio", 4: "quartet", 5: "quintet"}; TKO = {1: "솔로", 2: "듀오", 3: "트리오", 4: "4인", 5: "5인"}
HEELT = ["thirty inches", "thirty-two inches", "thirty-six inches", "forty inches"]
BODYLIFT = "her feet arched fully vertical on the very tips of her toes like a dancer on pointe, her legs stretched impossibly long and her whole body lifted far above the ground on them as if standing on stilts"
def person(kind, pick, label, phys, age, hair, pose, heel, rr):
    nm, desc, base, acc = pick; phy_name, phy_detail = phys
    nmw = nm if (kind == "wood" and nm.endswith("wood")) or kind == "stone" else nm + " wood"
    if kind == "wood":
        dw = desc if desc.endswith("wood") else desc + " wood"
        mat = (f"full body {dw} carved directly over her own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not a printed pattern, this is solid carved wood curving to follow her body's true three-dimensional shape, divided into dozens of fitted carved sections whose grain changes direction from one section to the next, each joint standing in a thin raised ridge catching its own soft glint and casting its own small shadow, nothing lying flat. Dense fitted sections — {base}, {acc}, polished to a warm satin sheen, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
        nails = f"extra long nails in matching polished {nmw}"
    else:
        mat = (f"full body {desc} fused directly to her own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, this is solid stone curving to follow her body's true three-dimensional shape, divided into dozens of fitted stone sections, each joint standing in a thin raised ridge catching its own bright glint and casting its own small shadow, nothing lying flat. Dense fitted sections — {base}, {acc}, high-gloss polished, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
        nails = f"extra long nails in matching polished {nm}"
    p = f"{label}: " if label else ""
    if heel:
        shoe = f"heels of the most absurdly extreme height imaginable, thigh-high platform stiletto boots carved from the same {nmw}, each with a razor-thin tapered heel a full {rr.choice(HEELT)} tall and a twelve-inch hidden front platform, {BODYLIFT}, {nails}."
    else:
        shoe = f"extreme platform boots carved from the same {nmw}, {nails}."
    return (f"{p}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {hair} — {mat}. Pose: {pose} — most extreme {phy_name} silhouette ever displayed.\n{p}{shoe}")
BGX = "MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient."
CAM = " Full-length wide shot from a moderate distance with the camera at waist height, the whole figure from the soles of the boots to the top of her head completely visible, with the door, railing or steps beside her at normal human scale so the extreme heel height reads at a glance, the towering heels clearly separating the boot soles from the floor."
def build(kind, picks, physs, ages, hairs, poses, heel, bright, rr):
    n = len(picks); labels = [f"#{i+1}" for i in range(n)] if n > 1 else [None]
    body = "\n\n".join(person(kind, picks[i], labels[i], physs[i], ages[i], hairs[i], poses[i], heel, rr) for i in range(n))
    envtxt = f"Environment: {bright}, bright and evenly lit, shadows soft, the whole floor and surroundings clearly visible and in focus, NO dark background NO black void." if bright else None
    if n == 1:
        tail = (envtxt.replace("Environment: ", "Background: ") + " ONE woman only. Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle.") if bright else f"{BGX} ONE woman only. Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
    else:
        env = envtxt if bright else f"Environment: {BGX}"
        tail = f"{env}\nAll: Extreme macro detail on every surface texture and shadow. CRITICAL: all {n} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere, every element standing in true relief, nothing flat. {NUM[n]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame."
    if heel and bright: tail += CAM
    elif heel: tail += " Very low camera angle with the full length of every boot visible down to the floor, the towering heel height dominating the silhouette and lifting her far above the floor."
    return f"""Professional fashion photograph, full body shot. {NUM[n]} wom{"a" if n == 1 else "e"}n standing{" side by side" if n > 1 else ""}.

{body}

{tail} 8K portrait {ASP[n]} aspect ratio."""
rr = random.Random(20261009)
out = []; seen = set(); sc = collections.Counter()
for kind, pool, cat, kname in [("wood", WOODS, "🏺 Living Artifact · Wood Formula", "목재"), ("stone", STONES, "🏺 Living Artifact · Stone Formula", "석재")]:
    use = collections.Counter()
    for n in range(1, 6):
        for k in range(1, 61):
            for attempt in range(50):
                picks = rr.sample(pool, n) if n <= len(pool) else None
                picks = sorted(picks, key=lambda x: use[x[0]])[:0] or picks
                physs = rr.sample(BIG, n) if n <= len(BIG) else [rr.choice(BIG) for _ in range(n)]
                ages = [rr.choice(AGES) for _ in range(n)]; hairs = rr.sample(HAIRS, n); poses = [rr.choice(POSES) for _ in range(n)]
                heel = rr.random() < 0.35; bright = rr.choice(range(8)) if rr.random() < 0.5 else None
                t = build(kind, picks, physs, ages, hairs, poses, heel, SETS[bright] if bright is not None else None, rr)
                chk = t
                try: check(f"{kind}{n}_{k}", chk)
                except AssertionError: continue
                if re.search(r"\b(\w+) \1\b", t) or t in seen: continue
                break
            else: raise SystemExit("fail")
            seen.add(t)
            for p_ in picks: use[p_[0]] += 1
            sc[(kind, n, heel, bright is not None)] += 1
            bgko = SETKO[bright] if bright is not None else "검정 배경"
            pnames = " / ".join(p_[0] for p_ in picks); pb = ", ".join(x[0] for x in physs)
            key = f"la_{kind}_{TYPEN[n]}_{k:02d}"
            out.append({"key": key, "category": cat, "title": f"{kind.capitalize()} {TYPEN[n].capitalize()} #{k:02d} ({kname} {TKO[n]} · {pnames} · 체형 {pb} · 배경 {bgko}{' · 극단 힐' if heel else ''})",
                        "prompt": t, "meta": {"group_size": n, "aspect_ratio": ASP[n], "format": "woodstone", "material": kind, "species": [x[0] for x in picks], "physiques": [x[0] for x in physs], "background": bgko, "extreme_heel": heel}})
assert len(out) == 600 and len({p["key"] for p in out}) == 600
for p in out: assert not re.search(r"[가-힣]", p["prompt"])
json.dump(out, open(O + "la_woodstone_600_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(out), collections.Counter(p["meta"]["group_size"] for p in out), "heel", sum(p["meta"]["extreme_heel"] for p in out), "bright", sum(p["meta"]["background"] != "검정 배경" for p in out))
print(collections.Counter(x for p in out for x in p["meta"]["species"]).most_common(4), len(collections.Counter(x for p in out for x in p["meta"]["species"])))
print("len", min(len(p["prompt"].split()) for p in out), max(len(p["prompt"].split()) for p in out))
