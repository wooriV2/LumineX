# -*- coding: utf-8 -*-
import re
P1 = re.compile(r"The boundaries between regions are hazy and feathered — there is no visible line at all\. Each transition zone is about a hand's width wide, and across it the neighbouring (?P<n>patterns|materials|leaf colours) dissolve into each other, (?P<e>motifs|elements|flakes) from one thinning out as (?P=e) from the other appear, density fading rather than stopping abruptly, never a hard edge\.")
# Structure Pack '큰 조각' 구조의 경계 문장
P3 = re.compile(r"The patch edges are hazy and feathered — there is no visible outline at all\. Around each patch, a transition zone about a hand's width wide lets the patch's material and the background material dissolve into each other, elements from one thinning out as elements from the other appear, density fading rather than stopping abruptly, never a hard edge\.")
P2 = re.compile(r" Even inside a transition zone the skin is never left bare: at every point one (?:pattern|material|colour), or a mixture of the two, fully covers it\.?")
NEW3 = ("Where a patch meets the background, the two materials interlock naturally: elements of one reach into the other and the two materials simply touch, "
        "so the edge of every patch is made only of the patch's material and the background material, each in its own colours, with no gap between them.")
def _new(m):
    n, e = m.group("n"), m.group("e")
    u = {"patterns": "patterns", "materials": "materials", "leaf colours": "colours"}[n]
    tail = "each in its own colours, with no gap between them" if n != "leaf colours" else "with no gap between them"
    return f"Where two regions meet, the {n} interlock naturally: {e} of one reach into the other and the two {u} simply touch, so the boundary is made only of the two neighbouring {u}, {tail}."
def _dups(t): return len(re.findall(r"\b(\w+) \1\b", t))
def interlock(t):
    """흐릿한 전환 구역 문장 → 맞물림 경계 문장(변형 C). 보호 문장 삭제. 바꿀 것이 없으면 None."""
    n0 = t.count("hazy and feathered")
    if n0 == 0: return None
    d0, c0 = _dups(t), t.count(".,")
    t, a = P1.subn(_new, t); t, c = P3.subn(NEW3, t); t, b = P2.subn("", t)
    assert a + c == n0 and b == n0, (a, c, b, n0)
    t = re.sub(r"(?<=[a-z])\.,", ",", t)
    assert "hand's width" not in t and "dissolve" not in t and "Even inside a transition zone" not in t and "hazy and feathered" not in t
    assert _dups(t) <= d0 and t.count(".,") <= c0 and ".." not in t.replace("...", "") and " ," not in t
    return t
