# -*- coding: utf-8 -*-
import re
s = open("gen_woodstone_sample4.py", encoding="utf-8").read()
ns = {}
exec(s[:s.index("# (소재 종류")], ns)
PH = ns["PH"]; bbw = PH[2]; assert bbw[0] == "BBW bombshell"
for i in range(8): PH[i] = bbw
W, T = ns["WOODS"], ns["STONES"]
S = [("목재", W[2], 1, 3), ("목재", W[5], 2, 6), ("석재", T[2], 1, 8), ("석재", T[5], 2, 11)]  # 마호가니·제브라우드·비취·로도나이트
o = ["# 목재·석재 단독 — 가장 부피 큰 체형(BBW bombshell) 샘플 4개\n", "얼굴 문장 없음(v1과 같은 틀), 이전 샘플과 다른 소재. 번호별로 정상/이상만 알려주세요.\n"]
for i, (kind, pick, n, slot) in enumerate(S, 1):
    fn = (ns["wood_fn"] if kind == "목재" else ns["stone_fn"])(pick)
    t = ns["build"](fn, n, slot); ns["check"](f"s{i}", t)
    assert not re.search(r"\b(\w+) \1\b", t)
    ti = f"{kind} {['','솔로','듀오','트리오'][n]} · {pick[0]} · 체형 BBW bombshell"
    o.append(f"## {i}. {ti}\n\n```\n{t}\n```\n"); print(i, ti, len(t.split()))
open("/mnt/user-data/outputs/LumineX_WoodStone_BBW4.md", "w", encoding="utf-8").write("\n".join(o))
