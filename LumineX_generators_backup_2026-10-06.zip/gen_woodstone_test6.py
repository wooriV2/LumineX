# -*- coding: utf-8 -*-
# 힐 숫자 A/B(40인치 표기 vs 몸 기준 비교) + 몸 주얼리 추가 — 6개
import re, random
src = open("gen_woodstone_full10.py", encoding="utf-8").read()
head = src[:src.index("PLAN = [")]
head = head.replace('rr = random.Random(20261010)', 'rr = random.Random(20261011)')
# 힐 문구를 모드에 따라 분기
old = 'each with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform, {BODYLIFT}."'
assert old in head
head = head.replace(old, '{HEELPH()}, {BODYLIFT}."')
# 주얼리 줄 추가
old2 = 'return "\\n".join([body, shoe, nails, fc]), info, nmw'
assert old2 in head
head = head.replace(old2, 'return "\\n".join([body, shoe, nails] + ([f"{p}Jewelry: {jewel(p)}"] if JEWEL else []) + [fc]), info, nmw')
exec(head)
MODE = "num"; JEWEL = False; JR = random.Random(77)
def HEELPH():
    if MODE == "num": return "each with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform"
    return "each with a razor-thin tapered heel taller than her entire shin from ankle to knee and a towering hidden front platform"
JW = ["a long layered gold necklace falling between her breasts", "a wide gold waist chain resting over the carved curve of her hips", "thick polished gold bangles stacked on both wrists",
      "a delicate silver body chain draped across her collarbones and down her torso", "sculpted gold armbands high on both upper arms", "a pearl choker and a long strand of pearls hanging low on her chest",
      "a gold belly chain with a small pendant at her navel", "a fine gold chain looped around her thigh above the knee", "heavy gold rings on every finger"]
def jewel(p):
    a = JR.sample(JW, 3)
    return ", ".join(a[:-1]) + ", and " + a[-1] + ". Jewelry is metal and pearl only, worn on the body, nothing added to her face or ears."
PLAN = [(1, ["wood"]), (2, ["stone", "wood"])]
sel = []
for n, kinds in PLAN:
    for attempt in range(60):
        picks = [rr.choice(WOODS if k == "wood" else STONES) for k in kinds]
        if len({p[0] for p in picks}) < n: continue
        physs = ([PH_BBW] if n == 1 else [PH_BBW, PH_AMA]); ages = [rr.choice(AGES) for _ in range(n)]; poses = [rr.choice(POSES) for _ in range(n)]; eths = rr.sample(ETH, n)
        si = rr.randrange(8); st = rr.getstate()
        outs = []; ok = True
        for mode, jw in (("num", False), ("rel", False), ("rel", True)):
            MODE, JEWEL = mode, jw; JR.seed(500 + n)
            rr.setstate(st)
            t, infos = build(kinds, picks, physs, ages, poses, eths, SETS[si])
            try: check(f"t{n}{mode}{jw}", t)
            except AssertionError: ok = False; break
            if re.search(r"\b(\w+) \1\b", t) or re.search(r"[가-힣]", t): ok = False; break
            outs.append((t, infos))
        if ok: break
    else: raise SystemExit("fail")
    sel.append((n, kinds, picks, physs, eths, si, outs))
o = ["# 목재·석재 — 힐 숫자 A/B + 주얼리 테스트 (6개)\n",
     "1↔2, 3↔4는 힐 문구만 다르고 나머지는 완전히 동일합니다(1·3은 40인치 표기, 2·4는 숫자 없이 '종아리보다 높은 힐'). 5는 2에, 6은 4에 몸 주얼리 줄만 추가했습니다(얼굴·귀는 그대로). 번호별로 정상/이상만 알려주세요.\n"]
labels = {0: "힐 40인치 표기", 1: "힐 숫자 없음(몸 기준 비교)", 2: "힐 숫자 없음 + 몸 주얼리"}
order = [(0, 0), (0, 1), (1, 0), (1, 1), (0, 2), (1, 2)]
num = 0
for si_, vi in order:
    n, kinds, picks, physs, eths, si, outs = sel[si_]; t, infos = outs[vi]; num += 1
    ti = f"{['','솔로','듀오'][n]} · " + " / ".join(f"{'목재' if k=='wood' else '석재'} {p[0]}" for k, p in zip(kinds, picks)) + " · 체형 " + ", ".join(x[0] for x in physs) + " · 인종 " + ", ".join(e[0] for e in eths) + " · " + " ‖ ".join(infos) + f" · 배경 {SETKO[si]} · {labels[vi]}"
    o.append(f"## {num}. {ti}\n\n```\n{t}\n```\n"); print(num, ti[:260], len(t.split()))
open(O + "LumineX_WoodStone_HeelNumber_Jewelry6.md", "w", encoding="utf-8").write("\n".join(o))
