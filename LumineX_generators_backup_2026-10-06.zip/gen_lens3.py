# -*- coding: utf-8 -*-
import random, re
import cjk_face_lib as C
f, mk = C.load()
src = [x for x in f if x["meta"]["piercing"] == "P25"][0]
TAIL = ", sitting naturally on the irises and clear of the eyelids"
NAT = {"한국": "Korean", "중국": "Chinese", "일본": "Japanese"}
def lens(d):
    return f"{d}, fully opaque and solidly saturated across the whole iris with no natural brown showing through, the colour bright and unmistakable, with a darker limbal ring"
CASES = [
 ("한국", "20대", "도도한", ("코발트 블루", "deep cobalt-blue coloured contact lens with round natural pupils"), ("에메랄드", "vivid emerald-green coloured contact lens with round natural pupils"), "둥근 동공"),
 ("일본", "20대", "냉혹한", ("형광 라임", "neon lime-green coloured contact lens with a vertical slit cat-eye pupil"), ("크림슨 레드", "intense crimson-red coloured contact lens with a vertical slit cat-eye pupil"), "고양이눈"),
 ("중국", "20대", "카리스마 있는", ("순백", "pure opaque white coloured contact lens with a greatly enlarged dilated pupil"), ("핫핑크", "hot-pink coloured contact lens with a heart-shaped pupil"), "큰 동공 | 하트 동공"),
 ("한국", "20대", "몽환적인", ("오렌지 파이어", "fiery orange coloured contact lens with a radiating sunburst iris pattern"), ("터쿼이즈", "bright turquoise coloured contact lens with a thick dark outer ring and round natural pupils"), "방사형 무늬 | 두꺼운 외곽 링"),
]
o = ["# 렌즈 3차 시험 4개 — 한 장에 양쪽 눈 다른 렌즈 (P0, 메이크업 없음)\n",
     "시험용입니다. 왼쪽 눈과 오른쪽 눈에 서로 다른 색·모양 렌즈를 넣었습니다. 한쪽 색이 빠지거나 두 색이 섞이면 '이상'으로 보시고, 어느 쪽이 빠졌는지만 알려주세요.\n"]
for i, (nat, grp, ex, L1, L2, shp) in enumerate(CASES, 1):
    rr = random.Random(10 + i)
    t = C.build(src, NAT[nat], grp, ex, None, mk, rr); t = C.strip_piercing(t)
    old = "full lips, " + C.EXPR[ex]
    assert t.count(old) == 1, i
    new = ("full lips, odd-eyed with two clearly different lenses: her left eye has a " + lens(L1[1]) + ", and her right eye has a " + lens(L2[1])
           + TAIL + ", the two eye colours both bright and clearly different from each other, " + C.EXPR[ex])
    t = t.replace(old, new)
    assert not re.search(r"[가-힣]", t)
    o.append(f"## {i}. {nat} · {grp} · {ex} · 왼쪽 {L1[0]} | 오른쪽 {L2[0]} ({shp})\n\n```\n{t}\n```\n")
open("/mnt/user-data/outputs/LumineX_Lens_Round3_OddEye4.md", "w", encoding="utf-8").write("\n".join(o))
print(o[2][:200])
