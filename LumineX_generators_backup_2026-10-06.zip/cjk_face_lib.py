# -*- coding: utf-8 -*-
# 한중일 얼굴 컷: 등록 맥시멀리스트 얼굴 컷(피어싱 프레임)의 구조에 한/중/일 얼굴 구절 + 나이대 + 표정 + (선택) 메이크업을 얹는다.
import json, re, random
import sf_blend_lib as L
O = "/mnt/user-data/outputs/"
FE = {"Korean": "East Asian Korean features: a slim V-line face with a small tapered chin and smooth forehead, large double-lidded eyes with soft fullness under them, a straight narrow nose bridge with a small rounded tip, softly full lips, gently straight eyebrows",
      "Chinese": "East Asian Chinese features: a longer oval face with prominent high cheekbones and a defined jawline, long upturned phoenix-shaped eyes with sharp inner folds, a high strong nose bridge, thin arched eyebrows with a slight rise, balanced lips",
      "Japanese": "East Asian Japanese features: a soft rounded short face with full cheeks and a small delicate chin, small narrow monolid eyes set slightly wide apart with no crease, a low soft nose bridge with a rounded tip, small modest lips, soft low flat eyebrows"}
AGE = {"아이돌": ("{n} pop idol visual", "early 20s", "Early 20s.", ["long straight black hair with soft see-through bangs", "soft chestnut-brown long waves with curtain bangs", "a sleek high ponytail with wispy side bangs"]),
       "20대": ("{n} fresh natural beauty", "mid 20s", "Mid 20s.", ["glossy dark-brown loose waves past the shoulders", "sleek black long hair with a centre part", "a chic black lob with soft layers"]),
       "30대": ("{n} poised refined beauty", "mid 30s", "Mid 30s.", ["sleek black shoulder-length hair with a side part", "a polished low bun with a few loose strands", "long glossy dark-brown waves swept to one side"])}
BODY = "hourglass physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — most dramatic hourglass ratio ever, simultaneously maximum enormous bust AND maximum enormous hips both flaring to absolute impossible extremes while the waist is cinched to impossible minimum"
EXPR = {"도도한": "looking down along the nose with the chin lifted slightly, lips closed in a faint haughty line, an aloof, haughty expression",
        "카리스마 있는": "a piercing direct stare, jaw set, lips firmly closed, a bold, commanding, fierce expression",
        "군림하는": "gazing down from beneath lowered lids with the chin raised high as if looking down on a subject kneeling before her, lips sealed in a faint regal curve, an imperious, queenly, commanding expression",
        "냉혹한": "a cold narrowed stare without a trace of warmth straight through the camera, brows low and still, lips pressed in a thin flat line, an icy, ruthless, merciless expression",
        "섹시한": "heavy-lidded eyes under half-lowered eyelids, lips slightly parted, a sultry, alluring expression",
        "고혹적인": "a slow, lingering gaze, lips closed in a restrained knowing half-smile, an alluring, mature, magnetic expression",
        "귀여운": "wide bright eyes, cheeks lifted by a playful half-smile with a hint of teeth, a cute, playful expression",
        "발랄한": "eyes crinkling with joy, cheeks lifted high by a wide open laughing smile showing white teeth, a lively, cheerful, radiant expression",
        "몽환적인": "a faraway, unfocused gaze drifting just past the camera, lips softly parted, a dreamy, ethereal expression",
        "당황한": "eyes wide and startled, unsure where to look, a deep blush spreading across the cheeks and nose, the lower lip lightly bitten, a flustered, embarrassed expression",
        "눈물 글썽한": "glistening eyes brimming with unshed tears, a pleading upward gaze at the camera, lips trembling slightly, a teary-eyed, vulnerable, pleading expression"}
PFX = "large eyes with bright real catchlights, full lips, "
SUFX = ", a bold, commanding expression"
STYLE_EXPR = {"비주얼계": "a cold, poised expression", "만바": "a fierce, playful expression", "구풍": "a serene expression", "홍콩풍": "a poised, glamorous expression",
              "강남언니": "a poised, refined, confident expression", "아게하": "a confident sparkling expression", "인스타글램": "a confident, camera-ready smile",
              "지뢰계": "a hollow, dreamy expression", "코갸루": "a bright cheeky grin", "반바": "a fierce, playful expression", "걸크러시": "a cold, commanding gaze",
              "아마갸루": "a sweet, shy smile", "야마바": "a bold cheeky grin"}
def load():
    g = json.load(open(O + "la_pframe_geo_300_bundle.json", encoding="utf-8")); m = json.load(open(O + "la_pframe_maxmk_60_bundle.json", encoding="utf-8"))
    faces = [x for x in g if x["meta"]["track"] == "맥시멀리스트" and x["meta"]["group_size"] == 1 and x["meta"]["frame"] == "face"]
    mk = {}
    for p in m:
        s = p["meta"].get("makeup")
        if s in STYLE_EXPR and s not in mk:
            t = p["prompt"]; a = t.index("a soft sheen of natural oils, ") + len("a soft sheen of natural oils, "); b = t.index(" — a photograph of a real face"); seg = t[a:b]
            assert seg.startswith(PFX) and seg.endswith(SUFX), s
            seg = seg[len(PFX):-len(SUFX)]; assert seg.endswith(", " + STYLE_EXPR[s]), (s, seg[-60:])
            mk[s] = seg[:-len(", " + STYLE_EXPR[s])]
    return faces, mk
SUBJ = L  # placeholder
HEAD = re.compile(r"(Subject: A real photograph of a striking adult woman — )(?P<hh>.+?)\. Real pores and fine skin grain on her skin", re.S)
def build(src, nat, grp, expr, makeup, mk, rr):
    desc, age, tag, hairs = AGE[grp]
    t = src["prompt"]; m = HEAD.search(t); assert m, src["key"]
    head = f"{desc.format(n=nat)} {L.SKIN[rr.choice('BCD')]}, {age}, {BODY}, {rr.choice(hairs)}"
    t = t[:m.start("hh")] + head + t[m.end("hh"):]
    t, n = re.subn(r"((?:Early|Mid|Late) [0-9]0s)\.\n", tag + "\n", t, count=1); assert n == 1
    a = "a striking adult woman —"; assert t.count(a) == 1; t = t.replace(a, f"a striking adult {nat} woman —")
    old = PFX + "a bold, commanding expression"; assert t.count(old) == 1
    mid = (mk[makeup] + ", ") if makeup else ""
    t = t.replace(old, PFX + mid + EXPR[expr])
    b = "a photograph of a real face,"; assert t.count(b) == 1
    t = t.replace(b, f"a photograph of a real {nat} woman's face ({FE[nat]}),")
    assert not re.search(r"[가-힣]", t) and "silver fox" not in t and "silver-white" not in t and "silver-era" not in t and "DARKEST" not in t
    assert not re.search(r"\b(\w+) \1\b", t), re.findall(r".{20}\b(\w+) \1\b.{20}", t)
    return t

# ---- 번들 생성용 확장 ----
BLACK_MK = {"고스 블랙립": "a deathly pale matte complexion with a cool undertone, heavy black smoky eyeshadow blended up to the brow bone, a sharp black winged liner, dramatic spidery lashes, a defined hollow contour under the cheekbones, matte jet-black lips with a precise edge",
            "펑크 블랙립": "smudged black raccoon eyeliner ringing the eyes, jagged black eyeshadow shards at the outer corners, thick black lower lashes, thin bleached brows, glossy black lips with a deliberately ragged edge",
            "비닐 블랙립": "wet-look black gradient eyeshadow with a chrome highlight on the lids, a graphic black liner, sleek lashes, high-shine black vinyl lips like polished glass, a cool matte contour",
            "잉크 블랙립": "a blurred ink-black gradient across the lids like soft smoke, a fine black liner, natural full lashes, a glass-skin highlight on the cheekbones, ink-black glossy lips with a softly blurred gradient edge"}
TAN = "deeply sun-tanned bronze-brown skin with a warm glossy sheen"
INT = "extremely heavy, fully saturated and bold, never subtle, faded or blended away: "
TAN_STYLES = {"코갸루", "야마바", "만바", "반바"}
DARK = {"비주얼계", "고스 블랙립", "펑크 블랙립", "비닐 블랙립", "잉크 블랙립", "걸크러시"}
def strip_piercing(t):
    for k in ("Piercings: ", "Piercing depth: ", "Jewelry: "):
        t, n = re.subn(re.escape(k) + r".*?\n\n", "", t, count=1, flags=re.S); assert n == 1 or k == "Jewelry: ", k
    t = t.replace(", so the glints on every piece of metal read clearly against her skin", ""); assert "metal" not in t and "Piercing" not in t and "piercings" not in t
    return t
def build2(src, nat, grp, expr, makeup, mk, rr, intense=False, p0=False):
    t = build(src, nat, grp, expr, makeup, mk, rr)
    if makeup in TAN_STYLES:
        sk = [v for v in L.SKIN.values() if v in t]; assert len(sk) == 1; t = t.replace(sk[0], TAN)
    if makeup and intense:
        seg = mk[makeup]; assert t.count(seg) == 1; t = t.replace(seg, INT + seg)
    if p0: t = strip_piercing(t)
    return t

# 눈 큰 표정 3종 (2026-10-08 시험 통과)
EXPR.update({"놀란": "eyes opened very wide with the whites showing above and below the irises, brows lifted high, lips parted in a round open O, staring straight into the camera, a startled, astonished expression",
             "호기심 어린": "round bright eyes opened wide and sparkling, brows raised a little, lips slightly parted, gazing straight at the camera with eager interest, a curious, inquisitive expression",
             "광기 어린": "eyes opened extremely wide with the whites showing all around the irises, a fixed unblinking stare, brows raised, a wide stretched grin showing teeth, a manic, unhinged expression"})
