import re, os, pickle, subprocess, sys, time
ops = pickle.load(open("/tmp/replay/ops.pkl", "rb"))
WRITE = re.compile(r"cat\s*>>?\s*\S+\.(py|txt|json)|sed\s+-i|\btee\b|\bcp\s+\S+\s+\S+\.py|\bmv\s+\S+\s+\S+\.py|open\([^)]*['\"][wa]['\"]|write_text|\.write\(")
stats = {"bash_run": 0, "bash_fail": 0, "bash_skip": 0, "create": 0, "strep_ok": 0, "strep_fail": 0}
fails = []
t0 = time.time()
for tr, pos, name, obj in ops:
    if name == "create_file":
        p = obj.get("path", ""); txt = obj.get("file_text", "")
        if p.startswith("/home/claude"):
            os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w", encoding="utf-8").write(txt); stats["create"] += 1
        continue
    if name == "str_replace":
        p = obj.get("path", ""); old = obj.get("old_str", ""); new = obj.get("new_str", "")
        if p.startswith("/home/claude") and os.path.exists(p):
            s = open(p, encoding="utf-8").read()
            if s.count(old) == 1: open(p, "w", encoding="utf-8").write(s.replace(old, new)); stats["strep_ok"] += 1
            else: stats["strep_fail"] += 1; fails.append((tr, "str_replace", p))
        continue
    cmd = obj.get("command", "")
    if "/home/claude" not in cmd and "cd " not in cmd and not cmd.lstrip().startswith(("cat", "python3", "sed", "cp", "mv")): stats["bash_skip"] += 1; continue
    if not WRITE.search(cmd): stats["bash_skip"] += 1; continue
    if "/mnt/user-data/uploads" in cmd: stats["bash_skip"] += 1; continue
    cmd = cmd.replace("/mnt/user-data/outputs", "/tmp/rep_out")
    try:
        r = subprocess.run(["bash", "-c", cmd], capture_output=True, text=True, timeout=90, cwd="/home/claude")
        stats["bash_run"] += 1
        if r.returncode != 0: stats["bash_fail"] += 1; fails.append((tr, pos, r.stderr[-160:].replace("\n", " ")))
    except subprocess.TimeoutExpired:
        stats["bash_fail"] += 1; fails.append((tr, pos, "timeout"))
print(stats, "| 경과 %.0f초" % (time.time() - t0))
pickle.dump(fails, open("/tmp/replay/fails.pkl", "wb"))
print("실패 샘플:"); [print(" ", f) for f in fails[:12]]
