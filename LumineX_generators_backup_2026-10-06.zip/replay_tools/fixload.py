import subprocess, re, os, shutil, sys
for attempt in range(25):
    r = subprocess.run(["python3", "-c", """
import sys
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
src = open('gen_pierce_statue.py', encoding='utf-8').read().split('\\nspecs = [')[0]
exec(src)
print('OK', list(FR), len(g18.T50), len(T.MAKEUP_48))
"""], capture_output=True, text=True, cwd="/home/claude/glassface", timeout=80)
    if r.returncode == 0: print("로드 성공:", r.stdout.strip()); break
    err = r.stderr.strip().split("\n")[-1]
    m = re.search(r"No such file or directory: '([^']+)'", err)
    if not m: print("다른 오류:", err[:300]); break
    want = m.group(1); base = os.path.basename(want); dest = want if want.startswith("/") else os.path.join("/home/claude/glassface", want)
    src = os.path.join("/mnt/user-data/outputs", base)
    if os.path.exists(src):
        os.makedirs(os.path.dirname(dest), exist_ok=True); shutil.copy(src, dest); print("복사:", base, "->", dest)
    else: print("outputs에도 없음:", want); break
