import re, json, glob, os, pickle
dec = json.JSONDecoder()
TR = "/mnt/transcripts"
files = sorted(glob.glob(TR + "/2026-*.txt")) + sorted(glob.glob(TR + "/2026-*.md.txt"))
files = sorted(set(files), key=lambda f: os.path.basename(f)[:19])
ops = []   # (transcript, pos, name, input_dict)
for f in files:
    t = open(f, encoding="utf-8", errors="ignore").read()
    for m in re.finditer(r'"name":\s*"(bash_tool|create_file|str_replace)",\s*"input":\s*(?=\{)', t):
        try:
            obj, end = dec.raw_decode(t[m.end():])
            ops.append((os.path.basename(f)[:19], m.start(), m.group(1), obj))
        except Exception: pass
print("전사본:", len(files), "| 추출된 도구 호출:", len(ops))
by = {}
for tr, pos, name, obj in ops: by.setdefault(tr, {}).setdefault(name, 0); by[tr][name] += 1
for k in sorted(by): print(k, by[k])
pickle.dump(ops, open("/tmp/replay/ops.pkl", "wb"))
