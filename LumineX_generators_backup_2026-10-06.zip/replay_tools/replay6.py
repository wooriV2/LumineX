import re, os, pickle, subprocess, sys
ops = pickle.load(open("/tmp/replay/ops.pkl", "rb"))
HDL = re.compile(r"cat\s*>>?\s*(\S+)\s*<<\s*-?\s*['\"]?(\w+)['\"]?")
PYL = re.compile(r"python3?\s+-\s*<<\s*['\"]?(\w+)['\"]?")
CDL = re.compile(r"cd\s+(/home/claude/\w+)")
stat = {"heredoc": 0, "create": 0, "sed": 0, "sed_fail": 0, "pypatch": 0, "pypatch_fail": 0, "strep_ok": 0, "strep_fail": 0}
def resolve(path, cwd):
    p = path.strip("'\"").replace("/mnt/user-data/outputs", "/tmp/rep_out")
    return p if p.startswith("/") else os.path.join(cwd, p)
for idx, (tr, pos, name, obj) in enumerate(ops):
    if name == "create_file":
        p = obj.get("path", "")
        if p.startswith("/home/claude"):
            os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w", encoding="utf-8").write(obj.get("file_text", "")); stat["create"] += 1
        continue
    if name == "str_replace":
        p = obj.get("path", "")
        if p.startswith("/home/claude") and os.path.exists(p):
            s = open(p, encoding="utf-8").read(); old = obj.get("old_str", "")
            if s.count(old) == 1: open(p, "w", encoding="utf-8").write(s.replace(old, obj.get("new_str", ""))); stat["strep_ok"] += 1
            else: stat["strep_fail"] += 1
        continue
    cmd = obj.get("command", "").replace("/mnt/user-data/outputs", "/tmp/rep_out")
    lines = cmd.split("\n"); cwd = "/home/claude/glassface"
    for ln in lines[:3]:
        m = CDL.search(ln)
        if m: cwd = m.group(1); break
    if "python3 -c" in cmd and "json.dump" in cmd and "/mnt/user-data/uploads" not in cmd and "rm -rf /" not in cmd:
        try:
            r = subprocess.run(["bash", "-c", cmd], capture_output=True, text=True, timeout=40, cwd=cwd); stat["pyc"] = stat.get("pyc", 0) + 1; stat["pyc_fail"] = stat.get("pyc_fail", 0) + (r.returncode != 0)
        except Exception: stat["pyc_fail"] = stat.get("pyc_fail", 0) + 1
    i = 0
    while i < len(lines):
        ln = lines[i]; hm = HDL.search(ln) if ("cat" in ln and "<<" in ln) else None
        pm = PYL.search(ln) if ("python" in ln and "<<" in ln) else None
        if hm or pm:
            delim = (hm or pm).group(2 if hm else 1); j = i + 1; buf = []
            while j < len(lines) and lines[j].strip() != delim: buf.append(lines[j]); j += 1
            if hm:
                target = resolve(hm.group(1), cwd)
                if target.startswith("/home/claude") and target.endswith((".py", ".txt", ".json", ".md")):
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    open(target, "a" if ">>" in ln.split("<<")[0] else "w", encoding="utf-8").write("\n".join(buf) + "\n"); stat["heredoc"] += 1
            else:
                body = "\n".join(buf)
                if "open(" in body and re.search(r"['\"][wa]['\"]", body) and (".py" in body or "json.dump" in body or ".json" in body):
                    try:
                        r = subprocess.run(["python3", "-"], input=body, capture_output=True, text=True, timeout=40, cwd=cwd); stat["pypatch"] += 1; stat["pypatch_fail"] += (r.returncode != 0)
                    except Exception: stat["pypatch_fail"] += 1
            i = j + 1; continue
        if re.search(r"(^|&&|;)\s*(cp|mv)\s+\S+\s+\S+", ln) and "/home/claude" in cmd and "<<" not in ln:
            try:
                c = re.sub(r"^\s*cd [^&]+&&\s*", "", ln)
                for seg in re.split(r"&&|;", c):
                    seg = seg.strip()
                    if re.match(r"(cp|mv)\s", seg):
                        r = subprocess.run(["bash", "-c", seg], capture_output=True, text=True, timeout=20, cwd=cwd); stat["cpmv"] = stat.get("cpmv", 0) + 1; stat["cpmv_fail"] = stat.get("cpmv_fail", 0) + (r.returncode != 0)
            except Exception: pass
        if "sed -i" in ln and ln.strip().startswith(("sed", "cd ")):
            try:
                c = re.sub(r"^\s*cd [^&]+&&\s*", "", ln)
                r = subprocess.run(["bash", "-c", c], capture_output=True, text=True, timeout=20, cwd=cwd); stat["sed"] += 1; stat["sed_fail"] += (r.returncode != 0)
            except Exception: stat["sed_fail"] += 1
        i += 1
print(stat)
