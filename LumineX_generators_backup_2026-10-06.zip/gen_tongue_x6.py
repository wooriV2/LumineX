# -*- coding: utf-8 -*-
import random, re
import cjk_face_lib as C
F, MK = C.load(); MK.update(C.BLACK_MK)
NAT = {"한국": "Korean", "중국": "Chinese", "일본": "Japanese"}
FULL = "the tongue split completely all the way back to its root, the two halves fully separate and spread wide apart like two separate tongues, each half ending in a pointed tip"
LONG = "stretched out unnaturally long, the two halves hanging far down over the chin toward the collarbone as two long separate ribbons"
FULLB = "the tongue dyed jet-black and split completely all the way back to its root, the two halves fully separate and spread wide apart like two separate tongues, each half ending in a pointed tip"
CHAIN = "a fine matching chain strung between a ring through each tip, drooping in a curve between the two halves"
BAR = "a long straight matching barbell passing through both halves side by side so that it links them together, with a ball at each end outside the halves"
MULTI = "five small matching rings stacked along the edge of each half"
QUAD = "the tongue split three times into four thin strands fanned out like a sea anemone, a small matching ring through the tip of each strand"
BLK = "dyed jet-black"
def src(lv, jew): return [x for x in F if x["meta"]["piercing"] == lv and (("Jewelry:" in x["prompt"]) == jew)][0]
EY = {"광기": "eyes opened extremely wide with the whites showing all around the irises, a fixed unblinking stare, a wide stretched grin with her mouth open and ",
      "관능": "heavy-lidded eyes looking straight into the camera, lips parted wide with ",
      "도발": "heavy-lidded eyes with a provocative stare straight into the camera, mouth wide open with ",
      "발랄": "wide bright eyes, cheeks lifted by a cheeky grin, mouth wide open with "}
EN = {"광기": "a manic, unhinged expression", "관능": "a sultry, teasing expression", "도발": "a defiant, provocative expression", "발랄": "a playful, mischievous expression"}
CASES = [("한국", "20대", "광기", f"her tongue stuck far out, {FULL}, {CHAIN}", "", None, ("P100", True), "끝까지 갈라진 혀 + 끝 링 사이 체인"),
         ("일본", "30대", "관능", f"her tongue stuck far out, {FULL}, {LONG}, a small matching ring through the tip of each half", "", None, ("P150", False), "아주 길게 늘어진 갈라진 혀 + 끝 링"),
         ("중국", "20대", "도발", f"her tongue stuck far out, {FULL}, {BAR}", "", "비주얼계", ("P100", True), "끝까지 갈라진 혀 + 두 갈래를 잇는 바"),
         ("한국", "아이돌", "발랄", f"her tongue stuck far out, {FULL}, {MULTI}", "", None, ("P50", True), "끝까지 갈라진 혀 + 가장자리 링 5개씩"),
         ("일본", "20대", "광기", f"her tongue stuck far out, {FULLB}, {LONG}, {CHAIN} strung with tiny black pearls", ", two sharp pointed vampire fangs showing", "고스 블랙립", ("P150", True), "검은 길게 늘어진 갈라진 혀 + 체인 + 송곳니"),
         ("중국", "30대", "도발", f"her tongue stuck far out, {QUAD}", "", None, ("P100", False), "4갈래 혀 + 갈래마다 링")]
o = ["# 갈라진 혀 극단 표현 시험 6개 (얼굴 클로즈업)\n", "혀를 최대한 극단적으로 표현했습니다. 번호별로 정상/이상만 알려주세요. 이상이면 갈라진 모양이 안 나왔는지, 체인·바·링이 안 나왔는지 한 줄만 적어주세요.\n"]
for i, (nat, grp, ex, tg, orn, mkn, (lv, jew), lab) in enumerate(CASES, 1):
    key = f"tx{i}"; C.EXPR[key] = EY[ex] + tg + orn + ", " + EN[ex]
    t = C.build(src(lv, jew), NAT[nat], grp, key, mkn, MK, random.Random(50 + i))
    assert not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t), re.findall(r".{20}\b(\w+) \1\b", t)
    o.append(f"## {i}. {nat} · {grp} · {lab} · {'메이크업 ' + mkn if mkn else '메이크업 없음'} · 피어싱 {lv}{'+쥬얼리' if jew else ''}\n\n```\n{t}\n```\n")
    print(i, C.EXPR[key][:330])
open("/mnt/user-data/outputs/LumineX_Tongue_Extreme6.md", "w", encoding="utf-8").write("\n".join(o))
