# -*- coding: utf-8 -*-
# 바디페인팅·이레즈미·UV네온·왁스 트리오 — 힐 40인치 표기 vs 숫자 없음 (A/B 8개)
import json, re
O = "/mnt/user-data/outputs/"
L = lambda f: {p["key"]: p for p in json.load(open(O + f, encoding="utf-8"))}
core, mx, d120 = L("la_core_bundle.json"), L("la_maximalist_bundle.json"), L("la_120_bundle.json")
BODYLIFT = "her feet arched fully vertical on the very tips of her toes like a dancer on pointe, her legs stretched impossibly long and her whole body lifted far above the ground on them as if standing on stilts"
LOW = " Very low camera angle with the full length of every boot visible down to the floor, the towering heel height dominating the silhouette and lifting her far above the floor."
def HEEL(mode):
    if mode == "num": return "a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform"
    return "a razor-thin tapered heel taller than her entire shin from ankle to knee and a towering hidden front platform"
def put_low(t):
    i = t.rindex(" 8K"); return t[:i] + LOW + t[i:]
def core_fix(t, mode):
    def f(m):
        lead, desc = m.group(1), re.sub(r"^[Ee]xtreme ", "", m.group(2))
        return f"{lead}ootwear: the most absurdly extreme heels imaginable — {desc}, each with {HEEL(mode)}, {BODYLIFT}."
    t, k = re.subn(r"((?:[Ll]eft woman's f|[Cc]enter woman's f|[Rr]ight woman's f|F))ootwear: (.*?), the platform soles rising far higher than her ankle bone, at least three times the thickness of an ordinary heel\.", f, t)
    assert k == 3, k
    return t.rstrip("\n") + LOW
def mx_fix(t, mode):
    t, k = re.subn(r"platform boots 8 inch, extra long stiletto nails", f"thigh-high platform stiletto boots in the colours of the body art, each with {HEEL(mode)}, {BODYLIFT}, extra long stiletto nails", t)
    assert k == 3, k
    return put_low(t)
def wax_fix(t, mode):
    t, k = re.subn(r"extreme platform heels entirely coated in the same hardened wax drips", f"extreme platform heels entirely coated in the same hardened wax drips, each with {HEEL(mode)}, {BODYLIFT}", t)
    assert k == 3, k
    return put_low(t)
def phys(p):
    if p["meta"].get("composition"): return " / ".join(p["meta"]["composition"])
    return ", ".join(x for x in re.findall(r"([A-Za-z][\w\- ]{3,40}?) physique", p["prompt"]) if "completely" not in x)
SETS = [("바디페인팅", core["la_core_trio_01"], core_fix), ("이레즈미", mx["la_irezumi_trio_01"], mx_fix), ("UV네온", mx["la_uvneon_trio_01"], mx_fix), ("왁스", d120["la_wax_trio_01"], wax_fix)]
o = ["# 트리오 힐 숫자 A/B — 바디페인팅 · 이레즈미 · UV네온 · 왁스 (8개)\n",
     "각 트랙의 등록 프롬프트(트리오 01)에서 신발 문장만 바꿨습니다. 홀수 번호는 힐 40인치 표기, 짝수 번호는 숫자 없이 '정강이보다 높은 힐'이며, 1↔2, 3↔4, 5↔6, 7↔8이 짝입니다(짝끼리는 힐 문구 외 동일). 번호별로 정상/이상, 그리고 쌍마다 어느 쪽이 더 높았는지만 알려주세요.\n"]
n = 0
for tr, p, fix in SETS:
    for mode, lab in (("num", "힐 40인치 표기"), ("rel", "힐 숫자 없음")):
        t = fix(p["prompt"], mode); n += 1
        assert not re.search(r"[가-힣]", t)
        assert ("forty inches" in t) == (mode == "num")
        ti = f"{tr} 트리오 · {phys(p)} · {lab}"
        o.append(f"## {n}. {ti}\n\n```\n{t}\n```\n"); print(n, ti[:150], len(t.split()))
open(O + "LumineX_Trio_HeelAB_Tracks8.md", "w", encoding="utf-8").write("\n".join(o))
