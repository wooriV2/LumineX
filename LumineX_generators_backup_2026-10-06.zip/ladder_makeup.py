# -*- coding: utf-8 -*-
# 메이크업 강도 사다리: 같은 얼굴 틀(P0)에서 메이크업 문구와 (선택) 피부·헤어만 단계별로 바꿔 비교한다.
import sys, random, re
sys.path.insert(0, ".")
import cjk_face_lib as C, sf_blend_lib as L
def ladder(title, out, nat, grp, expr, levels, hair=None, seed=7, pier=None):
    f, mk = C.load(); src = [x for x in f if x["meta"]["piercing"] == (pier or "P25") and (pier is None or 'Jewelry:' in x['prompt'])][0]
    o = [f"# {title}\n", "같은 얼굴 틀(P0)에서 메이크업 강도만 올렸습니다. 표정과 헤어는 동일합니다.\n"]
    for lab, txt, skin in levels:
        rr = random.Random(seed); t = C.build(src, nat, grp, expr, "x", {"x": txt}, rr)
        if not pier: t = C.strip_piercing(t)
        if hair:
            hs = [h for h in C.AGE[grp][3] if h in t]; assert len(hs) == 1; t = t.replace(hs[0], hair)
        if skin:
            sk = [v for v in L.SKIN.values() if v in t]; assert len(sk) == 1; t = t.replace(sk[0], skin)
        o.append(f"## {lab}\n\n```\n{t}\n```\n")
    open(out, "w", encoding="utf-8").write("\n".join(o))
