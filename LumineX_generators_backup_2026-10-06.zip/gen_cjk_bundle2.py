# -*- coding: utf-8 -*-
# 한중일 얼굴컷 v2 번들 120: 한국·중국·일본 각 40. 메이크업(단계/원본) × 포인트(피어싱·마이크로더멀·스티커·헤나·렌즈) 랜덤, 포인트 최대 3종.
import json, random, collections, re
import cjk_face_lib as C, gen_cjk_v2 as G
O = "/mnt/user-data/outputs/"
rr = random.Random(20261008)
NATS = [("Korean", "한국", "kr"), ("Chinese", "중국", "cn"), ("Japanese", "일본", "jp")]
AGES = ["아이돌", "20대", "30대"]
EX = {"아이돌": ["귀여운", "발랄한", "당황한", "눈물 글썽한", "몽환적인", "도도한", "놀란", "호기심 어린"],
      "20대": ["도도한", "섹시한", "귀여운", "발랄한", "몽환적인", "당황한", "눈물 글썽한", "카리스마 있는", "놀란", "호기심 어린", "광기 어린"],
      "30대": ["고혹적인", "군림하는", "냉혹한", "카리스마 있는", "도도한", "섹시한", "몽환적인", "놀란", "광기 어린"]}
DARK_EX = ["도도한", "섹시한", "카리스마 있는", "군림하는", "냉혹한", "고혹적인", "몽환적인", "광기 어린"]
LIPFOCUS = set(["비주얼계 블랙립", "고스 블랙립", "비닐 블랙립", "립온리 블랙", "뱀파이어 다크", "펑크 블랙립", "잉크 블랙립", "클래식 레드립", "와인 레드립", "코랄 립", "푸시아 립", "블러드 립"])
BL = ["비주얼계 블랙립", "고스 블랙립", "비닐 블랙립", "립온리 블랙", "뱀파이어 다크", "펑크 블랙립", "잉크 블랙립"]
RL = ["클래식 레드립", "와인 레드립", "코랄 립", "푸시아 립", "블러드 립"]
COMMON = ["걸크러시", "인스타글램", "강남언니", "글래스 스킨", "지뢰계", "아마갸루"] + BL + RL
AFF = {"kr": ["혼례(연지곤지)", "글래스 스킨", "강남언니", "인스타글램", "걸크러시", "지뢰계", "아마갸루"] + BL + RL,
       "cn": ["경극", "둔황 비천풍", "구풍", "홍콩풍", "걸크러시", "인스타글램", "글래스 스킨"] + BL + RL,
       "jp": ["코갸루", "마이코", "야마바", "만바", "반바", "아게하", "지뢰계", "아마갸루", "글래스 스킨"] + BL + RL}
NATSTYLE = {"kr": ["혼례(연지곤지)", "글래스 스킨"], "cn": ["경극", "둔황 비천풍", "구풍", "홍콩풍"], "jp": ["코갸루", "마이코", "야마바", "만바", "반바", "아게하"]}
NACC = [0, 1, 2, 3]; NW = [0.08, 0.27, 0.40, 0.25]
CAT = {"kr": "🏺 Living Artifact · Korean Face Formula", "cn": "🏺 Living Artifact · Chinese Face Formula", "jp": "🏺 Living Artifact · Japanese Face Formula"}
FORK = "the tongue deeply forked like a snake's, split down the middle for most of its length, the two pointed tips clearly separated and curling slightly apart"
BLACKF = "the tongue dyed jet-black and deeply forked like a snake's, split down the middle for most of its length, the two pointed tips clearly separated and curling slightly apart"
RING = ", with a small matching metal ring through each fork tip"
STUDS = ", with a small matching barbell stud through each half of the fork, one ball on top and one underneath"
TV = [("분리된 혀", FORK, 3), ("분리된 혀+끝 링", FORK + RING, 3), ("분리된 혀+양쪽 스터드", FORK + STUDS, 2), ("검은 분리된 혀", BLACKF, 1.5), ("검은 분리된 혀+끝 링", BLACKF + RING, 1.5)]
STRAND = ", the strands fanned slightly apart"
THREE = "the tongue split into three narrow pointed strands from the tip back about two-thirds of its length" + STRAND
FOUR = "the tongue split into four narrow pointed strands from the tip back about two-thirds of its length" + STRAND
RING_S = ", a small matching ring through the tip of each strand"
T3 = [("3갈래 혀", THREE), ("3갈래 혀+갈래마다 링", THREE + RING_S)]
T4 = [("4갈래 혀", FOUR), ("4갈래 혀+갈래마다 링", FOUR + RING_S)]
ORN = [", a gold grill covering the upper front teeth, set with small clear gems", ", two sharp pointed vampire fangs showing", ""]
TE = {"발랄": "wide bright eyes, cheeks lifted by a cheeky grin, mouth open with her tongue stuck out straight over the lower lip, {t}{x}, a playful, mischievous expression",
      "도발": "heavy-lidded eyes with a provocative stare straight into the camera, mouth open with her tongue stuck out and curled up toward one corner of the lips, {t}{x}, a defiant, provocative expression",
      "관능": "heavy-lidded eyes, lips parted, her tongue stretched out long and low with its tip reaching down past the lower lip toward the chin, {t}{x}, a sultry, teasing expression",
      "광기": "eyes opened extremely wide with the whites showing all around the irises, a fixed unblinking stare, a wide stretched grin with her tongue flicked out, {t}{x}, a manic, unhinged expression"}
TAGE = {"아이돌": ["발랄"], "20대": ["발랄", "도발", "광기"], "30대": ["도발", "관능", "광기"]}
out = []; sc = collections.Counter(); ec = collections.Counter(); tn = 0
for nat_en, kr, cd in NATS:
    ages = [AGES[i % 3] for i in range(40)]; rr.shuffle(ages)
    nomk = set(rr.sample(range(40), 4)); mine = collections.Counter(); tgi = set(rr.sample(range(40), 6))
    for i in range(40):
        grp = ages[i]
        for attempt in range(20):
            if i in nomk: style = "NONE"
            else:
                lst = AFF[cd] if rr.random() > 0.15 else [x for x in G.STYLES if x in AFF["kr"] + AFF["cn"] + AFF["jp"]]
                wts = [(6.0 if x in NATSTYLE[cd] else 2.0 if x in COMMON[:6] else 1.0) / (1 + mine.get(x, 0)) for x in lst]
                style = rr.choices(lst, wts)[0]
            sub = random.Random(rr.random())
            dark_guess = style in G.DARKSTEP or style in G.DARKORIG
            pool = [e for e in (DARK_EX if dark_guess else EX[grp]) if e in EX[grp]] or EX[grp]
            if style in LIPFOCUS: pool = [e for e in pool if e not in ("놀란", "호기심 어린")] or pool
            mnn = min(ec.get(x, 0) for x in pool); e = rr.choice([x for x in pool if ec.get(x, 0) == mnn])
            nacc = rr.choices(NACC, NW)[0]
            tong = None; ekey = e
            if i in tgi:
                order = sorted(tgi).index(i)
                if order == 0: tl, tt = rr.choice(T4); nn = 4
                elif order == 1: tl, tt = rr.choice(T3); nn = 3
                else: tl, tt, _ = rr.choices(TV, [w for _, _, w in TV])[0]; nn = 2
                tt = tt + f" [[TG{nn}]]"
                te = rr.choice(TAGE[grp]); orn = rr.choice(ORN)
                tn += 1; ekey = f"tg_{cd}_{i}_{attempt}"; C.EXPR[ekey] = TE[te].format(t=tt, x=orn); tong = (tl, te, orn); e = f"혀 내밀기({te})"
            try:
                t, title, m = G.make(sub, kr, grp, ekey, style=style, nacc=max(nacc, 1) if tong else nacc, must=(['pierce'] if tong else None), pier_min=bool(tong))
                if style == "NONE" and m["makeup"]: raise AssertionError
                if style != "NONE" and not m["makeup"]: raise AssertionError
                break
            except AssertionError:
                continue
        else: raise SystemExit("fail " + style)
        mine[style] += 1; ec[e] += 1
        t = re.sub(r" \[\[TG\d\]\]", "", t)  # 한글 병기는 제미나이에서 효과 없어 제거 (2026-10-08)
        if tong: m['info'] = m['info'] + [(tong[0] if tong[0][0].isdigit() else '혀 ' + tong[0]) + (' + 금니 그릴' if 'grill' in tong[2] else ' + 송곳니' if 'fangs' in tong[2] else '')]
        n = len([p for p in out if p["meta"]["nat"] == cd]) + 1
        mk_ = f"메이크업 {m['makeup_label']}" if m["makeup"] else "메이크업 없음"
        pts = (" · " + " · ".join(m["info"])) if m["info"] else " · 포인트 없음"
        out.append({"key": f"la_cjkface_{cd}_solo_{n:02d}", "category": CAT[cd],
                    "title": f"{nat_en} Face Solo #{n:02d} ({kr} · {grp} · {e} · {mk_}{pts}{' · 태운 피부' if m['tan'] else ''})", "prompt": t,
                    "meta": {"group_size": 1, "aspect_ratio": "2:3", "format": "cjk-face", "nat": cd, "age_group": grp, "expression": e, "piercing": m["piercing"],
                             "jewelry": m["jewelry"], "makeup": m["makeup"], "makeup_label": m["makeup_label"], "tan": m["tan"], "microdermal": m["micro"],
                             "sticker": m["sticker"], "henna": m["henna"], "lens": m["lens"], "tongue": (tong[0] if tong else None), "accent_count": len(m["info"]) - (1 if tong else 0)}})
assert len(out) == 120 and len({p["key"] for p in out}) == 120
for p in out: assert not re.search(r"[가-힣]", p["prompt"]) and "[[" not in p["prompt"]
json.dump(out, open(O + "la_cjk_face_120_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
def cnt(f): return sum(1 for p in out if f(p["meta"]))
print("nat", collections.Counter(p["meta"]["nat"] for p in out)); print("age", collections.Counter(p["meta"]["age_group"] for p in out))
print("accent_count", sorted(collections.Counter(p["meta"]["accent_count"] for p in out).items()))
print("pierce", cnt(lambda m: m["piercing"] != "P0"), "levels", sorted(collections.Counter(p["meta"]["piercing"] for p in out).items()), "jewelry", cnt(lambda m: m["jewelry"]))
print("micro", cnt(lambda m: m["microdermal"]), "sticker", cnt(lambda m: m["sticker"]), "henna", cnt(lambda m: m["henna"]), "lens", cnt(lambda m: m["lens"]), "odd", cnt(lambda m: m["lens"] and "오드아이" in m["lens"]))
print("nomakeup", cnt(lambda m: not m["makeup"]), "tan", cnt(lambda m: m["tan"]))
print("expr", sorted(ec.items()))
print("style", sorted(collections.Counter(p["meta"]["makeup"] for p in out).items(), key=lambda x: -x[1]))
print("hi_dark", sum(1 for p in out if p["meta"]["piercing"] in ("P100", "P150")), [p["meta"]["makeup"] for p in out if p["meta"]["piercing"] in ("P100", "P150")])
print("len max/min", max(len(p["prompt"]) for p in out), min(len(p["prompt"]) for p in out))
