# -*- coding: utf-8 -*-
# 실버폭스 Piercing Frame 120: 등록 맥시멀리스트 솔로 피어싱 프레임 130개(얼굴 90·가슴 20·허리 20) 중 120개 → K 60 + 국제 60.
# 한국은 밝은 피부라 P50 이하, 국제는 전 단계.
import json, random, re, sys, collections
HERE = "/tmp/claude-0/-home-claude/62db5eea-2487-540b-9935-a7df06448e2a/scratchpad/"
sys.path.insert(0, HERE + "sfv2"); sys.path.insert(0, HERE + "bi")
import sf_pierce_lib as P, bi_lib as BI
O = "/mnt/user-data/outputs/"
g = json.load(open(O + "la_pframe_geo_300_bundle.json", encoding="utf-8")); m = json.load(open(O + "la_pframe_maxmk_60_bundle.json", encoding="utf-8"))
src = [x for x in g if x["meta"]["track"] == "맥시멀리스트" and x["meta"]["group_size"] == 1] + m
assert len(src) == 130
rr = random.Random(20261008)
lvl = lambda x: int(x["meta"]["piercing"][1:])
pick = {"K": [], "I": []}
faces = [x for x in src if x["meta"]["frame"] == "face"]; chest = [x for x in src if x["meta"]["frame"] == "chest"]; waist = [x for x in src if x["meta"]["frame"] == "waist"]
low = [x for x in faces if lvl(x) <= 50]; high = [x for x in faces if lvl(x) > 50]
rr.shuffle(low); rr.shuffle(high)
assert len(low) == 64 and len(high) == 26
kf = low[:40]; i_f = high + low[40:54]          # 남는 낮은 단계 얼굴 10개는 미사용
pick["K"] += kf; pick["I"] += i_f
for x in chest: (pick["K"] if lvl(x) <= 50 else pick["I"]).append(x)
for lv in (25, 50):
    w = [x for x in waist if lvl(x) == lv]; rr.shuffle(w); pick["K"] += w[:5]; pick["I"] += w[5:]
assert len(pick["K"]) == 60 and len(pick["I"]) == 60 and all(lvl(x) <= 50 for x in pick["K"])
CAT = {"K": "🏺 Living Artifact · K-Silverfox Piercing Frame Formula", "I": "🏺 Living Artifact · Silverfox Piercing Frame Formula"}
PFX = {"K": "la_ksilverfox_pframe", "I": "la_silverfox_pframe"}
ORDER = {"face": 0, "chest": 1, "waist": 2}
out = []
for kd in "KI":
    pk = sorted(pick[kd], key=lambda x: (ORDER[x["meta"]["frame"]], x["key"]))
    for n, x in enumerate(pk, 1):
        seed = rr.randrange(10 ** 9); t = P.convert_close(x["prompt"], kd, seed)
        b = BI.interlock(t)
        if b: t = b
        assert "hazy and feathered" not in t
        inner = re.search(r"\((.*)\)$", x["title"]).group(1).split(" · ")
        parts = [p.replace("맥시멀리스트 ", "") for p in inner if p != "맥시멀리스트" and not p.startswith("피부톤")]
        title = f"{'K-Silverfox' if kd == 'K' else 'Silverfox'} Piercing Frame Solo #{n:02d} ({'한국' if kd == 'K' else '국제'} · {' · '.join(parts)})"
        age = re.search(r"((?:early|mid|late) [45]0s)", t).group(1)
        meta = {"group_size": 1, "aspect_ratio": "2:3", "format": "silverfox-piercing-frame", "kind": kd, "frame": x["meta"]["frame"], "piercing": x["meta"]["piercing"],
                "jewelry": "Jewelry:" in t, "age": age, "source": x["key"]}
        if "makeup" in x["meta"]: meta["makeup"] = x["meta"]["makeup"]
        out.append({"key": f"{PFX[kd]}_solo_{n:02d}", "category": CAT[kd], "title": title, "prompt": t, "meta": meta})
json.dump(out, open(O + "la_silverfox_pframe_120_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(out), len(set(p["key"] for p in out)), len(set(p["meta"]["source"] for p in out)))
print(collections.Counter((p["meta"]["kind"], p["meta"]["frame"]) for p in out))
print(sorted(collections.Counter((p["meta"]["kind"], p["meta"]["piercing"]) for p in out).items()))
print("jewelry", collections.Counter((p["meta"]["kind"], p["meta"]["jewelry"]) for p in out))
