# -*- coding: utf-8 -*-
# 등록된 맥시멀리스트 트랙 재질·구조 혼합 프롬프트(Material Blend / Structure Pack)의 인물을 실버폭스로 치환.
import json, re, random
BLACK = "THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky"
HAIR16 = ["silver-white sleek straight hair falling past her shoulders", "silver-white loose waves cascading to her waist", "silver-white voluminous curls framing her face",
          "silver-white hair in a sleek high ponytail", "silver-white hair in an elegant updo", "silver-white half-up hair, top section lifted with the length flowing loose below",
          "silver-white hair in a low bun", "silver-white chin-length bob", "silver-white layered tousled shag cut", "silver-white layered wolf cut with curtain bangs",
          "silver-white flat glossy finger waves styled close to the scalp", "silver-white intricate fishtail braid", "silver-white crown braid wrapping around the head",
          "silver-white low chignon knot at the nape", "silver-white vintage victory rolls framing the face", "silver-white sleek wet-look hair slicked straight back"]
SF_AGES = ["early 40s", "mid 40s", "late 40s", "early 50s"]
SKIN = {"B": "luminous fair porcelain complexion with a neutral-rose undertone and clear glass-skin glow",
        "C": "luminous light-neutral complexion with a soft peach-beige undertone",
        "D": "luminous milky ivory-fair complexion with a cool-neutral undertone and smooth dewy skin"}
KFACE = "Korean silver fox goddess {sk} elegant silver-era maturity"
HDR = re.compile(r"^(#\d+: )?" + re.escape(BLACK) + r", ((?:early|mid|late) \d0s) goddess, (.+? physique THE MOST EXTREME)")
CONT = " — her body carries "
def convert_person(line, kind, age, hair, rr):
    m = HDR.match(line); assert m, line[:150]
    lab = m.group(1) or ""
    head = (f"{lab}{BLACK}, {age} silver fox goddess, {m.group(3)}" if kind == "I"
            else f"{lab}{KFACE.format(sk=SKIN[rr.choice('BCD')])}, {age}, {m.group(3)}")
    rest = line[m.end():]
    i = rest.index(CONT); seg = rest[:i]; j = seg.rfind(", ")
    oh = seg[j + 2:]
    assert re.search(r"hair|braid|bun|bob|ponytail|crop|cut|waves|curls|locs|afro|updo|crown|chignon|twist|tresses|mane|shag|rolls|mohawk|fro|knot", oh, re.I), oh
    return head + seg[:j + 2] + hair + rest[i:]
def convert_prompt(t, kind, seed):
    rr = random.Random(seed); lines = t.split("\n"); n = sum(1 for l in lines if HDR.match(l))
    ages = rr.sample(SF_AGES * 3, n); hairs = rr.sample(HAIR16, n); k = 0; out = []
    for l in lines:
        if HDR.match(l): l = convert_person(l, kind, ages[k], hairs[k], rr); k += 1
        out.append(l)
    t2 = "\n".join(out); assert k == n and k >= 1
    assert not re.search(r"[가-힣]", t2) and not re.search(r"\b(\w+) \1\b", t2)
    if kind == "K": assert "DARKEST BLACK" not in t2
    return t2, n

# ---- 또렷한 경계판: 흐릿한 전환 구역 문장을 '딱 맞물리는 이음선' 문장으로 교체 ----
def crisp(t):
    n0 = t
    t = t.replace("The boundaries between regions are hazy and feathered — there is no visible line at all.",
                  "The regions meet along crisp, exact, tightly interlocked edges — each material ends precisely where the next begins, like fitted puzzle pieces edge to edge, and where two different materials touch there is at most a single hair-thin natural line and no visible band, no stripe, no gradient and no fog between them.")
    t = re.sub(r"Each transition zone is about a hand's width wide, and across it .*?never a hard edge\.",
               "Each join is a clean tight seam: the material on one side runs right up to the material on the other with no gap, no overlap and no blank strip between them.", t, flags=re.S)
    t = t.replace("Even inside a transition zone the skin is never left bare: at every point one material, or a mixture of the two, fully covers it",
                  "Along every join the skin is never left bare: the materials on either side meet directly and fully cover it")
    t = re.sub(r"hazy ((?:ray|ring)-shaped )?transition zones?", lambda m: "dividing line" + ("s" if "zones" in m.group(0) else ""), t)
    t = re.sub(r"\bhazy ", "", t)
    t = t.replace("transition zones", "dividing lines").replace("transition zone", "dividing line")
    t = t.replace("every blended transition", "every clean join")
    assert not re.search(r"hazy|feathered|dissolve|transition", t), re.findall(r".{30}(?:hazy|feathered|dissolve|transition).{30}", t)
    assert not re.search(r"\b(\w+) \1\b", t)
    return t
