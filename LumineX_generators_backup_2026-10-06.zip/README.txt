LumineX 생성 스크립트 백업 (2026-10-06)
- glassface/*.py : 시험·번들 생성 모듈 (gen_pierce_*.py 등)
- diversity/*.py : tracker.py (T 모듈)
- replay_tools/ : 대화 기록(/mnt/transcripts)에서 도구를 복원하는 스크립트 (extract.py → replay6.py)
복원 방법: 샌드박스가 초기화되면 이 zip을 /home/claude 아래에 풀고, 부족한 JSON(register_*·la_*_bundle.json)은 outputs에서 복사.

[2026-10-09 추가] 목재·석재 v2 · 힐/신발/주얼리 시험 생성기 (핸드오프 v6.36 31장)
- gen_woodstone2_600.py : 목재·석재 포뮬러 v2 600 (시드 20261016) → la_woodstone2_600_bundle.json → patch_la_woodstone2_1_json.py
- gen_wsmix2_240.py : 목재+석재 혼합 v2 240 (시드 20261017) → la_wsmix2_240_bundle.json → patch_la_wsmix2_1_json.py
  (두 생성기는 gen_woodstone_trio2.py 머리부를 exec 한다 → gen_woodstone_duo2/test4/test6 → gen_woodstone_full10 → gen_woodstone_600 → groups6 순으로 이어진다. 같은 폴더에 모두 있어야 한다. 외부: gen_cjk_v2.py, cjk_face_lib.py)
- gen_woodstone_full10.py : 부피 큰 체형 + 메이크업만 + 최극단 힐 솔로5·듀오5
- gen_woodstone_test6.py / test4.py / duo2.py / duo2b.py / heel4.py / trio2.py / q45.py : 힐 숫자 A/B(40인치 vs 숫자 없음), 10·20·30·40 비교, 주얼리, 쿼텟·퀸텟 시험
- gen_heel_ab_tracks8.py : 바디페인팅·이레즈미·UV네온·왁스 트리오 힐 A/B (소스: outputs의 la_core_bundle, la_maximalist_bundle, la_120_bundle)
- gen_heel_color3.py : 신발 색을 몸 패턴 색으로 지정(이레즈미·UV네온·왁스 트리오)
- gen_woodstone_face4/bbw4/heels3~6/full6.py : 목재·석재 얼굴·BBW·극단 힐 중간 시험들
