# -*- coding: utf-8 -*-
import re, random
import gen_cjk_v2 as G
s = open("gen_woodstone_sample4.py", encoding="utf-8").read()
ns = {}
exec(s[:s.index("# (소재 종류")], ns)
PH = ns["PH"]
PH[7] = ("pear hourglass", "hips and thighs flaring to absolute maximum beyond any proportion, waist cinched to impossible minimum, a full soft bust, smooth rounded feminine curves everywhere")
BANNED = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","safety pin","gash","crack"]
PALE = re.compile(r"pale|porcelain|ivory|fair|milky|white complexion|deathly|tan\b", re.I)
SAFE = ["인스타글램", "강남언니", "글래스 스킨", "걸크러시", "지뢰계", "클래식 레드립", "와인 레드립", "푸시아 립", "블러드 립", "코랄 립", "잉크 블랙립", "비닐 블랙립", "립온리 블랙", "비주얼계 블랙립"]
EXPR = ["섹시한", "도도한", "고혹적인", "카리스마 있는", "몽환적인", "귀여운", "호기심 어린", "놀란"]
rrg = random.Random(20261009)
_ex = EXPR[:]; rrg.shuffle(_ex); _ei = [0]
def face_text():
    for _ in range(120):
        st = rrg.choice(SAFE); ex = _ex[_ei[0] % len(_ex)]; minp = rrg.random() < 0.35
        slots = (["pierce"] if minp else []) + rrg.sample(["lens", "micro", "sticker", "henna"], 2 if not minp else 1)
        try: t, title, m = G.make(random.Random(rrg.random()), "한국", "20대", ex, style=st, slots=slots, pier_level=(rrg.choice(["P3", "P8"]) if minp else None))
        except AssertionError: continue
        a = t.index("catchlights, full lips, ") + len("catchlights, full lips, "); b = t.index(" — a photograph of a real")
        seg = t[a:b]
        if PALE.search(seg): continue
        pz = re.search(r"\nPiercings: (.*?)\n\nPiercing depth: (.*?)(?:\n\nJewelry: (.*?))?\n\nLighting:", t, re.S)
        pier = (pz.group(1).strip() + " " + pz.group(2).strip() + ((" Jewelry: " + pz.group(3).strip()) if pz.group(3) else "")) if pz else ""
        if any(w in (seg + ' ' + pier).replace('snake-bite', '').lower() for w in BANNED): continue
        _ei[0] += 1
        return seg.strip(), pier, title
    raise SystemExit("fail")
def withface(fn, log):
    def f(label, idx):
        base = fn(label, idx); seg, pier, title = face_text(); log.append(title)
        p = f"{label}: " if label else ""
        face = (f"{p}Face: her face and ears are NOT carved — they are real living flesh with real pores and bright real catchlights, an unmistakably feminine face with a delicate jaw and full lips, {seg}." + (f" Piercings: {pier}" if pier else ""))
        return base + "\n" + face
    return f
S = [("목재", ns["WOODS"][3], 1, 4), ("목재", ns["WOODS"][0], 3, 7), ("석재", ns["STONES"][3], 1, 5), ("석재", ns["STONES"][0], 2, 9)]
o = ["# 목재·석재 단독 보강 샘플 4개 (v3: 메이크업·표정·포인트 추가, 피어싱은 없음 또는 최소, 파워리프터 제외)\n", "번호별로 정상/이상만 알려주세요.\n"]
for i, (kind, pick, n, slot) in enumerate(S, 1):
    log = []
    fn = withface((ns["wood_fn"] if kind == "목재" else ns["stone_fn"])(pick), log)
    t = ns["build"](fn, n, slot)
    chk = t.replace("snake-bite", "snake-X")
    ns["check"](f"s{i}", chk)
    assert not re.search(r"\b(\w+) \1\b", t), re.findall(r".{20}\b(\w+) \1\b", t)
    phys = ", ".join(PH[(slot * 3 + j) % 8][0] for j in range(n))
    ti = f"{kind} {['','솔로','듀오','트리오'][n]} · {pick[0]} · 체형 {phys} · " + " / ".join(x.split(" · ", 2)[2] if x.count(" · ") >= 2 else x for x in log)
    o.append(f"## {i}. {ti}\n\n```\n{t}\n```\n"); print(i, ti[:260], len(t.split()))
open("/mnt/user-data/outputs/LumineX_WoodStone_Face_Sample4_v3.md", "w", encoding="utf-8").write("\n".join(o))
