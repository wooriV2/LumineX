# -*- coding: utf-8 -*-
# 한중일 얼굴 컷 120: 한국·중국·일본 각 40. 아이돌/20대/30대 × 표정 11 × 메이크업(13+블랙립4, 약 25% 없음) × 피어싱 P0~P150.
import sys, json, random, re, collections
sys.path.insert(0, ".")
import cjk_face_lib as C
O = C.O
faces, mk = C.load(); mk.update(C.BLACK_MK)
rr = random.Random(20261008)
NATS = [("Korean", "한국", "kr"), ("Chinese", "중국", "cn"), ("Japanese", "일본", "jp")]
AGES = ["아이돌", "20대", "30대"]
EX = {"아이돌": ["귀여운", "발랄한", "당황한", "눈물 글썽한", "몽환적인", "도도한"],
      "20대": ["도도한", "섹시한", "귀여운", "발랄한", "몽환적인", "당황한", "눈물 글썽한", "카리스마 있는"],
      "30대": ["고혹적인", "군림하는", "냉혹한", "카리스마 있는", "도도한", "섹시한", "몽환적인"]}
DARK_EX = ["도도한", "섹시한", "카리스마 있는", "군림하는", "냉혹한", "고혹적인", "몽환적인"]
AFF = {"kr": ["강남언니", "인스타글램", "걸크러시", "지뢰계", "비주얼계", "고스 블랙립", "잉크 블랙립", "아마갸루"],
       "cn": ["구풍", "홍콩풍", "걸크러시", "인스타글램", "강남언니", "비주얼계", "고스 블랙립", "비닐 블랙립", "펑크 블랙립"],
       "jp": ["코갸루", "야마바", "만바", "반바", "아게하", "지뢰계", "아마갸루", "비주얼계", "고스 블랙립", "펑크 블랙립", "비닐 블랙립", "잉크 블랙립"]}
ALL = [k for k in mk]
LV = {"P0": [], "low": ["P3", "P5", "P8"], "mid": ["P15", "P25", "P50"], "high": ["P100", "P150"]}
CAT = {"kr": "🏺 Living Artifact · Korean Face Formula", "cn": "🏺 Living Artifact · Chinese Face Formula", "jp": "🏺 Living Artifact · Japanese Face Formula"}
byl = collections.defaultdict(list)
for x in faces: byl[x["meta"]["piercing"]].append(x)
out = []
for nat, kr, cd in NATS:
    # 40개: 피어싱 쿼터 P0 6 / low 10 / mid 18 / high 6, 메이크업 없음 10, 강화형 15 / 포인트형 15
    plan = ["P0"] * 6 + ["low"] * 10 + ["mid"] * 18 + ["high"] * 6; rr.shuffle(plan)
    ages = [AGES[(i + len(out) // 40) % 3] for i in range(40)]; rr.shuffle(ages)
    nomk = set(rr.sample(range(40), 10))
    # 고단계 6개는 어두운 메이크업, 나머지는 친화 목록에서
    for i in range(40):
        cls = plan[i]; grp = ages[i]
        if i in nomk and cls == "high": nomk.discard(i)
        if i in nomk: m = None
        elif cls == "high": m = rr.choice([k for k in AFF[cd] if k in C.DARK])
        else:
            lst = [k for k in AFF[cd] if (k in C.DARK) == (rr.random() < 0.22)] or AFF[cd]
            if rr.random() > 0.8: lst = [k for k in ALL if k not in C.DARK]
            m = rr.choice(lst)
        pool = DARK_EX if (m in C.DARK) else EX[grp]
        pool = [e for e in pool if e in EX[grp]] or [e for e in pool]
        cnt = collections.Counter(p["meta"]["expression"] for p in out)
        mn = min(cnt.get(x, 0) for x in pool); e = rr.choice([x for x in pool if cnt.get(x, 0) == mn])
        p0 = cls == "P0"
        lv = "P0" if p0 else rr.choice(LV[cls])
        src = rr.choice(byl[lv] if not p0 else faces)
        intense = (m is not None) and rr.random() < 0.5
        t = C.build2(src, nat, grp, e, m, mk, rr, intense=intense, p0=p0)
        jw = "Jewelry:" in t
        mkl = f"메이크업 {m}{'(강화)' if intense else ''}" if m else "메이크업 없음"
        n = len([p for p in out if p["meta"]["nat"] == cd]) + 1
        title = f"{nat} Face Solo #{n:02d} ({kr} · {grp} · {e} · {lv}{' · 쥬얼리' if jw else ''} · {mkl}{' · 태운 피부' if m in C.TAN_STYLES else ''})"
        out.append({"key": f"la_cjkface_{cd}_solo_{n:02d}", "category": CAT[cd], "title": title, "prompt": t,
                    "meta": {"group_size": 1, "aspect_ratio": "2:3", "format": "cjk-face", "nat": cd, "age_group": grp, "expression": e, "piercing": lv,
                             "jewelry": jw, "makeup": m, "makeup_mode": ("intense" if intense else "accent") if m else None, "tan": m in C.TAN_STYLES, "source": src["key"]}})
json.dump(out, open(O + "la_cjk_face_120_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(out), len(set(p["key"] for p in out)))
for k in ("nat", "age_group", "piercing", "expression", "makeup", "makeup_mode", "jewelry", "tan"):
    print(k, sorted(collections.Counter(str(p["meta"][k]) for p in out).items()))
print("dark+high", sum(1 for p in out if p["meta"]["piercing"] in ("P100","P150") and p["meta"]["makeup"] in C.DARK))
