# -*- coding: utf-8 -*-
# 목재·석재 혼합 v2 240 (듀오~5인 각 60): 목재 300 + 석재 300, 각 소재 솔로~5인 60개.
# 부피 큰 체형 · 인종/메이크업(얼굴은 살색, 장식 없음) · 최장 네일 · 소재 표면 패턴 · 몸 주얼리 · 최극단 힐(듀오 이상 40인치, 솔로 40인치/숫자 없음 혼합) · 밝은 배경 + 와이드샷
import re, json, random, collections
src = open("gen_woodstone_trio2.py", encoding="utf-8").read()
exec(src[:src.index("sel = []")])
O = "/mnt/user-data/outputs/"
BIG5 = [ns["PH0"][k] for k in (2, 4, 5, 0, 6)]   # BBW, amazon, latina curves, super hourglass, hourglass bombshell
W5 = [0.34, 0.2, 0.16, 0.14, 0.16]
TYPEN = {1: "solo", 2: "duo", 3: "trio", 4: "quartet", 5: "quintet"}; TKO = {1: "솔로", 2: "듀오", 3: "트리오", 4: "4인", 5: "5인"}
rr = random.Random(20261017); out = []; seen = set()
CAT = "🏺 Living Artifact · Wood-Stone Mix v2"
for n in range(2, 6):
    for k in range(1, 61):
        for attempt in range(120):
            w = rr.randint(1, n - 1); kinds = ["wood"] * w + ["stone"] * (n - w); rr.shuffle(kinds)
            wp = rr.sample(WOODS, w); sp = rr.sample(STONES, n - w); picks = [wp.pop() if kd == "wood" else sp.pop() for kd in kinds]
            physs = []
            while len(physs) < n:
                c = rr.choices(BIG5, W5)[0]
                if c not in physs: physs.append(c)
            ages = [rr.choice(AGES) for _ in range(n)]; poses = [rr.choice(POSES) for _ in range(n)]; eths = rr.sample(ETH, n)
            si = rr.randrange(8); MODE = "num"; JEWEL = True; JR.seed(rr.randrange(10**9))
            t, infos = build(kinds, picks, physs, ages, poses, eths, SETS[si])
            try: check(f"mix{n}_{k}", t)
            except AssertionError: continue
            if re.search(r"\b(\w+) \1\b", t) or re.search(r"[가-힣]", t) or t in seen: continue
            break
        else: raise SystemExit(f"fail {n} {k}")
        seen.add(t)
        pn = " / ".join(f"{'목재' if kd == 'wood' else '석재'} {p_[0]}" for kd, p_ in zip(kinds, picks)); pb = ", ".join(x[0] for x in physs); eb = ", ".join(e[0] for e in eths); mk = " ‖ ".join(infos)
        out.append({"key": f"la_wsmix_{TYPEN[n]}_{k:02d}", "category": CAT,
                    "title": f"WoodStone Mix {TYPEN[n].capitalize()} #{k:02d} (목재+석재 {TKO[n]} · {pn} · 체형 {pb} · 인종 {eb} · {mk} · 배경 {SETKO[si]} · 힐 40인치 · 몸 주얼리)",
                    "prompt": t, "meta": {"group_size": n, "aspect_ratio": ASP[n], "format": "woodstone_mix2", "material": "mixed", "kinds": kinds, "species": [x[0] for x in picks], "physiques": [x[0] for x in physs],
                                          "ethnicity": [e[0] for e in eths], "background": SETKO[si], "heel_mode": "forty", "jewelry": True}})
assert len(out) == 240 and len({p["key"] for p in out}) == 240
for p in out: assert not re.search(r"[가-힣]", p["prompt"]) and p["prompt"].count("forty inches") == p["meta"]["group_size"]
json.dump(out, open(O + "la_wsmix2_240_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(out), collections.Counter(p["meta"]["group_size"] for p in out))
print(collections.Counter(tuple(sorted(set(p["meta"]["kinds"]))) for p in out), collections.Counter(p["meta"]["kinds"].count("wood") for p in out))
print("len", min(len(p["prompt"].split()) for p in out), max(len(p["prompt"].split()) for p in out))
