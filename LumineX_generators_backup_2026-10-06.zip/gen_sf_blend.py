# -*- coding: utf-8 -*-
# 실버폭스 Material Blend 180: 등록된 la_matblend3/4 (geo_180 + replace_134 적용본) → K 90 + I 90. 경계 문장은 등록본 그대로.
import json, random, re, sys, collections
sys.path.insert(0, "/tmp/claude-0/-home-claude/62db5eea-2487-540b-9935-a7df06448e2a/scratchpad/sfv2")
import sf_blend_lib as L, apply_face_k as F
O = "/mnt/user-data/outputs/"
src = json.load(open(O + "la_matblend_geo_180_bundle.json", encoding="utf-8"))
rep = {x["key"]: x for x in json.load(open(O + "la_matblend_replace_134_bundle.json", encoding="utf-8"))}
eff = [rep.get(x["key"], x) for x in src]
rr = random.Random(20261007)
CAT = {"K": "🏺 Living Artifact · K-Silverfox Material Blend Formula", "I": "🏺 Living Artifact · Silverfox Material Blend Formula"}
PFX = {"K": "la_ksilverfox_blend", "I": "la_silverfox_blend"}
NM = {1: "solo", 2: "duo", 3: "trio"}; NMT = {1: "Solo", 2: "Duo", 3: "Trio"}
out = []
for gs in (1, 2, 3):
    pool = [x for x in eff if x["meta"]["group_size"] == gs]
    kinds = {}
    for mc in (3, 4):
        grp = [x for x in pool if x["meta"]["mix_count"] == mc]
        # 종횡비까지 균형: (종횡비)별로 K/I 반반
        for ar in ("2:3", "3:4", "4:5"):
            g = [x for x in grp if x["meta"]["aspect_ratio"] == ar]; rr.shuffle(g)
            for i, x in enumerate(g): kinds[x["key"]] = "K" if i % 2 == 0 else "I"
    # 종류별 균형 보정(30/30)
    ks = [k for k, v in kinds.items() if v == "K"]; is_ = [k for k, v in kinds.items() if v == "I"]
    while len(ks) > 30: k = ks.pop(); kinds[k] = "I"; is_.append(k)
    while len(is_) > 30: k = is_.pop(); kinds[k] = "K"; ks.append(k)
    cnt = {"K": 0, "I": 0}
    for x in pool:
        kd = kinds[x["key"]]; cnt[kd] += 1
        t, n = L.convert_prompt(x["prompt"].replace("formations formations", "formations"), kd, rr.randrange(10**9)); assert n == gs
        title = x["title"].replace("Material Blend", ("K-Silverfox" if kd == "K" else "Silverfox") + " Material Blend", 1)
        title = title.replace("(", "(" + ("한국" if kd == "K" else "국제") + " · ", 1)
        out.append({"key": f"{PFX[kd]}_{NM[gs]}_{cnt[kd]:02d}", "category": CAT[kd], "title": title, "prompt": t,
                    "meta": {**x["meta"], "format": "silverfox-blend", "kind": kd, "source": x["key"]}})
# 번호 정렬: 같은 종류·인원 안에서는 소스 순서(3혼합→4혼합) 유지
for p in out:
    if p["meta"]["kind"] == "K" and p["meta"]["group_size"] <= 2:
        t, n = F.apply(p["prompt"]); assert n == p["meta"]["group_size"], p["key"]; p["prompt"] = t
json.dump(out, open(O + "la_silverfox_blend_180_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(out), collections.Counter((p["meta"]["kind"], p["meta"]["group_size"], p["meta"]["mix_count"]) for p in out))
print(len(set(p["key"] for p in out)), len(set(p["meta"]["source"] for p in out)))
