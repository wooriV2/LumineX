# -*- coding: utf-8 -*-
# 한국형 번들의 피부 문구(warm golden-olive)를 B/C/D 3종으로 인물별 무작위 교체. 입력: bundle_v2_preskin.json
import json, random, re, collections
OLD = "luminous warm golden-olive complexion"
SKIN = {"B": "luminous fair porcelain complexion with a neutral-rose undertone and clear glass-skin glow",
        "C": "luminous light-neutral complexion with a soft peach-beige undertone",
        "D": "luminous milky ivory-fair complexion with a cool-neutral undertone and smooth dewy skin"}
src = "bundle_v2_preskin.json"; dst = "/mnt/user-data/outputs/la_silverfox_600_bundle.json"
N = json.load(open(src, encoding="utf-8")); cnt = collections.Counter()
for p in N:
    if p["meta"]["kind"] != "K": continue
    r = random.Random("skin" + p["key"]); parts = p["prompt"].split(OLD)
    out = parts[0]
    for rest in parts[1:]:
        k = r.choice("BCD"); cnt[k] += 1; out += SKIN[k] + rest
    p["prompt"] = out
json.dump(N, open(dst, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(cnt)
