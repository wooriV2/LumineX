# -*- coding: utf-8 -*-
# 목재·석재 포뮬러 v2 600: 목재 300 + 석재 300, 각 소재 솔로~5인 60개.
# 부피 큰 체형 · 인종/메이크업(얼굴은 살색, 장식 없음) · 최장 네일 · 소재 표면 패턴 · 몸 주얼리 · 최극단 힐(듀오 이상 40인치, 솔로 40인치/숫자 없음 혼합) · 밝은 배경 + 와이드샷
import re, json, random, collections
src = open("gen_woodstone_trio2.py", encoding="utf-8").read()
exec(src[:src.index("sel = []")])
O = "/mnt/user-data/outputs/"
BIG5 = [ns["PH0"][k] for k in (2, 4, 5, 0, 6)]   # BBW, amazon, latina curves, super hourglass, hourglass bombshell
W5 = [0.34, 0.2, 0.16, 0.14, 0.16]
TYPEN = {1: "solo", 2: "duo", 3: "trio", 4: "quartet", 5: "quintet"}; TKO = {1: "솔로", 2: "듀오", 3: "트리오", 4: "4인", 5: "5인"}
rr = random.Random(20261016); out = []; seen = set()
for kind, pool, cat, kname in [("wood", WOODS, "🏺 Living Artifact · Wood Formula v2", "목재"), ("stone", STONES, "🏺 Living Artifact · Stone Formula v2", "석재")]:
    for n in range(1, 6):
        for k in range(1, 61):
            for attempt in range(80):
                picks = rr.sample(pool, n)
                physs = []
                while len(physs) < n:
                    c = rr.choices(BIG5, W5)[0]
                    if c not in physs: physs.append(c)
                ages = [rr.choice(AGES) for _ in range(n)]; poses = [rr.choice(POSES) for _ in range(n)]; eths = rr.sample(ETH, n)
                si = rr.randrange(8)
                MODE = "num" if (n >= 2 or rr.random() < 0.5) else "rel"; JEWEL = True; JR.seed(rr.randrange(10**9))
                t, infos = build([kind] * n, picks, physs, ages, poses, eths, SETS[si])
                try: check(f"{kind}{n}_{k}", t)
                except AssertionError: continue
                if re.search(r"\b(\w+) \1\b", t) or re.search(r"[가-힣]", t) or t in seen: continue
                break
            else: raise SystemExit(f"fail {kind} {n} {k}")
            seen.add(t)
            pnames = " / ".join(p_[0] for p_ in picks); pb = ", ".join(x[0] for x in physs); eb = ", ".join(e[0] for e in eths); mk = " ‖ ".join(infos)
            heel_ko = "힐 40인치" if MODE == "num" else "힐 숫자 없음"
            out.append({"key": f"la_{kind}2_{TYPEN[n]}_{k:02d}", "category": cat,
                        "title": f"{kind.capitalize()}2 {TYPEN[n].capitalize()} #{k:02d} ({kname} {TKO[n]} · {pnames} · 체형 {pb} · 인종 {eb} · {mk} · 배경 {SETKO[si]} · {heel_ko} · 몸 주얼리)",
                        "prompt": t, "meta": {"group_size": n, "aspect_ratio": ASP[n], "format": "woodstone2", "material": kind, "species": [x[0] for x in picks], "physiques": [x[0] for x in physs],
                                              "ethnicity": [e[0] for e in eths], "background": SETKO[si], "heel_mode": "forty" if MODE == "num" else "relative", "jewelry": True}})
assert len(out) == 600 and len({p["key"] for p in out}) == 600
for p in out: assert not re.search(r"[가-힣]", p["prompt"])
json.dump(out, open(O + "la_woodstone2_600_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(out), collections.Counter(p["meta"]["group_size"] for p in out), collections.Counter(p["meta"]["heel_mode"] for p in out))
print(collections.Counter(x for p in out for x in p["meta"]["physiques"]).most_common())
print(len(collections.Counter(x for p in out for x in p["meta"]["species"])), "species;", "len", min(len(p["prompt"].split()) for p in out), max(len(p["prompt"].split()) for p in out))
