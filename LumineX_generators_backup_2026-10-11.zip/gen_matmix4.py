# -*- coding: utf-8 -*-
# 새 재질 6종(옥·도자기·청동 녹청·옻칠·호박 수지·산호·진주조개) 솔로 시험 — v2 틀(부피 큰 체형·메이크업만·몸 주얼리·40인치 힐·밝은 배경)
import re, random
src = open("gen_woodstone_full10.py", encoding="utf-8").read()
exec(src[:src.index("PLAN = [")])
exec(open("gen_woodstone2_600.py", encoding="utf-8").read().split("TYPEN =")[0].split("exec(src[:src.index(\"sel = []\")])")[1].split("\n",1)[1].split("O = ")[0]) if False else None
# 주얼리 모듈(v2에서 쓰는 것) 가져오기
s2 = open("gen_woodstone_trio2.py", encoding="utf-8").read()
ns2 = {}
exec(s2[:s2.index("sel = []")], ns2)
JR = ns2["JR"]; person_v2 = ns2["person"]; build_v2 = ns2["build"]
# v2 build/person 을 그대로 쓰되 재질 문장만 갈아끼운다
NEW = {
 "jade": ("jade", "polished carved imperial jade", "jade", "jade",
          "BLAZING deep imperial-green jade surface across the full torso both legs neck to ankle", "VIVID pale celadon veins and creamy white cloud-like flecks running between the sections", "high-gloss polished"),
 "porcelain": ("porcelain", "glazed blue-and-white porcelain", "glazed porcelain", "porcelain",
          "BLAZING glossy white glaze painted with cobalt-blue dragons, clouds and waves across the full torso both legs neck to ankle", "VIVID deep cobalt-blue borders and fine crackle lines running between the sections", "high-gloss glazed"),
 "bronze": ("bronze", "aged ancient bronze", "cast bronze", "bronze",
          "BLAZING warm copper-gold bronze metal across the full torso both legs neck to ankle", "VIVID turquoise-green verdigris patina gathering in every recess and joint", "satin-polished raised edges"),
 "lacquer": ("lacquer", "glossy urushi lacquer", "lacquered", "lacquer",
          "BLAZING deep vermilion-red urushi lacquer across the full torso both legs neck to ankle", "VIVID jet-black lacquer panels with fine gold maki-e flowers and cranes between the sections", "mirror-gloss lacquered"),
 "amber": ("amber", "polished honey amber resin", "amber resin", "amber",
          "BLAZING warm honey-orange amber surface across the full torso both legs neck to ankle", "VIVID deeper red-brown swirls and tiny golden bubbles flowing through every section", "high-gloss polished"),
 "coral": ("coral", "carved pink coral and iridescent mother-of-pearl", "coral and shell", "coral and mother-of-pearl",
          "BLAZING coral-pink branching coral relief across the full torso both legs neck to ankle", "VIVID iridescent pearl-white nacre sections shimmering pink, green and violet between the coral", "high-gloss polished"),
}
def person_new(label, key, phys, age, pose, eth):
    nm, desc, solid, nmw, base, acc, fin = NEW[key]; pn, pd = phys; p = f"{label}: " if label else ""
    pat = rr.choice(PAT)
    mat = (f"full body {desc} fused directly to her own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, this is solid {solid} curving to follow her body's true three-dimensional shape, divided into dozens of fitted {nm} sections, each joint standing in a thin raised ridge catching its own bright glint and casting its own small shadow, nothing lying flat. Dense fitted sections — {base}, {acc}, with {pat}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    feat, seg, info = face(eth); skin = eth[1]
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of the same {nmw}, each with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, made of the same {nmw} with a high polish."
    fc = f"{p}Face: her face and ears are NOT {nm} — they are real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair()} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    return "\n".join([body, shoe, nails, jw, fc]), info

BIG5 = [ns["PH0"][k] for k in (2, 4, 5, 0, 6)]
ETHALL = ETH
ns2["JEWEL"] = True; ns2["MODE"] = "num"
orig_person = ns2["person"]
def disp(label, kind, pick, phys, age, pose, eth, heel_in):
    if kind in NEW:
        t, info = person_new(label, kind, phys, age, pose, eth); return t, info, NEW[kind][3]
    return orig_person(label, kind, pick, phys, age, pose, eth, heel_in)
ns2["person"] = disp
build2 = ns2["build"]
W5 = [0.34, 0.2, 0.16, 0.14, 0.16]
rg = random.Random(20261010)
PLAN = [("duo", ["jade", "porcelain"]), ("trio", ["bronze", "lacquer", "amber"]), ("quartet", ["coral", "jade", "porcelain", "lacquer"]), ("quintet", ["wood", "stone", "coral", "bronze", "amber"])]
o = ["# 재질 섞기 시험 — 듀오 · 트리오 · 4인 · 5인 (4개)\n",
     "한 장면에서 인물마다 다른 재질을 입힌 구성입니다(번호가 붙은 인물 = 재질 하나). 틀은 v2와 같고(부피 큰 체형, 메이크업만, 몸 주얼리, 40인치 힐, 밝은 배경) 5인 컷은 목재·석재까지 같이 섞었습니다. 번호별로 정상/이상만 알려주세요. 이상이면 한 줄(예: 재질이 서로 번짐, 한 사람 재질이 빠짐, 얼굴이 재질이 됨).\n"]
for i, (g, kinds) in enumerate(PLAN, 1):
    n = len(kinds)
    for attempt in range(100):
        physs = []
        while len(physs) < n:
            c = rg.choices(BIG5, W5)[0]
            if c not in physs: physs.append(c)
        picks = [rg.choice(WOODS) if k == "wood" else rg.choice(STONES) if k == "stone" else None for k in kinds]
        ages = [rg.choice(AGES) for _ in range(n)]; poses = [rg.choice(POSES) for _ in range(n)]; eths = rg.sample(ETH, n)
        si = rg.randrange(8); ns2["JR"].seed(rg.randrange(10**9))
        t, infos = build2(kinds, picks, physs, ages, poses, eths, SETS[si])
        if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t): continue
        break
    else: raise SystemExit("fail")
    assert t.count("forty inches") == n and t.count("Jewelry:") == n, (t.count("forty inches"), t.count("Jewelry:"))
    mats = " / ".join(k if k in NEW else f"{k} {p[0]}" for k, p in zip(kinds, picks))
    o.append(f"## {i}. {g} · {mats} · 체형 {', '.join(x[0] for x in physs)} · 인종 {', '.join(e[0] for e in eths)} · {' ‖ '.join(infos)} · 배경 {SETKO[si]}\n\n```\n{t}\n```\n"); print(i, g, mats, len(t.split()))
open(O + "LumineX_MatMix4.md", "w", encoding="utf-8").write("\n".join(o))
