# -*- coding: utf-8 -*-
# Persona Mix 300: 컨셉(재질 짝짓기) · 새 포즈 · 보호 스타일 헤어 · 메두사 뱀 머리 · 앵글 5종을 섞은 번들
import re, random, sys, json, collections
sys.path.insert(0, "../bg")
src6 = open("gen_persona6.py", encoding="utf-8").read()
exec(src6[:src6.index("PERS = {}")])
rg = random.Random(20261020)
PERS = {}
orig_disp3 = disp3
SNAKE = "a mass of dozens of thick coiling snakes carved from the same {m}, each snake with a detailed head, open eyes and a flicking tongue, writhing around her head and falling down her back, the snakes are her hair"
def disp4(label, kind, pick, phys, age, pose, eth, heel_in):
    pe = PERS.get(label)
    HAIRO[0] = pe[1] if pe else None
    t, info, nm = orig_disp3(label, kind, pick, phys, age, pose, eth, heel_in)
    if pe and pe[1] and kind not in NEWV and kind not in PAINT:
        t, n = re.subn(r', ([^,—]+?) hair — ', f', {pe[1]} — ', t, count=1); assert n == 1
    if pe and pe[0]:
        t, n = re.subn(r" goddess, ", f", {pe[0]}, ", t, count=1); assert n == 1
    return t, info, nm
ns2["person"] = disp4
CAMD = {"base": ("기본(허리 높이)", None),
 "high": ("하이앵글 70도", "Full-length steep high-angle shot taken from far above with a long telephoto lens, the camera directly above and in front of her angled roughly seventy degrees downward as if from a high ceiling or drone, flat telephoto compression with natural proportions and no wide-angle distortion, the whole figure from head to boots fully visible,"),
 "side": ("측면", "Full-length side view with the camera at waist height, her body in clean profile,"),
 "low": ("극단 로우앵글", "Full-length EXTREME worm's-eye view shot with the camera placed on the floor at boot level and tilted steeply upward, the towering heels and boots huge in the foreground, her legs rising in exaggerated perspective and her head far above at the top of the frame,"),
 "tq": ("극단 3/4 앵글", "Full-length EXTREME three-quarter view from the far front-left, her whole body turned a full sixty degrees away from the camera with her shoulders and hips twisted, the camera at waist height and pushed close for strong foreshortening,")}
CAMBASE = "Full-length wide shot from a moderate distance with the camera at waist height,"
def pick_angle(n):
    if n >= 4: ks, ws = ["base", "high", "side"], [55, 30, 15]
    else: ks, ws = ["base", "high", "low", "side", "tq"], [38, 20, 15, 15, 12]
    return rg.choices(ks, ws)[0]
ETHD = {e[0]: e for e in ETH}
CAT = "🏺 Living Artifact · Persona Mix Formula"
def draw_picks(kinds):
    picks = []
    for idx, k in enumerate(kinds):
        lab = f"#{idx+1}" if len(kinds) > 1 else None
        if k == "bodypaint": picks.append(rg.choice(BP))
        elif k == "irezumi": picks.append(rg.choice(IR))
        elif k == "uvneon": picks.append(rg.choice(UV))
        elif k == "wood": picks.append(rg.choice(WOODS))
        elif k == "stone": picks.append(rg.choice(STONES))
        else:
            v = rg.choice(NEWV[k]); CUR_VAR[(lab, k)] = v; picks.append(v)
    return picks
def pick_name(k, p):
    if k in NEWV: return f"{KO[k]} {p[7]}"
    if k == "wood": return f"목재 {p[0]}"
    if k == "stone": return f"석재 {p[0]}"
    return KO[k]
out = []; seen = set()
for n in range(1, 6):
    for kk in range(1, 61):
        for attempt in range(400):
            if n == 1: kinds = [NEWKINDS[(kk - 1) % 6]]
            else:
                kinds = [rg.choice(NEWKINDS)]
                pool = [x for x in ALLK if x != kinds[0]]
                kinds += rg.sample(pool, n - 1); rg.shuffle(kinds)
                if len(set(kinds)) < n: continue
            PERS.clear(); CUR_VAR.clear()
            picks = draw_picks(kinds)
            ang = pick_angle(n)
            # 컨셉·인종 배정: 컨셉이 있는 재질은 80% 확률, 인종이 겹치면 컨셉 생략
            used = []; eths = [None] * n; concepts = [None] * n
            for idx, k in enumerate(kinds):
                if k in P and rg.random() < 0.8:
                    ko, en, ethn = rg.choice(P[k])
                    if ethn not in used: used.append(ethn); eths[idx] = ETHD[ethn]; concepts[idx] = (ko, en)
            rest = [e for e in ETH if e[0] not in used]; rg.shuffle(rest)
            for idx in range(n):
                if eths[idx] is None: eths[idx] = rest.pop()
            infos_p = []
            for idx, k in enumerate(kinds):
                lab = f"#{idx+1}" if n > 1 else None
                ethn = eths[idx][0]; con = concepts[idx]; hb = None
                if ethn in ("ebony", "blue-black"): hb = rg.choice(HAIRB)
                if con and con[0] == "메두사": hb = SNAKE.format(m=picks[idx][1])
                if con or hb: PERS[lab] = (con[1] if con else None, hb)
                tag = [KO[k] + (f"={con[0]}" if con else "")]
                if hb: tag.append("뱀 머리" if (con and con[0] == "메두사") else hb.split(" in ")[0])
                infos_p.append("·".join(tag))
            physs = []
            while len(physs) < n:
                c = rg.choices(BIG5, W5)[0]
                if c not in physs: physs.append(c)
            ages = [rg.choice(AGES) for _ in range(n)]
            okp = [p for p in NEWPOSES if not (ang != "base" and ("camera" in p or "back" in p))]
            poses = rg.sample(okp, n)
            bid, wx = BGL.pick(rg, n); scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
            HEELMODE[0] = "forty" if (n >= 2 or rg.random() < 0.55) else "relative"
            ns2["JR"].seed(rg.randrange(10**9))
            t, infos = build3(kinds, picks, physs, ages, poses, eths, scene)
            t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as " + ("her" if n == 1 else "any of them") + ".", 1)
            if CAMD[ang][1]:
                t, nn = re.subn(re.escape(CAMBASE), CAMD[ang][1], t, count=1)
                if nn != 1: continue
            if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t) or t in seen: continue
            fort = t.count("forty inches"); assert fort == (n if HEELMODE[0] == "forty" else 0), (fort, n, HEELMODE)
            assert t.count("Jewelry:") == n and "completely empty of other people" in t
            break
        else: raise SystemExit(f"fail {n} {kk}")
        seen.add(t)
        mats = " / ".join(f"{pick_name(k, p)}" for k, p in zip(kinds, picks))
        hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
        out.append({"key": f"la_pm_{TYPEN[n]}_{kk:02d}", "category": CAT,
                    "title": f"PersonaMix {TYPEN[n].capitalize()} #{kk:02d} ({TKO[n]} · {' / '.join(infos_p)} · {mats} · 앵글 {CAMD[ang][0]} · 체형 {', '.join(x[0] for x in physs)} · 인종 {', '.join(e[0] for e in eths)} · {' ‖ '.join(infos)} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko} · 몸 주얼리)",
                    "prompt": t, "meta": {"group_size": n, "aspect_ratio": ASP[n], "format": "personamix", "kinds": kinds, "concepts": [c[0] if c else None for c in concepts], "angle": ang, "poses": poses,
                                          "physiques": [x[0] for x in physs], "ethnicity": [e[0] for e in eths], "background": bid, "weather": wx[0] if wx else None,
                                          "heel_mode": HEELMODE[0], "jewelry": True}})
assert len(out) == 300 and len({p["key"] for p in out}) == 300
json.dump(out, open(O + "la_personamix_300_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(out), collections.Counter(p["meta"]["group_size"] for p in out))
print(collections.Counter(p["meta"]["angle"] for p in out))
print(collections.Counter(c for p in out for c in p["meta"]["concepts"]).most_common())
print(sum("coiling snakes" in p["prompt"] for p in out), "메두사 뱀 머리")
print(len({p["meta"]["background"] for p in out}), "배경 종류", min(len(p["prompt"].split()) for p in out), max(len(p["prompt"].split()) for p in out))
