# -*- coding: utf-8 -*-
# 컨셉(재질 짝짓기) + 포즈 확장 + 헤어 확장 시험 6개 (새 재질 솔로 4 + 듀오 2)
import re, random, sys, json
sys.path.insert(0, "../bg")
src = open("gen_matmix_bundle.py", encoding="utf-8").read()
exec(src[:src.index("rg = random.Random(20261012)")])
rp = random.Random(20261017)
NEWPOSES = ["hands on her hips in a powerful stance, chin lifted, weight on one leg",
            "mid-stride runway walk toward the camera, shoulders back, one boot crossing in front of the other",
            "walking away with her back to the camera, looking back over her shoulder",
            "S-curve stance, one knee bent, hip tilted out, one hand resting on her thigh",
            "arms crossed under her bust, intense gaze straight into the camera",
            "both arms raised above her head, back arched, body fully stretched",
            "leaning against a pillar with one arm resting on it, one knee bent",
            "hair streaming in the wind, one arm sweeping across her body, dynamic stance",
            "turned in full profile, back straight, chin raised",
            "back to the camera, shoulder blades emphasized, face turned in profile",
            "hands pressed together raised above her head in a devotional pose, eyes lifted"]
HAIRB = ["tight cornrows in natural black", "long box braids in deep burgundy", "a braided crown in natural black", "a voluminous natural afro in jet-black", "voluminous natural curls in dark brown", "long box braids in honey blonde", "a sculpted high braided updo in natural black", "thick twist-out curls in chestnut brown"]
HAIRO = [None]
_hair0 = hair
def hair(): return HAIRO[0] if HAIRO[0] else _hair0()
P = {  # 재질 → [(한글, 영어 컨셉 문장, 어울리는 인종)]
 "jade": [("용녀", "an Eastern dragon princess of mythology", "Chinese"), ("선녀", "a celestial maiden of Korean and Chinese legend", "Korean")],
 "porcelain": [("항아", "Chang'e, the Chinese moon goddess", "Chinese"), ("낙신", "Luoshen, the river goddess of classical Chinese legend", "Chinese")],
 "bronze": [("발키리", "a Valkyrie of Norse legend", "Slavic"), ("아마조네스", "an Amazon warrior queen of ancient legend", "Latina")],
 "lacquer": [("경국지색", "a legendary Eastern beauty said to topple nations", "Japanese")],
 "amber": [("오슌", "Oshun, the golden Yoruba goddess of rivers and love", "ebony"), ("클레오파트라", "Cleopatra, the queen of ancient Egypt", "Middle Eastern")],
 "coral": [("예마야", "Yemaya, the Yoruba ocean mother goddess", "blue-black")],
 "stone": [("메두사", "a Medusa-like goddess of Greek myth", "Slavic")]}
PERS = {}
orig_disp3 = disp3
def disp4(label, kind, pick, phys, age, pose, eth, heel_in):
    pe = PERS.get(label)
    HAIRO[0] = pe[1] if pe else None
    t, info, nm = orig_disp3(label, kind, pick, phys, age, pose, eth, heel_in)
    if pe and kind not in NEWV and kind not in PAINT and pe[1]:
        t, n = re.subn(r', ([^,—]+?) hair — ', f', {pe[1]} — ', t, count=1); assert n == 1
    if pe:
        t, n = re.subn(r" goddess, ", f", {pe[0]}, ", t, count=1); assert n == 1
    return t, info, nm
ns2["person"] = disp4
ETHD = {e[0]: e for e in ETH}
PLAN = [(["jade"], ["base"]), (["bronze"], ["high"]), (["amber"], ["side"]), (["coral"], ["low"]), (["porcelain", "lacquer"], ["tq"]), (["amber", "stone", "jade"], ["base"])]
CAMD = {"base": ("기본(허리 높이)", None),
 "high": ("하이앵글 70도", "Full-length steep high-angle shot taken from far above with a long telephoto lens, the camera directly above and in front of her angled roughly seventy degrees downward as if from a high ceiling or drone, flat telephoto compression with natural proportions and no wide-angle distortion, the whole figure from head to boots fully visible,"),
 "side": ("측면", "Full-length side view with the camera at waist height, her body in clean profile,"),
 "low": ("극단 로우앵글", "Full-length EXTREME worm's-eye view shot with the camera placed on the floor at boot level and tilted steeply upward, the towering heels and boots huge in the foreground, her legs rising in exaggerated perspective and her head far above at the top of the frame,"),
 "tq": ("극단 3/4 앵글", "Full-length EXTREME three-quarter view from the far front-left, her whole body turned a full sixty degrees away from the camera with her shoulders and hips twisted, the camera at waist height and pushed close for strong foreshortening,")}
o = ["# 컨셉(재질 짝짓기) · 포즈 확장 · 헤어 확장 시험 · 앵글 포함 번들 시제 (6개)\n",
     "재질에 어울리는 신화 컨셉을 '여신' 자리에 넣고(의상 묘사 없이 이름과 한 줄 소개만), 인종도 컨셉에 맞췄고, 포즈는 새 서 있는 포즈에서, 흑인 인물은 보호 스타일 헤어(코르넬로·박스 브레이드 등)를 넣었습니다. 번호별로 정상/이상만 알려주세요. 이상이면 한 줄(예: 날개·옷 같은 게 생김, 재질이 안 덮임, 포즈 이상, 컨셉이 얼굴을 바꿈).\n"]
for i, (kinds, _) in enumerate(PLAN, 1):
    n = len(kinds)
    for attempt in range(100):
        _ang = _[0]; PERS.clear(); CUR_VAR.clear(); eths = []; picks = []; infos_p = []
        for idx, k in enumerate(kinds):
            lab = f"#{idx+1}" if n > 1 else None
            ko, en, ethn = rp.choice(P[k]); eth = ETHD[ethn]; eths.append(eth)
            if k in NEWV: v = rp.choice(NEWV[k]); CUR_VAR[(lab, k)] = v; picks.append(v)
            else: picks.append(rp.choice(STONES) if k == "stone" else rp.choice(WOODS))
            hb = rp.choice(HAIRB) if ethn in ("ebony", "blue-black") else None
            if k == "stone": hb = "a mass of dozens of thick coiling snakes carved from the same " + picks[-1][1] + ", each snake with a detailed head, open eyes and a flicking tongue, writhing around her head and falling down her back, the snakes are her hair"
            PERS[lab] = (en, hb); infos_p.append(f"{KO[k]}={ko}" + (f"·{'뱀 머리' if k=='stone' else hb.split(' in ')[0]}" if hb else ""))
        physs = []
        while len(physs) < n:
            c = rp.choices(BIG5, W5)[0]
            if c not in physs: physs.append(c)
        ages = [rp.choice(AGES) for _ in range(n)]; poses = rp.sample([p for p in NEWPOSES if not (_ang in ('side','tq','low','high') and ('camera' in p or 'back' in p))], n)
        bid, wx = BGL.pick(rp, n); scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty"; ns2["JR"].seed(rp.randrange(10**9))
        t, infos = build3(kinds, picks, physs, ages, poses, eths, scene)
        t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as " + ("her" if n == 1 else "any of them") + ".", 1)
        if CAMD[_ang][1]:
            t, nn = re.subn(r"Full-length wide shot from a moderate distance with the camera at waist height,", CAMD[_ang][1], t, count=1); assert nn == 1
        if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t): continue
        break
    else: raise SystemExit("fail")
    assert t.count("forty inches") == n and t.count("Jewelry:") == n
    o.append(f"## {i}. {({1:'솔로',2:'듀오',3:'트리오'})[n]} · {' / '.join(infos_p)} · 앵글 {CAMD[_ang][0]} · 인종 {', '.join(e[0] for e in eths)} · 포즈 {' / '.join(p.split(',')[0] for p in poses)} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''}\n\n```\n{t}\n```\n"); print(i, infos_p, len(t.split()))
open(O + "LumineX_Mix6.md", "w", encoding="utf-8").write("\n".join(o))
