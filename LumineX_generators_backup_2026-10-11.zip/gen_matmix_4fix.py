# -*- coding: utf-8 -*-
exec(open("gen_matmix_all4.py", encoding="utf-8").read())   # 같은 시드 → 4번 프롬프트(t)와 scene 재현 (MatMixAll4.md 도 같은 내용으로 다시 기록됨)
t4, scene4 = t, scene
def mk(kinds, scene_):
    n = len(kinds)
    for attempt in range(200):
        physs = []
        while len(physs) < n:
            c = rg.choices(BIG5, W5)[0]
            if c not in physs: physs.append(c)
        picks = [rg.choice(WOODS) if k == "wood" else rg.choice(STONES) if k == "stone" else None for k in kinds]
        ages = [rg.choice(AGES) for _ in range(n)]; poses = [rg.choice(POSES) for _ in range(n)]; eths = rg.sample(ETH, n)
        ns2["JR"].seed(rg.randrange(10**9))
        tt, infos = build2(kinds, picks, physs, ages, poses, eths, scene_)
        tt = tt.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as any of them.", 1)
        if re.search(r"[가-힣]", tt) or re.search(r"\b(\w+) \1\b", tt): continue
        return tt, physs, eths, infos
plaza = BGL.BG["plaza"][3]
t4a = t4.replace(scene4, plaza); assert t4a != t4
t4b, ph, et, inf = mk(["wood", "stone", "bronze", "amber", "jade"], scene4)
o = ["# 5인 섞기 4번 원인 분리 시험 (2개)\n", "4번(이레즈미·바디페인팅·청동·호박·목재, 만리장성)이 안 됐던 원인을 가르기 위한 시험입니다. 번호별로 정상/이상만 알려주세요.\n",
     f"## 1. 4번과 같은 인물 5명, 배경만 도시 광장으로 교체\n\n```\n{t4a}\n```\n",
     f"## 2. 몸에 그리는 트랙 없이 재질 5명(목재·석재·청동·호박·옥), 배경은 만리장성 그대로\n\n```\n{t4b}\n```\n"]
open(O + "LumineX_MatMix_4Fix2.md", "w", encoding="utf-8").write("\n".join(o))
print(len(t4a.split()), len(t4b.split()))
