# -*- coding: utf-8 -*-
"""사람 한 명의 블록을 만드는 레시피 (재질 문장 · 신발 · 네일 · 주얼리 · 얼굴). 풀은 mdefs 에서만 가져온다."""
import re, random
import mdefs as D

HEAD = "covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE"
BOOTEND = "down to the top edge of her boots"
SPOT = ", lit by her own dedicated UV blacklight spot with zero white light reaching her specifically, every formation glowing at maximum intensity"
NOTDARK = "NOT black, NOT dark, NOT plain — the footwear must be a bright, saturated, glossy colour taken straight from her own body art"
PAINT_KINDS = {"bodypaint", "irezumi", "uvneon"}
CRAFT_KEYS = list(D.CRAFTS); SCALE_KEYS = list(D.SCALE_DB) + ["peacock"]


def _pre(t): return t if t.startswith("BLAZING") else "BLAZING " + t


def _cols(mat):
    seg = mat.split("ANYWHERE", 1)[1] if "ANYWHERE" in mat else mat
    out = []
    for r in re.findall(r"\b[A-Z]{3,}(?:[ -][A-Z]{3,})*\b", seg):
        r = r.lower()
        if r not in out and r not in ("no", "the", "and"): out.append(r)
    return out[:3]


def _cj(c): return f"{c[0]} and {c[1]}" if len(c) < 3 else f"{c[0]}, {c[1]} and {c[2]}"


# ───────── 신발 색 (본연의 단색, 몸 문양과 같은 계열, 어둡지 않게) ─────────
FAM = [("green", r"green|emerald|jade|celadon|malachite|olive|mint|sage|lime"), ("blue", r"blue|cobalt|navy|indigo|azure|cyan|turquoise|teal|sapphire|lapis|aqua"),
       ("red", r"red|crimson|scarlet|ruby|vermilion|cherry|burgundy|wine"), ("pink", r"pink|rose|magenta|blush|fuchsia"),
       ("purple", r"violet|purple|lavender|amethyst|plum|lilac|orchid"), ("orange", r"orange|copper|tangerine|rust|terracotta|amber|caramel|honey|apricot"),
       ("yellow", r"yellow|gold|golden|saffron|champagne|mustard|citrine|topaz"), ("white", r"white|cream|ivory|pearl|porcelain|alabaster|snow|clear|ice"),
       ("silver", r"silver|grey|gray|platinum|steel|pewter|quartz"), ("brown", r"brown|mahogany|walnut|chestnut|tan|bronze|tawny|wood|teak|cherrywood")]
SHC = {"green": ["emerald green", "mint green", "sage green"], "blue": ["cobalt blue", "sky blue", "turquoise"], "red": ["cherry red", "coral red", "scarlet red"],
       "pink": ["blush pink", "hot pink", "rose pink"], "purple": ["lavender", "orchid purple", "violet"], "orange": ["caramel tan", "copper-orange", "apricot"],
       "yellow": ["gold", "champagne gold", "butter yellow"], "white": ["ivory white", "pearl white", "nude beige"], "silver": ["silver", "pearl grey", "metallic platinum"],
       "brown": ["caramel tan", "cognac", "nude beige"], "none": ["cherry red", "gold", "ivory white", "nude beige"]}
METAL = {"gold", "champagne gold", "silver", "metallic platinum", "copper-orange"}


def family(mat):
    seg = mat.split("ANYWHERE", 1)[-1].lower()
    m = re.search(r"blazing ([^,]{3,120})", seg)
    for scope in ([m.group(1)] if m else []) + [seg]:
        pos = []
        for name, rx in FAM:
            mm = re.search(r"\b(?:%s)" % rx, scope)
            if mm: pos.append((mm.start(), name))
        if pos: return min(pos)[1]
    return "none"


# ───────── 재질 사양 ─────────
def mat_spec(rng, kind):
    """재질 하나를 뽑아 {text, nm, nail, track, name, [hair]} 로 돌려준다. track: paint(몸 색 그대로) / real(진짜 신발 + 계열색)"""
    if kind == "bodypaint":
        k = rng.choice(CRAFT_KEYS); cn, cd, cb, cf = D.CRAFTS[k]
        text = f"painted in {cn} — {cd}, wide {cb} bands following every deep crease, {'' if cf.startswith('dense ') else 'dense '}{cf} filling the space between bands, pigment on living skin, covering her whole body below the jaw with no bare skin anywhere, face unpainted, pattern fading at the neck"
        return dict(text=text, nm="painted", nail="painted in the same colours as her body art", track="paint", cols=cb, name=f"{D.KO[kind]} {cn}")
    if kind in ("irezumi", "uvneon"):
        n, t = rng.choice(D.IREZUMI if kind == "irezumi" else D.UVNEON)
        pre = "irezumi" if kind == "irezumi" else "UV neon"
        if kind == "irezumi": text = f"full body {n} irezumi {HEAD}. Bold black ink outlines — {_pre(t)}, NO airbrush NO gradient wash"
        else: text = f"full body UV neon {n} bodypaint {HEAD}. Bold formations — {_pre(t)}, NO airbrush NO gradient wash" + SPOT
        cols = _cj(_cols(text)) if len(_cols(text)) >= 2 else _cols(text)[0]
        return dict(text=text, nm="painted", nail="painted in the same colours as her body art" + (" with UV reactive tips" if kind == "uvneon" else ""), track="paint", cols=cols, name=f"{D.KO[kind]} {n}")
    if kind in D.NEWV:
        nm, desc, solid, nmw, base, acc, fin, tag = rng.choice(D.NEWV[kind]); pat = rng.choice(D.PAT)
        text = (f"full body {desc} fused directly to her own form {HEAD} — this is not a garment, not jewelry, not a printed pattern, this is solid {solid} curving to follow her body's true three-dimensional shape, divided into dozens of fitted {nm} sections, each joint standing in a thin raised ridge catching its own bright glint and casting its own small shadow, nothing lying flat. Dense fitted sections — {base}, {acc}, with {pat}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
        return dict(text=text, nm=nm, nail=f"made of the same {nmw} with a high polish", track="real", name=f"{D.KO[kind]} {tag}", mname=nmw, hair_kind=kind)
    if kind == "wood":
        nm, desc, base, acc = rng.choice(D.WOODS); dw = desc if desc.endswith("wood") else desc + " wood"; nmw = nm if nm.endswith("wood") else nm + " wood"; pat = rng.choice(D.PAT)
        text = (f"full body {dw} carved directly over her own form {HEAD} — this is not a garment, not a printed pattern, this is solid carved wood curving to follow her body's true three-dimensional shape, divided into dozens of fitted carved sections whose grain changes direction from one section to the next, each joint standing in a thin raised ridge catching its own soft glint and casting its own small shadow, nothing lying flat. Dense fitted sections — {base}, {acc}, with {pat}, polished to a warm satin sheen, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
        return dict(text=text, nm="carved", nail=f"carved from the same {nmw} with a high polish", track="real", name=f"{D.KO[kind]} {nm}", mname=nmw, hair_kind=kind)
    if kind == "stone":
        nm, desc, base, acc = rng.choice(D.STONES); pat = rng.choice(D.PAT)
        text = (f"full body {desc} fused directly to her own form {HEAD} — this is not a garment, not jewelry, not a printed pattern, this is solid stone curving to follow her body's true three-dimensional shape, divided into dozens of fitted stone sections, each joint standing in a thin raised ridge catching its own bright glint and casting its own small shadow, nothing lying flat. Dense fitted sections — {base}, {acc}, with {pat}, high-gloss polished, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
        return dict(text=text, nm="carved", nail=f"carved from the same {nm} with a high polish", track="real", name=f"{D.KO[kind]} {nm}", mname=nm, hair_kind=kind)
    if kind == "glass":
        c1, c2 = rng.choice(D.GLASS_COLORS)
        text = (f"full body stained glass {HEAD} — this is solid thick glass fused directly to her form, not a garment, made of hundreds of small individual panes each no larger than a coin, densely packed edge to edge, never large sheets, each tiny pane curving to follow her body's true shape with real physical thickness, dark lead-line seams webbing between every pane, each seam standing in a small raised ridge casting its own shadow, never flat. BLAZING {c1} and VIVID {c2} panes alternating in a dense irregular mosaic, bright light passing through each tiny pane with sharp refraction glints, NO airbrush NO gradient wash")
        return dict(text=text, nm="glass", nail="made of the same stained glass in the same colours with a high polish", track="real", name=f"{D.KO[kind]} {c1.lower()}")
    if kind == "goldleaf":
        c = rng.choice(D.LEAF)
        text = (f"full body applied {c} metallic leaf {HEAD}. Thin irregular metallic sheets — BLAZING {c} leaf with fine natural creases and overlapping seams laid onto the contour of her body, a bright {c} sheen filling every gap, NO airbrush NO gradient wash")
        return dict(text=text, nm="gilded", nail=f"covered in the same {c} metallic leaf with a high polish", track="real", name=f"{D.KO[kind]} {c.lower()}")
    if kind == "botanical":
        f, c1, c2 = rng.choice(D.FLOWERS)
        text = (f"full body living {f} growing directly from her own skin {HEAD} — this is not a garment, not a printed pattern, not a dress, every stem rooted directly into her living skin and every petal standing up in true three-dimensional relief casting its own small shadow, nothing lying flat. BLAZING {c1} {f} blossoms in full three-dimensional bloom, VIVID {c2} leaves and curling tendrils filling every remaining gap with real depth and texture, NO airbrush NO gradient wash, NO flat printed surface anywhere")
        return dict(text=text, nm="covered in blooms", nail=f"with tiny {f} petals embedded at each tip", track="real", name=f"{D.KO[kind]} {f}", hair="real trailing vines threaded through her hair")
    if kind == "crystal":
        c1, c2, s = rng.choice(D.CRYSTAL_COLORS)
        text = (f"full body {s} clusters growing directly out of her own skin {HEAD} — this is not a garment, not jewelry, not a printed pattern, every crystal point erupting outward from beneath the surface of her living skin in true three-dimensional relief, each facet catching its own individual glint and casting its own small hard shadow onto the skin and onto neighbouring crystals, nothing lying flat. Dense overlapping clusters — BLAZING {c1} crystal points erupting across the full torso both legs neck to ankle, VIVID {c2} mineral veins and undertone glinting through the thinnest points filling every remaining gap with real depth and texture, each facet sharply faceted and distinct, NO airbrush NO gradient wash, NO flat printed surface anywhere")
        return dict(text=text, nm="crystal", nail=f"with tiny individual {s} points erupting at each tip", track="real", name=f"{D.KO[kind]} {s}")
    if kind == "scale":
        animal = rng.choice(SCALE_KEYS)
        if animal == "peacock": shape, pals = D.PEACOCK; what = "peacock feather-eye markings"
        else: shape, pals = D.SCALE_DB[animal]; what = f"{animal} scales"
        c1, c2 = rng.choice(pals)
        if animal == "peacock":
            text = (f"her own skin itself covered in {shape} {HEAD} — this is not fabric, not a garment, not a printed pattern, this is the real cellular structure of her own skin, every marking standing in true relief and casting its own small shadow, nothing lying flat. Dense overlapping fields — BLAZING {c1} eye-marking centres across the full torso both legs neck to ankle, VIVID {c2} radiating barb-ridge detail filling every remaining gap with real texture, NO airbrush NO gradient wash, NO flat printed surface anywhere")
        else:
            text = (f"her own skin itself covered in {shape} {HEAD} — this is not fabric, not a garment, not a printed pattern, this is the real cellular structure of her own skin, each scale casting its own small shadow on the scales beneath it, nothing lying flat as one smooth sheet. Dense overlapping fields — BLAZING {c1} scale formations shifting across the full torso both legs neck to ankle, VIVID {c2} scale-edge detail filling every remaining gap with real texture, every scale catching the light with a sharp shifting glint as the angle changes, NO airbrush NO gradient wash, NO flat printed surface anywhere")
        return dict(text=text, nm="scaled", nail="with the same iridescent shimmer at each tip", track="real", name=f"{D.KO[kind]} {animal}")
    if kind == "obsidian":
        text = (f"full body polished obsidian stone fused directly to her own form {HEAD} — this is not a garment, not jewelry, not a printed pattern, this is solid glossy black stone curving to follow her body's true three-dimensional shape, with molten gold seams running between dozens of fitted stone sections, each seam standing in a thin raised ridge catching its own bright glint and casting its own small shadow, nothing lying flat. Dense fitted sections — BLAZING glossy jet-black obsidian surface across the full torso both legs neck to ankle, VIVID MOLTEN GOLD seams branching and converging densely with no plain stone section left ungilded, NO airbrush NO gradient wash, NO flat printed surface anywhere")
        return dict(text=text, nm="stone", nail="glossy black obsidian with molten gold seam tips", track="real", name=D.KO[kind], force_family="yellow")
    if kind == "wax":
        c1, c2 = rng.choice(D.WAX_COLORS)
        text = (f"full body molten wax flowing and set directly over her own skin {HEAD} — this is not a garment, not a printed pattern, this is real wax that has flowed down every curve and hardened in place, each drip and pooled ridge standing in true three-dimensional relief, casting its own small soft shadow, nothing lying flat. Dense flowing drips — BLAZING {c1} molten wax streams pooling and hardening across the full torso both legs neck to ankle, VIVID {c2} translucent drip-ridges catching the light filling every remaining gap with real depth and texture, each ridge glossy and rounded exactly like real set wax, NO airbrush NO gradient wash, NO flat printed surface anywhere")
        return dict(text=text, nm="wax", nail="with tiny hardened wax drip tips at each nail", track="real", name=f"{D.KO[kind]} {c1.lower()}")
    raise KeyError(kind)


# ───────── 얼굴 · 헤어 ─────────
FACE_STYLES = [s for s in D.G.STYLES if s not in D.G.FACEPAINT]


def face(rng, eth):
    nm, skin, feat, local = eth
    styles = FACE_STYLES
    for _ in range(300):
        st = local if (local and rng.random() < 0.4) else rng.choice(styles)
        mk = D.G.pick_makeup(random.Random(rng.random()), st)
        if not mk or mk["tan"] or mk["facepaint"]: continue
        seg = mk["text"].strip().rstrip(",")
        if nm in ("blue-black", "ebony", "Indian", "Polynesian") and D.PALE.search(seg): continue
        if any(w in seg.lower() for w in D.MAKEUP_BAD) or "lens" in seg.lower() or "sticker" in seg.lower(): continue
        return feat, seg, f"메이크업 {mk['label']}"
    raise SystemExit("face fail")


def hair(rng, eth, spec, concept_snake=False):
    st = rng.choice(D.HAIR_STYLES); co = rng.choice(D.HAIR_COLORS)
    if st in D.SIMPLE_HAIR: h = f"{st} hair coloured {co}"
    else: h = f"hair coloured {co} worn as {D.HAIR_ART.get(st, st)}"
    label = st
    if eth[0] in ("ebony", "blue-black"):
        h = rng.choice(D.HAIR_PROTECT); label = h.split(" in ")[0]
    if concept_snake:
        h = D.SNAKE.format(m=spec.get("mname", "stone")); label = "뱀 머리"
    if spec.get("hair"): h = h + ", " + spec["hair"]
    return h, label


# ───────── 사람 블록 ─────────
def person(rng, label, kind, spec, body, age, pose, eth, hair_txt, concept, cls, shoe_form, floor_key=None, is_boot=None):
    pn, pd = body; p = f"{label}: " if label else ""
    mat = spec["text"]
    boots = "boot" in shoe_form
    if boots: mat = re.sub(r"\bto ankles?\b", BOOTEND, mat)
    skin = eth[1]
    if spec["track"] == "paint": skin = skin.replace("THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky", "a deep blue-black complexion")
    who = f"{age}, {concept[1]}" if concept else f"{age} goddess"
    body_l = f"{p}{skin}, {who}, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair_txt} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    # 신발
    h = "soles" if cls == "flat" else "heels"
    if floor_key and cls != "ballet": stance = D.FLIFT[floor_key].format(h=h)
    else: stance = D.NATURAL
    if cls == "ballet":
        form = shoe_form
        col = ""
        if spec["track"] == "real":
            fam = spec.get("force_family") or family(mat); c = rng.choice(SHC[fam])
            col = f" in solid {c} " + ("metallic leather" if c in METAL else rng.choice(D.LEATHER))
            form = form.replace("ballet boots", "ballet boots" + col, 1)
        else:
            form = form.replace("ballet boots", "ballet boots entirely in the exact same colours as her own body art — " + spec["cols"] + " — " + NOTDARK, 1)
        shoe = f"{p}Footwear: the most absurdly extreme {form}, each with {D.BAL_HEEL}, {D.BAL_STANCE}."
    else:
        sole = D.STIL_HEEL if cls == "stil" else shoe_form[1]
        form = shoe_form if cls == "stil" else shoe_form[0]
        if spec["track"] == "real":
            fam = spec.get("force_family") or family(mat); c = rng.choice(SHC[fam])
            fx = f"{form} in solid {c} " + ("metallic leather" if c in METAL else rng.choice(D.LEATHER))
        else:
            fx = f"{form} entirely in the exact same colours as her own body art — {spec['cols']} — {NOTDARK}"
        shoe = f"{p}Footwear: {'heels' if cls == 'stil' else 'shoes'} of the most absurdly extreme height imaginable, {fx}, each with {sole}, {stance}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rng.choice(D.NAIL_SHAPES)} nails each {rng.choice(D.NAIL_LEN)}, {spec['nail']}."
    feat, seg, info = face(rng, eth)
    fc = f"{p}Face: her face and ears are NOT {spec['nm']} — they are real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = rng.sample(D.JEWEL_BODY, 3)
    jt = ", ".join(jw[:-1]) + ", and " + jw[-1] + ". Jewelry is metal and pearl only, worn on the body, nothing added to her face or ears."
    return "\n".join([body_l, shoe, nails, f"{p}Jewelry: {jt}", fc]), info, boots
