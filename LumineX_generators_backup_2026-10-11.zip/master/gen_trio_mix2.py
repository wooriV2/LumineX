# -*- coding: utf-8 -*-
"""트리오 시험 2: 실사 / 프레임 컷(5재질 혼합·3조각 분할, 등록 문구 그대로) / 듀얼바디 / 상체 실사+하체 재질 의 조합. 전원 USSBBW, 세로 4:5."""
import sys, re, json, random
import gen_trio_mix as T
import mdefs as D, mrecipes as R

REG = json.load(open('/mnt/user-data/outputs/la_pstatue_geo_300_bundle.json', encoding='utf-8'))
SOLO = [x for x in REG if x['meta']['group_size'] == 1]
WHERE = {"hip": "a short way down her thighs, just below the hip line",
         "demi": "a little further below the middle of her thighs",
         "tq": "right at the knee, where the leg would bend"}
TOPS = {"hip": "hips", "demi": "mid-thighs", "tq": "knees"}
SHORT = {"hip": "just below the hips", "demi": "below the middle of the thighs", "tq": "at the knees"}

# ---- 상체 실사 + 하체 재질용 재질 풀(등록된 단일 재질 문구에서 추출) ----
UR_POOL = []
for x in SOLO:
    if x['meta']['structure'] != 'single' or x['meta']['frame'] != 'demi':
        continue
    m = re.search(r"physically made of (one solid [^.]*?), carved as one solid sculpted mass", x['prompt'])
    if m and ("투명" in x['title'] or "목재" in x['title'] or "석재" in x['title']):
        UR_POOL.append((m.group(1), "투명" in x['title']))

# ---- 듀얼바디 재질 풀: 투명 계열만(등록된 단일 투명·내용물 투명 문구 추출). 불투명 석재·목재는 DB에서 제외 ----
DB_SOLID = []; DB_CONTENT = []
for _x in SOLO:
    if _x['meta']['structure'] != 'single': continue
    if "단일 투명" in _x['title']:
        _m = re.search(r"physically made of (one solid transparent material,.*?every wrist, palm, finger and knuckle the same material)\.", _x['prompt'], re.S)
        if _m: DB_SOLID.append(_m.group(1))
    if "내용물 투명" in _x['title']:
        _m = re.search(r"is (ONE solid, continuous block of .*?not a separate vessel)\.", _x['prompt'], re.S)
        if _m: DB_CONTENT.append(_m.group(1))
DB_STONE = []; DB_WOOD = []
for _x in SOLO:
    if _x['meta']['structure'] != 'single': continue
    _m = re.search(r"physically made of (one solid opaque (stone|wood),.*?every wrist, palm, finger and knuckle the same material)\.", _x['prompt'], re.S)
    if _m: (DB_STONE if _m.group(2) == "stone" else DB_WOOD).append(_m.group(1))
DB_SOLID = sorted(set(DB_SOLID)); DB_CONTENT = sorted(set(DB_CONTENT)); DB_STONE = sorted(set(DB_STONE)); DB_WOOD = sorted(set(DB_WOOD))
assert DB_STONE and DB_WOOD
assert DB_SOLID and DB_CONTENT, (len(DB_SOLID), len(DB_CONTENT))
CONNECT_DB = ("The vessel is ONE single continuous hollow from the armpit line down to just above her ankles, with no wall, partition, seal or valve anywhere inside it between the torso, the thighs and the calves, so the water behaves like real water: it settles at the very bottom first, filling both calves and both thighs completely, and rises evenly through the hips and belly to its one level waterline — the legs are never empty while the torso holds water, and the water stands at the same height everywhere inside.")
WATER_VIS = ("The water is clearly and richly coloured — far more saturated than the almost colourless glass — so exactly how much water there is reads at a glance; its surface is a crisp, bright, sharply defined line, and any part of the vessel above it stays clear and colourless.")
SHORTMODE = False; ARMPIT = False; DBTINTS = []; DBWORLDS = []; HAIRNOTE = ''; SCENE_OVERRIDE = None
DBFILLS = []; DBTIERS = []; DBWATERS = []   # 듀얼바디 여러 명일 때 인물별 지정(순서대로 소비)
DBTYPE = None   # None=랜덤: solid / tank / content (+ UR이 없을 때만 stone / wood)
DBFILL = None   # None=랜덤: empty / half / three_quarter / full (tank 전용)
FILLKO = {"empty": "비움", "half": "반", "three_quarter": "4분의 3", "full": "가득", "p50": "50%", "p25": "25%"}
THIN_GLASS = ("The glass is unmistakably glass: a thin, crystal-clear, polished shell with bright specular reflections sliding along every curved surface, sharp white highlights and fine dark refraction edges along the thin rims, tiny bubbles trapped in the glass itself, the background and its light sources seen straight through the vessel, bent only slightly by the thin walls.")

ARMBOUND_DB = ("A single straight, perfectly horizontal line runs all the way around her body at the height of her armpits, straight across her chest and her back and across the tops of both upper arms, never jagged, never zigzag — real skin above it (her face, ears, neck, shoulders, upper chest and the tops of her upper arms), thin glass immediately below it. At that line the glass edge rises in a small raised step above her flesh, casting a crisp shadow.")

def db_apply(body, lt, rt, water3, typ, fill):
    """듀얼바디 몸체 문장을 재질 유형별로 교체. 반환: (body, 설명)"""
    rr = T.rr
    head_old = f"are a sculpted vessel of thick, crystal-clear glass completely filled with {T.WATERS[water3]}, with no hollow space and no air gap anywhere inside it."
    arms_old = " Both arms below the shoulder, both hands, and every finger and knuckle, are the same solid clear glass, with no skin anywhere on them."
    fish_old = " Small bright fish and slow-drifting water plants move through the whole filled volume, never crowding."
    cut_old = "the full thickness of the glass wall and the clear water sealed inside it are visible edge-on"
    assert head_old in body and arms_old in body and fish_old in body and cut_old in body
    W = T.WATERS[water3]
    if typ == "tank":
        see = "its thin glass walls are so transparent that the whole backdrop is clearly visible straight through her body"
        if fill == "empty":
            new = (f"are a thin-walled sculpted vessel of crystal-clear glass, completely empty: the vessel holds no water, no liquid and no objects of any kind, only clear air inside its sealed hollow, and {see}.")
            body = body.replace(head_old, new).replace(T.GLASS, THIN_GLASS).replace(fish_old, "")
            body = body.replace(cut_old, "the thin glass wall and the sealed empty hollow inside it are visible edge-on")
            assert "clear water" not in body and "completely filled with" not in body and "bright fish" not in body
        elif fill == "full":
            new = (f"are a thin-walled sculpted vessel of crystal-clear glass completely filled with {W}, with no hollow space and no air gap anywhere inside it, and {see}.")
            body = body.replace(head_old, new).replace(T.GLASS, THIN_GLASS)
            body = body.replace(cut_old, "the thin glass wall and the clear water sealed inside it are visible edge-on")
        else:
            if fill == "p50":
                line = "high on her thighs, just below the hip crease, so the water fills only the lower part of the vessel — her lower thighs, knees and calves — while the glass above it, up to the armpit line, is empty"
            elif fill == "p25":
                line = "at the height of her knees, so the water fills only her calves and the lowest part of her knees while the glass above it, her thighs, hips, belly, chest and arms up to the armpit line, is empty"
            elif fill == "three_quarter":
                line = "at the height of her breasts, so the water fills the vessel from the cut up to there while the glass above it, up to the collarbones, is empty"
            else:
                line = ("at the height of her navel" if lt == "L1" and rt == "L1" else "at the height of her hips") + ", so the water fills only the lower half of the vessel while the glass above it, up to the collarbones, is empty"
            new = (f"are a thin-walled sculpted vessel of crystal-clear glass, only partly filled with {W}: the water stands at one single flat, level waterline {line}. Everything below that line is filled with {W} with no air gap, and everything above it is simply empty, clear and transparent, with nothing inside, only clear air; a thin bright line marks the water surface where it meets the glass wall. The vessel is her body itself, not a shell worn around a body: there is no human body, no skin, no flesh, no bones and no organs anywhere inside it, so the empty part above the waterline is nothing but clear air inside a thin glass outline of her shape, and the backdrop is plainly visible straight through it. {see.capitalize()}.")
            body = body.replace(head_old, new).replace(T.GLASS, THIN_GLASS)
            body = body.replace(fish_old, " Small bright fish and slow-drifting water plants move only within the water below the waterline, never crowding, always with open water around each one.")
            body = body.replace(cut_old, "the thin glass wall and the clear water sealed inside it are visible edge-on")
        return body, f"수조({FILLKO[fill]})"
    if typ in ("stone", "wood"):   # 불투명: UR 없는 구성에서만
        seg = rr.choice(DB_STONE if typ == "stone" else DB_WOOD)
        body = body.replace(head_old, f"are not painted, covered or clothed but physically made of {seg}. Her body is a completely opaque solid that no light passes through, blocking the backdrop's glow entirely, its surface catching the light with a hard, honest sheen and soft contact shadows; her face stays real living flesh.")
        body = body.replace(T.GLASS + arms_old, "").replace(fish_old, "")
        assert T.GLASS not in body
        for a, b in [("the glass ends in", "the material ends in"), ("the glass continues, unbroken,", "the material continues, unbroken,"),
                     ("cut face of the glass above", "cut face of the material above"), ("glass immediately below", "carved material immediately below"),
                     ("the glass edge rises", "the material's edge rises"), ("part of the glass body", "part of the carved body"),
                     ("cast-glass sculpture", "carved sculpture"), ("solid glass", "solid carved")]:
            body = body.replace(a, b)
        body = body.replace(cut_old, "the solid opaque material is visible edge-on as a smooth, uniform cross-section with no hollow")
        body = body.replace("opaque.  A single", "opaque. A single").replace("  ", " ")
        return body, ("석재" if typ == "stone" else "목재")
    # solid / content: 투명 재질 한 가지
    if typ == "solid":
        seg = rr.choice(DB_SOLID); label = "단일 투명"
        new = f"are not painted, covered or clothed but physically made of {seg}."
        arms_new = ""
    else:
        seg = rr.choice(DB_CONTENT).replace("and both thighs", "and the transparent parts of her legs"); label = "내용물 투명"
        new = f"are {seg}."
        arms_new = " Both arms below the shoulder, both hands, and every finger and knuckle, are the same material, with no skin anywhere on them."
    trans = " The background and its light sources are visible straight through her transparent body, bent and tinted by the material, with bright refraction edges and soft coloured shadows; her face stays completely opaque."
    body = body.replace(head_old, new + trans).replace(T.GLASS + arms_old, arms_new.lstrip()).replace(fish_old, "")
    assert T.GLASS not in body
    body = body.replace("opaque.  A single", "opaque. A single")
    for a, b in [("the glass ends in", "the transparent material ends in"), ("the glass continues, unbroken,", "the transparent material continues, unbroken,"),
                 ("cut face of the glass above", "cut face of the transparent material above"), ("glass immediately below", "transparent material immediately below"),
                 ("the glass edge rises", "the material's edge rises"), ("part of the glass body", "part of the transparent body"),
                 ("cast-glass sculpture", "solid transparent sculpture"), ("solid glass", "solid transparent")]:
        body = body.replace(a, b)
    body = body.replace(cut_old, "the solid transparent material is visible edge-on as a smooth, uniform cross-section" + (", with the embedded shapes visible inside it" if typ == "content" else ""))
    return body, label

EXT = {}
for _x in SOLO:
    for _m in re.finditer(r"carved from (ONE solid block of ([^,]+?), [^.]*?completely opaque)", _x['prompt']):
        if "amethyst" in _m.group(0) or "glass" in _m.group(2): continue
        EXT.setdefault(_m.group(2), _m.group(1))

def adapt(ut):
    ut = ut.replace("covering her whole body below the jaw with no bare skin anywhere", "covering her whole upper body from below the jaw down to the boundary line with no bare skin anywhere above that line")
    ut = ut.replace(R.HEAD, "covering EVERY inch of skin from the neck down to the boundary line WITHOUT EXCEPTION, NO bare skin on her upper body ANYWHERE")
    ut = ut.replace("full body ", "upper-body ", 1)
    ut = re.sub(r"\bthe full torso both legs\b", "the upper torso and both arms", ut)
    ut = re.sub(r"\bfull torso, both legs\b", "upper torso and both arms", ut)
    ut = re.sub(r",? ?\bboth legs\b", "", ut)
    ut = re.sub(r"neck to ankles?", "neck to the boundary line", ut)
    return re.sub(r"  +", " ", ut)

def both_legs(tier):
    x = T.leg_tr("left", tier)
    reps = [("On the left leg,", "On both legs, identically,"), ("Her real left leg is a separate thing entirely: it simply begins", "Her real legs are a separate thing entirely: they simply begin"),
            ("flush against the cut face of the glass above it", "flush against the cut face of the glass above"), ("an ordinary, undisturbed real leg,", "ordinary, undisturbed real legs,"),
            ("Her real left knee, calf and foot are", "Her real knees, calves and feet are"), ("Her real left ankle bone and foot are", "Her real ankle bones and feet are"),
            ("an ordinary, undisturbed real ankle and foot,", "ordinary, undisturbed real ankles and feet,"), ("the entire thigh, knee, calf, ankle and foot all real", "the entire thighs, knees, calves, ankles and feet all real")]
    for a, b in reps:
        x = x.replace(a, b)
    assert "left" not in x, x
    return x

def pick_shoe(rr, cls, no_boot):
    pool = [x for x in D.STIL if not (no_boot and "boot" in x)] if cls == "stil" else [x for x in D.FLAT if not (no_boot and "boot" in x[0])]
    return rr.choice(pool)

def db_shoe(rr, lab, cls):
    sf = pick_shoe(rr, cls, True)
    form = sf if cls == "stil" else sf[0]
    sole = D.STIL_HEEL if cls == "stil" else sf[1]
    c = rr.choice(sum(R.SHC.values(), []))
    fx = f"{form} in solid {c} " + (("leather" if c.startswith("metallic") else "metallic leather") if c in R.METAL else rr.choice(D.LEATHER))
    return f"{lab}: Footwear: {'heels' if cls == 'stil' else 'shoes'} of the most absurdly extreme height imaginable, {fx}, each with {sole}, {D.NATURAL}."

def b_cut(rr_body):
    s = rr_body
    for a, b in [("sagging down toward her knees under its own weight", "sagging down over her hips under its own weight"),
                 ("thick heavy calves", "both thighs clearly separate and individually shaped"),
                 ("her arms, hands, legs and feet stay in correct proportion to each other", "her arms, hands and thighs stay in correct proportion to each other")]:
        assert a in s, a
        s = s.replace(a, b)
    return s

def build(kinds, structure, flevel, tiers, water3, bgkey, urlevel="demi"):
    rr = T.rr
    used = set(); ages = rr.sample(D.AGES, max(3, len(kinds)))
    cls = rr.choices(["stil", "flat"], [42, 18])[0]
    b_real = T.USS[1] + "; " + T.SETTLES + "; " + T.SKIN
    b_mat = T.USS[1] + "; " + T.SETTLES
    b_leg = b_cut(T.USS[1]) + "; " + T.SETTLES
    n_stand = sum(1 for k in kinds if k in ("real", "db", "urf"))
    plural = n_stand > 1
    blocks = []; metas = []; nmeta = {}; dbtypes = []
    for idx, kind in enumerate(kinds):
        lab = f"#{idx+1}"
        e = T.eth_pick(used); age = ages[idx]
        if kind == "urf":  # 전신: 상체 페인트 + 하체 불투명 조각재질(발목 위까지) + 실사 발·하이힐
            for _t in range(30):
                mat, clear = rr.choice([x for x in UR_POOL if not x[1]])
                if mat not in USED_MATS: break
            USED_MATS.add(mat)
            pk0 = URKINDS.pop(0) if URKINDS else None
            for _try in range(60):
                pk = pk0 or rr.choice(["bodypaint", "irezumi", "uvneon"]); spec = R.mat_spec(rr, pk)
                ut = adapt(spec["text"])
                if "ankle" in ut or "to the boundary" not in ut or re.search(r"\b(legs?|thighs?|knees?|feet|foot|calves|ankles?|whole body|full body)\b", ut):
                    continue
                break
            else:
                raise AssertionError("urf paint spec")
            pos = rr.choice(["chest", "waist", "hip"])
            if URFPOS: pos = URFPOS.pop(0) if isinstance(URFPOS, list) else URFPOS
            posx = {"chest": "directly beneath her breasts, at the lower edge of her ribcage", "waist": "at the narrowest part of her waist, just above her navel", "hip": "at her hip line, just below her navel",
                    "thigh": "halfway down her thighs, midway between the hip crease and the knee"}[pos]
            incl = "including both thighs, both knees and both calves" if pos != "thigh" else "including the lower halves of both thighs, both knees and both calves"
            lower = (f"{ut}; the pigment sits on living skin so it distorts slightly over every bulge and cracks a little where the skin folds. Below the boundary line described next, the rest of her body — everything from that line down to the very tips of her toes, {incl}, both ankles, both feet and every toe — is not painted, covered or clothed but physically made of {mat}, carved as one solid sculpted mass like a statue, never hollow, with no seam and no skin anywhere between the line and her toes, "
                     "so her feet and toes inside her shoes are the same carved material as her legs")
            if URFN > 1:
                for _t in range(50):
                    mats = rr.sample(sorted(EXT.values()), URFN)
                    if sum(bool(re.search(r"wenge|black granite|black ebony", x)) for x in mats) <= 1: break
                tail = "so her feet and toes inside her shoes are the same carved material as the leg above them"
                join = "Where each material meets its neighbour, the two distinct materials sit flush against each other with a thin, clean seam, deliberate and precise, never jagged or torn — always the finish of a sculpture, each material keeping its own colour and surface completely separate from the one beside it"
                head_ = f"{ut}; the pigment sits on living skin so it distorts slightly over every bulge and cracks a little where the skin folds. Below the boundary line described next, the rest of her body — everything from that line down to the very tips of her toes — is not painted, covered or clothed but physically made of "
                if URFN == 2:
                    body_ = (f"two different solid opaque materials divided by one straight vertical seam running down the exact centre of her lower body, from the boundary line down between her legs to the floor: everything on the left of the picture — the left half of her lower torso, her left thigh, knee, calf, ankle, foot and toes — is carved from {mats[0]}; everything on the right of the picture — the right half of her lower torso, her right thigh, knee, calf, ankle, foot and toes — is carved from {mats[1]}. {join}, with no skin anywhere between the line and her toes, {tail}")
                elif URFN == 3:
                    body_ = (f"three different solid opaque materials: her lower torso, from the boundary line down to the creases where the thighs begin, is carved from {mats[0]}; her entire left leg (the leg on the left of the picture), from the hip crease down through thigh, knee, calf, ankle, foot and toes, is carved from {mats[1]}; her entire right leg (on the right of the picture), from the hip crease to her toes, is carved from {mats[2]}. {join}, with no skin anywhere between the line and her toes, {tail}")
                else:
                    body_ = (f"four different solid opaque materials: her lower torso, from the boundary line down to the creases where the thighs begin, is divided by one straight vertical seam down its exact centre into two halves — the half on the left of the picture is carved from {mats[0]} and the half on the right of the picture is carved from {mats[1]}; her entire left leg (on the left of the picture), from the hip crease down through thigh, knee, calf, ankle, foot and toes, is carved from {mats[2]}; her entire right leg (on the right of the picture), from the hip crease to her toes, is carved from {mats[3]}. {join}, with no skin anywhere between the line and her toes, {tail}")
                lower = head_ + body_
                metas_mat = " / ".join(re.sub(r"^ONE solid block of ", "", m_)[:30] for m_ in mats)
            h, l = R.hair(rr, e, spec)
            shoe_forms = [x for x in D.STIL if "boot" not in x]
            spec2 = dict(spec); spec2["text"] = lower
            blk, info, _ = R.person(rr, lab, "bodypaint", spec2, ("USSBBW", b_leg), age,
                                    "standing tall, one hand on her hip and the other arm held clear of her body, chin lifted, weight on one leg",
                                    e, h, None, cls, pick_shoe(rr, cls, True), None)
            lines = blk.split("\n")
            bnd = (f"{lab}: Boundary: a clean, straight horizontal line runs all the way around her body {posx} — her painted real skin above, the carved material immediately below. At that line, the material's edge rises in a small raised step above her painted skin, casting a crisp shadow. The paint stops exactly at this line and never continues onto the material, and the material itself is never painted.")
            blocks.append("\n".join([lines[0], bnd] + lines[1:] + [""]))
            metas.append(f"{lab} 전신(발끝까지 재질) 상체 {spec['name']} / 하체 조각재질 {URFN}종(불투명) · 경계 {pos}" + (f" · {metas_mat}" if URFN > 1 else ""))
            continue
        if kind == "real":
            spec = R.mat_spec(rr, "bodypaint"); h, l = R.hair(rr, e, spec)
            blk, info, _ = R.person(rr, lab, "bodypaint", spec, ("USSBBW", b_real), age,
                                    "standing with both hands on her hips in a powerful stance, chin lifted, weight on one leg",
                                    e, h, None, cls, pick_shoe(rr, cls, False), None)
            blk = blk.replace(". Pose:", "; the pigment sits on living skin so it distorts slightly over every bulge and cracks a little where the skin folds. Pose:", 1)
            blocks.append(blk); metas.append(f"{lab} 실사({spec['name']})")
            continue
        h = T.hair_(e); face, jew, info = T.person_bits(lab, e, age)
        nails_len = rr.choice(D.NAIL_SHAPES) + " nails each " + rr.choice(D.NAIL_LEN)
        if kind == "db":
            lt, rt = DBTIERS.pop(0) if DBTIERS else tiers
            if DBWATERS: water3 = DBWATERS.pop(0)
            legs = (T.LEGDESC[lt].format(s="left") + "; " + T.LEGDESC[rt].format(s="right")) if lt != rt else (T.LEGDESC[lt].format(s="each").replace("her each thigh","each of her thighs").replace("her each calf","each calf").replace("her entire each calf","each entire calf").replace("are part","are part") )
            body = (f"{lab}: {e[1]}, {age} goddess, USSBBW physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {b_mat}, {h} — a dual-body woman: her face, ears and neck are real living flesh, and below the collarbones her chest, both arms, both hands, belly, hips and the upper parts of her legs ({legs}) are a sculpted vessel of thick, crystal-clear glass completely filled with {T.WATERS[water3]}, with no hollow space and no air gap anywhere inside it. {T.GLASS} Both arms below the shoulder, both hands, and every finger and knuckle, are the same solid clear glass, with no skin anywhere on them. Small bright fish and slow-drifting water plants move through the whole filled volume, never crowding. {T.BOUND} "
                    f"{('Both legs: ' + both_legs(lt)) if lt == rt else ('Left leg: ' + T.leg_tr('left', lt) + ' Right leg: ' + T.leg_tr('right', rt))} Pose: standing tall with her solid glass left hand resting on her flared hip and her right arm held clear of her body, the hand solid glass and relaxed at hip height, her head tilted slightly toward the camera — most extreme USSBBW silhouette ever displayed.")
            _typ = DBTYPE or rr.choice(["solid", "tank", "content"] + ([] if "urf" in kinds else ["stone"]))   # 목재 DB는 시험 실패(2026-10-11)로 랜덤 풀에서 제외, DBTYPE="wood" 지정 시에만 생성
            assert not (_typ in ("stone", "wood") and "urf" in kinds)
            _fill = ((DBFILLS.pop(0) if DBFILLS else None) or DBFILL or rr.choice(["empty", "half", "three_quarter", "full"])) if _typ == "tank" else None
            body, _lab = db_apply(body, lt, rt, water3, _typ, _fill); dbtypes.append(_typ)
            if ARMPIT:
                import gen_hipframe_tank as _H
                _tint = DBTINTS.pop(0) if DBTINTS else "pale aquamarine-blue"
                _wk = DBWORLDS.pop(0) if DBWORLDS else None
                if _typ == "tank":
                    if SHORTMODE:
                        body = body.replace(THIN_GLASS, _H.glass("x").replace("a faint x tint", "a faint tint of its own colour"))
                        body = body.replace(" Pose:", f" Her glass is tinted {_tint}. Pose:", 1)
                    else:
                        body = body.replace(THIN_GLASS, _H.glass(_tint))
                    if _wk and _fill != "empty":
                        body = re.sub(r" Small bright fish and slow-drifting water plants move [^.]*\.", " The vessel holds ONE single world, kept entirely within the water" + (" below the waterline, nothing floating above it" if _fill != "full" else "") + ": " + _H.WORLDS[_wk][2] + ".", body)
                body = body.replace("below the collarbones her chest, both arms, both hands, belly, hips", "below a straight line at the height of her armpits her chest, both arms from the upper arm down, both hands, belly, hips")
                body = body.replace(T.BOUND, ARMBOUND_DB)
                if _typ == "tank" and _fill != "empty":
                    _w = T.WATERS[water3]
                    body = body.replace(_w, _w.replace("clear ", "vividly coloured "))
                    body = body.replace("The glass is unmistakably glass but", CONNECT_DB + " " + WATER_VIS + " The glass is unmistakably glass but", 1)
                body = body.replace("Both arms below the shoulder, both hands", "Both arms below that line, both hands").replace("up to the collarbones", "up to the armpit line")
            nails = f"{lab}: Nails: the longest nails physically imaginable, {nails_len}, made of the same clear glass with a high polish." if _typ == "tank" else f"{lab}: Nails: the longest nails physically imaginable, {nails_len}, made of the same " + ("carved opaque" if _typ in ("stone", "wood") else "transparent") + " material as each hand, with a high polish."
            blocks.append("\n".join([body, db_shoe(rr, lab, cls), nails, jew, face, ""])); metas.append(f"{lab} 듀얼바디 {_lab}(좌{lt}/우{rt}" + (f", 물 {water3}" if _typ == "tank" and _fill != "empty" else "") + ")")
            continue
        W = WHERE[flevel if kind == "frame" else urlevel]; LV = flevel if kind == "frame" else urlevel
        who = "women" if plural else "woman"
        pp = ("both rounded tips resting side by side on the flat top of a tall plain pale stone plinth block that rises from the floor up to the height of the standing " + who + "'s " + TOPS[LV] + ", so that her head is level with " + ("theirs" if plural else "hers") + "; below the tips only the bare plinth block is visible")
        if kind == "frame":
            cands = [x for x in SOLO if x['meta']['structure'] == structure and x['meta']['frame'] == flevel]
            src = rr.choice(cands); p = src['prompt']
            paras = p.split("\n\n")
            if structure == "single":
                hdr = None
                keep = [q for q in paras if re.match(r"(Body|Transmission|Material|Boundary)", q)]
                assert len(keep) >= 3, [q[:20] for q in keep]
            else:
                hdr = re.search(r"a sculpted body made of (.*?)\. ONE woman", p, re.S).group(1)
                keep = [q for q in paras if re.match(r"(Boundary|Left arm|Right arm|Torso|Left thigh|Right thigh|Where each material)", q)]
                assert len(keep) >= 6, [q[:20] for q in keep]
            out = []
            for q in keep:
                q = q.replace("both rounded tips resting side by side on the surface beneath her", pp)
                q = re.sub(r"both (sealed )?rounded tips resting side by side on the surface beneath her", pp, q)
                if "Where each material" in q[:20]:
                    q = q.rstrip()
                out.append(f"{lab}: " + q)
            assert any(pp in q for q in out)
            frm = (f"{lab}: Framing of the sculpture: her whole sculpted form is visible from the top of her head down to two individually rounded, deliberately carved tips {W}, her face in natural scale with her body. Where her sculpted form comes to an end at her thighs, it is because the sculpture itself ends there, not because a camera frame happens to cut her off.")
            head = (f"{lab}: {e[1]}, {age} goddess, USSBBW physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {b_leg}, {h} — a sculpture-woman: her face, ears and neck are real living flesh, and {('below the collarbones her whole body is one sculpture made of a single material, described below.' if hdr is None else 'below the underarm line her body is a sculpture made of ' + hdr + '.')}")
            tail = (f"{lab}: no calves, no feet, nothing continues below either tip — the material simply reaching its natural end on each leg. The rounded tip is the material's own carved finish, always the clean, deliberate result of a sculpture — never the edge of a photograph. "
                    "Pose: only her torso and the tops of her thighs rise above the plinth, her left hand resting on her flared hip and her right arm held clear of her body with the hand relaxed at hip height, her head tilted slightly toward the camera — most extreme USSBBW silhouette ever displayed.")
            nails = f"{lab}: Nails: the longest nails physically imaginable, {nails_len}, made of the same material as each hand, with a high polish."
            blocks.append("\n".join([head, frm, *out, tail, nails, jew, face, ""]))
            metas.append(f"{lab} 프레임컷 {ProdKO[flevel]} {ProdST[structure]}({src['key']})")
        else:  # ur: 상체 = 페인트 재질(바디페인팅·이레즈미·UV네온), 하체 = 조각 재질 (의상 없음)
            mat, clear = rr.choice([x for x in UR_POOL if x[1] == (URMODE == 'clear')])  # 상체 페인트 구조는 하체를 불투명(목재·석재)으로만 (투명은 전체컷으로 나온 사례 1건)
            for _try in range(60):
                pk = URKINDS.pop(0) if URKINDS else rr.choice(["bodypaint", "irezumi", "uvneon"]); spec = R.mat_spec(rr, pk)
                ut = spec["text"]
                ut = adapt(ut)
                if "ankle" in ut or "to the boundary" not in ut:
                    continue
                if re.search(r"\b(legs?|thighs?|knees?|feet|foot|calves|ankles?|whole body|full body)\b", ut):
                    continue
                break
            else:
                raise AssertionError("ur paint spec")
            pos = rr.choice(["chest", "waist", "hip"])
            posx = {"chest": "directly beneath her breasts, at the lower edge of her ribcage",
                    "waist": "at the narrowest part of her waist, just above her navel",
                    "hip": "at her hip line, just below her navel"}[pos]
            body = (f"{lab}: {e[1]}, {age} goddess, USSBBW physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {b_leg}, {h} — a half-painted half-sculpture woman: her whole upper body is real living skin {ut}; the pigment sits on living skin so it distorts slightly over every bulge and cracks a little where the skin folds. "
                    f"Below the boundary line described next, the rest of her body — everything from that line down to the tips of both thighs — is not painted, covered or clothed but physically made of {mat}, carved as one solid sculpted mass like a statue, never hollow, with no seam and no skin anywhere below the line.")
            bnd = (f"{lab}: Boundary: a clean, straight horizontal line runs all the way around her body {posx} — her painted real skin above, the sculpted material immediately below. At that line, the material's edge rises in a small raised step above her painted skin, casting a crisp shadow. The paint stops exactly at this line and never continues onto the material, and the material itself is never painted.")
            frm = (f"{lab}: Framing of the sculpture: her whole form is visible from the top of her head down to two individually rounded, deliberately carved tips {W}, her face in natural scale with her body. Where her form comes to an end at her thighs, it is because the sculpture itself ends there, not because a camera frame happens to cut her off.")
            cutp = (f"{lab}: {W[0].upper()+W[1:]}, each thigh individually curves inward and rounds off into its own smooth, deeply polished tip — the two thighs stay clearly separate all the way down, never merging, fusing or tapering into a single base — no calves, no feet, nothing continues below either tip — the material simply reaching its natural end on each leg, {pp}. "
                    "The rounded tip is the material's own carved finish, always the clean, deliberate result of a sculpture — never the edge of a photograph. "
                    "She is NOT a full-length standing woman and is never drawn standing on the floor: the plinth block lifts the thigh tips to the height of the other women's mid-thighs, so she is exactly as tall as they are, never shorter, never smaller, never a dwarf. "
                    "Pose: only her torso and the tops of her thighs rise above the plinth, her left hand resting on her flared hip and her right arm held clear of her body with the hand relaxed at hip height, her head tilted slightly toward the camera — most extreme USSBBW silhouette ever displayed.")
            nails = f"{lab}: Nails: the longest nails physically imaginable, {nails_len}, {spec['nail']}."
            blocks.append("\n".join([body, frm, bnd, cutp, nails, jew, face, ""]))
            metas.append(f"{lab} 상체 {spec['name']} / 하체 조각재질({'투명' if clear else '불투명'}) · 경계 {pos}")
    # --- 공통 문장 ---
    desc = {"real": "a real living woman standing",
            "db": "a standing woman whose " + {"stone": "carved stone", "wood": "carved wood", "solid": "transparent", "content": "transparent", "tank": "glass"}[dbtypes[0] if dbtypes else "tank"] + " body turns back into real skin part-way down her legs",
            "frame": "a woman whose sculpted body ends " + SHORT[flevel] + " and rises from a tall stone plinth block",
            "urf": "a standing woman whose painted real upper body gives way to a carved-material lower body all the way down to her toes",
            "ur": "a woman whose painted real upper body gives way to a carved-material lower body that ends " + SHORT[urlevel] + " and rises from a tall stone plinth block"}
    N = len(kinds)
    pos_ko = {1: ["in the centre"], 2: ["on the left", "on the right"], 3: ["on the left", "in the centre", "on the right"], 4: ["on the far left", "on the centre-left", "on the centre-right", "on the far right"]}[N]
    NUMW = {1: "ONE woman", 2: "TWO women side by side", 3: "THREE women side by side in a row", 4: "FOUR women side by side in a row"}[N]
    if N == 1:
        head = "Professional fashion photograph, full body portrait. ONE woman standing in the centre: " + desc[kinds[0]] + "."
    else:
        head = (f"Professional fashion photograph, full body group shot. {NUMW}: " +
                (" and ".join if N == 2 else ", ".join)((pos_ko[i] + " " + desc[k]) if (i < N - 1 or N == 2) else ("and " + pos_ko[i] + " " + desc[k]) for i, k in enumerate(kinds)) + ".")
    bg = D.BGL.BG[bgkey]; scene = SCENE_OVERRIDE or re.sub(r"\ba (?=[aeiou])", "an ", bg[3])
    names = {"real": "the real woman", "db": "the dual-body woman", "frame": "the sculpture-woman on the plinth", "ur": "the half-painted half-sculpture woman on the plinth", "urf": "the half-painted half-sculpture woman"}
    arr = "Arrangement: " + ", ".join(f"#{i+1} is {names[k]} {pos_ko[i]}" for i, k in enumerate(kinds)) + "." if N > 1 else ""
    env = (f"Environment: {scene}, soft even gallery light from the front with a thin cool rim light along {"each figure" if N > 1 else "her figure"} and a gentle glow passing through the transparent parts of the bodies, the whole floor and surroundings clearly visible and in focus, NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no other statues or props besides the plinth blocks. {arr}")
    if dbtypes and all(x in ('stone', 'wood') for x in dbtypes) and 'urf' not in kinds:
        env = env.replace(' and a gentle glow passing through the transparent parts of the bodies', '')
    allp = ("All: Extreme macro detail on every surface texture and shadow. " + {1: "She is a USSBBW giant of overwhelming scale, her body's material and surface in true relief.", 2: "Both women are USSBBW giants of the same overwhelming scale, with their heads at the same height, each body's material, body art and surface in true relief.", 3: "All three women are USSBBW giants of the same overwhelming scale, with their heads at the same height, each body's material, body art and surface in true relief.", 4: "All four women are USSBBW giants of the same overwhelming scale, with their heads at the same height, each body's material, body art and surface in true relief."}[N] + (" " + HAIRNOTE if HAIRNOTE else ""))
    stand_names = " and ".join(names[k] for k in kinds if k in ("real", "db", "urf"))
    cut_names = " and ".join(names[k] for k in kinds if k in ("frame", "ur"))
    cam = (f"Wide shot with the camera at waist height looking straight on, no high angle, pushed close so the three fill the frame edge to edge, {stand_names} completely visible from the soles of {'their' if n_stand>1 else 'her'} shoes to the top of {'their' if n_stand>1 else 'her'} head{'s' if n_stand>1 else ''}, while {cut_names} {'are' if len(cut_names.split(' and '))>1 else 'is'} visible only from the top of the head down to the rounded tips of the thighs, and below those tips the tall plain plinth block fills the rest of the frame down to the floor; the sculpted lower bodies have NO knees, NO shins, NO calves, NO ankles, NO feet and NO shoes anywhere, and nothing of them continues below the tips. A plinth woman must never be drawn as a full standing figure with legs, because the plinth hides everything below her thigh tips, and her head must reach the same height as the others. 8K portrait 4:5 aspect ratio.")
    if not cut_names:
        cam = {1: "Full-length shot with the camera at waist height looking straight on, no high angle, pushed close so she fills the frame, her whole body completely visible from the soles of her shoes to the top of her head, 8K portrait 4:5 aspect ratio.", 2: "Full-length wide shot with the camera at waist height looking straight on, no high angle, pushed close so the two fill the frame edge to edge, both women completely visible from the soles of their shoes to the top of their heads, 8K portrait 4:5 aspect ratio.", 3: "Full-length wide shot with the camera at waist height looking straight on, no high angle, pushed close so the three fill the frame edge to edge, all three women completely visible from the soles of their shoes to the top of their heads, 8K portrait 4:5 aspect ratio.", 4: "Full-length wide shot with the camera at waist height looking straight on, no high angle, pushed close so the four fill the frame edge to edge, all four women completely visible from the soles of their shoes to the top of their heads, 8K portrait 4:5 aspect ratio."}[N]
        env = env.replace(" no other statues or props besides the plinth blocks.", " no statues or props.")
    t = f"{head}\n\n" + "\n".join(blocks) + f"\n{env}\n{allp} {cam}"
    t = re.sub(r"\ba (?=[aeiou])", "an ", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    assert not re.search(r"[가-힣]", t), re.findall(r".{20}[가-힣]+", t)
    d = re.findall(r"\b(\w+) \1\b", t); assert not d, d
    return t, metas + [bg[2], "신발 " + ("스틸레토" if cls == "stil" else "플랫")]

URKINDS = []
URFPOS = None
URFN = 1
DBEMPTY = False
USED_MATS = set()
URMODE = 'opaque'
ProdKO = {"hip": "힙컷", "demi": "데미스탯", "tq": "쓰리쿼터"}
ProdST = {"mix5": "5재질 혼합", "split3": "몸통 3조각", "single": "단일 재질"}

if __name__ == "__main__":
    rr = T.rr
    indoor = [k for k, v in D.BGL.BG.items() if not v[4] and v[0] not in D.BGL.NARROW and not re.search(r"stair|step|escalator", v[3], re.I)]
    out = []
    globals()['URFN'] = 1; globals()['URFPOS'] = None; globals()['URMODE'] = "opaque"
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 777
    rr.seed(seed)
    for typ, kinds in [("stone", ["db"]), ("wood", ["db"]), (None, ["db", "real"])]:   # UR 없는 구성: 불투명 포함 5종 랜덤
        globals()['DBTYPE'] = typ; globals()['DBFILL'] = None; USED_MATS.clear(); URKINDS[:] = []
        wk = list(T.WATERS); rr.shuffle(wk); bgk = rr.choice(indoor)
        t, meta = build(kinds, None, "demi", rr.choice([("L1", "L1"), ("L2", "L2"), ("L3", "L3")]), wk[0], bgk)
        out.append((t, meta, kinds, None, 1)); print(len(out), len(t.split()), meta)
    json.dump(out, open("trio_mix_dbopaque.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
