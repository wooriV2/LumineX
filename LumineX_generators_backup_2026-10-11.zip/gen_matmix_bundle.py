# -*- coding: utf-8 -*-
# Material Mix Formula 300: 새 재질 솔로 60 + 전체 재질 섞기(듀오~5인 각 60). 배경 라이브러리·주얼리·메이크업만 얼굴·40인치 힐·신발 색 일치
import re, random, sys, json, collections
sys.path.insert(0, "../bg")
import bg_library as BGL
src = open("gen_matmix_all4.py", encoding="utf-8").read()
exec(src[:src.index("rg = random.Random(20261011)")])
V = lambda nm, desc, solid, nmw, base, acc, fin, tag: (nm, desc, solid, nmw, base, acc, fin, tag)
NEWV = {
 "jade": [V("jade", "polished carved imperial jade", "jade", "jade", "BLAZING deep imperial-green jade surface across the full torso both legs neck to ankle", "VIVID pale celadon veins and creamy white cloud-like flecks running between the sections", "high-gloss polished", "제왕녹"),
          V("jade", "polished carved lavender jade", "jade", "jade", "BLAZING soft lavender-violet jade surface across the full torso both legs neck to ankle", "VIVID pale mauve and white veins running between the sections", "high-gloss polished", "라벤더"),
          V("jade", "polished carved white mutton-fat jade", "jade", "jade", "BLAZING creamy milk-white mutton-fat jade surface across the full torso both legs neck to ankle", "VIVID faint pale-green and russet-gold veins running between the sections", "soft waxy-gloss polished", "백옥"),
          V("jade", "polished carved crimson-red jade", "jade", "jade", "BLAZING deep crimson-red jade surface across the full torso both legs neck to ankle", "VIVID golden-yellow and white veins running between the sections", "high-gloss polished", "적옥")],
 "porcelain": [V("porcelain", "glazed blue-and-white porcelain", "glazed porcelain", "porcelain", "BLAZING glossy white glaze painted with cobalt-blue dragons, clouds and waves across the full torso both legs neck to ankle", "VIVID deep cobalt-blue borders and fine crackle lines running between the sections", "high-gloss glazed", "청화백자"),
               V("porcelain", "glazed celadon porcelain", "glazed porcelain", "porcelain", "BLAZING soft jade-green celadon glaze with incised lotus and cloud patterns across the full torso both legs neck to ankle", "VIVID darker green pooled glaze and fine crackle lines running between the sections", "glossy glazed", "청자"),
               V("porcelain", "glazed famille-rose porcelain", "glazed porcelain", "porcelain", "BLAZING glossy white glaze painted with pink peonies, golden birds and green leaves across the full torso both legs neck to ankle", "VIVID gold-lined borders and ruby-pink enamel dots running between the sections", "high-gloss glazed", "분채"),
               V("porcelain", "glazed ox-blood red porcelain", "glazed porcelain", "porcelain", "BLAZING deep ox-blood copper-red glaze across the full torso both legs neck to ankle", "VIVID pale streaks and fine golden crackle lines running between the sections", "high-gloss glazed", "홍유")],
 "bronze": [V("bronze", "aged ancient bronze", "cast bronze", "bronze", "BLAZING warm copper-gold bronze metal across the full torso both legs neck to ankle", "VIVID turquoise-green verdigris patina gathering in every recess and joint", "satin-polished raised edges", "녹청"),
            V("bronze", "polished golden bronze", "cast bronze", "bronze", "BLAZING bright polished golden bronze across the full torso both legs neck to ankle", "VIVID darker amber tarnish gathering in every recess and joint", "mirror-polished raised edges", "금빛"),
            V("bronze", "dark red-brown bronze", "cast bronze", "bronze", "BLAZING deep red-brown bronze metal across the full torso both legs neck to ankle", "VIVID black patina and bright copper highlights gathering at every joint", "satin-polished raised edges", "검붉은")],
 "lacquer": [V("lacquer", "glossy urushi lacquer", "lacquered", "lacquer", "BLAZING deep vermilion-red urushi lacquer across the full torso both legs neck to ankle", "VIVID jet-black lacquer panels with fine gold maki-e flowers and cranes between the sections", "mirror-gloss lacquered", "주홍"),
             V("lacquer", "glossy black urushi lacquer", "lacquered", "lacquer", "BLAZING mirror-black urushi lacquer across the full torso both legs neck to ankle", "VIVID gold maki-e waves, pines and moons between the sections", "mirror-gloss lacquered", "흑칠"),
             V("lacquer", "carved cinnabar lacquer", "lacquered", "lacquer", "BLAZING deep carved cinnabar-red lacquer with scrolling cloud relief across the full torso both legs neck to ankle", "VIVID black lacquer grooves between the sections", "deep-gloss lacquered", "조각 주칠"),
             V("lacquer", "glossy gold-flecked urushi lacquer", "lacquered", "lacquer", "BLAZING warm gold-flecked lacquer across the full torso both legs neck to ankle", "VIVID deep red lacquer lines and scattered gold dust between the sections", "mirror-gloss lacquered", "금분")],
 "amber": [V("amber", "polished honey amber resin", "amber resin", "amber", "BLAZING warm honey-orange amber surface across the full torso both legs neck to ankle", "VIVID deeper red-brown swirls and tiny golden bubbles flowing through every section", "high-gloss polished", "꿀색"),
           V("amber", "polished cherry-red amber resin", "amber resin", "amber", "BLAZING deep cherry-red amber surface across the full torso both legs neck to ankle", "VIVID golden-orange swirls and tiny bubbles flowing through every section", "high-gloss polished", "붉은 호박"),
           V("amber", "polished green amber resin", "amber resin", "amber", "BLAZING olive-green amber surface across the full torso both legs neck to ankle", "VIVID golden-yellow swirls and tiny bubbles flowing through every section", "high-gloss polished", "녹색 호박"),
           V("amber", "polished blue amber resin", "amber resin", "amber", "BLAZING deep sea-blue amber surface with a golden glow across the full torso both legs neck to ankle", "VIVID pale cyan swirls and tiny bubbles flowing through every section", "high-gloss polished", "푸른 호박")],
 "coral": [V("coral", "carved pink coral and iridescent mother-of-pearl", "coral and shell", "coral and mother-of-pearl", "BLAZING coral-pink branching coral relief across the full torso both legs neck to ankle", "VIVID iridescent pearl-white nacre sections shimmering pink, green and violet between the coral", "high-gloss polished", "분홍"),
           V("coral", "carved deep red coral and iridescent mother-of-pearl", "coral and shell", "coral and mother-of-pearl", "BLAZING deep red branching coral relief across the full torso both legs neck to ankle", "VIVID iridescent pearl-white nacre sections shimmering pink and gold between the coral", "high-gloss polished", "붉은 산호"),
           V("coral", "carved white coral and iridescent abalone shell", "coral and shell", "coral and abalone shell", "BLAZING creamy white branching coral relief across the full torso both legs neck to ankle", "VIVID iridescent teal, violet and pink abalone sections between the coral", "high-gloss polished", "백산호"),
           V("coral", "carved peach coral and iridescent mother-of-pearl", "coral and shell", "coral and mother-of-pearl", "BLAZING soft peach-orange branching coral relief across the full torso both legs neck to ankle", "VIVID iridescent pearl-white nacre sections shimmering pink and mint between the coral", "high-gloss polished", "복숭아")]}
NEWKINDS = list(NEWV)
HEELMODE = ["forty"]; CUR_VAR = {}
HEEL_REL = "a razor-thin tapered heel taller than her entire shin from ankle to knee and a towering hidden front platform"
def person_nv(label, key, phys, age, pose, eth):
    nm, desc, solid, nmw, base, acc, fin, tag = CUR_VAR[(label, key)]
    pn, pd = phys; p = f"{label}: " if label else ""
    pat = rr.choice(PAT)
    mat = (f"full body {desc} fused directly to her own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, this is solid {solid} curving to follow her body's true three-dimensional shape, divided into dozens of fitted {nm} sections, each joint standing in a thin raised ridge catching its own bright glint and casting its own small shadow, nothing lying flat. Dense fitted sections — {base}, {acc}, with {pat}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    feat, seg, info = face(eth); skin = eth[1]
    hl = HEEL_ if HEELMODE[0] == "forty" else HEEL_REL
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of the same {nmw}, each with {hl}, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, made of the same {nmw} with a high polish."
    fc = f"{p}Face: her face and ears are NOT {nm} — they are real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair()} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    return "\n".join([body, shoe, nails, jw, fc]), info
def disp3(label, kind, pick, phys, age, pose, eth, heel_in):
    if kind in PAINT:
        t, info = person_paint(label, kind, pick, phys, age, pose, eth); return t, info, kind
    if kind in NEWV:
        t, info = person_nv(label, kind, phys, age, pose, eth); return t, info, kind
    return orig_person(label, kind, pick, phys, age, pose, eth, heel_in)
ns2["person"] = disp3; build3 = ns2["build"]
KO = {"bodypaint": "바디페인팅", "irezumi": "이레즈미", "uvneon": "UV네온", "wood": "목재", "stone": "석재", "jade": "옥", "porcelain": "도자기", "bronze": "청동", "lacquer": "옻칠", "amber": "호박", "coral": "산호·조개"}
ALLK = ["bodypaint", "irezumi", "uvneon", "wood", "stone"] + NEWKINDS
TYPEN = {1: "solo", 2: "duo", 3: "trio", 4: "quartet", 5: "quintet"}; TKO = {1: "솔로", 2: "듀오", 3: "트리오", 4: "4인", 5: "5인"}
CAT = "🏺 Living Artifact · Material Mix Formula"
rg = random.Random(20261012); out = []; seen = set()
def draw_picks(kinds):
    picks = []
    for idx, k in enumerate(kinds):
        lab = f"#{idx+1}" if len(kinds) > 1 else None
        if k == "bodypaint": picks.append(rg.choice(BP))
        elif k == "irezumi": picks.append(rg.choice(IR))
        elif k == "uvneon": picks.append(rg.choice(UV))
        elif k == "wood": picks.append(rg.choice(WOODS))
        elif k == "stone": picks.append(rg.choice(STONES))
        else:
            v = rg.choice(NEWV[k]); CUR_VAR[(lab, k)] = v; picks.append(v)
    return picks
def pick_name(k, p):
    if k in NEWV: return f"{KO[k]} {p[7]}"
    if k == "wood": return f"목재 {p[0]}"
    if k == "stone": return f"석재 {p[0]}"
    return KO[k]
for n in range(1, 6):
    cnt = 60 if n >= 2 else 60
    for kk in range(1, cnt + 1):
        for attempt in range(300):
            if n == 1:
                kinds = [NEWKINDS[(kk - 1) % 6]]
            else:
                kinds = [rg.choice(NEWKINDS)] + rg.sample([x for x in ALLK], n)[:0]
                pool = [x for x in ALLK if x != kinds[0]]
                kinds += rg.sample(pool, n - 1); rg.shuffle(kinds)
                if len(set(kinds)) < n: continue
            physs = []
            while len(physs) < n:
                c = rg.choices(BIG5, W5)[0]
                if c not in physs: physs.append(c)
            CUR_VAR.clear(); picks = draw_picks(kinds)
            ages = [rg.choice(AGES) for _ in range(n)]; poses = [rg.choice(POSES) for _ in range(n)]; eths = rg.sample(ETH, n)
            bid, wx = BGL.pick(rg, n)
            scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
            HEELMODE[0] = "forty" if (n >= 2 or rg.random() < 0.55) else "relative"
            ns2["JR"].seed(rg.randrange(10**9))
            t, infos = build3(kinds, picks, physs, ages, poses, eths, scene)
            t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as " + ("her" if n == 1 else "any of them") + ".", 1)
            if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t) or t in seen: continue
            fort = t.count("forty inches"); assert fort == (n if HEELMODE[0] == "forty" else 0), (fort, n, HEELMODE)
            assert t.count("Jewelry:") == n and "completely empty of other people" in t
            break
        else: raise SystemExit(f"fail {n} {kk}")
        seen.add(t)
        mats = " / ".join(pick_name(k, p) for k, p in zip(kinds, picks))
        hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
        out.append({"key": f"la_mm_{TYPEN[n]}_{kk:02d}", "category": CAT,
                    "title": f"MatMix {TYPEN[n].capitalize()} #{kk:02d} ({'새 재질' if n == 1 else '재질 섞기'} {TKO[n]} · {mats} · 체형 {', '.join(x[0] for x in physs)} · 인종 {', '.join(e[0] for e in eths)} · {' ‖ '.join(infos)} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko} · 몸 주얼리)",
                    "prompt": t, "meta": {"group_size": n, "aspect_ratio": ASP[n], "format": "materialmix", "kinds": kinds, "physiques": [x[0] for x in physs], "ethnicity": [e[0] for e in eths],
                                          "background": bid, "weather": wx[0] if wx else None, "heel_mode": HEELMODE[0].replace("relative", "relative"), "jewelry": True}})
assert len(out) == 300 and len({p["key"] for p in out}) == 300
json.dump(out, open(O + "la_matmix_300_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(out), collections.Counter(p["meta"]["group_size"] for p in out))
print(collections.Counter(k for p in out for k in p["meta"]["kinds"]).most_common())
print(collections.Counter(p["meta"]["background"] for p in out).most_common(6), len({p["meta"]["background"] for p in out}), "배경 종류")
print(collections.Counter(p["meta"]["heel_mode"] for p in out if p["meta"]["group_size"] == 1))
print(min(len(p["prompt"].split()) for p in out), max(len(p["prompt"].split()) for p in out))
