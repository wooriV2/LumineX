# -*- coding: utf-8 -*-
"""LumineX 배경 라이브러리 v1 (밝은 배경 전용). 각 항목: (id, 분류, 한글명, 영어 장면 문장, 실외 여부, 날씨 허용)
- 장면 문장은 '정상 크기의 문·난간·계단' 같은 기준물을 반드시 포함 (힐 높이가 읽히도록)
- 공통 접미(ENV_SUFFIX): 밝고 고른 조명 + 다른 사람 없음 + 읽히는 간판·글씨 없음 + 같은 재질 소품 없음
- 날씨(WX)는 실외·날씨 허용 항목에만 붙인다. 겨울 항목은 눈 장면 고정.
"""
import random
ENV_SUFFIX = ", bright and evenly lit, shadows soft, the whole floor and surroundings clearly visible and in focus, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as her, NO dark background NO black void."
WX = [("화창한 낮", "in clear sunny daylight"), ("흐린 낮", "under a soft overcast sky with gentle diffused light"),
      ("황금빛 오후", "in warm golden late-afternoon light"), ("비 갠 뒤", "just after the rain, with wet surfaces shining softly")]
# (id, cat, ko, scene, outdoor, wx)
B = [
 # ── 기존 8곳(v2) ──
 ("gallery", "기존", "갤러리", "a bright white-walled modern gallery hall with a polished pale floor and a full-height doorway standing open behind her", False, False),
 ("terrace", "기존", "야외 테라스", "a sunlit open-air stone terrace at midday with a pale paved floor, a waist-high balustrade, potted palms and a standard-height doorway", True, False),
 ("atrium", "기존", "아트리움", "a bright airy glass-roofed atrium with a pale polished floor, a wide staircase with standard-height steps and a normal-height doorway", False, False),
 ("seaside", "기존", "바닷가 산책로", "a sunny seaside promenade of pale paving stones with a waist-high white railing, a lamp post and a row of normal-height beach huts", True, False),
 ("courtyard", "기존", "하얀 안뜰", "a sunlit white-washed courtyard with a pale tiled floor, an arched doorway at normal height, low stone steps and a waist-high wall", True, False),
 ("loft", "기존", "미니멀 로프트", "a bright minimalist loft studio with pale concrete floors, tall factory windows, a standard door and a row of standard-height steps", False, False),
 ("plaza", "기존", "도시 광장", "a sunny city plaza of light paving with a low fountain edge, a street lamp and standard-height shop doors behind her", True, False),
 ("marble", "기존", "대리석 홀", "a bright grand hall with a pale marble floor, tall columns, standard-height arched doors and soft golden daylight", False, False),
 # ── 4계절 ──
 ("spring_cherry", "계절", "봄 벚꽃길", "a cherry-blossom avenue in full bloom with a pale paved path strewn with petals, a waist-high wooden fence, a standard park bench and lamp posts", True, True),
 ("spring_garden", "계절", "봄 정원 테라스", "a bright spring garden terrace of pale stone with blooming tulip beds, a low trimmed hedge, a standard-height garden gate and a bench", True, True),
 ("summer_beach", "계절", "여름 해변", "a bright white-sand beach at midday with calm turquoise water, a wooden boardwalk with a waist-high rail and a row of closed striped cabanas of normal door height", True, True),
 ("summer_meadow", "계절", "여름 들판", "a sunny green meadow full of wildflowers with a dirt path, a wooden fence and gate of normal height", True, True),
 ("autumn_maple", "계절", "가을 단풍길", "a maple avenue in full autumn colour with a pale path scattered with red and gold leaves, a standard park bench and lamp posts", True, True),
 ("autumn_park", "계절", "가을 공원", "a sunlit autumn park with orange trees, a stone bridge with a waist-high parapet and a standard bench on a leaf-strewn path", True, True),
 ("winter_plaza", "계절", "겨울 눈 광장", "a snow-covered stone plaza in soft daylight with light snow lying only on the ground, a fountain edge under snow, standard lamp posts and a waist-high railing", True, False),
 ("winter_field", "계절", "겨울 설원", "a bright snowfield with bare trees under a pale sky, a wooden fence of normal height and a cabin with a standard-size door in the distance", True, False),
 # ── 대중교통 ──
 ("train_station", "교통", "기차역 대합실", "a bright grand railway station concourse with a pale stone floor, tall arched windows, standard-height doors and a long bench", False, False),
 ("subway", "교통", "지하철 승강장", "a clean brightly lit subway platform with pale tiled walls, a yellow safety line along the platform edge, standard-height train doors and a bench", False, False),
 ("airport", "교통", "공항 터미널", "a bright airy airport terminal hall with a glossy pale floor, floor-to-ceiling windows, standard-height doors and a row of seats", False, False),
 ("bus_terminal", "교통", "버스 터미널", "a bright modern bus terminal with a clean pale concrete floor, a glass canopy, standard-height bus doors and a bench", False, False),
 # ── 문화 시설 ──
 ("art_museum", "문화", "미술관", "a bright art museum atrium with a pale stone floor, tall blank white walls, a wide staircase of standard steps and a normal-height doorway", False, False),
 ("museum", "문화", "박물관", "a grand museum hall with a pale stone floor, tall columns, a wide staircase of standard steps and plain banners without any text", False, False),
 ("exhibition", "문화", "전시장", "a vast bright exhibition hall with a smooth pale floor, steel roof trusses, standard-height doors and plain white partition walls", False, False),
 ("concert_hall", "문화", "공연장", "a grand concert hall stage with a polished wooden floor, steps down to the stalls, rows of red seats and a standard-height stage door", False, False),
 ("opera_stairs", "문화", "오페라 하우스 계단", "the grand marble staircase of an opera house with standard-height steps, a waist-high carved balustrade, chandeliers and warm daylight from tall windows", False, False),
 ("library", "문화", "대형 도서관", "a grand old library hall with a pale marble floor, tall bookshelves, a spiral stair with a waist-high rail and a standard-height doorway", False, False),
 # ── 세계 유적지(폐허·궁전 위주, 현재 사용 중인 예배 장소 제외) ──
 ("parthenon", "유적", "아테네 파르테논", "the ancient Parthenon terrace on the Acropolis in Athens, pale weathered marble paving, fluted columns and standard-height stone steps, empty of tourists", True, True),
 ("colosseum", "유적", "로마 콜로세움", "the sunlit arches of the Roman Colosseum with worn stone paving, standard-height arched doorways and low stone steps, empty of tourists", True, True),
 ("taj", "유적", "타지마할 정원", "the long reflecting pool path in front of the Taj Mahal with pale marble paving, a waist-high ornamental rail and low steps, empty of tourists", True, True),
 ("angkor", "유적", "앙코르와트 회랑", "the carved stone galleries of Angkor Wat with sunlit sandstone paving, standard-height doorways and low stone steps, empty of tourists", True, True),
 ("petra", "유적", "페트라", "the sandstone canyon floor in front of the rose-red Treasury at Petra, a smooth sandy path and standard-height rock-cut doorways, empty of tourists", True, True),
 ("machu", "유적", "마추픽추 계단식 터", "the green stone terraces of Machu Picchu with stone steps of normal height and low terrace walls, empty of tourists", True, True),
 ("gyeongbok", "유적", "경복궁 마당", "the wide granite courtyard of Gyeongbokgung Palace with a standard-height palace gate, low stone steps and a waist-high stone balustrade, empty of visitors", True, True),
 ("great_wall", "유적", "만리장성", "a sunlit stretch of the Great Wall of China with worn brick paving, waist-high crenellated parapet, standard-height arched gate and stone steps, empty of tourists", True, True),
 ("pyramids", "유적", "기자 피라미드", "the sandy Giza plateau with the great pyramids behind her, a smooth flat sand path and a standard-height stone doorway block at her side, empty of tourists", True, True),
 ("alhambra", "유적", "알람브라 사자의 정원", "the Court of the Lions at the Alhambra with a pale marble floor, slender arcade columns, standard-height arched doorways and a low fountain, empty of visitors", True, True),
 ("forbidden", "유적", "자금성 마당", "a vast stone courtyard of the Forbidden City with a standard-height palace gate, marble steps with waist-high balustrades, empty of visitors", True, True),
 # ── 자연 ──
 ("dunes", "자연", "사막 모래언덕", "golden sand dunes under a clear sky with a smooth flat sand foreground and a standard-height wooden gate frame standing at her side", True, True),
 ("canyon", "자연", "협곡", "a sunlit red-rock canyon floor with a smooth sandy path, low boulders of knee height and a waist-high wooden trail rail", True, True),
 ("waterfall", "자연", "폭포 전망대", "a bright waterfall viewpoint with a wooden deck, a waist-high wooden railing, stone steps of normal height and lush green cliffs behind her", True, True),
 ("forest", "자연", "숲길", "a bright sun-dappled forest path with a packed earth floor, a waist-high wooden rail, a standard bench and tall straight trees", True, True),
 ("lavender", "자연", "라벤더 들판", "a blooming lavender field in neat rows under a clear sky with a gravel path, a wooden gate and fence of normal height", True, True),
 ("rice_terrace", "자연", "계단식 논", "green stepped rice terraces with a stone path, a waist-high stone wall and a standard-height farm hut door at her side", True, True),
 ("sea_cliff", "자연", "해안 절벽", "a bright coastal clifftop with a grassy path, a waist-high wooden safety rail, standard-height stone steps and a white lighthouse far behind her", True, True),
 ("salt_flat", "자연", "소금 사막", "a vast white salt flat reflecting the sky with a smooth flat floor and a standard-height wooden doorway frame standing at her side", True, True),
 ("bamboo", "자연", "대나무 숲", "a bright bamboo grove with a smooth stone path, tall green bamboo on both sides, a waist-high bamboo fence and a standard gate", True, True),
 ("jungle", "자연", "열대 정글 보드워크", "a bright tropical jungle boardwalk of wooden planks with a waist-high rope rail, large green leaves and standard-height steps", True, True),
 ("ice_cave", "자연", "얼음 동굴", "a bright blue-white glacier ice cave lit by daylight through the ice, a flat frozen floor and a standard-height wooden walkway rail", True, False),
 # ── 도시 ──
 ("rooftop", "도시", "옥상 테라스", "a bright modern rooftop terrace with a pale deck floor, a waist-high glass railing, a standard door and a city skyline in the daylight haze", True, True),
 ("bridge", "도시", "대교 보행로", "a wide pedestrian walkway on a large suspension bridge with a waist-high railing, standard lamp posts and the city skyline in daylight", True, True),
 ("skyscraper_plaza", "도시", "고층빌딩 광장", "a sunny plaza at the foot of glass skyscrapers with pale paving, a low fountain edge, standard-height glass doors and benches", True, True),
 ("harbor", "도시", "항구 등대", "a sunny harbour quay of pale stone with a waist-high iron railing, mooring posts of normal height and a white lighthouse behind her", True, True),
 ("greenhouse", "도시", "유리 온실 식물원", "a bright Victorian glass greenhouse with a pale tiled floor, tall palms, a waist-high iron rail and a standard-height glass door", False, False),
 ("arcade", "도시", "쇼핑 아케이드", "a bright glass-vaulted shopping arcade with a polished marble floor, standard-height shop doors and a long bench, completely empty", False, False),
 # ── 건축·실내 ──
 ("palace_hall", "건축", "궁전 대계단 홀", "a grand palace hall with a wide marble staircase of standard steps, gilded waist-high balustrades and tall windows full of daylight", False, False),
 ("castle", "건축", "고성 안뜰", "a sunlit castle courtyard with a worn cobblestone floor, a standard-height arched gate, low stone steps and a waist-high well edge", True, True),
 ("hotel_lobby", "건축", "호텔 로비", "a bright luxury hotel lobby with a polished pale marble floor, a standard-height entrance door, a curved staircase and a long reception counter", False, False),
 ("ballroom", "건축", "무도회장", "a bright grand ballroom with a polished parquet floor, tall mirrors, standard-height double doors and a low stage step", False, False),
 # ── 전통 정원·건축 ──
 ("japanese_garden", "정원", "일본 정원", "a serene Japanese garden with raked pale gravel, a stone path, a low wooden bridge with a waist-high rail and a standard-height wooden gate", True, True),
 ("chinese_garden", "정원", "중국 정원", "a classical Chinese garden with a stone path, a zigzag bridge with a waist-high rail, a moon gate of standard height and a pavilion", True, True),
 ("hanok", "정원", "한옥 마당", "a sunlit hanok courtyard with a pale earth floor, a standard-height wooden door, a low stone step and a waist-high clay wall", True, True),
 ("indian_palace", "정원", "인도 궁전 안뜰", "a sunlit Indian palace courtyard of pale sandstone with carved arches of standard height, low steps and a waist-high jali screen", True, True),
 # ── 패션·무대 ──
 ("runway", "패션", "런웨이", "a long white fashion-show runway with a glossy white floor, standard-height steps at the end and softly lit empty rows of seats", False, False),
 ("red_carpet", "패션", "레드카펫 계단", "a wide red-carpeted grand staircase with standard-height steps, a waist-high brass handrail and warm daylight from tall windows", False, False),
 # ── 스포츠·산업 ──
 ("pool", "스포츠", "수영장", "a bright indoor swimming pool hall with pale tiled floors, a pool edge, standard-height steps and tall windows full of daylight", False, False),
 ("ice_rink", "스포츠", "아이스 링크", "a bright empty ice rink with a clean white ice surface, a waist-high boards edge and standard-height gates", False, False),
 ("stadium", "스포츠", "경기장", "an empty sunlit stadium with green turf, a running track, standard-height gates and low stands behind her", True, True),
 ("hangar", "산업", "항공기 격납고", "a vast bright aircraft hangar with a clean pale concrete floor, a standard-height side door and a small jet far behind her", False, False),
 ("observatory", "산업", "천문대", "a bright observatory hall with a pale floor, a large white telescope dome behind her, a standard-height door and a short steel stair", False, False),
 ("planetarium", "산업", "플라네타륨 로비", "a bright planetarium lobby with a polished pale floor, a curved white wall, a standard-height door and a low step", False, False),
]
BG = {b[0]: b for b in B}
def desc(bid, wx=None):
    _, cat, ko, scene, out, wxok = BG[bid]
    s = scene
    if wx is not None and wxok: s = f"{scene}, {wx[1]}"
    return s + ENV_SUFFIX
WEIGHT = {"기존": 1.0, "계절": 1.2, "교통": 0.8, "문화": 1.0, "유적": 0.55, "자연": 1.0, "도시": 0.9, "건축": 0.8, "정원": 0.8, "패션": 0.6, "스포츠": 0.6, "산업": 0.5}
# 폭이 좁아 4~5인이 나란히 서기 어려운 곳 (4인 이상 그룹에서는 제외)
NARROW = {"great_wall", "petra", "subway", "bamboo", "forest", "jungle", "waterfall", "ice_cave", "canyon", "sea_cliff", "rice_terrace", "bridge", "spiral"}
def pick(rng, n=1):
    items = [b for b in BG.values() if not (n >= 4 and b[0] in NARROW)]
    b = rng.choices(items, [WEIGHT[x[1]] for x in items])[0]
    w = rng.choice(WX) if b[5] else None
    return b[0], w
if __name__ == "__main__":
    import collections
    print(len(B), collections.Counter(b[1] for b in B))
