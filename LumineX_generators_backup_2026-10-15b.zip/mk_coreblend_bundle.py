# -*- coding: utf-8 -*-
# 기존 Material Blend 틀(검은 피부·검은 배경) + Core 체형 + 새 재질 포함 기본 랜덤 재질 — 샘플 4개
import re, sys, random, json
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity"); sys.path.insert(0, "../../bk"); sys.path.insert(0, "../../master")
GT = {"__name__": "gt"}
exec(open("mk_blendnew6.py", encoding="utf-8").read().split("items = []")[0], GT)
exec(open("gen_matblend_geo_test.py", encoding="utf-8").read().split("\nitems=[]")[0].split("rnd.seed(20261008)")[1], GT)  # 이미 로드된 모듈 위에 mat_person/build_mat 재정의
import mdefs as D
exec(open("../../bk/newbody_defs.py", encoding="utf-8").read(), GT)
NB = GT["NB"]
_NBd = [b[1] for b in D.BODIES if b[0] == "Nubian booty builder"][0]
_NBB = _NBd.replace("wide flaring lats", "a full, heavy, firm bust standing out on her chest").replace("a deeply carved abdomen with sharp obliques", "a deeply carved six-pack abdomen with sharp obliques")
CORE = ["legendary bust", "curved bust", "siren bust hourglass", "glamour hourglass", "hourglass bombshell", "black glamour", "apex siren", "violin hip hourglass", "latina curves", "Brazilian booty glam",
        "amazon bombshell", "towering hourglass", "amazoness", "muscular hourglass BBW", "hourglass SSBBW", "USSBBW", "Nubian booty builder", "powerlifter bombshell", "Nubian bust builder"]
POOL = {b[0]: b[1] for b in D.BODIES}; POOL.update({nm: desc for nm, ko, kod, desc in NB}); POOL["Nubian bust builder"] = _NBB
KO = {"legendary bust": "레전더리 바스트", "curved bust": "커브드 바스트", "siren bust hourglass": "사이렌 바스트 아워글래스", "glamour hourglass": "글래머 아워글래스", "hourglass bombshell": "아워글래스 밤쉘", "black glamour": "블랙 글래머", "apex siren": "에이펙스 사이렌",
      "violin hip hourglass": "바이올린 힙 아워글래스", "latina curves": "라티나 커브스", "Brazilian booty glam": "브라질리언 부티 글램", "amazon bombshell": "아마존 밤쉘", "towering hourglass": "타워링 아워글래스", "amazoness": "아마조네스",
      "muscular hourglass BBW": "머스큘러 아워글래스 BBW", "hourglass SSBBW": "아워글래스 SSBBW", "USSBBW": "USSBBW", "Nubian booty builder": "누비안 부티 빌더", "powerlifter bombshell": "파워리프터 밤쉘", "Nubian bust builder": "누비안 바스트 빌더"}
GT["PHYS"] = [(nm, POOL[nm]) for nm in CORE]
GT["POSES_MX"] = [p for p in GT["POSES_MX"] if "arms crossed under her bust" not in p and "framing the face" not in p]
NEWM = GT["NEWM"]; EXC = {"crystal", "botanical", "ice", "mirror", "scale_peacock"}
MK = [m for m in GT["MATKEYS"] if m not in NEWM] + NEWM; MK = [m for m in MK if m not in EXC]
rnd = GT["rnd"]; rnd.seed(20261950)
def pm(n):
    while True:
        m = rnd.sample(MK, n)
        if {"stone", "wood"} <= set(m): continue
        return m
GT["pick_mats"] = pm

import json, collections
REC = []
_pm0 = GT["pick_mats"]
def _pmr(n):
    m = _pm0(n); REC.append(list(m)); return m
GT["pick_mats"] = _pmr
GN = {1: "Solo", 2: "Duo", 3: "Trio"}; GK = {1: "solo", 2: "duo", 3: "trio"}
PAT = [
 (r" ?The boundaries between regions are hazy.*?fully covers it\.", ""),
]
def curve(p):
    for a, b in PAT: p = re.sub(a, b, p)
    p = re.sub(r"by (\d+) parallel hazy transition zones? running", lambda m: ("split along %s parallel gently undulating curves running" % m.group(1)) if int(m.group(1)) > 1 else "split along 1 gently undulating curve running", p)
    p = re.sub(r"by (\d+) hazy transition zones? centred", lambda m: "split along gently undulating curves at" if int(m.group(1)) > 1 else "split along a gently undulating curve at", p)
    p = re.sub(r"separated by (\d+) hazy ring-shaped transition zones? at about", lambda m: "split along gently undulating curves at about" if int(m.group(1)) > 1 else "split along a gently undulating curve at about", p)
    p = re.sub(r"(\d+) hazy ray-shaped transition zones leave", r"\1 gently curving dividing rays leave", p)
    p = p.replace("transition zone", "dividing curve").replace(" and every blended transition", "")
    assert not re.search(r"hazy|zone|transition|boundar", p, re.I), p[:200]
    return p
EXCKO = None
rows = []; SEENP = set()
CAT = {}
for mix in (2, 3, 4):
    for gs in (1, 2, 3):
        cat = f"🏺 Living Artifact · Core Blend {mix}-Mix {GN[gs]} Formula"
        i = 0
        while i < 30:
            REC.clear(); GT["PHYS"] = [(nm, POOL[nm]) for nm in CORE]
            try:
                p, descs = GT["build_mat"](gs, mix)
            except AssertionError:
                continue
            if re.search(r"[가-힣]", p) or re.search(r"\b(\w+) \1\b", p): continue
            try: p = curve(p)
            except AssertionError: continue
            if p in SEENP: continue
            GT["validate"](f"cb_{mix}_{gs}", p)
            nms = [d.split(" / ")[-1] for d in descs]
            sts = [d.split(" / ")[0] for d in descs]
            mats = [list(m) for m in REC]
            assert len(mats) == gs and all(len(m) == mix for m in mats)
            SEENP.add(p); i += 1
            key = f"la_coreblend{mix}_{GK[gs]}_{i:03d}"
            bodies = " / ".join(nms)
            matko = " / ".join("+".join(GT["MAT_KO"][m] for m in mm) for mm in mats)
            title = f"Core Blend {mix}-Mix {GN[gs]} #{i:03d} · {bodies} · {matko}"
            if len(title) > 103: title = f"Core Blend {mix}-Mix {GN[gs]} #{i:03d} · {bodies}"
            if len(title) > 103: title = f"Core Blend {mix}-Mix {GN[gs]} #{i:03d} · " + " / ".join(KO[n] for n in nms)
            rows.append({"key": key, "category": cat, "title": title, "prompt": p,
                         "meta": {"group_size": gs, "aspect_ratio": GT["ASP"][gs], "format": "core-blend", "mix_count": mix, "layout": "geometry-curve-v1",
                                  "structures": sts, "materials": mats, "physiques": nms, "boundary": "curve-v1"}})
json.dump(rows, open("/mnt/user-data/outputs/la_coreblend_270_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(rows), max(len(r["title"]) for r in rows), len({r["key"] for r in rows}), len({r["title"] for r in rows}))
c = collections.Counter(n for r in rows for n in r["meta"]["physiques"]); print(sorted(c.items(), key=lambda x: -x[1])[:3], sorted(c.items(), key=lambda x: x[1])[:3])
import statistics
for gs in (1, 2, 3):
    for mix in (2, 3, 4):
        w = [len(r["prompt"].split()) for r in rows if r["meta"]["group_size"] == gs and r["meta"]["mix_count"] == mix]
        print(gs, mix, int(statistics.mean(w)), max(w))
