# -*- coding: utf-8 -*-
# Material Blend(기본 랜덤 틀) 샘플 — 영역 분할 문장은 기존 블렌드, 나머지 축은 Material Mix 틀 기본 랜덤, Core 18체형 중 랜덤
import os, sys, re, random
HERE = os.getcwd()
_m = open("mk_mixnew3.py", encoding="utf-8").read()
exec(_m[:_m.index('OLD = ["bodypaint"')], globals())
exec(open("newbody_defs.py", encoding="utf-8").read(), globals())
POSES = [p for p in POSES if "arms crossed under her bust" not in p and "framing the face" not in p]
sys.path.insert(0, "../master")
import mdefs as _D
# ── 블렌드 네임스페이스 (별도) ──
os.chdir(os.path.join(HERE, "..", "zx", "glassface"))
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity")
GT = {"__name__": "gt"}
exec(open("mk_blendnew6.py", encoding="utf-8").read().split("items = []")[0], GT)
os.chdir(HERE)
NEWM = GT["NEWM"]; MATKEYS = [m for m in GT["MATKEYS"] if m not in NEWM] + NEWM
def pick_mats_all(n, rnd):
    while True:
        m = rnd.sample(MATKEYS, n)
        if {"stone", "wood"} <= set(m): continue
        return m
BRNG = random.Random(20261901)
def blend_text(n):
    mats = pick_mats_all(n, BRNG)
    kind, shape = GT["draw_cells"](1)[0]
    texts = [GT["mat_text"](m)[0] for m in mats]
    pre, reg, lab = GT["make_structure"](kind, n, shape); assert GT["sens_count"](pre + " " + " ".join(reg)) == 0
    sents = " ".join(f"Region {i+1} is {reg[i]}: it carries {texts[i]}." for i in range(n))
    hz = GT["hazy_mat"](shape, GT["STRUCT_KIND"][kind])
    uv = "uvneon" in mats
    light = " A standard hard key light illuminates most of her body; a separate dedicated UV blacklight illuminates the UV-reactive region specifically, making it glow at full intensity while the rest reads under normal light." if uv else ""
    txt = f"her body carries {n} different materials at once, each claiming its own region of her figure. {pre} {sents} {hz}, no fabric no seam no garment anywhere, every material fused to or erupting from her own living skin, covering her completely with no bare skin anywhere from neck to ankle"
    return txt, light, "+".join(GT["MAT_KO"][m] for m in mats), f"{GT['STRUCT_KO'][kind]}·{'물결' if shape=='undulating' else '매끈'}"
NEWV["blend"] = [dict(n=3)]
NSEL = [3]
BINFO = {}
_prev_b = person_nv
def person_nv(label, key, phys, age, pose, eth):
    if key != "blend": return _prev_b(label, key, phys, age, pose, eth)
    n = NSEL[0]
    txt, light, ko, st = blend_text(n); BINFO[label] = (ko, st)
    pn, pd = phys; p = f"{label}: " if label else ""
    feat, seg, info = face(eth); skin = eth[1]
    hl = HEEL_ if HEELMODE[0] == "forty" else HEEL_REL
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} blending the materials of the regions they fall in, each with {hl}, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each matching whichever region that hand falls in, with a high polish."
    fc = f"{p}Face: her face and ears are NOT any of these materials — they are real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair()} — {txt}. Pose: {pose}, every region clearly visible to the camera — most extreme {pn} silhouette ever displayed.{light}"
    return "\n".join([body, shoe, nails, jw, fc]), info
# ── Core 18 ──
_NBd = [b[1] for b in _D.BODIES if b[0] == "Nubian booty builder"][0]
_NBB = _NBd.replace("wide flaring lats", "a full, heavy, firm bust standing out on her chest").replace("a deeply carved abdomen with sharp obliques", "a deeply carved six-pack abdomen with sharp obliques")
CORE = ["legendary bust", "curved bust", "siren bust hourglass", "glamour hourglass", "hourglass bombshell", "black glamour", "apex siren", "violin hip hourglass", "latina curves", "Brazilian booty glam",
        "amazon bombshell", "towering hourglass", "amazoness", "muscular hourglass BBW", "hourglass SSBBW", "USSBBW", "Nubian booty builder", "powerlifter bombshell", "Nubian bust builder"]
POOL = {b[0]: b[1] for b in _D.BODIES}; POOL.update({nm: desc for nm, ko, kod, desc in NB}); POOL["Nubian bust builder"] = _NBB
assert all(c in POOL for c in CORE)
LINK = dict(_D.BODY_LINK); LINK["Nubian bust builder"] = LINK["Nubian booty builder"]
KO = {"legendary bust": "레전더리 바스트", "curved bust": "커브드 바스트", "siren bust hourglass": "사이렌 바스트 아워글래스", "glamour hourglass": "글래머 아워글래스", "hourglass bombshell": "아워글래스 밤쉘", "black glamour": "블랙 글래머", "apex siren": "에이펙스 사이렌",
      "violin hip hourglass": "바이올린 힙 아워글래스", "latina curves": "라티나 커브스", "Brazilian booty glam": "브라질리언 부티 글램", "amazon bombshell": "아마존 밤쉘", "towering hourglass": "타워링 아워글래스", "amazoness": "아마조네스",
      "muscular hourglass BBW": "머스큘러 아워글래스 BBW", "hourglass SSBBW": "아워글래스 SSBBW", "USSBBW": "USSBBW", "Nubian booty builder": "누비안 부티 빌더", "powerlifter bombshell": "파워리프터 밤쉘", "Nubian bust builder": "누비안 바스트 빌더"}
PLAN = [(1, 3), (1, 4), (2, 3), (3, 3)]
GN = {1: "솔로", 2: "듀오", 3: "트리오"}
rg = random.Random(20261902); rr.seed(20261902); ns2["JR"].seed(20261902)
o = ["# LumineX — Material Blend 기본 랜덤 틀 샘플 4개 (솔로 3·4혼합 / 듀오 / 트리오)\n", "영역 분할 문장은 기존 Material Blend 그대로이고, 검은 피부·검은 배경 대신 나이·포즈·인종·배경·힐·네일·주얼리·메이크업은 기본 랜덤, 체형은 Core 체형 중 랜덤입니다. 번호별로 성공/실패만 알려주세요.\n"]
SEEN = set(); USED = set()
for si, (gs, n) in enumerate(PLAN, 1):
    for attempt in range(800):
        CUR_VAR.clear(); BINFO.clear()
        names = rg.sample([c for c in CORE if c not in USED], gs)
        phys = [(nm, POOL[nm]) for nm in names]
        ages = [rg.choice(AGES) for _ in range(gs)]; poses = [rg.choice(POSES) for _ in range(gs)]
        eths = []
        for nm in names:
            cand = [e for e in ETH if e[0] in LINK[nm]] if nm in LINK else ETH
            eths.append(rg.choice(cand))
        bid, wx = BGL.pick(rg, 1); scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
        ns2["JR"].seed(rg.randrange(10**9))
        NSEL[0] = n; vs = [dict(n=n) for _ in range(gs)]
        t, infos = build3(["blend"] * gs, vs, phys, ages, poses, eths, scene)
        t = t.replace("covers it., no fabric", "covers it; no fabric")
        if HEELMODE[0] == "relative": t = t.replace("a full forty inches tall and a twelve-inch hidden front platform", "taller than her entire shin from ankle to knee and a towering hidden front platform")
        t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as her.", 1)
        if not chk(t) or re.search(r"\b(foil|lens|sticker|doll)\b", t, re.I) or t in SEEN: continue
        if t.count("Jewelry:") != gs or t.count("forty inches") != (gs if HEELMODE[0] == "forty" else 0): continue
        SEEN.add(t); break
    else: raise SystemExit("fail")
    USED.update(names)
    hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
    desc = " ; ".join(f"[{KO[nm]} / {BINFO[lb][0]}]" for nm, lb in zip(names, [("#%d" % (i+1)) if gs > 1 else None for i in range(gs)]))
    o.append(f"## {si}. {GN[gs]} {n}혼합 · {desc} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko}\n\n```\n{t}\n```\n")
    print(si, GN[gs], n, len(t.split()), desc[:160], t.count("forty inches"))
open(O + "LumineX_MatBlend_Core_Samples4.md", "w", encoding="utf-8").write("\n".join(o))
