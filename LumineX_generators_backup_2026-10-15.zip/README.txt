LumineX 생성 스크립트 백업 (2026-10-06)
- glassface/*.py : 시험·번들 생성 모듈 (gen_pierce_*.py 등)
- diversity/*.py : tracker.py (T 모듈)
- replay_tools/ : 대화 기록(/mnt/transcripts)에서 도구를 복원하는 스크립트 (extract.py → replay6.py)
복원 방법: 샌드박스가 초기화되면 이 zip을 /home/claude 아래에 풀고, 부족한 JSON(register_*·la_*_bundle.json)은 outputs에서 복사.

[2026-10-09 추가] 목재·석재 v2 · 힐/신발/주얼리 시험 생성기 (핸드오프 v6.36 31장)
- gen_woodstone2_600.py : 목재·석재 포뮬러 v2 600 (시드 20261016) → la_woodstone2_600_bundle.json → patch_la_woodstone2_1_json.py
- gen_wsmix2_240.py : 목재+석재 혼합 v2 240 (시드 20261017) → la_wsmix2_240_bundle.json → patch_la_wsmix2_1_json.py
  (두 생성기는 gen_woodstone_trio2.py 머리부를 exec 한다 → gen_woodstone_duo2/test4/test6 → gen_woodstone_full10 → gen_woodstone_600 → groups6 순으로 이어진다. 같은 폴더에 모두 있어야 한다. 외부: gen_cjk_v2.py, cjk_face_lib.py)
- gen_woodstone_full10.py : 부피 큰 체형 + 메이크업만 + 최극단 힐 솔로5·듀오5
- gen_woodstone_test6.py / test4.py / duo2.py / duo2b.py / heel4.py / trio2.py / q45.py : 힐 숫자 A/B(40인치 vs 숫자 없음), 10·20·30·40 비교, 주얼리, 쿼텟·퀸텟 시험
- gen_heel_ab_tracks8.py : 바디페인팅·이레즈미·UV네온·왁스 트리오 힐 A/B (소스: outputs의 la_core_bundle, la_maximalist_bundle, la_120_bundle)
- gen_heel_color3.py : 신발 색을 몸 패턴 색으로 지정(이레즈미·UV네온·왁스 트리오)
- gen_woodstone_face4/bbw4/heels3~6/full6.py : 목재·석재 얼굴·BBW·극단 힐 중간 시험들

[2026-10-09 추가 2] 바 피어싱·신발 문구 시험·교체 패치 (핸드오프 v6.37 32장)
- gen_woodstone_leg4.py / gen_woodstone_legC2.py : 힐 40인치 신발 문구 A·B·C(다리 길이 vs 체형) 시험 생성기
- patch_la_brow_ringstud_1.py : repo presets의 눈썹 바 문장 5종을 링+스터드로 교체(907개, 재실행 안전, 검증 출력 포함)
- patch_la_woodstone_shoe_c_1.py : 목재·석재 신발 문구를 C로 교체(v2 840개, --v1이면 221개 추가)
- 바 피어싱 시험(문구 A·B·C·링 샘플)은 등록 번들(la_pframe_geo_300·la_cjk_face_120)의 문장을 직접 치환해 만들었다 → 32-1 참조

[2026-10-09 v6.38] gen_xheel_300.py: 극단 힐 추가 번들 292개 생성(외부 의존 la_core/la_maximalist/la_120/la_wax_duo01_replace 번들). gen_heel_big4.py: 4~5인 힐 시험. patch_la_xheel_1_json.py: presets/la_xheel_*.json 생성.

[2026-10-10 v6.39] gen_matmix_bundle.py: Material Mix 300 생성(체인 gen_matmix_all4→gen_matmix4→gen_woodstone_full10..., 외부 bg_library.py 와 등록 번들 la_core/la_maximalist/la_120). gen_newmat6/gen_matmix4/gen_matmix_all4/gen_matmix_4fix: 시험용. bg_library.py: 배경 라이브러리 70곳. patch_la_matmix_1_json.py: presets/la_mm_*.json 생성.


[2026-10-14 v6.57] 새 영역 4종·의상 번들·밴도/벨트 시험 (핸드오프 v6.57 52~55장)
- 실행: 모든 mk_*.py 는 `export PYTHONPATH=master` 에서 실행(master/ 의 gen_*.py 를 import). 출력은 /mnt/user-data/outputs/.
- mk_area4_bundle.py : 새 영역 4종(크롬·라인스톤·프로젝션·스플래시) + 4요소 믹스 400 → la_area4_400_bundle.json → patch_la_area4_1_json.py (등록 14940)
- patch_la_wet_1_json.py : Wet Look 240. retitle_tools/ + patch_la_retitle_3/4.py : 제목 형식 교체(390 + Face Sculpt 1,202), 자체 완결·--dry·--undo.
- mk_cloth_bundle.py : 의상 번들 400 (키 la_clothes_<패밀리>_solo_NNN, 카테고리 6개) → la_cloth_400_bundle.json → patch_la_cloth_1_json.py (등록 15340, commit 96e66693). 패밀리별 문구 풀을 파일 안에 정의. 머리부는 mk_musbust2b.py 를 복사해 사용(CUSTOM 체형 근육질/아마존).
- 의상 시험 생성기(체인): mk_bust3tops → mk_bustband → mk_bandw3 → mk_bandretry → mk_bandcol2 → mk_microbust3 → mk_roundnip2/roundarel2/skirtround2/skirttri2/tribot6/roundskirt4/square2 → mk_band7 → mk_belt3/belt2/beltswim2 → mk_bandnew4 → mk_lacescarf2 → mk_scarfknot2 → mk_bandmat4 → mk_paper2 → mk_micronip2 → mk_nipple3c(3색) → mk_nipplemin2(최소화 문구).
- 그 밖: mk_micro3(마이크로 비키니)·mk_cloth5(캣슈트·메시·컷아웃·수영복)·mk_bikini4·mk_plunge2/3·mk_plungesmall_bust2·mk_plungeshort*·mk_cutlen3·mk_slit5·mk_umtop4·mk_musbust2/2b·mk_body6/8·mk_busttop3/4·mk_underbust4·mk_ubcami4/ubplunge4/ubtee4·mk_crop4·mk_cami4·mk_corsetbra2·mk_corsethigh1·mk_satin2·mk_microbot4·mk_microplunge1·mk_plungewide1·mk_rhine2.


[2026-10-14 v6.58] 코스튬·그룹 번들 (핸드오프 v6.58 56장)
- 실행: `export PYTHONPATH=master`, 출력 /mnt/user-data/outputs/.
- mk_costume_bundle.py : 코스튬 솔로 140(28종×5) + 코스튬 그룹 75 + 의상 그룹 95 = 310 → la_costume_310_bundle.json → patch_la_costume_1_json.py (등록 15650, commit 4bf14a73). 입력: cost_pool.json(코스튬 28종 문구), mk_cloth_bundle.py(의상 패밀리 풀 FAM을 exec). 시드 20267501.
- patch_la_pose_1.py : 등록된 의상 400개 중 팔짱·얼굴 감싸기 59개를 다른 포즈로 교체(--dry, --undo, pose_swap_backup.json).
- 코스튬 시험: mk_costume5(5종) → mk_costume9(9종 섹시 체형) → mk_costume3big(부피 큰 체형) → mk_costume2mus(근육질) → mk_costume2dt(의사·선생) → mk_costume6new(승무원·인어·벨리·여왕·복서·소방관) → mk_costume8more(닌자 재시험·이집트 여왕·뱀파이어·요정·군인·훌라·서퍼). 그룹 시험: mk_costumegroup4, mk_clothgroup4. 극단 체형 서 있는 포즈 시험: mk_extstand4(불채택). 밴도 손가락 2개: mk_band2bust. 유두만 비키니 색 시험: mk_nipple3c, mk_nipplemin2.

[2026-10-15 v6.59] 새 재질 6종(얼음·서리, 깃털, 회로·사이버, 진주층, 곤충 날개, 거울 파편 모자이크) 시험·번들 300 (핸드오프 57장)
- mk_newmat7.py : 새 재질 7종 솔로 샘플(헤나 포함, 헤나 실패로 제외). scratch_up/build_mk7.py 가 mk_area8.py 를 읽어 이 파일을 만든다.
- mk_newmat_grp.py : 새 재질 그룹 샘플 8개(같은 재질 2~5인 + 섞은 재질 2~5인). scratch_up/build_mkgrp.py 로 생성.
- mk_mat6_bundle.py : 새 재질 번들 300 + 새 색 확인 샘플 6 생성(시드 20261501 확인, 20261502 번들). mk_area4_bundle.py 의 변형표 앞부분을 exec 하고 scratch_up/newmat_defs.py(재질 템플릿 T_ICE 등, 색 변형)를 ../newmat_defs.py 경로로 읽는다.
  → 작업 폴더(이 zip의 최상위)의 한 단계 위에 scratch_up/ 의 파일 4개(newmat_defs.py, build_mk7.py, build_mkgrp.py, mk_leg3.py)를 두고, PYTHONPATH=master:. 로 실행. 제외할 색은 mat6_excl.json(["ice|딥 사파이어", ...])로 지정.
- mk_leg3.py : legendary bust 체형 코스튬 3개(의사·선생·간호사) 샘플. mk_costume_bundle.py 를 exec.
- 출력: la_newmat6_300_bundle.json + patch_la_newmat6_1_json.py (outputs 폴더). 접두어 la_{ice,feather,circuit,nacre,wing,mirror}_ / la_m6mix_.
