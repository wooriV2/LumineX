src = open("mk_area8.py", encoding="utf-8").read()
head = src[:src.index("# ── 템플릿 ──")]
mid = src[src.index("def mat_of"):src.index("PLAN = [")]
tail = src[src.index("rg = random.Random(20261301)"):]
new_defs = r'''
# ── 새 재질 7종 템플릿 ──
FULL = "across the full torso both legs neck to ankle"
T_ICE = LEAD + "a body-wide shell of clear and frosted ice, thick translucent ice plates and crusted hoarfrost with sharp feathery frost crystals growing outward along every curve, clear icicles hanging from her fingertips, hips and knees, cold light refracting through the ice, nothing lying flat. Dense icy surface — {base}, {acc}, {fin}, completely covering her whole body, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_FEATHER = LEAD + "layers of real feathers overlapping like plumage, small downy feathers over the torso and long sweeping quill feathers along her arms, hips and legs, every feather with its own shaft and fine barbs ruffling at the edges and casting small shadows on the feathers below, nothing lying flat. Dense plumage surface — {base}, {acc}, {fin}, completely covering her whole body, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_HENNA = "intricate hand-drawn henna mehndi patterns in dark reddish-brown paste applied directly to her skin and wrapping around every curve, dense lace-like paisleys, floral vines, mandalas and fine dot-work with delicate line work, the paste slightly raised in fine dark lines, no area of skin left plain. Dense henna surface — {base}, {acc}, {fin}, covering her whole body, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_CIRC = LEAD + "a dense printed-circuit surface grown over her entire body, raised copper traces and solder pads running in tidy right-angled lines over every curve, tiny glowing LED points and small rectangles of black silicon chips set into the surface, hair-thin lines of light pulsing along the traces, nothing lying flat. Dense circuit surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_NACRE = LEAD + "overlapping mother-of-pearl nacre tiles set edge to edge over her whole body, each tile with a fine edge and a soft milky lustre that shifts through rainbow colours across every curve, hard bright highlights, nothing lying flat. Dense nacre surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_WING = LEAD + "thin translucent insect-wing membranes layered over her whole body like overlapping dragonfly and butterfly wings, a network of fine dark veins and cells running through each wing, iridescent colour shifting across every curve, wing edges fringed with tiny scales, nothing lying flat. Dense wing surface — {base}, {acc}, {fin}, completely covering her whole body, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_MIRROR = LEAD + "hundreds of broken mirror shards of all sizes mosaicked over her entire body, each shard with sharp straight edges set at a different angle and reflecting a different piece of the surroundings, thin dark grout lines between the shards, sharp white glints flashing off every edge, nothing lying flat. Dense mirror-mosaic surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
HEAD_H = HEAD.replace("fused directly to", "drawn directly onto").replace("not a printed pattern, this is a solid {solid} ", "not a sticker, this is {solid} ")
def AV(tag, desc, solid, nmw, T, base, acc, fin, part, head=None):
    return dict(tag=tag, desc=desc, solid=solid, nmw=nmw, T=T, base=base, acc=acc, fin=fin, part=part, head=head or HEAD)
N_ICE = AV("얼음·서리", "ice-and-frost-encrusted", "shell of glacial ice", "clear frosted ice", T_ICE, f"BLAZING pale glacier-blue ice plates and white hoarfrost {FULL}", "VIVID crisp white frost crystals fanning out from the edges and clear icicles hanging from her fingertips, hips and knees, with a faint breath-mist drifting", "glassy frozen", "the ice")
N_FEA = AV("깃털 · 레이븐 블랙", "feather-covered", "coat of plumage", "glossy black feathers", T_FEATHER, f"BLAZING glossy raven-black plumage with an oil-slick purple and green sheen {FULL}", "VIVID long sweeping quill feathers trailing from her arms and hips and loose down floating in the air around her", "glossy feathered", "the plumage")
N_HEN = AV("헤나·메헨디", "henna-patterned", "a layer of henna mehndi lace-work", "henna-brown lacquer", T_HENNA, f"BLAZING deep reddish-brown henna lace-work {FULL}", "VIVID large mandala medallions on her torso and thighs, with fine dot-work and tiny floral sprigs filling every gap", "dark glossy paste", "the henna", HEAD_H)
N_CIR = AV("회로·사이버", "circuit-board", "circuit-board surface", "black circuit-board lacquer", T_CIRC, f"BLAZING matte black circuit-board surface with gold copper traces {FULL}", "VIVID electric cyan light pulses racing along the traces and small glowing LED points scattered across her torso", "etched circuitry", "the circuit board")
N_NAC = AV("진주층", "mother-of-pearl", "mother-of-pearl nacre shell", "mother-of-pearl", T_NACRE, f"BLAZING milky pearl-white nacre with pink and aqua lustre {FULL}", "VIVID soft rainbow sheen sliding across each tile and a few larger shell-pearl bumps", "polished nacre", "the nacre")
N_WIN = AV("곤충 날개", "insect-wing-covered", "layer of insect-wing membrane", "iridescent wing membrane", T_WING, f"BLAZING iridescent green-gold and violet dragonfly-wing membranes {FULL}", "VIVID dark vein networks and tiny scale-dust shimmer along the wing edges", "iridescent wing", "the wings")
N_MIR = AV("거울 파편 모자이크", "mirror-shard-mosaic", "mosaic of broken mirror shards", "mirror shards", T_MIRROR, f"BLAZING silver mirror shards {FULL}", "VIVID bright white glints off the shard edges and a few shards tinted gold and rose", "razor-edged mirror", "the mirror")
'''
plan = """import random as _R
_pr = _R.Random(20261402)
_POOL = [N_ICE, N_FEA, N_CIR, N_NAC, N_WIN, N_MIR]
PLAN = []
for _n in (2, 3, 4, 5):
    PLAN.append((f"같은 재질 {_n}인", [_pr.choice(_POOL)] * _n))
for _n in (2, 3, 4, 5):
    PLAN.append((f"섞은 재질 {_n}인", _pr.sample(_POOL, _n)))
"""
tail = tail.replace("20261301", "20261403")
tail = tail.replace("LumineX_NewArea4_Solo_Duo8.md", "LumineX_NewMat6_Group8.md")
tail = tail.replace("# 새 영역 4종 샘플 — 크롬·홀로그램 / 라인스톤 / 파우더·스플래시 / 프로젝션 매핑 (각 솔로 1 · 듀오 1)", "# 새 재질 6종 그룹 샘플 8개 — 같은 재질 2~5인 4개 · 섞은 재질 2~5인 4개")
filt = '\nPOSES = [p for p in POSES if "arms crossed under her bust" not in p and "framing the face" not in p]\n'
out = head + new_defs + filt + mid + plan + tail
open("mk_newmat_grp.py", "w", encoding="utf-8").write(out)
