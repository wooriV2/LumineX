_s = open('mk_costume_bundle.py', encoding='utf-8').read()
exec(_s[:_s.index("out = []")], globals())
rg = random.Random(20267601); rr.seed(20267601); ns2["JR"].seed(20267601)
o = ["# LumineX — legendary bust 체형 코스튬 샘플 3개 (의사 · 선생 · 간호사)\n", "체형만 legendary bust로 고정, 인종·나이·포즈·배경·힐·네일·주얼리·메이크업은 기본 랜덤입니다. 정상/이상 번호만 알려주세요.\n"]
for i, c in enumerate(["의사", "선생", "간호사"], 1):
    r = gen([COST[c]], [lambda: "legendary bust"], [None])
    pose = pose_ko(r["poses"][0]); hk = "힐 40인치" if r["heel"] == "forty" else "힐 숫자 없음"
    o.append(f"## {i}. 성인 코스튬 · {c} · 체형 legendary bust · 인종 {r['eths'][0]} · {pose} · 배경 {BGL.BG[r['bid']][2]} · {hk}\n\n```\n{r['t']}\n```\n")
    print(i, c, len(r['t'].split()), r['t'].count('forty inches'))
open(O_ + "LumineX_LegendaryBust_Costume3.md", "w", encoding="utf-8").write("\n".join(o))
