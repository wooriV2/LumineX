# -*- coding: utf-8 -*-
import re, random

banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","safety pin","gash"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    hits = [w for w in banned if w in p.lower()]
    assert not hits, (name,hits)

PHYSIQUES = [
 ("super hourglass", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum beyond any proportion, most dramatic hourglass ratio ever recorded on any human body, thighs so thick pressing together"),
 ("wide hip narrow", "hips so impossibly wide extending beyond frame creating the most extreme hip-to-waist ratio ever, waist cinched to absolute impossible minimum, upper body slim emphasizing the dramatic hip explosion"),
 ("BBW bombshell", "most massive full-figure BBW body ever at absolute maximum in every dimension, hips so wide beyond proportion dominating the entire frame, bust so enormous overwhelming gravity, waist deeply snatched despite impossible volume"),
 ("curvy petite", "smallest most compact frame possible yet curves exploding at absolute maximum in every direction, bubble butt projecting dramatically backward from the tiny frame, thighs so thick they dwarf the petite frame"),
 ("amazon bombshell", "impossibly tall commanding frame with simultaneously the most massive full-figure curves, enormous powerful presence dominating the entire frame top to bottom, legs endlessly long massively thick and powerful"),
 ("latina curves", "most dramatic hourglass ratio ever, simultaneously maximum enormous bust AND maximum enormous hips both flaring to absolute impossible extremes while the waist is cinched to impossible minimum"),
 ("hourglass bombshell", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum, thighs pressing together, every curve maximized at once"),
]
HAIRS = ["long sleek jet-black hair cascading past hips","silver-white natural hair swept into a high sculpted crown",
         "long straight platinum-silver hair past her hips","silver-white locs cascading to her waist",
         "loose beach waves mid-length tousled","blunt collarbone-length bob thick heavy",
         "curtain bangs long straight hair sweeping past the shoulders"]
POSES = [
 "strong hip pop right, both hands pressing sides of hips outward simultaneously arching back to extreme",
 "full frontal wide stance, both fists pressing outer hips outward to absolute maximum",
 "standing full height, both arms slightly spread commanding the frame",
 "back three-quarter turned, face over shoulder direct eye contact, bubble butt projected backward",
 "strong hip pop left, both hands pressing outer hips outward arching back to extreme",
]
AGES = ["early 20s","late 20s","early 30s","mid 30s","late 30s","mid 40s","early 50s","mid 50s"]
LABELS = ["#1","#2","#3","#4","#5","#6","#7"]
ASPECT = {4:"4:5",5:"5:4",6:"16:9",7:"16:9"}
NUM_WORD = {4:"FOUR",5:"FIVE",6:"SIX",7:"SEVEN"}

# ===== UV NEON =====
UV_MOTIFS = [
 ("cosmic nebula", "ELECTRIC MAGENTA nebula cloud formations swirling across the chest and upper body, VIVID NEON CYAN plasma stream formations flowing down both legs entirely, BLAZING NEON GOLD star cluster formations scattered densely filling every gap"),
 ("lightning web", "ELECTRIC EMERALD lightning bolt formations branching across the full torso both legs neck to ankle, VIVID NEON YELLOW spark burst formations filling every gap, STARK WHITE electric arc highlights"),
 ("crystal lattice", "ELECTRIC VIOLET geometric lattice facets full torso both legs to ankle, prismatic crystal faces refracting CYAN light, STARK WHITE crystal node bursts filling every gap"),
 ("ocean wave", "ELECTRIC CYAN ocean wave formations flowing organically full torso both legs neck to ankle, VIVID WHITE seafoam accent filling every gap"),
 ("dragon formations", "ELECTRIC MAGENTA dragon coiling the full torso both legs neck to ankle, VIVID NEON GREEN dragon flame formations filling every gap, STARK WHITE eye highlights"),
 ("Saturn ring", "NEON GOLD planetary ring formations circling the belly curve naturally, VIVID ORANGE supernova burst formations at each breast, STARK WHITE star pinpoints filling every remaining gap"),
 ("sound wave cymatics", "ELECTRIC GOLD cymatics geometric mandala formations vibrating full torso both legs to ankle, VIVID ORANGE Chladni pattern sand formations both legs hip to toe, STARK WHITE resonance node points filling every gap"),
]
def uv_block(idx, label, rnd):
    phy_name, phy_detail = PHYSIQUES[idx % len(PHYSIQUES)]
    motif_name, motif_ink = UV_MOTIFS[idx % len(UV_MOTIFS)]
    hair = HAIRS[idx % len(HAIRS)]; pose = POSES[idx % len(POSES)]; age = AGES[rnd.randrange(len(AGES))]
    return (f"{label}: THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, UV-reactive BLAZING {hair} — "
            f"full body UV neon {motif_name} bodypaint covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Bold formations — BLAZING {motif_ink}, NO airbrush NO gradient wash. Pose: {pose} — most extreme {phy_name} silhouette ever displayed.\n"
            f"{label}: platform boots 8 inch, extra long stiletto nails BLAZING NEON UV reactive tips.")

def build_uv(n, seed):
    rnd = random.Random(seed)
    labels = LABELS[:n]
    blocks = [uv_block(i, labels[i], rnd) for i in range(n)]
    body = "\n\n".join(blocks)
    aspect = ASPECT[n]
    p = f"""Professional fashion photograph, full body shot. {NUM_WORD[n]} women standing side by side.

{body}

MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. UV blacklight illumination only — zero white light. All: Multiple UV blacklights from all angles making every formation glow at maximum intensity, extreme high-gloss oil. CRITICAL: all {n} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere. {NUM_WORD[n]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame. 8K {aspect} aspect ratio."""
    return p

# ===== STAINED GLASS =====
GLASS_COLORS = [("ELECTRIC CRIMSON","VIVID GOLD"),("ELECTRIC VIOLET","VIVID CYAN"),("ELECTRIC EMERALD","VIVID GOLD"),
                ("ELECTRIC MAGENTA","VIVID SILVER"),("ELECTRIC COBALT","VIVID AMBER"),("ELECTRIC ROSE","VIVID TEAL"),("ELECTRIC AMBER","VIVID INDIGO")]
def glass_block(idx, label, rnd):
    phy_name, phy_detail = PHYSIQUES[idx % len(PHYSIQUES)]
    c1,c2 = GLASS_COLORS[idx % len(GLASS_COLORS)]
    hair = HAIRS[idx % len(HAIRS)]; pose = POSES[idx % len(POSES)]; age = AGES[rnd.randrange(len(AGES))]
    return (f"{label}: THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {hair} — "
            f"full body stained glass covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is solid thick glass fused directly to her form, not a garment, every pane curving to follow her body's true shape with real physical thickness, lead-line seams standing in a small raised ridge casting their own shadow, never flat. "
            f"BLAZING {c1} glass panes catching light across the full torso both legs neck to ankle, VIVID {c2} panes filling every gap, bright light passing through with sharp refraction glints bending as the glass curves, NO airbrush NO gradient wash. Pose: {pose} — most extreme {phy_name} silhouette ever displayed.\n"
            f"{label}: leaded-glass platform boots 8 inch, the glass shaped as one solid curved piece with her legs, extra long stiletto nails to match.")

def build_glass(n, seed):
    rnd = random.Random(seed)
    labels = LABELS[:n]
    blocks = [glass_block(i, labels[i], rnd) for i in range(n)]
    body = "\n\n".join(blocks)
    aspect = ASPECT[n]
    p = f"""Professional fashion photograph, full body shot. {NUM_WORD[n]} women standing side by side.

{body}

Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.
All: extreme high-gloss glass finish. CRITICAL: all {n} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere, the glass solid and curved throughout, never flat. {NUM_WORD[n]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame. 8K {aspect} aspect ratio."""
    return p

# ===== BOTANICAL =====
FLOWERS = [("peony","CRIMSON","EMERALD"),("orchid","VIOLET","GOLD"),("sakura","PINK","GOLD"),
           ("chrysanthemum","AMBER","EMERALD"),("wisteria","VIOLET","SILVER"),("rose","CRIMSON","GOLD"),("lotus","PINK","JADE")]
def bot_block(idx, label, rnd):
    phy_name, phy_detail = PHYSIQUES[idx % len(PHYSIQUES)]
    flower,c1,c2 = FLOWERS[idx % len(FLOWERS)]
    pose = POSES[idx % len(POSES)]; age = AGES[rnd.randrange(len(AGES))]
    return (f"{label}: THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, hair threaded through with real trailing vines — "
            f"full body living {flower} growing directly from her own skin covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not a printed pattern, not a dress, every stem rooted directly into her living skin and every petal standing up in true three-dimensional relief casting its own small shadow, nothing lying flat. "
            f"BLAZING {c1} {flower} blossoms in full three-dimensional bloom across the full torso both legs neck to ankle, VIVID {c2} leaves and curling tendrils filling every remaining gap with real depth and texture, NO airbrush NO gradient wash, NO flat printed surface anywhere. Pose: {pose} — most extreme {phy_name} silhouette ever displayed.\n"
            f"{label}: extreme platform heels entirely overgrown with the same living {flower} blooms and vines, extra long nails with tiny {flower} petals embedded at each tip.")

def build_bot(n, seed):
    rnd = random.Random(seed)
    labels = LABELS[:n]
    blocks = [bot_block(i, labels[i], rnd) for i in range(n)]
    body = "\n\n".join(blocks)
    aspect = ASPECT[n]
    p = f"""Professional fashion photograph, full body shot. {NUM_WORD[n]} women standing side by side.

{body}

Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.
All: Extreme macro detail on every raised petal and leaf vein. CRITICAL: all {n} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere, every petal standing in true relief, nothing flat. {NUM_WORD[n]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame. 8K {aspect} aspect ratio."""
    return p

OUT = []
for n in [4,5,6,7]:
    p = build_uv(n, seed=n*10)
    check(f"uv{n}",p)
    OUT.append((f"UV네온 {n}인", p))
for n in [4,5,6,7]:
    p = build_glass(n, seed=n*20)
    check(f"glass{n}",p)
    OUT.append((f"스테인드글라스 {n}인", p))
for n in [4,5,6,7]:
    p = build_bot(n, seed=n*30)
    check(f"bot{n}",p)
    OUT.append((f"보태니컬 {n}인", p))

for label,p in OUT:
    print(label, len(p.split()))

L = ["# LumineX · UV네온·스테인드글라스·보태니컬 — 4~7인 확장 테스트\n"]
for label,p in OUT:
    L.append(f"## {label}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_ThreeTracks_4to7_Test.md","w",encoding="utf-8").write("\n".join(L))
print("saved")
