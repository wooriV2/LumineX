# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_final3.py', encoding='utf-8').read().split("\n# ================= A.")[0])
rnd.seed(20261023)
def pct(lo, hi, step=1): return rnd.randrange(lo, hi+1, step)
NW[4] = "FOUR"; ASP[4] = "4:5"

def make_struct(kind, n, shape):
    if n <= 4: return make_structure(kind, n, shape)
    ko = "물결" if shape == "undulating" else "매끈"
    if kind == "H":
        lv = spaced(n-1, 8, 92, 12)
        pre = f"Her figure is divided into {n} horizontal bands by {n-1} hazy transition zones centred {ordinal_list(lv, down)}."
        reg = ["everything above the first transition zone"] + [f"the band between transition zone {i} and transition zone {i+1}" for i in range(1,n-1)] + ["everything below the last transition zone"]
        return pre, reg, f"가로 띠 {n}구역·{ko} ({'/'.join(map(str,lv))}%)"
    if kind == "V":
        lv = spaced(n-1, 8, 92, 12)
        pre = f"Her figure is divided into {n} vertical bands by {n-1} hazy transition zones centred {ordinal_list(lv, across)}."
        reg = ["everything to her left of the first transition zone"] + [f"the strip between transition zone {i} and transition zone {i+1}" for i in range(1,n-1)] + ["everything to her right of the last transition zone"]
        return pre, reg, f"세로 띠 {n}구역·{ko} ({'/'.join(map(str,lv))}%)"
    if kind == "D":
        d, dk = rnd.choice(DIRS); lv = spaced(n-1, 10, 90, 12)
        pre = f"Her figure is divided into {n} diagonal bands by {n-1} parallel hazy transition zones running {d} as seen by the camera, crossing the centre line of her figure {ordinal_list(lv, down)}."
        reg = ["everything on the upper side of the first diagonal transition zone"] + [f"the diagonal band between transition zone {i} and transition zone {i+1}" for i in range(1,n-1)] + ["everything on the lower side of the last diagonal transition zone"]
        return pre, reg, f"대각 띠 {n}구역·{dk}·{ko} ({'/'.join(map(str,lv))}%)"
    if kind == "C":
        c = pct(40,60); rs = spaced(n-1, 12, 92, 10)
        pre = f"Her figure is divided into {n} concentric regions around a single centre point located {down(c)} on the centre line of her figure, separated by {n-1} hazy ring-shaped transition zones at about {ordinal_list(rs, lambda r: str(r)+'%')} of the way out from that centre point to the farthest edge of her figure."
        reg = ["the innermost core around the centre point"] + [f"the ring between transition zone {i} and transition zone {i+1}" for i in range(1,n-1)] + ["the outermost region beyond the last ring"]
        return pre, reg, f"동심원 {n}구역·{ko} (중심 {c}%)"
    c = pct(40,60); parts=[2]*n
    for _ in range(12-2*n): parts[rnd.randrange(n)] += 1
    h0 = rnd.randrange(1,13); pos=[h0]
    for p in parts[:-1]: pos.append((pos[-1]+p-1)%12+1)
    pre = f"Her figure is divided into {n} wedge-shaped regions radiating from a single centre point located {down(c)} on the centre line of her figure. {n} hazy ray-shaped transition zones leave that centre pointing toward {ordinal_list(pos, lambda h: str(h)+chr(39)+'clock')} as seen by the camera, where 12 o'clock points straight up."
    reg = [f"the wedge between the {pos[i]} o'clock ray and the {pos[(i+1)%n]} o'clock ray, sweeping clockwise" for i in range(n)]
    return pre, reg, f"부채꼴 {n}구역·{ko} (중심 {c}%)"

LEAF = {"24K YELLOW GOLD":"황금","ROSE-GOLD":"로즈골드","BRIGHT SILVER":"은색","COPPER":"구리","EMERALD GREEN":"에메랄드","SAPPHIRE BLUE":"사파이어","AMETHYST VIOLET":"자수정","RUBY RED":"루비","TURQUOISE":"터콰이즈","CHAMPAGNE":"샴페인"}
def leaf_hz(shape, kind):
    return hazy_mat(shape, kind).replace("materials","leaf colours").replace("elements","flakes").replace("one material","one colour")

def leaf_person(label, n, kind, shape, phys, hair, age, pose):
    cols = rnd.sample(list(LEAF), n)
    texts = [f"applied {c} metallic leaf, thin irregular sheets laid onto the contour of her body with fine natural creases and overlapping seams, a bright {c} sheen filling every gap" for c in cols]
    pre, reg, lab = make_struct(kind, n, shape); assert sens_count(pre+" "+" ".join(reg)) == 0
    sents = " ".join(f"Region {i+1} is {reg[i]}: it carries {texts[i]}." for i in range(n))
    pn, pd = phys; prefix = f"{label}: " if label else ""
    txt = (f"{prefix}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair} — her body is covered in applied metallic leaf in {n} different colours at once, each colour claiming its own region of her figure. {pre} {sents} {leaf_hz(shape, STRUCT_KIND[kind] if kind in STRUCT_KIND else kind)}, no fabric no seam no garment anywhere, every sheet of leaf applied to her own living skin, covering her completely with no bare skin anywhere from neck to ankle. Pose: {pose}, every region clearly visible to the camera — most extreme {pn} silhouette ever displayed.\n"
           f"{prefix}extreme platform heels/boots covered in the same leaf colours at her feet, extra long nails each matching whichever region that hand falls in.")
    return txt, f"{STRUCT_KO[kind]}·{'물결' if shape=='undulating' else '매끈'}", pn, "+".join(LEAF[c] for c in cols)

def build_leaf(g, n):
    phys = rnd.sample(PHYS, g); hairs = rnd.sample(HAIRS_MX, g); ages = rnd.sample(AGES_MX, g); cells = draw_cells(g)
    blocks=[]; descs=[]
    for i in range(g):
        b, st, pn, cs = leaf_person(["#1","#2","#3","#4"][i] if g>1 else None, n, cells[i][0], cells[i][1], phys[i], hairs[i], ages[i], rnd.choice(POSES_MX))
        blocks.append(b); descs.append(f"[{st} / {pn} / {cs}]")
    if g == 1:
        tail = f"MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. ONE woman only. Extreme macro detail on every leaf sheet and every blended transition. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle. 8K portrait 2:3 aspect ratio."
    else:
        tail = (f"Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.\nAll: Extreme macro detail on every leaf sheet and every blended transition. CRITICAL: all {g} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare skin visible anywhere. {NW[g]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame. 8K portrait {ASP[g]} aspect ratio.")
    p = f"Professional fashion photograph, full body shot. {NW[g]} wom{'a' if g==1 else 'e'}n standing{' side by side, each with her own multi-colour gold-leaf body' if g>1 else ''}.\n\n" + "\n\n".join(blocks) + f"\n\n{tail}"
    return p, " ; ".join(descs)

specs = [(1,2),(1,4),(1,6),(2,3),(2,5),(3,2),(3,4),(3,6),(4,3),(4,5)]
items=[]
for g,n in specs:
    p, desc = build_leaf(g, n); p = fix(p); check("gl", p, allow_uv=False, mat=True)
    assert f"Region {n}" in p and "leaf" in p
    items.append((g, n, desc, p))
order=list(range(10)); rnd.shuffle(order); no={i:order.index(i)+1 for i in range(10)}; ranked=sorted(range(10), key=lambda i:no[i])
GN={1:"솔로",2:"듀오",3:"트리오",4:"쿼르텟"}
L=["# LumineX · 금박만으로 색 2~6종 혼합 시험 10개 (솔로·듀오·트리오·쿼르텟)\n",
   "재질은 금박 하나이고, 구역마다 금박의 색이 다릅니다. 색 수는 2~6종이고(구역 수와 같음) 색 수와 인원이 모두 두 번 이상 나오게 10개로 구성했습니다. 금박은 맥시멀리스트 문장 구조로 만들었습니다. 번호는 섞여 있습니다. **성공/실패만** 알려주세요(최대 3회, 1회/2회/3회/실패). 예: `03: 2회 / 07: 실패 / 나머지 1회`\n",
   "## 색인\n","| 번호 | 인원 | 색 수 | 구성 (구조·경계선 / 체형 / 금박 색) |","|---|---|---|---|"]
for i in ranked:
    g,n,desc,p = items[i]; L.append(f"| {no[i]:02d} | {GN[g]} | {n}색 | {desc} |")
L.append("")
for i in ranked:
    g,n,desc,p = items[i]; L.append(f"## {no[i]:02d}. {GN[g]} {n}색\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_GoldLeaf_Colors_Test_10.md","w",encoding="utf-8").write("\n".join(L))
json.dump([{"no":no[i],"gsize":items[i][0],"n":items[i][1],"desc":items[i][2]} for i in ranked], open("/home/claude/goldleaf_meta.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
print("10개 저장")
for i in ranked: print(f"  {no[i]:02d} {GN[items[i][0]]} {items[i][1]}색 {len(items[i][3].split()):>4}단어 | {items[i][2][:80]}")
