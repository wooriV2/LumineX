# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g3 = load("g3","gen3.py"); g13 = load("g13","gen13.py")
T25_ROSE = g13.T25

SPEC = [
 ("코갸루","silver","silver with a few turquoise-enamel rings",
  ", the lips parted in a bright grin so the upper front teeth and the tip of the tongue show",
  "silver barbell with two small turquoise round ends", "clear crystals set in silver", 
  "은 + 터키석색 에나멜"),
 ("히메갸루","rose-gold","rose gold with a few small pearl studs",
  ", the lips parted in a sweet smile so the upper front teeth and the tip of the tongue show",
  "rose-gold barbell with two small pearl round ends", "pale-pink crystals set in rose gold",
  "로즈골드 + 진주"),
 ("걸크러시","black-steel","black steel and silver, alternating piece by piece",
  ", the lips slightly parted in a cool, confident smirk so the upper front teeth and the tip of the tongue show",
  "black-steel barbell with two small silver round ends", "clear crystals set in silver",
  "검은 스틸 + 은"),
]
OUT = []
for sty, m, metal_txt, expr, barbell, gems, label in SPEC:
    nat, mk, face = g3.face_of(sty)
    pierce = T25_ROSE.replace("rose-gold", m)
    if sty == "히메갸루": pierce = T25_ROSE   # 이미 로즈골드
    care = g13.CARE.format(metal=metal_txt)
    p = f"""Professional fashion photograph, close-up beauty portrait. ONE woman, her face turned about 30 degrees toward the camera, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {face}{expr}. Real pores and fine skin grain, real living eyes with bright catchlights and genuine depth, individual hair strands catching the light — a photograph of a real face, not an illustration, not a render, not cel-shaded.

Piercings: {pierce} {care}

Mouth: two small {gems} are bonded to the surface of two upper front teeth, tiny and bright, catching the light. A {barbell} passes through the middle of the tongue, the tongue tip raised playfully behind the upper teeth so both round ends of the barbell show and catch the light. The teeth are natural, white and clean, and the tongue is a healthy pink, calm and healed, with no blood and no swelling.

Lighting: a soft frontal beauty light on the face with a thin cool rim light along the hair, pure pitch black void background, shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait."""
    OUT.append((sty, label, p))
if __name__ == "__main__":
    for s, l, p in OUT:
        print(s, l, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
