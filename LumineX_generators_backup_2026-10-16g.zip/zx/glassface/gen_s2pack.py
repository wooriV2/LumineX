# -*- coding: utf-8 -*-
import re, sys, random, json
from collections import Counter
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_s2_env_test.py', encoding='utf-8').read().split("\nSPECS = [")[0])      # build(specs)·struct2·덮어쓰기(꽃·수정·촛농·팔올림 제외, UV 1명)·fix·check
rnd.seed(20261031)
HAIRW = re.compile(r'\b(hair|braid|braids|braided|bun|ponytail|twin|bangs|fringe|locs|afro|bob|updo|curls|waves|ringlets|pigtails)\b', re.I)
CLAUSES = sorted({c.strip() for m in T.MAKEUP_48 for c in face(m)[1].split(',') if HAIRW.search(c)}, key=len, reverse=True)
TR=["맥시","임산부","일반"]; TYPES=["STR","CHV","MON","DOT","SG"]
TN={1:"solo",2:"duo",3:"trio"}; TY={1:"Solo",2:"Duo",3:"Trio"}; ASPV={1:"2:3",2:"3:4",3:"4:5"}
def tracks_for(g):
    if g == 1: return [rnd.choice(TR)]
    if g == 2: return [rnd.choice(TR), rnd.choice(TR)]
    if rnd.random() < 0.4: t = rnd.choice(TR); return [t, t, t]
    a, b = rnd.sample(TR, 2); L = [a, a, b] if rnd.random() < 0.5 else [a, b, b]; return rnd.sample(L, 3)     # 트리오는 트랙 최대 2종
P=[]
for g in [1,2,3]:
    for slot in range(1,41):
        key=f"la_s2pack_{TN[g]}_{slot:02d}"; trk = tracks_for(g); typs = rnd.sample(TYPES, g)
        p, desc = build(list(zip(trk, typs))); p = fix(p); check(key, p, allow_uv=True, mat=True)
        assert not any(c in p for c in CLAUSES), key
        structs=[d.strip("[]").split(" / ")[0] for d in desc.split(" ; ")]
        P.append({"key":key,"category":"🏺 Living Artifact · Structure Pack Formula","title":f"Structure Pack {TY[g]} #{slot:02d} ({' / '.join(structs)})","prompt":p,
            "meta":{"group_size":g,"aspect_ratio":ASPV[g],"format":"structure-pack-material","layout":"geometry-hazy-stage2","tracks":trk,"structures":structs}})
assert len(P)==120 and len({x["key"] for x in P})==120
json.dump(P, open("la_s2pack_geo_120_bundle.json","w",encoding="utf-8"), ensure_ascii=False, indent=2)
print("생성:", len(P), "개")
for g in [1,2,3]:
    ws=[len(x["prompt"].split()) for x in P if x["meta"]["group_size"]==g]; print(f"  {TY[g]}: {min(ws)}~{max(ws)}단어")
print("구조 분포(인물):", dict(Counter(s.split(" ")[1].split("·")[0] if " " in s else s for x in P for s in x["meta"]["structures"])))
print("트랙 분포(인물):", dict(Counter(t for x in P for t in x["meta"]["tracks"])))
print("트리오 트랙 종류 수:", dict(Counter(len(set(x["meta"]["tracks"])) for x in P if x["meta"]["group_size"]==3)))
print("UV 2명 이상 이미지:", sum(x["prompt"].count("UV-reactive neon bodypaint")>=2 for x in P))
