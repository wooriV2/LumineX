# -*- coding: utf-8 -*-
import re, sys, random
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_layout_test.py', encoding='utf-8').read().split("outA=[]; outB=[]")[0])   # build_A/build_B/region_block 등 재사용
rnd.seed(424242)

SENS = ["chest","belly","sternum","throat","pelvis","inner thighs","flank","flanks","ribs","hips","hip","thighs","back","bust","breast","shoulder","shoulders","arm","arms","leg","legs","torso","waist"]
def sens_count(txt): return sum(len(re.findall(r'\b'+t+r'\b', txt.lower())) for t in SENS)

def pct(lo, hi, step=5): return rnd.randrange(lo, hi+1, step)
def two(lo, hi, gap):
    while True:
        a, b = sorted((pct(lo,hi), pct(lo,hi)))
        if b-a >= gap: return a, b
def three(lo, hi, gap):
    while True:
        v = sorted(pct(lo,hi) for _ in range(3))
        if v[1]-v[0] >= gap and v[2]-v[1] >= gap: return v

DIRS = [("from the upper left to the lower right","좌상→우하"),("from the upper right to the lower left","우상→좌하")]
def down(p): return f"about {p}% of the way down her figure from the top"
def across(p): return f"about {p}% of the way across her figure from her left edge"

def rand_layout(n, kind=None):
    if n == 2:
        kind = kind or rnd.choice(["H","V","D"])
        if kind == "H":
            a = pct(25,75)
            return ("H", f"가로 1컷 {a}%", f"A single soft line runs horizontally across her figure {down(a)}.", ["everything above that line","everything below that line"])
        if kind == "V":
            a = pct(25,75)
            return ("V", f"세로 1컷 {a}%", f"A single soft line runs vertically down her figure {across(a)}.", ["everything to her left of that line","everything to her right of that line"])
        d, dk = rnd.choice(DIRS); h = pct(30,70)
        return ("D", f"대각 1컷 {dk} {h}%", f"A single soft diagonal line runs {d} as seen by the camera, crossing the centre line of her figure {down(h)}.", ["everything on the upper side of that diagonal","everything on the lower side of that diagonal"])
    if n == 3:
        kind = kind or rnd.choice(["HH","VV","DD","THV","TVH"])
        if kind == "HH":
            a,b = two(20,80,20)
            return ("HH", f"가로 2컷 {a}%/{b}%", f"Two soft lines run horizontally across her figure, the first {down(a)} and the second {down(b)}.", ["everything above the first line","the band between the two lines","everything below the second line"])
        if kind == "VV":
            a,b = two(20,80,20)
            return ("VV", f"세로 2컷 {a}%/{b}%", f"Two soft lines run vertically down her figure, the first {across(a)} and the second {across(b)}.", ["everything to her left of the first line","the strip between the two lines","everything to her right of the second line"])
        if kind == "DD":
            d, dk = rnd.choice(DIRS); a,b = two(25,75,20)
            return ("DD", f"대각 평행2컷 {dk} {a}%/{b}%", f"Two soft parallel diagonal lines run {d} as seen by the camera, the first crossing the centre line of her figure {down(a)} and the second {down(b)}.", ["everything on the upper side of the first diagonal","the band between the two diagonals","everything on the lower side of the second diagonal"])
        if kind == "THV":
            h = pct(25,60); x = pct(35,65)
            return ("THV", f"T형 가로{h}%+하부 세로{x}%", f"A soft line runs horizontally across her figure {down(h)}. Below that line only, a second soft line runs vertically down her figure {across(x)}.", ["everything above the horizontal line","the lower area to her left of the vertical line","the lower area to her right of the vertical line"])
        h = pct(30,70); x = pct(35,65); side = rnd.choice(["left","right"]); other = "right" if side=="left" else "left"
        return ("TVH", f"T형 세로{x}%+{side} 가로{h}%", f"A soft line runs vertically down her figure {across(x)}. On the {side} side of that line only, a second soft line runs horizontally {down(h)}.", [f"everything to her {other} of the vertical line", f"the upper part of her {side} side", f"the lower part of her {side} side"])
    kind = kind or rnd.choice(["HHH","HV","X"])
    if kind == "HHH":
        a,b,c = three(15,85,15)
        return ("HHH", f"가로 3컷 {a}/{b}/{c}%", f"Three soft lines run horizontally across her figure, at {down(a)}, {down(b)} and {down(c)}.", ["everything above the first line","the band between the first and second lines","the band between the second and third lines","everything below the third line"])
    if kind == "HV":
        h = pct(30,70); x = pct(35,65)
        return ("HV", f"십자 가로{h}%+세로{x}%", f"A soft horizontal line crosses her figure {down(h)}, and a soft vertical line crosses it {across(x)}, dividing her figure into four areas.", ["the upper-left area","the upper-right area","the lower-left area","the lower-right area"])
    h = pct(35,65)
    return ("X", f"X자 교차 {h}%", f"Two soft diagonal lines cross each other at the centre line of her figure {down(h)}, one running from the upper left to the lower right and the other from the upper right to the lower left, dividing her figure into four wedges.", ["the top wedge","the bottom wedge","the left wedge","the right wedge"])

outA=[]; outB=[]; kinds_used=[]
plan = {2:["H","V","D"], 3:["HH","VV","DD","THV","TVH"], 4:["HHH","HV","X"]}
for n in [2,3,4]:
    ks = rnd.sample(plan[n], 2)
    for k in ks:
        lay = rand_layout(n, k)
        assert sens_count(lay[2]+" "+" ".join(lay[3])) == 0, lay
        pA, phys, ms = build_A(n, lay); validate(f"gA_{n}_{k}", pA)
        outA.append((f"{n}혼합 · {lay[1]} — {phys} / 재질: {ms}", pA))
        pB, body, mk, cr = build_B(n, lay); validate(f"gB_{n}_{k}", pB)
        outB.append((f"{n}혼합 · {lay[1]} — {body} / {mk} / 공예: {cr}", pB))
        kinds_used.append((n,k,lay[1]))

for name,out,title in [("Material",outA,"재질(맥시멀리스트)"),("Craft",outB,"바디페인팅 공예(실사)")]:
    L=[f"# LumineX · 랜덤 컷(기하학 문구) 테스트 — {title}, 솔로 {len(out)}개\n\n경계를 부위 이름 없이 선의 방향·위치(%)로만 적었습니다. 위치 숫자는 매번 랜덤입니다.\n"]
    for label,p in out:
        L.append(f"## {label}\n"); L.append("```"); L.append(p); L.append("```\n")
    open(f"/tmp/rep_out/LumineX_RandomCut_Test_{name}.md","w",encoding="utf-8").write("\n".join(L))
for n,k,l in kinds_used: print(n, k, l)
# 반복 여부: 같은 종류를 큰 수로 뽑았을 때 서로 다른 레이아웃이 몇 개 나오는지
sig=set()
for _ in range(300):
    n=rnd.choice([2,3,4]); sig.add(rand_layout(n)[2])
print("랜덤 300번 뽑기 → 서로 다른 컷 문장:", len(sig), "개")
print("A 단어수:", [len(p.split()) for _,p in outA]); print("B 단어수:", [len(p.split()) for _,p in outB])
