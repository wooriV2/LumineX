# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_final3.py', encoding='utf-8').read().split("\n# ================= A.")[0])     # PHYS·HAIRS_MX·AGES_MX·POSES_MX(정면 포즈만)·NW·ASP·validate·dd ...
rnd.seed(20261101)
SCHEMES = [("DEEP CRIMSON","AMBER"),("DEEP EMERALD","GOLD"),("DEEP VIOLET","ROSE")]
KO = {"DEEP CRIMSON":"크림슨","DEEP EMERALD":"에메랄드","DEEP VIOLET":"바이올렛"}

def wax_person(label, scheme, phys, hair, age, pose):
    c1, c2 = scheme; pn, pd = phys; px = f"{label}: "
    txt = (f"{px}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair} — full body molten wax flowing and set directly over her own skin covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not a printed pattern, this is real wax that has flowed down every curve and hardened in place, each drip and pooled ridge standing in true three-dimensional relief, casting its own small soft shadow, nothing lying flat. Dense flowing drips — BLAZING {c1} molten wax streams pooling and hardening across her whole body from neck to ankle, VIVID {c2} translucent drip-ridges catching the light filling every remaining gap with real depth and texture, each ridge glossy and rounded exactly like real set wax, NO airbrush NO gradient wash, NO flat printed surface anywhere. Pose: {pose}, her whole body clearly visible to the camera — most extreme {pn} silhouette ever displayed.\n"
           f"{px}extreme platform heels entirely coated in the same hardened wax drips, extra long nails with tiny wax drip tips at each nail.")
    return txt, f"{pn}", f"{KO[c1]}"

def build_wax(g):
    phys = rnd.sample(PHYS, g); hairs = rnd.sample(HAIRS_MX, g); ages = rnd.sample(AGES_MX, g); sch = rnd.sample(SCHEMES, g)
    blocks=[]; descs=[]
    for i in range(g):
        b, pn, cn = wax_person(f"#{i+1}", sch[i], phys[i], hairs[i], ages[i], rnd.choice(POSES_MX)); blocks.append(b); descs.append(f"[{pn} / 촛농 {cn}]")
    p = (f"Professional fashion photograph, full body shot. {NW[g]} women standing side by side.\n\n" + "\n\n".join(blocks) +
         f"\n\nEnvironment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.\nAll: Extreme macro detail on every surface texture and shadow. CRITICAL: all {g} women's legs must show FULL wax coverage from hip to ankle to toe with NO bare skin visible anywhere, every element standing in true relief, nothing flat. {NW[g]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame. 8K portrait {ASP[g]} aspect ratio.")
    return p, " ; ".join(descs)

items=[]
for g in [2,2,2,3,3,3]:
    p, desc = build_wax(g); p = dd(p).replace(",,", ",")
    validate("wax", p); assert "overhead" not in p.lower() and "back three-quarter" not in p
    assert not [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", p) if m.group(1).lower() not in ("had","that")]
    items.append((g, desc, p))
order=list(range(6)); rnd.shuffle(order); no={i:order.index(i)+1 for i in range(6)}; ranked=sorted(range(6), key=lambda i:no[i])
GN={2:"듀오",3:"트리오"}
L=["# LumineX · 촛농 단일 재질 듀오·트리오 시험 6개 (새로 작성)\n",
   "촛농 하나만 전신에 입힌 구성입니다(혼합 아님). 등록된 Wax Formula 문장을 바탕으로 하되 뒤돌아선 자세(back three-quarter)를 빼고 정면 계열 포즈만 쓰고, 몸 부위 나열 표현(\"full torso both legs\")과 어긋난 마지막 문장(\"untattooed skin\")을 정리했습니다. 번호는 섞여 있습니다. **성공/실패만** 알려주세요(최대 3회). 예: `3: 2회 / 5: 실패 / 나머지 1회`\n",
   "## 색인\n","| 번호 | 인원 | 구성 (체형 / 촛농 색) |","|---|---|---|"]
for i in ranked: g,desc,p = items[i]; L.append(f"| {no[i]:02d} | {GN[g]} | {desc} |")
L.append("")
for i in ranked: g,desc,p = items[i]; L.append(f"## {no[i]:02d}. {GN[g]}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_Wax_Single_Group_Test_6.md","w",encoding="utf-8").write("\n".join(L))
print("6개 저장")
for i in ranked: print(f"  {no[i]:02d} {GN[items[i][0]]} {len(items[i][2].split()):>4}단어 | {items[i][1][:100]}")
