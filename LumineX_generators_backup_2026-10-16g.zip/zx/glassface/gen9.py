# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re, copy
spec = importlib.util.spec_from_file_location("g7","gen7.py"); g7 = importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(io.StringIO()):
    spec.loader.exec_module(g7)
g = g7.g; OLD = g7.OLD
NEW = "All jewelry is real opaque metal, passing through drilled openings in the carved material (through real flesh for the lips), never turning into the material. Brow bars stay on the brow bone and every stud stays at least a finger's width from the eyes, all kept clear of the eyeballs. Piercings on the centre line hang across the jagged line and stay bright real metal on both halves."

P80 = ("An extreme, dense armour of about eighty real metal piercings covering the face: a thick black-steel septum ring with a smaller ring above it and two black-steel rings through each nostril; a straight black-steel bar across the bridge of the nose between the brows; "
 "four thick black-steel bars stacked through the outer half of each eyebrow; a row of five small black-steel studs across the forehead above the brows; three small studs up each temple on the bone, well clear of the eyes; a row of five small studs along each cheekbone; a black-steel Medusa stud above the lips; "
 "a big black-steel hoop, two smaller rings and a snake-bite ring on each side through the lower lip's edge, and four small hoops along the upper lip's edge; a black-steel labret stud and three rings through the chin; four small studs along each jaw; "
 "on each ear a full dense row of eight big hoops, thick bars, stretched plugs, helix rings and studs from lobe to top; and six fine black-steel chains looping from the ear hoops to the nostril rings and the septum ring.")
P100 = ("An extreme, dense armour of about one hundred real metal piercings covering the face: a thick black-steel septum ring with a smaller ring above it and two black-steel rings through each nostril; a straight black-steel bar across the bridge of the nose between the brows; "
 "five thick black-steel bars stacked through the outer half of each eyebrow; two rows of four small black-steel studs across the forehead above the brows; four small studs up each temple on the bone, well clear of the eyes; a row of six small studs along each cheekbone; a black-steel Medusa stud above the lips; "
 "a big black-steel hoop, two smaller rings and a snake-bite ring on each side through the lower lip's edge, and five small hoops along the upper lip's edge; a black-steel labret stud and four rings through the chin; five small studs along each jaw; "
 "on each ear a full dense row of ten big hoops, thick bars, stretched plugs, helix rings and studs from lobe to top; and eight fine black-steel chains looping from the ear hoops to the nostril rings and the septum ring.")

OUT = []
for name, txt in (("P80", P80), ("P100", P100)):
    r = copy.deepcopy(g.ROWS[6]); r["tier"] = name; r["pierce"] = txt
    _, an, bn, p = g.build(r)
    assert OLD in p
    OUT.append((name, p.replace(OLD, NEW)))
for n, p in OUT:
    print(n, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
