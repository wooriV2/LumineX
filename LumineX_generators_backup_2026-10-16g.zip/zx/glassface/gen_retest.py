# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_final3.py', encoding='utf-8').read().split("\n# ================= A.")[0])     # 덮어쓰기(꽃·수정·촛농·팔올림 제외, UV 1명)·person_pm·region_sents·alt_seq ...
rnd.seed(20261019)
def pct(lo, hi, step=1): return rnd.randrange(lo, hi+1, step)

def d_row():
    row = rnd.randrange(len(D["makeup"]))
    return (AGE_EN_FULL[D["age"][row]], VIBE_EN_FULL[D["vibe"][row]], SHOE_EN_FULL[D["shoe"][row]],
            pierce_phrase(D["pierce_p"][row],D["pierce_c"][row],D["pierce_g"][row],D["pierce_f"][row],D["pierce_s"][row],D["pierce_m"][row]),
            f"{JQ_SHORT[D['jq'][row]]} of {JMETAL_EN[D['jmetal'][row]]} {JTYPE_EN[D['jtype'][row]]}")

def wrap(blocks, g, who):
    if g == 1:
        return (f"Professional fashion photograph, full body shot. ONE woman standing or kneeling as described.\n\nSubject: {blocks[0]}\n\nBackground: a plain seamless deep-charcoal backdrop, nothing else in frame. Lighting: a single hard key light raking in from one side, sharp focus head to toe, realistic photographic grain, a real photograph not an illustration not CGI not a render. Pattern density maximum, zero bare skin from neck to ankle. 2:3 vertical 8K portrait, taller than it is wide.")
    return (f"Professional fashion photograph, full body shot. {NUM_WORD[g]} women standing side by side, each {who}.\n\n" + "\n\n".join(blocks) +
            f"\n\nBackground: a plain seamless deep-charcoal backdrop, nothing else in frame. Composition: each woman's own pose as described, inner arms not crossing her neighbours, generous spacing so every figure reads clearly. Lighting: a single hard key light raking across all of them from one side, sharp focus head to toe on each, realistic photographic grain, a real photograph not an illustration not CGI not a render. Pattern density maximum, zero bare skin from neck to ankle on any of them. Shot on a Hasselblad X2D, {ASPECT[g]} aspect ratio, 8K.")

# ---------- 임산부 2혼합(공예, 패턴 2종을 3~4구역에 번갈아) ----------
def person_p2(label, makeup, bodykey, n, kind, shape, solo):
    nat, fa = face_nohair(makeup); age, vibe, shoe, pierce, jewelry = d_row()
    hair = f"{HAIR_COLOR_EN_FULL[rnd.choice(T.HAIR_COLOR)]} hair styled in {HAIR_EN_FULL[rnd.choice(T.HAIR_STYLE)]}"
    bodytext = ALL_PREG[bodykey].replace("a high, smoothly rounded pregnant belly", f"a high, smoothly rounded pregnant belly, {BELLY_BOOST},", 1)
    pose = rnd.choice(POSES); crafts = rnd.sample(T.CRAFTS_39, 2)
    pre, reg, lab = make_structure(kind, n, shape); assert sens_count(pre+" "+" ".join(reg)) == 0
    texts=[]
    for c in crafts:
        cn,cd,cb,cf = CRAFT_DB_FULL[c]; texts.append(f"{cn} ({cd}), wide {cb} bands following the contours of the body, with {cf} filling the space between bands")
    sents = region_sents(reg, alt_seq(n), texts, "is painted in")
    paint = (f"{'Full body painted' if solo else 'Painted'} in 2 different traditional patterns repeated across {n} regions of her figure, covering every inch of skin from neck to ankle without exception, the patterns reading as a continuous second skin with no gaps. {pre}{ALT.format(what='patterns')} {sents} {hz(shape, KINDKEY[kind])} The bands of every pattern curve fully around her belly like contour lines circling a globe, the rounded surface of her belly staying fully covered as part of whichever region it falls in, with the same density continuing in full strength over her bust, nowhere on her body left bare. ")
    head = f"{nat} woman, an adult, in her {age}, {vibe} expression" if solo else f"{label}: {nat}, in her {age}, {vibe} expression"
    block = (f"{head}, warm radiant skin tone, extraordinarily large pregnant physique far beyond any real person — {bodytext} Her face is a real living adult face, {fa}, {hair}, real pores, real living eyes, {pierce}, wearing {jewelry}. {paint}Pose: {pose}, " +
             (f"her whole silhouette filling the frame from head to her {shoe}, the platform soles rising far higher than her ankle bone." if solo else f"her {shoe}, the platform soles rising far higher than her ankle bone."))
    return block, f"{STRUCT_KO[kind]} {n}구역·{'물결' if shape=='undulating' else '매끈'}", f"{bodykey}/{makeup}", "+".join(crafts)

def build_p2(g, n, mk):
    kinds = rnd.sample(["H","V","D","C","R"] if n==4 else ["H","V","D","C"], g)
    bodies = rnd.sample(STABLE_BODIES, g); blocks=[]; descs=[]
    for i in range(g):
        b, st, who, cr = person_p2(f"#{i+1}", mk[i], bodies[i], n, kinds[i], rnd.choice(["smooth","undulating"]), g==1)
        blocks.append(b); descs.append(f"[{st} / {who} / {cr}]")
    return wrap(blocks, g, "an extraordinarily large pregnant woman, far beyond any real person"), " ; ".join(descs)

# ---------- 일반인 몸에 재질 섞기 재도전 (임산부에서 잘 된 문장 구조를 그대로 사용) ----------
def person_gf(label, makeup, bodykey, n, kind, shape, solo):
    nat, fa = face_nohair(makeup); age, vibe, shoe, pierce, jewelry = d_row()
    hair = f"{HAIR_COLOR_EN_FULL[rnd.choice(T.HAIR_COLOR)]} hair styled in {HAIR_EN_FULL[rnd.choice(T.HAIR_STYLE)]}"
    bodytext = BODY_FULL[bodykey]; pose = POSE_EN_FULL[rnd.choice(FRONT_POSES)]
    mats = pick_noUV(n); texts = [mat_text(m)[0] for m in mats]
    pre, reg, lab = make_structure(kind, n, shape); assert sens_count(pre+" "+" ".join(reg)) == 0
    sents = " ".join(f"Region {i+1} is {reg[i]}: it carries {texts[i]}." for i in range(n))
    body = (f"{'Full body fused' if solo else 'Fused'} with {n} different materials instead of ordinary skin below the collarbones, each material claiming its own region of her figure, covering every inch from neck to ankle without exception, the materials reading as one continuous second skin with no gaps. "
            f"{pre} {sents} {hazy_mat(shape, STRUCT_KIND[kind])} The materials of every region continue in full strength over her whole figure, nowhere on her body left bare, no fabric no seam no garment anywhere. ")
    head = f"{nat} woman, an adult, in her {age}, {vibe} expression" if solo else f"{label}: {nat}, in her {age}, {vibe} expression"
    block = (f"{head}, warm radiant skin tone — {bodytext} Her face is a real living adult face, {fa}, {hair}, real pores, real living eyes, {pierce}, wearing {jewelry}. {body}Pose: {pose}, " +
             (f"her whole silhouette filling the frame from head to her {shoe}, the platform soles rising far higher than her ankle bone." if solo else f"her {shoe}, the platform soles rising far higher than her ankle bone."))
    return block, f"{STRUCT_KO[kind]}·{'물결' if shape=='undulating' else '매끈'}", f"{bodykey}/{makeup}", "+".join(MAT_KO[m] for m in mats)

def build_gf(g, n, mk):
    cells = draw_cells(g); bodies = rnd.sample(VOLBODY, g); blocks=[]; descs=[]
    for i in range(g):
        b, st, who, ms = person_gf(f"#{i+1}", mk[i], bodies[i], n, cells[i][0], cells[i][1], g==1)
        blocks.append(b); descs.append(f"[{st} / {who} / {ms}]")
    return wrap(blocks, g, "an extraordinarily large woman, far beyond any real person"), " ; ".join(descs)

items=[]; MK = rnd.sample(T.MAKEUP_48, 24); k=0
def add(tag, g, n, desc, p, mat):
    p = fix(p); check("t", p, allow_uv=False, mat=mat); items.append((tag, g, n, desc, p))
for g,n in [(1,3),(1,4),(2,3),(2,4),(3,3),(3,4)]:
    p, d = build_p2(g, n, MK[k:k+g]); k += g; add("임산부 2혼합", g, n, d, p, mat=False)
for g,n in [(1,3),(1,4),(1,3),(2,3),(2,4),(3,3)]:
    p, d = build_gf(g, n, MK[k:k+g]); k += g; add("일반인 재질", g, n, d, p, mat=True)
order=list(range(12)); rnd.shuffle(order); no={i:order.index(i)+1 for i in range(12)}; ranked=sorted(range(12), key=lambda i:no[i])
GN={1:"솔로",2:"듀오",3:"트리오"}
L=["# LumineX · 임산부 2혼합 6개 + 일반인 재질 재도전 6개\n",
   "**임산부 2혼합**은 패턴 2종을 3~4구역에 A, B, A(, B) 순서로 번갈아 칠한 것이고, **일반인 재질**은 일반인 몸에 재질 3~4종을 섞은 것입니다. 일반인 쪽은 지난번에 실패가 몰렸던 문장 형식 대신, 임산부에서 잘 된 문장 구조를 그대로 가져왔습니다. 재질은 꽃·수정·촛농을 뺐고 팔 올린 자세도 뺐습니다. 번호는 섞여 있습니다. **성공/실패만** 알려주세요(최대 3회, 1회/2회/3회/실패). 예: `03: 2회 / 07: 실패 / 나머지 1회`\n",
   "## 색인\n","| 번호 | 구분 | 인원 | 구역 수 | 구성 (구조·경계선 / 체형 / 메이크업 / 구성) |","|---|---|---|---|---|"]
for i in ranked:
    t,g,n,desc,p = items[i]; L.append(f"| {no[i]:02d} | {t} | {GN[g]} | {n} | {desc} |")
L.append("")
for i in ranked:
    t,g,n,desc,p = items[i]; L.append(f"## {no[i]:02d}. {t} · {GN[g]} {n}구역\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_Retest_12.md","w",encoding="utf-8").write("\n".join(L))
json.dump([{"no":no[i],"tag":items[i][0],"gsize":items[i][1],"n":items[i][2],"desc":items[i][3]} for i in ranked], open("/home/claude/retest_meta.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
print("12개 저장")
for i in ranked: print(f"  {no[i]:02d} {items[i][0]} {GN[items[i][1]]} {items[i][2]}구역 {len(items[i][3].split()):>4}단어 | {items[i][2] and items[i][3][:70]}")
