# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re, copy
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g3 = load("g3","gen3.py"); g13 = load("g13","gen13.py"); g11 = load("g11","gen11.py")
g5 = g11.g   # gen5 module (build)
T25 = g13.T25
nat, mk, face = g3.face_of("강남언니")

# ------------------ 실사 3개 ------------------
CARE = g13.CARE.format(metal="rose gold")
def real(extra_par, face_text=face):
    return f"""Professional fashion photograph, close-up beauty portrait. ONE woman, her face turned about 30 degrees toward the camera, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {face_text}. Real pores and fine skin grain, real living eyes with bright catchlights and genuine depth, individual hair strands catching the light — a photograph of a real face, not an illustration, not a render, not cel-shaded.

Piercings: {T25} {CARE}

{extra_par}

Lighting: a soft frontal beauty light on the face with a thin cool rim light along the hair, pure pitch black void background, shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait."""

REAL = [
 ("실사-1","초커","Neckwear: a black velvet choker with a small rose-gold ring at the front sits snugly at the base of the neck, resting flat on the skin. It is real velvet and real metal, soft and matte, and never covers the piercings or the jaw."),
 ("실사-2","진주 헤어 핀","Hair ornaments: six pearl hairpins and a few small pearl clips are pushed into the hair above the ears and around the crown, real glossy pearls on fine rose-gold pins, arranged neatly so the hair and the face stay clearly visible."),
 ("실사-3","치아 젬",None),
]
real_out = []
for tier, label, par in REAL:
    if label == "치아 젬":
        ft = face.replace("glossy peach-pink lips", "glossy rose-coral lips") if False else face
        ft = ft + ", the lips parted in a poised smile that shows the upper front teeth"
        par = "Tooth gems: two small rose-gold-set crystals are bonded to the surface of two upper front teeth, tiny and bright, catching the light, the teeth otherwise natural, white and clean."
        real_out.append((tier, label, real(par, ft)))
    else:
        real_out.append((tier, label, real(par)))

# ------------------ 투명 재질 4개 ------------------
BASE = dict(ko="강남언니", nat="Korean", mk="Gangnam-eonni", a="amber", b="cobalt",
  eyes="dark brown irises", gaze="a poised, refined, confident gaze",
  lips="a plump glossy rose-coral real lipstick sitting on real skin, in a poised, confident smile",
  lashes="full natural lashes carved as fine raised fibres and a precise winged liner carved as a fine dark line at each outer corner",
  hair="the long sleek chestnut waves are carved as soft sculpted waves falling around the face and behind the ears, each a chiselled ribbon of solid material with a polished surface",
  makeup="Softly defined brown bands blend across the carved lids as a darker tone within the surface, a satin highlight glows on the carved cheekbones as a paler tone within the material, and a sculpted contour runs beneath as a deeper tone.",
  pierce=T25, lipp=True, orn="", tier="25")
OLD = re.compile(r"All jewelry is real opaque metal, pearl, enamel or acrylic, passing through[^.]*\.")
NEWRULE = "All jewelry is real opaque metal, pearl, enamel or acrylic, passing through drilled openings in the carved material (through real flesh for the lips), never turning into the material. Brow bars stay on the brow bone, all kept clear of the eyeballs. Piercings on the centre line hang across the jagged line and stay bright real metal on both halves."

DEC = [
 ("투명-1","초커", dict(orn="A black velvet choker with a small rose-gold ring at the front sits snugly around the base of the carved neck. It is real velvet and real metal, soft and matte, and stays exactly so, never turning into the material.")),
 ("투명-2","진주 헤어 핀", dict(orn="Six pearl hairpins and a few small pearl clips are pushed into the carved hair above the ears and around the crown, real glossy pearls on fine rose-gold pins, staying exactly so and never turning into the material.")),
 ("투명-3","호박 속 내포물", dict(makeup=BASE["makeup"] + " Inside the amber half, tiny dried flower petals and a small fern leaf hang suspended deep within the cheek, jaw and neck, with one tiny insect caught in the amber near the temple, all clearly visible through the material and never near the eyeball.")),
 ("투명-4","금 균열선(킨츠기)", dict(makeup=BASE["makeup"] + " Fine metallic-gold kintsugi crack lines run through the cobalt glass half of the face and neck, following the cheekbone, the jaw and the column of the neck like the repaired seams of broken porcelain, thin and branching and glowing gold, the glass still solid and whole all the way through, the lines never crossing the eyeball or the lips.")),
]
tr_out = []
for tier, label, over in DEC:
    r = copy.deepcopy(BASE); r.update(over)
    _, an, bn, p = g5.build(r)
    p, n = OLD.subn(NEWRULE, p, count=1); assert n == 1
    tr_out.append((tier, label, p))

if __name__ == "__main__":
    for t, l, p in real_out + tr_out:
        print(t, l, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
