# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_layout_test.py', encoding='utf-8').read().split("outA=[]; outB=[]")[0])   # validate, face_nohair, cap, VOLBODY, craft_bodyart, FRONT_POSES 등
rnd.seed(20261005)

SENS = ["chest","belly","sternum","throat","pelvis","inner thighs","flank","flanks","ribs","hips","hip","thighs","back","bust","breast","shoulder","shoulders","arm","arms","leg","legs","torso","waist"]
def sens_count(txt): return sum(len(re.findall(r'\b'+t+r'\b', txt.lower())) for t in SENS)
def pct(lo,hi,step=5): return rnd.randrange(lo,hi+1,step)
def spaced(k, lo, hi, gap):
    while True:
        v = sorted(pct(lo,hi) for _ in range(k))
        if all(v[i+1]-v[i] >= gap for i in range(k-1)): return v
def down(p): return f"about {p}% of the way down her figure from the top"
def across(p): return f"about {p}% of the way across her figure from her left edge"
def ordinal_list(vs, f):
    parts=[f(v) for v in vs]
    return parts[0] if len(parts)==1 else ", ".join(parts[:-1])+" and "+parts[-1]

DIRS = [("from the upper left to the lower right","좌상→우하"),("from the upper right to the lower left","우상→좌하")]

def hazy(shape, kind):
    s = ("The boundaries between regions are hazy and feathered — there is no visible line at all. Each transition zone is about a hand's width wide, and across it the neighbouring patterns dissolve into each other, motifs from one thinning out as motifs from the other appear, density fading rather than stopping abruptly, never a hard edge.")
    noun = {"band":"straight","diag":"straight","conc":"perfectly circular","rad":"straight"}[kind]
    if shape == "undulating":
        s += f" Each transition zone follows a gently undulating wave, rising and falling softly, rather than a {noun} course."
    else:
        s += f" Each transition zone follows a smooth, even, {noun} course."
    return s

def make_structure(kind, n, shape):
    """returns (pre, regions, label_ko)"""
    ko_shape = "물결" if shape=="undulating" else "매끈"
    if kind == "H":
        lv = spaced(n-1, 20, 80, 15 if n==4 else 20) if n>2 else [pct(25,75)]
        pre = f"Her figure is divided into {n} horizontal bands by {n-1} hazy transition zone{'s' if n>2 else ''} centred {ordinal_list(lv, down)}."
        reg = ["everything above the first transition zone"] + [f"the band between transition zone {i} and transition zone {i+1}" for i in range(1,n-1)] + [f"everything below the {'last' if n>2 else 'first'} transition zone"]
        return pre, reg, f"가로 띠 {n}구역·{ko_shape} ({'/'.join(map(str,lv))}%)"
    if kind == "V":
        lv = spaced(n-1, 20, 80, 15 if n==4 else 20) if n>2 else [pct(25,75)]
        pre = f"Her figure is divided into {n} vertical bands by {n-1} hazy transition zone{'s' if n>2 else ''} centred {ordinal_list(lv, across)}."
        reg = ["everything to her left of the first transition zone"] + [f"the strip between transition zone {i} and transition zone {i+1}" for i in range(1,n-1)] + [f"everything to her right of the {'last' if n>2 else 'first'} transition zone"]
        return pre, reg, f"세로 띠 {n}구역·{ko_shape} ({'/'.join(map(str,lv))}%)"
    if kind == "D":
        d, dk = rnd.choice(DIRS)
        lv = spaced(n-1, 25, 75, 15 if n==4 else 20) if n>2 else [pct(30,70)]
        pre = f"Her figure is divided into {n} diagonal bands by {n-1} parallel hazy transition zone{'s' if n>2 else ''} running {d} as seen by the camera, crossing the centre line of her figure {ordinal_list(lv, lambda p: down(p))}."
        reg = ["everything on the upper side of the first diagonal transition zone"] + [f"the diagonal band between transition zone {i} and transition zone {i+1}" for i in range(1,n-1)] + [f"everything on the lower side of the {'last' if n>2 else 'first'} diagonal transition zone"]
        return pre, reg, f"대각 띠 {n}구역·{dk}·{ko_shape} ({'/'.join(map(str,lv))}%)"
    if kind == "C":
        c = pct(40,60); rs = spaced(n-1, 20, 85, 15)
        pre = f"Her figure is divided into {n} concentric regions around a single centre point located {down(c)} on the centre line of her figure, separated by {n-1} hazy ring-shaped transition zone{'s' if n>2 else ''} at about {ordinal_list(rs, lambda r: str(r)+'%')} of the way out from that centre point to the farthest edge of her figure."
        reg = ["the innermost core around the centre point"] + [f"the ring between transition zone {i} and transition zone {i+1}" for i in range(1,n-1)] + ["the outermost region beyond the last ring"]
        return pre, reg, f"동심원 {n}구역·{ko_shape} (중심 {c}%, 반경 {'/'.join(map(str,rs))}%)"
    if kind == "R":
        c = pct(40,60)
        parts=[2]*n
        for _ in range(12-2*n): parts[rnd.randrange(n)] += 1
        h0 = rnd.randrange(1,13); pos=[h0]
        for p in parts[:-1]: pos.append((pos[-1]+p-1)%12+1)
        pre = f"Her figure is divided into {n} wedge-shaped regions radiating from a single centre point located {down(c)} on the centre line of her figure. {n} hazy ray-shaped transition zones leave that centre pointing toward {ordinal_list(pos, lambda h: f"{h} o'clock")} as seen by the camera, where 12 o'clock points straight up."
        reg = [f"the wedge between the {pos[i]} o'clock ray and the {pos[(i+1)%n]} o'clock ray, sweeping clockwise" for i in range(n)]
        return pre, reg, f"부채꼴 {n}구역·{ko_shape} (중심 {c}%, 광선 {'/'.join(map(str,pos))}시)"

STRUCT_N = {"H":[2,3,4],"V":[2,3,4],"D":[2,3,4],"C":[2,3,4],"R":[3,4,4]}
STRUCT_KO = {"H":"가로 띠","V":"세로 띠","D":"대각 띠","C":"동심원","R":"부채꼴"}
STRUCT_KIND = {"H":"band","V":"band","D":"diag","C":"conc","R":"rad"}

makeups = rnd.sample(T.MAKEUP_48, 33); bodies = (VOLBODY*6)[:33]; rnd.shuffle(bodies)
craft_deck = list(T.CRAFTS_39); rnd.shuffle(craft_deck)
def draw_crafts(n):
    global craft_deck
    if len(craft_deck) < n: craft_deck = list(T.CRAFTS_39); rnd.shuffle(craft_deck)
    got = craft_deck[:n]; craft_deck = craft_deck[n:]; return got

def assemble(makeup, bodykey, art):
    nat, fa = face_nohair(makeup)
    age = AGE_EN_FULL[rnd.choice(T.AGE_12)]; vibe = VIBE_EN_FULL[rnd.choice(T.VIBE_5)]
    hs = HAIR_EN_FULL[rnd.choice(T.HAIR_STYLE)]; hc = HAIR_COLOR_EN_FULL[rnd.choice(T.HAIR_COLOR)]
    nail = f"{NAIL_SHAPE_EN_FULL[rnd.choice(T.NAIL_SHAPES)]} nails, {NAIL_FIN_EN_FULL[rnd.choice(T.NAIL_FINISH)]} finish"
    pose = POSE_EN_FULL[rnd.choice(FRONT_POSES)]; shoe = SHOE_EN_FULL[rnd.choice(T.SHOES_24)]
    return (f"Image format: a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide.\n\nA full-body photograph with a plain seamless deep-charcoal backdrop, shot on a medium format camera with an 85mm lens at f/8, a single hard key light raking in from one side, sharp focus from head to toe, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n"
            f"Subject: ONE real adult {nat} woman in her {age}, her face exactly the same tone as her body, real skin texture with visible pores and fine grain, {fa}, {vibe}, {hc} hair styled in {hs}, real living eyes. Long {nail}.\n\n"
            f"Physique: {cap(BODY_FULL[bodykey])}\n\n"
            f"Skin: Real photographic skin — visible pores and fine grain, a smooth taut surface with natural creases and shadow only where the flesh folds. No smooth illustration finish, no plastic CG sheen.\n\n"
            f"{art}\n\n"
            f"Pose: {pose}, every region clearly visible to the camera.\n\nFootwear: extreme {shoe}, painted with the blended patterns following the same soft transitions as her skin.\n\n"
            f"Background & Lighting: the blended painted patterns reading crisp against her skin, the hard raking light carving every fold and curve.\n\nVertical 2:3 portrait-orientation full-body photograph, taller than it is wide. portrait 2:3 vertical.")

items=[]   # (label_group, ko_label, n, prompt, makeup, body, crafts)
k=0
for kind in ["H","V","D","C","R"]:
    for shape in ["smooth","undulating"]:
        for n in STRUCT_N[kind]:
            pre, reg, lab = make_structure(kind, n, shape)
            geo = pre+" "+" ".join(reg)
            assert sens_count(geo)==0, geo
            crafts = draw_crafts(n)
            texts=[]
            for c in crafts:
                cn,cd,cb,cf = CRAFT_DB_FULL[c]
                texts.append(f"{cn} ({cd}), wide {cb} bands following the contours of the body, dense {cf} filling the space between bands")
            sents = " ".join(f"Region {i+1} is {reg[i]}: it is painted in {texts[i]}." for i in range(n))
            art = (f"Body Art: Her bare skin is painted with {n} different traditional patterns, each claiming its own region of her figure. {pre} {sents} {hazy(shape, STRUCT_KIND[kind])} Pigment on living skin throughout, covering every inch of her body below the jaw with no bare skin anywhere, face unpainted.")
            p = assemble(makeups[k], bodies[k], art); validate(f"hz_{k}", p)
            items.append((f"{STRUCT_KO[kind]}", lab, n, p, makeups[k], bodies[k], "+".join(crafts), shape)); k+=1

# 대조군 3개: 등록분/기존 검증 방식(경계 모호 + 구역 문구) 그대로
ctrl_specs = [(2,"horizontal","대조군 · 허리 가로 2혼합(기존 검증 방식)"),(2,"lr","대조군 · 좌우 2혼합(기존 검증 방식)"),(3,"zones","대조군 · 3혼합 자유형(기존 등록 방식, 'diagonally' 문구)")]
for n,style,lab in ctrl_specs:
    crafts = draw_crafts(n)
    dims = ("upper body, from her collarbones down to her waistline,","lower body, from her waistline down to her ankles,") if style=="horizontal" else ("LEFT side","RIGHT side")
    art = craft_bodyart(crafts, style, dims)
    p = assemble(makeups[k], bodies[k], art); validate(f"ctrl_{k}", p)
    items.append(("대조군", lab, n, p, makeups[k], bodies[k], "+".join(crafts), "control")); k+=1

assert len(items)==33
order = list(range(33)); rnd.shuffle(order)       # 번호는 섞어서 부여(앞쪽만 해봐도 구조가 골고루 나오게)
idx = {i:order.index(i)+1 for i in range(33)}
ranked = sorted(range(33), key=lambda i: idx[i])

L=["# LumineX · 희미한 경계 테스트 — 바디페인팅(실사) 솔로 33개\n",
   "원칙: 모든 경계는 선이 보이지 않는 희미한 전환 구간. 경계는 부위 이름 없이 선·중심점·시계 방향 같은 기하학 문구로만 기술. 번호는 구조가 섞이도록 무작위로 부여했습니다(앞쪽 몇 개만 해보셔도 구조가 골고루 나옵니다). 결과는 번호로 알려주세요.\n",
   "## 색인\n","| 번호 | 구조·구역수·경계선 | 체형 | 메이크업 | 공예 구성 |","|---|---|---|---|---|"]
for i in ranked:
    g,lab,n,p,mk,bd,cr,sh = items[i]
    L.append(f"| {idx[i]:02d} | {lab} | {bd} | {mk} | {cr} |")
L.append("")
for i in ranked:
    g,lab,n,p,mk,bd,cr,sh = items[i]
    L.append(f"## {idx[i]:02d}. {lab} — {bd} / {mk} / 공예: {cr}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_HazyBoundary_Test_Craft_33.md","w",encoding="utf-8").write("\n".join(L))

json.dump([{"no":idx[i],"group":items[i][0],"label":items[i][1],"n":items[i][2],"shape":items[i][7],"makeup":items[i][4],"body":items[i][5],"crafts":items[i][6]} for i in ranked], open("/home/claude/hazy_test_meta.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
from collections import Counter
print("총", len(items), "개 | 구조×경계선별 개수:", dict(Counter((it[0], it[7]) for it in items)))
ws=[len(it[3].split()) for it in items]; print("단어 수:", min(ws), "~", max(ws))
print("체형 분포:", dict(Counter(it[5] for it in items))); print("공예 사용 종류:", len({c for it in items for c in it[6].split('+')}), "/ 40")
print("\n[샘플 색인 5줄]"); 
for i in ranked[:5]: print(f"  {idx[i]:02d}. {items[i][1]}")
