# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g3 = load("g3","gen3.py"); g9 = load("g9","gen9.py"); g13 = load("g13","gen13.py")

t = g9.P100
reps = [
 ("a big black-steel hoop, two smaller rings and a snake-bite ring on each side through the lower lip's edge, and five small hoops along the upper lip's edge",
  "a big black-steel hoop through the lower lip's edge with a snake-bite ring on each side, the upper lip and the front of the mouth kept clear"),
 ("five thick black-steel bars stacked", "six thick black-steel bars stacked"),
 ("four small studs up each temple", "five small studs up each temple"),
 ("a row of six small studs along each cheekbone", "a row of seven small studs along each cheekbone"),
 ("five small studs along each jaw", "six small studs along each jaw"),
]
for a, b in reps:
    assert a in t, a
    t = t.replace(a, b)
t = t.replace("black-steel", "bronze").replace("about one hundred real metal piercings", "about one hundred real bronze piercings with a few turquoise-enamel rings among them")
DENS = g13.DENS
CARE = g13.CARE.format(metal="bronze with a few turquoise-enamel rings")
nat, mk, face = g3.face_of("코갸루")
face += ", the lips parted in a bright grin so the upper front teeth and the tip of the tongue show"
p = f"""Professional fashion photograph, close-up beauty portrait. ONE woman, her face turned about 30 degrees toward the camera, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {face}. Real pores and fine skin grain, real living eyes with bright catchlights and genuine depth, individual hair strands catching the light — a photograph of a real face, not an illustration, not a render, not cel-shaded.

Piercings: {t}{DENS} {CARE}

Mouth: two small clear crystals set in bronze are bonded to the surface of two upper front teeth, tiny and bright, catching the light. A bronze barbell with two small turquoise round ends passes through the middle of the tongue, the tongue tip raised playfully behind the upper teeth so both round ends of the barbell show and catch the light. The teeth are natural, white and clean, and the tongue is a healthy pink, calm and healed, with no blood and no swelling.

Lighting: a soft frontal beauty light on the face with a thin cool rim light along the hair, pure pitch black void background, shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait."""
print(len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
print(p)
