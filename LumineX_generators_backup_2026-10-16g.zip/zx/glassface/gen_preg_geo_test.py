# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
_top = open('gen_craftblend_geo.py', encoding='utf-8').read().split("\nold = {")[0]
exec(_top)      # make_structure, hazy2, draw_cells, sens_count, validate, face_nohair, pct(1%), STRUCT_KO/KIND, cap, T ...
_pre = open('generate_pregnant_solo.py', encoding='utf-8').read().split("def person_block")[0]
exec(_pre)      # 등록된 임산부 생성기의 상수: D, ALL_PREG, BELLY_BOOST, POSES, 피어싱·쥬얼리 사전, ASPECT ...
rnd.seed(20261011)

STABLE_BODIES = ['임산부글래머','임산부콜로설','임산부풀텀트윈즈','임산부USSBBW','임산부아워글래스SSBBW','임산부슈퍼글래머','임산부블랙글래머','임산부레전드바스트','임산부커브드바스트','임산부브라질부티글램','임산부폴리네시안여신']
STABLE_BODIES = [b for b in STABLE_BODIES if b in ALL_PREG]
MAKEUPS = rnd.sample(T.MAKEUP_48, 18)
def hz_p(shape, kind): return hazy2(shape, kind)

def regions_text(n, kind, shape):
    pre, reg, lab = make_structure(kind, n, shape)
    assert sens_count(pre+" "+" ".join(reg)) == 0
    return pre, reg, lab

def person_preg(label, makeup, bodykey, n, kind, shape, solo):
    nat, fa = face_nohair(makeup)
    row = rnd.randrange(len(D["makeup"]))                              # 등록분과 같은 분포에서 피어싱·쥬얼리·나이·분위기·신발을 뽑음
    age = AGE_EN_FULL[D["age"][row]]; vibe = VIBE_EN_FULL[D["vibe"][row]]; shoe = SHOE_EN_FULL[D["shoe"][row]]
    pierce = pierce_phrase(D["pierce_p"][row],D["pierce_c"][row],D["pierce_g"][row],D["pierce_f"][row],D["pierce_s"][row],D["pierce_m"][row])
    jewelry = f"{JQ_SHORT[D['jq'][row]]} of {JMETAL_EN[D['jmetal'][row]]} {JTYPE_EN[D['jtype'][row]]}"
    hair = f"{HAIR_COLOR_EN_FULL[rnd.choice(T.HAIR_COLOR)]} hair styled in {HAIR_EN_FULL[rnd.choice(T.HAIR_STYLE)]}"
    bodytext = ALL_PREG[bodykey].replace("a high, smoothly rounded pregnant belly", f"a high, smoothly rounded pregnant belly, {BELLY_BOOST},", 1)
    pose = rnd.choice(POSES)
    crafts = rnd.sample(T.CRAFTS_39, n)
    pre, reg, lab = regions_text(n, kind, shape)
    texts=[]
    for c in crafts:
        cn,cd,cb,cf = CRAFT_DB_FULL[c]
        texts.append(f"{cn} ({cd}), wide {cb} bands following the contours of the body, with {cf} filling the space between bands")
    sents = " ".join(f"Region {i+1} is {reg[i]}: it is painted in {texts[i]}." for i in range(n))
    paint = (f"{'Full body painted' if solo else 'Painted'} in {n} different traditional patterns, each claiming its own region of her figure, covering every inch of skin from neck to ankle without exception, the patterns reading as a continuous second skin with no gaps. "
             f"{pre} {sents} {hz_p(shape, STRUCT_KIND[kind])} The bands of every pattern curve fully around her belly like contour lines circling a globe, the rounded surface of her belly staying fully covered as part of whichever region it falls in, with the same density continuing in full strength over her bust, nowhere on her body left bare. ")
    head = (f"{nat} woman, an adult, in her {age}, {vibe} expression" if solo else f"{label}: {nat}, in her {age}, {vibe} expression")
    block = (f"{head}, warm radiant skin tone, extraordinarily large pregnant physique far beyond any real person — {bodytext} "
             f"Her face is a real living adult face, {fa}, {hair}, real pores, real living eyes, {pierce}, wearing {jewelry}. "
             f"{paint}"
             f"Pose: {pose}, " + (f"her whole silhouette filling the frame from head to her {shoe}, the platform soles rising far higher than her ankle bone." if solo else f"her {shoe}, the platform soles rising far higher than her ankle bone."))
    return block, f"{STRUCT_KO[kind]}·{'물결' if shape=='undulating' else '매끈'}", f"{bodykey}/{makeup}", "+".join(crafts)

def build_new(gsize, n, mk):
    bodies = rnd.sample(STABLE_BODIES, gsize); cells = draw_cells(gsize); blocks=[]; descs=[]
    for i in range(gsize):
        b, st, who, cr = person_preg(f"#{i+1}", mk[i], bodies[i], n, cells[i][0], cells[i][1], gsize==1)
        blocks.append(b); descs.append(f"[{st} / {who} / {cr}]")
    if gsize == 1:
        p = (f"Professional fashion photograph, full body shot. ONE woman standing or kneeling as described.\n\nSubject: {blocks[0]}\n\nBackground: a plain seamless deep-charcoal backdrop, nothing else in frame. Lighting: a single hard key light raking in from one side, sharp focus head to toe, realistic photographic grain, a real photograph not an illustration not CGI not a render. Pattern density maximum, zero bare skin from neck to ankle. 2:3 vertical 8K portrait, taller than it is wide.")
    else:
        p = (f"Professional fashion photograph, full body shot. {NUM_WORD[gsize]} women standing side by side, each an extraordinarily large pregnant woman, far beyond any real person.\n\n" + "\n\n".join(blocks) +
             f"\n\nBackground: a plain seamless deep-charcoal backdrop, nothing else in frame. Composition: each woman's own pose as described, inner arms not crossing her neighbours, generous spacing so every figure reads clearly. Lighting: a single hard key light raking across all of them from one side, sharp focus head to toe on each, realistic photographic grain, a real photograph not an illustration not CGI not a render. Pattern density maximum, zero bare skin from neck to ankle on any of them. Shot on a Hasselblad X2D, {ASPECT[gsize]} aspect ratio, 8K.")
    return p, " ; ".join(descs)

DUP = re.compile(r"\b(\w+) \1\b")
items=[]; k=0
for gsize, n in [(1,3),(1,4),(1,3),(2,3),(2,4),(2,4),(3,3),(3,3),(3,4)]:
    p, desc = build_new(gsize, n, MAKEUPS[k:k+gsize]); k += gsize
    validate(f"pg_{gsize}_{n}", p)
    assert not re.search(r'(?<!corset-)\blace\b(?!-up)', p.lower())
    d = [m.group(0) for m in DUP.finditer(p) if m.group(1).lower() not in ("had","that")]
    assert not d, d
    items.append(("새 방식", gsize, n, desc, p))

# 대조군: 레포 현재 상태(헤어·중복 수정 반영)의 등록된 임산부 프리셋
def reg(tn, gsize):
    while True:
        key=f"la_preg_{tn}_{rnd.randrange(1,51):02d}"; f=f"/tmp/repo_state/presets/{key}.json"
        try: x=json.load(open(f,encoding="utf-8")); break
        except FileNotFoundError: continue
    comp = " ; ".join(x["meta"].get("composition", []))
    return ("등록분", gsize, 1, f"{key} — {comp}", x["prompt"])
items += [reg("solo",1), reg("duo",2), reg("trio",3)]
assert len(items)==12

order=list(range(12)); rnd.shuffle(order); no={i:order.index(i)+1 for i in range(12)}; ranked=sorted(range(12), key=lambda i:no[i])
GN={1:"솔로",2:"듀오",3:"트리오"}
L=["# LumineX · 임산부 바디페인팅 혼합 새 방식 확인 12개\n",
   "새 방식 9개(솔로 3·듀오 3·트리오 3, 패턴 3~4종)와 이미 등록된 임산부 프리셋 3개(대조군, 공예 1종)를 섞어 번호를 붙였습니다. **성공/실패만** 알려주세요(최대 3회, 1회/2회/3회/실패). 예: `03: 2회 / 07: 실패 / 나머지 1회`\n",
   "## 색인\n","| 번호 | 구분 | 인원 | 패턴 수 | 구성 (구조·경계선 / 체형 / 메이크업 / 공예) |","|---|---|---|---|---|"]
for i in ranked:
    g,gs,n,desc,p = items[i]; L.append(f"| {no[i]:02d} | {g} | {GN[gs]} | {n if g=='새 방식' else 1} | {desc} |")
L.append("")
for i in ranked:
    g,gs,n,desc,p = items[i]; L.append(f"## {no[i]:02d}. {g} · {GN[gs]}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_Pregnant_Geo_Test_12.md","w",encoding="utf-8").write("\n".join(L))
json.dump([{"no":no[i],"kind":items[i][0],"gsize":items[i][1],"n":items[i][2],"desc":items[i][3]} for i in ranked], open("/home/claude/preg_test_meta.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
print("12개 저장")
for gs in [1,2,3]:
    nw=[len(it[4].split()) for it in items if it[0]=="새 방식" and it[1]==gs]; rg=[len(it[4].split()) for it in items if it[0]=="등록분" and it[1]==gs]
    print(f"  {GN[gs]}: 새 방식 {nw} / 등록분 {rg}")
print("대조군 번호:", [(no[i], items[i][3].split(' — ')[0]) for i in ranked if items[i][0]=='등록분'])
for i in ranked:
    if items[i][0]=="새 방식": print(f"  {no[i]:02d} {GN[items[i][1]]} {items[i][2]}패턴 | {items[i][3][:110]}")
