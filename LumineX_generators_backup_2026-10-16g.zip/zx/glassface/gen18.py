# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g2 = load("g2","gen2.py"); g3 = load("g3","gen3.py"); g6 = load("g6","gen6.py"); g9 = load("g9","gen9.py"); g10 = load("g10","gen10.py"); g13 = load("g13","gen13.py")
MAT, BODY = g2.MAT, g2.BODY
DENS = g13.DENS
CARE = g13.CARE

# ---------- 가슴 프레임용 피어싱 (귀 장식 대형화) ----------
BIGEAR = "the biggest hoops hanging clear of the neck down to the shoulders"
T8  = "On each ear a huge thick gold hoop hanging clear of the neck down to the shoulder, a wide gold ear cuff, a large gold stud and a small helix ring."
T25 = ("A thin gold septum ring hangs below the nose with a smaller ring above it, and a gold ring passes through each nostril; two thin gold bars pass through the outer end of each eyebrow; a gold Medusa stud sits above the lips; "
       "a gold hoop passes through the lower lip's edge with a snake-bite ring on each side and one small ring beside it; a gold labret stud and one ring pass through the chin; one small gold stud sits on each jaw; "
       "on each ear four oversized pieces — a huge gold hoop hanging clear of the neck down to the shoulder, a wide ear cuff, a large pearl drop and a helix ring.")
def big_ears(txt, repl):
    return txt.replace("on each ear a full dense row from lobe to top of big black-steel hoops, thick bars and stretched plugs",
                       "on each ear a full dense row from lobe to top of oversized " + repl + " hoops, thick bars and stretched plugs, " + BIGEAR)
T50 = big_ears(g6.V["pierce"], "black-steel").replace("black-steel", "gold")
T100 = g9.P100.replace("ten big hoops, thick bars, stretched plugs, helix rings and studs from lobe to top", "ten oversized hoops, thick bars, stretched plugs, helix rings and studs from lobe to top, " + BIGEAR).replace("black-steel", "gold").replace(
    "about one hundred real metal piercings", "about one hundred real gold piercings with a few gold coin drops among them")
T150 = g10.P150.replace("twelve big hoops, thick bars, stretched plugs, helix rings and studs from lobe to top", "twelve oversized hoops, thick bars, stretched plugs, helix rings and studs from lobe to top, " + BIGEAR).replace("black-steel", "gold").replace(
    "about one hundred and fifty real metal piercings", "about one hundred and fifty real gold piercings with a few red-enamel beads among them")
K1 = big_ears(g6.V["pierce"], "black-steel").replace("black-steel", "silver") + g13.K1_CH
K2 = (g9.P100.replace("ten big hoops, thick bars, stretched plugs, helix rings and studs from lobe to top", "ten oversized hoops, thick bars, stretched plugs, helix rings and studs from lobe to top, " + BIGEAR).replace("black-steel", "gold").replace(
    "about one hundred real metal piercings", "about one hundred real gold piercings with a few gold beads among them") + g13.K2_CH)

SPEC = [
 # 단계, 스타일, 체형, L, R, 피어싱, 금속, 라벨, 고밀도
 ("8",   "프렌치 레드립(프랑스)", "bust", "cobalt","amber", T8, "yellow gold", "금", False),
 ("25",  "홍콩풍", "top", "jade","ruby", T25, "gold with a few pearl drops", "금 + 진주", False),
 ("50",  "락혼 글램(태국)", "hgu", "amethyst","carnelian", T50, "gold", "금", False),
 ("100", "발칸 글램(루마니아·불가리아)", "tent", "smoky","citrine", T100, "gold with a few gold coin drops", "금 + 금화 드롭", True),
 ("150", "텔레노벨라 글램(멕시코·콜롬비아)", "colo", "emerald","rosepink", T150, "gold with a few red-enamel beads", "금 + 붉은 에나멜", True),
 ("K1",  "파케앙트 글램(필리핀)", "hgs", "egglass","rosequartz", K1, "silver with pastel enamel and acrylic charms", "은 + 파스텔 참", False),
 ("K2",  "서아프리카 파티·웨딩 글램", "bust", "murano","sapphire", K2, "gold with gold beads and many small charms", "금 + 금 구슬 + 참 다수", True),
]

OUT = []
for tier, sty, bk, a, b, pierce, metal, label, dense in SPEC:
    nat, mk, face = g3.face_of(sty)
    an, adesc, ainner = MAT[a]; bn, bdesc, binner = MAT[b]
    bname, btext = BODY[bk]
    p = f"""Professional fashion photograph, bust shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head to just below her chest, the frame cutting off beneath the chest. Her face sits large and sharp in the upper half of the frame, and her ear pieces are oversized so they read clearly at this distance. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {face}. Her whole face, ears and neck are real living flesh with real pores and fine skin grain — a photograph of a real face, not an illustration.

Piercings: {pierce}{DENS if dense else ''} {CARE.format(metal=metal)}

Physique: {btext}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest): solid {adesc}, with {ainner}. Right half: solid {bdesc}, with {binner}. Each is carved as one solid sculpted mass like a statue, never hollow, the chest two great rounded masses with the groove between them cut into the material itself. The arms flow into the chest with no seam, and every wrist, palm, finger and knuckle is the same material as its arm, with no skin texture on any hand.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the chest and out of the bottom of the frame where the two materials meet, never horizontal. Shards interlock along the lines only, every edge solid all the way through.

Pose: body angled 45 degrees, her left hand (solid material) held low at the frame edge beside her chest, her right hand (solid material) held at chest height clear of her body, well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal light on her face and ears only, so the makeup and the glints on every piece of metal read clearly; a strong backlight through each half so both sides of the body glow from within; a thin cool rim light along the centre line. 2:3 vertical 8K portrait."""
    OUT.append((tier, sty, bname, an, bn, label, p))

if __name__ == "__main__":
    for t, s, bn_, an, bn, l, p in OUT:
        print(t, s, bn_, an, "×", bn, l, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
