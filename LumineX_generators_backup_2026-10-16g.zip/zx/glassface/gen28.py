# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g18 = load("g18","gen18.py"); g3 = g18.g3
MAT = g18.MAT; CARE = g18.CARE; DENS = g18.DENS
HIP_BODY = g3.HIP_BODY
T8, T25, T50 = g18.T8, g18.T25, g18.T50

def metalize(txt, m):
    return re.sub(r"\bgold\b", m, txt) if m != "gold" else txt

BODY_RULE = "All body jewelry is real opaque metal, passing through drilled openings in the material itself or set on anchored posts, never turning into the material, each piece kept a hand's breadth away from the boundary lines, with a crisp small shadow under it and no wound anywhere."

def body_text(tier, M):
    b8  = f"In the carved hollow of her navel hangs a real {M} barbell with a small pearl drop."
    b25 = f" Two {M} surface bars lie flat across the front of the hip bones, one on each side, only their two end studs showing."
    b50 = f" A row of three small domed {M} jewels on anchored posts sits along each shoulder cap, and several of her fingers carry real {M} rings."
    b100 = f" A vertical ladder of five small {M} rings runs up each side of the waist like corset lacing, two thick {M} surface bars lie across each upper arm, and a fine {M} chain loops from the navel barbell to the hip bars."
    b150 = f" Two more {M} surface bars lie across each forearm, a real {M} ring circles each wrist, a row of small domed jewels sits on each upper thigh at the bottom of the frame, two more fine chains loop across the belly, and a few surface bars sit a hand's breadth below the collarbones."
    charm1 = " About ten small light charms — a tiny star, a heart, a ribbon bow, a small teddy-bear charm, a short bead string and a rhinestone bottle in pastel enamel and acrylic — hang on short fine chains from the navel barbell, the hip-bar studs and the ear hoops, all generic and light, none near the eyes."
    charm2 = " About twenty small light charms — tiny stars, hearts, ribbon bows, teddy-bear charms, bead strings, pearl strings, small bells and rhinestone bottles in enamel, acrylic and pearl — hang on short fine chains from the navel barbell, the hip-bar studs, the waist rings, the wrist rings and the ear hoops, all generic and light, none near the eyes."
    t = {"8": b8, "25": b8+b25, "50": b8+b25+b50, "100": b8+b25+b50+b100,
         "150": b8+b25+b50+b100+b150, "K1": b8+b25+b50+b100+charm1, "K2": b8+b25+b50+b100+b150+charm2}
    return t[tier]

# (단계, 스타일, 체형, L, R, 얼굴 피어싱, 금속 코드, 금속 문구, 라벨, 얼굴 수준)
SPEC = [
 ("8",   "프렌치 레드립(프랑스)", "hgs",  "sapphire","amber",     T8,  "gold",        "yellow gold with a pearl", "금 + 진주", "귀 대형"),
 ("25",  "홍콩풍",               "hipq", "egglass","carnelian",  T25, "gold",        "gold with a few pearl drops", "금 + 진주", "25"),
 ("50",  "락혼 글램(태국)",       "uss",  "amethyst","citrine",   T25, "rose-gold",   "rose gold", "로즈골드", "25"),
 ("100", "발칸 글램(루마니아·불가리아)","tent","cobalt","ruby",   T25, "silver",      "silver", "은", "25"),
 ("150", "텔레노벨라 글램(멕시코·콜롬비아)","hgu","emerald","rosepink", T50, "gold",   "gold with a few red-enamel beads", "금 + 붉은 에나멜", "50"),
 ("K1",  "파케앙트 글램(필리핀)", "hipq", "smoky","citrine",     T8,  "silver",      "silver with pastel enamel and acrylic charms", "은 + 파스텔 참", "귀 대형"),
 ("K2",  "서아프리카 파티·웨딩 글램","uss","murano","aquamarine", T25, "gold",        "gold with gold beads and many small charms", "금 + 금 구슬 + 참 다수", "25"),
]

OUT = []
for tier, sty, bk, a, b, face_p, mcode, mtxt, label, flevel in SPEC:
    nat, mk, fc = g3.face_of(sty)
    an, adesc, ainner = MAT[a]; bn, bdesc, binner = MAT[b]
    bname, btext = HIP_BODY[bk]
    fp = metalize(face_p, mcode) if mcode in ("rose-gold","silver") else face_p
    M = mcode if mcode != "gold" else "gold"
    bt = body_text(tier, M)
    p = f"""Professional fashion photograph, three-quarter body shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head down through the hips, the frame cutting off across the upper thighs so no knees, lower legs or feet are visible. Her face sits in the upper part of the frame, and her ear pieces are oversized so they read clearly at this distance. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}. Her whole face, ears and neck are real living flesh with real pores and fine skin grain — a photograph of a real face, not an illustration.

Face piercings: {fp} {CARE.format(metal=mtxt)}

Physique: {btext}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest, belly, hip and upper thigh): solid {adesc}, with {ainner}. Right half: solid {bdesc}, with {binner}. Each is carved as one solid sculpted mass like a statue, never hollow, the chest, belly folds and hip creases cut into the material itself as grooves. The arms flow into the torso and the torso into the thighs with no seam, and every wrist, palm, finger and knuckle is the same material as its arm.

Body piercings: {bt} {BODY_RULE}

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the chest, belly and between the hips and thighs and out of the bottom of the frame where the two materials meet, never horizontal. Shards interlock along the lines only, every edge solid all the way through.

Pose: body angled 45 degrees, her left hand (solid material) resting on her flared hip, her right hand (solid material) held clear of her body at hip height, well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal light on her face and ears only, so the makeup and the glints on every piece of metal read clearly; a strong backlight through each half so both sides of the body glow from within; a thin cool rim light along the centre line. 2:3 vertical 8K portrait."""
    OUT.append((tier, sty, bname, an, bn, label, flevel, p))

if __name__ == "__main__":
    for t, s, bn_, an, bn, l, fl, p in OUT:
        print(t, s, bn_, an, "×", bn, l, fl, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
