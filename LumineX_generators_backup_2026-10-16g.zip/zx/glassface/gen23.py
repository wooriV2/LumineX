# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g3 = load("g3","gen3.py"); g2 = load("g2","gen2.py"); g4 = load("g4","gen4.py")
MAT = g2.MAT

# ---------------- 힙 버전 · USSBBW · 락혼 글램 · 라이롯남 × 루비색 유리 ----------------
nat, mk, fc = g3.face_of("락혼 글램(태국)")
rn, rdesc, rinner = MAT["ruby"]
hip_body = g3.HIP_BODY["uss"][1]
HIP = f"""Professional fashion photograph, double portrait, three-quarter body shot. TWO figures standing close side by side, both angled 45 degrees toward the camera, framed from the very top of their heads down through the hips, the frame cutting off across the upper thighs. Where their bodies press together the flesh and the glass bulge against each other, each figure's own outline still clear. Both faces are large and sharp in the upper part of the frame.

The left figure is a real living woman: a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}. Her body: {hip_body} Her face is left clear and is entirely real living skin with real pores and fine grain, real living eyes and real lips. On each ear she wears a big real gold hoop with a chased-gold drop. The rest of her is a real body covered in full-body Thai lai rot nam body painting: brilliant gold-leaf kranok flame scrolls over glossy black lacquer, the pigment lying directly on her real skin, the real volume of her body clearly visible beneath it. The design runs continuously over every surface with no bands and no borders anywhere, dense gold scrollwork fills every gap so no plain lacquer is left, and it follows every belly roll and every crease — the shoulders, the arms, the backs of the hands, the chest, the belly, the sides, the hips and the tops of the thighs — as densely as everywhere else. The painting softens away at the neck, and her face stays clear.

The right figure is her exact twin as a sculpture: the same face, the same expression, the same body and the same long waved hair, the same pose mirrored, carved as one solid statue of {rdesc} with nothing beneath and no skin anywhere, with {rinner}. The statue is sculpted with the fine detail of a master portrait sculptor: a colossal chest and an enormous belly of massive rounded rolls carved into the glass itself, polished ruby-clear gem irises for eyes, a strong black winged liner as a fine dark line at each outer corner, a deep red glow in the carved lips, and the same gold hoops with chased-gold drops as real metal on drilled openings in the glass. The gold scroll pattern of the painting appears on the statue only as fine engraved lines cut into the surface, catching the light, so the statue is carved and never painted.

The statue is unmistakably a solid three-dimensional carved object, and the real woman is unmistakably alive — warm skin, moist eyes, individual hair strands. Their outer hands rest on their flared hips and their inner arms hang relaxed at their sides. Both figures are equally sharp.

Lighting: pure pitch black background. A soft warm frontal light on the real woman's face and the gold of her body painting; a strong deep-red backlight through the ruby glass so the statue glows crimson from within; a thin cool rim light along the statue's edge. 2:3 vertical 8K portrait."""

# ---------------- 전신 버전 · 콜로설 · 텔레노벨라 · 이마리 × 에메랄드 ----------------
nat2, mk2, fc2 = g3.face_of("텔레노벨라 글램(멕시코·콜롬비아)")
en, edesc, einner = MAT["emerald"]
full_body = g4.BODY["colo"][1]
FULL = f"""Professional fashion photograph, double portrait, full body shot, head to toe. TWO figures standing side by side with a small gap between them, both angled 45 degrees toward the camera, the camera set back so both whole bodies fit in the frame from the top of their heads to their feet. Both faces stay sharp.

The left figure is a real living woman: a strikingly beautiful adult {nat2} woman in {mk2} makeup — {fc2}. Her body: {full_body} Her face is left clear and is entirely real living skin with real pores and fine grain, real living eyes and real lips. On each ear she wears a large real gold hoop. The rest of her is a real body covered in full-body Imari porcelain body painting: cobalt blue underglaze scrolls, lotus and cranes joined by iron-red overglaze enamel and raised gilt accents over a brilliant white ground, the pigment lying directly on her real skin, the real shape of her body clearly visible beneath it. The design runs continuously over every surface with no bands and no borders anywhere, dense scrollwork fills every gap so no plain white is left, and it reaches every part of her below the jaw — the shoulders, the arms, the backs of the hands, the chest, the belly, the sides, the hips, the thighs, the knees, the calves and the tops of the feet — as densely as everywhere else. The painting softens away at the neck, and her face stays clear. She wears real extreme platform stiletto sandals of glossy black leather.

The right figure is her exact twin as a sculpture: the same face, the same expression, the same body and height, the same long voluminous waves, the same pose mirrored, carved as one solid statue of {edesc} with nothing beneath and no skin anywhere, with {einner}. The statue is sculpted with the fine detail of a master portrait sculptor, with polished deep-green gem irises for eyes, a sharp black winged liner as a fine dark line at each outer corner, warm terracotta tones and a berry glow in the carved lips as colour inside the crystal, and the same gold hoops as real metal on drilled openings in the crystal. Her platform stiletto sandals are carved from the same emerald as her legs, the material running unbroken through the ankle, the instep and every toe. The pattern of the painting appears on the statue only as fine engraved lines cut into the surface, catching the light, so the statue is carved and never painted.

The statue is unmistakably a solid three-dimensional carved object, and the real woman is unmistakably alive — warm skin, moist eyes, individual hair strands. Both stand with feet planted apart, their outer hands resting on their flared hips and their inner arms hanging relaxed at their sides, their hands well away from their faces. Both figures are equally sharp.

Lighting: pure pitch black background. A soft warm frontal light on the real woman; a strong green backlight through the emerald so the statue glows deep green from within; a thin cool rim light along the statue's edge. 2:3 vertical 8K portrait."""

if __name__ == "__main__":
    for n, p in (("HIP", HIP), ("FULL", FULL)):
        print(n, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
