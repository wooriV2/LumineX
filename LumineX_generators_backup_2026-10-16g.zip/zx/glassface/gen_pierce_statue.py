# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_pierce_chest.py', encoding='utf-8').read().split("\nspecs = [")[0])     # g18(MAT·T50·T100)·DENS·recolor·conc_chest·pick_metal·face_nohair·EXPOSED·HC·HS ...
rnd.seed(20261113)
MAT = g18.MAT
REAL_FACE = "Her whole face, ears and neck are real living flesh with real pores and fine skin grain, real living eyes with bright catchlights and genuine depth, individual hair strands catching the light — a photograph of a real face, not an illustration, not a render, not cel-shaded."
DEPTH = ("Piercing depth: every bar and surface bar is embedded in the skin — its middle runs beneath the skin so only its two end studs show on the surface, the skin between them faintly raised over the hidden bar, with a small warm shadow at each end and nothing lying on top of the skin like a sticker. "
         "Every ring passes through a small healed opening in the skin, the skin visible through the loop, and every stud sits through the skin with its back hidden. Where a bar, ring or stud goes through the ear, the lip, the nostril or the brow, it passes through the real tissue with the skin wrapping snugly around it.")
CARE2 = "All jewelry is real {metal}, sitting in real, calm, healthy skin — no redness, no swelling, no irritation — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes."
FR = {"hip": ("hip-cut statue portrait", "a short way down her thighs, just below the hip line", "thighs"),
      "demi": ("demi statue portrait", "a little further below the middle of her thighs", "thighs"),
      "tq": ("three-quarter statue portrait", "right at the knee, where the leg would bend", "knees")}
FRKO = {"hip": "힙컷", "demi": "데미스탯", "tq": "쓰리쿼터"}
PHYS = ["A giant hourglass frame flaring at both ends — broad shoulders, a colossal chest projecting past them, a big round belly, hips as broad as the shoulders, both thighs clearly separate and individually shaped.",
        "A colossal chest, a waist that pulls in sharply beneath it, wide flaring hips, both thighs clearly separate and individually shaped.",
        "A still-visible cinched waist beneath a full soft chest, wide curving hips, both thighs clearly separate and individually shaped.",
        "A colossal, statuesque chest, a broad heavy torso and wide statuesque hips, both thighs clearly separate and individually shaped, all on a grand imperial scale."]
BACKS = [("a warm golden amber", "a bright citrus yellow"), ("a soft teal", "a pale sea-green"), ("a deep royal blue", "a cool silver"), ("a warm rose pink", "a soft cream"), ("a deep crimson", "a warm gold"), ("a pale lilac", "a soft mint")]
STONES = [("lapis lazuli", "deep lapis lazuli, a rich royal-blue stone scattered with small glittering flecks of golden pyrite throughout, polished to a hard, cool sheen, completely opaque"),
          ("white marble", "polished white Carrara marble with fine grey veining, a hard cool luminous sheen, completely opaque"),
          ("black granite", "polished black granite with fine silver flecks and a deep mirror-like sheen, completely opaque"),
          ("jade", "deep green nephrite jade, polished to a soft waxy lustre with faint paler clouding, completely opaque")]
WOODS = [("padauk", "padauk wood, a vivid reddish-orange hardwood with fine straight grain, oiled to a warm satin glow, completely opaque"),
         ("walnut", "dark walnut wood with rich swirling grain, oiled to a deep satin glow, completely opaque"),
         ("ebony", "deep black ebony wood with a fine tight grain, polished to a dark glossy sheen, completely opaque"),
         ("mahogany", "reddish mahogany wood with long flowing grain, polished to a warm lustrous sheen, completely opaque")]
CONTENTS = {"rosegarden": ("장미 정원", "a rose garden at dawn: red and white roses among dark green leaves, a few drifting petals, standing in the clear water that fills her body, denser near the chest and thinning toward the thighs."),
            "lilyfield": ("백합 들판", "pale mist drifting low over a field of white lilies: the lilies standing in clear water that fills her body, denser near the chest and thinning toward the thighs, with plenty of perfectly clear space between them."),
            "fireflynight": ("반딧불이 밤", "a warm summer night: hundreds of small glowing fireflies and a scatter of tiny floating paper lanterns drifting in the clear water that fills her body, from her chest down through her thighs.")}
OBJECTS = {"butterflies": ("나비", "a dozen small, perfectly carved crystal butterflies with delicate translucent wings, each one a paler, brighter facet than the crystal around it"),
           "shards": ("수정 조각", "dozens of small, jagged clear quartz shards like frozen lightning bolts, each one a brighter, sharper facet than the glass around it")}
HIGHCLEAR = ["resin", "ice", "glacial", "citrine", "aquamarine", "ruby", "cobalt", "egglass", "rosepink", "amethyst", "sapphire", "smoky"]
LIST = "From the collarbones down, her whole body — shoulders, arms, hands, chest, belly, hips and both distinct thighs"
def body_text(kind, key):
    if kind == "stone" or kind == "wood":
        name, desc = (STONES if kind == "stone" else WOODS)[key]
        return (f"{LIST} — is not painted, covered or clothed but physically made of one solid opaque {'stone' if kind=='stone' else 'wood'}, solid {desc}, carved as one solid sculpted mass like a statue, never hollow, with no seam and no skin anywhere, every wrist, palm, finger and knuckle the same material.", name, False)
    if kind == "T1":
        d, i = MAT[key][1], MAT[key][2]
        return (f"{LIST} — is not painted, covered or clothed but physically made of one solid transparent material, solid {d}, with {i}, carved as one solid sculpted mass like a statue, never hollow, with no seam and no skin anywhere, every wrist, palm, finger and knuckle the same material.", MAT[key][0], True)
    if kind == "T2":
        GLASS = "The glass is unmistakably glass: thick, crystal-clear and polished, with bright specular reflections sliding along every curved surface, sharp white highlights and dark refraction edges where the walls are thickest, tiny bubbles trapped in the glass itself. Her shoulders, chest, belly, hips and both thighs keep their exact sculpted shapes as clear glass outlines, and a clean glass rim runs along the boundary where the vessel meets the neck."
        return (f"{LIST} — is a sculpted vessel of thick, crystal-clear glass in the exact shape of her body, filled completely to the brim so nothing is hollow and there is no air gap. {GLASS} The vessel holds ONE single world, unbroken and continuous through her whole chest, belly, hips and both thighs, with no split, no second world and no change of contents anywhere: {CONTENTS[key][1]}", f"수조·{CONTENTS[key][0]}", True)
    mk, ok = key
    d, i = MAT[mk][1], MAT[mk][2]
    return (f"{LIST} — is ONE solid, continuous block of {d}, with {i}, carved as one uniform sculpted mass, never hollow, never split down the centre. Yet suspended deep within this solid material, visible through it exactly like objects frozen inside a single flawless crystal, are {OBJECTS[ok][1]}, spread naturally from her chest down through her belly, hips and both thighs, each one fully embedded in the solid material with no cavity, no hollow chamber and no liquid around it — the material itself grew solid around them. The material reads as one unbroken solid mass throughout; the embedded shapes are simply what is visible deep inside it, not a separate vessel.", f"내용물·{MAT[mk][0]}+{OBJECTS[ok][0]}", True)

def build(frame, P, method, kind, key):
    pname, pos, part = FR[frame]
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC)+1)
    M = pick_metal(ci); G = rnd.choice(GEMS); F = rnd.choice(FORMS); phys = rnd.choice(PHYS); (ba, bb) = rnd.choice(BACKS)
    hair = f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}"
    pierce = conc_chest(P, M, F) if method == "집중형" else recolor({"P50": g18.T50, "P100": g18.T100}[P], M)
    dense = P == "P100"; body, mname, transparent = body_text(kind, key)
    vessel = (kind == "T2")
    tip = (f"{pos[0].upper()}{pos[1:]}, each thigh individually curves inward and " + ("seals shut into its own smooth, rounded, closed tip" if vessel else "rounds off into its own smooth, deeply polished tip") +
           " — the two thighs stay clearly separate all the way down, never merging" + (" or fusing" if vessel else ", fusing or tapering") + " into a single base — no calves, no feet, nothing continues below either tip — the " + ("vessel" if vessel else "material") + " simply reaching its natural end on each leg, both " + ("sealed " if vessel else "") + "rounded tips resting side by side on the surface beneath her.")
    if transparent:
        mid = ("Transmission: everything below the collarbones is a transparent material that light passes through, while her real face, ears and neck are opaque living flesh that no light passes through. The background and its light sources are visible straight through her body, bent and tinted by the material, with bright refraction edges and soft coloured shadows. Her face stays completely opaque.")
        light = (f"Lighting: the glowing backdrop floods her body from behind, so {ba} passes through one side and {bb} passes through the other. A soft frontal light falls on her face and ears only; a thin cool rim light traces her whole figure. Only her face, ears and neck read as real skin.")
    else:
        mid = ("Material: everything below the collarbones is a completely opaque solid that no light passes through, while her real face, ears and neck are living flesh. The body blocks the backdrop's glow entirely, its surface catching the light with a hard, honest sheen and soft contact shadows, so it is unmistakable that the body itself is carved from the material.")
        light = (f"Lighting: the glowing backdrop frames her whole silhouette from behind, {ba} on one side and {bb} on the other, while her opaque body blocks it completely. A soft frontal light falls on her face and ears, and a thin cool rim light traces her whole figure so the carved surface of the material reads clearly. Only her face, ears and neck read as real skin.")
    metal_phrase = "mixed metal (yellow gold, silver, copper and rose gold, alternating piece by piece)" if M == "MX" else ("rose gold" if M == "MR" else MN[M].replace("-", " "))
    p = (f"Professional fashion photograph, {pname}. ONE woman, angled 45 degrees toward the camera, framed so her whole sculpted form is visible from the top of her head down to two individually rounded, deliberately carved tips {pos}, her face in natural scale with her body — never an oversized close-up crop of just the face. Where her sculpted form comes to an end at her {part}, it is because the sculpture itself ends there, not because a camera frame happens to cut her off.\n\n"
         f"Subject: A real photograph of a strikingly beautiful adult {nat} woman — {fa}, {hair}. {REAL_FACE}\n\n"
         f"Piercings: {pierce}{DENS if dense else ''}{gem_text(G) if method == '집중형' else ''} {CARE2.format(metal=metal_phrase)}\n\n{DEPTH}\n\n"
         f"Physique: {phys}\n\nBody: {body} {tip}\n\n{mid}\n\n"
         f"Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. There is no line down the centre of her body. At that line, the material's edge rises in a small raised step above her flesh, casting a crisp shadow — her skin beside it stays smooth and even. The rounded tip is the material's own carved finish, always the clean, deliberate result of a sculpture — never the edge of a photograph. Shards interlock along the collarbone line only.\n\n"
         f"Setting: a huge backdrop behind her washed with two coloured lights from behind — {ba} on one side and {bb} on the other, blending into a smooth gradient in the middle, and a glossy dark floor beneath her.\n\n"
         f"Pose: standing tall, her left hand (solid material) resting on her flared hip, her right arm held clear of her body with the hand (solid material) relaxed at hip height, both hands well away from her face, head tilted slightly toward the camera.\n\n{light} Shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait.")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), (frame, P, kind)
    if M not in ("MG", "MR", "MX"): assert "gold" not in pierce.lower(), (frame, P, M)
    desc = f"{re.sub(r'^[A-Z]+', '', HS[si-1])} · {re.sub(r'^[A-Z]+', '', HC[ci-1])} · 메이크업 {mk} · 금속 {MKO[M]} · 재질 {mname}"
    return p, desc, mname
specs = [("hip","P50","정의형","stone",0), ("hip","P100","정의형","T1","resin"), ("demi","P25","집중형","T2","rosegarden"), ("demi","P50","정의형","T3",("sapphire","butterflies")), ("tq","P8","집중형","wood",0), ("tq","P25","집중형","stone",1)]
items = [(fr, P, m, k) + build(fr, P, m, k, key) for fr, P, m, k, key in specs]
order = list(range(6)); rnd.shuffle(order); no = {i: order.index(i)+1 for i in range(6)}; ranked = sorted(range(6), key=lambda i: no[i])
L = ["# LumineX · 재질 프레임 컷 + 피어싱 한도 시험 — 힙컷·데미스탯·쓰리쿼터 (6개, 조각이 매끈하게 끝나는 방식)\n",
     "몸 전체가 재질로 대체된 조각이고, 카메라가 자르는 게 아니라 **조각 자체가 허벅지·무릎에서 매끈하게 끝나는** 형식입니다(첨부하신 데미스탯 프리셋 구조). 얼굴·귀·목만 실사 살입니다. 재질은 석재, 목재, 단일 투명재질, 수조 투명재질, 내용물 투명재질을 섞어서 배정했습니다. 각 프레임에서 한도로 추정한 단계의 위아래를 한 개씩 넣었습니다(힙컷 P50·P100, 데미스탯 P25·P50, 쓰리쿼터 P8·P25). P8·P25는 집중형(왼쪽 몰림, 정면 화면에서는 오른쪽), P50 이상은 정의형입니다. 피어싱 문구는 첨부 프리셋의 안전한 문구(calm, healthy skin)와 Piercing depth 문단을 썼습니다. 번호는 섞여 있습니다.\n",
     "**알려주실 것**: 집중형(P8·P25)은 **얼굴·귀 피어싱 개수만** 세어 주시고, P50 이상은 **성공/실패**(얼굴·귀 피어싱이 눈에 띄지 않거나 조각 형태가 안 나오면 실패)로 적어 주세요. 최대 3회. 예: `1: 9개 / 2: 실패 / 3: 성공`\n",
     "## 색인\n", "| 번호 | 프레임 | 단계 | 방식 | 재질 종류 | 구성 |", "|---|---|---|---|---|---|"]
KIND_KO = {"stone": "석재", "wood": "목재", "T1": "단일 투명", "T2": "수조 투명", "T3": "내용물 투명"}
for i in ranked: fr, P, m, k, p, d, mn = items[i]; L.append(f"| {no[i]:02d} | {FRKO[fr]} | {P} | {m} | {KIND_KO[k]} | {d} |")
L.append("")
for i in ranked: fr, P, m, k, p, d, mn = items[i]; L += [f"## {no[i]:02d}. {FRKO[fr]} · {P} · {KIND_KO[k]}({mn})\n", "```", p, "```\n"]
open("/tmp/rep_out/LumineX_Pierce_StatueFrames_Round1.md", "w", encoding="utf-8").write("\n".join(L))
print("6개 저장")
for i in ranked: fr, P, m, k, p, d, mn = items[i]; print(f"  {no[i]:02d} {FRKO[fr]:<4} {P:<4} {m:<4} {len(p.split()):>4}단어 | {KIND_KO[k]} · {mn}")
