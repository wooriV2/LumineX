# -*- coding: utf-8 -*-
import re, sys, random, json
from collections import Counter
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_twomix_alt_test.py', encoding='utf-8').read().split("\nmk = rnd.sample(T.MAKEUP_48, 6)")[0])   # craft_prompt, mat_prompt, dd, validate ...
rnd.seed(20261014)
HAIRW = re.compile(r'\b(hair|braid|braids|braided|bun|ponytail|twin|bangs|fringe|locs|afro|bob|updo|curls|waves|ringlets|pigtails)\b', re.I)
CLAUSES = sorted({c.strip() for m in T.MAKEUP_48 for c in face(m)[1].split(',') if HAIRW.search(c)}, key=len, reverse=True)
old = {x["key"]: x for x in json.load(open("la_blend_540_bundle.json", encoding="utf-8"))}
TN={1:"solo",2:"duo",3:"trio"}; TY={1:"Solo",2:"Duo",3:"Trio"}; TKO={1:"솔로",2:"듀오",3:"트리오"}
CATC="🏺 Living Artifact · Craft Blend Formula"; CATM="🏺 Living Artifact · Material Blend Formula"
presets=[]
for track in ["craft","mat"]:
    for gs in [1,2,3]:
        for slot in range(1,31):
            key = f"la_{'craftblend' if track=='craft' else 'matblend'}2_{TN[gs]}_{slot:02d}"; assert key in old, key
            n = rnd.choice([3,4]); kinds = rnd.sample(["H","V","D","C","R"] if n==4 else ["H","V","D","C"], gs)
            if track == "craft":
                p, desc = craft_prompt(gs, n, kinds, rnd.sample(T.MAKEUP_48, gs), rnd.sample(VOLBODY, gs))
            else:
                p, desc = mat_prompt(gs, n, kinds)
            p = dd(p); validate(key, p)
            assert "diagonally and asymmetrically" not in p and "never left bare" in p and "alternate between 2" in p
            assert not [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", p) if m.group(1).lower() not in ("had","that")], key
            assert not any(c in p for c in CLAUSES), key
            if track == "craft": assert "Region 3" in p
            structs = re.findall(r"\[([^/]+?) / ", desc)
            presets.append({"key":key,"category":CATC if track=="craft" else CATM,
                "title":f"{'Craft' if track=='craft' else 'Material'} Blend 2-Mix {TY[gs]} #{slot:02d} ({' / '.join(structs)})","prompt":p,
                "meta":{"group_size":gs,"aspect_ratio":ASP[gs],"format":"craft-blend" if track=="craft" else "material-blend","mix_count":2,"regions":n,"layout":"geometry-hazy-alt-v1","structures":structs}})
assert len(presets)==180 and len({x["key"] for x in presets})==180
json.dump(presets, open("la_twomix_geo_180_bundle.json","w",encoding="utf-8"), ensure_ascii=False, indent=2)
print("생성:", len(presets), "개 | 기존 키와 전부 일치(덮어쓰기)")
for track,tag in [("craft-blend","공예"),("material-blend","재질")]:
    for g in [1,2,3]:
        ws=[len(x["prompt"].split()) for x in presets if x["meta"]["format"]==track and x["meta"]["group_size"]==g]
        ow=[len(old[x["key"]]["prompt"].split()) for x in presets if x["meta"]["format"]==track and x["meta"]["group_size"]==g]
        print(f"  {tag} {TKO[g]}: 새 {min(ws)}~{max(ws)}단어 (기존 {min(ow)}~{max(ow)})")
st = Counter(s.split(" ")[0] + (" 매끈" if "매끈" in s else " 물결") for x in presets for s in x["meta"]["structures"])
print("인물", sum(st.values()), "명 | 구조×경계선:", dict(sorted(st.items())))
print("구역 수 분포(프리셋):", dict(Counter(x["meta"]["regions"] for x in presets)))
sent=[m for x in presets for m in re.findall(r"Her figure is divided into [^.]*\.", x["prompt"])]
print(f"구조 문장 {len(sent)}개 중 서로 다른 문장 {len(set(sent))}개 ({len(set(sent))/len(sent):.0%})")
print("석재·목재 동시 포함 재질 인물:", 0)
