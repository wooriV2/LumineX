# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g18 = load("g18","gen18.py"); g3 = g18.g3
MAT = g18.MAT; CARE = g18.CARE; DENS = g18.DENS
WAIST_BODY = g3.WAIST_BODY

# (단계, 체형키, 재질L, 재질R) — 피어싱/스타일은 가슴 프레임 버전과 동일
PLAN = {
 "8":   ("hgs",  "sapphire","citrine"),
 "25":  ("hgu",  "emerald","carnelian"),
 "50":  ("musc", "ruby","aquamarine"),
 "100": ("uss",  "cobalt","amber"),
 "150": ("colo", "jade","amethyst"),
 "K1":  ("p_hgu","smoky","rosequartz"),
 "K2":  ("p_uss","resin","sapphire"),
}
WHITISH = {"alabaster","moonstone","opal","frosted","seaglass","rosequartz","resin","ice","glacial"}
for k,(b,a,c) in PLAN.items():
    assert not (a in WHITISH and c in WHITISH)

OUT = []
for tier, sty, _bk, _a, _b, pierce, metal, label, dense in g18.SPEC:
    bk, a, b = PLAN[tier]
    nat, mk, face = g3.face_of(sty)
    an, adesc, ainner = MAT[a]; bn, bdesc, binner = MAT[b]
    bname, btext = WAIST_BODY[bk]
    preg = bk.startswith("p_")
    belly = " The pregnant belly is one smooth swelling of the material, its surface the material's own polished curve." if preg else ""
    p = f"""Professional fashion photograph, upper-body shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head down to the middle of her belly, the frame cutting off across the belly so no hips, legs or feet are visible. Her face sits in the upper part of the frame, and her ear pieces are oversized so they read clearly at this distance. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {face}. Her whole face, ears and neck are real living flesh with real pores and fine skin grain — a photograph of a real face, not an illustration.

Piercings: {pierce}{DENS if dense else ''} {CARE.format(metal=metal)}

Physique: {btext}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest and belly): solid {adesc}, with {ainner}. Right half: solid {bdesc}, with {binner}. Each is carved as one solid sculpted mass like a statue, never hollow, the chest two great rounded masses, and the grooves and belly folds cut into the material itself.{belly} The arms flow into the torso with no seam, and every wrist, palm, finger and knuckle is the same material as its arm, with no skin texture on any hand.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the chest and belly and out of the bottom of the frame where the two materials meet, never horizontal. Shards interlock along the lines only, every edge solid all the way through.

Pose: body angled 45 degrees, her left hand (solid material) held low at the frame edge beside her belly, her right hand (solid material) held at chest height clear of her body, well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal light on her face and ears only, so the makeup and the glints on every piece of metal read clearly; a strong backlight through each half so both sides of the body glow from within; a thin cool rim light along the centre line. 2:3 vertical 8K portrait."""
    OUT.append((tier, sty, bname, an, bn, label, p))

if __name__ == "__main__":
    for t, s, bn_, an, bn, l, p in OUT:
        print(t, s, bn_, an, "×", bn, l, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
