# -*- coding: utf-8 -*-
import re, sys, random
sys.path.insert(0, '.')
sys.path.insert(0, '/home/claude/diversity')
from full_dicts import face, NAIL_SHAPE_EN_FULL, NAIL_FIN_EN_FULL, HAIR_EN_FULL, HAIR_COLOR_EN_FULL, SHOE_EN_FULL, POSE_EN_FULL, AGE_EN_FULL, VIBE_EN_FULL, CRAFT_DB_FULL
from body_full import BODY_FULL, BODY_PREGNANT, BODY_PREGNANT_MORE
import tracker as T

banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","snake","safety pin","gash"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    low = p.lower()
    hits = [w for w in banned if w in low and w not in ("bite","snake")]
    assert not hits, (name,hits)
    risky = ['embroider','weav','woven','textile','stitch']
    rh = [w for w in risky if w in low]
    assert not rh, (name, "FABRIC_WORD", rh)

ALL_PREG = {**BODY_PREGNANT, **BODY_PREGNANT_MORE}
PREG_BODIES = list(ALL_PREG.keys())
GEM_EN = {"GD":"diamonds","GP":"pearls","GO":"opals","GA":"amethysts","GR":"rubies","GS":"sapphires","GX":"mixed gems"}
FORM_EN = {"FH":"hoops","FS":"studs","FB":"bars","FC":"clicker rings","FD":"drop dangles","FG":"segment rings","FX":"mixed"}
METAL_EN = {"MG":"gold","MR":"rose-gold","MS":"silver","MC":"copper","MBR":"brass","MBZ":"bronze","MX":"mixed"}
PCOUNT = {"P0":"0","P3":"3","P5":"5","P8":"8","P15":"15","P25":"25","P50":"50","P100":"100","P150":"150","P200":"200"}
JTYPE_EN = {"JE":"earrings","JN":"a necklace","JB":"a bracelet","JR":"a ring","JA":"an anklet","JH":"a hair ornament"}
JMETAL_EN = {"JMG":"gold","JMS":"silver","JMR":"rose-gold","JMP":"platinum","JMX":"mixed-metal"}
JQ_SHORT = {"JQ1":"a single piece","JQ2":"two to three pieces","JQ3":"four to six pieces, layered","JQ4":"seven to ten pieces, heavily stacked","JQ5":"well over ten pieces, an extreme maximalist stack"}
def pierce_phrase(p,f,g,m):
    if p=="P0": return "ears bare, no piercings"
    return f"{PCOUNT[p]} {FORM_EN[f]} piercings set with {GEM_EN[g]} in {METAL_EN[m]}-toned metal"
BELLY_BOOST = "larger and more dramatically rounded than an ordinary full-term pregnancy, projecting forward well beyond the line of her own chest"

# 무난한 10종 헤어스타일/컬러
HAIR_STYLE_10 = ["HSS스트레이트","HSW웨이브","HSC컬","HSPT포니테일","HSU업두","HSHU하프업","HSBN번","HSBC보브컷","HSSH샤기컷","HSWF울프컷"]
HAIR_COLOR_10 = ["HCJB제트블랙","HCNB내추럴블랙","HCDB다크브라운","HCCB체스트넛브라운","HCCH초콜릿브라운","HCAB애쉬브라운","HCAU오번","HCHB허니블론드","HCGB골든블론드","HCBL발레아쥬"]

rnd = random.Random(777111)
def rpick(pool): return rnd.choice(pool)

def bp_block(label):
    makeup = rpick(T.MAKEUP_48)
    craft = rpick(T.CRAFTS_39)
    nat, fa = face(makeup)
    bodykey = rpick(T.BODY_14)
    bodytext = BODY_FULL[bodykey]
    cn, cd, cb, cf = CRAFT_DB_FULL[craft]
    nail = f"{NAIL_SHAPE_EN_FULL[rpick(T.NAIL_SHAPES)]} nails, {NAIL_FIN_EN_FULL[rpick(T.NAIL_FINISH)]} finish"
    hair_style = HAIR_EN_FULL[rpick(HAIR_STYLE_10)]
    hair_color = HAIR_COLOR_EN_FULL[rpick(HAIR_COLOR_10)]
    age = AGE_EN_FULL[rpick(T.AGE_12)]; vibe = VIBE_EN_FULL[rpick(T.VIBE_5)]
    pose = POSE_EN_FULL[rpick(T.POSE_19)]; shoe = SHOE_EN_FULL[rpick(T.SHOES_24)]
    return (f"{label} (Bodypaint): a real adult {nat} woman in her {age}, her face exactly the same tone as her body, real skin texture with visible pores, {fa}, {vibe}, {hair_color} hair styled in {hair_style}, real living eyes. Long {nail}. "
            f"{bodytext} "
            f"Painted in {cn} ({cd}), wide {cb} bands following every deep crease, dense {cf} filling the space between bands, pigment on living skin, covering her whole body below the jaw with no bare skin anywhere, face unpainted. "
            f"Pose: {pose}. Footwear: extreme {cb} {shoe}.")

def preg_block(label):
    makeup = rpick(T.MAKEUP_48)
    craft = rpick(T.CRAFTS_39)
    nat, fa = face(makeup)
    bodykey = rpick(PREG_BODIES)
    bodytext = ALL_PREG[bodykey].replace("a high, smoothly rounded pregnant belly", f"a high, smoothly rounded pregnant belly, {BELLY_BOOST},", 1)
    cn, cd, cb, cf = CRAFT_DB_FULL[craft]
    nail = f"{NAIL_SHAPE_EN_FULL[rpick(T.NAIL_SHAPES)]} nails, {NAIL_FIN_EN_FULL[rpick(T.NAIL_FINISH)]} finish"
    hair_style = HAIR_EN_FULL[rpick(HAIR_STYLE_10)]
    hair_color = HAIR_COLOR_EN_FULL[rpick(HAIR_COLOR_10)]
    age = AGE_EN_FULL[rpick(T.AGE_12)]; vibe = VIBE_EN_FULL[rpick(T.VIBE_5)]
    shoe = SHOE_EN_FULL[rpick(T.SHOES_24)]
    pierce = pierce_phrase(rpick(T.PIERCE_P), rpick(T.PIERCE_F), rpick(T.PIERCE_G), rpick(T.PIERCE_M))
    jq = rpick(list(T.JEWELRY_QTY.keys())) if isinstance(T.JEWELRY_QTY, dict) else rpick(T.JEWELRY_QTY)
    jtype = rpick(['JE','JN','JB','JR','JA','JH']); jmetal = rpick(['JMG','JMS','JMR','JMP','JMX'])
    jewelry = f"{JQ_SHORT[jq]} of {JMETAL_EN[jmetal]} {JTYPE_EN[jtype]}"
    return (f"{label} (Pregnant): {nat}, in her {age}, {vibe} expression, warm radiant skin tone, extraordinarily large pregnant physique far beyond any real person — {bodytext} "
            f"Her face is a real living adult face, {fa}, {hair_color} hair styled in {hair_style}, real pores, real living eyes, {pierce}, wearing {jewelry}. "
            f"Painted in {cn}, {cd}, covering every inch of skin from neck to ankle, wide {cb} bands curving fully around her belly, the densest concentration of {cf} wrapping the belly as centrepiece and continuing over her bust, nowhere left bare. "
            f"Pose: standing frontal, both hands cradling the underside of her belly, extreme {cb} {shoe}.")

OUT = []
for i in range(5):
    b1 = preg_block("LEFT")
    b2 = preg_block("CENTER")
    b3 = bp_block("RIGHT")
    body = "\n\n".join([b1,b2,b3])
    p = f"""Image format: a landscape-orientation photograph, 4:5 aspect ratio.

A photograph of THREE women standing side by side on a plain seamless deep-charcoal backdrop, nothing else in the frame, the camera set back so all three fill the frame, 50mm lens at f/8, a single hard key light raking across all of them from one side, sharp focus head to toe on each — a real photograph, not an illustration, not CGI, not a render.

{body}

Composition: each woman's own pose as described, inner arms not crossing her neighbours, all faces toward the camera.

Lighting: the painted patterns reading crisp against each woman's skin, the hard raking light carving every fold and curve. Shot on a Hasselblad X2D, 4:5 8K."""
    check(f"trio{i}", p)
    OUT.append((f"트리오 {i+1} (임산부+임산부+바디페인팅)", p))

for label,p in OUT:
    print(label, len(p.split()))

L = ["# LumineX · 임산부2+바디페인팅1 트리오 5개 (헤어 무난한10종만, 나머지 랜덤)\n"]
for label,p in OUT:
    L.append(f"## {label}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_Preg2_BP1_Trio5_SafeHair.md","w",encoding="utf-8").write("\n".join(L))
print("saved")
