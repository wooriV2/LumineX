# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'/home/claude/glassface')
from full_dicts import face, NAIL_SHAPE_EN_FULL, NAIL_FIN_EN_FULL, HAIR_EN_FULL, SHOE_EN_FULL, POSE_EN_FULL, AGE_EN_FULL, VIBE_EN_FULL, CRAFT_DB_FULL
from body_full import BODY_FULL, BODY_PREGNANT, BODY_PREGNANT_MORE

banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","snake","safety pin","gash"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    hits = [w for w in banned if w in p.lower() and w not in ("bite","snake")]
    assert not hits, (name,hits)
    risky = ['embroider','weav','woven','textile','stitch']
    rh = [w for w in risky if w in p.lower()]
    assert not rh, (name, "FABRIC_WORD", rh)
    lace_bad = re.findall(r'(?<!corset-)\blace\b(?!-up)', p.lower())
    assert not lace_bad, (name, "LACE")

ALL_PREG = {**BODY_PREGNANT, **BODY_PREGNANT_MORE}
GEM_EN = {"GD":"diamonds","GP":"pearls","GO":"opals","GA":"amethysts","GR":"rubies","GS":"sapphires","GX":"mixed gems"}
FORM_EN = {"FH":"hoops","FS":"studs","FB":"bars","FC":"clicker rings","FD":"drop dangles","FG":"segment rings","FX":"mixed"}
METAL_EN = {"MG":"gold","MR":"rose-gold","MS":"silver","MC":"copper","MBR":"brass","MBZ":"bronze","MX":"mixed"}
PCOUNT = {"P0":"0","P3":"3","P5":"5","P8":"8"}
JTYPE_EN = {"JE":"earrings","JN":"a necklace","JB":"a bracelet","JR":"a ring","JA":"an anklet","JH":"a hair ornament"}
JMETAL_EN = {"JMG":"gold","JMS":"silver","JMR":"rose-gold","JMP":"platinum","JMX":"mixed-metal"}
JQ_SHORT = {"JQ1":"a single piece","JQ2":"two to three pieces","JQ3":"four to six pieces","JQ4":"seven to ten pieces, stacked"}
def pierce_phrase(p,f,g,m):
    if p=="P0": return "ears bare, no piercings"
    return f"{PCOUNT[p]} {FORM_EN[f]} piercings with {GEM_EN[g]} in {METAL_EN[m]}-toned metal"
BELLY_BOOST = "larger and more dramatically rounded than an ordinary full-term pregnancy, projecting forward well beyond the line of her own chest"

FACE_CUSTOM = {
 "아게하": ("Japanese","gyaru-style tan skin, heavy false lashes, glittery eyeshadow, glossy pale lip"),
 "한복화보": ("Korean","flawless porcelain skin, soft rose-pink lips, delicate graceful eye makeup"),
 "만바": ("Japanese","deep tan skin, bold white eyeliner, colorful glittery eyeshadow, a glossy nude lip"),
 "지뢰계": ("Japanese","pale skin, dark smoky eyes, red-toned makeup, a melancholic wistful expression"),
 "코갸루": ("Japanese","tan skin, loose white socks aesthetic makeup, glossy brown lip, playful eyes"),
 "아마갸루": ("Japanese","dark tan skin, heavy white eyeliner, glittery eyeshadow, a glossy pale lip"),
 "프렌치레드립": ("French","fair skin, a classic matte red lip, subtle winged eyeliner"),
 "GermanGlam": ("German","fair skin, sculpted contour, a nude glossy lip, polished blonde brows"),
}
def face_c(sty):
    if sty in FACE_CUSTOM: return FACE_CUSTOM[sty]
    return face(sty)

BP_DATA = {
 "makeup": ["아게하","한복화보","만바","지뢰계","BollywoodGlam","AoDaiGlam","코갸루","아마갸루","텔레노벨라글램","파키스탄브라이덜글램","프렌치레드립","GermanGlam"],
 "body": ["레전드바스트","브라질부티글램","블랙글래머","USSBBW","슈퍼글래머","아워글래스SSBBW","커브드바스트","머슬아워글래스BBW","폴리네시안여신","아마조네스","파워리프터","글래머아워글래스"],
 "craft": ["IslamicGeometric","SpanishAndalusian","GeorgianMinonkari","FinnishIittala","IndianMughal","CroatianHvar","PortugueseAzulejo","CubistFragment","YorubaAdireEleko","MoroccanZellige","UkrainianPysanka","TurkishIznik"],
 "shoe": ["익스트림플랫폼버클부츠","익스트림플랫폼하이힐","익스트림플랫폼싸이하이부츠","익스트림플랫폼싸이하이부츠","익스트림플랫폼클리어힐","익스트림플랫폼레이스업샌들","익스트림플랫폼레이스업샌들","익스트림플랫폼웨지","익스트림플랫폼하이힐","익스트림플랫폼싸이하이부츠","익스트림플랫폼싸이하이부츠","익스트림플랫폼레이스업샌들"],
 "pose": ["3/4각도","양무릎꿇고정면","뒷모습3/4","얼굴감싸기","완전뒷모습","벽에기대기","걷는동작","점프동작","양팔위로","정면와이드스탠스","바닥옆으로기대기","한쪽무릎꿇기"],
 "nail_s": ["NS스퀘어","NS스퀘어","NR라운드","NA아몬드","NS스퀘어","NS스퀘어","NS스퀘어","NO오벌","NR라운드","NT스틸레토","NC코핀","NO오벌"],
 "nail_f": ["FC크롬","FT글리터","FT글리터","FH홀로그래픽","FH홀로그래픽","FH홀로그래픽","FC크롬","FC크롬","FH홀로그래픽","FG글로시","FM매트","FT글리터"],
 "hair": ["HSPT포니테일","HSTT트윈테일","HSC컬","HSC컬","HSTT트윈테일","HSB브레이드","HSB브레이드","HSC컬","HSU업두","HSW웨이브","HSW웨이브","HSC컬"],
 "age": ["A50M","A50E","A50L","A40M","A20E","A40E","A30E","A20M","A40L","A20L","A30L","A30M"],
 "vibe": ["VCH시크한","VC귀여운","VP청순한","VC귀여운","VS섹시한","VPR도발적인","VC귀여운","VPR도발적인","VPR도발적인","VS섹시한","VPR도발적인","VPR도발적인"],
}
bp_counter = [0]
def bp_block(label):
    i = bp_counter[0] % 12
    bp_counter[0] += 1
    nat, fa = face_c(BP_DATA["makeup"][i])
    bodykey = BP_DATA["body"][i]
    bodytext = BODY_FULL[bodykey]
    cn, cd, cb, cf = CRAFT_DB_FULL[BP_DATA["craft"][i]]
    nail = f"{NAIL_SHAPE_EN_FULL[BP_DATA['nail_s'][i]]} nails, {NAIL_FIN_EN_FULL[BP_DATA['nail_f'][i]]} finish"
    hair = HAIR_EN_FULL[BP_DATA["hair"][i]]; age = AGE_EN_FULL[BP_DATA["age"][i]]; vibe = VIBE_EN_FULL[BP_DATA["vibe"][i]]
    pose = POSE_EN_FULL[BP_DATA["pose"][i]]; shoe = SHOE_EN_FULL[BP_DATA["shoe"][i]]
    return (f"{label} (Bodypaint track): a real adult {nat} woman in her {age}, her face exactly the same tone as her body, real skin texture with visible pores, {fa}, {vibe}, {hair} hair, real living eyes. Long {nail}. "
            f"An extraordinarily large woman, far beyond any real person. {bodytext} "
            f"Painted in {cn} ({cd}), wide {cb} bands following every deep crease, dense {cf} filling the space between bands, pigment on living skin, covering her whole body below the jaw with no bare skin anywhere, face unpainted. "
            f"Pose: {pose}. Footwear: extreme {cb} {shoe}.")

PREG_BODIES = ['임산부글래머','임산부콜로설','임산부풀텀트윈즈','임산부USSBBW','임산부아워글래스SSBBW','임산부슈퍼글래머','임산부블랙글래머','임산부레전드바스트','임산부커브드바스트','임산부브라질부티글램','임산부폴리네시안여신','임산부USSBBW']
PREG_DATA = {
 "makeup": ["레바논웨딩글램","파케앙트글램","소피아로렌풍","강남언니","화환화장","웨이쉰","GermanGlam","한복화보","AoDaiGlam","BollywoodGlam","프렌치레드립","텔레노벨라글램"],
 "body": PREG_BODIES,
 "craft": ["TurkishIznik","GeorgianMinonkari","PortugueseAzulejo","UkrainianPysanka","MoroccanZellige","YorubaAdireEleko","IslamicGeometric","SpanishAndalusian","IndianMughal","CroatianHvar","FinnishIittala","CubistFragment"],
 "shoe": ["익스트림플랫폼하이힐","익스트림플랫폼스퀘어토힐","익스트림플랫폼버클부츠","익스트림플랫폼클리어힐","익스트림플랫폼레이스업샌들","익스트림플랫폼웨지","익스트림플랫폼싸이하이부츠","익스트림플랫폼하이힐","익스트림플랫폼스퀘어토힐","익스트림플랫폼버클부츠","익스트림플랫폼클리어힐","익스트림플랫폼레이스업샌들"],
 "nail_s": ["NS스퀘어","NT스틸레토","NA아몬드","NC코핀","NR라운드","NO오벌","NS스퀘어","NT스틸레토","NA아몬드","NC코핀","NR라운드","NO오벌"],
 "nail_f": ["FG글로시","FH홀로그래픽","FC크롬","FT글리터","FM매트","FG글로시","FH홀로그래픽","FC크롬","FT글리터","FM매트","FG글로시","FH홀로그래픽"],
 "hair": ["HSU업두","HSS스트레이트","HSC컬","HSW웨이브","HSB브레이드","HSBN번","HSPT포니테일","HSTT트윈테일","HSU업두","HSS스트레이트","HSC컬","HSW웨이브"],
 "age": ["A40E","A30L","A30M","A20E","A40L","A30E","A40M","A20M","A30L","A40E","A20L","A30M"],
 "vibe": ["VC귀여운","VPR도발적인","VCH시크한","VS섹시한","VP청순한","VC귀여운","VCH시크한","VP청순한","VS섹시한","VPR도발적인","VC귀여운","VCH시크한"],
 "pierce_p": ["P3","P5","P0","P8","P3","P5","P0","P8","P3","P5","P0","P8"],
 "pierce_f": ["FB","FG","FD","FH","FC","FB","FG","FD","FH","FC","FB","FG"],
 "pierce_g": ["GP","GD","GR","GS","GA","GO","GP","GD","GR","GS","GA","GO"],
 "pierce_m": ["MS","MX","MBZ","MG","MC","MBR","MS","MX","MBZ","MG","MC","MBR"],
 "jq": ["JQ4","JQ1","JQ2","JQ3","JQ4","JQ1","JQ2","JQ3","JQ4","JQ1","JQ2","JQ3"],
 "jtype": ["JN","JH","JE","JB","JR","JA","JN","JH","JE","JB","JR","JA"],
 "jmetal": ["JMR","JMG","JMS","JMP","JMX","JMR","JMG","JMS","JMP","JMX","JMR","JMG"],
}
preg_counter = [0]
def preg_block(label):
    i = preg_counter[0] % 12
    preg_counter[0] += 1
    nat, fa = face_c(PREG_DATA["makeup"][i])
    bodykey = PREG_DATA["body"][i]
    bodytext = ALL_PREG[bodykey].replace("a high, smoothly rounded pregnant belly", f"a high, smoothly rounded pregnant belly, {BELLY_BOOST},", 1)
    cn, cd, cb, cf = CRAFT_DB_FULL[PREG_DATA["craft"][i]]
    nail = f"{NAIL_SHAPE_EN_FULL[PREG_DATA['nail_s'][i]]} nails, {NAIL_FIN_EN_FULL[PREG_DATA['nail_f'][i]]} finish"
    pierce = pierce_phrase(PREG_DATA["pierce_p"][i], PREG_DATA["pierce_f"][i], PREG_DATA["pierce_g"][i], PREG_DATA["pierce_m"][i])
    jewelry = f"{JQ_SHORT[PREG_DATA['jq'][i]]} of {JMETAL_EN[PREG_DATA['jmetal'][i]]} {JTYPE_EN[PREG_DATA['jtype'][i]]}"
    return (f"{label} (Pregnant track): {nat}, in her {AGE_EN_FULL[PREG_DATA['age'][i]]}, {VIBE_EN_FULL[PREG_DATA['vibe'][i]]} expression, warm radiant skin tone, extraordinarily large pregnant physique far beyond any real person — {bodytext} "
            f"Her face is a real living adult face, {fa}, {HAIR_EN_FULL[PREG_DATA['hair'][i]]} hair, real pores, {pierce}, wearing {jewelry}. "
            f"Painted in {cn}, {cd}, covering every inch of skin from neck to ankle, wide {cb} bands curving fully around her belly, the densest concentration of {cf} wrapping the belly as centrepiece and continuing over her bust, nowhere left bare. "
            f"Pose: standing frontal, both hands cradling the underside of her belly, extreme {cb} {SHOE_EN_FULL[PREG_DATA['shoe'][i]]}.")

IREZUMI_MOTIFS = [
 ("dragon phoenix", "BLAZING ELECTRIC GOLD dragon coiling the full torso and both legs neck to ankle, VIVID CRIMSON phoenix wings spreading across the full chest"),
 ("koi sakura", "BLAZING CRIMSON koi ascending spiral full torso both legs neck to ankle, VIVID PINK sakura petal cascade filling every gap"),
 ("chrysanthemum", "BLAZING DEEP GOLD chrysanthemum blooms enormous layered petals full torso both legs neck to ankle, VIVID EMERALD leaf lattice filling every gap"),
 ("plum crane", "BLAZING VIVID CRIMSON plum blossom storm full torso both legs neck to ankle, VIVID GOLD crane pair soaring filling every gap"),
]
PHYSIQUES = [
 ("super hourglass", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum beyond any proportion, most dramatic hourglass ratio ever recorded on any human body, thighs so thick pressing together"),
 ("wide hip narrow", "hips so impossibly wide extending beyond frame creating the most extreme hip-to-waist ratio ever, waist cinched to absolute impossible minimum, upper body slim emphasizing the dramatic hip explosion"),
 ("BBW bombshell", "most massive full-figure BBW body ever at absolute maximum in every dimension, hips so wide beyond proportion dominating the entire frame, bust so enormous overwhelming gravity, waist deeply snatched despite impossible volume"),
 ("curvy petite", "smallest most compact frame possible yet curves exploding at absolute maximum in every direction, bubble butt projecting dramatically backward from the tiny frame, thighs so thick they dwarf the petite frame"),
 ("amazon bombshell", "impossibly tall commanding frame with simultaneously the most massive full-figure curves, enormous powerful presence dominating the entire frame top to bottom, legs endlessly long massively thick and powerful"),
]
HAIRS = ["long sleek jet-black hair cascading past hips","silver-white natural hair swept into a high sculpted crown","loose beach waves mid-length tousled","blunt collarbone-length bob thick heavy","silver-white locs cascading to her waist"]
POSES_M = ["strong hip pop right, both hands pressing sides of hips outward simultaneously arching back to extreme",
 "full frontal wide stance, both fists pressing outer hips outward to absolute maximum",
 "standing full height, both arms slightly spread commanding the frame",
 "back three-quarter turned, face over shoulder direct eye contact, bubble butt projected backward",
 "strong hip pop left, both hands pressing outer hips outward arching back to extreme"]
AGES_M = ["early 30s","late 20s","mid 40s","late 30s","mid 50s"]
mx_counter = [0]
def next_mx_idx():
    i = mx_counter[0] % 5
    mx_counter[0] += 1
    return i

def irezumi_block(label):
    i = next_mx_idx()
    phy_name, phy_detail = PHYSIQUES[i]
    motif_name, motif_ink = IREZUMI_MOTIFS[i % len(IREZUMI_MOTIFS)]
    return (f"{label} (Irezumi track): THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {AGES_M[i]} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {HAIRS[i]} — full body {motif_name} irezumi covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Bold black ink outlines — {motif_ink}, NO airbrush NO gradient wash. Pose: {POSES_M[i]} — most extreme {phy_name} silhouette ever displayed. Footwear: platform boots 8 inch, extra long stiletto nails to match.")

UV_MOTIFS = [
 ("cosmic nebula", "ELECTRIC MAGENTA nebula cloud formations swirling across the chest and upper body, VIVID NEON CYAN plasma stream formations flowing down both legs, BLAZING NEON GOLD star cluster formations filling every gap"),
 ("lightning web", "ELECTRIC EMERALD lightning bolt formations branching across the full torso both legs neck to ankle, VIVID NEON YELLOW spark burst formations filling every gap"),
 ("crystal lattice", "ELECTRIC VIOLET geometric lattice facets full torso both legs to ankle, prismatic crystal faces refracting CYAN light"),
]
def uvneon_block(label):
    i = next_mx_idx()
    phy_name, phy_detail = PHYSIQUES[i]
    motif_name, motif_ink = UV_MOTIFS[i % len(UV_MOTIFS)]
    return (f"{label} (UV Neon track): THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {AGES_M[i]} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, UV-reactive BLAZING {HAIRS[i]} — full body UV neon {motif_name} bodypaint covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Bold formations — BLAZING {motif_ink}, NO airbrush NO gradient wash. Pose: {POSES_M[i]} — most extreme {phy_name} silhouette ever displayed. Under her own dedicated UV blacklight spot, zero white light reaching her specifically. Footwear: platform boots 8 inch, extra long stiletto nails BLAZING NEON UV reactive tips.")

GLASS_COLORS = [("ELECTRIC CRIMSON","VIVID GOLD"),("ELECTRIC VIOLET","VIVID CYAN"),("ELECTRIC EMERALD","VIVID GOLD")]
def glass_block(label):
    i = next_mx_idx()
    phy_name, phy_detail = PHYSIQUES[i]
    c1,c2 = GLASS_COLORS[i % len(GLASS_COLORS)]
    return (f"{label} (Stained Glass track): THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {AGES_M[i]} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {HAIRS[i]} — full body stained glass covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is solid thick glass fused directly to her form, not a garment, made of hundreds of small individual panes each no larger than a coin, densely packed edge to edge, never large sheets, each tiny pane curving to follow her body's true shape with real physical thickness, dark lead-line seams webbing between every pane, each seam standing in a small raised ridge casting its own shadow, never flat. BLAZING {c1} and VIVID {c2} panes alternating in a dense irregular mosaic, bright light passing through each tiny pane with sharp refraction glints, NO airbrush NO gradient wash. Pose: {POSES_M[i]} — most extreme {phy_name} silhouette ever displayed. Footwear: leaded-glass platform boots 8 inch, the same dense small-pane mosaic continuing onto the shoe, extra long stiletto nails to match.")

LEAF_COLORS = [("ELECTRIC CRIMSON","GOLD"),("ELECTRIC VIOLET","CYAN"),("ELECTRIC EMERALD","GOLD")]
def goldleaf_block(label):
    i = next_mx_idx()
    phy_name, phy_detail = PHYSIQUES[i]
    c1,c2 = LEAF_COLORS[i % len(LEAF_COLORS)]
    return (f"{label} (Gold Leaf track): THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {AGES_M[i]} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {HAIRS[i]} — full body applied {c1} leaf covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Thin irregular metallic sheets — BLAZING {c1} leaf with fine natural creases and overlapping seams, VIVID {c2} undertone glinting through the thinnest points, a soft warm metallic sheen filling every gap, NO airbrush NO gradient wash. Pose: {POSES_M[i]} — most extreme {phy_name} silhouette ever displayed. Footwear: platform boots 8 inch, extra long stiletto nails to match.")

FLOWERS = [("peony","CRIMSON","EMERALD"),("orchid","VIOLET","GOLD"),("sakura","PINK","GOLD")]
def botanical_block(label):
    i = next_mx_idx()
    phy_name, phy_detail = PHYSIQUES[i]
    flower,c1,c2 = FLOWERS[i % len(FLOWERS)]
    return (f"{label} (Botanical track): THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {AGES_M[i]} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, hair threaded through with real trailing vines — full body living {flower} growing directly from her own skin covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not a printed pattern, not a dress, every stem rooted directly into her living skin and every petal standing up in true three-dimensional relief casting its own small shadow, nothing lying flat. BLAZING {c1} {flower} blossoms in full three-dimensional bloom, VIVID {c2} leaves and curling tendrils filling every remaining gap with real depth and texture, NO airbrush NO gradient wash, NO flat printed surface anywhere. Pose: {POSES_M[i]} — most extreme {phy_name} silhouette ever displayed. Footwear: extreme platform heels entirely overgrown with the same living {flower} blooms and vines, extra long nails with tiny petals embedded at each tip.")

TRACK_FN = {"bp": bp_block, "preg": preg_block, "ire": irezumi_block, "uv": uvneon_block, "glass": glass_block, "gold": goldleaf_block, "bot": botanical_block}
LABELS = ["#1","#2","#3","#4","#5"]
NUM_WORD = {2:"TWO",3:"THREE",4:"FOUR",5:"FIVE"}
ASPECT = {2:"3:4",3:"4:5",4:"4:5",5:"5:4"}

def build_mixed(n, track_keys, seed):
    mx_counter[0] = seed
    labels = LABELS[:n]
    blocks = [TRACK_FN[track_keys[i]](labels[i]) for i in range(n)]
    body = "\n\n".join(blocks)
    frame_note = ", significantly wider than it is tall" if n>=6 else ""
    p = f"""Professional fashion photograph, full body shot. {NUM_WORD[n]} women standing side by side, each from a different Living Artifact track.

{body}

MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. Composition: each woman's own pose as described, inner arms not crossing her neighbours. Lighting: a single hard key light raking across all women from one side, realistic photographic grain where applicable, extreme high-gloss oil on maximalist tracks — a real photograph, not an illustration, not CGI, not a render; any UV Neon track woman additionally lit by her own dedicated UV blacklight spot. Pattern density maximum on all {n}, zero bare skin from neck to ankle. Shot on a Hasselblad X2D, {ASPECT[n]} aspect ratio{frame_note}."""
    return p

COMBOS = {
 2: [("bp","preg"), ("ire","gold"), ("glass","bot")],
 3: [("bp","preg","ire"), ("uv","glass","gold"), ("bot","bp","gold")],
 4: [("bp","preg","ire","uv"), ("glass","gold","bot","bp"), ("preg","ire","uv","glass")],
 5: [("bp","preg","ire","uv","glass"), ("gold","bot","bp","preg","ire"), ("uv","glass","gold","bot","preg")],
}
TRACK_KO = {"bp":"바디페인팅","preg":"임산부","ire":"이레즈미","uv":"UV네온","glass":"스테인드글라스","gold":"금박","bot":"보태니컬"}

OUT = []
seed = 0
for n in [2,3,4,5]:
    for combo in COMBOS[n]:
        p = build_mixed(n, combo, seed)
        seed += 1
        check(f"{n}_{combo}", p)
        combo_ko = "+".join(TRACK_KO[t] for t in combo)
        OUT.append((f"{NUM_WORD[n].capitalize()}({n}인) — {combo_ko}", p))

for label,p in OUT:
    print(label, len(p.split()))

L = ["# LumineX · 자유축+맥시멀리스트 다트랙 혼합 — 듀오3·트리오3·쿼르텟3·퀸텟3\n"]
for label,p in OUT:
    L.append(f"## {label}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_MixedTracks_Duo3_Trio3_Quartet3_Quintet3.md","w",encoding="utf-8").write("\n".join(L))
print("saved", len(OUT))

# ===================== 6~14인: 7개 트랙 전부 순환 사용 =====================
LABELS14 = [f"#{i}" for i in range(1,15)]
NUM_WORD2 = {6:"SIX",7:"SEVEN",8:"EIGHT",9:"NINE",10:"TEN",11:"ELEVEN",12:"TWELVE",13:"THIRTEEN",14:"FOURTEEN"}
ASPECT2 = {n:"16:9" for n in range(6,15)}
TRACK_ORDER = ["bp","preg","ire","uv","glass","gold","bot"]

def build_mixed_large(n, seed):
    mx_counter[0] = seed
    labels = LABELS14[:n]
    track_keys = [TRACK_ORDER[i % 7] for i in range(n)]
    blocks = [TRACK_FN[track_keys[i]](labels[i]) for i in range(n)]
    body = "\n\n".join(blocks)
    p = f"""Professional fashion photograph, full body shot. {NUM_WORD2[n]} women standing side by side in a single row, each from a different Living Artifact track (tracks cycle and repeat as needed), generous horizontal spacing so every figure reads clearly.

{body}

MANDATORY pure pitch black void background only for the whole frame, absolutely NO studio backdrop NO texture NO grey NO gradient. Composition: each woman's own pose as described, inner arms not crossing her neighbours, every woman an extraordinarily large woman far beyond any real person. Lighting: a single hard key light raking across all bodypaint/pregnant/irezumi/stained-glass/gold-leaf/botanical women from one side, realistic photographic grain where applicable, extreme high-gloss oil on maximalist tracks — a real photograph, not an illustration, not CGI, not a render; any UV Neon track woman additionally lit by her own dedicated UV blacklight spot. Pattern density maximum on all {n}, zero bare skin from neck to ankle. Shot on a Hasselblad X2D, 16:9 landscape 8K, significantly wider than it is tall."""
    return p

OUT2 = []
for n in range(6,15):
    p = build_mixed_large(n, seed=n*13)
    check(f"large{n}", p)
    tracks_used = [TRACK_ORDER[i % 7] for i in range(n)]
    tracks_ko = "+".join(TRACK_KO[t] for t in tracks_used)
    OUT2.append((f"{NUM_WORD2[n].capitalize()}({n}인) — {tracks_ko}", p))

for label,p in OUT2:
    print(label, len(p.split()))

L2 = ["# LumineX · 7트랙 전부 순환 사용 — 6~14인\n"]
for label,p in OUT2:
    L2.append(f"## {label}\n"); L2.append("```"); L2.append(p); L2.append("```\n")
open("/tmp/rep_out/LumineX_AllTracks_6to14.md","w",encoding="utf-8").write("\n".join(L2))
print("saved2", len(OUT2))

# ===================== 15인 2개 =====================
LABELS15 = [f"#{i}" for i in range(1,16)]
def build_mixed_15(seed, start_track_idx):
    mx_counter[0] = seed
    n = 15
    labels = LABELS15
    track_keys = [TRACK_ORDER[(start_track_idx+i) % 7] for i in range(n)]
    blocks = [TRACK_FN[track_keys[i]](labels[i]) for i in range(n)]
    body = "\n\n".join(blocks)
    p = f"""Professional fashion photograph, full body shot. FIFTEEN women standing side by side in a single row, each from a different Living Artifact track (tracks cycle and repeat as needed), generous horizontal spacing so every figure reads clearly.

{body}

MANDATORY pure pitch black void background only for the whole frame, absolutely NO studio backdrop NO texture NO grey NO gradient. Composition: each woman's own pose as described, inner arms not crossing her neighbours, every woman an extraordinarily large woman far beyond any real person. Lighting: a single hard key light raking across all bodypaint/pregnant/irezumi/stained-glass/gold-leaf/botanical women from one side, realistic photographic grain where applicable, extreme high-gloss oil on maximalist tracks — a real photograph, not an illustration, not CGI, not a render; any UV Neon track woman additionally lit by her own dedicated UV blacklight spot. Pattern density maximum on all 15, zero bare skin from neck to ankle. Shot on a Hasselblad X2D, 16:9 landscape 8K, significantly wider than it is tall."""
    return p

p1 = build_mixed_15(seed=150, start_track_idx=0)
check("fifteen1", p1)
p2 = build_mixed_15(seed=151, start_track_idx=3)
check("fifteen2", p2)
print("15-1", len(p1.split()))
print("15-2", len(p2.split()))

tracks1 = [TRACK_ORDER[i % 7] for i in range(15)]
tracks2 = [TRACK_ORDER[(3+i) % 7] for i in range(15)]
L3 = ["# LumineX · 7트랙 순환 — 15인 2개\n"]
L3.append(f"## 15인 #1 — {'+'.join(TRACK_KO[t] for t in tracks1)}\n"); L3.append("```"); L3.append(p1); L3.append("```\n")
L3.append(f"## 15인 #2 — {'+'.join(TRACK_KO[t] for t in tracks2)}\n"); L3.append("```"); L3.append(p2); L3.append("```\n")
open("/tmp/rep_out/LumineX_AllTracks_Fifteen_2.md","w",encoding="utf-8").write("\n".join(L3))
print("saved3")

# ===================== 등록용: 2~10인 각 30개 =====================
import random as _random
NUM_WORD_ALL = {2:"TWO",3:"THREE",4:"FOUR",5:"FIVE",6:"SIX",7:"SEVEN",8:"EIGHT",9:"NINE",10:"TEN"}
ASPECT_ALL = {2:"3:4",3:"4:5",4:"4:5",5:"5:4",6:"16:9",7:"16:9",8:"16:9",9:"16:9",10:"16:9"}
TYPE_NAME_ALL = {2:"duo",3:"trio",4:"quartet",5:"quintet",6:"sextet",7:"septet",8:"octet",9:"nonet",10:"decet"}

def build_registered(n, track_keys, seed):
    mx_counter[0] = seed
    labels = LABELS15[:n]
    blocks = [TRACK_FN[track_keys[i]](labels[i]) for i in range(n)]
    body = "\n\n".join(blocks)
    frame_note = ", significantly wider than it is tall" if n>=6 else ""
    p = f"""Professional fashion photograph, full body shot. {NUM_WORD_ALL[n]} women standing side by side, each from a different Living Artifact track.

{body}

MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. Composition: each woman's own pose as described, inner arms not crossing her neighbours. Lighting: a single hard key light raking across all bodypaint/pregnant/irezumi/stained-glass/gold-leaf/botanical women from one side, realistic photographic grain where applicable, extreme high-gloss oil on maximalist tracks — a real photograph, not an illustration, not CGI, not a render; any UV Neon track woman additionally lit by her own dedicated UV blacklight spot. Pattern density maximum on all {n}, zero bare skin from neck to ankle. Shot on a Hasselblad X2D, {ASPECT_ALL[n]} aspect ratio{frame_note}."""
    return p

all_presets = []
rnd_master = _random.Random(20261003)
stats = {}
for n in range(2, 11):
    type_name = TYPE_NAME_ALL[n]
    lengths = []
    for slot in range(1, 31):
        # 트랙 조합: 7종 중 n개를 순환/셔플해서 다양성 확보 (n>7이면 반복 허용)
        base = TRACK_ORDER[:]
        rnd_master.shuffle(base)
        if n <= 7:
            track_keys = base[:n]
        else:
            track_keys = [base[i % 7] for i in range(n)]
        seed = rnd_master.randrange(100000)
        p = build_registered(n, track_keys, seed)
        check(f"mixed_{type_name}_{slot}", p)
        key = f"la_mixed7_{type_name}_{slot:02d}"
        tracks_ko = "+".join(TRACK_KO[t] for t in track_keys)
        all_presets.append({
            "key": key,
            "category": "🏺 Living Artifact · Mixed-Track Formula",
            "title": f"Mixed7 {type_name.capitalize()} #{slot:02d} ({tracks_ko})",
            "prompt": p,
            "meta": {"group_size": n, "aspect_ratio": ASPECT_ALL[n], "format": "mixed-7-track", "tracks": track_keys}
        })
        lengths.append(len(p.split()))
    stats[type_name] = (min(lengths), max(lengths))

print("생성 완료:", len(all_presets), "개")
for t,(mn,mx) in stats.items():
    print(f"  {t}: {mn}~{mx} 단어")

with open("/home/claude/mixed12/la_mixed7_bundle.json","w",encoding="utf-8") as f:
    json.dump(all_presets, f, ensure_ascii=False, indent=2)
print("번들 저장 완료")
