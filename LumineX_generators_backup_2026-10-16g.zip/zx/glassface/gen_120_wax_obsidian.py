# -*- coding: utf-8 -*-
import re, random, json

banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","safety pin","gash","crack"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    hits = [w for w in banned if w in p.lower()]
    assert not hits, (name,hits)

PHYSIQUES = [
 ("super hourglass", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum beyond any proportion, most dramatic hourglass ratio ever recorded on any human body, thighs so thick pressing together"),
 ("wide hip narrow", "hips so impossibly wide extending beyond frame creating the most extreme hip-to-waist ratio ever, waist cinched to absolute impossible minimum, upper body slim emphasizing the dramatic hip explosion"),
 ("BBW bombshell", "most massive full-figure BBW body ever at absolute maximum in every dimension, hips so wide beyond proportion dominating the entire frame, bust so enormous overwhelming gravity, waist deeply snatched despite impossible volume"),
 ("curvy petite", "smallest most compact frame possible yet curves exploding at absolute maximum in every direction, bubble butt projecting dramatically backward from the tiny frame, thighs so thick they dwarf the petite frame"),
 ("amazon bombshell", "impossibly tall commanding frame with simultaneously the most massive full-figure curves, enormous powerful presence dominating the entire frame top to bottom, legs endlessly long massively thick and powerful"),
 ("latina curves", "most dramatic hourglass ratio ever, simultaneously maximum enormous bust AND maximum enormous hips both flaring to absolute impossible extremes while the waist is cinched to impossible minimum"),
 ("hourglass bombshell", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum, thighs pressing together, every curve maximized at once"),
 ("powerlifter bombshell", "immense powerful thighs and shoulders built with real strength, a thick solid waist, overwhelming muscular bulk layered with soft curves everywhere"),
]
HAIRS = ["long sleek jet-black hair cascading past hips","silver-white natural hair swept into a high sculpted crown","loose beach waves mid-length tousled","blunt collarbone-length bob thick heavy","silver-white locs cascading to her waist","curtain bangs long straight hair sweeping past the shoulders","two thick goddess braids","high ponytail swept sleek"]
POSES = ["strong hip pop right, both hands pressing sides of hips outward simultaneously arching back to extreme",
 "full frontal wide stance, both fists pressing outer hips outward to absolute maximum",
 "standing full height, both arms slightly spread commanding the frame",
 "back three-quarter turned, face over shoulder direct eye contact, bubble butt projected backward",
 "strong hip pop left, both hands pressing outer hips outward arching back to extreme",
 "full frontal, both hands framing the face, chin raised",
 "three-quarter angle, one hand on the outer hip, the other raised overhead"]
AGES = ["early 20s","late 20s","early 30s","mid 30s","late 30s","mid 40s","early 50s","mid 50s"]

WAX_COLORS = [("DEEP CRIMSON","AMBER"),("DEEP EMERALD","GOLD"),("DEEP VIOLET","ROSE")]

rnd = random.Random(99099)
def rpick(pool): return rnd.choice(pool)

def wax_block(label, idx):
    phy_name, phy_detail = PHYSIQUES[idx % 8]
    c1,c2 = rpick(WAX_COLORS)
    age = AGES[idx % 8]; hair = HAIRS[idx % 8]; pose = POSES[idx % 7]
    mat = (f"full body molten wax flowing and set directly over her own skin covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not a printed pattern, this is real wax that has flowed down every curve and hardened in place, each drip and pooled ridge standing in true three-dimensional relief, casting its own small soft shadow, nothing lying flat. Dense flowing drips — BLAZING {c1} molten wax streams pooling and hardening across the full torso both legs neck to ankle, VIVID {c2} translucent drip-ridges catching the light filling every remaining gap with real depth and texture, each ridge glossy and rounded exactly like real set wax, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    prefix = f"{label}: " if label else ""
    return (f"{prefix}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {hair} — {mat}. Pose: {pose} — most extreme {phy_name} silhouette ever displayed.\n"
            f"{prefix}extreme platform heels entirely coated in the same hardened wax drips, extra long nails with tiny wax drip tips at each nail.")

def obsidian_block(label, idx):
    phy_name, phy_detail = PHYSIQUES[idx % 8]
    age = AGES[idx % 8]; hair = HAIRS[idx % 8]; pose = POSES[idx % 7]
    mat = ("full body polished obsidian stone fused directly to her own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, this is solid glossy black stone curving to follow her body's true three-dimensional shape, with molten gold seams running between dozens of fitted stone sections, each seam standing in a thin raised ridge catching its own bright glint and casting its own small shadow, nothing lying flat. Dense fitted sections — BLAZING glossy jet-black obsidian surface across the full torso both legs neck to ankle, VIVID MOLTEN GOLD seams branching and converging densely with no plain stone section left ungilded, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    prefix = f"{label}: " if label else ""
    return (f"{prefix}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {hair} — {mat}. Pose: {pose} — most extreme {phy_name} silhouette ever displayed.\n"
            f"{prefix}extreme platform boots carved from the same glossy obsidian with gold seams, extra long nails glossy black with gold seam tips.")

NUM_WORD = {1:"ONE",2:"TWO",3:"THREE"}
ASPECT = {1:"2:3",2:"3:4",3:"4:5"}
LABELS3 = ["#1","#2","#3"]
TYPE_NAME = {1:"solo",2:"duo",3:"trio"}

def build(material_fn, n, slot_base):
    labels = LABELS3[:n] if n>1 else [None]
    blocks = []
    for i in range(n):
        idx = slot_base*3+i
        blocks.append(material_fn(labels[i], idx))
    body = "\n\n".join(blocks)
    if n == 1:
        tail = "MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. ONE woman only. Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
    else:
        tail = f"Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.\nAll: Extreme macro detail on every surface texture and shadow. CRITICAL: all {n} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere, every element standing in true relief, nothing flat. {NUM_WORD[n]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame."
    p = f"""Professional fashion photograph, full body shot. {NUM_WORD[n]} wom{"a" if n==1 else "e"}n standing{" side by side" if n>1 else ""}.

{body}

{tail} 8K portrait {ASPECT[n]} aspect ratio."""
    return p

all_presets = []
for mat_key, mat_fn, catname in [("wax", wax_block, "🏺 Living Artifact · Wax Formula"), ("obsidian", obsidian_block, "🏺 Living Artifact · Obsidian Gold Formula")]:
    for n in [1,2,3]:
        type_name = TYPE_NAME[n]
        for slot in range(1,21):
            p = build(mat_fn, n, slot)
            check(f"{mat_key}_{type_name}_{slot}", p)
            key = f"la_{mat_key}_{type_name}_{slot:02d}"
            all_presets.append({
                "key": key, "category": catname,
                "title": f"{mat_key.capitalize()} {type_name.capitalize()} #{slot:02d}",
                "prompt": p, "meta": {"group_size": n, "aspect_ratio": ASPECT[n], "material": mat_key}
            })

print("생성:", len(all_presets))
with open("/home/claude/glassface/la_120_bundle.json","w",encoding="utf-8") as f:
    json.dump(all_presets, f, ensure_ascii=False, indent=2)
print("저장 완료")
