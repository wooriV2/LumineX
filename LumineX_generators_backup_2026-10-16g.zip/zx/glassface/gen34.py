# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g33 = load("g33","gen33.py"); g18 = g33.g18; g3 = g33.g3; MAT = g33.MAT
WAIST_BODY = g3.WAIST_BODY; DEPTH = g33.DEPTH; DENS = g33.DENS; CARE_BODY = g33.CARE_BODY

PREG_CUE = (" The belly dome projects far out in front of her body and is seen in a strong three-quarter profile, so its full round curve reads clearly against the dark background: a smooth taut rounded dome rising from beneath the chest and curving back in toward the hips, unmistakably a late-term pregnancy, the largest form in the frame.")

OUT = []
for label, sty, bk, a, b, ptxt, dens, metal, age in g33.SPEC:
    if not bk.startswith("p_"):
        continue
    nat, mk, fc = g3.face_of(sty)
    an, adesc, ainner = MAT[a]; bn, bdesc, binner = MAT[b]
    bname, btext = WAIST_BODY[bk]
    care = CARE_BODY if label == "P200" else g18.CARE.format(metal=metal)
    p = f"""Professional fashion photograph, three-quarter body shot. ONE woman, angled about 60 degrees toward the camera so her body is seen in strong three-quarter profile, framed from the very top of her head down through the hips, the frame cutting off across the upper thighs so no knees, lower legs or feet are visible. Her face sits in the upper part of the frame, and her ear pieces are oversized so they read clearly at this distance. {age}.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}. Her whole face, ears and neck are real living flesh with real pores and fine skin grain — a photograph of a real face, not an illustration.

Piercings: {ptxt}{DENS if dens else ''} {care}

{DEPTH}

Physique: {btext}{PREG_CUE}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest, belly, hip and upper thigh): solid {adesc}, with {ainner}. Right half: solid {bdesc}, with {binner}. Each is carved as one solid sculpted mass like a statue, never hollow, the chest two great rounded masses and the folds and creases cut into the material itself. The pregnant belly is one smooth swelling of the material, its surface the material's own polished curve. The arms flow into the torso and the torso into the thighs with no seam, and every wrist, palm, finger and knuckle is the same material as its arm.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the chest, over the crown of the belly dome and between the hips and thighs, out of the bottom of the frame where the two materials meet, never horizontal. Shards interlock along the lines only, every edge solid all the way through.

Pose: body angled about 60 degrees, her left hand (solid material) resting gently under the curve of the belly, her right hand (solid material) held at chest height clear of her body, well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal light on her face and ears only, so the makeup and the glints on every piece of metal read clearly; a strong backlight through each half so the whole belly dome glows from within; a thin cool rim light along the belly's curve and the centre line. 2:3 vertical 8K portrait."""
    OUT.append((label, sty, bname, an, bn, metal, p))

if __name__ == "__main__":
    for l, s, bn_, an, bn, m, p in OUT:
        print(l, s, bn_, an, "×", bn, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
