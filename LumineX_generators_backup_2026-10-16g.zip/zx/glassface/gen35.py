# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g2 = load("g2","gen2.py"); g3 = load("g3","gen3.py"); g4 = load("g4","gen4.py")
MAT = g2.MAT; BUST_BODY = g2.BODY; FULL_BODY = g4.BODY; HIP_BODY = g3.HIP_BODY
REAL_FACE = "Her whole face, ears and neck are real living flesh with real pores and fine grain."

# =============== 1. Glass Face Duo (각자 통재질) ===============
def duo(frame_txt, sty1, sty2, body1, body2, m1, m2, ear1, ear2, col1, col2, shoe, pose):
    n1, k1, f1 = g3.face_of(sty1); n2, k2, f2 = g3.face_of(sty2)
    a1n, a1d, a1i = MAT[m1]; a2n, a2d, a2i = MAT[m2]
    lower1 = "belly, hips and thighs" if frame_txt == "hip" else "belly, hips, legs and feet"
    shoes = (" Each woman's extreme platform stiletto sandals are carved from the same material as her own legs, running unbroken through the ankle, the instep and every toe." if shoe else "")
    frame = ("framed from the very top of their heads down through the hips, the frame cutting off across the upper thighs" if frame_txt == "hip"
             else "the camera set back so both whole bodies fit in the frame from the top of their heads to their feet")
    return f"""Professional fashion photograph, double portrait{', three-quarter body shot' if frame_txt=='hip' else ', full body shot, head to toe'}. TWO women standing close side by side, shoulder to shoulder, both angled 45 degrees toward the camera, {frame}. Both faces are sharp. Each woman's body is one single material — the two materials never mix and each figure's own outline stays clear.

The left woman: a strikingly beautiful adult {n1} woman in {k1} makeup — {f1}. {REAL_FACE} {ear1} Her body: {body1} From the collarbones down, her whole body — shoulders, arms, hands, chest, {lower1} — is not painted, covered or clothed but physically made of one solid transparent material, solid {a1d}, with {a1i}, carved as one solid sculpted mass like a statue, never hollow, with no seam and no skin anywhere, every wrist, palm, finger and knuckle the same material.

The right woman: a strikingly beautiful adult {n2} woman in {k2} makeup — {f2}. {REAL_FACE} {ear2} Her body: {body2} From the collarbones down, her whole body — shoulders, arms, hands, chest, {lower1} — is not painted, covered or clothed but physically made of one solid transparent material, solid {a2d}, with {a2i}, carved as one solid sculpted mass like a statue, never hollow, with no seam and no skin anywhere, every wrist, palm, finger and knuckle the same material.{shoes}

Boundary: on each woman a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. There is no line down the centre of either body: each is one uniform material. Shards interlock along the collarbone lines only, every edge solid all the way through. Where the two women touch at the shoulder, the two materials press against each other and stay distinct.

Pose: {pose}

Lighting: pure pitch black background. A soft frontal light on both faces and ears only; {col1}; {col2}; a thin cool rim light along both figures. Only their faces, ears and necks read as real skin. 3:4 vertical 8K portrait."""

D1 = duo("hip","슬라브 글램(러시아·동유럽)","락혼 글램(태국)", HIP_BODY["uss"][1], HIP_BODY["hipq"][1], "emerald","ruby",
  "On each ear a big silver hoop with a filigree silver drop.", "On each ear a big gold hoop with a chased-gold drop.",
  "a strong green backlight through the emerald woman so she glows from within",
  "a strong crimson backlight through the ruby woman so she glows from within",
  False,
  "their outer hands rest on their flared hips (solid material) and their inner arms hang relaxed at their sides, all hands well away from their faces, both heads tilted slightly toward the camera.")
D2 = duo("full","요루바 신부 화장(나이지리아)","노르딕 발키리(노르웨이)", FULL_BODY["hgu"][1], FULL_BODY["colo"][1], "cobalt","citrine",
  "On each ear a big gold hoop with a red-enamel bead.", "On each ear a thick silver knotted hoop.",
  "a strong blue backlight through the cobalt woman so she glows from within",
  "a strong golden backlight through the citrine woman so she glows from within",
  True,
  "both stand tall on long legs, never short or squat, feet planted apart, their outer hands (solid material) resting on their flared hips and their inner arms hanging relaxed at their sides, all hands well away from their faces, both heads tilted slightly toward the camera.")

# =============== 2. 조명 색 축 ===============
def light(colors, name):
    n, k, f = g3.face_of("소피아 로렌풍(이탈리아)")
    an, ad, ai = MAT["glacial"]; bn, bd, bi = MAT["emerald"]
    return f"""Professional fashion photograph, bust shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head to just below her chest, the frame cutting off beneath the chest. Her face sits large and sharp in the upper half of the frame. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {n} woman in {k} makeup — {f}. {REAL_FACE} On each ear a large real pearl drop with a gold clip.

Physique: {BUST_BODY['top'][1]}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest): solid {ad}, with {ai}. Right half: solid {bd}, with {bi}. Each is carved as one solid sculpted mass like a statue, never hollow, the chest two great rounded masses with the groove between them cut into the material itself. The arms flow into the chest with no seam, and every wrist, palm, finger and knuckle is the same material as its arm.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the chest and out of the bottom of the frame where the two materials meet, never horizontal. Shards interlock along the lines only, every edge solid all the way through.

Pose: body angled 45 degrees, her left hand (solid material) held low at the frame edge beside her chest, her right hand (solid material) held at chest height clear of her body, well away from her face, head tilted slightly toward the camera.

Lighting: pure black background. A soft, neutral frontal light on her face and ears only. {colors} The coloured light passes through both halves of the body and tints every carved surface and edge, while her real face keeps its natural skin tone. Only her face, ears and neck read as real skin. 2:3 vertical 8K portrait."""

L1 = light("A strong warm sunset backlight in deep orange and gold from behind both sides, so the ice glows amber-orange and the emerald glows warm golden-green, with a thin gold rim light along the centre line.", "sunset")
L2 = light("A strong neon backlight in hot pink and magenta from behind both sides, so the ice glows pink and the emerald glows deep magenta-green, with a thin electric cyan rim light along the centre line.", "neon")
L3 = light("A strong cold moonlight backlight in blue and silver from behind both sides, so the ice glows pale blue and the emerald glows deep teal, with a thin silver rim light along the centre line.", "moon")

# =============== 3. Vessel Body 변형 (가슴) ===============
def vessel(sty, bk, left, right, lightL, lightR, ear):
    n, k, f = g3.face_of(sty)
    return f"""Professional fashion photograph, bust shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head to just below her chest, the frame cutting off beneath the chest. Her face sits large and sharp in the upper half of the frame. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {n} woman in {k} makeup — {f}. {REAL_FACE} {ear} All jewelry is real metal on real skin, healed, clean and calm.

Physique: {BUST_BODY[bk][1]}

Vessel body: from the collarbones down, her body is not skin — it is a sculpted vessel of thick clear glass in the exact shape of her chest, shoulder, arm and hand, filled to the brim so nothing is hollow and there is no air gap. The glass walls are thick and polished, with crisp glints along every edge. {left} {right} The hands are solid clear glass with tiny bubbles inside, every finger and knuckle the same glass as its arm.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, the glass vessel immediately below. A second jagged line runs down the centre of the chest, out of the bottom of the frame, where the two worlds meet, never horizontal. A few small shards of glass interlock along the lines and cast real shadows.

Pose: body angled 45 degrees, her left hand (solid glass) held low at the frame edge beside her chest, her right hand (solid glass) held at chest height clear of her body, well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal light on her face and ears; {lightL}; {lightR}; a thin cool rim light along the centre line. Only her face, ears and neck read as real skin. 2:3 vertical 8K portrait."""

VA = vessel("발칸 글램(루마니아·불가리아)","top",
  "The left half (left shoulder, the whole arm and hand, half the chest) is a lantern: the glass is filled with warm golden light, with small candle flames and dozens of glowing fireflies drifting inside the chest and the arm, and a soft halo of light against the glass walls.",
  "The right half is clockwork: the glass is filled with brass gears, cogs and coiled springs of different sizes meshing together inside the chest and the arm, a small pendulum swinging, and a few tiny clock faces ticking among them.",
  "a strong warm amber backlight through the lantern half so the flames and fireflies glow",
  "a soft brass-gold backlight through the clockwork half so the gears gleam",
  "On each ear a thick gold hoop with a gold coin drop hangs clear of the neck down to the shoulder.")
VB = vessel("코갸루","hgu",
  "The left half (left shoulder, the whole arm and hand, half the chest) is a candy jar: the glass is packed to the brim with colourful jellybeans, gummy candies, striped hard candies and small lollipops filling the chest and the arm.",
  "The right half is a petal jar: the glass is packed to the brim with deep red and soft pink rose petals filling the chest and the arm, a few petals pressed flat against the glass.",
  "a strong warm pink-orange backlight through the candy half so the sweets glow like stained glass",
  "a strong soft crimson backlight through the petal half so the petals glow",
  "On each ear a big silver hoop with a small turquoise-enamel bead hangs clear of the neck down to the shoulder.")
VC = vessel("락혼 글램(태국)","tent",
  "The left half (left shoulder, the whole arm and hand, half the chest) is an hourglass: the glass is filled with fine glowing golden sand streaming down through the chest and the arm in slow bright ribbons, with a few grains suspended in the light.",
  "The right half is an aurora: the glass is filled with rippling ribbons of green and violet light drifting through the chest and the arm, with a scatter of tiny stars deep inside.",
  "a strong warm golden backlight through the sand half so the streaming sand glows",
  "a strong green-violet backlight through the aurora half so the ribbons glow",
  "On each ear a big gold hoop with a chased-gold drop hangs clear of the neck down to the shoulder.")
VD = vessel("프렌치 레드립(프랑스)","colo",
  "The left half (left shoulder, the whole arm and hand, half the chest) is a snow globe: the glass is filled with clear water and softly falling snow around a tiny village with warm-lit windows and a small church in the chest, snowy hills flowing down the arm.",
  "The right half is a kaleidoscope: the glass is filled with shifting shards of coloured glass — red, blue, gold and green — arranged in bright symmetrical patterns through the chest and the arm.",
  "a strong cool blue-white backlight through the snow-globe half so the snow and the tiny windows glow",
  "a strong multicoloured backlight through the kaleidoscope half so the glass shards glow",
  "A single thick gold hoop hangs on each ear.")

# =============== 4. 스케일 듀오 ===============
def scale_palm():
    n, k, f = g3.face_of("슬라브 글램(러시아·동유럽)")
    an, ad, ai = MAT["ruby"]; bn, bd, bi = MAT["aquamarine"]
    return f"""Professional fashion photograph, upper-body shot. ONE towering giantess and ONE tiny real woman. The giantess is angled 45 degrees toward the camera, framed from the very top of her head down to her waist. Her right hand is extended forward toward the camera, palm up, at chest height, and standing on the palm is a tiny real woman no taller than the giantess's index finger. Both are sharp. Mid 20s.

The giantess: a strikingly beautiful adult {n} woman in {k} makeup — {f}. {REAL_FACE} On each ear a big silver hoop with a filigree silver drop. Her body: {BUST_BODY['colo'][1].replace('A giantess on an even scale', 'A towering giantess on an even scale')} From the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest and belly): solid {ad}, with {ai}. Right half: solid {bd}, with {bi}. Each is carved as one solid sculpted mass like a statue, never hollow. Every finger and the whole open palm are the same material as the arm, the lines of the palm carved into it.

The tiny woman: a real living woman, entirely real skin, real hair and real fabric, in a simple white sleeveless dress, standing barefoot on the giantess's palm in the middle of the carved palm lines, her head tilted back, looking up at the giantess's face with wonder. Her tiny size against the huge hand makes the giantess's scale unmistakable.

Boundary: on the giantess a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below — and a second jagged line runs down the centre of the chest and belly and along the middle of the arm and palm, where the two materials meet, never horizontal. Shards interlock along the lines only.

Pose: the giantess holds her right arm forward with the palm up, well below and away from her face, her left arm relaxed at her side, her head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal light on the giantess's face and on the tiny woman; a strong crimson backlight through the ruby half and a strong teal backlight through the aquamarine half, the coloured light passing through the palm and falling on the tiny woman's dress and skin; a thin cool rim light along the centre line. 2:3 vertical 8K portrait."""

def scale_foot():
    n, k, f = g3.face_of("웨이쉰")
    an, ad, ai = MAT["emerald"]; bn, bd, bi = MAT["amethyst"]
    return f"""Professional fashion photograph, full body shot, head to toe. ONE towering giantess standing with her feet planted apart, angled 45 degrees toward the camera, the camera set back and low so her whole body fits in the frame from the top of her head to her feet; in the lower corner of the frame, at the foot of her right leg, stands ONE tiny real woman who reaches only to the giantess's ankle. Both are sharp. Mid 20s.

The giantess: a strikingly beautiful adult {n} woman in {k} makeup — {f}. {REAL_FACE} On each ear a big rose-gold hoop hangs clear of the neck down to the shoulder. Her body: {FULL_BODY['colo'][1]} From the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest, belly, left hip and the whole left leg down through the foot): solid {ad}, with {ai}. Right half: solid {bd}, with {bi}. Each is carved as one solid sculpted mass like a statue, never hollow, and every wrist, palm, finger, knuckle and toe is the same material as its limb. Her extreme platform stiletto sandals are carved from the same material as the leg each one sits under, running unbroken through the ankle and every toe.

The tiny woman: a real living woman, entirely real skin, real hair and real fabric, in a simple white sleeveless dress, standing barefoot on the floor beside the giantess's right platform sandal, her head tilted far back, looking up along the towering figure. Her tiny size against the giantess's ankle makes the scale unmistakable.

Boundary: on the giantess a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below — and a second jagged line runs down the centre of the body, between the hips and legs and down to the floor, where the two materials meet, never horizontal. Shards interlock along the lines only.

Pose: the giantess stands tall on long legs, never short or squat, her left hand (solid material) resting on her flared hip, her right arm held clear of her body with the hand (solid material) relaxed at hip height, well away from her face, her head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal light on the giantess's face and on the tiny woman; a strong green backlight through the emerald half and a strong violet backlight through the amethyst half, throwing soft coloured light onto the floor and onto the tiny woman; a thin cool rim light along the centre line. Only the giantess's face, ears and neck read as real skin. 2:3 vertical 8K portrait."""

S1 = scale_palm(); S2 = scale_foot()

ITEMS = [
 ("D1","Glass Face Duo 힙","슬라브 글램 + 락혼 글램 · USSBBW + 힙 퀸 · 에메랄드(통) + 루비색 유리(통)", D1),
 ("D2","Glass Face Duo 전신","요루바 + 노르딕 발키리 · 아워글래스 USSBBW + 콜로설 · 코발트 유리(통) + 시트린(통)", D2),
 ("L1","조명 색 축 · 노을","소피아 로렌풍 · 빙하 얼음 × 에메랄드 · 주황·금색 역광", L1),
 ("L2","조명 색 축 · 네온","소피아 로렌풍 · 빙하 얼음 × 에메랄드 · 분홍·마젠타 역광", L2),
 ("L3","조명 색 축 · 달빛","소피아 로렌풍 · 빙하 얼음 × 에메랄드 · 청은색 역광", L3),
 ("V1","Vessel Body 변형 · 랜턴 × 시계 장치","발칸 글램 · 톱헤비 아워글래스 · 가슴", VA),
 ("V2","Vessel Body 변형 · 캔디 병 × 꽃잎 병","코갸루 · 아워글래스 USSBBW · 가슴", VB),
 ("V3","Vessel Body 변형 · 모래시계 × 오로라","락혼 글램 · 텐트폴 · 가슴", VC),
 ("V4","Vessel Body 변형 · 스노글로브 × 만화경","프렌치 레드립 · 콜로설 · 가슴", VD),
 ("S1","스케일 듀오 · 손바닥","슬라브 글램 콜로설 거인(루비×아쿠아마린) + 손바닥 위 작은 실사 여성 · 허리 프레임", S1),
 ("S2","스케일 듀오 · 발치","웨이쉰 콜로설 거인(에메랄드×자수정) + 발치의 작은 실사 여성 · 전신", S2),
]
if __name__ == "__main__":
    for n,t,d,p in ITEMS:
        print(n,t,len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
