# -*- coding: utf-8 -*-
import re, random, sys
sys.path.insert(0,'.')
sys.path.insert(0,'/home/claude/diversity')
from full_dicts import CRAFT_DB_FULL
import tracker as T

banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","safety pin","gash","crack"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    hits = [w for w in banned if w in p.lower()]
    assert not hits, (name,hits)
    risky = ['embroider','woven','textile','stitch']
    rh = [w for w in risky if w in p.lower()]
    assert not rh, (name,"FABRIC",rh)

rnd = random.Random(55555)

# ===== 바디페인팅 공예 텍스트 =====
def craft_text(key):
    cn, cd, cb, cf = CRAFT_DB_FULL[key]
    return f"painted {cn} ({cd}), pigment on living skin, {cb} bands following every crease, {cf} filling gaps"

# ===== 맥시멀리스트/재질 풀 =====
MATPOOL = {
 "irezumi": "traditional irezumi tattoo ink, bold black ink outlines, BLAZING CRIMSON koi sakura spiral formations, VIVID PINK petal cascade, extreme high-gloss oil finish",
 "uvneon": "UV-reactive neon bodypaint, invisible under standard light but BLAZING ELECTRIC VIOLET geometric lattice facets glowing under her own dedicated UV blacklight, VIVID CYAN refraction detail",
 "glass": "solid thick stained glass fused to her form, hundreds of small individual panes, BLAZING ELECTRIC EMERALD and VIVID GOLD panes alternating, dark lead-line seams",
 "goldleaf": "applied rose-gold leaf, thin irregular metallic sheets with fine natural creases and overlapping seams, VIVID CYAN undertone glinting through",
 "botanical": "living orchid blooms growing directly from her own skin, every petal standing in three-dimensional relief, BLAZING VIOLET blossoms, VIVID GOLD leaves and tendrils",
 "crystal": "sapphire crystal clusters growing directly out of her own skin, erupting in true three-dimensional relief, BLAZING SAPPHIRE BLUE crystal points, VIVID SILVER mineral veins",
 "scale_dragon": "dragon scales (large thick armor-plate scales, each sharply faceted), BLAZING CRIMSON scale formations, VIVID EMBER scale-edge detail",
 "scale_koi": "koi-fish scales (rounded smooth scales with fine growth rings), BLAZING ELECTRIC CRIMSON scale formations, VIVID PEARL-WHITE scale-edge detail",
 "obsidian": "polished obsidian stone fused directly to her own form, solid glossy black stone, with molten gold seams running between fitted stone sections",
 "wax": "molten wax flowing and set directly over her own skin, BLAZING DEEP CRIMSON wax streams pooling and hardening, VIVID AMBER translucent drip-ridges",
 "wood": "rich dark walnut wood fused directly into her own form, natural grain lines flowing to follow every curve, BLAZING deep warm-brown grain with VIVID honey-gold highlight streaks",
 "stone": "solid polished white marble fused directly into her own form, natural grey-gold veining, BLAZING pale marble surface with VIVID golden vein striations",
}
MATKEYS = list(MATPOOL.keys())

PHYSIQUES = [
 ("super hourglass", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum beyond any proportion, most dramatic hourglass ratio ever recorded on any human body, thighs so thick pressing together"),
 ("BBW bombshell", "most massive full-figure BBW body ever at absolute maximum in every dimension, hips so wide beyond proportion dominating the entire frame, bust so enormous overwhelming gravity, waist deeply snatched despite impossible volume"),
 ("wide hip narrow", "hips so impossibly wide extending beyond frame creating the most extreme hip-to-waist ratio ever, waist cinched to absolute impossible minimum, upper body slim emphasizing the dramatic hip explosion"),
 ("curvy petite", "smallest most compact frame possible yet curves exploding at absolute maximum in every direction, bubble butt projecting dramatically backward from the tiny frame, thighs so thick they dwarf the petite frame"),
 ("amazon bombshell", "impossibly tall commanding frame with simultaneously the most massive full-figure curves, enormous powerful presence dominating the entire frame top to bottom, legs endlessly long massively thick and powerful"),
 ("latina curves", "most dramatic hourglass ratio ever, simultaneously maximum enormous bust AND maximum enormous hips both flaring to absolute impossible extremes while the waist is cinched to impossible minimum"),
 ("hourglass bombshell", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum, thighs pressing together, every curve maximized at once"),
 ("powerlifter bombshell", "immense powerful thighs and shoulders built with real strength, a thick solid waist, overwhelming muscular bulk layered with soft curves everywhere"),
]
HAIRS = ["long sleek jet-black hair cascading past hips","silver-white natural hair swept into a high sculpted crown","loose beach waves mid-length tousled","blunt collarbone-length bob thick heavy","silver-white locs cascading to her waist","curtain bangs long straight hair sweeping past the shoulders","two thick goddess braids","high ponytail swept sleek"]
POSES = ["strong hip pop right, both hands pressing sides of hips outward simultaneously arching back to extreme",
 "full frontal wide stance, both fists pressing outer hips outward to absolute maximum",
 "standing full height, both arms slightly spread commanding the frame",
 "back three-quarter turned, face over shoulder direct eye contact, bubble butt projected backward",
 "strong hip pop left, both hands pressing outer hips outward arching back to extreme",
 "full frontal, both hands framing the face, chin raised",
 "three-quarter angle, one hand on the outer hip, the other raised overhead",
 "standing full height, both arms slightly spread commanding the frame"]
AGES = ["early 20s","late 20s","early 30s","mid 30s","late 30s","mid 40s","early 50s","mid 50s"]

def rpick(pool): return rnd.choice(pool)

# ===== N개 재질 자유형 경계흐림 (한 인물) =====
def person_nmix(idx, label, mat_names, uvneon_included):
    phy_name, phy_detail = PHYSIQUES[idx % 8]
    age = AGES[idx % 8]; hair = HAIRS[idx % 8]; pose = POSES[idx % 8]
    n = len(mat_names)
    mat_texts = [MATPOOL[m] for m in mat_names]
    prefix = f"{label}: " if label else ""
    if n == 2:
        zones_desc = (f"her LEFT side is dominated by {mat_texts[0]}. Her RIGHT side is dominated by {mat_texts[1]}. "
                       f"Rather than a sharp boundary, the two materials interweave and overlap gradually across a soft irregular zone a few inches wide down the centre of her body, elements of each scattered into the other's territory, density fading rather than stopping abruptly")
    else:
        zone_sentences = " ".join(f"{mat_texts[i]} dominates zone {i+1}." for i in range(n))
        zones_desc = (f"her body carries {n} different materials at once, each claiming roughly an equal irregular, organic share of her body rather than any straight line, zones arranged diagonally and asymmetrically across her torso and limbs. {zone_sentences} "
                       f"Wherever any two zones meet, the boundary is soft, diagonal or curving rather than a straight line, the materials interweaving and overlapping gradually across an irregular blended border a few inches wide, elements of each scattered into the neighbouring zone, density fading rather than stopping abruptly")
    extra_light = ""
    if uvneon_included:
        extra_light = " A standard hard key light illuminates most of her body; a separate dedicated UV blacklight illuminates the UV-reactive zone specifically, making it glow at full intensity while the rest reads under normal light."
    return (f"{prefix}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {hair} — {zones_desc}, no fabric no seam no garment anywhere, every material rooted in or fused to her own living skin, covering her completely with no bare skin anywhere from neck to ankle. Pose: {pose} — most extreme {phy_name} silhouette ever displayed.{extra_light}\n"
            f"{prefix}extreme platform heels/boots blending the relevant materials at her feet, extra long nails each matching whichever zone that hand falls in.")

NUM_WORD = {1:"ONE",2:"TWO",3:"THREE"}
ASPECT = {1:"2:3",2:"3:4",3:"4:5"}
LABELS3 = ["#1","#2","#3"]

def build_group(mat_assignments, seed_base):
    # mat_assignments: list of lists, each inner list = materials for that person
    n = len(mat_assignments)
    labels = LABELS3[:n] if n>1 else [None]
    blocks = []
    any_uv = False
    for i, mats in enumerate(mat_assignments):
        uvin = "uvneon" in mats
        if uvin: any_uv = True
        blocks.append(person_nmix(seed_base+i, labels[i], mats, uvin))
    body = "\n\n".join(blocks)
    if n == 1:
        tail = "MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. ONE woman only. Extreme macro detail on every material and every blended transition. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
    else:
        tail = f"Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.\nAll: Extreme macro detail on every material and every blended transition. CRITICAL: all {n} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere. {NUM_WORD[n]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame."
    p = f"""Professional fashion photograph, full body shot. {NUM_WORD[n]} wom{"a" if n==1 else "e"}n standing{" side by side, each with her own multi-material blended body" if n>1 else ""}.

{body}

{tail} 8K portrait {ASPECT[n]} aspect ratio."""
    return p

# ================= PART 1: 바디페인팅 공예만, 경계흐림 =================
CRAFTS = list(T.CRAFTS_39)
rnd.shuffle(CRAFTS)

def craft_blur_2(idx, c1key, c2key):
    phy_name, phy_detail = PHYSIQUES[idx % 8]
    age = AGES[idx % 8]; hair = HAIRS[idx % 8]; pose = POSES[idx % 8]
    t1 = craft_text(c1key); t2 = craft_text(c2key)
    block = (f"a real adult woman, her face exactly the same tone as her body, real skin texture with visible pores, {age}, {hair}. An extraordinarily large woman, far beyond any real person — a {phy_name} silhouette, {phy_detail}. "
             f"Body Art: her LEFT side is {t1}. Her RIGHT side is {t2}. Rather than a sharp boundary, the two painted patterns blend gradually into each other across a soft irregular zone a few inches wide down the centre of her body, motifs from each pattern scattered into the other's territory, density fading rather than stopping abruptly, face unpainted. "
             f"Pose: {pose}.")
    return f"""Image format: a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide.

A full-body photograph with a plain seamless deep-charcoal backdrop, shot on a medium format camera with an 85mm lens at f/8, a single hard key light raking in from one side, sharp focus from head to toe, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.

Subject: {block}

Footwear: extreme platform heels blending both painted patterns across the surface.

Background & Lighting: the blended patterns reading crisp against her skin, the hard raking light carving every fold.

Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide. portrait 2:3 vertical."""

def craft_blur_3(idx, c1key, c2key, c3key):
    phy_name, phy_detail = PHYSIQUES[idx % 8]
    age = AGES[idx % 8]; hair = HAIRS[idx % 8]; pose = POSES[idx % 8]
    t1 = craft_text(c1key); t2 = craft_text(c2key); t3 = craft_text(c3key)
    block = (f"a real adult woman, her face exactly the same tone as her body, real skin texture with visible pores, {age}, {hair}. An extraordinarily large woman, far beyond any real person — a {phy_name} silhouette, {phy_detail}. "
             f"Body Art: her body carries three different painted patterns at once, each claiming roughly an equal irregular organic share of her body rather than any straight line, zones arranged diagonally and asymmetrically. {t1} dominates one zone. {t2} dominates the second zone. {t3} dominates the third zone. Wherever any two zones meet, the boundary is soft and diagonal rather than a straight line, motifs blending gradually across an irregular border a few inches wide, face unpainted. "
             f"Pose: {pose}.")
    return f"""Image format: a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide.

A full-body photograph with a plain seamless deep-charcoal backdrop, shot on a medium format camera with an 85mm lens at f/8, a single hard key light raking in from one side, sharp focus from head to toe, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.

Subject: {block}

Footwear: extreme platform heels blending all three painted patterns across the surface.

Background & Lighting: the blended patterns reading crisp against her skin, the hard raking light carving every fold.

Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide. portrait 2:3 vertical."""

PART1 = []
p = craft_blur_2(0, CRAFTS[0], CRAFTS[1]); check("c2a",p); PART1.append((f"바디페인팅 2개섞기 1 — {CRAFTS[0]}+{CRAFTS[1]}",p))
p = craft_blur_2(1, CRAFTS[2], CRAFTS[3]); check("c2b",p); PART1.append((f"바디페인팅 2개섞기 2 — {CRAFTS[2]}+{CRAFTS[3]}",p))
p = craft_blur_3(2, CRAFTS[4], CRAFTS[5], CRAFTS[6]); check("c3a",p); PART1.append((f"바디페인팅 3개섞기 1 — {CRAFTS[4]}+{CRAFTS[5]}+{CRAFTS[6]}",p))
p = craft_blur_3(3, CRAFTS[7], CRAFTS[8], CRAFTS[9]); check("c3b",p); PART1.append((f"바디페인팅 3개섞기 2 — {CRAFTS[7]}+{CRAFTS[8]}+{CRAFTS[9]}",p))

print("PART1:", len(PART1))
for l,p in PART1: print(" ", l, len(p.split()))

# ================= PART 2: 모든 축, 2/3/4개 섞기 × 솔로/듀오/트리오 각3 =================
PART2 = []
seed = 0
for mixn in [2,3,4]:
    for gsize in [1,2,3]:
        for variant in range(3):
            assignments = []
            for person_i in range(gsize):
                mats = rnd.sample(MATKEYS, mixn)
                assignments.append(mats)
            p = build_group(assignments, seed)
            seed += gsize
            check(f"mix{mixn}_g{gsize}_v{variant}", p)
            gname = {1:"솔로",2:"듀오",3:"트리오"}[gsize]
            desc = " / ".join("+".join(m) for m in assignments)
            PART2.append((f"{mixn}개섞기 {gname} #{variant+1} — {desc}", p))

print("PART2:", len(PART2))
for l,p in PART2: print(" ", l[:80], len(p.split()))

# ===== 저장 =====
L = ["# LumineX · 자유축 경계흐림 + 전체축 N개섞기 매트릭스\n\n## Part 1 — 바디페인팅 공예만 (경계흐림)\n"]
for label,p in PART1:
    L.append(f"### {label}\n"); L.append("```"); L.append(p); L.append("```\n")
L.append("\n## Part 2 — 모든 축 2/3/4개 섞기 × 솔로/듀오/트리오 각 3개\n")
for label,p in PART2:
    L.append(f"### {label}\n"); L.append("```"); L.append(p); L.append("```\n")

open("/tmp/rep_out/LumineX_FullBlurMatrix.md","w",encoding="utf-8").write("\n".join(L))
print("saved total:", len(PART1)+len(PART2))
