# -*- coding: utf-8 -*-
import re

banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","safety pin","gash"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    hits = [w for w in banned if w in p.lower()]
    assert not hits, (name,hits)

PHYSIQUES = {
 "super hourglass": ("super hourglass physique", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum beyond any proportion, most dramatic hourglass ratio ever recorded on any human body, thighs so thick pressing together"),
 "wide hip narrow": ("wide hip narrow physique", "hips so impossibly wide extending beyond frame creating the most extreme hip-to-waist ratio ever, waist cinched to absolute impossible minimum, upper body slim emphasizing the dramatic hip explosion"),
 "BBW bombshell": ("BBW bombshell physique", "most massive full-figure BBW body ever at absolute maximum in every dimension, hips so wide beyond proportion dominating the entire frame, bust so enormous overwhelming gravity, waist deeply snatched despite impossible volume"),
 "curvy petite": ("curvy petite physique", "smallest most compact frame possible yet curves exploding at absolute maximum in every direction, bubble butt projecting dramatically backward from the tiny frame, thighs so thick they dwarf the petite frame"),
 "amazon bombshell": ("amazon bombshell physique", "impossibly tall commanding frame with simultaneously the most massive full-figure curves, enormous powerful presence dominating the entire frame top to bottom, legs endlessly long massively thick and powerful"),
 "latina curves": ("latina curves physique", "most dramatic hourglass ratio ever, simultaneously maximum enormous bust AND maximum enormous hips both flaring to absolute impossible extremes while the waist is cinched to impossible minimum"),
}
HAIRS = ["long sleek jet-black hair cascading past hips","silver-white natural hair swept into a high sculpted crown",
         "long straight platinum-silver hair past her hips","silver-white locs cascading to her waist",
         "loose beach waves mid-length tousled","blunt collarbone-length bob thick heavy"]
POSES = [
 "strong hip pop right, both hands pressing sides of hips outward simultaneously arching back to extreme",
 "full frontal wide stance, both fists pressing outer hips outward to absolute maximum",
 "standing full height, both arms slightly spread commanding the frame",
 "back three-quarter turned, face over shoulder direct eye contact, bubble butt projected backward",
 "strong hip pop left, both hands pressing outer hips outward arching back to extreme",
]

MATERIALS = {
 "stainedglass": {
   "label":"스테인드글라스",
   "bodyart": lambda c1,c2: f"full body stained glass mosaic covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Bold dark lead-line outlines dividing every pane — BLAZING {c1} glass panes catching light across the full torso both legs neck to ankle, VIVID {c2} panes filling every gap, bright light passing through every individual pane with sharp refraction glints, NO airbrush NO gradient wash",
   "bg":"MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. A single strong backlight passing through every pane from directly behind, casting jewel-toned light forward.",
 },
 "goldleaf": {
   "label":"금박",
   "bodyart": lambda c1,c2: f"full body applied {c1} leaf covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Thin irregular metallic sheets — BLAZING {c1} leaf with fine natural creases and overlapping seams across the full torso both legs neck to ankle, VIVID {c2} undertone glinting through the thinnest points, a soft warm metallic sheen filling every gap, NO airbrush NO gradient wash",
   "bg":"MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. A single hard key light raking across the metallic leaf catching every crease and seam in sharp glints.",
 },
 "botanical": {
   "label":"보태니컬",
   "bodyart": lambda c1,c2: f"full body living flower bodypaint covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Dense overlapping blossoms — BLAZING {c1} flowers blooming across the full torso both legs neck to ankle, VIVID {c2} trailing vines and leaves filling every gap with zero visible skin, NO airbrush NO gradient wash",
   "bg":"MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. Soft directional light bringing out the true saturated colour of every petal and leaf.",
 },
 "holographic": {
   "label":"홀로그래픽/이리디센트",
   "bodyart": lambda c1,c2: f"full body holographic iridescent sheen covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. A smooth opalescent surface — BLAZING shifting {c1} and {c2} rainbow sheen rippling across the full torso both legs neck to ankle as the angle changes, filling every gap with a continuous shifting colour wash, NO airbrush NO gradient wash",
   "bg":"MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. Bright light sweeping across her body catching the full shifting rainbow at maximum intensity.",
 },
 "cosmic": {
   "label":"코스믹",
   "bodyart": lambda c1,c2: f"full body cosmic starfield bodypaint covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. A deep indigo-black void surface — BLAZING {c1} nebula cloud formations swirling across the full torso both legs neck to ankle, VIVID {c2} star cluster formations scattered densely filling every gap, STARK WHITE pinpoint stars throughout, NO airbrush NO gradient wash",
   "bg":"MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. The glow of the nebula and stars within her own body the dominant light source, a soft ambient fill keeping her face lit.",
 },
 "geode": {
   "label":"지오드",
   "bodyart": lambda c1,c2: f"full body geode crystal-growth bodypaint covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Clusters of small crystal points breaking through the surface — BLAZING {c1} crystal clusters erupting across the full torso both legs neck to ankle, VIVID {c2} crystal facets filling every gap with sharp internal refraction, NO airbrush NO gradient wash",
   "bg":"MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. Bright light catching sharp glints and internal refraction across every crystal cluster.",
 },
}

COLOR_PAIRS = [("ELECTRIC CRIMSON","VIVID GOLD"),("ELECTRIC VIOLET","VIVID CYAN"),("ELECTRIC EMERALD","VIVID GOLD")]

def person_block(idx, label, mat, age, phy_key):
    phy_name, phy_detail = PHYSIQUES[phy_key]
    hair = HAIRS[idx % len(HAIRS)]
    pose = POSES[idx % len(POSES)]
    c1,c2 = COLOR_PAIRS[idx % len(COLOR_PAIRS)]
    bodyart = mat["bodyart"](c1,c2)
    prefix = f"{label}: " if label else ""
    block = (f"{prefix}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {phy_name} THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {hair} — {bodyart}. Pose: {pose} — most extreme {phy_key} silhouette ever displayed.\n"
             f"{prefix}platform boots 8 inch, extra long stiletto nails to match.")
    return block, phy_key

def build_solo(mat):
    block, phy = person_block(0, None, mat, "early 30s", "super hourglass")
    p = f"""Professional fashion photograph, full body shot. ONE woman standing.

{block}

{mat['bg']} ONE woman only. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle. Extreme high-gloss oil. 2:3 vertical 8K portrait. portrait 2:3 vertical."""
    return p

def build_duo(mat):
    b1, p1 = person_block(0, "LEFT", mat, "late 20s", "wide hip narrow")
    b2, p2 = person_block(1, "RIGHT", mat, "early 30s", "super hourglass")
    p = f"""Professional fashion photograph, full body shot. TWO women standing side by side.

{b1}

{b2}

Environment: {mat['bg']}
All: extreme high-gloss oil. CRITICAL: both women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere. TWO completely different extreme physiques — {p1} and {p2} — must CONTRAST and DOMINATE every inch of frame. 8K portrait 3:4 vertical."""
    return p

def build_trio(mat):
    b1, p1 = person_block(0, "LEFT", mat, "early 30s", "super hourglass")
    b2, p2 = person_block(1, "CENTER", mat, "mid 40s", "BBW bombshell")
    b3, p3 = person_block(2, "RIGHT", mat, "late 30s", "curvy petite")
    p = f"""Professional fashion photograph, full body shot. THREE women standing side by side.

{b1}

{b2}

{b3}

Environment: {mat['bg']}
All: extreme high-gloss oil. CRITICAL: all three women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere. THREE completely different extreme physiques — {p1}, {p2}, {p3} — must CONTRAST and DOMINATE every inch of frame. 8K portrait 4:5 vertical."""
    return p

OUT = []
for key, mat in MATERIALS.items():
    ps = build_solo(mat); check(f"{key}_solo", ps); OUT.append((f"{mat['label']} — 솔로", ps))
    pd = build_duo(mat); check(f"{key}_duo", pd); OUT.append((f"{mat['label']} — 듀오", pd))
    pt = build_trio(mat); check(f"{key}_trio", pt); OUT.append((f"{mat['label']} — 트리오", pt))

for label,p in OUT:
    print(label, len(p.split()))

L = ["# LumineX · 신규재질 6종 맥시멀리스트 스타일 — 솔로·듀오·트리오 각 1개(총 18개)\n"]
for label,p in OUT:
    L.append(f"## {label}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_SixMaterials_HOFStyle_18.md","w",encoding="utf-8").write("\n".join(L))
print("saved")
