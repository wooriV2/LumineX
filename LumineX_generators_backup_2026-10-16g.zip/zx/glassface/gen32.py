# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g9 = load("g9","gen9.py"); g10 = load("g10","gen10.py"); g13 = load("g13","gen13.py"); g30 = load("g30","gen30.py"); g31 = load("g31","gen31.py")
g3 = g30.g3
nat, mk, fc = g3.face_of("코갸루")
btext = g30.btext
BIGEAR = "the biggest hoops hanging clear of the neck down to the shoulders"
DEPTH = ("Piercing depth: every bar and surface bar is embedded in the skin — its middle runs beneath the skin so only its two end studs show on the surface, the skin between them faintly raised over the hidden bar, with a small warm shadow at each end and nothing lying on top of the skin like a sticker. "
"Every ring passes through a small healed opening in the skin, the skin visible through the loop, and every stud sits through the skin with its back hidden. "
"Where a bar, ring or stud goes through the ear, the lip, the nostril or the brow, it passes through the real tissue with the skin wrapping snugly around it.")
CARE = "All jewelry is real silver with a few turquoise-enamel rings, sitting in real skin that is healed, clean and calm — no blood, no redness, no swelling, no wound, the skin around each piece smooth and unbroken — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes."

def metalize(t):
    return t.replace("black-steel", "silver").replace("about one hundred real metal piercings", "about one hundred real silver piercings with a few turquoise-enamel rings among them").replace(
        "about one hundred and fifty real metal piercings", "about one hundred and fifty real silver piercings with a few turquoise-enamel rings among them")

P100 = metalize(g9.P100).replace("ten big hoops, thick bars, stretched plugs, helix rings and studs from lobe to top", "ten oversized hoops, thick bars, stretched plugs, helix rings and studs from lobe to top, " + BIGEAR)
P150 = metalize(g10.P150).replace("twelve big hoops, thick bars, stretched plugs, helix rings and studs from lobe to top", "twelve oversized hoops, thick bars, stretched plugs, helix rings and studs from lobe to top, " + BIGEAR)

def build(pierce, charms):
    return f"""Professional fashion photograph, bust shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head to just below her chest, the frame cutting off beneath the chest. Her face sits large and sharp in the upper half of the frame, and her ear pieces are oversized so they read clearly. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}. She is a real living woman: real pores and fine skin grain on her face, neck, shoulders, arms and hands, real living eyes with bright catchlights, individual hair strands catching the light — a photograph of a real person, not an illustration, not a render.

Clothing: she wears a plain black matte stretch tank top with thin straps that covers her chest, leaving her collarbones, shoulders, arms and hands bare.

Physique: {btext}

Piercings: {pierce}{charms}{g13.DENS} {CARE}

{DEPTH}

Pose: body angled 45 degrees, her left hand low at the frame edge beside her chest, her right hand held at chest height clear of her body, both hands well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal beauty light on her face, shoulders and arms, so the glints on every piece of metal and every charm read clearly, with a thin cool rim light along her hair and shoulders, shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait."""

A = build(P100, g13.K1_CH.replace("pastel enamel and acrylic", "pastel enamel and acrylic"))
B = build(P150, g13.K2_CH)
if __name__ == "__main__":
    for n, p in (("P100+C1", A), ("P150+C2", B)):
        print(n, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
