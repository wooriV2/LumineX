# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re, collections
spec = importlib.util.spec_from_file_location("g","gen2.py"); g = importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(io.StringIO()):
    spec.loader.exec_module(g)
MAT, S, ENG = g.MAT, g.S, g.ENG
IDX = {s[1]: i for i, s in enumerate(S)}

# ---------- 체형 ----------
WAIST_BODY = {
 "hgu":  ("아워글래스 USSBBW","A colossal heavy chest wider than her shoulders, directly below it a waistline that still pulls in sharply even at this size, then an enormous soft belly of massive rounded folds spilling out beneath it, her upper body filling the frame edge to edge."),
 "hgs":  ("아워글래스 SSBBW","A colossal heavy chest, a still-visible cinched waist, a big soft rounded belly below the waistline hanging heavily, very thick soft arms."),
 "musc": ("머슬 아워글래스 BBW","A thick soft layer over huge muscle, broad powerful shoulders, thick heavy arms with rounded biceps, a colossal soft chest, a cinched waist above a soft rounded belly, more soft than hard."),
 "uss":  ("USSBBW","A colossal rounded chest spilling wide past the shoulders, an enormous belly of massive rounded folds hanging low and heavy, no waist at all, upper arms so thick they are pushed out almost horizontally from her sides."),
 "colo": ("콜로설","A giantess on an even scale — massive rounded shoulders spanning more than four head-widths, huge thick arms, a colossal full chest, a broad heavy torso with a large smooth rounded belly, no single part standing out."),
 "p_hgu":("아워글래스 USSBBW 임산부","A colossal heavy chest wider than her shoulders, a waistline that pulls in sharply beneath it, then a vast, perfectly round pregnant belly dome swelling far out in front of her with heavy folds hanging beneath the dome. She is in the last weeks of pregnancy."),
 "p_uss":("USSBBW 임산부","A colossal rounded chest spilling wide past the shoulders and resting on a vast, perfectly round pregnant belly dome, several massive folds of heavy flesh hanging beneath the dome, no waist at all. She is in the last weeks of pregnancy."),
 "p_colo":("콜로설 임산부","A giantess on an even scale in the last weeks of pregnancy — massive rounded shoulders, a colossal full chest, a vast, perfectly smooth pregnant belly dome swollen to the same immense scale as everything else."),
}
HIP_BODY = {
 "hipq": ("힙 퀸","Her waist cinched to an impossible minimum, making the contrast with the enormous rear utterly extreme: the rear and hips flare to more than four times the width of that narrow waist, an enormous rounded rear projecting far out behind her and merging into the lower back and thighs as one continuous mass, a moderate chest, slim shoulders, the thighs disappearing out of the bottom of the frame."),
 "uss":  ("USSBBW","A colossal rounded chest, an enormous belly of massive rounded folds hanging low and heavy, no waist at all, colossal wide hips flaring beyond the chest and massive thick thighs disappearing out of the bottom of the frame."),
 "hgu":  ("아워글래스 USSBBW","A colossal heavy chest wider than her shoulders, a waistline that still pulls in sharply, then an enormous belly and colossal wide hips flaring out again, thick thighs disappearing out of the bottom of the frame."),
 "tent": ("텐트폴 USSBBW","A giant hourglass frame flaring at both ends — shoulders more than four times a normal woman's width, a colossal chest projecting past them, a big round belly, no waist at all, hips as broad as the shoulders, thick thighs disappearing out of the bottom of the frame."),
 "hgs":  ("아워글래스 SSBBW","A colossal heavy chest, a cinched waist above a big soft rounded belly and enormous round hips, thick soft thighs disappearing out of the bottom of the frame."),
 "p_uss":("USSBBW 임산부","A colossal rounded chest resting on a vast, perfectly round pregnant belly dome, several massive folds of heavy flesh beneath it, no waist at all, colossal wide hips, thick thighs disappearing out of the bottom of the frame. She is in the last weeks of pregnancy."),
 "p_hgu":("아워글래스 USSBBW 임산부","A colossal heavy chest wider than her shoulders, a waistline that pulls in sharply beneath it, then a vast, perfectly round pregnant belly dome, colossal wide hips, thick thighs disappearing out of the bottom of the frame. She is in the last weeks of pregnancy."),
 "p_tent":("텐트폴 USSBBW 임산부","A giant hourglass frame flaring at the shoulders, a colossal chest projecting past them, a vast, perfectly round pregnant belly dome, hips as broad as the shoulders, thick thighs disappearing out of the bottom of the frame. She is in the last weeks of pregnancy."),
}

# ---------- 허리 10 ----------
WAIST = [
 # (스타일, 체형, 재질L, 재질R, 얼굴 피어싱)
 ("로리타 갸루","hgu","sapphire","rosequartz","A thick silver septum ring hangs below the nose; a big silver hoop passes through the lower lip's edge; on each ear a big silver hoop and one stretched gold-rimmed ear plug."),
 ("아마갸루","hgs","rosepink","aquamarine","A small silver heart stud sits in the left nostril; on each ear a big pastel-enamel hoop (pink on the left, lilac on the right) and a small silver heart stud in the upper ear."),
 ("걸크러시","musc","smoky","amber","A thick silver septum ring hangs below the nose; two thick silver bars run through the outer end of the left eyebrow, well clear of the eye; on each ear a big silver hoop and a thick silver bar."),
 ("뱀파이어 다크","uss","ruby","alabaster","A thick black-steel bar runs through the outer end of the left eyebrow, clear of the eye; a small black-steel ring sits at the left corner of the lower lip; on each ear a thick black-steel bar and a pointed silver spike stud."),
 ("홍콩풍","hgu","cobalt","citrine","A small gold stud sits in the left nostril; a large vintage pearl clip-style earring on each ear."),
 ("락혼 글램(태국)","colo","emerald","carnelian","A thin gold ring passes through the left nostril; a small gold labret stud sits beneath the lower lip; on each ear a big gold hoop with a chased-gold drop."),
 ("파케앙트 글램(필리핀)","p_hgu","amethyst","amber","A small gold stud sits in the left nostril; a thin gold ring runs through the outer end of the left eyebrow; on each ear a big gold hoop with a pearl."),
 ("하베샤 화장(에티오피아·에리트레아)","hgs","jade","murano","A silver ring passes through the left nostril; on each ear a big silver filigree hoop and a small silver stud in the upper ear."),
 ("슬라브 글램(러시아·동유럽)","p_uss","glacial","egglass","A thin silver ring passes through the left nostril; a small silver bar runs through the outer end of the left eyebrow; on each ear a big silver hoop with a filigree silver drop."),
 ("프렌치 레드립(프랑스)","p_colo","resin","sapphire","A single thick gold hoop on each ear, nothing else."),
]

# ---------- 힙 10 ----------
# (스타일, 체형, L, R, 얼굴 피어싱, 배꼽 서술 또는 None)
HIP = [
 ("야마바","hipq","ice","amethyst","A big neon-acrylic hoop and a small silver star stud on each ear.",
  "a neon-acrylic star dangling from a silver barbell"),
 ("반바","uss","opal","emerald","Two big multicolour acrylic hoops on each ear.",
  "a multicolour acrylic ring hanging from a silver barbell"),
 ("데코라","hgu","murano","cobalt","On each ear a large primary-colour acrylic ring; a small star-shaped acrylic stud sits in the left nostril.",
  "a primary-colour acrylic star drop on a silver barbell"),
 ("히메갸루","tent","rosequartz","egglass","On each ear a big gold hoop with a small pearl drop and a small gold ribbon-shaped stud in the upper ear; a thin gold ring passes through the left nostril.",
  "a pearl drop on a gold barbell"),
 ("아게하","hipq","carnelian","aquamarine","On each ear a large gold chandelier-shaped hoop; a small gold stud sits in the left nostril; a gold hoop passes through the lower lip's edge.",
  "a gold chain ending in a small gold ball"),
 ("코갸루","p_uss","amber","glacial","A thick silver septum ring hangs below the nose; a big silver hoop passes through the lower lip's edge; on each ear a big silver hoop and one turquoise-enamel ring.",
  None),
 ("비주얼계","hgu","alabaster","ruby","A thick black-steel septum ring hangs below the nose; a thick black-steel bar runs through the outer end of the left eyebrow, clear of the eye; on each ear a big black-steel hoop.",
  "a black-steel barbell with a small silver spike hanging from it"),
 ("요루바 신부 화장(나이지리아)","p_hgu","smoky","citrine","A thin gold ring passes through the left nostril; on each ear a big gold hoop with a red-enamel bead.",
  None),
 ("화환 화장(우크라이나)","p_tent","emerald","rosepink","A small silver bar runs through the outer end of the left eyebrow, clear of the eye; on each ear a big silver hoop with a red-enamel bead.",
  None),
 ("소피아 로렌풍(이탈리아)","hipq","ruby","jade","A small gold stud sits in the left nostril; on each ear a large pearl drop and a gold clip.",
  "a pearl drop on a gold barbell"),
]
assert len(WAIST) == 10 and len(HIP) == 10

WHITISH = {"alabaster","moonstone","opal","frosted","seaglass","rosequartz","resin","ice","glacial"}
for lst in (WAIST, HIP):
    for row in lst:
        a, b = row[2], row[3]
        assert a != b and not ({"ice","glacial"} <= {a,b}) and not ({"moonstone","opal"} <= {a,b})
        assert not (a in WHITISH and b in WHITISH), row

def face_of(name):
    i = IDX[name]
    cat, nm, nat, face, _ = S[i]
    nat = "Japanese" if i < 13 else nat
    return nat, ENG[i], face

def build_waist(row):
    name, bk, a, b, pierce = row
    nat, mk, face = face_of(name)
    bname, btext = WAIST_BODY[bk]
    an, adesc, ainner = MAT[a]; bn, bdesc, binner = MAT[b]
    p = f"""Professional fashion photograph, upper-body shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head down to the middle of her belly, the frame cutting off across the belly so no hips, legs or feet are visible. Her face sits large and sharp in the upper part of the frame. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {face}. Real jewelry: {pierce} All jewelry is opaque metal, pearl, enamel or acrylic. Her whole face, ears and neck are real living flesh with real pores and fine skin grain — a photograph of a real face, not an illustration.

Physique: {btext}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest and belly): solid {adesc}, with {ainner}. Right half: solid {bdesc}, with {binner}. Each is carved as one solid sculpted mass like a statue, never hollow, the chest two great rounded masses with the grooves and belly folds cut into the material itself. The arms flow into the torso with no seam, and every wrist, palm, finger and knuckle is the same material as its arm, with no skin texture on any hand.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the chest and belly and out of the bottom of the frame where the two materials meet, never horizontal. Shards interlock along the lines only, every edge solid all the way through.

Pose: body angled 45 degrees, her left hand (solid material) held low at the frame edge beside her belly, her right hand (solid material) held at chest height clear of her body, well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal light on her face only; a strong backlight through each half so both sides glow from within; a thin cool rim light along the centre line. 2:3 vertical 8K portrait."""
    return name, bname, an, bn, p

def build_hip(row):
    name, bk, a, b, pierce, navel = row
    nat, mk, face = face_of(name)
    bname, btext = HIP_BODY[bk]
    an, adesc, ainner = MAT[a]; bn, bdesc, binner = MAT[b]
    navel_line = ""
    if navel:
        navel_line = f" In the carved hollow of her navel hangs a real jewel — {navel} — through a clean drilled opening in the material, staying bright real opaque metal and never turning transparent; the centre line passes beside it."
    p = f"""Professional fashion photograph, three-quarter body shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head down through the hips, the frame cutting off across the upper thighs so no knees, lower legs or feet are visible. Her face sits large and sharp in the upper part of the frame. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {face}. Real jewelry: {pierce} All jewelry is opaque metal, pearl, enamel or acrylic. Her whole face, ears and neck are real living flesh with real pores and fine skin grain — a photograph of a real face, not an illustration.

Physique: {btext}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest, belly, hip and upper thigh): solid {adesc}, with {ainner}. Right half: solid {bdesc}, with {binner}. Each is carved as one solid sculpted mass like a statue, never hollow, the chest, belly folds and hip creases cut into the material itself as grooves. The arms flow into the torso and the torso into the thighs with no seam, and every wrist, palm, finger and knuckle is the same material as its arm, with no skin texture on any hand.{navel_line}

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the chest, belly and between the hips and thighs and out of the bottom of the frame where the two materials meet, never horizontal. Shards interlock along the lines only, every edge solid all the way through.

Pose: body angled 45 degrees, her left hand (solid material) resting on her flared hip, her right hand (solid material) held clear of her body at hip height, well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal light on her face only; a strong backlight through each half so both sides glow from within; a thin cool rim light along the centre line. 2:3 vertical 8K portrait."""
    return name, bname, an, bn, p

W = [build_waist(r) for r in WAIST]
H = [build_hip(r) for r in HIP]

for label, lst in (("허리", W), ("힙", H)):
    wc = [len(x[4].split()) for x in lst]
    print(label, "단어수", min(wc), sum(wc)//len(wc), max(wc))
    for x in lst:
        if re.search(r'[\uac00-\ud7a3]', x[4]): print("KOREAN LEAK", x[0])
mc = collections.Counter()
for r in WAIST+HIP:
    mc[r[2]] += 1; mc[r[3]] += 1
print({MAT[k][0]:v for k,v in sorted(mc.items(), key=lambda x:-x[1])})
