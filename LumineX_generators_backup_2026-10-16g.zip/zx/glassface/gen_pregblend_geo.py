# -*- coding: utf-8 -*-
import re, sys, random, json
from collections import Counter
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
_top = open('gen_preg_geo_test.py', encoding='utf-8').read().split("\nDUP = re.compile")[0]
exec(_top)      # person_preg, build_new, STABLE_BODIES, make_structure, validate, ... (시험 때 검증된 문장 구조 그대로)
rnd.seed(20261012)
HAIRW = re.compile(r'\b(hair|braid|braids|braided|bun|ponytail|twin|bangs|fringe|locs|afro|bob|updo|curls|waves|ringlets|pigtails)\b', re.I)
CLAUSES = sorted({c.strip() for m in T.MAKEUP_48 for c in face(m)[1].split(',') if HAIRW.search(c)}, key=len, reverse=True)
DUP = re.compile(r"\b(\w+) \1\b")
TN={1:"solo",2:"duo",3:"trio"}; TY={1:"Solo",2:"Duo",3:"Trio"}; TKO={1:"솔로",2:"듀오",3:"트리오"}
CAT = "🤰 Living Artifact · Pregnant Blend Formula"
presets=[]
for mixn in [3,4]:
    for gs in [1,2,3]:
        for slot in range(1,31):
            key=f"la_pregblend{mixn}_{TN[gs]}_{slot:02d}"
            mk = rnd.sample(T.MAKEUP_48, gs)
            p, desc = build_new(gs, mixn, mk)
            validate(key, p)
            assert not re.search(r'(?<!corset-)\blace\b(?!-up)', p.lower())
            assert not [m.group(0) for m in DUP.finditer(p) if m.group(1).lower() not in ("had","that")], key
            assert "diagonally and asymmetrically" not in p and "never left bare" in p and "circling a globe" in p
            assert not any(c in p for c in CLAUSES), key
            structs = re.findall(r"\[([^/]+?) / ", desc)
            presets.append({"key":key,"category":CAT,"title":f"Pregnant Blend {mixn}-Mix {TY[gs]} #{slot:02d} ({' / '.join(structs)})","prompt":p,
                "meta":{"group_size":gs,"aspect_ratio":(ASPECT[gs]),"format":"fused-blend","mix_count":mixn,"layout":"geometry-hazy-v1","structures":structs}})
assert len(presets)==180 and len({x["key"] for x in presets})==180
json.dump(presets, open("la_pregblend_geo_180_bundle.json","w",encoding="utf-8"), ensure_ascii=False, indent=2)
print("생성:", len(presets), "개 (신규 키)")
for mixn in [3,4]:
    for g in [1,2,3]:
        ws=[len(x["prompt"].split()) for x in presets if x["meta"]["mix_count"]==mixn and x["meta"]["group_size"]==g]
        print(f"  {mixn}혼합 {TKO[g]}: {min(ws)}~{max(ws)}단어")
st = Counter(s for x in presets for s in x["meta"]["structures"])
print("인물", sum(st.values()), "명 | 구조×경계선:", dict(sorted(st.items())))
sent=[m for x in presets for m in re.findall(r"Her figure is divided into [^.]*\.", x["prompt"])]
print(f"구조 문장 {len(sent)}개 중 서로 다른 문장 {len(set(sent))}개 ({len(set(sent))/len(sent):.0%})")
bodies = Counter(b for x in presets for b in re.findall(r"임산부\w+", json.dumps(x["meta"], ensure_ascii=False)))
