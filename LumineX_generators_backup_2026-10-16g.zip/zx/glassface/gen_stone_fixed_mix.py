# -*- coding: utf-8 -*-
import re, random
banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","safety pin","gash","crack"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    hits = [w for w in banned if w in p.lower()]
    assert not hits, (name,hits)

STONE_VARIANTS = {
 "marble": "solid polished white marble fused directly into her own form, natural grey-gold veining flowing to follow every curve, BLAZING pale marble surface with VIVID golden vein striations",
 "granite": "solid polished black granite fused directly into her own form, fine natural speckled texture flowing to follow every curve, BLAZING deep charcoal-black granite surface with VIVID silver mineral fleck detail",
 "rose_stone": "solid polished rose-quartz stone fused directly into her own form, soft natural veining flowing to follow every curve, BLAZING soft pink stone surface with VIVID white vein striations",
 "jade_stone": "solid polished jade-green stone fused directly into her own form, natural cloudy veining flowing to follow every curve, BLAZING deep jade-green stone surface with VIVID pale-green vein striations",
}
OTHER_POOL = {
 "irezumi": "traditional irezumi tattoo ink, bold black ink outlines, BLAZING CRIMSON koi sakura spiral formations, VIVID PINK petal cascade, extreme high-gloss oil finish",
 "uvneon": "UV-reactive neon bodypaint, invisible under standard light but BLAZING ELECTRIC VIOLET geometric lattice facets glowing under her own dedicated UV blacklight, VIVID CYAN refraction detail",
 "glass": "solid thick stained glass fused to her form, hundreds of small individual panes, BLAZING ELECTRIC EMERALD and VIVID GOLD panes alternating, dark lead-line seams",
 "goldleaf": "applied rose-gold leaf, thin irregular metallic sheets with fine natural creases and overlapping seams, VIVID CYAN undertone glinting through",
 "botanical": "living orchid blooms growing directly from her own skin, every petal standing in three-dimensional relief, BLAZING VIOLET blossoms, VIVID GOLD leaves and tendrils",
 "crystal": "sapphire crystal clusters growing directly out of her own skin, erupting in true three-dimensional relief, BLAZING SAPPHIRE BLUE crystal points, VIVID SILVER mineral veins",
 "scale_dragon": "dragon scales (large thick armor-plate scales, each sharply faceted), BLAZING CRIMSON scale formations, VIVID EMBER scale-edge detail",
 "scale_koi": "koi-fish scales (rounded smooth scales with fine growth rings), BLAZING ELECTRIC CRIMSON scale formations, VIVID PEARL-WHITE scale-edge detail",
 "obsidian": "polished obsidian stone fused directly to her own form, solid glossy black stone, with molten gold seams running between fitted stone sections",
 "wax": "molten wax flowing and set directly over her own skin, BLAZING DEEP CRIMSON wax streams pooling and hardening, VIVID AMBER translucent drip-ridges",
}
MAT_KO = {"marble":"대리석","granite":"화강암","rose_stone":"로즈쿼츠석","jade_stone":"비취석",
 "irezumi":"이레즈미","uvneon":"UV네온","glass":"스테인드글라스","goldleaf":"금박","botanical":"보태니컬",
 "crystal":"크리스탈","scale_dragon":"드래곤비늘","scale_koi":"코이비늘","obsidian":"흑요암금","wax":"왁스"}

ALLMAT = {**STONE_VARIANTS, **OTHER_POOL}
OTHERKEYS = list(OTHER_POOL.keys())

PHYSIQUES = [
 ("super hourglass", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum beyond any proportion, most dramatic hourglass ratio ever recorded on any human body, thighs so thick pressing together"),
 ("wide hip narrow", "hips so impossibly wide extending beyond frame creating the most extreme hip-to-waist ratio ever, waist cinched to absolute impossible minimum, upper body slim emphasizing the dramatic hip explosion"),
 ("BBW bombshell", "most massive full-figure BBW body ever at absolute maximum in every dimension, hips so wide beyond proportion dominating the entire frame, bust so enormous overwhelming gravity, waist deeply snatched despite impossible volume"),
]
HAIRS = ["long sleek jet-black hair cascading past hips","silver-white natural hair swept into a high sculpted crown","loose beach waves mid-length tousled"]
POSES = ["strong hip pop right, both hands pressing sides of hips outward simultaneously arching back to extreme",
 "full frontal wide stance, both fists pressing outer hips outward to absolute maximum",
 "standing full height, both arms slightly spread commanding the frame"]
AGES = ["early 30s","mid 40s","late 20s"]

def person_nmix(idx, label, mats, uv_included):
    phy_name, phy_detail = PHYSIQUES[idx % 3]
    age = AGES[idx % 3]; hair = HAIRS[idx % 3]; pose = POSES[idx % 3]
    n = len(mats)
    texts = [ALLMAT[m] for m in mats]
    prefix = f"{label}: " if label else ""
    if n == 2:
        zones = f"her LEFT side is dominated by {texts[0]}. Her RIGHT side is dominated by {texts[1]}. Rather than a sharp boundary, the two materials interweave and overlap gradually across a soft irregular zone a few inches wide down the centre of her body, elements of each scattered into the other's territory, density fading rather than stopping abruptly"
    else:
        zone_sent = " ".join(f"{texts[i]} dominates zone {i+1}." for i in range(n))
        zones = f"her body carries {n} different materials at once, each claiming roughly an equal irregular organic share of her body rather than any straight line, zones arranged diagonally and asymmetrically. {zone_sent} Wherever any two zones meet, the boundary is soft, diagonal or curving rather than a straight line, the materials interweaving and overlapping gradually across an irregular blended border a few inches wide"
    extra_light = ""
    if uv_included:
        extra_light = " A standard hard key light illuminates most of her body; a separate dedicated UV blacklight illuminates the UV-reactive zone specifically."
    return (f"{prefix}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {hair} — {zones}, no fabric no seam no garment anywhere, every material fused to or erupting from her own living skin, covering her completely with no bare skin anywhere from neck to ankle. Pose: {pose} — most extreme {phy_name} silhouette ever displayed.{extra_light}\n"
            f"{prefix}extreme platform heels/boots blending the relevant materials at her feet, extra long nails each matching whichever zone that hand falls in.")

NUM_WORD = {1:"ONE",2:"TWO",3:"THREE"}
ASPECT = {1:"2:3",2:"3:4",3:"4:5"}
LABELS3 = ["#1","#2","#3"]

def build(gsize, mats_per_person, seed_base):
    labels = LABELS3[:gsize] if gsize>1 else [None]
    any_uv = any("uvneon" in m for m in mats_per_person)
    blocks = [person_nmix(seed_base+i, labels[i], mats_per_person[i], "uvneon" in mats_per_person[i]) for i in range(gsize)]
    body = "\n\n".join(blocks)
    if gsize == 1:
        tail = "MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. ONE woman only. Extreme macro detail on every material and every blended transition. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
    else:
        tail = f"Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.\nAll: Extreme macro detail on every material and every blended transition. CRITICAL: all {gsize} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere. {NUM_WORD[gsize]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame."
    p = f"""Professional fashion photograph, full body shot. {NUM_WORD[gsize]} wom{"a" if gsize==1 else "e"}n standing{" side by side, each with her own multi-material blended body" if gsize>1 else ""}.

{body}

{tail} 8K portrait {ASPECT[gsize]} aspect ratio."""
    return p

rnd = random.Random(13579)
GNAME = {1:"솔로",2:"듀오",3:"트리오"}
OUT = []
seed = 0
for mixn in [2,3,4]:
    for gsize in [1,2,3]:
        mats_per_person = []
        for i in range(gsize):
            stone_pick = rnd.choice(list(STONE_VARIANTS.keys()))
            others = rnd.sample(OTHERKEYS, mixn-1)
            mats = [stone_pick] + others
            rnd.shuffle(mats)
            mats_per_person.append(mats)
        p = build(gsize, mats_per_person, seed)
        seed += gsize
        check(f"sfix_{mixn}_{gsize}", p)
        desc = " / ".join("+".join(MAT_KO[m] for m in mats) for mats in mats_per_person)
        OUT.append((f"{mixn}개혼합(석재고정) {GNAME[gsize]} — {desc}", p))

for label,p in OUT:
    print(label, len(p.split()))

L = ["# LumineX · 석재 고정+나머지 랜덤(목재 제외) 2/3/4개 혼합 — 솔로·듀오·트리오 각 1개\n"]
for label,p in OUT:
    L.append(f"## {label}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_StoneFixed_RandomMix_9.md","w",encoding="utf-8").write("\n".join(L))
print("saved", len(OUT))
