# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_pierce_statue.py', encoding='utf-8').read().split("\nspecs = [")[0])
WOODS.append(("wenge", "dark wenge wood, a deep near-black wood finely striped with narrow gold-tan pinstripes running through it, polished to a hard satin sheen, completely opaque"))   # idx 4
rnd.seed(20261203)
NWD = {2: "TWO", 3: "THREE"}; ASPG = {2: "3:4", 3: "4:5"}
CARE_G = "All jewelry is real metal, sitting in real, calm, healthy skin — no redness, no swelling, no irritation — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes."
def hair_of():
    si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC)+1); return f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}", ci, si
def pierce_for(P, method, ci):
    M = pick_metal(ci); F = rnd.choice(FORMS); G = rnd.choice(GEMS)
    t = conc_chest(P, M, F) if method == "집중형" else recolor({"P50": g18.T50, "P100": g18.T100}[P], M)
    return t + (DENS if P == "P100" else "") + (gem_text(G) if method == "집중형" else ""), M
REAL_SHORT = REAL_FACE.split("— ")[0].strip()
import ast
_tree = ast.parse(open("gen_blend_540.py", encoding="utf-8").read())
MAXPHYS = [ast.literal_eval(n.value) for n in _tree.body if isinstance(n, ast.Assign) and getattr(n.targets[0], "id", "") == "PHYS"][0]
MATKO2 = {"irezumi": "이레즈미", "glass": "스테인드글라스"}

def craft_text(c):
    cn, cd, cb, cf = CRAFT_DB_FULL[c]; return f"{cn} ({cd}), wide {cb} bands following the contours of the body, with {cf} filling the space between bands", cn

def stat_person(lab, frame, P, method, kind, key):
    pname, pos, part = FR[frame]
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); hair, ci, si = hair_of(); phys = rnd.choice(PHYS)
    pierce, M = pierce_for(P, method, ci); body, mname, transp = body_text(kind, key)
    tip = ("rounded off into its own smooth, deeply polished tip" if kind != "T2" else "sealed shut into its own smooth, rounded, closed tip")
    tipsent = f"{pos[0].upper()}{pos[1:]}, each thigh individually curves inward and {tip} — the two thighs stay clearly separate, never merging into a single base — nothing continues below either tip."
    mat = ("Her body below the collarbones is a transparent material that light passes through; her face, ears and neck stay opaque living flesh." if transp else "Her body below the collarbones is a completely opaque solid that no light passes through; her face, ears and neck are living flesh.")
    block = (f"{lab}: A strikingly beautiful adult {nat} woman — {fa}, {hair}. {REAL_SHORT}.\n{lab} Piercings: {pierce}\n{lab} Physique: {phys}\n{lab} Body: {body} {tipsent} {mat}")
    return block, f"[{FRKO[frame]}·{P} {method}·{mname}·메이크업 {mk}]", transp
def stat_group(frame, people):
    g = len(people); pname, pos, part = FR[frame]; blocks, descs = [], []
    for i, (P, method, kind, key) in enumerate(people):
        b, d, tr = stat_person(f"#{i+1}", frame, P, method, kind, key); blocks.append(b); descs.append(d)
    (ba, bb) = rnd.choice(BACKS)
    intro = (f"Professional fashion photograph, {pname}. {NWD[g]} women standing side by side, each angled 45 degrees toward the camera, framed so every woman's whole sculpted form is visible from the top of her head down to two individually rounded, deliberately carved tips {pos}, each face in natural scale with her body — never an oversized close-up crop. Where a sculpted form comes to an end at the {part}, it is because the sculpture itself ends there, not because a camera frame happens to cut her off. Generous spacing so every figure reads clearly, nobody's arms crossing a neighbour.")
    common = (f"All piercings: {CARE_G}\n\n{DEPTH}\n\nBoundary for each woman: a sharp jagged line runs around the base of her neck and across both collarbones — real skin above, material immediately below. At that line, the material's edge rises in a small raised step above her flesh, casting a crisp shadow — her skin beside it stays smooth and even. Each rounded tip is that material's own carved finish — never the edge of a photograph. Shards interlock along the collarbone line only.")
    setting = f"Setting: a huge backdrop behind them washed with two coloured lights from behind — {ba} on one side and {bb} on the other, blending into a smooth gradient in the middle, and a glossy dark floor beneath them."
    pose = "Pose: each stands tall, her left hand resting on her flared hip, her right arm held clear of her body with the hand relaxed at hip height, every hand well away from every face, heads tilted slightly toward the camera."
    light = ("Lighting: the glowing backdrop floods every transparent body from behind, tinting it, while the opaque bodies block it completely and are lit by two large softboxes raking from either side. A soft frontal light falls on all the faces and ears; a thin cool rim light traces every figure. Only each woman's face, ears and neck read as real skin. Shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. " + f"{ASPG[g]} aspect ratio, 8K.")
    return f"{intro}\n\n" + "\n\n".join(blocks) + f"\n\n{common}\n\n{setting}\n\n{pose}\n\n{light}", " ; ".join(descs)
BLACK = "THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky"
def crop_person(lab, track, P, method, bodykind):
    hair, ci, si = hair_of(); pierce, M = pierce_for(P, method, ci)
    if track == "일반":
        mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); subj = f"{lab}: A strikingly beautiful adult {nat} woman — {fa}, {hair}. {REAL_SHORT}."
        tg = f"메이크업 {mk}"
    else:
        pn, pd = rnd.choice(MAXPHYS); tg = f"체형 {pn}"; age = rnd.choice(AGES_MX); subj = f"{lab}: A striking adult woman — {BLACK}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair}. Real pores and fine skin grain on her skin, large eyes with bright real catchlights, a bold, commanding expression. {REAL_SHORT}."
    body = ""; bko = "얼굴만"
    if bodykind == "craft":
        ct, cn = craft_text(rnd.choice(T.CRAFTS_39)); bko = f"공예({cn})"
        body = f"\n{lab} Body: Below the collarbones her whole body is painted in one traditional pattern: {ct}, covering every inch of skin from the collarbones to the bottom of the frame, the pattern reading as one continuous second skin, nowhere left bare, no fabric no seam no garment anywhere."
    elif bodykind:
        mt = mat_text(bodykind)[0]; bko = MATKO2[bodykind]
        body = f"\n{lab} Body: Below the collarbones her whole body is fused with one material instead of ordinary skin: {mt}, covering every inch from the collarbones to the bottom of the frame, nowhere left bare, no fabric no seam no garment anywhere."
    return f"{subj}\n{lab} Piercings: {pierce}{body}", f"[{track}·{P} {method}·{bko}·{tg}]", track == "맥시"
def crop_group(frame, people):
    g = len(people); blocks, descs, anymax = [], [], False
    for i, (track, P, method, bk) in enumerate(people):
        b, d, mx = crop_person(f"#{i+1}", track, P, method, bk); blocks.append(b); descs.append(d); anymax |= mx
    if frame == "face":
        intro = f"Professional fashion photograph, close-up beauty portrait. {NWD[g]} women side by side, each facing the camera straight on in a perfectly frontal portrait, heads level, both ears of every woman clearly visible, framed tightly from the very top of their heads down to the base of their necks and the tops of their collarbones, the frame cutting off there. Every face is large and sharp. Mid 20s."
    else:
        intro = f"Professional fashion photograph, bust shot. {NWD[g]} women standing side by side, each facing the camera straight on, heads level, both ears of every woman clearly visible, framed from the very top of their heads to just below their chests, the frame cutting off beneath the chests. Every face sits large and sharp in the upper half of the frame, and every woman's ear pieces are oversized so they read clearly at this distance. Mid 20s."
    bg = "MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient." if anymax else "a plain seamless deep-charcoal backdrop, nothing else in frame."
    return (f"{intro}\n\n" + "\n\n".join(blocks) + f"\n\nAll piercings: {CARE_G}\n\n{DEPTH}\n\nPose: each woman faces the camera, arms relaxed at her sides, heads level. Generous spacing so every face reads clearly.\n\nLighting: {bg} A soft frontal light on all the faces and ears, so the makeup and the glints on every piece of metal read clearly; a thin cool rim light along the hair and shoulders. {ASPG[g]} aspect ratio, 8K."), " ; ".join(descs)
specs = [("재질 프레임 듀오 데미스탯", "stat", ("demi", [("P25","집중형","T1","aquamarine"), ("P50","정의형","stone",0)])),
         ("재질 프레임 듀오 쓰리쿼터", "stat", ("tq", [("P8","집중형","wood",4), ("P50","정의형","T2","lilyfield")])),
         ("재질 프레임 트리오 데미스탯", "stat", ("demi", [("P25","집중형","T1","aquamarine"), ("P25","집중형","wood",4), ("P50","정의형","T3",("cobalt","shards"))])),
         ("크롭 듀오 얼굴 컷", "crop", ("face", [("일반","P25","집중형",None), ("일반","P100","정의형",None)])),
         ("크롭 듀오 가슴 컷", "crop", ("chest", [("일반","P50","정의형","craft"), ("맥시","P50","정의형","irezumi")])),
         ("크롭 트리오 가슴 컷", "crop", ("chest", [("일반","P25","집중형","craft"), ("일반","P50","정의형","irezumi"), ("맥시","P100","정의형","glass")]))]
items = []
for name, kind, (frame, people) in specs:
    p, d = (stat_group if kind == "stat" else crop_group)(frame, people)
    p = dd(p).replace(",,", ",").replace(".,", ",")
    _d = [x.group(0) for x in re.finditer(r"\b(\w+) \1\b", p)]
    assert not re.search(r"[가-힣]", p) and not _d, (name, _d)
    items.append((name, d, p))
rr = random.Random(141); order = list(range(6)); rr.shuffle(order); no = {i: order.index(i)+1 for i in range(6)}; ranked = sorted(range(6), key=lambda i: no[i])
L = ["# LumineX · 듀오·트리오 피어싱 시험 — 재질 프레임 3개 + 실사 크롭 3개\n",
     "지금까지 피어싱 시험은 전부 솔로였습니다. 여러 명이 한 화면에 있을 때 **피어싱과 재질 구조가 유지되는지** 확인합니다. **재질 프레임 3개**(데미스탯 듀오·쓰리쿼터 듀오·데미스탯 트리오, 인물마다 재질 종류가 다름)와 **실사 크롭 3개**(얼굴 컷 듀오·가슴 컷 듀오·가슴 컷 트리오, 일반 실사와 맥시멀리스트 혼합)입니다. 길이를 줄이려고 피어싱 깊이·안전 문구·경계·배경·조명은 공통으로 한 번만 썼고 인물별 문단만 따로 있습니다. 번호는 섞여 있습니다.\n",
     "**알려주실 것**: 번호마다 **성공/실패**. 실패하면 이유를 한마디(**인원이 안 맞음 / 인물이 합쳐짐 / 피어싱 묻힘 / 재질 구조가 무너짐 / 생성 안 됨**). 최대 3회. 예: `1: 성공 / 3: 실패(인원이 안 맞음) / 5: 2회`\n",
     "## 색인\n", "| 번호 | 구분 | 구성 (인물별) |", "|---|---|---|"]
for i in ranked: name, d, p = items[i]; L.append(f"| {no[i]:02d} | {name} | {d} |")
L.append("")
for i in ranked: name, d, p = items[i]; L += [f"## {no[i]:02d}. {name}\n", "```", p, "```\n"]
open("/mnt/user-data/outputs/LumineX_Pierce_Group_Round1.md", "w", encoding="utf-8").write("\n".join(L))
print("6개 저장")
for i in ranked: name, d, p = items[i]; print(f"  {no[i]:02d} {name:<18} {len(p.split()):>4}단어 | {d[:80]}")
