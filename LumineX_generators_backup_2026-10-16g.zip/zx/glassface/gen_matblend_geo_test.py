# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
_top = open('gen_group_test.py', encoding='utf-8').read().split("\nitems=[]")[0]
exec(_top)      # hazy2, CELLS, draw_cells, make_structure, STRUCT_KIND/KO, sens_count, validate, pick_mats, mat_text, PHYS, HAIRS_MX, AGES_MX, POSES_MX, MAT_KO ...
rnd.seed(20261008)

def pick_mats_nosw(n):
    while True:
        m = pick_mats(n)
        if not ({"stone","wood"} <= set(m)): return m          # 석재+목재 동시 포함은 미검증이라 이번 테스트에서 제외

def hazy_mat(shape, kind):
    return hazy2(shape, kind).replace("patterns","materials").replace("motifs","elements").replace("one pattern","one material")

def mat_person(label, n, kind, shape, phys, hair, age, pose):
    mats = pick_mats_nosw(n); texts = [mat_text(m)[0] for m in mats]
    pre, reg, lab = make_structure(kind, n, shape); assert sens_count(pre+" "+" ".join(reg)) == 0
    sents = " ".join(f"Region {i+1} is {reg[i]}: it carries {texts[i]}." for i in range(n))
    uv = "uvneon" in mats
    light = " A standard hard key light illuminates most of her body; a separate dedicated UV blacklight illuminates the UV-reactive region specifically, making it glow at full intensity while the rest reads under normal light." if uv else ""
    pn, pd = phys; prefix = f"{label}: " if label else ""
    txt = (f"{prefix}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair} — her body carries {n} different materials at once, each claiming its own region of her figure. {pre} {sents} {hazy_mat(shape, STRUCT_KIND[kind])}, no fabric no seam no garment anywhere, every material fused to or erupting from her own living skin, covering her completely with no bare skin anywhere from neck to ankle. Pose: {pose}, every region clearly visible to the camera — most extreme {pn} silhouette ever displayed.{light}\n"
           f"{prefix}extreme platform heels/boots blending the relevant materials at her feet, extra long nails each matching whichever region that hand falls in.")
    return txt, f"{STRUCT_KO[kind]}·{'물결' if shape=='undulating' else '매끈'}", "+".join(MAT_KO[m] for m in mats), pn

def build_mat(gsize, n):
    phys = rnd.sample(PHYS, gsize); hairs = rnd.sample(HAIRS_MX, gsize); ages = rnd.sample(AGES_MX, gsize); cells = draw_cells(gsize)
    blocks=[]; descs=[]
    for i in range(gsize):
        b, st, ms, pn = mat_person(["#1","#2","#3"][i] if gsize>1 else None, n, cells[i][0], cells[i][1], phys[i], hairs[i], ages[i], rnd.choice(POSES_MX))
        blocks.append(b); descs.append(f"{st} / {ms} / {pn}")
    body = "\n\n".join(blocks)
    if gsize == 1:
        tail = "MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. ONE woman only. Extreme macro detail on every material and every blended transition. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
    else:
        tail = (f"Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.\nAll: Extreme macro detail on every material and every blended transition. CRITICAL: all {gsize} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere. {NW[gsize]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame.")
    p = (f"Professional fashion photograph, full body shot. {NW[gsize]} wom{'a' if gsize==1 else 'e'}n standing{' side by side, each with her own multi-material blended body' if gsize>1 else ''}.\n\n{body}\n\n{tail} 8K portrait {ASP[gsize]} aspect ratio.")
    return p, descs

items=[]
for gsize, n in [(1,3),(1,4),(1,3),(2,3),(2,4),(2,4),(3,3),(3,3),(3,4)]:
    p, descs = build_mat(gsize, n); validate(f"mg_{gsize}_{n}", p)
    items.append(("새 방식", gsize, n, " ; ".join(f"[{d}]" for d in descs), p))

bundle = {x["key"]: x for x in json.load(open("la_blend_540_bundle.json", encoding="utf-8"))}
def reg(mixn, tn, gsize):
    while True:
        key = f"la_matblend{mixn}_{tn}_{rnd.randrange(1,31):02d}"; x = bundle[key]
        if all(len(ms)==mixn for ms in x["meta"]["materials"]): break
    ms = " ; ".join("+".join(MAT_KO[m] for m in mm) for mm in x["meta"]["materials"])
    return ("등록분", gsize, mixn, f"{key} — {ms}", x["prompt"])
items += [reg(4,"solo",1), reg(3,"duo",2), reg(4,"trio",3)]
assert len(items)==12

order=list(range(12)); rnd.shuffle(order); no={i:order.index(i)+1 for i in range(12)}; ranked=sorted(range(12), key=lambda i:no[i])
GN={1:"솔로",2:"듀오",3:"트리오"}
L=["# LumineX · 재질 블렌드 새 방식 확인 12개 (재질 쪽 3·4혼합)\n",
   "새 방식 9개(솔로 3·듀오 3·트리오 3)와 이미 등록된 Material Blend 프리셋 3개(대조군)를 섞어 번호를 붙였습니다. **성공/실패만** 알려주세요(최대 3회, 1회/2회/3회/실패). 예: `03: 2회 / 07: 실패 / 나머지 1회`\n",
   "## 색인\n","| 번호 | 구분 | 인원 | 구역 수 | 구성 (구조·경계선 / 재질 / 체형) |","|---|---|---|---|---|"]
for i in ranked:
    g,gs,n,desc,p = items[i]; L.append(f"| {no[i]:02d} | {g} | {GN[gs]} | {n} | {desc} |")
L.append("")
for i in ranked:
    g,gs,n,desc,p = items[i]; L.append(f"## {no[i]:02d}. {g} · {GN[gs]} {n}구역\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_MaterialBlend_Geo_Test_12.md","w",encoding="utf-8").write("\n".join(L))
json.dump([{"no":no[i],"kind":items[i][0],"gsize":items[i][1],"n":items[i][2],"desc":items[i][3]} for i in ranked], open("/home/claude/mat_test_meta.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
print("12개 저장")
for gs in [1,2,3]:
    nw=[len(it[4].split()) for it in items if it[0]=="새 방식" and it[1]==gs]; rg=[len(it[4].split()) for it in items if it[0]=="등록분" and it[1]==gs]
    print(f"  {GN[gs]}: 새 방식 {nw} / 등록분 {rg}")
print("대조군:", [(no[i], items[i][3].split(' — ')[0]) for i in ranked if items[i][0]=='등록분'])
print("UV 포함 새 방식 번호:", [no[i] for i in ranked if items[i][0]=='새 방식' and 'UV네온' in items[i][3]])
print("새 방식 구성 샘플:")
for i in ranked:
    if items[i][0]=="새 방식": print(f"  {no[i]:02d} {GN[items[i][1]]}{items[i][2]}구역", items[i][3][:150])
