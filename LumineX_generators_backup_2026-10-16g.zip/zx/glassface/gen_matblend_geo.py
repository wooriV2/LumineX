# -*- coding: utf-8 -*-
import re, sys, random, json
from collections import Counter
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
_top = open('gen_matblend_geo_test.py', encoding='utf-8').read().split("\nitems=[]")[0]
exec(_top)      # pick_mats_nosw, hazy_mat, make_structure, draw_cells, mat_text, MAT_KO, validate, sens_count, PHYS ...
rnd.seed(20261009)
def pct(lo, hi, step=1): return rnd.randrange(lo, hi+1, step)       # 위치 숫자 1% 단위

def mat_person_k(label, n, kind, shape, phys, hair, age, pose):
    mats = pick_mats_nosw(n); texts = [mat_text(m)[0] for m in mats]
    pre, reg, lab = make_structure(kind, n, shape); assert sens_count(pre+" "+" ".join(reg)) == 0
    sents = " ".join(f"Region {i+1} is {reg[i]}: it carries {texts[i]}." for i in range(n))
    uv = "uvneon" in mats
    light = " A standard hard key light illuminates most of her body; a separate dedicated UV blacklight illuminates the UV-reactive region specifically, making it glow at full intensity while the rest reads under normal light." if uv else ""
    pn, pd = phys; prefix = f"{label}: " if label else ""
    txt = (f"{prefix}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair} — her body carries {n} different materials at once, each claiming its own region of her figure. {pre} {sents} {hazy_mat(shape, STRUCT_KIND[kind])}, no fabric no seam no garment anywhere, every material fused to or erupting from her own living skin, covering her completely with no bare skin anywhere from neck to ankle. Pose: {pose}, every region clearly visible to the camera — most extreme {pn} silhouette ever displayed.{light}\n"
           f"{prefix}extreme platform heels/boots blending the relevant materials at her feet, extra long nails each matching whichever region that hand falls in.")
    return txt, f"{STRUCT_KO[kind]}·{'물결' if shape=='undulating' else '매끈'}", mats

def build_A(gsize, n):
    phys = rnd.sample(PHYS, gsize); hairs = rnd.sample(HAIRS_MX, gsize); ages = rnd.sample(AGES_MX, gsize); cells = draw_cells(gsize)
    blocks=[]; descs=[]; allm=[]
    for i in range(gsize):
        b, st, mats = mat_person_k(["#1","#2","#3"][i] if gsize>1 else None, n, cells[i][0], cells[i][1], phys[i], hairs[i], ages[i], rnd.choice(POSES_MX))
        blocks.append(b); descs.append(st); allm.append(mats)
    body = "\n\n".join(blocks)
    if gsize == 1:
        tail = "MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. ONE woman only. Extreme macro detail on every material and every blended transition. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
    else:
        tail = (f"Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.\nAll: Extreme macro detail on every material and every blended transition. CRITICAL: all {gsize} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere. {NW[gsize]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame.")
    p = (f"Professional fashion photograph, full body shot. {NW[gsize]} wom{'a' if gsize==1 else 'e'}n standing{' side by side, each with her own multi-material blended body' if gsize>1 else ''}.\n\n{body}\n\n{tail} 8K portrait {ASP[gsize]} aspect ratio.")
    return p, descs, allm

old = {x["key"]: x for x in json.load(open("la_blend_540_bundle.json", encoding="utf-8"))}
TN={1:"solo",2:"duo",3:"trio"}; TY={1:"Solo",2:"Duo",3:"Trio"}; CAT="🏺 Living Artifact · Material Blend Formula"
presets=[]
for mixn in [3,4]:
    for gs in [1,2,3]:
        for slot in range(1,31):
            key=f"la_matblend{mixn}_{TN[gs]}_{slot:02d}"; assert key in old, key
            p, descs, allm = build_A(gs, mixn); validate(key, p)
            assert "diagonally and asymmetrically" not in p and "never left bare" in p
            assert all(not ({"stone","wood"} <= set(ms)) for ms in allm)
            assert ("dedicated UV blacklight" in p) == any("uvneon" in ms for ms in allm)
            mats_ko = " / ".join("+".join(MAT_KO[m] for m in ms) for ms in allm)
            presets.append({"key":key,"category":CAT,"title":f"Material Blend {mixn}-Mix {TY[gs]} #{slot:02d} ({' / '.join(descs)} | {mats_ko})",
                "prompt":p,"meta":{"group_size":gs,"aspect_ratio":ASP[gs],"format":"material-blend","mix_count":mixn,"layout":"geometry-hazy-v1","structures":descs,"materials":allm}})
assert len(presets)==180 and len({x["key"] for x in presets})==180
json.dump(presets, open("la_matblend_geo_180_bundle.json","w",encoding="utf-8"), ensure_ascii=False, indent=2)

print("생성:", len(presets), "개 | 기존 키와 전부 일치(덮어쓰기)")
for mixn in [3,4]:
    for g in [1,2,3]:
        ws=[len(x["prompt"].split()) for x in presets if x["meta"]["mix_count"]==mixn and x["meta"]["group_size"]==g]
        ow=[len(old[x["key"]]["prompt"].split()) for x in presets if x["meta"]["mix_count"]==mixn and x["meta"]["group_size"]==g]
        print(f"  {mixn}혼합 {TKO[g]}: 새 {min(ws)}~{max(ws)}단어 (기존 {min(ow)}~{max(ow)})")
persons=[(s,ms) for x in presets for s,ms in zip(x["meta"]["structures"], x["meta"]["materials"])]
print("인물", len(persons), "명 | 구조×경계선:", dict(sorted(Counter(s for s,_ in persons).items())))
mc=Counter(MAT_KO[m] for _,ms in persons for m in ms); print("재질 사용:", dict(sorted(mc.items(), key=lambda kv:-kv[1])))
print("석재·목재 동시 포함 인물:", sum(1 for _,ms in persons if {"stone","wood"} <= set(ms)), "| UV 포함 인물:", sum("uvneon" in ms for _,ms in persons), "| 공작 포함 프리셋:", sum(any("scale_peacock" in ms for ms in x['meta']['materials']) for x in presets))
sent=[m for x in presets for m in re.findall(r"Her figure is divided into [^.]*\.", x["prompt"])]
print(f"구조 문장 {len(sent)}개 중 서로 다른 문장 {len(set(sent))}개 ({len(set(sent))/len(sent):.0%})")
