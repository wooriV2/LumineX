# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_goldleaf_test.py', encoding='utf-8').read().split("\nspecs = [")[0])      # leaf_person, make_struct, LEAF, 덮어쓰기 ...
rnd.seed(20261026)
DARK = "THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky"
TONES = {"포셀린":"FLAWLESS PORCELAIN PALE SKIN, luminous fair complexion with a cool rosy undertone",
         "올리브":"WARM OLIVE SKIN, smooth golden-olive complexion",
         "아이보리":"SMOOTH IVORY SKIN, creamy soft complexion with a warm undertone",
         "브론즈":"RICH BRONZE SKIN, sun-kissed deep tan complexion"}

def build_leaf_tone(g, n):
    phys = rnd.sample(PHYS, g); hairs = rnd.sample(HAIRS_MX, g); ages = rnd.sample(AGES_MX, g); cells = draw_cells(g)
    tones = rnd.sample(list(TONES), g); blocks=[]; descs=[]
    for i in range(g):
        b, st, pn, cs = leaf_person(["#1","#2","#3"][i] if g>1 else None, n, cells[i][0], cells[i][1], phys[i], hairs[i], ages[i], rnd.choice(POSES_MX))
        assert DARK in b; b = b.replace(DARK, TONES[tones[i]])
        blocks.append(b); descs.append(f"[{st} / {pn} / {tones[i]} 피부 / {cs}]")
    if g == 1:
        tail = f"MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. ONE woman only. Extreme macro detail on every leaf sheet and every blended transition. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle. 8K portrait 2:3 aspect ratio."
    else:
        tail = (f"Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.\nAll: Extreme macro detail on every leaf sheet and every blended transition. CRITICAL: all {g} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare skin visible anywhere. {NW[g]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame. 8K portrait {ASP[g]} aspect ratio.")
    p = f"Professional fashion photograph, full body shot. {NW[g]} wom{'a' if g==1 else 'e'}n standing{' side by side, each with her own multi-colour gold-leaf body' if g>1 else ''}.\n\n" + "\n\n".join(blocks) + f"\n\n{tail}"
    return p, " ; ".join(descs)

specs = [(1,3),(1,5),(2,3),(2,4),(3,2),(3,4)]
items=[]
for g,n in specs:
    p, desc = build_leaf_tone(g, n); p = fix(p); check("lt", p, allow_uv=False, mat=True)
    assert "DARKEST BLACK" not in p and f"Region {n}" in p
    items.append((g, n, desc, p))
order=list(range(6)); rnd.shuffle(order); no={i:order.index(i)+1 for i in range(6)}; ranked=sorted(range(6), key=lambda i:no[i])
GN={1:"솔로",2:"듀오",3:"트리오"}
L=["# LumineX · 금박 색 혼합 + 피부톤 교체(맥시멀리스트 틀 유지) 시험 6개\n",
   "맥시멀리스트 문장 구조(대문자, 강한 커버 반복, 검정 배경)는 그대로 두고 피부톤 문장만 포셀린·올리브·아이보리·브론즈로 바꿨습니다. 이미지 전체 구역 수는 12개 이하입니다. 번호는 섞여 있습니다. **성공/실패만** 알려주세요(최대 3회, 1회/2회/3회/실패). 예: `03: 2회 / 05: 실패 / 나머지 1회`\n",
   "## 색인\n","| 번호 | 인원 | 색 수 | 구성 (구조·경계선 / 체형 / 피부톤 / 금박 색) |","|---|---|---|---|"]
for i in ranked:
    g,n,desc,p = items[i]; L.append(f"| {no[i]:02d} | {GN[g]} | {n}색 | {desc} |")
L.append("")
for i in ranked:
    g,n,desc,p = items[i]; L.append(f"## {no[i]:02d}. {GN[g]} {n}색\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_GoldLeaf_SkinTone_Test_6.md","w",encoding="utf-8").write("\n".join(L))
json.dump([{"no":no[i],"gsize":items[i][0],"n":items[i][1],"desc":items[i][2]} for i in ranked], open("/home/claude/leaftone_meta.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
print("6개 저장")
for i in ranked: print(f"  {no[i]:02d} {GN[items[i][0]]} {items[i][1]}색 (전체 {items[i][0]*items[i][1]}구역) {len(items[i][3].split()):>4}단어 | {items[i][2][:100]}")
