# -*- coding: utf-8 -*-
import re, sys, random, json
from collections import Counter
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_mix6_test.py', encoding='utf-8').read().split("\nspecs = [")[0])      # build_mix2(일반 통과 구조 포함)·fix·check ...
rnd.seed(20261022)
HAIRW = re.compile(r'\b(hair|braid|braids|braided|bun|ponytail|twin|bangs|fringe|locs|afro|bob|updo|curls|waves|ringlets|pigtails)\b', re.I)
CLAUSES = sorted({c.strip() for m in T.MAKEUP_48 for c in face(m)[1].split(',') if HAIRW.search(c)}, key=len, reverse=True)
TN={2:"duo",3:"trio"}; TY={2:"Duo",3:"Trio"}; TKO={2:"듀오",3:"트리오"}
TR=["일반","임산부","맥시"]
def pick_tracks(g):
    if g == 2: return rnd.sample(TR, 2)
    if rnd.random() < 0.5: return rnd.sample(TR, 3)
    d = rnd.choice(TR); o = rnd.choice([t for t in TR if t != d]); L = [d, d, o]; return rnd.sample(L, 3)
C=[]
for mixn in [3,4]:
    for g in [2,3]:
        for slot in range(1,31):
            key=f"la_trackmix{mixn}_{TN[g]}_{slot:02d}"; tracks=pick_tracks(g)
            p, desc = build_mix2(tracks, mixn); p=fix(p); check(key, p, allow_uv=True, mat=True)
            assert not any(c in p for c in CLAUSES), key
            structs=[d.strip("[]").split(" / ")[0] for d in desc.split(" ; ")]
            C.append({"key":key,"category":"🏺 Living Artifact · Track Mix Material Formula","title":f"Track Mix {mixn}-Mix {TY[g]} #{slot:02d} ({' / '.join(structs)})","prompt":p,
                "meta":{"group_size":g,"aspect_ratio":ASP[g],"format":"track-mix-material","mix_count":mixn,"layout":"geometry-hazy-v2","tracks":tracks,"structures":structs}})
assert len(C)==120 and len({x["key"] for x in C})==120
json.dump(C, open("la_trackmix_geo_120_bundle.json","w",encoding="utf-8"), ensure_ascii=False, indent=2)
print("생성:", len(C), "개")
for g in [2,3]:
    ws=[len(x["prompt"].split()) for x in C if x["meta"]["group_size"]==g]; print(f"  {TKO[g]}: {min(ws)}~{max(ws)}단어")
tc=Counter(t for x in C for t in x["meta"]["tracks"]); print("인물 트랙 분포:", dict(tc))
print("일반 포함 프리셋:", sum("일반" in x["meta"]["tracks"] for x in C), "/ 3트랙 모두 포함:", sum(len(set(x["meta"]["tracks"]))==3 for x in C))
