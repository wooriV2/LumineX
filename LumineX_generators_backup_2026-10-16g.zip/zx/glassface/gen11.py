# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re, copy
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g6 = load("g6","gen6.py"); g9 = load("g9","gen9.py"); g10 = load("g10","gen10.py")
g = g9.g   # gen5 module
ROWS = g.ROWS
base = {r["ko"]: r for r in ROWS}

NEW_LOW = "All jewelry is real opaque metal, pearl, enamel or acrylic, passing through drilled openings in the carved material{lips}, never turning into the material. Brow bars stay on the brow bone, all kept clear of the eyeballs. Piercings on the centre line hang across the jagged line and stay bright real metal on both halves."
NEW_HIGH = "All jewelry is real opaque metal, pearl, enamel or acrylic, passing through drilled openings in the carved material (through real flesh for the lips), never turning into the material. Brow bars stay on the brow bone and every stud stays at least a finger's width from the eyes, all kept clear of the eyeballs. Piercings on the centre line hang across the jagged line and stay bright real metal on both halves."
DENS = " The piercings are packed so densely that the rows touch and overlap, leaving only hairline gaps of bare material between them, until the face reads as a single armour of metal; only the area around the eyeballs and the lips stays clear."

def mk(**kw): return kw
NEWROWS = {
 "코갸루": mk(ko="코갸루", nat="Japanese", mk="ko-gyaru",
   eyes="dark brown irises", gaze="a bright, cheeky gaze",
   lips="a glossy white real lipstick sitting on real skin, grinning brightly",
   lashes="long lashes carved as fine raised fibres along each lid",
   hair="the long bleached blonde hair with sun-streaked highlights is carved as loose sculpted waves falling around the face and behind the ears, each a chiselled ribbon of solid material with a polished surface",
   makeup="The deep sun-tan is the warm depth of the material's own tone. Bold bands of milky white run through the surface of the carved lids, with a bright turquoise line at each outer corner as a thin vein of turquoise colour inside the carving.",
   orn="A small turquoise satin ribbon is tied at the side of the head. It is real fabric, soft and matte, and stays exactly so."),
 "아마갸루": mk(ko="아마갸루", nat="Japanese", mk="ama-gyaru",
   eyes="soft brown irises enlarged by pale circle lenses", gaze="a sweet, shy gaze",
   lips="a dewy pink real lipstick sitting on real skin, in a soft shy smile",
   lashes="curled lashes carved as fine raised fibres along each lid",
   hair="the long light-brown hair in twin tails is carved as smooth sculpted twin tails falling around the face, each a chiselled ribbon of solid material with a polished surface",
   makeup="Soft pastel pink and lilac bands run through the surface of the carved lids, and a soft round blush lies deep within each cheek.",
   orn="Pastel ribbons tie the twin tails. They are real fabric, soft and matte, and stay exactly so."),
 "아게하": mk(ko="아게하", nat="Japanese", mk="age-gyaru",
   eyes="dark irises", gaze="a confident, sparkling gaze",
   lips="a glossy peach-pink real lipstick sitting on real skin, in a confident smile",
   lashes="extremely long dramatic lashes carved as fine raised fibres top and bottom, and thick black eyeliner carved as a bold dark line around each eye",
   hair="the towering teased bleached-blonde hair is carved as tall, teased sculpted locks standing high above the crown and falling around the face, each a chiselled ribbon of solid material",
   makeup="A bright highlighter glows on the carved cheekbones as a paler tone within the surface, and the whole face has a luminous, glossy finish like polished material.",
   orn=""),
 "오네에갸루": mk(ko="오네에갸루", nat="Japanese", mk="onee-gyaru",
   eyes="dark brown irises", gaze="a poised, mature, confident gaze",
   lips="a glossy rose-nude real lipstick sitting on real skin, in a composed, knowing smile",
   lashes="full natural lashes carved as fine raised fibres and a precise winged liner carved as a fine dark line at each outer corner",
   hair="the long sleek chestnut waves are carved as soft sculpted waves falling around the face and behind the ears, each a chiselled ribbon of solid material with a polished surface",
   makeup="Defined brown-mauve bands blend across the carved lids as a darker tone within the surface, and the cheeks are softly contoured as gentle hollows.",
   orn=""),
}
def style(name):
    return copy.deepcopy(NEWROWS[name]) if name in NEWROWS else copy.deepcopy(base[name])

b = lambda s, m: s.replace("black-steel", m)
p50_text = b(g6.V["pierce"], "silver")
p100_text = b(g9.P100, "bronze").replace("real metal piercings", "real bronze piercings with a few turquoise-enamel rings among them")
p150_text = g10.P150.replace("black-steel ", "").replace(
    "about one hundred and fifty real metal piercings covering the face and neck",
    "about one hundred and fifty real piercings in mixed metals — yellow gold, silver, copper, rose gold and black steel, alternating piece by piece, with a few pearl studs among them — covering the face and neck")

SPEC = [
 # 단계, 스타일, 재질L, 재질R, 피어싱 문구, 입술피어싱, 금속 라벨, 고밀도
 ("P3","오네에갸루","moonstone","ruby",
  "A thick polished yellow-gold hoop on each ear and one small gold stud above it.", False, "금(옐로 골드)", False),
 ("P5","아마갸루","frosted","cobalt",
  "A big rose-gold hoop on each ear with a small rose-gold stud above it on the left; a small rose-gold ring passes through the left nostril; a thin rose-gold bar passes through the outer end of the left eyebrow.", False, "로즈골드", False),
 ("P9","히메갸루","resin","amethyst",
  "A thick polished copper septum ring hangs below the nose; two thick copper bars pass through the outer end of the left eyebrow; a copper hoop passes through the lower lip's edge; a copper labret stud sits beneath the lower lip; on each ear a big copper hoop and a thick copper bar.", True, "동(구리)", False),
 ("P18","야마바","seaglass","carnelian",
  "A thick antique-brass septum ring hangs below the nose, with a brass ring through each nostril; two thick brass bars pass through the outer half of each eyebrow; a brass Medusa stud sits above the lips; a big brass hoop passes through the lower lip's edge with a snake-bite ring on each side; a brass labret stud sits beneath the lower lip; on each ear a big brass hoop, a thick brass bar and a stretched brass plug ringed in neon acrylic.", True, "황동 + 네온 아크릴", False),
 ("P50","아게하","ice","amber", p50_text, True, "은", False),
 ("P100","코갸루","opal","jade", p100_text, True, "청동 + 터키석색 에나멜", True),
 ("P150","로리타 갸루","murano","emerald", p150_text, True, "혼합 금속(금·은·동·로즈골드·검은 스틸) + 진주", True),
]

OUT = []
for tier, sty, a, bb, pierce, lipp, metal, dense in SPEC:
    r = style(sty)
    r["a"], r["b"] = a, bb
    r["pierce"] = pierce + (DENS if dense else "")
    r["lipp"] = lipp
    r["tier"] = tier
    _, an, bn, p = g.build(r)
    if tier in ("P3","P5","P9","P18"):
        newrule = NEW_LOW.format(lips=" (through real flesh for the lips)" if lipp else "")
    else:
        newrule = NEW_HIGH
    p2, n = re.subn(r"All jewelry is real opaque metal, pearl, enamel or acrylic, passing through[^.]*\.", newrule, p, count=1)
    assert n == 1, tier
    OUT.append((tier, r["ko"], an, bn, metal, p2))

if __name__ == "__main__":
    for t, ko, an, bn, metal, p in OUT:
        print(t, ko, an, "×", bn, metal, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
