# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re, copy
spec = importlib.util.spec_from_file_location("g5","gen5.py"); g = importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(io.StringIO()):
    spec.loader.exec_module(g)

OLD = "All jewelry is real opaque metal, pearl, enamel or acrylic, passing through drilled openings in the carved material (through real flesh for the lips), never turning into the material, and kept clear of the eyeballs."
NEW = "All jewelry is real opaque metal, pearl, enamel or acrylic, passing through drilled openings in the carved material (through real flesh for the lips), never turning into the material. Brow bars stay on the brow bone and cheek studs stay well below the eyes, all kept clear of the eyeballs. Piercings on the centre line hang across the jagged line and stay bright real metal on both halves."

V = copy.deepcopy(g.ROWS[6])   # 비주얼계
V["tier"] = "최대"
V["pierce"] = ("An extreme, dense array of large real metal piercings: a thick black-steel septum ring with a smaller black-steel ring above it and two black-steel rings through each nostril; "
 "a straight black-steel bar across the bridge of the nose between the brows; three thick black-steel bars stacked through the outer half of each eyebrow; a black-steel Medusa stud above the lips; "
 "a big black-steel hoop, two smaller rings and a snake-bite ring on each side through the lower lip's edge, and a row of small hoops through the upper lip's edge; "
 "a black-steel labret stud and two rings through the chin; a row of small black-steel studs along each jaw; a curved row of small black-steel studs along each cheekbone; "
 "on each ear a full dense row from lobe to top of big black-steel hoops, thick bars and stretched plugs; and two fine black-steel chains looping from the ear hoops to the nostril rings.")

L = copy.deepcopy(g.ROWS[8])   # 로리타 갸루
L["tier"] = "최대"
L["pierce"] = ("An extreme, dense array of large real metal piercings: a thick silver septum ring with a smaller silver ring above it and two silver rings through each nostril; "
 "a straight silver bar across the bridge of the nose between the brows; three thick silver bars stacked through the outer half of each eyebrow; a silver Medusa stud above the lips; "
 "a big silver hoop, two smaller rings and a snake-bite ring on each side through the lower lip's edge, and a row of small hoops through the upper lip's edge; "
 "a silver labret stud and two rings through the chin; a row of small silver studs along each jaw; a curved row of small pearl studs along each cheekbone; "
 "on each ear a full dense row from lobe to top of big silver hoops, thick bars and stretched gold-rimmed plugs; and two fine silver chains looping from the ear hoops to the nostril rings.")

OUT = []
for r in (V, L):
    _, an, bn, p = g.build(r)
    assert OLD in p
    p = p.replace(OLD, NEW)
    OUT.append((r, an, bn, p))

if __name__ == "__main__":
    for r, an, bn, p in OUT:
        print(r["ko"], an, bn, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
        print(p); print("-----")
