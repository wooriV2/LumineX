# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
import tracker as T
from full_dicts import (face, CRAFT_DB_FULL, SHOE_EN_FULL, POSE_EN_FULL, AGE_EN_FULL, VIBE_EN_FULL,
                        NAIL_SHAPE_EN_FULL, NAIL_FIN_EN_FULL, HAIR_EN_FULL, HAIR_COLOR_EN_FULL, SCALE_ANIMAL_DB)
from body_full import BODY_FULL

# 이레즈미·UV네온 문양 풀(26/27종) — 이전에 검증한 정의 재사용
_src = open('gen_fix_ire_uv_6to10.py', encoding='utf-8').read().split('print("이레즈미 풀:"')[0]
exec(_src)   # IREZUMI_FULL, UV_FULL 정의됨

BANNED = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","safety pin","gash","crack"]
RISKY = ["embroider","textile","stitch"]
HAIRW = re.compile(r'\b(hair|braid|braids|braided|bun|ponytail|twin|bangs|fringe|locs|afro|bob|updo|curls|waves|ringlets|pigtails)\b', re.I)
def face_nohair(makeup):
    nat, fa = face(makeup)
    clauses = [c.strip() for c in fa.split(',')]
    kept = [c for c in clauses if not HAIRW.search(c)]
    return nat, ", ".join(kept)

def validate(name, p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name, "KOREAN")
    low = p.lower()
    hits = [w for w in BANNED if re.search(r'\b'+re.escape(w)+r'\b', low)]
    assert not hits, (name, "BANNED", hits)
    rh = [w for w in RISKY if w in low]
    assert not rh, (name, "FABRIC", rh)
    assert not re.search(r'far beyond any real person\.\s*[Aa]n (extraordinarily large|enormous)', p), (name, "DUP_SENTENCE")
    assert "VIVID VIVID" not in p and "BLAZING BLAZING" not in p, (name, "DUP_COLOR_WORD")

def strip_pref(c):  # 색상 앞 BLAZING/VIVID 접두어 중복 방지
    return re.sub(r'^(BLAZING|VIVID)\s+', '', c)

rnd = random.Random(20261004)

# ============================================================
# A. 재질 블렌드 (맥시멀리스트 골격 유지)
# ============================================================
COLOR_RE = re.compile(r'\b((?:BLAZING|VIVID|STARK|ELECTRIC|DEEP|NEON)(?: [A-Z][A-Z\-]+)+)')
def motif_colors(ink):
    cols = [strip_pref(c) for c in COLOR_RE.findall(ink)]
    return cols[:2]

CRYSTAL_COLORS = [("ICE BLUE","SILVER-WHITE","ice crystal"),("ROSE QUARTZ PINK","SOFT GOLD","rose quartz crystal"),("AMETHYST VIOLET","DEEP GOLD","amethyst crystal"),
 ("CITRINE YELLOW","AMBER","citrine crystal"),("EMERALD GREEN","GOLD","emerald crystal"),("SMOKY GREY","CHARCOAL","smoky quartz crystal"),
 ("SAPPHIRE BLUE","SILVER","sapphire crystal"),("RUBY RED","GOLD","ruby crystal"),("TOPAZ ORANGE","BRONZE","topaz crystal"),("CLEAR WHITE","PRISMATIC RAINBOW","clear quartz crystal")]
GLASS_COLORS = [("ELECTRIC CRIMSON","GOLD"),("ELECTRIC VIOLET","CYAN"),("ELECTRIC EMERALD","GOLD"),("ELECTRIC MAGENTA","SILVER")]
LEAF_COLORS = [("ELECTRIC CRIMSON","GOLD"),("ELECTRIC VIOLET","CYAN"),("ELECTRIC EMERALD","GOLD"),("ELECTRIC MAGENTA","SILVER"),("ROSE-GOLD","CYAN")]
FLOWERS = [("peony","CRIMSON","EMERALD"),("orchid","VIOLET","GOLD"),("sakura","PINK","GOLD"),("lotus","PINK","JADE")]
WAX_COLORS = [("DEEP CRIMSON","AMBER"),("DEEP EMERALD","GOLD"),("DEEP VIOLET","ROSE")]
WOODS = {
 "walnut": "rich dark walnut wood fused directly into her own form, natural grain lines flowing to follow every curve, BLAZING deep warm-brown grain with VIVID honey-gold highlight streaks",
 "oak": "pale golden oak wood fused directly into her own form, natural straight grain lines flowing to follow every curve, BLAZING warm honey-blonde grain with VIVID amber highlight streaks",
 "mahogany": "rich reddish mahogany wood fused directly into her own form, natural fine grain lines flowing to follow every curve, BLAZING deep red-brown grain with VIVID copper highlight streaks",
 "ebony": "deep black ebony wood fused directly into her own form, natural fine grain lines flowing to follow every curve, BLAZING glossy jet-black grain with VIVID dark-brown highlight streaks"}
STONES = {
 "marble": "solid polished white marble fused directly into her own form, natural grey-gold veining flowing to follow every curve, BLAZING pale marble surface with VIVID golden vein striations",
 "granite": "solid polished black granite fused directly into her own form, fine natural speckled texture flowing to follow every curve, BLAZING deep charcoal-black granite surface with VIVID silver mineral fleck detail",
 "rose_stone": "solid polished rose-quartz stone fused directly into her own form, soft natural veining flowing to follow every curve, BLAZING soft pink stone surface with VIVID white vein striations",
 "jade_stone": "solid polished jade-green stone fused directly into her own form, natural cloudy veining flowing to follow every curve, BLAZING deep jade-green stone surface with VIVID pale-green vein striations"}
PEACOCK = ("overlapping feather-barb ridges each converging into a round eye-marking with a raised rim",
           [("ELECTRIC TEAL-GOLD","DEEP VIOLET"),("ELECTRIC EMERALD","DEEP BLUE"),("ELECTRIC TEAL","GOLD")])

MAT_KO = {"irezumi":"이레즈미","uvneon":"UV네온","glass":"스테인드글라스","goldleaf":"금박","botanical":"보태니컬","crystal":"크리스탈",
 "scale_butterfly":"나비날개비늘","scale_koi":"코이비늘","scale_snake":"뱀비늘","scale_dragon":"드래곤비늘","scale_mermaid":"인어비늘","scale_peacock":"공작눈무늬",
 "obsidian":"흑요암금","wax":"왁스","wood":"목재","stone":"석재"}
MATKEYS = list(MAT_KO.keys())   # 16종 (석재·목재는 각각 1슬롯, 변종은 선택 시 랜덤)

def mat_text(key):
    if key == "irezumi":
        name, ink = rnd.choice(IREZUMI_FULL); cols = motif_colors(ink)
        c = " and ".join(cols) if cols else "BLAZING GOLD"
        return f"traditional irezumi tattoo ink, bold black ink outlines, {name} formations in {c}, extreme high-gloss oil finish", name
    if key == "uvneon":
        name, ink = rnd.choice(UV_FULL); cols = motif_colors(ink)
        c = " and ".join(cols) if cols else "ELECTRIC VIOLET"
        return f"UV-reactive neon bodypaint, invisible under standard light but {name} formations in {c} glowing at full intensity under her own dedicated UV blacklight", name
    if key == "glass":
        c1,c2 = rnd.choice(GLASS_COLORS)
        return f"solid thick stained glass fused to her form, hundreds of small individual panes each no larger than a coin, BLAZING {c1} and VIVID {c2} panes alternating in a dense irregular mosaic, dark lead-line seams webbing between every pane", f"{c1}"
    if key == "goldleaf":
        c1,c2 = rnd.choice(LEAF_COLORS)
        return f"applied {c1} leaf, thin irregular metallic sheets laid onto the contour of her body with fine natural creases and overlapping seams, VIVID {c2} undertone glinting through the thinnest points", c1
    if key == "botanical":
        f,c1,c2 = rnd.choice(FLOWERS)
        return f"living {f} blooms growing directly from her own skin, every stem rooted in her living skin and every petal standing in three-dimensional relief casting its own small shadow, BLAZING {c1} blossoms, VIVID {c2} leaves and tendrils", f
    if key == "crystal":
        c1,c2,s = rnd.choice(CRYSTAL_COLORS)
        return f"{s} clusters growing directly out of her own skin, erupting in true three-dimensional relief, each facet casting its own hard shadow, BLAZING {c1} crystal points, VIVID {c2} mineral veins", s
    if key.startswith("scale_"):
        animal = key.split("_",1)[1]
        if animal == "peacock":
            shape, pals = PEACOCK; c1,c2 = rnd.choice(pals)
            return f"peacock feather-eye markings ({shape}), BLAZING {strip_pref(c1)} eye-marking centres, VIVID {strip_pref(c2)} radiating barb-ridge detail, every marking standing in true relief", "peacock"
        shape, pals = SCALE_ANIMAL_DB[animal]; c1,c2 = rnd.choice(pals)
        return f"{animal} scales ({shape}), BLAZING {strip_pref(c1)} scale formations, VIVID {strip_pref(c2)} scale-edge detail, every scale catching its own glint and casting its own small shadow", animal
    if key == "obsidian":
        return "polished obsidian stone fused directly to her own form, solid glossy black stone curving to follow her body's true shape, with molten gold seams running between fitted stone sections", "obsidian"
    if key == "wax":
        c1,c2 = rnd.choice(WAX_COLORS)
        return f"molten wax flowing and set directly over her own skin, BLAZING {c1} wax streams pooling and hardening, VIVID {c2} translucent drip-ridges catching the light", c1
    if key == "wood":
        v = rnd.choice(list(WOODS)); return WOODS[v], v
    if key == "stone":
        v = rnd.choice(list(STONES)); return STONES[v], v
    raise KeyError(key)

def pick_mats(n):
    """n개 재질 선택. 석재·목재는 각 1슬롯, 2개 혼합일 때 {석재,목재} 단독 조합 제외."""
    while True:
        mats = rnd.sample(MATKEYS, n)
        if n == 2 and set(mats) == {"stone","wood"}:
            continue
        return mats

PHYS = [
 ("super hourglass","waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum beyond any proportion, most dramatic hourglass ratio ever recorded on any human body, thighs so thick pressing together"),
 ("BBW bombshell","most massive full-figure BBW body ever at absolute maximum in every dimension, hips so wide beyond proportion dominating the entire frame, bust so enormous overwhelming gravity, waist deeply snatched despite impossible volume"),
 ("wide hip narrow","hips so impossibly wide extending beyond frame creating the most extreme hip-to-waist ratio ever, waist cinched to absolute impossible minimum, upper body slim emphasizing the dramatic hip explosion"),
 ("curvy petite","smallest most compact frame possible yet curves exploding at absolute maximum in every direction, bubble butt projecting dramatically backward from the tiny frame, thighs so thick they dwarf the petite frame"),
 ("amazon bombshell","impossibly tall commanding frame with simultaneously the most massive full-figure curves, enormous powerful presence dominating the entire frame top to bottom, legs endlessly long massively thick and powerful"),
 ("latina curves","most dramatic hourglass ratio ever, simultaneously maximum enormous bust AND maximum enormous hips both flaring to absolute impossible extremes while the waist is cinched to impossible minimum"),
 ("hourglass bombshell","waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum, thighs pressing together, every curve maximized at once"),
 ("powerlifter bombshell","immense powerful thighs and shoulders built with real strength, a thick solid waist, overwhelming muscular bulk layered with soft curves everywhere")]
HAIRS_MX = ["long sleek jet-black hair cascading past hips","silver-white natural hair swept into a high sculpted crown","loose beach waves mid-length tousled","blunt collarbone-length bob thick heavy",
            "silver-white locs cascading to her waist","curtain bangs long straight hair sweeping past the shoulders","two thick goddess braids","high ponytail swept sleek"]
POSES_MX = ["strong hip pop right, both hands pressing sides of hips outward simultaneously arching back to extreme",
 "full frontal wide stance, both fists pressing outer hips outward to absolute maximum",
 "standing full height, both arms slightly spread commanding the frame",
 "strong hip pop left, both hands pressing outer hips outward arching back to extreme",
 "full frontal, both hands framing the face, chin raised",
 "three-quarter angle, one hand on the outer hip, the other raised overhead"]   # 구역이 잘 보이도록 정면·측면 계열만
AGES_MX = ["early 20s","late 20s","early 30s","mid 30s","late 30s","mid 40s","early 50s","mid 50s"]

def mx_person(label, phys, hair, age, pose, mats):
    n = len(mats); items = [mat_text(m) for m in mats]; texts = [t for t,_ in items]
    uv = "uvneon" in mats
    if n == 2:
        style = rnd.choices(["lr","marbled"], weights=[6,4])[0]
    else:
        style = "zones"
    if style == "lr":
        zones = (f"her LEFT side is dominated by {texts[0]}. Her RIGHT side is dominated by {texts[1]}. Rather than a sharp boundary, the two materials interweave and overlap gradually across a soft irregular zone a few inches wide down the centre of her body, elements of each scattered into the other's territory, density fading rather than stopping abruptly")
        pose_tail = ", both halves of her body clearly visible"
    elif style == "marbled":
        zones = (f"her entire body, from neck to ankle, is a random intermingled mix of two materials with no spatial division at all — not left versus right, not top versus bottom, but irregular patches of each scattered all over her body in a marbled, organic distribution, exactly like natural mineral veining. {texts[0]} and {texts[1]} are woven through each other everywhere: a patch of one material on one shoulder, immediately beside it a patch of the other, then the first again across the ribs, the second at the hip, the first down one thigh, the second across the opposite calf — the two materials never separating into a clean zone anywhere on her body, every square inch densely interlocking")
        pose_tail = ""
    else:
        ordw = ["one","the second","the third","the fourth"]
        zs = " ".join(f"{texts[i]} dominates zone {i+1}." for i in range(n))
        zones = (f"her body carries {n} different materials at once, each claiming roughly an equal irregular organic share of her body rather than any straight line, zones arranged diagonally and asymmetrically. {zs} Wherever any two zones meet, the boundary is soft, diagonal or curving rather than a straight line, the materials interweaving and overlapping gradually across an irregular blended border a few inches wide, elements of each scattered into the neighbouring zone")
        pose_tail = ""
    pn, pd = phys
    light = " A standard hard key light illuminates most of her body; a separate dedicated UV blacklight illuminates the UV-reactive zone specifically, making it glow at full intensity while the rest reads under normal light." if uv else ""
    prefix = f"{label}: " if label else ""
    txt = (f"{prefix}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair} — {zones}, no fabric no seam no garment anywhere, every material fused to or erupting from her own living skin, covering her completely with no bare skin anywhere from neck to ankle. Pose: {pose}{pose_tail} — most extreme {pn} silhouette ever displayed.{light}\n"
           f"{prefix}extreme platform heels/boots blending the relevant materials at her feet, extra long nails each matching whichever zone that hand falls in.")
    return txt, style, [MAT_KO[m] for m in mats], [d for _,d in items]

NW = {1:"ONE",2:"TWO",3:"THREE"}; ASP = {1:"2:3",2:"3:4",3:"4:5"}; LAB = ["#1","#2","#3"]
TN = {1:"solo",2:"duo",3:"trio"}; TKO = {1:"솔로",2:"듀오",3:"트리오"}

def build_A(gsize, mixn):
    phys = rnd.sample(PHYS, gsize); hairs = rnd.sample(HAIRS_MX, gsize); ages = rnd.sample(AGES_MX, gsize)
    blocks=[]; styles=[]; matnames=[]; allmats=[]
    for i in range(gsize):
        mats = pick_mats(mixn)
        b, st, kn, dt = mx_person(LAB[i] if gsize>1 else None, phys[i], hairs[i], ages[i], rnd.choice(POSES_MX), mats)
        blocks.append(b); styles.append(st); matnames.append("+".join(kn)); allmats.append(mats)
    body = "\n\n".join(blocks)
    if gsize == 1:
        tail = "MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. ONE woman only. Extreme macro detail on every material and every blended transition. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
    else:
        tail = (f"Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.\nAll: Extreme macro detail on every material and every blended transition. CRITICAL: all {gsize} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere. {NW[gsize]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame.")
    p = (f"Professional fashion photograph, full body shot. {NW[gsize]} wom{'a' if gsize==1 else 'e'}n standing"
         f"{' side by side, each with her own multi-material blended body' if gsize>1 else ''}.\n\n{body}\n\n{tail} 8K portrait {ASP[gsize]} aspect ratio.")
    return p, styles, matnames, allmats

# ============================================================
# B. 공예 블렌드 (바디페인팅 북엔드 구조)
# ============================================================
VOLBODY = ["USSBBW","슈퍼글래머","아마조네스","블랙글래머","머슬아워글래스BBW","헤비머슬"]
ORD = ["one zone","the second zone","the third zone","the fourth zone"]

def cap(s): return s[0].upper()+s[1:]

def craft_bodyart(crafts, style, dims=None):
    n = len(crafts); T4 = [CRAFT_DB_FULL[c] for c in crafts]
    if n == 2:
        (cn1,cd1,cb1,cf1),(cn2,cd2,cb2,cf2) = T4
        d0,d1 = dims
        return (f"Body Art: Her bare skin is painted in two different patterns covering every inch of her body below the jaw with no bare skin anywhere. Her {d0} is painted in {cn1} ({cd1}), wide {cb1} bands following every deep crease, dense {cf1} filling the space between bands, pigment on living skin. Her {d1} is painted in {cn2} ({cd2}), wide {cb2} bands following every crease, dense {cf2} filling the space between bands, pigment on living skin. Rather than a sharp boundary, the two painted patterns blend gradually into each other across a soft irregular zone a few inches wide, motifs from each pattern scattered into the other's territory, density fading rather than stopping abruptly, face unpainted.")
    zs = " ".join(f"{cn} ({cd}, wide {cb} bands, dense {cf}) dominates {ORD[i]}." for i,(cn,cd,cb,cf) in enumerate(T4))
    return (f"Body Art: Her bare skin carries {n} different painted patterns at once, together covering every inch of her body below the jaw with no bare skin anywhere, each pattern claiming roughly an equal irregular share of her body rather than any straight line, zones arranged diagonally and asymmetrically. {zs} Wherever any two zones meet, the boundary is soft and diagonal rather than a straight line, motifs blending gradually across an irregular border a few inches wide, pigment on living skin throughout, face unpainted.")

def person_B(label, makeup, bodykey, crafts):
    nat, fa = face_nohair(makeup)
    age = AGE_EN_FULL[rnd.choice(T.AGE_12)]; vibe = VIBE_EN_FULL[rnd.choice(T.VIBE_5)]
    hs = HAIR_EN_FULL[rnd.choice(T.HAIR_STYLE)]; hc = HAIR_COLOR_EN_FULL[rnd.choice(T.HAIR_COLOR)]
    nail = f"{NAIL_SHAPE_EN_FULL[rnd.choice(T.NAIL_SHAPES)]} nails, {NAIL_FIN_EN_FULL[rnd.choice(T.NAIL_FINISH)]} finish"
    pose = POSE_EN_FULL[rnd.choice(T.POSE_19)]; shoe = SHOE_EN_FULL[rnd.choice(T.SHOES_24)]
    body = cap(BODY_FULL[bodykey])
    n = len(crafts)
    style = rnd.choice(["horizontal","lr"]) if n == 2 else "zones"
    dims = ("upper body, from her collarbones down to her waistline,","lower body, from her waistline down to her ankles,") if style=="horizontal" else ("LEFT side","RIGHT side")
    art = craft_bodyart(crafts, style, dims)
    subj = f"a real adult {nat} woman in her {age}, her face exactly the same tone as her body, real skin texture with visible pores and fine grain, {fa}, {vibe}, {hc} hair styled in {hs}, real living eyes. Long {nail}."
    skin = "Skin: Real photographic skin — visible pores and fine grain, a smooth taut surface with natural creases and shadow only where the flesh folds. No smooth illustration finish, no plastic CG sheen."
    foot = f"Footwear: extreme {shoe}, painted with the blended patterns following the same soft transitions as her skin."
    if label is None:
        return (f"Subject: ONE real adult {subj[len('a real adult '):]}\n\nPhysique: {body}\n\n{skin}\n\n{art}\n\nPose: {pose}.\n\n{foot}"), style
    art_body = art[len("Body Art: "):]
    return (f"{label} woman: {subj}\n\n{label} woman's physique: {body}\n\n{label} woman's body art: {art_body}\n\n{label} woman's pose: {pose}.\n\n{label} woman's footwear: {foot[len('Footwear: '):]}"), style

def build_B(gsize, mixn):
    makeups = rnd.sample(T.MAKEUP_48, gsize); bodies = rnd.sample(VOLBODY, gsize)
    pool = rnd.sample(T.CRAFTS_39, gsize*mixn)
    blocks=[]; styles=[]; craftnames=[]
    for i in range(gsize):
        crafts = pool[i*mixn:(i+1)*mixn]
        lab = ["Left","Center","Right"][i] if gsize>1 else None
        b, st = person_B(lab, makeups[i], bodies[i], crafts)
        blocks.append(b); styles.append(st); craftnames.append("+".join(crafts))
    body = "\n\n".join(blocks)
    if gsize == 1:
        p = (f"Image format: a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide.\n\nA full-body photograph with a plain seamless deep-charcoal backdrop, shot on a medium format camera with an 85mm lens at f/8, a single hard key light raking in from one side, sharp focus from head to toe, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n{body}\n\nBackground & Lighting: the blended painted patterns reading crisp against her skin, the hard raking light carving every fold and curve.\n\nVertical 2:3 portrait-orientation full-body photograph, taller than it is wide. portrait 2:3 vertical.")
    else:
        p = (f"Image format: a landscape-orientation photograph, {ASP[gsize]} aspect ratio.\n\nA photograph of {NW[gsize]} women standing side by side on a plain seamless deep-charcoal backdrop, nothing else in the frame, 50mm lens at f/8, a single hard key light raking across all of them from one side, sharp focus head to toe on each — a real photograph, not an illustration, not CGI, not a render.\n\n{body}\n\nComposition: each woman's own pose as described, inner arms not crossing her neighbours, all faces toward the camera.\n\nLighting: the blended painted patterns reading crisp against each woman's skin, the hard raking light carving every fold and curve. Shot on a Hasselblad X2D, {ASP[gsize]} 8K.")
    return p, styles, craftnames

# ============================================================
# 생성 + 검증
# ============================================================
presets=[]; statsA={"style":{}, "mat":{}}; statsB={"style":{}, "craft":{}}
CATA="🏺 Living Artifact · Material Blend Formula"; CATB="🏺 Living Artifact · Craft Blend Formula"
for mixn in [2,3,4]:
    for gsize in [1,2,3]:
        for slot in range(1,31):
            pA, stA, mnA, rawA = build_A(gsize, mixn)
            nameA = f"matblend{mixn}_{TN[gsize]}_{slot:02d}"; validate(nameA, pA)
            for st in stA: statsA["style"][st]=statsA["style"].get(st,0)+1
            for ms in rawA:
                for m in ms: statsA["mat"][m]=statsA["mat"].get(m,0)+1
            presets.append({"key":f"la_{nameA}","category":CATA,
                "title":f"Material Blend {mixn}-Mix {TN[gsize].capitalize()} #{slot:02d} ({' / '.join(mnA)})",
                "prompt":pA,"meta":{"group_size":gsize,"aspect_ratio":ASP[gsize],"format":"material-blend","mix_count":mixn,"styles":stA,"materials":rawA}})
            pB, stB, cnB = build_B(gsize, mixn)
            nameB = f"craftblend{mixn}_{TN[gsize]}_{slot:02d}"; validate(nameB, pB)
            for st in stB: statsB["style"][st]=statsB["style"].get(st,0)+1
            for cs in cnB:
                for c in cs.split("+"): statsB["craft"][c]=statsB["craft"].get(c,0)+1
            presets.append({"key":f"la_{nameB}","category":CATB,
                "title":f"Craft Blend {mixn}-Mix {TN[gsize].capitalize()} #{slot:02d} ({' / '.join(cnB)})",
                "prompt":pB,"meta":{"group_size":gsize,"aspect_ratio":ASP[gsize],"format":"craft-blend","mix_count":mixn,"styles":stB,"crafts":cnB}})

keys=[p["key"] for p in presets]
assert len(keys)==len(set(keys))==540, len(keys)
# 석재+목재 단독조합 사후 검증
for p in presets:
    if p["meta"]["format"]=="material-blend":
        for ms in p["meta"]["materials"]:
            assert not (len(ms)==2 and set(ms)=={"stone","wood"}), p["key"]
json.dump(presets, open("la_blend_540_bundle.json","w",encoding="utf-8"), ensure_ascii=False, indent=2)

print("생성:", len(presets), "개 / 키 중복 없음")
for cat,tag in [("material-blend","A 재질"),("craft-blend","B 공예")]:
    for mixn in [2,3,4]:
        for g in [1,2,3]:
            ws=[len(p["prompt"].split()) for p in presets if p["meta"]["format"]==cat and p["meta"]["mix_count"]==mixn and p["meta"]["group_size"]==g]
            print(f"  {tag} {mixn}혼합 {TKO[g]}: {len(ws)}개 {min(ws)}~{max(ws)}단어")
print("A 경계방식 분포:", statsA["style"]); print("B 경계방식 분포:", statsB["style"])
print("A 재질 사용 빈도:", dict(sorted(statsA["mat"].items(), key=lambda x:-x[1])))
used=len(statsB["craft"]); print(f"B 공예 사용 종류: {used}/40, 최소 {min(statsB['craft'].values())}회 ~ 최대 {max(statsB['craft'].values())}회")
print("공작 포함 프리셋:", sum(1 for p in presets if p["meta"]["format"]=="material-blend" and any("scale_peacock" in ms for ms in p["meta"]["materials"])))
print("UV 블랙라이트 문장 일치:", all(("dedicated UV blacklight" in p["prompt"])==any("uvneon" in ms for ms in p["meta"]["materials"]) for p in presets if p["meta"]["format"]=="material-blend"))
