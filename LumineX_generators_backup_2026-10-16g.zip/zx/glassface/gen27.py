# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g25 = load("g25","gen25.py")
g3 = g25.g3; FULL_BODY = g25.FULL_BODY; MAT = g25.MAT; REAL_FACE = g25.REAL_FACE

def combo(sty, bk, a, b, ear, title, growth_txt, setting):
    nat, mk, fc = g3.face_of(sty)
    an, ad, ai = MAT[a]; bn, bd, bi = MAT[b]
    return f"""Professional fashion photograph, full body shot, head to toe. ONE woman standing, angled 45 degrees toward the camera, the camera set back so her whole body fits in the frame from the top of her head to her feet and the floor and wall around her are visible, her face still sharp. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}. {REAL_FACE} {ear} Real jewelry on real skin, healed, clean and calm.

Physique: {FULL_BODY[bk][1]}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest, belly, left hip and the whole left leg down through the foot): solid {ad}, with {ai}. Right half: solid {bd}, with {bi}. Each is carved as one solid sculpted mass like a statue, never hollow. The arms flow into the torso and the torso into the legs with no seam, and every wrist, palm, finger, knuckle and toe is the same material as its limb. Her extreme platform stiletto sandals are carved from the same material as the leg each one sits under, running unbroken through the ankle and every toe.

{title}: {growth_txt}

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the body, between the hips and legs and down to the floor, where the two materials meet, never horizontal. Shards interlock along the lines only, every edge solid all the way through.

Setting and light: {setting} Her real face stays softly lit from the front.

Pose: body angled 45 degrees, feet planted apart, her left hand (solid material) resting on her flared hip, her right arm held clear of her body with the hand (solid material) relaxed at hip height, well away from her face, head tilted slightly toward the camera. Only her face, ears and neck read as real skin. 2:3 vertical 8K portrait."""

PLANT_TAIL = " The leaves and petals are real and soft. The plants grow only from the shoulders, arms, chest and hips — never on the neck, the face or the hair, and never covering the hands."
K1 = combo("프렌치 레드립(프랑스)","top","emerald","sapphire",
  "A single thick gold hoop on each ear.",
  "Growth",
  "real plants grow out of the material below the collarbones, rooted in fine cracks inside the material, their pale roots visible as threads through it. On the left emerald, dark green ivy with pale veins climbs from the shoulder and winds down the arm to the hip, its tendrils curling. On the right sapphire, long hanging clusters of white-and-lilac wisteria cascade from the shoulder and drape down over the arm and the side of the chest, a few petals dropping toward the floor." + PLANT_TAIL,
  "she stands on a worn pale stone floor in front of a bare stone wall in an old hall. Through a tall arched window behind her left a strong hard beam of golden sunlight falls across the room, with fine dust drifting in it. The beam passes through her transparent body and the plants, throwing long caustic shadows — green patches from the emerald side and blue patches from the sapphire side — across the floor and the wall, each with bright bending edges of concentrated light.")
K2 = combo("브리티시 모드(영국)","hgu","egglass","cobalt",
  "A large flat geometric silver disc earring on each ear.",
  "Perched creatures",
  "small living creatures rest and drift around the material as if it were a garden statue at dusk, real, alive and still. On the left emerald-green glass, three iridescent blue-green dragonflies with transparent wings perch on the shoulder cap, the upper arm and the hip. On the right cobalt glass, a couple of dozen fireflies drift and rest along the arm, the ribs and the hip, each a soft warm glowing point of light whose glow reflects in the crystal and in the wet floor. The creatures stay well away from her face and neck and never cover the boundary line or the piercings.",
  "it is dusk. She stands on a polished, wet black stone floor in front of a dark blue-grey wall, lit by one soft cool light from the upper right behind her. Her transparent body glows from within and throws faint green and blue patches of caustic light onto the wet floor, and her whole glowing body, the dragonflies and every firefly are mirrored in a soft reflection in the wet floor, the warm points of light rippling in it.")
K3 = combo("노르딕 발키리(노르웨이)","tent","smoky","amber",
  "A thick silver knotted hoop on each ear.",
  "Growth",
  "real plants grow out of the material below the collarbones, rooted in fine cracks inside the material, their pale roots visible as threads through it. On the left smoky glass, a branch of cherry blossom with pale pink blossoms, buds and bronze-green leaves grows out of the shoulder and arches over the upper arm and along the side of the chest, petals drifting down toward the floor. On the right amber, a shorter branch of white plum blossom rises from the shoulder and the upper arm." + PLANT_TAIL,
  "she stands on a deep teal painted floor in front of a deep teal painted wall, lit by one hard warm light from the left behind her. The light passes through her transparent body and the blossoms and throws long caustic shadows across the floor and the wall — dark smoky grey patches from the smoky glass side and golden-orange patches from the amber side glowing against the teal, each with bright bending edges of concentrated light, and pale pink petals scattered on the floor.")

ITEMS = [
 ("K1","창문 빛줄기 × 등나무·아이비","B5 + GP4","프렌치 레드립 · 톱헤비 아워글래스 · 에메랄드(아이비) × 사파이어(등나무) · 석조 홀의 햇살 줄기"),
 ("K2","반사 바닥 × 잠자리·반딧불이","B4 + GA2","브리티시 모드 · 아워글래스 USSBBW · 에메랄드 그린 유리(잠자리) × 코발트 유리(반딧불이) · 해질녘 젖은 검은 바닥"),
 ("K3","청록 벽 × 벚꽃·매화","B6 + GP1","노르딕 발키리 · 텐트폴 · 스모키 유리(벚꽃) × 호박(매화) · 청록색 벽과 바닥에 흩어진 꽃잎"),
]
PROMPTS = [K1, K2, K3]
if __name__ == "__main__":
    for (n,t,c,d), p in zip(ITEMS, PROMPTS):
        print(n,t,c,len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
