# -*- coding: utf-8 -*-
import re, random

banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","safety pin","gash"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    hits = [w for w in banned if w in p.lower()]
    assert not hits, (name,hits)

PHYSIQUES = [
 ("wide hip narrow physique", "hips so impossibly wide extending beyond frame creating the most extreme hip-to-waist ratio ever, waist cinched to absolute impossible minimum, upper body slim emphasizing the dramatic hip explosion", "wide hip narrow"),
 ("super hourglass physique", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum beyond any proportion, most dramatic hourglass ratio ever recorded, thighs so thick pressing together", "super hourglass"),
 ("BBW bombshell physique", "most massive full-figure BBW body ever at absolute maximum in every dimension, hips so wide beyond proportion dominating the entire frame, bust so enormous overwhelming gravity, waist deeply snatched despite impossible volume", "BBW bombshell"),
 ("latina curves physique", "most dramatic hourglass ratio ever, simultaneously maximum enormous bust AND maximum enormous hips both flaring to absolute impossible extremes while the waist is cinched to impossible minimum", "latina curves"),
 ("curvy petite physique", "smallest most compact frame possible yet curves exploding at absolute maximum in every direction, bubble butt projecting dramatically backward from the tiny frame, thighs so thick they dwarf the petite frame", "curvy petite"),
 ("amazon bombshell physique", "impossibly tall commanding frame with simultaneously the most massive full-figure curves, enormous powerful presence dominating the entire frame top to bottom, legs endlessly long massively thick and powerful", "amazon bombshell"),
 ("hourglass bombshell physique", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum, thighs pressing together, every curve maximized at once", "hourglass bombshell"),
]

MOTIFS = [
 ("dragon", "BLAZING ELECTRIC GOLD dragon coiling full torso both legs neck to ankle", "gold dragon-scale"),
 ("phoenix", "ELECTRIC CRIMSON phoenix wings spreading across the full chest as natural focal point", "crimson phoenix"),
 ("koi sakura", "BLAZING CRIMSON koi ascending spiral full torso both legs neck to ankle, VIVID PINK sakura petal cascade filling every gap", "crimson koi"),
 ("chrysanthemum", "BLAZING DEEP GOLD chrysanthemum blooms enormous layered petals full torso both legs neck to ankle, VIVID EMERALD leaf lattice filling every gap", "gold chrysanthemum"),
 ("wisteria", "BLAZING ELECTRIC VIOLET wisteria cascading full torso both legs neck to ankle", "violet wisteria"),
 ("plum crane", "BLAZING VIVID CRIMSON plum blossom storm full torso both legs neck to ankle, VIVID GOLD crane pair soaring filling every gap", "crimson plum"),
 ("peony", "BLAZING VIVID PINK peony blooms cascading full torso both legs neck to ankle, ELECTRIC GOLD centre highlights filling every gap", "pink peony"),
]

POSES = [
 "strong hip pop right, both hands pressing sides of hips outward simultaneously arching back to extreme",
 "full frontal wide stance, both fists pressing outer hips outward to absolute maximum",
 "standing full height, both arms slightly spread commanding the frame",
 "back three-quarter turned, face over shoulder direct eye contact, bubble butt projected backward",
 "strong hip pop left, both hands pressing outer hips outward arching back to extreme",
 "full frontal, both hands framing the face, chin raised",
 "three-quarter angle, one hand on the outer hip, the other raised overhead",
]

AGES = ["early 20s","late 20s","early 30s","mid 30s","late 30s","mid 40s","early 50s","mid 50s"]
HAIRS = ["long sleek jet-black hair cascading past hips","silver-white natural hair swept into a high sculpted crown",
         "long straight platinum-silver hair past her hips","silver-white locs cascading to her waist",
         "loose beach waves mid-length tousled","blunt collarbone-length bob thick heavy",
         "curtain bangs long straight hair sweeping past the shoulders","two thick goddess braids"]
SHOE_COLORS = ["gold crimson","crimson gold","violet gold","pink gold","emerald gold","gold emerald","silver crimson"]

NUM_WORD = {4:"FOUR",5:"FIVE",6:"SIX",7:"SEVEN",8:"EIGHT",9:"NINE",10:"TEN"}
ASPECT = {4:"4:5",5:"5:4",6:"16:9",7:"16:9",8:"16:9",9:"16:9",10:"16:9"}
LABELS10 = ["#1","#2","#3","#4","#5","#6","#7","#8","#9","#10"]

def person_block(idx, label, rnd):
    phy_desc, phy_detail, phy_name = PHYSIQUES[idx % len(PHYSIQUES)]
    motif_name, motif_ink, shoe_tip = MOTIFS[idx % len(MOTIFS)]
    pose = POSES[idx % len(POSES)]
    age = AGES[rnd.randrange(len(AGES))]
    hair = HAIRS[rnd.randrange(len(HAIRS))]
    shoe_color = SHOE_COLORS[idx % len(SHOE_COLORS)]
    block = (f"{label}: THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {phy_desc} THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {hair} — full body {motif_name} irezumi covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Bold black ink outlines — {motif_ink}, STARK WHITE highlight detail filling every remaining gap, NO airbrush NO gradient wash. Pose: {pose} — most extreme {phy_name} silhouette ever displayed.\n"
             f"{label}: {shoe_color} platform boots 8 inch, extra long stiletto nails {shoe_tip} tips.")
    return block, phy_name

def build(n, seed):
    rnd = random.Random(seed)
    labels = LABELS10[:n]
    blocks = []
    phynames = []
    for i in range(n):
        block, phy = person_block(i, labels[i], rnd)
        blocks.append(block)
        phynames.append(phy)
    body = "\n\n".join(blocks)
    aspect = ASPECT[n]
    p = f"""Professional fashion photograph, full body shot. {NUM_WORD[n]} women standing side by side.

{body}

All: extreme high-gloss oil. MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. CRITICAL: all {n} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere. {NUM_WORD[n]} completely different extreme physiques — {', '.join(phynames)} — must CONTRAST and DOMINATE every inch of frame. 8K {aspect} aspect ratio, significantly wider than tall if landscape."""
    return p, phynames

OUT = []
for n in range(4, 11):
    for v in range(2):
        p, phynames = build(n, seed=n*100+v)
        check(f"{n}_{v}", p)
        OUT.append((n, v+1, phynames, p))

for n,v,phynames,p in OUT:
    print(f"{n}인#{v}:", len(p.split()))

L = ["# LumineX · 이레즈미 전용 — 4~10인 각 2개(HOF 스타일)\n"]
for n,v,phynames,p in OUT:
    L.append(f"## {n}인 #{v} ({', '.join(phynames)})\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_Irezumi_4to10_2Each.md","w",encoding="utf-8").write("\n".join(L))
print("saved")
