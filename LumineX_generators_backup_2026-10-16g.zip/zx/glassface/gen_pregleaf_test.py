# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_goldleaf_test.py', encoding='utf-8').read().split("\nspecs = [")[0])      # make_struct, LEAF, leaf_hz, person_pm 계열 상수·함수, 덮어쓰기
rnd.seed(20261024)

def person_pl(label, makeup, bodykey, n, kind, shape, solo):
    nat, fa = face_nohair(makeup)
    row = rnd.randrange(len(D["makeup"]))
    age = AGE_EN_FULL[D["age"][row]]; vibe = VIBE_EN_FULL[D["vibe"][row]]; shoe = SHOE_EN_FULL[D["shoe"][row]]
    pierce = pierce_phrase(D["pierce_p"][row],D["pierce_c"][row],D["pierce_g"][row],D["pierce_f"][row],D["pierce_s"][row],D["pierce_m"][row])
    jewelry = f"{JQ_SHORT[D['jq'][row]]} of {JMETAL_EN[D['jmetal'][row]]} {JTYPE_EN[D['jtype'][row]]}"
    hair = f"{HAIR_COLOR_EN_FULL[rnd.choice(T.HAIR_COLOR)]} hair styled in {HAIR_EN_FULL[rnd.choice(T.HAIR_STYLE)]}"
    bodytext = ALL_PREG[bodykey].replace("a high, smoothly rounded pregnant belly", f"a high, smoothly rounded pregnant belly, {BELLY_BOOST},", 1)
    pose = rnd.choice(POSES); cols = rnd.sample(list(LEAF), n)
    texts = [f"applied {c} metallic leaf, thin irregular sheets laid onto the contour of her body with fine natural creases and overlapping seams, a bright {c} sheen filling every gap" for c in cols]
    pre, reg, lab = make_struct(kind, n, shape); assert sens_count(pre+" "+" ".join(reg)) == 0
    sents = " ".join(f"Region {i+1} is {reg[i]}: it carries {texts[i]}." for i in range(n))
    body = (f"{'Full body covered' if solo else 'Covered'} in applied metallic leaf in {n} different colours instead of ordinary skin below the collarbones, each colour claiming its own region of her figure, covering every inch from neck to ankle without exception, the leaf reading as one continuous second skin with no gaps. "
            f"{pre} {sents} {leaf_hz(shape, STRUCT_KIND[kind])} The leaf of every region curves fully around her belly like contour lines circling a globe, the rounded surface of her belly staying fully covered as part of whichever region it falls in, with the same density continuing in full strength over her bust, nowhere on her body left bare, no fabric no seam no garment anywhere. ")
    head = f"{nat} woman, an adult, in her {age}, {vibe} expression" if solo else f"{label}: {nat}, in her {age}, {vibe} expression"
    block = (f"{head}, warm radiant skin tone, extraordinarily large pregnant physique far beyond any real person — {bodytext} Her face is a real living adult face, {fa}, {hair}, real pores, real living eyes, {pierce}, wearing {jewelry}. {body}Pose: {pose}, " +
             (f"her whole silhouette filling the frame from head to her {shoe}, the platform soles rising far higher than her ankle bone." if solo else f"her {shoe}, the platform soles rising far higher than her ankle bone."))
    return block, f"{STRUCT_KO[kind]}·{'물결' if shape=='undulating' else '매끈'}", f"{bodykey}/{makeup}", "+".join(LEAF[c] for c in cols)

def build_pl(g, n, mk):
    cells = draw_cells(g); bodies = rnd.sample(STABLE_BODIES, g); blocks=[]; descs=[]
    for i in range(g):
        b, st, who, cs = person_pl(f"#{i+1}", mk[i], bodies[i], n, cells[i][0], cells[i][1], g==1)
        blocks.append(b); descs.append(f"[{st} / {who} / {cs}]")
    if g == 1:
        p = (f"Professional fashion photograph, full body shot. ONE woman standing or kneeling as described.\n\nSubject: {blocks[0]}\n\nBackground: a plain seamless deep-charcoal backdrop, nothing else in frame. Lighting: a single hard key light raking in from one side, sharp focus head to toe, realistic photographic grain, a real photograph not an illustration not CGI not a render. Pattern density maximum, zero bare skin from neck to ankle. 2:3 vertical 8K portrait, taller than it is wide.")
    else:
        p = (f"Professional fashion photograph, full body shot. {NW[g]} women standing side by side, each an extraordinarily large pregnant woman, far beyond any real person.\n\n" + "\n\n".join(blocks) +
             f"\n\nBackground: a plain seamless deep-charcoal backdrop, nothing else in frame. Composition: each woman's own pose as described, inner arms not crossing her neighbours, generous spacing so every figure reads clearly. Lighting: a single hard key light raking across all of them from one side, sharp focus head to toe on each, realistic photographic grain, a real photograph not an illustration not CGI not a render. Pattern density maximum, zero bare skin from neck to ankle on any of them. Shot on a Hasselblad X2D, {ASPECT[g]} aspect ratio, 8K.")
    return p, " ; ".join(descs)

specs = [(1,3),(1,5),(2,4),(2,6),(3,3),(3,4)]
MK = rnd.sample(T.MAKEUP_48, 12); items=[]; k=0
for g,n in specs:
    p, desc = build_pl(g, n, MK[k:k+g]); k += g; p = fix(p); check("pl", p, allow_uv=False, mat=True)
    assert f"Region {n}" in p and "metallic leaf" in p
    items.append((g, n, desc, p))
order=list(range(6)); rnd.shuffle(order); no={i:order.index(i)+1 for i in range(6)}; ranked=sorted(range(6), key=lambda i:no[i])
GN={1:"솔로",2:"듀오",3:"트리오"}
L=["# LumineX · 임산부 몸에 금박 색 혼합 시험 6개\n",
   "임산부 문장 구조에 금박 색 혼합을 넣었습니다. 색 수는 이미지 전체 구역 수가 12개 이하가 되게 했습니다(앞선 금박 시험에서 확인된 한도). 번호는 섞여 있습니다. **성공/실패만** 알려주세요(최대 3회, 1회/2회/3회/실패). 예: `03: 2회 / 05: 실패 / 나머지 1회`\n",
   "## 색인\n","| 번호 | 인원 | 색 수 | 구성 (구조·경계선 / 체형 / 메이크업 / 금박 색) |","|---|---|---|---|"]
for i in ranked:
    g,n,desc,p = items[i]; L.append(f"| {no[i]:02d} | {GN[g]} | {n}색 | {desc} |")
L.append("")
for i in ranked:
    g,n,desc,p = items[i]; L.append(f"## {no[i]:02d}. {GN[g]} {n}색\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_PregGoldLeaf_Test_6.md","w",encoding="utf-8").write("\n".join(L))
json.dump([{"no":no[i],"gsize":items[i][0],"n":items[i][1],"desc":items[i][2]} for i in ranked], open("/home/claude/pregleaf_meta.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
print("6개 저장")
for i in ranked: print(f"  {no[i]:02d} {GN[items[i][0]]} {items[i][1]}색 (전체 {items[i][0]*items[i][1]}구역) {len(items[i][3].split()):>4}단어 | {items[i][2][:85]}")
