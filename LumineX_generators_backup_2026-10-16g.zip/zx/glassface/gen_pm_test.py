# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_final3.py', encoding='utf-8').read().split("\n# ================= A.")[0])     # 덮어쓰기(꽃·수정·팔올림 제외)·build_mix·build_pm·build_A·fix·check
rnd.seed(20261018)
items=[]
def add(g, n, desc, p, mat=True):
    p = fix(p); check("t", p, allow_uv=True); items.append((g, n, desc, p))
# 솔로 3개: 임산부 2, 맥시멀리스트 1
for n in (3,4):
    p, d = build_pm(1, n, rnd.sample(T.MAKEUP_48,1)); add(1, n, "[임산부 " + d.strip("[]").replace("[","").replace("]","") + "]", p)
p, d, am = build_A(1, 3); add(1, 3, "[맥시 " + d[0] + " / " + "+".join(MAT_KO[m] for m in am[0]) + "]", p)
# 듀오 4개, 트리오 5개: 임산부·맥시멀리스트 혼합
for tracks,n in [(["임산부","맥시"],3),(["맥시","임산부"],4),(["임산부","맥시"],4),(["맥시","맥시"],3),
                 (["임산부","맥시","맥시"],3),(["임산부","임산부","맥시"],4),(["맥시","임산부","맥시"],3),(["임산부","맥시","임산부"],4),(["맥시","임산부","임산부"],3)]:
    p, d = build_mix(tracks, n); add(len(tracks), n, d, p)
order=list(range(12)); rnd.shuffle(order); no={i:order.index(i)+1 for i in range(12)}; ranked=sorted(range(12), key=lambda i:no[i])
GN={1:"솔로",2:"듀오",3:"트리오"}
L=["# LumineX · 임산부·맥시멀리스트 재질 혼합 시험 12개 (일반인 제외, 꽃·수정·팔 올린 자세 제외)\n",
   "솔로 3개(임산부 2·맥시멀리스트 1), 듀오 4개, 트리오 5개입니다. 재질은 인물마다 3~4종이고, 꽃(보태니컬)·수정(크리스탈)·팔 올린 자세는 뺐으며 UV네온은 맥시멀리스트에게만 넣었습니다. 번호는 섞여 있습니다. **성공/실패만** 알려주세요(최대 3회, 1회/2회/3회/실패). 예: `03: 2회 / 07: 실패 / 나머지 1회`\n",
   "## 색인\n","| 번호 | 인원 | 구역 수 | 구성 (트랙 구조·경계선 / 체형 / 메이크업 / 재질) |","|---|---|---|---|"]
for i in ranked:
    g,n,desc,p = items[i]; L.append(f"| {no[i]:02d} | {GN[g]} | {n} | {desc} |")
L.append("")
for i in ranked:
    g,n,desc,p = items[i]; L.append(f"## {no[i]:02d}. {GN[g]} {n}구역\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_PregMax_Test_12.md","w",encoding="utf-8").write("\n".join(L))
json.dump([{"no":no[i],"gsize":items[i][0],"n":items[i][1],"desc":items[i][2]} for i in ranked], open("/home/claude/pregmax_test_meta.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
print("12개 저장")
for i in ranked: print(f"  {no[i]:02d} {GN[items[i][0]]} {items[i][1]}구역 {len(items[i][3].split()):>4}단어 | {items[i][2][:90]}")
