# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_stage2_test.py', encoding='utf-8').read().split("\nspecs = [")[0])        # make_structure, hz, art 관련, assemble, validate ...
exec(open('gen_matblend_geo.py', encoding='utf-8').read().split("\nold = {")[0])           # pick_mats, mat_text, hazy_mat, PHYS ...
rnd.seed(20261013)
def pct(lo, hi, step=1): return rnd.randrange(lo, hi+1, step)
DUPFIX = re.compile(r"\b(VIVID|BLAZING|extreme|dense|formations) \1\b")
def dd(t):
    while True:
        t, n = DUPFIX.subn(r"\1", t)
        if not n: return t

ALT = " The regions alternate between 2 {what} in a repeating order."
def alt_seq(n): return [i % 2 for i in range(n)]
KINDKEY = {"H":"band","V":"band","D":"diag","C":"conc","R":"rad"}

def region_sents(reg, seq, texts, verb):
    first={}; out=[]
    for i,pi in enumerate(seq):
        if pi in first: out.append(f"Region {i+1} is {reg[i]}: it {verb} the same {'pattern' if verb=='is painted in' else 'material'} as Region {first[pi]+1}.")
        else: first[pi]=i; out.append(f"Region {i+1} is {reg[i]}: it {verb} {texts[pi]}.")
    return " ".join(out)

# ---------- 공예(바디페인팅) ----------
def craft_art(n, kind, shape):
    pre, reg, lab = make_structure(kind, n, shape); assert sens_count(pre+" "+" ".join(reg)) == 0
    crafts = rnd.sample(T.CRAFTS_39, 2); texts=[]
    for c in crafts:
        cn,cd,cb,cf = CRAFT_DB_FULL[c]
        texts.append(f"{cn} ({cd}), wide {cb} bands following the contours of the body, with {cf} filling the space between bands")
    art = (f"Her bare skin is painted with 2 different traditional patterns repeated across {n} regions of her figure. {pre}{ALT.format(what='patterns')} {region_sents(reg, alt_seq(n), texts, 'is painted in')} {hz(shape, KINDKEY[kind])} Pigment on living skin throughout, covering every inch of her body below the jaw with no bare skin anywhere, face unpainted.")
    return art, f"{STRUCT_KO[kind]} {n}구역·{'물결' if shape=='undulating' else '매끈'}", "+".join(crafts)

def craft_person(label, makeup, bodykey, n, kind, shape):
    art, st, cr = craft_art(n, kind, shape)
    nat, fa = face_nohair(makeup)
    age = AGE_EN_FULL[rnd.choice(T.AGE_12)]; vibe = VIBE_EN_FULL[rnd.choice(T.VIBE_5)]
    hs = HAIR_EN_FULL[rnd.choice(T.HAIR_STYLE)]; hc = HAIR_COLOR_EN_FULL[rnd.choice(T.HAIR_COLOR)]
    nail = f"{NAIL_SHAPE_EN_FULL[rnd.choice(T.NAIL_SHAPES)]} nails, {NAIL_FIN_EN_FULL[rnd.choice(T.NAIL_FINISH)]} finish"
    pose = POSE_EN_FULL[rnd.choice(FRONT_POSES)]; shoe = SHOE_EN_FULL[rnd.choice(T.SHOES_24)]
    subj = f"a real adult {nat} woman in her {age}, her face exactly the same tone as her body, real skin texture with visible pores and fine grain, {fa}, {vibe}, {hc} hair styled in {hs}, real living eyes. Long {nail}."
    skin = "Skin: Real photographic skin — visible pores and fine grain, a smooth taut surface with natural creases and shadow only where the flesh folds. No smooth illustration finish, no plastic CG sheen."
    if label is None:
        txt = (f"Subject: ONE real adult {subj[len('a real adult '):]}\n\nPhysique: {cap(BODY_FULL[bodykey])}\n\n{skin}\n\nBody Art: {art}\n\nPose: {pose}, every region clearly visible to the camera.\n\nFootwear: {shoe}, painted with the blended patterns following the same soft transitions as her skin.")
    else:
        txt = (f"{label} woman: {subj}\n\n{label} woman's physique: {cap(BODY_FULL[bodykey])}\n\n{label} woman's body art: {art}\n\n{label} woman's pose: {pose}, every region clearly visible to the camera.\n\n{label} woman's footwear: {shoe}, painted with the blended patterns following the same soft transitions as her skin.")
    return txt, st, cr

def craft_prompt(gsize, n, kinds, makeups, bodies):
    blocks=[]; descs=[]
    for i in range(gsize):
        b, st, cr = craft_person(None if gsize==1 else ["Left","Center","Right"][i], makeups[i], bodies[i], n, kinds[i], rnd.choice(["smooth","undulating"]))
        blocks.append(b); descs.append(f"[{st} / {bodies[i]} / {makeups[i]} / {cr}]")
    body="\n\n".join(blocks)
    if gsize == 1:
        p=(f"Image format: a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide.\n\nA full-body photograph with a plain seamless deep-charcoal backdrop, shot on a medium format camera with an 85mm lens at f/8, a single hard key light raking in from one side, sharp focus from head to toe, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n{body}\n\nBackground & Lighting: the blended painted patterns reading crisp against her skin, the hard raking light carving every fold and curve.\n\nVertical 2:3 portrait-orientation full-body photograph, taller than it is wide. portrait 2:3 vertical.")
    else:
        p=(f"Image format: a landscape-orientation photograph, {ASP[gsize]} aspect ratio.\n\nA photograph of {NW[gsize]} women standing side by side on a plain seamless deep-charcoal backdrop, nothing else in the frame, 50mm lens at f/8, a single hard key light raking across all of them from one side, sharp focus head to toe on each — a real photograph, not an illustration, not CGI, not a render.\n\n{body}\n\nComposition: each woman's own pose as described, inner arms not crossing her neighbours, all faces toward the camera.\n\nLighting: the blended painted patterns reading crisp against each woman's skin, the hard raking light carving every fold and curve. Shot on a Hasselblad X2D, {ASP[gsize]} 8K.")
    return p, " ; ".join(descs)

# ---------- 재질(맥시멀리스트) ----------
def mat_person_alt(label, n, kind, shape, phys, hair, age, pose):
    mats = pick_mats(2); texts = [mat_text(m)[0] for m in mats]
    pre, reg, lab = make_structure(kind, n, shape); assert sens_count(pre+" "+" ".join(reg)) == 0
    sents = region_sents(reg, alt_seq(n), texts, "carries")
    uv = "uvneon" in mats
    light = " A standard hard key light illuminates most of her body; a separate dedicated UV blacklight illuminates the UV-reactive region specifically, making it glow at full intensity while the rest reads under normal light." if uv else ""
    pn, pd = phys; prefix = f"{label}: " if label else ""
    txt = (f"{prefix}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair} — her body carries 2 different materials repeated across {n} regions of her figure. {pre}{ALT.format(what='materials')} {sents} {hazy_mat(shape, KINDKEY[kind])}, no fabric no seam no garment anywhere, every material fused to or erupting from her own living skin, covering her completely with no bare skin anywhere from neck to ankle. Pose: {pose}, every region clearly visible to the camera — most extreme {pn} silhouette ever displayed.{light}\n"
           f"{prefix}extreme platform heels/boots blending the relevant materials at her feet, extra long nails each matching whichever region that hand falls in.")
    return txt, f"{STRUCT_KO[kind]} {n}구역·{'물결' if shape=='undulating' else '매끈'}", "+".join(MAT_KO[m] for m in mats), pn

def mat_prompt(gsize, n, kinds):
    phys = rnd.sample(PHYS, gsize); hairs = rnd.sample(HAIRS_MX, gsize); ages = rnd.sample(AGES_MX, gsize)
    blocks=[]; descs=[]
    for i in range(gsize):
        b, st, ms, pn = mat_person_alt(["#1","#2","#3"][i] if gsize>1 else None, n, kinds[i], rnd.choice(["smooth","undulating"]), phys[i], hairs[i], ages[i], rnd.choice(POSES_MX))
        blocks.append(b); descs.append(f"[{st} / {pn} / {ms}]")
    body="\n\n".join(blocks)
    tail = ("MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. ONE woman only. Extreme macro detail on every material and every blended transition. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle." if gsize==1 else
            f"Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.\nAll: Extreme macro detail on every material and every blended transition. CRITICAL: all {gsize} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere. {NW[gsize]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame.")
    p=(f"Professional fashion photograph, full body shot. {NW[gsize]} wom{'a' if gsize==1 else 'e'}n standing{' side by side, each with her own multi-material blended body' if gsize>1 else ''}.\n\n{body}\n\n{tail} 8K portrait {ASP[gsize]} aspect ratio.")
    return p, " ; ".join(descs)

mk = rnd.sample(T.MAKEUP_48, 6); bd = rnd.sample(VOLBODY, 6)
specs = [("공예",1,3,["C"]),("재질",1,4,["H"]),("공예",2,4,["D","R"]),("재질",2,3,["V","C"]),("공예",3,3,["H","C","V"]),("재질",3,4,["D","R","H"])]
items=[]; mi=0
for track,gs,n,kinds in specs:
    if track=="공예":
        p, desc = craft_prompt(gs, n, kinds, mk[mi:mi+gs] if gs<=len(mk)-mi else rnd.sample(T.MAKEUP_48,gs), rnd.sample(VOLBODY, gs)); mi=(mi+gs)%4
    else:
        p, desc = mat_prompt(gs, n, kinds)
    p = dd(p); validate(f"alt_{track}_{gs}", p)
    assert not [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", p) if m.group(1).lower() not in ("had","that")], desc
    assert "the same" in p and "alternate between 2" in p
    items.append((track, gs, n, desc, p))
order=list(range(6)); rnd.shuffle(order); no={i:order.index(i)+1 for i in range(6)}; ranked=sorted(range(6), key=lambda i:no[i])
GN={1:"솔로",2:"듀오",3:"트리오"}
L=["# LumineX · 2혼합 되살리기 시험 6개 (패턴·재질 2종을 3~4구역에 번갈아 배치)\n",
   "공예(바디페인팅)와 재질을 솔로·듀오·트리오 1개씩 넣었습니다. 패턴(재질)은 2종이고 구역은 3~4개이며, 구역마다 A, B, A(, B) 순서로 번갈아 칠합니다. **성공/실패만** 알려주세요(최대 3회, 1회/2회/3회/실패). 예: `03: 2회 / 05: 실패 / 나머지 1회`\n",
   "## 색인\n","| 번호 | 구분 | 인원 | 구역 수 | 구성 (구조·경계선 / 체형 / 메이크업 / 구성) |","|---|---|---|---|---|"]
for i in ranked:
    t,gs,n,desc,p=items[i]; L.append(f"| {no[i]:02d} | {t} | {GN[gs]} | {n} | {desc} |")
L.append("")
for i in ranked:
    t,gs,n,desc,p=items[i]; L.append(f"## {no[i]:02d}. {t} · {GN[gs]} {n}구역\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_TwoMix_Alt_Test_6.md","w",encoding="utf-8").write("\n".join(L))
print("6개 저장")
for i in ranked: print(f"  {no[i]:02d} {items[i][0]} {GN[items[i][1]]} {items[i][2]}구역 | {len(items[i][4].split())}단어 | {items[i][3][:105]}")
