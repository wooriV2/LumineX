# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
src = open('gen_matblend_geo_test.py', encoding='utf-8').read().split("\nitems=[]")[0]
exec(src)
rnd.seed(20261601)
NEWM = ["chrome", "rhine", "proj", "splash"]
MAT_KO.update({"chrome": "크롬", "rhine": "라인스톤", "proj": "프로젝션", "splash": "스플래시"})
_mt0 = mat_text
CHR = [("silver", "pale blue and warm white"), ("rose-gold", "warm pink and amber")]
RHI = [("aurora-borealis", "clear aurora-borealis rhinestones flashing blue, pink and green"), ("hot-pink", "hot-pink rhinestones"), ("jet-black", "jet-black rhinestones")]
PRJ = [("cyber grid", "electric cyan and magenta neon grid lines and geometric shapes"), ("kaleidoscope", "violet, gold and teal kaleidoscope mandala patterns"), ("water caustic", "deep blue and turquoise rippling water-caustic light")]
SPL = [("magenta-cyan", "hot magenta", "electric cyan", "yellow"), ("yellow-blue", "sunny yellow", "deep ultramarine-blue", "orange")]
def mat_text(key):
    if key == "chrome":
        c, a = rnd.choice(CHR)
        return f"a seamless liquid-metal {c} chrome shell fused to her form, perfect mirror finish reflecting the surroundings in sharp warped images over every curve, BLAZING flawless mirror {c} chrome, VIVID {a} reflections", f"{c} chrome"
    if key == "rhine":
        n, b = rnd.choice(RHI)
        return f"thousands of tiny faceted rhinestone crystals packed tightly together directly onto her skin with no skin showing between them, stones overlapping at random angles in thick layers, each stone with its own sharp star-shaped glint, BLAZING {b}, VIVID a few larger clear stones scattered among them", f"{n} rhinestone"
    if key == "proj":
        n, b = rnd.choice(PRJ)
        return f"animated light patterns projected from unseen projectors onto her skin, luminous with crisp edges and slightly warped over every bulge, BLAZING {b}, VIVID bright white pulses of light", n
    if key == "splash":
        n, c1, c2, c3 = rnd.choice(SPL)
        return f"thick wet paint splashed and splattered in overlapping layers until no skin shows, a continuous glossy coat with heavy drips running down every curve, BLAZING {c1} and {c2} paint, VIVID a few splashes of bright {c3} and white paint", n
    return _mt0(key)
def pick_mats(n):
    while True:
        k = rnd.choice(NEWM)
        rest = rnd.sample([m for m in MATKEYS if m not in NEWM], n - 1)
        mats = [k] + rest; rnd.shuffle(mats)
        if {"stone", "wood"} <= set(mats): continue
        return mats
items = []
for gsize, n in [(1, 3), (2, 3), (3, 3)]:
    for attempt in range(50):
        p, descs = build_mat(gsize, n)
        if not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p): break
    validate(f"nb_{gsize}_{n}", p)
    items.append((gsize, n, " ; ".join(f"[{d}]" for d in descs), p))
GN = {1: "솔로", 2: "듀오", 3: "트리오"}
L = ["# 재질 블렌드(1인 몸 구역별 재질 섞기) + 새 영역 4종 — 솔로 · 듀오 · 트리오 (3혼합)\n", "기존 Material Blend 틀(검은 배경, 구역 구조, 경계 흐림) 그대로이고 재질 목록에 크롬·라인스톤·프로젝션·스플래시만 추가했습니다. 번호별로 정상/이상만 알려주세요. 이상이면 한 줄만요.\n"]
for i, (gs, n, desc, p) in enumerate(items, 1):
    L.append(f"## {i}. {GN[gs]} {n}혼합 · {desc}\n\n```\n{p}\n```\n")
open("/mnt/user-data/outputs/LumineX_MatBlend_New4_Solo_Duo_Trio3.md", "w", encoding="utf-8").write("\n".join(L))
for gs, n, desc, p in items: print(GN[gs], len(p.split()), desc[:200])
