# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_pierce_face.py', encoding='utf-8').read().split("\nspecs = [")[0])     # pierce_text·CARE·gem_text·pick_metal·EXPOSED·MN·...
rnd.seed(20261108)
NUMW = {"P8": "eight", "P25": "twenty-five"}
def text_def(P, M, f): return pierce_text(P, M, f)
def text_count(P, M, f):
    m = MN[M]; n = NUMW[P]
    return f"Exactly {n} {m} piercings in total, each separate piece counted on its own, placed freely across her ears and face wherever they look best."
def text_conc(P, M, f):
    m = MN[M]; e = ear_noun(f); e2 = ear_noun(f)
    if P == "P8":
        return (f"All eight piercings gather on the left side of her face, and the right side stays bare: on the left ear five pieces — a big {m} {e} in the lobe, two smaller {m} rings above it, a thick {m} bar and a small {m} stud at the top; "
                f"two thin {m} bars pass through the outer end of the left eyebrow; a small {m} ring passes through the left nostril.")
    return (f"All twenty-five piercings gather mostly on the left side of her face, and the right side stays almost bare: on the left ear eight pieces — a big {m} {e} in the lobe, three smaller {m} rings above it, two thick {m} bars and two small {m} studs up to the top; "
            f"one small {m} stud sits in the right ear; four thin {m} bars pass through the outer half of the left eyebrow; two small {m} rings pass through the left nostril and a thick {m} septum ring hangs below the nose; "
            f"a {m} hoop passes through the left edge of the lower lip with a {m} snake-bite ring beside it and a small {m} ring at the left edge of the upper lip; a {m} Medusa stud sits above the lips; a {m} labret stud and a small {m} ring sit on the chin; three small {m} studs run along the left jaw.")
METHODS = [("정의형", text_def), ("개수만", text_count), ("비대칭 집중형", text_conc)]
def face_attrs():
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC)+1)
    return dict(mk=mk, nat=nat, fa=fa, si=si, ci=ci, M=pick_metal(ci), G=rnd.choice(GEMS), F=rnd.choice(FORMS))
def assemble(a, pierce):
    hair = f"{HAIR_COLOR_EN_FULL[HC[a['ci']-1]]} hair styled in {HAIR_EN_FULL[HS[a['si']-1]]}"
    M = a["M"]; metal_phrase = "mixed metal (yellow gold, silver, copper and rose gold, alternating piece by piece)" if M == "MX" else ("rose gold" if M == "MR" else MN[M].replace("-", " "))
    p = (f"Professional fashion photograph, close-up beauty portrait. ONE woman, facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp. Mid 20s.\n\n"
         f"Subject: A real photograph of a strikingly beautiful adult {a['nat']} woman — {a['fa']}, {hair}. Real pores and fine skin grain, real living eyes with bright catchlights and genuine depth, individual hair strands catching the light — a photograph of a real face, not an illustration, not a render, not cel-shaded.\n\n"
         f"Piercings: {pierce}{gem_text(a['G'])} {CARE.format(metal=metal_phrase)}\n\n"
         f"Lighting: a soft frontal beauty light on the face with a thin cool rim light along the hair, pure pitch black void background, shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait.")
    p = dd(p).replace(",,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p)
    return p
items = []
for P in ["P8", "P25"]:
    a = face_attrs()
    for mname, fn in METHODS:
        items.append((P, mname, assemble(a, fn(P, a["M"], a["F"])), a))
order = list(range(6)); rnd.shuffle(order); no = {i: order.index(i)+1 for i in range(6)}; ranked = sorted(range(6), key=lambda i: no[i])
def d(a): return f"{re.sub(r'^[A-Z]+', '', HS[a['si']-1])} · {re.sub(r'^[A-Z]+', '', HC[a['ci']-1])} · 메이크업 {a['mk']} · 금속 {MKO[a['M']]}·보석 {GKO[a['G']]}"
L = ["# LumineX · 피어싱 개수 방식 비교 시험 (6개, 정면 얼굴 컷)\n",
     "P8과 P25에서 **같은 얼굴**(메이크업·헤어·헤어컬러·금속·보석)에 지시 방식만 바꿨습니다. **정의형**은 부위별로 개수를 정해 준 지금 방식, **개수만**은 총 개수만 쓰고 위치는 맡긴 방식, **비대칭 집중형**은 총 개수를 한쪽(왼쪽)에 몰아서 쓴 방식입니다. 번호는 섞여 있습니다. 지난번처럼 **피어싱 개수만 세어서** 알려주세요. 예: `1: 9개 / 2: 7개 ...` (비대칭 집중형은 한쪽으로 몰렸는지 O/X도 함께). 생성이 안 되면 `실패`.\n",
     "## 색인\n", "| 번호 | 단계 | 방식 | 얼굴 구성 (같은 단계끼리 동일) |", "|---|---|---|---|"]
for i in ranked: P, m, p, a = items[i]; L.append(f"| {no[i]:02d} | {P} | {m} | {d(a)} |")
L.append("")
for i in ranked: P, m, p, a = items[i]; L += [f"## {no[i]:02d}. {P} · {m}\n", "```", p, "```\n"]
open("/tmp/rep_out/LumineX_Pierce_Method_Compare_6.md", "w", encoding="utf-8").write("\n".join(L))
print("6개 저장")
for i in ranked: P, m, p, a = items[i]; print(f"  {no[i]:02d} {P:<3} {m:<8} {len(p.split()):>3}단어")
print("P8 얼굴:", d(items[0][3])); print("P25 얼굴:", d(items[3][3]))
