# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re, json, sys

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m

CAT_GF = "🏺 Living Artifact · Glass Face 3-Split"
CAT_RF = "🏺 Living Artifact · Real Face Piercing"
CAT_VB = "🏺 Living Artifact · Vessel Body"
CAT_DS = "🏺 Living Artifact · Duo Statue"
CAT_SC = "🏺 Living Artifact · Glass Face Scene"

ITEMS = []
def add(key, title, cat, prompt, ratio="2:3"):
    ITEMS.append({"key": key, "title": title, "category": cat, "platform": "gemini", "aspect_ratio": ratio, "prompt": prompt.strip()})

def parse_md(path):
    s = open(path, encoding="utf-8").read()
    out = []
    for m in re.finditer(r'^### (.+?)\n\n```\n(.*?)\n```', s, flags=re.M | re.S):
        out.append((m.group(1).strip(), m.group(2).strip()))
    return out

OUT = "/tmp/rep_out/"
# ---- Glass Face 가슴 37 ----
bust = parse_md(OUT + "LumineX_GlassFace_bust_37prompts_v1.md")
assert len(bust) == 37, len(bust)
for head, p in bust:
    nn = head.split(".")[0].strip()
    add(f"la_glassface_bust_{nn}", f"Glass Face 가슴 {head}", CAT_GF, p)
# ---- 허리·힙 20 ----
wh = parse_md(OUT + "LumineX_GlassFace_waist_hip_20prompts_v1.md")
assert len(wh) == 20, len(wh)
for head, p in wh:
    code = head.split(".")[0].strip()      # W01 / H01
    frame = "waist" if code.startswith("W") else "hip"
    fname = "허리" if frame == "waist" else "힙"
    add(f"la_glassface_{frame}_{code[1:]}", f"Glass Face {fname} {code[1:]}. {head.split('.',1)[1].strip()}", CAT_GF, p)
# ---- 전신 6 ----
g4 = load("g4", "gen4.py")
for i, x in enumerate(g4.OUT, 1):
    add(f"la_glassface_full_{i:02d}", f"Glass Face 전신 {i:02d} · {x[0]} · {x[1]} · {x[2]} × {x[3]}", CAT_GF, x[4])
# ---- 가슴 피어싱 7, 허리 피어싱 7 (투명 몸) ----
g18 = load("g18", "gen18.py")
for t, sty, bn_, an, bn, l, p in g18.OUT:
    add(f"la_glassface_bustp_{t.lower()}", f"Glass Face 가슴 피어싱 {t} · {sty} · {bn_} · {an} × {bn}", CAT_GF, p)
g19 = load("g19", "gen19.py")
for t, sty, bn_, an, bn, l, p in g19.OUT:
    add(f"la_glassface_waistp_{t.lower()}", f"Glass Face 허리 피어싱 {t} · {sty} · {bn_} · {an} × {bn}", CAT_GF, p)

# ---- Real Face Piercing ----
g12 = load("g12", "gen12.py")
for t, sty, l, p in g12.OUT:
    add(f"la_realface_gyaru_p{t.lower()}", f"Real Face 갸루 P{t} · {sty} · {l}", CAT_RF, p)
g13 = load("g13", "gen13.py")
kmap = {"8":"p8","25":"p25","50":"p50","100":"p100","150":"p150","K1":"p50c1","K2":"p100c2"}
for t, sty, l, p in g13.OUT:
    add(f"la_realface_korean_{kmap[t]}", f"Real Face 한국 {kmap[t].upper()} · {sty} · {l}", CAT_RF, p)
g15 = load("g15", "gen15.py")
slug = {"코갸루":"kogal","히메갸루":"hime","걸크러시":"girlcrush","야마바":"yamanba"}
for sty, l, p in g15.OUT:
    add(f"la_realface_mouth_p25_{slug[sty]}", f"Real Face 입 안 축 P25 · {sty} · 치아 젬 + 혀 피어싱 · {l}", CAT_RF, p)
g16 = load("g16", "gen16.py")
add("la_realface_mouth_p100_kogal", "Real Face 입 안 축 P100 · 코갸루 · 치아 젬 + 혀 피어싱 · 청동", CAT_RF, g16.p)
g17 = load("g17", "gen17.py")
add("la_realface_mouth_p100_hime", "Real Face 입 안 축 P100 · 히메갸루 · 치아 젬 + 혀 피어싱 · 로즈골드", CAT_RF, g17.p1)
add("la_realface_mouth_p100_yamanba", "Real Face 입 안 축 P100 · 야마바 · 치아 젬 + 혀 피어싱 · 은", CAT_RF, g17.p2)
g32 = load("g32", "gen32.py")
add("la_realface_bust_p100c1", "Real Face 가슴 P100 + C1(참 약 10개) · 코갸루", CAT_RF, g32.A)
add("la_realface_bust_p150c2", "Real Face 가슴 P150 + C2(참 약 20개) · 코갸루", CAT_RF, g32.B)
g31 = load("g31", "gen31.py")
DEPTH = ("Piercing depth: every bar and surface bar is embedded in the skin — its middle runs beneath the skin so only its two end studs show on the surface, "
"the skin between them faintly raised over the hidden bar, with a small warm shadow at each end and nothing lying on top of the skin like a sticker. "
"Every microdermal is an anchored post sunk into the skin with only its small domed top showing and the skin sitting smoothly around its base. "
"Every ring passes through a small healed opening in the skin, the skin visible through the loop, and every stud sits through the skin with its back hidden. "
"Where a bar, ring or stud goes through the ear, the lip, the nostril or the brow, it passes through the real tissue with the skin wrapping snugly around it.")
p200 = g31.OUT[200]
marker = "Pose: body angled 45 degrees"
assert marker in p200
p200 = p200.replace(marker, DEPTH + "\n\n" + marker, 1)
add("la_realface_bust_p200", "Real Face 가슴 P200 · 비주얼계 · 바스트 퀸(실사 몸)", CAT_RF, p200)

# ---- Vessel Body ----
g20 = load("g20", "gen20.py")
add("la_vessel_bust_01", "Vessel Body 가슴 01 · 스칸디 프로스트 · 아쿠아리움 × 테라리움", CAT_VB, g20.P5)
g22 = load("g22", "gen22.py")
add("la_vessel_full_01", "Vessel Body 전신 01 · 웨이쉰 · 콜로설 · 밤하늘 × 심해", CAT_VB, g22.A)
add("la_vessel_full_02", "Vessel Body 전신 02 · 히메갸루 · 아워글래스 USSBBW · 온실 × 겨울 숲", CAT_VB, g22.B)

# ---- Duo Statue (3:4) ----
g21 = load("g21", "gen21.py"); g23 = load("g23", "gen23.py")
def r34(p): 
    assert "2:3 vertical 8K portrait" in p
    return p.replace("2:3 vertical 8K portrait", "3:4 vertical 8K portrait")
add("la_duostatue_hip_01", "Duo Statue 힙 01 · 홍콩풍 · 나전칠기 바디페인팅 × 비취 조각상", CAT_DS, r34(g21.HIP), "3:4")
add("la_duostatue_full_01", "Duo Statue 전신 01 · 화환 화장 · 청화백자 바디페인팅 × 호박 조각상", CAT_DS, r34(g21.FULL), "3:4")
add("la_duostatue_hip_02", "Duo Statue 힙 02 · 락혼 글램 · USSBBW · 라이롯남 × 루비색 유리 조각상", CAT_DS, r34(g23.HIP), "3:4")
add("la_duostatue_full_02", "Duo Statue 전신 02 · 텔레노벨라 · 콜로설 · 이마리 × 에메랄드 조각상", CAT_DS, r34(g23.FULL), "3:4")

# ---- Scene (배경 B / 성장 GP·GA) ----
g24 = load("g24", "gen24.py")
add("la_scene_b1_full_01", "Scene 전신 B1 회색 스튜디오 카우스틱 · 서아프리카 · 자수정 × 호박", CAT_SC, g24.P2)
add("la_scene_gp7_waist_01", "Scene 허리 GP7 재스민·양귀비 · 노르딕 발키리 · 비취 × 호박", CAT_SC, g24.P4)
g25 = load("g25", "gen25.py")
m25 = {"C1":("la_scene_b1_full_02","Scene 전신 B1 회색 스튜디오 카우스틱 · 텔레노벨라 · 코발트 유리 × 시트린"),
       "C2":("la_scene_b2_full_01","Scene 전신 B2 크림색 벽 카우스틱 · 홍콩풍 · 루비색 유리 × 아쿠아마린"),
       "C3":("la_scene_b3_full_01","Scene 전신 B3 프리즘 무지개 · 락혼 · 투명 레진 × 무라노 유리"),
       "V1":("la_scene_gp1_waist_01","Scene 허리 GP1 벚꽃·매화 · 웨이쉰 · 스모키 유리 × 에메랄드"),
       "V2":("la_scene_gp2_bust_01","Scene 가슴 GP2 장미 · 프렌치 레드립 · 빙하 얼음 × 자수정"),
       "V3":("la_scene_gp3_waist_01","Scene 허리 GP3 고사리·라벤더 · 하베샤 · 아쿠아마린 × 호박"),
       "A1":("la_scene_ga1_waist_01","Scene 허리 GA1 새·나비 · 화환 화장 · 호박 × 아쿠아마린")}
for n,t,f,d,p in g25.ITEMS:
    k, ti = m25[n]; add(k, ti, CAT_SC, p)
g26 = load("g26", "gen26.py")
m26 = {"C4":("la_scene_b4_full_01","Scene 전신 B4 반사 바닥 · 파케앙트 · 사파이어 × 카넬리안"),
       "C5":("la_scene_b5_full_01","Scene 전신 B5 창문 빛줄기 · 슬라브 · 비취 × 자수정"),
       "C6":("la_scene_b6_full_01","Scene 전신 B6 청록 벽 그림자 · 요루바 · 루비색 유리 × 호박"),
       "V4":("la_scene_gp4_bust_01","Scene 가슴 GP4 아이비·등나무 · 발칸 · 시트린 × 코발트 유리"),
       "V5":("la_scene_gp5_waist_01","Scene 허리 GP5 해바라기·데이지 · 인스타 · 자수정 × 비취"),
       "V6":("la_scene_gp6_waist_01","Scene 허리 GP6 연꽃·수련 · 소피아 · 아쿠아마린 × 스모키 유리"),
       "A2":("la_scene_ga2_waist_01","Scene 허리 GA2 잠자리·반딧불이 · 스칸디 · 에메랄드 그린 유리 × 사파이어"),
       "A3":("la_scene_ga3_bust_01","Scene 가슴 GA3 벌새·나비 · 텔레노벨라 · 시트린 × 자수정"),
       "A4":("la_scene_ga4_waist_01","Scene 허리 GA4 청개구리·무당벌레 · 서아프리카 · 루비색 유리 × 비취")}
for (n,t,f,d), p in zip(g26.ITEMS, g26.PROMPTS):
    k, ti = m26[n]; add(k, ti, CAT_SC, p)
g27 = load("g27", "gen27.py")
m27 = {"K1":("la_scene_b5gp4_full_01","Scene 전신 B5×GP4 창문 빛줄기 × 아이비·등나무 · 프렌치 레드립"),
       "K2":("la_scene_b4ga2_full_01","Scene 전신 B4×GA2 반사 바닥 × 잠자리·반딧불이 · 브리티시 모드"),
       "K3":("la_scene_b6gp1_full_01","Scene 전신 B6×GP1 청록 벽 × 벚꽃·매화 · 노르딕 발키리")}
for (n,t,c,d), p in zip(g27.ITEMS, g27.PROMPTS):
    k, ti = m27[n]; add(k, ti, CAT_SC, p)

# ---- 검증 ----
keys = [x["key"] for x in ITEMS]
assert len(keys) == len(set(keys)), [k for k in keys if keys.count(k) > 1]
leaks = [x["key"] for x in ITEMS if re.search(r'[\uac00-\ud7a3]', x["prompt"])]
assert not leaks, leaks
ws = [len(x["prompt"].split()) for x in ITEMS]
from collections import Counter
c = Counter(x["category"] for x in ITEMS)
print("total", len(ITEMS)); 
for k, v in c.items(): print(v, k)
print("words min/max", min(ws), max(ws))
json.dump(ITEMS, open("/home/claude/la_glassface_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
