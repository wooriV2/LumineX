# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_pregleaf_test.py', encoding='utf-8').read().split("\nspecs = [")[0])      # make_struct, LEAF, leaf_hz, 덮어쓰기, D·pierce 상수 ...
rnd.seed(20261025)

def person_gl(label, makeup, bodykey, n, kind, shape, solo):
    nat, fa = face_nohair(makeup)
    row = rnd.randrange(len(D["makeup"]))
    age = AGE_EN_FULL[D["age"][row]]; vibe = VIBE_EN_FULL[D["vibe"][row]]; shoe = SHOE_EN_FULL[D["shoe"][row]]
    pierce = pierce_phrase(D["pierce_p"][row],D["pierce_c"][row],D["pierce_g"][row],D["pierce_f"][row],D["pierce_s"][row],D["pierce_m"][row])
    jewelry = f"{JQ_SHORT[D['jq'][row]]} of {JMETAL_EN[D['jmetal'][row]]} {JTYPE_EN[D['jtype'][row]]}"
    hair = f"{HAIR_COLOR_EN_FULL[rnd.choice(T.HAIR_COLOR)]} hair styled in {HAIR_EN_FULL[rnd.choice(T.HAIR_STYLE)]}"
    bodytext = BODY_FULL[bodykey]; pose = POSE_EN_FULL[rnd.choice(FRONT_POSES)]; cols = rnd.sample(list(LEAF), n)
    texts = [f"applied {c} metallic leaf, thin irregular sheets laid onto the contour of her body with fine natural creases and overlapping seams, a bright {c} sheen filling every gap" for c in cols]
    pre, reg, lab = make_struct(kind, n, shape); assert sens_count(pre+" "+" ".join(reg)) == 0
    sents = " ".join(f"Region {i+1} is {reg[i]}: it carries {texts[i]}." for i in range(n))
    body = (f"{'Full body covered' if solo else 'Covered'} in applied metallic leaf in {n} different colours instead of ordinary skin below the collarbones, each colour claiming its own region of her figure, covering every inch from neck to ankle without exception, the leaf reading as one continuous second skin with no gaps. "
            f"{pre} {sents} {leaf_hz(shape, STRUCT_KIND[kind])} The leaf of every region continues in full strength over her whole figure, nowhere on her body left bare, no fabric no seam no garment anywhere. ")
    head = f"{nat} woman, an adult, in her {age}, {vibe} expression" if solo else f"{label}: {nat}, in her {age}, {vibe} expression"
    block = (f"{head}, warm radiant skin tone — {bodytext} Her face is a real living adult face, {fa}, {hair}, real pores, real living eyes, {pierce}, wearing {jewelry}. {body}Pose: {pose}, " +
             (f"her whole silhouette filling the frame from head to her {shoe}, the platform soles rising far higher than her ankle bone." if solo else f"her {shoe}, the platform soles rising far higher than her ankle bone."))
    return block, f"{STRUCT_KO[kind]}·{'물결' if shape=='undulating' else '매끈'}", f"{bodykey}/{makeup}", "+".join(LEAF[c] for c in cols)

def build_gl(g, n, mk):
    cells = draw_cells(g); bodies = rnd.sample(VOLBODY, g); blocks=[]; descs=[]
    for i in range(g):
        b, st, who, cs = person_gl(f"#{i+1}", mk[i], bodies[i], n, cells[i][0], cells[i][1], g==1)
        blocks.append(b); descs.append(f"[{st} / {who} / {cs}]")
    if g == 1:
        p = (f"Professional fashion photograph, full body shot. ONE woman standing or kneeling as described.\n\nSubject: {blocks[0]}\n\nBackground: a plain seamless deep-charcoal backdrop, nothing else in frame. Lighting: a single hard key light raking in from one side, sharp focus head to toe, realistic photographic grain, a real photograph not an illustration not CGI not a render. Pattern density maximum, zero bare skin from neck to ankle. 2:3 vertical 8K portrait, taller than it is wide.")
    else:
        p = (f"Professional fashion photograph, full body shot. {NW[g]} women standing side by side, each an extraordinarily large woman, far beyond any real person.\n\n" + "\n\n".join(blocks) +
             f"\n\nBackground: a plain seamless deep-charcoal backdrop, nothing else in frame. Composition: each woman's own pose as described, inner arms not crossing her neighbours, generous spacing so every figure reads clearly. Lighting: a single hard key light raking across all of them from one side, sharp focus head to toe on each, realistic photographic grain, a real photograph not an illustration not CGI not a render. Pattern density maximum, zero bare skin from neck to ankle on any of them. Shot on a Hasselblad X2D, {ASPECT[g]} aspect ratio, 8K.")
    return p, " ; ".join(descs)

specs = [(1,3),(1,5),(2,3)]
MK = rnd.sample(T.MAKEUP_48, 4); items=[]; k=0
for g,n in specs:
    p, desc = build_gl(g, n, MK[k:k+g]); k += g; p = fix(p); check("gl", p, allow_uv=False, mat=True)
    assert f"Region {n}" in p and "metallic leaf" in p
    items.append((g, n, desc, p))
GN={1:"솔로",2:"듀오"}
L=["# LumineX · 일반인 몸에 금박 색 혼합 시험 3개 (안 될 가능성이 높은 구성)\n",
   "임산부에서 금박이 안 됐기 때문에 일반인도 어려울 것으로 예상되지만, 확인용으로 3개 만들었습니다. 일반인 문장 구조는 재질 혼합에서 통과한 것을 그대로 썼습니다. **성공/실패만** 알려주세요(최대 3회, 1회/2회/3회/실패). 예: `1: 2회 / 2: 실패 / 3: 1회`\n",
   "## 색인\n","| 번호 | 인원 | 색 수 | 구성 (구조·경계선 / 체형 / 메이크업 / 금박 색) |","|---|---|---|---|"]
for i,(g,n,desc,p) in enumerate(items, 1): L.append(f"| {i:02d} | {GN[g]} | {n}색 | {desc} |")
L.append("")
for i,(g,n,desc,p) in enumerate(items, 1):
    L.append(f"## {i:02d}. {GN[g]} {n}색\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_GenGoldLeaf_Test_3.md","w",encoding="utf-8").write("\n".join(L))
print("3개 저장")
for i,(g,n,desc,p) in enumerate(items,1): print(f"  {i:02d} {GN[g]} {n}색 {len(p.split())}단어 | {desc[:90]}")
