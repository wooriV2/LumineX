# -*- coding: utf-8 -*-
import re
banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","safety pin","gash","crack"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    hits = [w for w in banned if w in p.lower()]
    assert not hits, (name,hits)

# ===== 재질별 묘사 함수 (half 텍스트 반환) =====
def mat_wood():
    return ("rich dark walnut wood fused directly into her own form, natural grain lines flowing to follow every curve of her body, a soft hand-polished sheen, BLAZING deep warm-brown grain patterns with VIVID honey-gold highlight streaks running through the wood")
def mat_stone():
    return ("solid polished white marble fused directly into her own form, natural grey-gold veining flowing to follow every curve of her body, a cool matte-to-soft-gloss stone surface, BLAZING pale marble surface with VIVID golden vein striations running through the stone")
def mat_crystal(c1,c2):
    return (f"{c1} crystal clusters growing directly out of her own skin, erupting in true three-dimensional relief, each facet catching its own glint and casting its own hard shadow, {c2} mineral veins filling every gap")
def mat_botanical(flower,c1,c2):
    return (f"living {flower} blooms growing directly from her own skin, every stem rooted directly into her living skin and every petal standing up in true three-dimensional relief casting its own small shadow, BLAZING {c1} blossoms in full bloom, VIVID {c2} leaves and tendrils filling every gap")
def mat_irezumi(motif,ink):
    return (f"traditional irezumi tattoo ink — bold black ink outlines, {motif} formations, {ink}, extreme high-gloss oil finish")
def mat_uvneon(motif,ink):
    return (f"UV-reactive neon bodypaint, invisible under standard light but BLAZING {motif} formations erupting into visibility under her own dedicated UV blacklight spot, {ink}")
def mat_goldleaf(c1,c2):
    return (f"applied {c1} leaf, thin irregular metallic sheets laid directly onto the contour of her body, fine natural creases and overlapping seams, {c2} undertone glinting through the thinnest points")
def mat_glass(c1,c2):
    return (f"solid thick stained glass fused directly to her form, made of hundreds of small individual panes each no larger than a coin, {c1} and {c2} panes alternating in a dense irregular mosaic, dark lead-line seams webbing between every pane")
def mat_obsidian():
    return ("polished obsidian stone fused directly to her own form, solid glossy black stone curving to follow her body's true shape, with molten gold seams running between dozens of fitted stone sections")
def mat_scale(animal,shape,c1,c2):
    return (f"{animal} scales ({shape}), BLAZING {c1} scale formations, VIVID {c2} scale-edge detail, every scale catching its own glint and casting its own small shadow")
def mat_craft(craftname, desc):
    return (f"painted {craftname} ({desc}), pigment on living skin, wide bands following every deep crease")

PHYSIQUES = [
 ("super hourglass", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum beyond any proportion, most dramatic hourglass ratio ever recorded on any human body, thighs so thick pressing together"),
 ("BBW bombshell", "most massive full-figure BBW body ever at absolute maximum in every dimension, hips so wide beyond proportion dominating the entire frame, bust so enormous overwhelming gravity, waist deeply snatched despite impossible volume"),
 ("wide hip narrow", "hips so impossibly wide extending beyond frame creating the most extreme hip-to-waist ratio ever, waist cinched to absolute impossible minimum, upper body slim emphasizing the dramatic hip explosion"),
 ("curvy petite", "smallest most compact frame possible yet curves exploding at absolute maximum in every direction, bubble butt projecting dramatically backward from the tiny frame, thighs so thick they dwarf the petite frame"),
 ("amazon bombshell", "impossibly tall commanding frame with simultaneously the most massive full-figure curves, enormous powerful presence dominating the entire frame top to bottom, legs endlessly long massively thick and powerful"),
]
HAIRS = ["long sleek jet-black hair cascading past hips","silver-white natural hair swept into a high sculpted crown","loose beach waves mid-length tousled","blunt collarbone-length bob thick heavy","silver-white locs cascading to her waist"]
POSES = ["strong hip pop right, both hands pressing sides of hips outward simultaneously arching back to extreme",
 "full frontal wide stance, both fists pressing outer hips outward to absolute maximum",
 "standing full height, both arms slightly spread commanding the frame",
 "back three-quarter turned, face over shoulder direct eye contact, bubble butt projected backward",
 "strong hip pop left, both hands pressing outer hips outward arching back to extreme"]
AGES = ["early 30s","mid 40s","late 20s","late 30s","mid 50s"]

def person_horiz(idx, label, mat_top, mat_bot, extra_light=""):
    phy_name, phy_detail = PHYSIQUES[idx]
    prefix = f"{label}: " if label else ""
    return (f"{prefix}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {AGES[idx]} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {HAIRS[idx]} — her upper body (collarbones to waist) is {mat_top}. At her waistline the material changes: her lower body (waist to ankles) is {mat_bot}. The boundary is a single straight line circling her waist, never jagged, no fabric no seam no garment. Pose: {POSES[idx]} — most extreme {phy_name} silhouette ever displayed.{extra_light}\n"
            f"{prefix}platform heels/boots matching the lower-body material, extra long nails split upper/lower matching each material.")

def person_vert(idx, label, mat_left, mat_right, blur=False, extra_light=""):
    phy_name, phy_detail = PHYSIQUES[idx]
    prefix = f"{label}: " if label else ""
    if blur:
        boundary = "Rather than a sharp boundary, the two materials interweave and overlap gradually across a soft irregular zone a few inches wide down the centre of her body, elements of each scattered into the other's territory, density fading rather than stopping abruptly."
    else:
        boundary = "The boundary is a single straight vertical line down the exact centre of her body front and back, never jagged, no fabric no seam no garment."
    return (f"{prefix}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {AGES[idx]} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {HAIRS[idx]} — her LEFT side (left arm, left half of torso, left leg to ankle) is {mat_left}. Her RIGHT side (right arm, right half of torso, right leg to ankle) is {mat_right}. {boundary} Pose: {POSES[idx]}, both halves clearly visible — most extreme {phy_name} silhouette ever displayed.{extra_light}\n"
            f"{prefix}left shoe/nail matching left material, right shoe/nail matching right material.")

def wrap_solo(block):
    return f"""Professional fashion photograph, full body shot. ONE woman standing.

{block}

MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. ONE woman only. Extreme macro detail on every material transition. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle. 2:3 vertical 8K portrait. portrait 2:3 vertical."""

def wrap_duo(b1,b2):
    return f"""Professional fashion photograph, full body shot. TWO women standing side by side, each with her own two-material body division.

{b1}

{b2}

Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.
All: Extreme macro detail on every material transition. CRITICAL: both women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere. TWO completely different extreme physiques must CONTRAST and DOMINATE every inch of frame. 8K portrait 3:4 vertical."""

OUT_SOLO = []
OUT_DUO = []

# ===== 솔로 5개 =====
b = person_horiz(0, None, mat_wood(), mat_stone())
p = wrap_solo(b); check("s1",p); OUT_SOLO.append(("목재(상체)+석재(하체) — 가로분할", p))

b = person_vert(1, None, mat_botanical("orchid","VIOLET","GOLD"), mat_irezumi("koi sakura spiral formations","VIVID PINK sakura petal cascade"))
p = wrap_solo(b); check("s2",p); OUT_SOLO.append(("보태니컬(왼쪽)+이레즈미(오른쪽) — 좌우분할", p))

uvlight = " A standard hard key light illuminates one half; a separate dedicated UV blacklight illuminates only the other half, making the neon formations glow at full intensity."
b = person_vert(2, None, mat_uvneon("ELECTRIC VIOLET geometric lattice facets","VIVID CYAN refraction detail"), mat_glass("ELECTRIC CRIMSON","VIVID GOLD"), blur=True, extra_light=uvlight)
p = wrap_solo(b); check("s3",p); OUT_SOLO.append(("UV네온(왼쪽)+스테인드글라스(오른쪽) — 좌우 경계흐림", p))

b = person_horiz(3, None, mat_wood(), mat_craft("Japanese Makie","black lacquer with gold powder detailing"))
p = wrap_solo(b); check("s4",p); OUT_SOLO.append(("목재(상체)+마키에공예(하체) — 가로분할", p))

b = person_vert(4, None, mat_scale("dragon","large thick armor-plate scales, each one substantial and sharply faceted","BLAZING CRIMSON","DEEP EMBER"), mat_goldleaf("ROSE-GOLD","CYAN"), blur=True)
p = wrap_solo(b); check("s5",p); OUT_SOLO.append(("드래곤비늘(왼쪽)+금박(오른쪽) — 좌우 경계흐림", p))

# ===== 듀오 5개 =====
b1 = person_horiz(0, "LEFT", mat_crystal("SAPPHIRE BLUE","SILVER"), mat_stone())
b2 = person_vert(1, "RIGHT", mat_wood(), mat_botanical("peony","CRIMSON","EMERALD"))
p = wrap_duo(b1,b2); check("d1",p); OUT_DUO.append(("듀오1: 왼쪽=크리스탈+석재(가로) / 오른쪽=목재+보태니컬(좌우)", p))

uvlight2 = " A standard hard key light illuminates one half of LEFT woman; a separate dedicated UV blacklight illuminates only her other half."
b1 = person_horiz(2, "LEFT", mat_irezumi("chrysanthemum blooms enormous layered petals","VIVID EMERALD leaf lattice"), mat_uvneon("ELECTRIC EMERALD lightning bolt formations","VIVID NEON YELLOW spark burst"), extra_light=uvlight2)
b2 = person_vert(3, "RIGHT", mat_obsidian(), mat_wood())
p = wrap_duo(b1,b2); check("d2",p); OUT_DUO.append(("듀오2: 왼쪽=이레즈미+UV네온(가로, 조명분리) / 오른쪽=흑요암금+목재(좌우)", p))

b1 = person_vert(4, "LEFT", mat_scale("koi","rounded smooth scales with fine visible growth rings, each scale glossy and slightly domed","ELECTRIC CRIMSON","PEARL WHITE"), mat_glass("ELECTRIC VIOLET","VIVID CYAN"), blur=True)
b2 = person_horiz(0, "RIGHT", mat_craft("Turkish Iznik","cobalt-blue floral tile motifs"), mat_stone())
p = wrap_duo(b1,b2); check("d3",p); OUT_DUO.append(("듀오3: 왼쪽=코이비늘+스테인드글라스(좌우흐림) / 오른쪽=바디페인팅공예+석재(가로)", p))

b1 = person_vert(1, "LEFT", mat_goldleaf("GOLD","CYAN"), mat_crystal("EMERALD GREEN","GOLD"))
b2 = person_horiz(2, "RIGHT", mat_botanical("lotus","PINK","JADE"), mat_obsidian())
p = wrap_duo(b1,b2); check("d4",p); OUT_DUO.append(("듀오4: 왼쪽=금박+크리스탈(좌우) / 오른쪽=보태니컬+흑요암금(가로)", p))

b1 = person_vert(3, "LEFT", mat_wood(), mat_stone(), blur=True)
b2 = person_horiz(4, "RIGHT", mat_irezumi("great wave crest formations sweeping","STARK WHITE foam spray"), mat_scale("snake","diamond-shaped angular scales aligned in neat overlapping rows","DEEP EMERALD","JADE"))
p = wrap_duo(b1,b2); check("d5",p); OUT_DUO.append(("듀오5: 왼쪽=목재+석재(좌우흐림) / 오른쪽=이레즈미+뱀비늘(가로)", p))

for label,p in OUT_SOLO:
    print("SOLO", label, len(p.split()))
for label,p in OUT_DUO:
    print("DUO", label, len(p.split()))

L = ["# LumineX · 전재질 교차 조합 — 솔로5·듀오5\n\n## 솔로\n"]
for label,p in OUT_SOLO:
    L.append(f"### {label}\n"); L.append("```"); L.append(p); L.append("```\n")
L.append("\n## 듀오\n")
for label,p in OUT_DUO:
    L.append(f"### {label}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_AllMaterials_Cross_Solo5_Duo5.md","w",encoding="utf-8").write("\n".join(L))
print("saved")
