# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_retest.py', encoding='utf-8').read().split("\nitems=[]; MK =")[0])      # person_gf(일반인, 통과한 구조)·person_pm·mat_person_k·UV_TAKEN ...
rnd.seed(20261021)

def build_mix2(tracks, n):
    g = len(tracks); cells = draw_cells(g); mk = rnd.sample(T.MAKEUP_48, g)
    bgen = rnd.sample(VOLBODY, g); bpre = rnd.sample(STABLE_BODIES, g); bmax = rnd.sample(PHYS, g)
    UV_TAKEN[0] = False; blocks=[]; descs=[]
    for i,t in enumerate(tracks):
        lab = f"#{i+1}"; kind, shape = cells[i]
        if t == "일반":
            b, st, who, ms = person_gf(lab, mk[i], bgen[i], n, kind, shape, False); descs.append(f"[일반 {st} / {who} / {ms}]")
        elif t == "임산부":
            b, st, who, ms = person_pm(lab, mk[i], bpre[i], n, kind, shape, False); descs.append(f"[임산부 {st} / {who} / {ms}]")
        else:
            b, st, mats = mat_person_k(lab, n, kind, shape, bmax[i], rnd.choice(HAIRS_MX), rnd.choice(AGES_MX), rnd.choice(POSES_MX)); descs.append(f"[맥시 {st} / {bmax[i][0]} / {'+'.join(MAT_KO[m] for m in mats)}]")
        blocks.append(b)
    if "맥시" in tracks:
        tail = (f"Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.\nAll: Extreme macro detail on every material and every blended transition, realistic photographic grain on the realistic-skin and pregnant women, extreme high-gloss oil on the darkest-skin women. CRITICAL: all {g} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere. {NW[g]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame. 8K portrait {ASP[g]} aspect ratio.")
    else:
        tail = (f"Background: a plain seamless deep-charcoal backdrop, nothing else in frame. Lighting: a single hard key light raking across all of them from one side, sharp focus head to toe on each, realistic photographic grain, a real photograph not an illustration not CGI not a render. Pattern density maximum, zero bare skin from neck to ankle on any of them. Shot on a Hasselblad X2D, {ASP[g]} aspect ratio, 8K.")
    p = f"Professional fashion photograph, full body shot. {NW[g]} women standing side by side, each from a different look, each with her own multi-material blended body.\n\n" + "\n\n".join(blocks) + f"\n\n{tail}"
    return p, " ; ".join(descs)

specs = [(["일반","임산부"],3),(["일반","맥시"],4),(["맥시","일반"],3),(["일반","임산부","맥시"],3),(["맥시","일반","임산부"],4),(["일반","맥시","맥시"],3)]
items=[]
for tracks,n in specs:
    p, desc = build_mix2(tracks, n); p = fix(p); check("m6", p, allow_uv=True, mat=True)
    assert "일반" in tracks and len(set(tracks)) >= 2
    items.append((len(tracks), n, desc, p))
order=list(range(6)); rnd.shuffle(order); no={i:order.index(i)+1 for i in range(6)}; ranked=sorted(range(6), key=lambda i:no[i])
GN={2:"듀오",3:"트리오"}
L=["# LumineX · 일반인 포함 트랙 혼합 시험 6개 (일반인 + 임산부·맥시멀리스트)\n",
   "듀오 3개·트리오 3개입니다. 일반인은 이번에 통과한 문장 구조로 넣었습니다. 재질은 인물마다 3~4종이고 꽃·수정·촛농·팔 올린 자세는 뺐으며, UV네온은 맥시멀리스트에게만(이미지당 1명) 넣었습니다. 번호는 섞여 있습니다. **성공/실패만** 알려주세요(최대 3회, 1회/2회/3회/실패). 예: `03: 2회 / 05: 실패 / 나머지 1회`\n",
   "## 색인\n","| 번호 | 인원 | 구역 수 | 구성 (트랙 구조·경계선 / 체형 / 메이크업 / 재질) |","|---|---|---|---|"]
for i in ranked:
    g,n,desc,p = items[i]; L.append(f"| {no[i]:02d} | {GN[g]} | {n} | {desc} |")
L.append("")
for i in ranked:
    g,n,desc,p = items[i]; L.append(f"## {no[i]:02d}. {GN[g]} {n}구역\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_Mix6_WithGeneral_Test.md","w",encoding="utf-8").write("\n".join(L))
json.dump([{"no":no[i],"gsize":items[i][0],"n":items[i][1],"desc":items[i][2]} for i in ranked], open("/home/claude/mix6_meta.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
print("6개 저장")
for i in ranked: print(f"  {no[i]:02d} {GN[items[i][0]]} {items[i][1]}구역 {len(items[i][3].split()):>4}단어 | {items[i][2][:85]}")
