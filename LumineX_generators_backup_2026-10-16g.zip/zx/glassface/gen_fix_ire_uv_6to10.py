# -*- coding: utf-8 -*-
import re, random, json

banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","safety pin","gash","crack"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    hits = [w for w in banned if w in p.lower()]
    assert not hits, (name,hits)

IREZUMI_FULL = [
 ("dragon phoenix", "BLAZING ELECTRIC GOLD dragon coiling the full torso and both legs neck to ankle, VIVID CRIMSON phoenix wings spreading across the full chest"),
 ("koi sakura", "BLAZING CRIMSON koi ascending spiral full torso both legs neck to ankle, VIVID PINK sakura petal cascade filling every gap"),
 ("chrysanthemum", "BLAZING DEEP GOLD chrysanthemum blooms enormous layered petals full torso both legs neck to ankle, VIVID EMERALD leaf lattice filling every gap"),
 ("wisteria", "BLAZING ELECTRIC VIOLET wisteria cascading full torso both legs neck to ankle, STARK WHITE highlight detail filling every gap"),
 ("plum crane", "BLAZING VIVID CRIMSON plum blossom storm full torso both legs neck to ankle, VIVID GOLD crane pair soaring filling every gap"),
 ("peony", "BLAZING VIVID PINK peony blooms cascading full torso both legs neck to ankle, ELECTRIC GOLD centre highlights filling every gap"),
 ("tiger", "BLAZING VIVID ORANGE tiger stripes wrapping the full torso both legs neck to ankle, STARK BLACK stripe detail and fierce tiger face motifs filling every gap"),
 ("hannya mask", "BLAZING CRIMSON hannya mask formations repeating across the full torso both legs neck to ankle, STARK GOLD horn and fang detail filling every gap"),
 ("fudo myo-o flames", "BLAZING ELECTRIC ORANGE flame formations wrapping the full torso both legs neck to ankle, VIVID GOLD ember detail filling every gap"),
 ("shishi lion-dog", "BLAZING DEEP GOLD shishi lion-dog mane formations across the full torso both legs neck to ankle, VIVID CRIMSON accent scales filling every gap"),
 ("great wave", "BLAZING DEEP COBALT wave crest formations sweeping the full torso both legs neck to ankle, STARK WHITE foam spray filling every gap"),
 ("bamboo forest", "BLAZING DEEP EMERALD bamboo stalks wrapping the full torso both legs neck to ankle, VIVID JADE leaf clusters filling every gap"),
 ("iris field", "BLAZING ELECTRIC VIOLET iris blossoms cascading the full torso both legs neck to ankle, VIVID EMERALD leaf blade detail filling every gap"),
 ("lotus pond", "BLAZING VIVID PINK lotus blooms across the full torso both legs neck to ankle, DEEP EMERALD lotus leaf formations filling every gap"),
 ("butterfly swarm", "BLAZING ELECTRIC INDIGO butterfly wing formations scattered across the full torso both legs neck to ankle, VIVID GOLD wing-vein detail filling every gap"),
 ("pine and crane", "BLAZING DEEP EMERALD pine branch formations across the full torso both legs neck to ankle, STARK WHITE crane pair soaring filling every gap"),
 ("water dragon", "BLAZING DEEP COBALT water dragon coiling the full torso both legs neck to ankle, VIVID SILVER scale highlights and wave-foam detail filling every gap"),
 ("phoenix solo", "BLAZING VIVID CRIMSON phoenix wing formations spreading the full torso both legs neck to ankle, ELECTRIC GOLD flame-feather detail filling every gap"),
 ("temple bell dragon", "BLAZING DEEP BRONZE temple-bell formations across the full torso both legs neck to ankle, VIVID GOLD dragon coil detail filling every gap"),
 ("firefly night", "BLAZING ELECTRIC INDIGO night-sky formations across the full torso both legs neck to ankle, VIVID GOLD firefly-light pinpoints filling every gap"),
 ("orchid", "BLAZING DEEP VIOLET orchid blossoms cascading the full torso both legs neck to ankle, VIVID EMERALD leaf detail filling every gap"),
 ("oni demon mask", "BLAZING CRIMSON oni mask formations repeating across the full torso both legs neck to ankle, STARK BLACK horn and brow detail filling every gap"),
 ("tengu feathers", "BLAZING DEEP CRIMSON feather formations sweeping the full torso both legs neck to ankle, VIVID GOLD plume-tip detail filling every gap"),
 ("raijin thunder drums", "BLAZING ELECTRIC VIOLET drum-ring formations across the full torso both legs neck to ankle, STARK GOLD pure spark detail filling every gap"),
 ("autumn maple storm", "BLAZING VIVID CRIMSON maple leaf formations swirling across the full torso both legs neck to ankle, VIVID GOLD leaf-vein detail filling every gap"),
 ("koi waterfall climb", "BLAZING DEEP CRIMSON koi formations ascending the full torso both legs neck to ankle, VIVID SILVER water-spray detail filling every gap"),
]
UV_FULL = [
 ("cosmic nebula", "ELECTRIC MAGENTA nebula cloud formations swirling across the chest and upper body, VIVID NEON CYAN plasma stream formations flowing down both legs, BLAZING NEON GOLD star cluster formations filling every gap"),
 ("lightning web", "ELECTRIC EMERALD lightning bolt formations branching across the full torso both legs neck to ankle, VIVID NEON YELLOW spark burst formations filling every gap"),
 ("crystal lattice", "ELECTRIC VIOLET geometric lattice facets full torso both legs to ankle, prismatic crystal faces refracting CYAN light"),
 ("ocean wave", "ELECTRIC CYAN ocean wave formations flowing organically full torso both legs neck to ankle, VIVID WHITE seafoam accent filling every gap"),
 ("dragon formations", "ELECTRIC MAGENTA dragon coiling the full torso both legs neck to ankle, VIVID NEON GREEN dragon flame formations filling every gap"),
 ("Saturn ring", "NEON GOLD planetary ring formations circling the belly curve naturally, VIVID ORANGE supernova burst formations at each breast"),
 ("sound wave cymatics", "ELECTRIC GOLD cymatics geometric mandala formations vibrating full torso both legs to ankle, VIVID ORANGE Chladni pattern sand formations both legs hip to toe"),
 ("aurora curtain", "ELECTRIC GREEN aurora curtain formations rippling across the full torso both legs neck to ankle, VIVID VIOLET edge-glow detail filling every gap"),
 ("jellyfish bioluminescence", "ELECTRIC CYAN jellyfish-bell formations across the full torso both legs neck to ankle, VIVID MAGENTA tentacle-trail detail filling every gap"),
 ("DNA helix", "ELECTRIC MAGENTA double-helix formations spiraling the full torso both legs neck to ankle, VIVID CYAN rung-connector detail filling every gap"),
 ("circuit traces", "ELECTRIC GREEN circuit-trace formations branching across the full torso both legs neck to ankle, VIVID GOLD node-point detail filling every gap"),
 ("plasma vortex", "ELECTRIC VIOLET vortex formations swirling the full torso both legs neck to ankle, VIVID MAGENTA core-glow detail filling every gap"),
 ("solar flare", "ELECTRIC ORANGE flare formations erupting across the full torso both legs neck to ankle, VIVID GOLD corona-ray detail filling every gap"),
 ("meteor shower", "ELECTRIC CYAN streak formations sweeping the full torso both legs neck to ankle, VIVID WHITE trail-spark detail filling every gap"),
 ("glowing coral reef", "ELECTRIC MAGENTA coral-branch formations across the full torso both legs neck to ankle, VIVID CYAN polyp-glow detail filling every gap"),
 ("electric vein network", "ELECTRIC VIOLET vein-line formations branching across the full torso both legs neck to ankle, VIVID CYAN pulse-node detail filling every gap"),
 ("supernova burst", "ELECTRIC GOLD radial burst formations across the full torso both legs neck to ankle, VIVID MAGENTA shockwave-ring detail filling every gap"),
 ("magnetic field lines", "ELECTRIC CYAN field-line formations curving the full torso both legs neck to ankle, VIVID VIOLET pole-point detail filling every gap"),
 ("bioluminescent wave", "ELECTRIC CYAN wave-crest formations sweeping the full torso both legs neck to ankle, VIVID GREEN foam-glow detail filling every gap"),
 ("nebula birth cluster", "ELECTRIC MAGENTA gas-cloud formations swirling the full torso both legs neck to ankle, VIVID GOLD newborn-star pinpoints filling every gap"),
 ("radio pulse rings", "ELECTRIC CYAN concentric-ring formations radiating across the full torso both legs neck to ankle, VIVID VIOLET pulse-edge detail filling every gap"),
 ("ion storm", "ELECTRIC VIOLET charged-particle formations swirling the full torso both legs neck to ankle, VIVID CYAN arc-trail detail filling every gap"),
 ("geyser plasma eruption", "ELECTRIC GOLD plume formations erupting across the full torso both legs neck to ankle, VIVID ORANGE spray-ray detail filling every gap"),
 ("resonance web", "ELECTRIC MAGENTA web-strand formations crossing the full torso both legs neck to ankle, VIVID CYAN node-glow detail filling every gap"),
 ("event horizon tunnel", "ELECTRIC VIOLET tunnel-ring formations receding across the full torso both legs neck to ankle, VIVID MAGENTA event-edge detail filling every gap"),
 ("fractal energy burst", "ELECTRIC GREEN fractal-branch formations spreading the full torso both legs neck to ankle, VIVID GOLD node-point detail filling every gap"),
 ("firefly swarm", "ELECTRIC GOLD pinpoint-cluster formations scattered across the full torso both legs neck to ankle, VIVID GREEN glow-halo detail filling every gap"),
]
print("이레즈미 풀:", len(IREZUMI_FULL), "/ UV네온 풀:", len(UV_FULL))

PHYSIQUES = [
 ("super hourglass", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum beyond any proportion, most dramatic hourglass ratio ever recorded on any human body, thighs so thick pressing together"),
 ("wide hip narrow", "hips so impossibly wide extending beyond frame creating the most extreme hip-to-waist ratio ever, waist cinched to absolute impossible minimum, upper body slim emphasizing the dramatic hip explosion"),
 ("BBW bombshell", "most massive full-figure BBW body ever at absolute maximum in every dimension, hips so wide beyond proportion dominating the entire frame, bust so enormous overwhelming gravity, waist deeply snatched despite impossible volume"),
 ("curvy petite", "smallest most compact frame possible yet curves exploding at absolute maximum in every direction, bubble butt projecting dramatically backward from the tiny frame, thighs so thick they dwarf the petite frame"),
 ("amazon bombshell", "impossibly tall commanding frame with simultaneously the most massive full-figure curves, enormous powerful presence dominating the entire frame top to bottom, legs endlessly long massively thick and powerful"),
 ("latina curves", "most dramatic hourglass ratio ever, simultaneously maximum enormous bust AND maximum enormous hips both flaring to absolute impossible extremes while the waist is cinched to impossible minimum"),
 ("hourglass bombshell", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum, thighs pressing together, every curve maximized at once"),
 ("powerlifter bombshell", "immense powerful thighs and shoulders built with real strength, a thick solid waist, overwhelming muscular bulk layered with soft curves everywhere"),
 ("curvy petite", "smallest most compact frame possible yet curves exploding at absolute maximum in every direction, bubble butt projecting dramatically backward from the tiny frame, thighs so thick they dwarf the petite frame"),
 ("wide hip narrow", "hips so impossibly wide extending beyond frame creating the most extreme hip-to-waist ratio ever, waist cinched to absolute impossible minimum, upper body slim emphasizing the dramatic hip explosion"),
]
HAIRS = ["long sleek jet-black hair cascading past hips","silver-white natural hair swept into a high sculpted crown","loose beach waves mid-length tousled","blunt collarbone-length bob thick heavy","silver-white locs cascading to her waist","curtain bangs long straight hair sweeping past the shoulders","two thick goddess braids","high ponytail swept sleek","voluminous curls cascading past her shoulders","long straight platinum-silver hair past her hips"]
POSES = ["strong hip pop right, both hands pressing sides of hips outward simultaneously arching back to extreme",
 "full frontal wide stance, both fists pressing outer hips outward to absolute maximum",
 "standing full height, both arms slightly spread commanding the frame",
 "back three-quarter turned, face over shoulder direct eye contact, bubble butt projected backward",
 "strong hip pop left, both hands pressing outer hips outward arching back to extreme",
 "full frontal, both hands framing the face, chin raised",
 "three-quarter angle, one hand on the outer hip, the other raised overhead",
 "standing full height, both arms slightly spread commanding the frame",
 "back three-quarter turned, face over shoulder direct eye contact, bubble butt projected backward",
 "strong hip pop right, both hands pressing sides of hips outward simultaneously arching back to extreme"]
AGES = ["early 20s","late 20s","early 30s","mid 30s","late 30s","mid 40s","early 50s","mid 50s","early 30s","late 20s"]

LABELS10 = [f"#{i}" for i in range(1,11)]
NUM_WORD = {6:"SIX",7:"SEVEN",8:"EIGHT",9:"NINE",10:"TEN"}
TYPE_NAME = {6:"sextet",7:"septet",8:"octet",9:"nonet",10:"decet"}

def irezumi_block(label, i, motif_idx, rnd):
    motif_name, motif_ink = IREZUMI_FULL[motif_idx % len(IREZUMI_FULL)]
    phy_name, phy_detail = PHYSIQUES[i % 10]
    return (f"{label}: THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {AGES[i%10]} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {HAIRS[i%10]} — full body {motif_name} irezumi covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Bold black ink outlines — {motif_ink}, NO airbrush NO gradient wash. Pose: {POSES[i%10]} — most extreme {phy_name} silhouette ever displayed.\n"
            f"{label}: platform boots 8 inch, extra long stiletto nails to match.")

def uvneon_block(label, i, motif_idx, rnd):
    motif_name, motif_ink = UV_FULL[motif_idx % len(UV_FULL)]
    phy_name, phy_detail = PHYSIQUES[i % 10]
    return (f"{label}: THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {AGES[i%10]} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, UV-reactive BLAZING {HAIRS[i%10]} — full body UV neon {motif_name} bodypaint covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Bold formations — BLAZING {motif_ink}, NO airbrush NO gradient wash. Pose: {POSES[i%10]} — most extreme {phy_name} silhouette ever displayed. Under her own dedicated UV blacklight spot, zero white light reaching her specifically.\n"
            f"{label}: platform boots 8 inch, extra long stiletto nails BLAZING NEON UV reactive tips.")

def build_irezumi(n, seed):
    rnd = random.Random(seed)
    pool_size = len(IREZUMI_FULL)
    start = rnd.randrange(pool_size)
    labels = LABELS10[:n]
    blocks = [irezumi_block(labels[i], i, start+i, rnd) for i in range(n)]
    body = "\n\n".join(blocks)
    frame_note = ", significantly wider than it is tall" if n>=6 else ""
    p = f"""Professional fashion photograph, full body shot. {NUM_WORD[n]} women standing side by side.

{body}

Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.
All: extreme high-gloss oil. CRITICAL: all {n} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere. {NUM_WORD[n]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame. 8K 16:9 aspect ratio{frame_note}."""
    return p

def build_uvneon(n, seed):
    rnd = random.Random(seed)
    pool_size = len(UV_FULL)
    start = rnd.randrange(pool_size)
    labels = LABELS10[:n]
    blocks = [uvneon_block(labels[i], i, start+i, rnd) for i in range(n)]
    body = "\n\n".join(blocks)
    frame_note = ", significantly wider than it is tall" if n>=6 else ""
    p = f"""Professional fashion photograph, full body shot. {NUM_WORD[n]} women standing side by side.

{body}

MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. UV blacklight illumination only — zero white light. All: Multiple UV blacklights from all angles making every formation glow at maximum intensity, extreme high-gloss oil. CRITICAL: all {n} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere. {NUM_WORD[n]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame. 8K 16:9 aspect ratio{frame_note}."""
    return p

all_presets = []
for n in [6,7,8,9,10]:
    type_name = TYPE_NAME[n]
    for slot in range(1,31):
        seed = hash(("ire", n, slot)) % 1000000
        p = build_irezumi(n, seed)
        check(f"ire_{type_name}_{slot}", p)
        all_presets.append({
            "key": f"la_irezumi_{type_name}_{slot:02d}",
            "category": "🏺 Living Artifact · Irezumi Formula",
            "title": f"Irezumi {type_name.capitalize()} #{slot:02d}",
            "prompt": p, "meta": {"group_size": n, "aspect_ratio": "16:9", "format": "maximalist", "fixed": "motif-pool-expanded-26"}
        })
    for slot in range(1,31):
        seed = hash(("uv", n, slot)) % 1000000
        p = build_uvneon(n, seed)
        check(f"uv_{type_name}_{slot}", p)
        all_presets.append({
            "key": f"la_uvneon_{type_name}_{slot:02d}",
            "category": "🏺 Living Artifact · UV Neon Formula",
            "title": f"UV Neon {type_name.capitalize()} #{slot:02d}",
            "prompt": p, "meta": {"group_size": n, "aspect_ratio": "16:9", "format": "maximalist", "fixed": "motif-pool-expanded-27"}
        })

print("생성:", len(all_presets))
with open("/home/claude/glassface/la_fix_ire_uv_bundle.json","w",encoding="utf-8") as f:
    json.dump(all_presets, f, ensure_ascii=False, indent=2)
print("저장 완료")
