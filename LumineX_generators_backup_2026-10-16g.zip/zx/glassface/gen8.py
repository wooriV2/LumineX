# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re, copy
spec = importlib.util.spec_from_file_location("g7","gen7.py"); g7 = importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(io.StringIO()):
    spec.loader.exec_module(g7)
g = g7.g; OLD = g7.OLD; NEW = g7.NEW

V = copy.deepcopy(g.ROWS[6]); V["tier"] = "매우 많이"
V["pierce"] = ("A thick black-steel septum ring hangs below the nose with a smaller black-steel ring above it, and a black-steel ring passes through each nostril; a straight black-steel bar crosses the bridge of the nose between the brows; three thick black-steel bars stack through the outer half of each eyebrow; a black-steel Medusa stud sits above the lips; "
 "a big black-steel hoop passes through the lower lip's edge with a snake-bite ring on each side, and three small black-steel hoops run along the upper lip's edge; a black-steel labret stud and two black-steel rings pass through the chin; two small black-steel studs run along each jaw; "
 "on each ear a big black-steel hoop, a thick black-steel bar, a stretched black-steel plug, a helix ring and a small stud.")
L = copy.deepcopy(g.ROWS[8]); L["tier"] = "매우 많이"
L["pierce"] = ("A thick silver septum ring hangs below the nose with a smaller silver ring above it, and a silver ring passes through each nostril; a straight silver bar crosses the bridge of the nose between the brows; three thick silver bars stack through the outer half of each eyebrow; a silver Medusa stud sits above the lips; "
 "a big silver hoop passes through the lower lip's edge with a snake-bite ring on each side, and three small silver hoops run along the upper lip's edge; a silver labret stud and two silver rings pass through the chin; two small silver studs run along each jaw; "
 "on each ear a big silver hoop, a thick silver bar, a stretched gold-rimmed plug, a helix ring and a small stud.")

OUT = []
for r in (V, L):
    _, an, bn, p = g.build(r)
    assert OLD in p
    OUT.append((r, an, bn, p.replace(OLD, NEW)))
for r, an, bn, p in OUT:
    print(r["ko"], len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
    print(p.split("Piercings:")[1].split("Lines:")[0][:1800])
