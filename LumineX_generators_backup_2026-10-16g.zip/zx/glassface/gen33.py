# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g18 = load("g18","gen18.py"); g9 = load("g9","gen9.py"); g10 = load("g10","gen10.py"); g13 = load("g13","gen13.py")
g28 = load("g28","gen28.py"); g30 = load("g30","gen30.py"); g32 = load("g32","gen32.py")
g3 = g18.g3; MAT = g18.MAT; WAIST_BODY = g3.WAIST_BODY
BIGEAR = g32.BIGEAR
DEPTH = g32.DEPTH
DENS = g13.DENS

# ---- 새 체형 3종 (허리 프레임용) ----
NEW_BODY = {
 "armq": ("암 퀸", "A woman with extraordinarily thick upper arms — each upper arm enormous, heavy and rounded, as thick as a tree trunk, resting against the sides of her body and tapering into thick forearms and normal-sized hands, the arms clearly the most massive part of her body. Broad soft shoulders, a full heavy chest, a soft rounded belly."),
 "belly": ("에이프런 벨리(허벅지 중간 상한)", "A woman with an enormous soft belly that swells far forward from just below her full chest and hangs in a heavy rounded overhang, its upper fold deep and soft, the belly flowing seamlessly into her sides and hips as one continuous body. A full heavy chest, broad soft shoulders, thick soft arms."),
 "matu": ("마츄어 커브", "A voluptuous mature hourglass figure: a full soft chest, a clearly defined waist, a soft rounded belly, wide curving hips, soft strong shoulders and full arms, the body of a confident woman in her early 40s."),
}
def body(k):
    return NEW_BODY[k] if k in NEW_BODY else WAIST_BODY[k]

# ---- 피어싱 텍스트 ----
T8 = g18.T8
T25 = g28.metalize(g18.T25, "rose-gold")
T50 = g28.metalize(g18.T50, "silver")
T100 = g9.P100.replace("ten big hoops, thick bars, stretched plugs, helix rings and studs from lobe to top", "ten oversized hoops, thick bars, stretched plugs, helix rings and studs from lobe to top, " + BIGEAR)
T150 = g10.P150.replace("twelve big hoops, thick bars, stretched plugs, helix rings and studs from lobe to top", "twelve oversized hoops, thick bars, stretched plugs, helix rings and studs from lobe to top, " + BIGEAR)
T200 = g30.pierce(200)
C1 = g32.P100 + g13.K1_CH
C2 = g32.P150 + g13.K2_CH

SPEC = [
 # 라벨, 스타일, 체형, L, R, 피어싱, dens, 금속, age
 ("P8",  "히메갸루",  "armq",  "jade","amber",      T8,   False, "yellow gold with a pearl", "Mid 20s"),
 ("P25", "강남언니",  "belly", "amethyst","aquamarine", T25, False, "rose gold", "Mid 20s"),
 ("P50", "오네에갸루","matu",  "carnelian","sapphire",  T50, False, "silver", "Early 40s"),
 ("P100","걸크러시",  "p_hgu", "emerald","citrine",  T100, True,  "black steel", "Mid 20s"),
 ("P150","비주얼계",  "p_colo","glacial","carnelian",T150, True,  "black steel", "Mid 20s"),
 ("P200","뱀파이어 다크","p_uss","smoky","ruby",    T200, True,  "black steel and silver", "Mid 20s"),
 ("P100+C1","인형 메이크업","p_hgu","rosequartz","sapphire", C1, True, "silver with a few turquoise-enamel rings and pastel charms", "Mid 20s"),
 ("P150+C2","로리타 갸루","hgs", "murano","emerald", C2, True, "silver with a few turquoise-enamel rings and many small charms", "Mid 20s"),
]
CARE_BODY = g30.CARE_FACE   # 얼굴 실사 + 몸 금속은 재질에 뚫린 구멍

OUT = []
for label, sty, bk, a, b, ptxt, dens, metal, age in SPEC:
    nat, mk, fc = g3.face_of(sty)
    an, adesc, ainner = MAT[a]; bn, bdesc, binner = MAT[b]
    bname, btext = body(bk)
    preg = bk.startswith("p_")
    belly = " The pregnant belly is one smooth swelling of the material, its surface the material's own polished curve." if preg else ""
    smile = " Her face shows a few fine, natural smile lines at the eyes and mouth." if bk == "matu" else ""
    care = CARE_BODY if label == "P200" else g18.CARE.format(metal=metal)
    p = f"""Professional fashion photograph, upper-body shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head down to the middle of her belly, the frame cutting off across the belly so no hips, legs or feet are visible. Her face sits in the upper part of the frame, and her ear pieces are oversized so they read clearly at this distance. {age}.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}.{smile} Her whole face, ears and neck are real living flesh with real pores and fine skin grain — a photograph of a real face, not an illustration.

Piercings: {ptxt}{DENS if dens else ''} {care}

{DEPTH}

Physique: {btext}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest and belly): solid {adesc}, with {ainner}. Right half: solid {bdesc}, with {binner}. Each is carved as one solid sculpted mass like a statue, never hollow, the chest two great rounded masses, and the grooves and belly folds cut into the material itself.{belly} The arms flow into the torso with no seam, and every wrist, palm, finger and knuckle is the same material as its arm.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the chest and belly and out of the bottom of the frame where the two materials meet, never horizontal. Shards interlock along the lines only, every edge solid all the way through.

Pose: body angled 45 degrees, her left hand (solid material) held low at the frame edge beside her belly, her right hand (solid material) held at chest height clear of her body, well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal light on her face and ears only, so the makeup and the glints on every piece of metal read clearly; a strong backlight through each half so both sides of the body glow from within; a thin cool rim light along the centre line. 2:3 vertical 8K portrait."""
    OUT.append((label, sty, bname, an, bn, metal, p))

if __name__ == "__main__":
    for l, s, bn_, an, bn, m, p in OUT:
        print(l, s, bn_, an, "×", bn, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "", "apron" if "apron" in p.lower() else "")
