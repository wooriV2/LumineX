# -*- coding: utf-8 -*-
import re, sys, random, json
from collections import Counter
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
_top = open('gen_group_test.py', encoding='utf-8').read().split("\nitems=[]")[0]
exec(_top)      # hazy2, CELLS, draw_cells, person_block, build_group, make_structure, STRUCT_*, validate, face_nohair 등
rnd.seed(20261007)
def pct(lo, hi, step=1): return rnd.randrange(lo, hi+1, step)   # 위치 숫자를 1% 단위로(반복 최소화)

def assemble(makeup, bodykey, art):
    nat, fa = face_nohair(makeup)
    age = AGE_EN_FULL[rnd.choice(T.AGE_12)]; vibe = VIBE_EN_FULL[rnd.choice(T.VIBE_5)]
    hs = HAIR_EN_FULL[rnd.choice(T.HAIR_STYLE)]; hc = HAIR_COLOR_EN_FULL[rnd.choice(T.HAIR_COLOR)]
    nail = f"{NAIL_SHAPE_EN_FULL[rnd.choice(T.NAIL_SHAPES)]} nails, {NAIL_FIN_EN_FULL[rnd.choice(T.NAIL_FINISH)]} finish"
    pose = POSE_EN_FULL[rnd.choice(FRONT_POSES)]; shoe = SHOE_EN_FULL[rnd.choice(T.SHOES_24)]
    return (f"Image format: a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide.\n\nA full-body photograph with a plain seamless deep-charcoal backdrop, shot on a medium format camera with an 85mm lens at f/8, a single hard key light raking in from one side, sharp focus from head to toe, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n"
            f"Subject: ONE real adult {nat} woman in her {age}, her face exactly the same tone as her body, real skin texture with visible pores and fine grain, {fa}, {vibe}, {hc} hair styled in {hs}, real living eyes. Long {nail}.\n\n"
            f"Physique: {cap(BODY_FULL[bodykey])}\n\n"
            f"Skin: Real photographic skin — visible pores and fine grain, a smooth taut surface with natural creases and shadow only where the flesh folds. No smooth illustration finish, no plastic CG sheen.\n\n"
            f"{art}\n\n"
            f"Pose: {pose}, every region clearly visible to the camera.\n\nFootwear: extreme {shoe}, painted with the blended patterns following the same soft transitions as her skin.\n\n"
            f"Background & Lighting: the blended painted patterns reading crisp against her skin, the hard raking light carving every fold and curve.\n\nVertical 2:3 portrait-orientation full-body photograph, taller than it is wide. portrait 2:3 vertical.")

def build_solo(n):
    makeup = rnd.choice(T.MAKEUP_48); bodykey = rnd.choice(VOLBODY); crafts = rnd.sample(T.CRAFTS_39, n)
    kind, shape = rnd.choice(CELLS)
    pre, reg, lab = make_structure(kind, n, shape); assert sens_count(pre+" "+" ".join(reg)) == 0
    texts=[]
    for c in crafts:
        cn,cd,cb,cf = CRAFT_DB_FULL[c]
        texts.append(f"{cn} ({cd}), wide {cb} bands following the contours of the body, dense {cf} filling the space between bands")
    sents = " ".join(f"Region {i+1} is {reg[i]}: it is painted in {texts[i]}." for i in range(n))
    art = (f"Body Art: Her bare skin is painted with {n} different traditional patterns, each claiming its own region of her figure. {pre} {sents} {hazy2(shape, STRUCT_KIND[kind])} Pigment on living skin throughout, covering every inch of her body below the jaw with no bare skin anywhere, face unpainted.")
    return assemble(makeup, bodykey, art), f"{STRUCT_KO[kind]}·{'물결' if shape=='undulating' else '매끈'}", crafts, makeup, bodykey, f"{kind}:{shape}"

old = {x["key"]: x for x in json.load(open("la_blend_540_bundle.json", encoding="utf-8"))}
TN = {1:"solo",2:"duo",3:"trio"}; TYPE_EN = {1:"Solo",2:"Duo",3:"Trio"}
CAT = "🏺 Living Artifact · Craft Blend Formula"
presets=[]; cell_count=Counter()
for mixn in [3,4]:
    for gsize in [1,2,3]:
        for slot in range(1,31):
            key = f"la_craftblend{mixn}_{TN[gsize]}_{slot:02d}"
            assert key in old, key
            if gsize == 1:
                p, desc, crafts, mk, bd, cell = build_solo(mixn); descs=[desc]; cells=[cell]; cr_str="+".join(crafts); who=f"{bd}/{mk}"
            else:
                p, descs, people = build_group(gsize, mixn); who=" ; ".join(people)
                cells=[d.split(":")[1] for d in descs]
                cr_str = " / ".join(re.findall(r"Region \d is [^:]+: it is painted in ([A-Za-z0-9 ]+?) \(", p)[i*mixn:(i+1)*mixn][0] for i in range(gsize)) if False else ""
            validate(key, p)
            assert "diagonally and asymmetrically" not in p and "never left bare" in p
            for d in descs: cell_count[d.split(":")[-1] if ":" in d else d]+=1
            pers = "+".join(descs) if gsize==1 else " / ".join(descs)
            presets.append({"key":key,"category":CAT,
              "title":f"Craft Blend {mixn}-Mix {TYPE_EN[gsize]} #{slot:02d} ({pers})",
              "prompt":p,
              "meta":{"group_size":gsize,"aspect_ratio":ASP[gsize],"format":"craft-blend","mix_count":mixn,"layout":"geometry-hazy-v1","structures":descs,"persons":who}})
assert len(presets)==180 and len({x["key"] for x in presets})==180
json.dump(presets, open("la_craftblend_geo_180_bundle.json","w",encoding="utf-8"), ensure_ascii=False, indent=2)

print("생성:", len(presets), "개 | 기존 키와 전부 일치(덮어쓰기)")
for mixn in [3,4]:
    for g in [1,2,3]:
        ws=[len(x["prompt"].split()) for x in presets if x["meta"]["mix_count"]==mixn and x["meta"]["group_size"]==g]
        ow=[len(old[x["key"]]["prompt"].split()) for x in presets if x["meta"]["mix_count"]==mixn and x["meta"]["group_size"]==g]
        print(f"  {mixn}혼합 {TKO[g]}: 새 {min(ws)}~{max(ws)}단어 (기존 {min(ow)}~{max(ow)})")
persons=sum(len(x["meta"]["structures"]) for x in presets)
print(f"인물 {persons}명 | 구조·경계선 조합 분포:", dict(sorted(Counter(d for x in presets for d in x['meta']['structures']).items(), key=lambda kv: kv[0])))
# 같은 이미지 안 구조 중복 없음 검증
dup=[x["key"] for x in presets if len(x["meta"]["group_size"] and {s.split("·")[0].split(":")[-1] for s in x["meta"]["structures"]})!=x["meta"]["group_size"]]
print("한 이미지 안 구조 중복:", len(dup), "개")
print("고유한 레이아웃 문장 수(인물별 구조 설명 기준):", len({re.search(r'Her figure is divided into[^.]*\.', x["prompt"]+" ").group(0) for x in presets if "Her figure is divided into" in x["prompt"]}) , "종류 (첫 인물 기준)")
