# -*- coding: utf-8 -*-
# 여성 바디페인팅 정면 비교 샘플 4개 (부피 큰 체형 2 + 근육질 2) — 남성 정면 실패 대조용
import re, sys
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity"); sys.path.insert(0, "../../master")
_g = open("gen_pierce_statue.py", encoding="utf-8").read()
exec(_g[:_g.index("def build(")])
import mdefs as D
exec(open("../../bk/newbody_defs.py", encoding="utf-8").read(), globals())
_src = open("../../bk/mk_statue_obj11.py", encoding="utf-8").read()
exec(_src[_src.index("rnd.seed("):_src.index("LABEL = ['Physique']")])      # KO 등
rnd.seed(20263502)
sys.path.insert(0, '../../bk')
import bg_library as _BG
OUTD = [b[0] for b in _BG.B if b[4]]
POOL = {b[0]: b[1] for b in D.BODIES}; POOL.update({nm: desc for nm, ko, kod, desc in NB})
_NBd = POOL["Nubian booty builder"]
POOL["Nubian bust builder"] = _NBd.replace("wide flaring lats", "a full, heavy, firm bust standing out on her chest").replace("a deeply carved abdomen with sharp obliques", "a deeply carved six-pack abdomen with sharp obliques")
POSES = {"s_curve": "standing facing the camera in a graceful S-curve, her left hand resting on her flared hip and her right hand lifting her hair away from her neck",
         "walk": "walking toward the camera with a slow swaying runway stride, one hand brushing her hair back",
         "over_shoulder": "standing in three-quarter view with her weight on one leg, one hand on her flared hip, looking back over her shoulder at the camera",
         "crossed": "standing facing the camera with one leg crossed in front of the other, both hands resting on her hips, her head tilted slightly",
         "wide": "standing in a wide confident stance facing the camera, both hands resting on her flared hips, her chin lifted"}
SHOES = ["Extreme gold ballet heels", "Extreme black patent stiletto pumps", "Extreme silver platform sandals", "Extreme red lacquer platform pumps"]
NAILS = ["Long square nails, glossy finish.", "Long almond nails, chrome finish.", "Long coffin nails, deep burgundy.", "Long stiletto nails, glossy black."]
BG = ["plain seamless deep-charcoal", "plain seamless mid-grey", "plain seamless deep-navy"]
NATSM = [("Korean", "smooth fair skin with a warm undertone"), ("Korean", "luminous porcelain skin"), ("Chinese", "smooth fair skin with a neutral undertone"), ("Chinese", "light skin with a warm golden undertone"), ("Japanese", "smooth pale skin with a cool undertone"), ("Japanese", "smooth fair skin with a neutral undertone")]
FACEM = ["a rugged masculine face with a strong square jaw, heavy straight brows and prominent cheekbones", "a chiseled masculine face with a broad jaw, deep-set eyes and a strong brow ridge", "a mature masculine face with a squared chin, a strong nose and a thick neck", "a hard-edged masculine face with a wide jaw, thick brows and a defined Adam's apple"]
MKUM = [""]
BEARDM = ["light stubble", "a short neatly trimmed beard", "a short trimmed beard and moustache", "a dark five-o'clock shadow"]
NATHC = [i for i, h in enumerate(HC) if h[:4] in ("HCJB", "HCNB", "HCDB", "HCCB", "HCAB")]
HKM = ["HSS스트레이트", "HSW웨이브", "HSSK슬릭백", "HSSH샤기컷"]
AGESM = ["in his late 20s", "in his early 30s", "in his mid 30s", "in his late 30s"]
import full_dicts as _F
SHOECOL = ["gold", "black", "red", "silver", "white", "cobalt-blue", "hot-pink"]
GB = {"__name__": "gb"}
exec(open("gen_blend_540.py", encoding="utf-8").read().split("\nPHYS = [")[0], GB)
GB["rnd"] = rnd
_nb = open("mk_blendnew6.py", encoding="utf-8").read()
exec(_nb[_nb.index("NEWM = ["):_nb.index("FORCE = [None]")], GB)
GB["WOODS"] = {k: v for k, v in GB["WOODS"].items() if k in ("walnut", "ebony")}
MATP = ["irezumi", "glass", "nacre", "scale_snake", "scale_dragon", "scale_butterfly", "scale_koi", "scale_mermaid", "feather", "circuit", "obsidian"]
MW = [2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 0.6]
SCM = []
def pick_scene_mats(n):
    while True:
        m = [rnd.choices(MATP, weights=MW)[0] for _ in range(n)]
        if len(set(m)) < n or m.count("uvneon") > 1 or ("stone" in m and "wood" in m): continue
        return m
MAT_ART = "{lab} Body Art: {Pr} body carries {mt}. It is fused to {pr} own living skin and flexes slightly over every bulge, with no fabric, seam or garment anywhere. It covers {pr} whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of {pr} hands, sides, back, rear, lower belly, knees, calves and the tops of {pr} feet. {Pr} face is left bare and the material fades out at the neck with no hard line."
def matart(lab, male):
    k = SCM.pop(0); mt, _ = GB["mat_text"](k)
    if male: mt = re.sub(r"\bher\b", "his", mt)
    pr = "his" if male else "her"
    return MAT_ART.format(lab=lab, mt=mt, pr=pr, Pr=pr.capitalize()), GB["MAT_KO"][k]
import json as _json
_wg = open("../../bk/gen_woodstone_groups6.py", encoding="utf-8").read(); _ns = {}
_wg = _wg.replace('open("gen_woodstone_sample4.py"', 'open("../../bk/gen_woodstone_sample4.py"')
exec(_wg[:_wg.index("NUM = {")], _ns)
DARKW = ("ebony", "walnut", "purpleheart", "rosewood", "wenge")
WSP = [("목재", x) for x in _ns["WOODS"] if x[0] in DARKW] + [("석재", x) for x in _ns["STONES"] if x[0] != "tiger's eye"]
SPKO = {"ebony": "에보니", "walnut": "월넛", "purpleheart": "퍼플하트", "rosewood": "로즈우드", "wenge": "웬지", "white marble": "대리석", "black granite": "화강암", "jade": "비취", "lapis lazuli": "라피스", "malachite": "말라카이트",
        "rhodonite": "로도나이트", "onyx": "오닉스", "labradorite": "라브라도라이트", "turquoise": "터쿼이즈", "carnelian": "카넬리안", "sodalite": "소달라이트"}
def spfull(kind, nm): return nm if (kind == "석재" or nm.endswith("wood")) else nm + " wood"
def matmat(kind, pick, pr):
    nm, desc, base, acc = pick
    if kind == "목재":
        return (f"full body {desc if desc.endswith('wood') else desc + ' wood'} carved directly over {pr} own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not a printed pattern, this is solid carved wood curving to follow {pr} body's true three-dimensional shape, divided into dozens of fitted carved sections whose grain changes direction from one section to the next, each joint standing in a thin raised ridge catching its own soft glint and casting its own small shadow, nothing lying flat. Dense fitted sections — {base}, {acc}, polished to a warm satin sheen, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    return (f"full body {desc} fused directly to {pr} own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, this is solid stone curving to follow {pr} body's true three-dimensional shape, divided into dozens of fitted stone sections, each joint standing in a thin raised ridge catching its own bright glint and casting its own small shadow, nothing lying flat. Dense fitted sections — {base}, {acc}, high-gloss polished, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
_OP = _json.load(open("../../bk/outfit_pool.json", encoding="utf-8"))
OFAM = {"MicroBikini": 4, "Bandeau": 2, "Bust": 3, "Latex": 1, "Mesh": 1, "Cutout": 1, "Plunge": 1, "UltraMini": 2}
F_OUT = []
for fam, w in OFAM.items():
    for ko, nmw, tx in _OP[fam]:
        if fam in ("Cutout", "Plunge") and "롱" in ko: continue
        F_OUT += [(ko, tx)] * w
_MC = [("블랙 레더", "black leather"), ("화이트 레더", "white leather"), ("레드 라텍스", "glossy red latex"), ("골드 시퀸", "gold sequin")]
M_OUT = []
_LP = {"블랙 레더": "black leather", "화이트 레더": "white leather", "레드 라텍스": "glossy red latex", "골드 메탈": "polished gold metal"}
for ck, c in _LP.items():
    M_OUT.append((f"마이크로브리프+하네스 {ck}", f"wearing a minimal {c} micro brief of one tiny low-rise opaque triangle on thin side strings tied at the hips, the small opaque piece fully covering him, paired with a black leather chest harness of thin crossing straps with silver ring hardware, his chest and stomach otherwise fully visible"))
    M_OUT.append((f"쇼츠 탈의 {ck}", f"wearing skin-tight {c} shorts ending at the top of his thighs and nothing else, his whole chest and stomach bare and fully visible"))
    M_OUT.append((f"마이크로브리프+메시베스트 {ck}", f"wearing a minimal {c} micro brief of one tiny low-rise opaque triangle on thin side strings tied at the hips, the small opaque piece fully covering him, with a sheer black mesh open vest hanging open over his bare chest"))
    M_OUT.append((f"G-스트링 {ck}", f"wearing nothing but a minimal {c} g-string of one tiny opaque pouch on thin side strings tied at the hips and a thin back strap, the small opaque piece fully covering him, his skin otherwise fully bare"))
    M_OUT.append((f"만키니 {ck}", f"wearing nothing but a {c} mankini of two narrow straps rising over his shoulders from a small opaque pouch at the front, thin side strings tied at the hips, the small opaque piece fully covering him"))
M_OUT += [
 ("마이크로 포우치 블랙 레더", "wearing nothing but the smallest possible black leather micro pouch cut tight to the body on two thin side strings tied high at the hips and a thin strap at the back, the small opaque piece fully covering him, his skin otherwise fully bare"),
 ("마이크로 포우치 골드 메탈", "wearing nothing but a tiny polished gold metal micro plate cut tight to the body on two thin gold chains tied high at the hips and a thin chain at the back, the small opaque piece fully covering him, his skin otherwise fully bare"),
 ("마이크로 포우치 레드 라텍스", "wearing nothing but the smallest possible glossy red latex micro pouch cut tight to the body on two thin side straps tied high at the hips and a thin strap at the back, the small opaque piece fully covering him, his skin otherwise fully bare"),
 ("마이크로 포우치 화이트 레더", "wearing nothing but the smallest possible white leather micro pouch cut tight to the body on two thin side strings tied high at the hips and a thin strap at the back, the small opaque piece fully covering him, his skin otherwise fully bare"),
 ("마이크로 포우치 실버 메탈", "wearing nothing but a tiny polished silver metal micro plate cut tight to the body on two thin silver chains tied high at the hips and a thin chain at the back, the small opaque piece fully covering him, his skin otherwise fully bare")]
M_OUT += [
 ("레이스 T백 블랙", "wearing nothing but a minimal black lace T-back thong of one tiny opaque lace pouch on thin side strings tied at the hips and a single thin strap running down the back, the small opaque piece fully covering him, his skin otherwise fully bare"),
 ("시어 메시 T백 화이트", "wearing nothing but a minimal white sheer mesh T-back thong with one small opaque panel at the front on thin side strings tied at the hips and a single thin strap at the back, the small opaque piece fully covering him, his skin otherwise fully bare"),
 ("체인 T백 골드", "wearing nothing but a minimal T-back thong of thin polished gold chains, with one small opaque gold plate at the front on chain sides tied at the hips and a single thin gold chain down the back, the small opaque piece fully covering him, his skin otherwise fully bare"),
 ("로우라이즈 가죽 T백 블랙", "wearing nothing but a low-rise glossy black leather T-back thong with a tiny opaque pouch at the front on thin straps tied low at the hips and a single thin leather strap down the back, the small opaque piece fully covering him, his skin otherwise fully bare"),
 ("라텍스 T백 레드", "wearing nothing but a minimal glossy red latex T-back thong with a tiny opaque pouch at the front on thin straps tied at the hips and a single thin latex strap down the back, the small opaque piece fully covering him, his skin otherwise fully bare")]
M_OUT += [
 ("가죽 팬츠 탈의", "wearing skin-tight high-waisted black leather pants fitted from waist to ankle and nothing else, his whole chest and stomach bare and fully visible"),
 ("라텍스 캣슈트 젯 블랙", "wearing a skin-tight glossy jet-black latex catsuit with a high collar zipped up the front to the sternum and long sleeves, stretched over every line of his body from neck to ankle with mirror shine and fine pull-creases at the elbows and knees, completely opaque"),
 ("시어 메시 보디수트 블랙", "wearing a long-sleeved jet-black sheer mesh bodysuit with opaque panels covering the hips and seams, a high collar and high-cut legs, fitted to every line of his body"),
 ("체인 하네스+브리프 골드", "wearing a gold-chain body harness of thin chains crossing his chest and shoulders, with a minimal gold-chain-and-plate brief of one small opaque plate on thin chain sides tied at the hips, the small opaque piece fully covering him"),
 ("시퀸 레오타드 골드", "wearing a high-cut gold sequin leotard with a deep plunging neckline to the navel and large cutouts at both sides of the waist, cut high on the hips and fully covering him"),
 ("젖은 수영 브리프 블랙", "wearing a tiny glossy black swim brief, soaked and clinging, water streaming down his whole body in glistening rivulets with countless beads and droplets clinging to his skin, his hair soaking wet and slicked"),
 ("서스펜더+쇼츠 블랙 레더", "wearing tiny glossy black leather micro shorts cut high on the hips, held up by thin suspenders over his bare chest"),
 ("스트랩 하네스+포우치", "wearing nothing but a minimal black leather body harness of thin straps crossing his chest, shoulders and hips with silver ring hardware, with a tiny opaque leather pouch on thin strings fully covering him, his skin otherwise fully visible")]

# --- v2 pools: female = micro-bikini-bottom sets only (with color variants), male = smallest tier only ---
_COLS = [("블랙", "black"), ("화이트", "white"), ("딥 퍼플", "deep purple"), ("레드", "red"), ("코발트 블루", "cobalt-blue"), ("에메랄드 그린", "emerald-green"), ("핫 핑크", "hot pink")]
_CKO = {en: ko for ko, en in _COLS}
F_OUT = []
for fam, w in (("MicroBikini", 2), ("Bandeau", 1), ("Bust", 1)):
    for ko, nmw, tx in _OP[fam]:
        if fam == "Bust" and "플런지" in ko: continue
        m = re.search(r"(black|white|deep purple|red) (leather|satin)", tx)
        if m and "레드 젖음" not in ko and "골드" not in ko:
            for ckor, cen in _COLS:
                tx2 = re.sub(r"\b(black|white|deep purple|red) (leather|satin)", lambda mm: f"{cen} {mm.group(2)}", tx)
                ko2 = re.sub(r"(블랙|화이트|딥 퍼플|레드) (레더|새틴)", lambda mm: f"{ckor} {mm.group(2)}", ko)
                F_OUT += [(ko2, tx2)] * w
        else:
            F_OUT += [(ko, tx)] * w
_MKEEP = ("마이크로브리프+하네스", "G-스트링", "만키니", "마이크로 포우치", "T백", "스트랩 하네스+포우치")
M_OUT = [(k, t) for k, t in M_OUT if any(x in k for x in _MKEEP)]
print("F_OUT", len(F_OUT), "M_OUT", len(M_OUT), sorted({k for k, _ in M_OUT}))
USEDM = set()
_FAMRE = re.compile(r"\s+(블랙|화이트|딥 퍼플|레드|코발트 블루|에메랄드 그린|핫 핑크|골드|실버|네이비|레이스|젖음|레더|새틴|시퀸|라텍스|메탈|시어 메시).*$")
USED = set(); AXL = []; AX_ = ["P"]; SEL = [None]
_AXW2 = {"CC": 2, "CP": 3, "CS": 3, "PP": 1, "SS": 1, "PS": 2}
_AXW3 = {"CPS": 7, "CCP": 2.5, "CCS": 2.5, "CPP": 1.5, "CSS": 1.5, "PPS": 1, "PSS": 1, "CCC": 0.5}
def pick_axes(n, kinds):
    w = _AXW2 if n == 2 else (_AXW3 if n == 3 else ({"CCPS": 4, "CPSS": 2, "CPPS": 2, "CCPP": 1, "PPSS": 1, "CCSS": 1} if n == 4 else {"CCPSS": 3, "CCCPS": 2, "CPPSS": 2, "CCPPS": 3}))
    if AXOV[0]: return ["C"] * n
    while True:
        a = list(rnd.choices(list(w), weights=list(w.values()))[0]); rnd.shuffle(a)
        if all(not (k == "MF" and x == "C") for k, x in zip(kinds, a)): return a
def matart(lab, male):
    ax = AX_[0]; pr = "his" if male else "her"; Pr = pr.capitalize()
    if ax == "P":
        k = SEL[0]; mt, _ = GB["mat_text"](k)
        if male: mt = re.sub(r"\bher\b", "his", mt)
        return MAT_ART.format(lab=lab, mt=mt, pr=pr, Pr=Pr), GB["MAT_KO"][k]
    if ax == "S":
        kind, pick = SEL[0]; mt = matmat(kind, pick, pr)
        if male: mt = re.sub(r"\bher\b", "his", mt)
        return f"{lab} Body Art: {mt}. {Pr} face stays real living skin and the {'carving' if kind == '목재' else 'stone'} ends cleanly at the neck.", f"{kind} {SPKO[pick[0]]}"
    while True:
        ko, tx = (FQ.pop(0) if (not male and FQ) else rnd.choice(M_OUT if male else F_OUT))
        fam_ = _FAMRE.sub("", ko) if not ko.startswith("마이크로 비키니") else ko[:8] + ko.split()[-1] if False else _FAMRE.sub("", ko)
        if fam_ not in USED: USED.add(fam_); break
    return f"{lab} Outfit: {Pr} skin is bare and unpainted, {tx}.", ko
def shoe_ax(lab, male, kind):
    if AX_[0] != "S": return shoe2(lab, male, kind)
    k, pick = SEL[0]; full = spfull(k, pick[0]); pr = "his" if male else "her"
    if kind in ("M", "MF") and rnd.random() < 0.225:
        return f"{lab} Footwear: Extreme platform combat boots carved from the same {full}, the thick platform soles rising far higher than {pr} ankle bone, at least three times the thickness of an ordinary sole."
    return f"{lab} Footwear: Extreme thigh-high platform stiletto boots carved from the same {full}, each with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform."
def craft(c):
    cn, cd, cb, cf = CRAFT_DB_FULL[c]
    return f"{cn} ({cd}), wide {cb} bands following every deep crease and curving around the hips and thighs like contour lines, dense {cf} filling the space between every band", cn

import json, collections
import full_dicts as F
CORE = ["legendary bust", "curved bust", "siren bust hourglass", "glamour hourglass", "hourglass bombshell", "black glamour", "apex siren", "violin hip hourglass", "latina curves", "Brazilian booty glam"]
for _k in CORE: assert _k in POOL, _k
JTYPE_EN = {"JE":"earrings","JN":"necklaces","JB":"bracelets","JR":"rings","JA":"anklets","JH":"hair ornaments"}
JSING = {"JE":"earring","JN":"necklace","JB":"bracelet","JR":"ring","JA":"anklet","JH":"hair ornament"}
JMETAL_EN = {"JMG":"gold","JMS":"silver","JMR":"rose-gold","JMP":"platinum","JMX":"mixed-metal"}
JQ_SHORT = {"JQ1":"a single {m} {s}","JQ2":"two to three {m} {p}","JQ3":"four to six layered {m} {p}","JQ4":"seven to ten heavily stacked {m} {p}","JQ5":"an extreme maximalist stack of well over ten {m} {p}"}
MALEIDOL = ["a handsome young man's idol face with a clean sharp jawline, straight thick brows and defined expressive eyes", "a handsome male model face with high cheekbones, a straight nose, a firm jaw and straight dark brows", "a striking young male model face with sharp straight brows, a strong chin and a visible Adam's apple",
            "a sleek male idol face with a straight nose, a sharp jawline, thick brows and cool intense eyes", "a clean-cut young male model face with defined cheekbones, a firm jaw and strong straight brows", "an elegant handsome young male face with a high nose bridge, a defined jaw, straight brows and a strong neck"]
BOYISH = ["a pretty-boy idol face with flawless smooth skin, large clear eyes, a slim jaw and soft full lips", "a youthful idol face with a small V-line jaw, bright expressive eyes and a straight nose", "a delicate beautiful-boy face with long lashes, a slim straight nose and a clean jawline", "a fresh-faced boy-group idol face with clear glowing skin, bright eyes and a gentle smile line", "a youthful boy-group center idol face with neat sharp brows, a slim nose and glossy full lips", "a pretty androgynous idol face with large doe eyes, a small chin and a soft jaw"]
PRETTY = ["a pretty-boy idol face with flawless smooth skin, large clear eyes, a slim jaw and soft full lips", "a youthful idol face with a small V-line jaw, bright expressive eyes and a straight nose", "a delicate beautiful-boy face with long lashes, a slim straight nose and a clean jawline"]
IDOLF = ["a pretty-boy idol face with flawless smooth skin, large clear eyes, a slim jaw and soft full lips", "a youthful idol face with a small V-line jaw, bright expressive eyes and a straight nose", "a delicate beautiful-boy face with long lashes, a slim straight nose and a clean jawline", "a fresh-faced boy-group idol face with clear glowing skin, bright eyes and a gentle smile line", "a youthful boy-group center idol face with neat sharp brows, a slim nose and glossy full lips", "a pretty androgynous idol face with large doe eyes, a small chin and a soft jaw"]
IDOLB = ["clean-shaven", "a very faint trace of stubble", "a very faint trace of stubble"]
def face_pick():
    if rnd.random() < 0.65: return rnd.choice(MALEIDOL), rnd.choice(IDOLB), True
    return rnd.choice(BOYISH), "clean-shaven", True
AGESB = ["in his early 20s", "in his mid 20s", "in his late 20s", "in his early 30s", "in his mid 30s", "in his late 30s", "in his early 40s", "in his mid 40s"]
MKB = [("", ""), ("dramatic black smoky eyeshadow with sharp winged eyeliner", "블랙 스모키 윙"), ("metallic gold glitter eyeshadow with defined lashes", "골드 글리터 아이"), ("graphic electric-blue eyeliner extended into bold wings", "그래픽 블루 라인"), ("deep plum smoky eyes with dark lashes", "플럼 스모키"), ("silver foil-lined eyes with a cool shimmer", "실버 포일 아이")]
BADCRAFT = {"CroatianHvar", "FinnishIittala", "UkrainianPysanka"}
CRAFTS = [c for c in T.CRAFTS_39 if c not in BADCRAFT]
PLAT = lambda k: k.startswith("플랫폼") or k.startswith("익스트림플랫폼")
SHOEK = list(T.SHOES_24)
POSE_ALL = [k for k in T.POSE_19 if k != "얼굴감싸기"]
POSE_GRP = ["정면와이드스탠스", "3/4각도"]
LAB3 = ["LEFT", "CENTER", "RIGHT"]; LAB2 = ["LEFT", "RIGHT"]
ART = ("{lab}Body Art: Her bare skin is painted in {ct}. The paint is pigment sitting on living skin, so it distorts slightly over every bulge. The paint covers her whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of her hands, sides, back, rear, lower belly, knees, calves and the tops of her feet. Her face is left unpainted and the pattern fades out at the neck with no hard line.")
def shoe_line(lab):
    k = rnd.choice(SHOEK); en = re.sub(r"^extreme ", "", F.SHOE_EN_FULL[k]); col = rnd.choice(SHOECOL)
    if PLAT(k): return f"{lab}Footwear: Extreme {col} {en}, the platform soles rising far higher than her ankle bone, at least three times the thickness of an ordinary heel.", k
    return f"{lab}Footwear: Extreme {col} {en} with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform.", k

MBODIES = {
 "V자 보디빌더": "An extraordinarily large and powerful man, far beyond any real person. A massive V-shaped torso: enormously broad shoulders with capped, rounded deltoids, a thick heavy chest, a deeply carved six-pack abdomen narrowing to a comparatively small waist, huge thick arms with split biceps and horseshoe triceps, wide flaring lats, and powerful thick quads and diamond calves. His head stays in correct proportion to his broad frame.",
 "린 애슬레틱": "A tall, lean, athletic man built like a swimmer. Broad shoulders tapering cleanly to a narrow waist, a defined chest, a visible eight-pack abdomen with sharp obliques, long strong arms with clear vein definition, and long lean muscular legs with defined calves. Nothing bulky, everything taut and sculpted.",
 "키 큰 슬렌더": "A very tall, slim, long-limbed man with a runway build. Straight shoulders, a flat lean chest, a flat defined stomach, slender strong arms and very long legs, lightly muscled and elegant, with visible collarbones and a narrow waist. His head stays in correct proportion to his long frame.",
 "파워리프터": "A thick, heavy, extremely strong man built like a powerlifter. A huge barrel chest, enormously wide shoulders and back, a thick solid waist with a firm rounded belly over strong abs, massive arms, and enormous thick thighs and calves. Every part is large, dense and continuous rather than sharply cut.",
 "대형 헤비": "A giant, big-bellied man with great natural size throughout. Broad powerful shoulders, a wide heavy chest, a large round soft belly hanging over a thick waist, thick strong arms, and wide heavy thighs beneath. Every curve is large, solid and continuous, with a warm, imposing bearing.",
 "클래식 머슬": "A classically muscular athletic man in the shape of a Greek statue. Wide shoulders, a full defined chest, a clean six-pack abdomen, strong rounded arms, and muscular thighs and calves, balanced and proportionate from head to toe, powerful but not exaggerated.",
 "스트롱맨": "A massive, stocky strongman. A thick short neck, huge round shoulders, an enormously deep chest, a thick powerful midsection with a solid belly, tree-trunk arms, and huge thick legs planted wide. Heavy, dense and immovable, every part solid.",
 "중년 실버 아스레틱": "A fit mature man in his late 40s with an athletic, well-kept build. Broad shoulders, a firm defined chest, a flat strong abdomen with visible lines, strong forearms, and lean strong legs, with the quiet, assured bearing of a man who has trained for decades.",
}
NATS = [("Korean", "smooth fair skin with a warm undertone"), ("Korean", "luminous porcelain skin"), ("Chinese", "smooth fair skin with a neutral undertone"), ("Chinese", "light skin with a warm golden undertone"), ("Japanese", "smooth pale skin with a cool undertone"), ("Japanese", "smooth fair skin with a neutral undertone")]
FACE = ["a refined idol face with a clean sharp jawline and defined expressive eyes", "a handsome model face with high cheekbones and a straight nose", "a soft-featured idol face with large clear eyes and a defined jaw", "a striking model face with sharp brows and a narrow chin"]
BEARD = ["clean-shaven", "clean-shaven", "clean-shaven", "a very faint trace of stubble"]
MKU = [("natural idol makeup with soft brown eyeshadow and a tinted lip", "아이돌 내추럴 메이크업"), ("light smoky eyeliner and glossy skin", "라이트 스모키"), ("glass-skin makeup with a faint shimmer on the cheekbones", "글래스 스킨"), ("", "메이크업 없음")]
MOOD = ["calm and cool", "intense and focused", "composed and elegant", "relaxed with a faint half-smile", "fierce and charismatic"]
HK = ["HSS스트레이트", "HSW웨이브", "HSSK슬릭백", "HSSH샤기컷", "HSWF울프컷", "HSPX픽시컷", "HSTN탑노트"]
AGES = ["in his early 20s", "in his mid 20s", "in his late 20s", "in his early 30s", "in his mid 30s"]
NAILS = ["Short, clean nails with a matte black polish.", "Short natural nails.", "Short nails with a glossy dark-grey polish.", "Short nails with a metallic gold polish."]
_NEWB = {
 "맨즈 피지크": "An extraordinarily tall and large man, far beyond any real person, with a men's physique build. Enormously broad shoulders with round capped deltoids, a wide upper chest tapering sharply to a very narrow waist in a dramatic V-taper, a lean sharply defined six-pack abdomen with visible obliques, thick strong arms, and long lean athletic legs that are muscular but not bulky. His head stays in correct proportion to his broad frame.",
 "머슬 모델": "An extraordinarily large and muscular man, far beyond any real person, built like a muscle model. Wide broad shoulders, a full thick defined chest, large rounded arms with clear biceps and triceps, a hard defined abdomen on a trim waist, wide flaring lats, and strong muscular thighs and calves in balance with the upper body. Powerful and imposing, yet lean and polished. His head stays in correct proportion to his broad frame.",
 "피트니스 모델": "A tall, extraordinarily well-built athletic man, far beyond any real person in size, built like a fitness model. Broad shoulders, a full athletic chest, a lean defined abdomen with a clear eight-pack, strong toned arms, a narrow waist, and long strong toned legs with defined calves. Large and powerful in frame, yet taut, lean and elegant rather than bulky. His head stays in correct proportion to his frame.",
}
MBODY_MAIN = ["V자 보디빌더", "클래식 머슬", "머슬 모델", "맨즈 피지크", "피트니스 모델"]
MBODY = MBODY_MAIN * 3 + ["파워리프터", "대형 헤비"]
MBODIES.update(_NEWB)
MNATS = [("Korean", "smooth fair skin with a warm undertone"), ("Korean", "luminous porcelain skin"), ("Chinese", "smooth fair skin with a neutral undertone"), ("Chinese", "light skin with a warm golden undertone"), ("Japanese", "smooth pale skin with a cool undertone"), ("Japanese", "smooth fair skin with a neutral undertone")]
BOYF = ["a pretty-boy idol face with flawless smooth skin, large clear eyes, a slim jaw and soft full lips", "a youthful idol face with a small V-line jaw, bright expressive eyes and a straight nose", "a delicate beautiful-boy face with long lashes, a slim straight nose and a clean jawline", "a fresh-faced boy-group idol face with clear glowing skin, bright eyes and a gentle smile line", "a youthful boy-group center idol face with neat sharp brows, a slim nose and glossy full lips", "a pretty androgynous idol face with large doe eyes, a small chin and a soft jaw"]
EYEMK = [x[0] for x in MKB if x[0]]
MMOOD = ["calm and cool", "intense and focused", "composed and elegant", "relaxed with a faint half-smile", "fierce and charismatic"]
FHS = [h for h in T.HAIR_STYLE if h[:4] not in ("HSTT", "HSSB")]
FEMBODY = ["legendary bust", "curved bust", "siren bust hourglass", "glamour hourglass", "hourglass bombshell", "black glamour", "apex siren", "violin hip hourglass", "latina curves", "Brazilian booty glam"]
MART = ("{lab} Body Art: His bare skin is painted in {ct}. The paint is pigment sitting on living skin, so it distorts slightly over every muscle and bulge. The paint covers his whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of his hands, sides, back, rear, lower belly, knees, calves and the tops of his feet. His face is left unpainted and the pattern fades out at the neck with no hard line.")
FART = ("{lab} Body Art: Her bare skin is painted in {ct}. The paint is pigment sitting on living skin, so it distorts slightly over every bulge. The paint covers her whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of her hands, sides, back, rear, lower belly, knees, calves and the tops of her feet. Her face is left unpainted and the pattern fades out at the neck with no hard line.")
def pose_t(k, male):
    t = F.POSE_EN_FULL[k]
    return re.sub(r"\bherself\b", "himself", re.sub(r"\bher\b", "his", t)) if male else t
MSHOES = ["combat boots", "chunky platform boots", "high-top platform sneakers", "cowboy boots", "work boots", "thick-soled derby shoes", "chelsea boots", "platform loafers"]
MSHOECOL = ["black", "white", "tan-brown", "silver", "red", "cobalt-blue", "gold", "olive-green"]
def shoe2(lab, male, kind="F"):
    if kind in ("M", "MF") and rnd.random() < 0.225:
        pr = "his" if male else "her"
        return f"{lab} Footwear: Extreme {rnd.choice(MSHOECOL)} {rnd.choice(MSHOES)} with thick platform soles rising far higher than {pr} ankle bone, at least three times the thickness of an ordinary sole."
    k = rnd.choice(list(T.SHOES_24)); en = re.sub(r"^extreme ", "", F.SHOE_EN_FULL[k]); col = rnd.choice(SHOECOL); pr = "his" if male else "her"
    if PLAT(k): return f"{lab} Footwear: Extreme {col} {en}, the platform soles rising far higher than {pr} ankle bone, at least three times the thickness of an ordinary heel."
    return f"{lab} Footwear: Extreme {col} {en} with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform."
def jw():
    q = rnd.choice(list(JQ_SHORT)); jm = JMETAL_EN[rnd.choice(list(JMETAL_EN))]; jt = rnd.choice([k for k in JTYPE_EN if k != "JE"]); return JQ_SHORT[q].format(m=jm, s=JSING[jt], p=JTYPE_EN[jt])
SHAPES = ["a round bell", "a chunky hexagonal nut-shaped weight with a round hole through the centre", "a cube-shaped block", "a square-sided cowbell", "a barrel-shaped weight", "a hammer head", "a teardrop-shaped sinker", "a small flared temple bell", "a ship's anchor", "a miniature anvil", "a pyramid-shaped lump"]
GEMS = ["ruby", "emerald", "sapphire", "diamond", "amethyst", "topaz", "pearl-cluster", "aquamarine"]
CHAINM = ["gold", "silver", "rose-gold", "platinum", "copper", "brass", "bronze"]
WMET = ["iron", "gold", "tin", "silver", "lead", "bronze", "copper"]
WMW = [1, 2, 1, 2, 1, 1, 1]
BRI = {"gold", "silver"}
def wear(n):
    cm = rnd.choice(CHAINM)
    while True:
        ms = [rnd.choices(WMET, weights=WMW)[0] for _ in range(n)]
        if (n == 1 or len(set(ms)) >= 2) and (BRI & set(ms)): break
    sh = rnd.sample(SHAPES, n)
    items = ", ".join(f"{'an' if m == 'iron' else 'a'} {m} {re.sub(r'^an? ', '', x)}" for m, x in zip(ms, sh)); nw = ["zero", "one", "two", "three", "four", "five", "six"][n]
    return f"a large {cm} hoop carrying {nw} heavy rough hammered matte metal weight{'s' if n > 1 else ''} on {cm} chain{'s of different lengths' if n > 1 else ''} ({items}), all hanging clear of the body and none below the collarbone"
def one_line():
    return f"a single long {rnd.choice(CHAINM)} chain ending in one large faceted {rnd.choice(GEMS)} drop"
def earr():
    t = rnd.randrange(4)
    if t == 0: return f"a different earring on each ear: on one ear {one_line()}, and on the other ear {wear(rnd.choice([2, 3, 4, 5]))}"
    if t == 1:
        n1 = rnd.choice([1, 2, 3, 4, 5]); n2 = rnd.choice([x for x in (2, 3, 4, 5, 6) if x != n1]); return f"a different earring on each ear: on one ear {wear(n1)}, and on the other ear {wear(n2)}"
    if t == 2: return f"a different earring on each ear: on one ear {wear(rnd.choice([3, 4, 5]))}, and on the other ear {one_line()} with a heavy rough {rnd.choice(WMET[1:])} {rnd.choice(SHAPES)} hanging at its end"
    n = rnd.choice([2, 3, 4]); return f"matching-style earrings on both ears, each ear {wear(n)}"

REG_F = {"EA": ["Japanese", "Korean", "Chinese"], "SEA": ["Thai", "Filipina", "Vietnamese"], "SA": ["Indian", "Pakistani", "Uzbek"], "BLACK": ["Nigerian", "Ethiopian", "Yoruba Nigerian", "Jamaican"],
         "ME": ["Iranian", "Lebanese", "Emirati", "Egyptian", "Turkish"], "EU": ["French", "Russian", "Italian", "Ukrainian", "Swedish", "Romanian", "Norwegian", "Spanish", "German"], "LAT": ["Latina", "Brazilian"], "PAC": ["American", "Hawaiian"]}
REG_W = {"EA": 1, "SEA": 1, "SA": 1, "BLACK": 1.6, "ME": 1.4, "EU": 1.8, "LAT": 1, "PAC": 0.8}
_NATMK = collections.defaultdict(list)
for _k in T.MAKEUP_48: _NATMK[face_nohair(_k)[0]].append(_k)
def pick_mk():
    reg = rnd.choices(list(REG_W), weights=list(REG_W.values()))[0]
    nat = rnd.choice([n for n in REG_F[reg] if _NATMK.get(n)])
    return rnd.choice(_NATMK[nat])
MN_REG = {"EA": [("Korean", "luminous porcelain skin"), ("Japanese", "smooth pale skin with a cool undertone"), ("Chinese", "smooth light skin with a warm golden undertone")],
 "SEA": [("Thai", "smooth golden-tan skin"), ("Vietnamese", "smooth warm light-tan skin"), ("Filipino", "smooth warm tan skin")],
 "SA": [("Indian", "smooth warm brown skin with a soft glow"), ("Pakistani", "smooth light-brown skin with a warm undertone"), ("Uzbek", "fair olive skin with a warm undertone")],
 "BLACK": [("Nigerian", "deep rich dark-brown skin with a smooth satin glow"), ("Ethiopian", "smooth medium-brown skin with a warm red undertone"), ("Senegalese", "deep blue-black skin with a smooth sheen"), ("Jamaican", "smooth deep caramel-brown skin"), ("Kenyan", "deep ebony skin with a soft glow")],
 "ME": [("Iranian", "olive skin with a warm undertone"), ("Lebanese", "smooth olive-tan skin"), ("Emirati", "smooth warm golden-tan skin"), ("Egyptian", "smooth warm light-brown skin"), ("Turkish", "fair olive skin with a warm undertone")],
 "EU": [("French", "fair skin with a faint rosy undertone"), ("Swedish", "very pale smooth skin with a cool undertone"), ("Italian", "smooth light-olive skin"), ("Spanish", "smooth warm olive skin"), ("Russian", "pale smooth skin with a cool undertone"), ("German", "fair skin with a neutral undertone"), ("Ukrainian", "fair smooth skin"), ("Norwegian", "pale smooth skin with a soft pink undertone")],
 "LAT": [("Brazilian", "smooth warm bronze skin"), ("Mexican", "smooth warm light-brown skin"), ("Colombian", "smooth golden-tan skin"), ("Argentinian", "smooth light-olive skin")],
 "PAC": [("Hawaiian", "smooth warm bronze skin"), ("Samoan", "smooth warm brown skin"), ("Maori", "smooth warm olive-brown skin")]}
MAGES = ["in his early 20s", "in his mid 20s", "in his mid 20s", "in his late 20s", "in his late 20s", "in his early 30s"]
EXPM = ["a warm natural smile", "a bright open smile showing his teeth", "a gentle soft smile", "a playful half-grin", "a relaxed easygoing look with a faint smile", "a calm gentle gaze", "a cool composed look", "a shy sweet smile", "a confident smirk", "a soft amused smile"]
EXPMF = ["a gentle soft smile", "a relaxed half-smile", "a calm easy look", "a confident smirk", "a soft amused smile"]
MKM = [("natural idol makeup with soft brown eyeshadow and a tinted lip", "아이돌 내추럴"), ("glass-skin makeup with a faint shimmer on the cheekbones", "글래스 스킨"), ("light smoky eyeliner and glossy skin", "라이트 스모키"),
       ("dramatic black smoky eyeshadow with sharp winged eyeliner", "블랙 스모키 윙"), ("metallic gold glitter eyeshadow with defined lashes", "골드 글리터"), ("graphic electric-blue eyeliner extended into bold wings", "블루 라인"),
       ("deep plum smoky eyes with dark lashes", "플럼 스모키"), ("silver foil-lined eyes with a cool shimmer", "실버 포일"), ("soft peach-pink eyeshadow, subtly glossy lips and a dewy highlight on the cheekbones", "피치 듀이"),
       ("bold emerald-green eyeliner with a sheer burgundy-stained lip", "에메랄드 라인"), ("sparkling glitter dusted under the eyes with rose-gold eyeshadow", "로즈골드 글리터"), ("sharp black graphic eyeliner with matte nude lips and defined contour", "그래픽 블랙"),
       ("copper-bronze smoky eyes with a golden highlight", "코퍼 브론즈"), ("pearly white eyeshadow with a clear gloss lip and soft blush", "펄 화이트 글로시")]
def pick_nm():
    reg = rnd.choices(list(REG_W), weights=list(REG_W.values()))[0]
    return rnd.choice(MN_REG[reg])
def nailz():
    fin = {"FC": "chrome", "FT": "glitter", "FH": "holographic"}[rnd.choice(["FC", "FT", "FH"])]
    if AX_[0] == "S":
        k_, pk_ = SEL[0]; return f"Extra long nails in matching polished {spfull(k_, pk_[0])}."
    return f"Extremely long {NAIL_SHAPE_EN_FULL[rnd.choice(T.NAIL_SHAPES)]} nails, {fin} finish studded with crystals."
def person(lab, kind, bkey, pk):
    AX_[0] = AXL.pop(0)
    while True:
        SEL[0] = rnd.choices(MATP, weights=MW)[0] if AX_[0] == "P" else (rnd.choice(WSP) if AX_[0] == "S" else None)
        if SEL[0] is None or str(SEL[0]) not in USEDM: break
    if SEL[0] is not None: USEDM.add(str(SEL[0]))
    hs = rnd.choice(FHS); hc = rnd.choice(T.HAIR_COLOR); hair = f"{HAIR_COLOR_EN_FULL[hc]} hair styled in {HAIR_EN_FULL[hs]}"
    if kind == "F":
        mk = pick_mk(); nat, fa = face_nohair(mk)
        t1 = f"{lab}: ONE real adult {nat} woman, her face exactly the same tone as her body, real skin texture with visible pores and fine grain, {fa}, {hair}, real living eyes, wearing {earr()}, and {jw()}. {nailz()}"
        ph = f"{lab} Physique: {POOL[bkey]} Her arms, hands, legs and feet stay in correct proportion to each other."
        art, cn = matart(lab, False); pose = f"{lab} Pose: {pose_t(pk, False)}."; tag = f"여성 {KO.get(bkey, bkey)}·메이크업 {mk}"
    elif kind == "MF":
        natm, skinm = pick_nm(); agem = rnd.choice(MAGES); mkt, mko = rnd.choice(MKM)
        fc, bd = rnd.choice(MALEIDOL), rnd.choice(IDOLB)
        mk = (", " + mkt) if mkt and False else ""
        t1 = f"{lab}: ONE real adult {natm} person with a handsome man's face on a full, curvaceous female body — a man {agem}, his face exactly the same tone as his body, real skin texture with visible pores and fine grain, {fc}, {bd}, {mkt}, {skinm}, {rnd.choice(EXPMF)}, {hair}, real living eyes, wearing {earr()}, and {jw()}. {nailz()}"
        ph = f"{lab} Physique: {POOL[bkey]} Her arms, hands, legs and feet stay in correct proportion to each other."
        art, cn = matart(lab, False); pose = f"{lab} Pose: {pose_t(pk, False)}."; tag = f"남성얼굴·여성체형 {KO.get(bkey, bkey)}·메이크업 {mko}"
    else:
        nat, skin = pick_nm(); age = rnd.choice(MAGES); mkt, mko = rnd.choice(MKM)
        t1 = f"{lab}: ONE real adult {nat} man {age}, his face exactly the same tone as his body, real skin texture with visible pores and fine grain, {rnd.choice(BOYF)}, clean-shaven, {mkt}, {skin}, {rnd.choice(EXPM)}, {hair}, real living eyes, wearing {earr()}, and {jw()}. {nailz()}"
        ph = f"{lab} Physique: {MBODIES[bkey]} His arms, hands, legs and feet stay in correct proportion to each other."
        art, cn = matart(lab, True); pose = f"{lab} Pose: {pose_t(pk, True)}."; tag = f"남성 {bkey}·메이크업 {mko}"
    return "\n".join([t1, ph, art, pose, shoe_ax(lab, kind == "M", kind)]), f"{tag}({cn})"
SKINP = "Real photographic skin — visible pores and fine grain, a taut surface with natural creases and shadow only where the flesh and muscle fold. No smooth illustration finish, no plastic CG sheen."
def build(kinds):
    n = len(kinds); labs = ["LEFT", "RIGHT"] if n == 2 else ["LEFT", "CENTER", "RIGHT"]
    _bid = rnd.choice(OUTD); BGD = _BG.desc(_bid); BGK = [b[2] for b in _BG.B if b[0] == _bid][0]
    BGD = BGD.replace("completely empty of other people", "empty of any people other than the subjects").replace("made of the same material as her", "made of the same material as them")
    blocks, tags = [], []
    for lab, kd in zip(labs, kinds):
        bk = rnd.choice(MBODY) if kd == "M" else rnd.choice(FEMBODY)
        t, tg = person(lab, kd, bk, rnd.choice(POSE_GRP)); blocks.append(t); tags.append(tg)
    if n == 2:
        fmt = "a vertical portrait-orientation photograph, 4:5 aspect ratio, taller than it is wide"; word = "TWO people standing side by side with generous spacing so every figure reads clearly and nobody's arms cross a neighbour"; cam = "the camera set back so both are visible from head to toe"; endl = "Vertical 4:5 portrait-orientation full-body photograph, taller than it is wide, all faces toward the camera."
    else:
        fmt = "a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide"; word = "THREE people standing close side by side, shoulder to shoulder in a single row, with just enough spacing that every figure reads clearly and nobody's arms cross a neighbour"; cam = "the camera set back far enough that all three are visible from head to toe, the whole row filling the width of the tall frame"; endl = "Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide, all faces toward the camera."
    p = (f"Image format: {fmt}.\n\n"
         f"A full-body photograph in {BGD}, {word}, {cam}, shot on a medium format camera with an 85mm lens at f/8, in natural sunlight, sharp focus on every figure, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n"
         + "\n\n".join(blocks) + "\n\n" + f"Skin (everyone): {SKINP}\n\n"
         f"Background & Lighting: each material catching the sunlight in sharp glints, the sunlight carving every fold, curve and muscle. {endl}")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), re.findall(r"\b(\w+) \1\b", p)
    return p, " / ".join(tags), BGK

import json, collections, itertools
DECKF = []; DECKM = []
def pickbody(kd):
    deck, pool = (DECKM, MBODY) if kd == "M" else (DECKF, FEMBODY)
    if not deck: deck.extend(rnd.sample(pool, len(pool)))
    return deck.pop()
_orig_rc = rnd.choice

F_OUT = [(ko, tx) for ko, nmw, tx in _OP["MicroBikini"]]
def _top(ko_key, fam):
    for ko, nmw, tx in _OP[fam]:
        if ko == ko_key: return tx
    raise KeyError(ko_key)
def _bot(c): return f"wearing a minimal {c} micro bikini bottom of one tiny low-rise opaque triangle on thin side strings tied at the hips, the small opaque piece fully covering her, paired with "
TOPS = {
 "패치 white leather": _bot("white leather") + "two tiny opaque white leather adhesive triangle patches stuck directly onto the skin, with no straps, strings, bra or top of any kind, each just big enough to cover only her nipple and nothing more, leaving the rest of her bust visible around them, her stomach fully visible below",
 "패치 deep purple leather": _bot("deep purple leather") + "two tiny opaque deep purple leather adhesive triangle patches stuck directly onto the skin, with no straps, strings, bra or top of any kind, each just big enough to cover only her nipple and nothing more, leaving the rest of her bust visible around them, her stomach fully visible below",
 "패치 black leather": _bot("black leather") + "two tiny opaque black leather adhesive triangle patches stuck directly onto the skin, with no straps, strings, bra or top of any kind, each just big enough to cover only her nipple and nothing more, leaving the rest of her bust visible around them, her stomach fully visible below",
}
FQ = []
_FAMRE = re.compile(r"$^")
ASP4 = ['1:1']
AXOV = [False]
def build2(kinds):
    AXL[:] = pick_axes(len(kinds), kinds); USED.clear(); USEDM.clear()
    n = len(kinds); labs = ["SUBJECT"] if n == 1 else ["LEFT", "RIGHT"] if n == 2 else (["LEFT", "CENTER", "RIGHT"] if n == 3 else (["FAR LEFT", "CENTER LEFT", "CENTER RIGHT", "FAR RIGHT"] if n == 4 else ["FAR LEFT", "LEFT", "CENTER", "RIGHT", "FAR RIGHT"]))
    _bid = rnd.choice(OUTD); BGD = _BG.desc(_bid); BGK = [b[2] for b in _BG.B if b[0] == _bid][0]
    if n > 1: BGD = BGD.replace("completely empty of other people", "empty of any people other than the subjects").replace("made of the same material as her", "made of the same material as them")
    blocks, tags, metas = [], [], []
    for lab, kd in zip(labs, kinds):
        bk = pickbody(kd); pk = rnd.choice(POSE_GRP)
        t, tg = person(lab, kd, bk, pk); blocks.append(t); tags.append((kd, bk, tg)); metas.append(dict(kind=kd, body=bk, pose=pk))
    if n == 1:
        fmt = "a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide"; asp = "2:3"; word = "ONE person standing"; cam = "sharp focus from head to toe"; endl = "Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide, the face toward the camera."
    elif n == 2:
        fmt = "a vertical portrait-orientation photograph, 4:5 aspect ratio, taller than it is wide"; asp = "4:5"; word = "TWO people standing side by side with generous spacing so every figure reads clearly and nobody's arms cross a neighbour"; cam = "the camera set back so both are visible from head to toe"; endl = "Vertical 4:5 portrait-orientation full-body photograph, taller than it is wide, all faces toward the camera."
    elif n == 3:
        fmt = "a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide"; asp = "2:3"; word = "THREE people standing close side by side, shoulder to shoulder in a single row, with just enough spacing that every figure reads clearly and nobody's arms cross a neighbour"; cam = "the camera set back far enough that all three are visible from head to toe, the whole row filling the width of the tall frame"; endl = "Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide, all faces toward the camera."
    else:
        asp = ASP4[0]; NW = {4: "FOUR", 5: "FIVE"}[n]; nw = NW.lower()
        if asp == "1:1":
            fmt = "a square photograph, 1:1 aspect ratio"; endl = "Square 1:1 full-body photograph, all faces toward the camera."
        elif asp == "5:4":
            fmt = "a landscape-orientation photograph, 5:4 aspect ratio, wider than it is tall"; endl = "Landscape 5:4 full-body photograph, wider than it is tall, all faces toward the camera."
        else:
            fmt = "a vertical portrait-orientation photograph, 3:4 aspect ratio, taller than it is wide"; endl = "Vertical 3:4 portrait-orientation full-body photograph, taller than it is wide, all faces toward the camera."
        word = f"{NW} people standing close side by side, shoulder to shoulder in a single row, with just enough spacing that every figure reads clearly and nobody's arms cross a neighbour"; cam = f"the camera set back far enough that all {nw} are visible from head to toe, the whole row filling the width of the frame"
    p = (f"Image format: {fmt}.\n\n"
         f"A full-body photograph in {BGD}, {word}, {cam}, shot on a medium format camera with an 85mm lens at f/8, in natural sunlight, sharp focus on every figure, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n"
         + "\n\n".join(blocks) + "\n\n" + f"Skin (everyone): {SKINP}\n\n"
         f"Background & Lighting: each material catching the sunlight in sharp glints, the sunlight carving every fold, curve and muscle. {endl}")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), re.findall(r"\b(\w+) \1\b", p)
    return p, tags, metas, BGK, asp
def short(kd, bk, tg, lv=0):
    mk = re.search(r"메이크업 (.*?)\(", tg); mt = re.search(r"\(([^()]*)\)$", tg); mk = mk.group(1) if mk else ""; mt = mt.group(1) if mt else ""
    nm = {"F": "여 ", "MF": "남얼굴 ", "M": "남 "}[kd] + KO.get(bk, bk)
    return nm + ("·" + mk if lv == 0 and mk else "") + ("·" + mt if lv <= 1 and mt else "")

import json
PLAN = [(("F",), "패치 white", "솔로"), (("F",), "패치 deep", "솔로"), (("F", "M"), "패치 black", "듀오"),
        (("F", "M", "F"), "패치 white", "트리오"), (("M", "F", "F"), "패치 deep", "트리오")]
rows = []
AXOV[0] = True
for i, (kinds, tk, gl) in enumerate(PLAN, 1):
    key_ = [k_ for k_ in TOPS if k_.startswith(tk)][0]
    while True:
        FQ[:] = [(key_, TOPS[key_])]
        try: p, tags, metas, BGK, asp = build2(list(kinds)); break
        except AssertionError: continue
    for lv in (0, 1, 2):
        title = f"MixedAxis PatchTest #{i:03d} · " + " / ".join(short(*t, lv) for t in tags)
        if len(title) <= 103: break
    rows.append({"key": f"la_patchtest_{i:03d}", "label": f"{gl} · {key_}", "title": title, "prompt": p, "asp": asp, "kinds": list(kinds)})
json.dump(rows, open("/mnt/user-data/outputs/la_patchtest1.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for r in rows: print(r["asp"], len(r["prompt"].split()), r["label"], "|", r["title"])
