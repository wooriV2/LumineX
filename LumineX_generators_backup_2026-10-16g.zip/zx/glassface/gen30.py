# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g18 = load("g18","gen18.py"); g3 = g18.g3; MAT = g18.MAT; BUST_BODY = g18.BODY
nat, mk, fc = g3.face_of("비주얼계")
an, adesc, ainner = MAT["smoky"]; bn, bdesc, binner = MAT["alabaster"]
btext = BUST_BODY["bust"][1]

MIX = "in black steel and silver, alternating piece by piece"
def pierce(level):
    if level == 200:
        return ("An overwhelming armour of about two hundred real piercings " + MIX + ", covering the face, neck, shoulders and arms: "
        "a thick septum ring with a smaller ring above it, three rings through each nostril and a small stud at the tip of the nose; two straight bars across the bridge of the nose between the brows; six thick bars stacked through the outer half of each eyebrow; three rows of five small studs across the forehead above the brows; six small studs up each temple on the bone, well clear of the eyes; two rows of six small studs along each cheekbone; a Medusa stud above the lips with a small stud on each side of it; "
        "a big hoop, four smaller rings and a snake-bite ring on each side through the lower lip's edge, and six small hoops along the upper lip's edge; a labret stud and five rings through the chin; six small studs along each jaw; a column of five small studs down each side of the neck; on each ear a full dense row of twelve oversized hoops, thick bars, stretched plugs, helix rings and studs from lobe to top, the biggest hoops hanging clear of the neck down to the shoulders; ten fine chains looping from the ear hoops to the nostril rings and the septum ring; "
        "and on the body, a row of six small domed jewels on anchored posts along each shoulder cap, four thick surface bars across each upper arm, real rings on every finger of both hands, six surface bars a hand's breadth below the collarbones, and eight fine chains looping from the ear hoops down to the shoulder jewels.")
    if level == 250:
        return ("An overwhelming armour of about two hundred and fifty real piercings " + MIX + ", covering the face, neck, shoulders and arms: "
        "a thick septum ring with a smaller ring above it, three rings through each nostril and a small stud at the tip of the nose; two straight bars across the bridge of the nose between the brows; six thick bars stacked through the outer half of each eyebrow; five rows of five small studs across the forehead above the brows; eight small studs up each temple on the bone, well clear of the eyes; three rows of six small studs along each cheekbone; a Medusa stud above the lips with a small stud on each side of it; "
        "a big hoop, four smaller rings and a snake-bite ring on each side through the lower lip's edge, and six small hoops along the upper lip's edge; a labret stud and five rings through the chin; eight small studs along each jaw; two columns of five small studs down each side of the neck; on each ear a full dense row of fifteen oversized hoops, thick bars, stretched plugs, helix rings and studs from lobe to top, the biggest hoops hanging clear of the neck down to the shoulders; fourteen fine chains looping from the ear hoops to the nostril rings and the septum ring; "
        "and on the body, a row of ten small domed jewels on anchored posts along each shoulder cap, six thick surface bars across each upper arm, two surface bars across each forearm, two real rings around each wrist, real rings on every finger of both hands, six surface bars a hand's breadth below the collarbones, and eight fine chains looping from the ear hoops down to the shoulder jewels.")
    return ("An overwhelming armour of about three hundred real piercings " + MIX + ", covering the face, neck, shoulders and arms: "
        "a thick septum ring with two smaller rings above it, four rings through each nostril, a small stud at each side of the tip of the nose; three straight bars across the bridge of the nose between the brows; eight thick bars stacked through the outer half of each eyebrow; five rows of six small studs across the forehead above the brows; eight small studs up each temple on the bone, well clear of the eyes; three rows of six small studs along each cheekbone; a Medusa stud above the lips with two small studs on each side of it; "
        "a big hoop, four smaller rings and two snake-bite rings on each side through the lower lip's edge, and eight small hoops along the upper lip's edge; two labret studs and eight rings through the chin; eight small studs along each jaw; two columns of five small studs down each side of the neck; on each ear a full dense row of fifteen oversized hoops, thick bars, stretched plugs, helix rings and studs from lobe to top, the biggest hoops hanging clear of the neck down to the shoulders; twelve fine chains looping from the ear hoops to the nostril rings and the septum ring; "
        "and on the body, a row of ten small domed jewels on anchored posts along each shoulder cap, six thick surface bars across each upper arm, four surface bars across each forearm, two real rings around each wrist, real rings on every finger of both hands and a second ring on six of them, eight surface bars a hand's breadth below the collarbones, and ten fine chains looping from the ear hoops down to the shoulder jewels.")

DENS_X = " The piercings are packed so densely that the rows touch and overlap, leaving almost no bare surface, until the face, neck, shoulders and arms read as a single sculpted armour of metal; only the eyeballs and eyelids stay clear."
CARE_FACE = "All face and neck jewelry is real opaque metal in real skin that is healed, clean and calm — no blood, no redness, no swelling, no wound — with a small natural warm shadow under each piece. All jewelry on the body passes through drilled openings in the transparent material or sits on anchored posts, never turning into the material. Brow bars stay on the brow bone and every stud stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes."

def build(level):
    return f"""Professional fashion photograph, bust shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head to just below her chest, the frame cutting off beneath the chest. Her face sits large and sharp in the upper half of the frame. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult Japanese woman in visual-kei makeup — {fc.replace('a cold, poised expression','a cold, poised expression')}. Her whole face, ears and neck are real living flesh with real pores and fine skin grain — a photograph of a real face, not an illustration.

Piercings: {pierce(level)}{DENS_X} {CARE_FACE}

Physique: {btext}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest): solid {adesc}, with {ainner}. Right half: solid {bdesc}, with {binner}. Each is carved as one solid sculpted mass like a statue, never hollow, the chest two great rounded masses with the groove between them cut into the material itself. The arms flow into the chest with no seam, and every wrist, palm, finger and knuckle is the same material as its arm.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the chest and out of the bottom of the frame where the two materials meet, never horizontal. Shards interlock along the lines only, every edge solid all the way through.

Pose: body angled 45 degrees, her left hand (solid material) held low at the frame edge beside her chest, her right hand (solid material) held at chest height clear of her body, well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal light on her face and ears only, so the glints on every piece of metal read clearly; a strong backlight through each half so both sides of the body glow from within; a thin cool rim light along the centre line. 2:3 vertical 8K portrait."""

OUT = {n: build(n) for n in (200, 250, 300)}
if __name__ == "__main__":
    for n, p in OUT.items():
        print(n, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
