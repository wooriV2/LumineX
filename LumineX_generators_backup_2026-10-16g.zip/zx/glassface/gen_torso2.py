# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g2 = load("g2","gen2.py"); g3 = load("g3","gen3.py")
MAT = g2.MAT
REAL_FACE = "Her whole face, ears and neck are real living flesh with real pores and fine grain."

TORSO_INTRO = ("Professional fashion photograph, sculpted display torso. ONE woman's head, neck, shoulders, chest, belly and hips, presented exactly in the manner of a couture atelier's fitting mannequin or a boutique window-display torso — no arms, no lower legs, the form ending in a smooth, deliberately tapered point at the top of the thighs where it meets a slender dark pedestal rod, exactly like a tailor's dress form. This taper is always the clean finished edge of a display object, never a wound, never torn, nothing organic at the point where it ends. Her face is angled 45 degrees toward the camera, large and sharp, filling the upper part of the frame, with the whole sculpted torso visible below it down to the top of the thighs.")

GLASS_TORSO = ("The glass is unmistakably glass: thick, crystal-clear and polished, with bright specular reflections sliding along every curved surface, sharp white highlights and dark refraction edges where the walls are thickest, tiny bubbles trapped in the glass itself. The shoulders, chest, belly and hips keep their exact sculpted shapes as clear glass outlines, and a clean glass rim runs along the boundary where the vessel meets the neck.")

def T1_solid(desc, inner):
    return (f"Below the neck, her entire visible form — shoulders, chest, belly and hips — is not painted, covered or clothed but physically made of ONE solid, transparent material, solid {desc}, with {inner}. "
            f"It is carved as one continuous sculpted mass, exactly like a display torso cut from a single flawless block of gemstone, never hollow, with no seam, no second material and nothing suspended within it — pure, uniform stone throughout, polished to a soft gloss, every curve and crease of the body carved into the stone itself.")

def T2_vessel(content):
    return (f"Below the neck, her entire visible form — shoulders, chest, belly and hips — is a sculpted vessel of thick, crystal-clear glass in the exact shape of the torso, filled completely to the brim so nothing is hollow and there is no air gap. {GLASS_TORSO} "
            f"The vessel holds ONE single world, unbroken and continuous through the whole chest, belly and hips, with no split, no second world and no change of contents anywhere: {content}")

def T3_combined(desc, inner, objects):
    return (f"Below the neck, her entire visible form — shoulders, chest, belly and hips — is ONE solid, continuous block of {desc}, with {inner}, carved as one uniform sculpted mass, never hollow, never split down the centre. "
            f"Yet suspended deep within this solid stone, visible through it exactly like objects frozen inside a single flawless crystal, are {objects}, spread naturally through the chest, the belly and the hips, each one fully embedded in the solid material with no cavity, no hollow chamber and no liquid around it — the stone itself grew solid around them. "
            f"The material reads as one unbroken solid mass throughout; the embedded shapes are simply what is visible deep inside it, not a separate vessel.")

def T4_split(descA, innerA, descB, innerB):
    return (f"Below the neck, her entire visible form — shoulders, chest, belly and hips — is split down the exact centre into two solid transparent materials, with nothing beneath and no skin anywhere. "
            f"Left half (left shoulder, half the chest, belly and hip): solid {descA}, with {innerA}. Right half: solid {descB}, with {innerB}. Each half is carved as one solid sculpted mass, never hollow, the groove between the two sides of the chest and the crease of the belly cut into the material itself, the centre line continuing straight down through the belly and between the hips to the taper.")

def T5_splitvessel(contentA, contentB):
    return (f"Below the neck, her entire visible form — shoulders, chest, belly and hips — is a sculpted vessel of thick, crystal-clear glass split down the exact centre, filled completely to the brim on both sides so nothing is hollow and there is no air gap. {GLASS_TORSO} "
            f"The left half holds one world, continuous through the chest, belly and hip: {contentA} The right half holds a second, different world, equally continuous: {contentB}")

def boundary_single():
    return "Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below, the only place where real flesh gives way to the sculpted form. Shards interlock along this line only, every edge solid all the way through."

def boundary_split():
    return ("Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs straight down the exact centre of the chest, belly and hips to the taper where the two halves meet, never horizontal. "
            "Shards interlock along both lines only, every edge solid all the way through.")

def solo_prompt(sty, ear, bodyline, bodyblock, split, glow):
    n, k, f = g3.face_of(sty)
    bnd = boundary_split() if split else boundary_single()
    return f"""{TORSO_INTRO}

Subject: A real photograph of a strikingly beautiful adult {n} woman in {k} makeup — {f}. {REAL_FACE} {ear}

Physique: {bodyline}

{bodyblock}

{bnd}

Setting: she stands on a slender dark pedestal rod rising from a low round base, barely visible in the black.

Lighting: pure pitch black background. A soft frontal light on her face and ears only, keeping her natural skin tone. {glow} Only her face, ears and neck read as real skin. 2:3 vertical 8K portrait."""

d,i = MAT["citrine"][1], MAT["citrine"][2]
S1 = solo_prompt("텔레노벨라 글램(멕시코·콜롬비아)",
  "On each ear a large gold hoop.",
  "A colossal, statuesque chest, a full rounded belly and wide flaring hips, carved on the same grand scale throughout.",
  T1_solid(d,i), False,
  "A strong warm golden backlight from directly behind floods the whole solid citrine so it glows amber-gold from within, with sharp internal light rays and a soft halo bleeding around her silhouette; a thin warm rim light traces her shoulders, waist and hips.")

CONTENT_HIME = "a sky full of drifting cherry blossoms: countless pale pink petals and a few whole blossoms turn slowly in the clear water that fills the torso, denser near the chest and thinning toward the hips, with plenty of perfectly clear space between them."
S2 = solo_prompt("히메갸루",
  "On each ear a big gold hoop with a small pearl drop.",
  "Full soft shoulders, a rounded youthful chest, a soft gently curved belly and softly flared hips.",
  T2_vessel(CONTENT_HIME), False,
  "A strong soft pink backlight from directly behind floods the whole glass vessel so the drifting petals glow like stained glass, with bright refraction edges along every curve of her chest, waist and hips; a thin rose-gold rim light traces her silhouette.")

d3desc, d3inner = MAT["amethyst"][1], MAT["amethyst"][2]
OBJ = "dozens of small, perfectly carved crystal stars and tiny five-petalled crystal flowers, each one a paler, brighter facet than the amethyst around it"
S3 = solo_prompt("발칸 글램(루마니아·불가리아)",
  "On each ear a thick gold hoop with a gold coin drop.",
  "A broad, powerful chest, a heavy rounded belly and wide statuesque hips, all on a grand, statuesque scale.",
  T3_combined(d3desc, d3inner, OBJ), False,
  "A strong violet backlight from directly behind floods the whole solid amethyst so it glows deep purple, and the embedded crystal stars and flowers catch extra points of brighter light scattered from her chest down to her hips, as though each one were its own tiny lantern inside the stone; a thin lilac rim light traces her silhouette.")

dA,iA = MAT["sapphire"][1], MAT["sapphire"][2]
dB,iB = MAT["ruby"][1], MAT["ruby"][2]
S4 = solo_prompt("걸크러시",
  "On each ear a thick black-steel hoop.",
  "A colossal, sharply sculpted chest, a taut waist and flaring hips, split evenly on both sides from chest to hip.",
  T4_split(dA,iA,dB,iB), True,
  "A strong deep-blue backlight floods the sapphire half and a strong crimson backlight floods the ruby half, each glowing from within with a hard, jewel-bright light from her shoulder down to her hip; a thin cool rim light traces the centre seam.")

CA = "a coral reef: clear turquoise water filled with branching pink coral, small bright fish and a scatter of rising bubbles, denser through the chest and thinning through the hip."
CB = "a rainforest floor: dense green ferns, hanging orchids and a single bright macaw perched among broad wet leaves, spreading from the chest down through the hip."
S5 = solo_prompt("파케앙트 글램(필리핀)",
  "On each ear a big gold hoop with a pearl.",
  "A full, rounded chest, a soft curved belly and wide statuesque hips, split evenly by two different worlds.",
  T5_splitvessel(CA,CB), True,
  "A strong turquoise backlight floods the reef half so the coral and fish glow, and a strong green-gold backlight floods the rainforest half so the leaves and macaw glow, from shoulder to hip on each side; a thin cool rim light traces the centre seam.")

ITEMS = [
 ("S1","단일 투명 재질(무내용물)","텔레노벨라 · 시트린(통짜)",S1),
 ("S2","내용물 단일(단일 세계, 재질 구분 없음)","히메갸루 · 벚꽃잎 물(단일 유리 그릇)",S2),
 ("S3","단일 투명재질 + 내용물(비분할, 결합형)","발칸 · 자수정 속에 크리스털 별·꽃",S3),
 ("S4","단일 투명재질 2개(좌우 분할, 무내용물)","걸크러시 · 사파이어 × 루비색 유리",S4),
 ("S5","내용물 투명재질 2개(좌우 분할, 무재질구분)","파케앙트 · 산호초 × 열대우림",S5),
]
for n,t,d,p in ITEMS:
    assert not re.search(r'[\uac00-\ud7a3]', p), n
    print(n, len(p.split()))
L = []
L.append("# LumineX · 토르소(허벅지까지) 솔로 5종 재발행 — 양장점 디스플레이 토르소 형식 (v1)\n")
L.append("**형식**: 흉상보다 아래로 내려서 **머리부터 허벅지 위까지**입니다. 팔과 다리는 없고, 몸통이 매끈하게 좁아지며 얇은 어두운 받침대 봉에 이어지는 **재단사의 디스플레이 토르소(마네킹)** 관례입니다. 이 지점은 절대 상처가 아니라 조각·마네킹의 매끈한 마감이라고 못박았습니다. 재질/내용물 5유형은 앞서 흉상 버전과 같습니다.\n")
L.append("**참고**: 이 형식은 가슴뿐 아니라 배·힙까지 노출되어 있어서, 앞서 말씀드린 인스타그램 등 SNS의 누드 정책과 부딪히는 정도가 흉상 버전보다 더 큽니다. 공개 게시보다는 개인 소장·프리셋 라이브러리용으로 쓰시길 권합니다.\n")
L.append("| # | 유형 | 구성 |")
L.append("|---|---|---|")
for n,t,d,p in ITEMS:
    L.append(f"| {n} | {t} | {d} |")
L.append("")
L.append("## 프롬프트\n")
for n,t,d,p in ITEMS:
    L.append(f"### {n} · {t} · {d}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_Torso_toThigh_Solo5_v1.md","w",encoding="utf-8").write("\n".join(L))
