# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g30 = load("g30","gen30.py"); g3 = g30.g3
nat, mk, fc = g3.face_of("비주얼계")
btext = g30.btext
DENS_X = g30.DENS_X

CARE_REAL = "All jewelry is real opaque metal in real skin that is healed, clean and calm — no blood, no redness, no swelling, no wound, the skin around each piece smooth and unbroken — with a small natural warm shadow under each piece. Brow bars stay on the brow bone and every stud stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes."

def build(level):
    ptxt = g30.pierce(level).replace("covering the face, neck, shoulders and arms", "covering the face, neck, shoulders and arms").replace(
        "six surface bars a hand's breadth below the collarbones", "six surface bars across the bare skin just below the collarbones above the neckline of her top").replace(
        "eight surface bars a hand's breadth below the collarbones", "eight surface bars across the bare skin just below the collarbones above the neckline of her top")
    return f"""Professional fashion photograph, bust shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head to just below her chest, the frame cutting off beneath the chest. Her face sits large and sharp in the upper half of the frame. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult Japanese woman in visual-kei makeup — {fc}. She is a real living woman: real pores and fine skin grain on her face, neck, shoulders, arms and hands, real living eyes with bright catchlights, individual hair strands catching the light — a photograph of a real person, not an illustration, not a render.

Clothing: she wears a plain black matte stretch tank top with thin straps that covers her chest, leaving her collarbones, shoulders, arms and hands bare.

Physique: {btext}

Piercings: {ptxt}{DENS_X} {CARE_REAL}

Pose: body angled 45 degrees, her left hand low at the frame edge beside her chest, her right hand held at chest height clear of her body, both hands well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal beauty light on her face, shoulders and arms, so the glints on every piece of metal read clearly, with a thin cool rim light along her hair and shoulders, shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait."""

OUT = {n: build(n) for n in (200, 250, 300)}
if __name__ == "__main__":
    for n, p in OUT.items():
        print(n, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
