# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_pierce_chest.py', encoding='utf-8').read().split("\nspecs = [")[0])     # conc_chest·p200·recolor·BODIES·BODY_KO·g18·make_structure·hz·hazy_mat·region_sents·mat_text ...
rnd.seed(20261110)
def kinds_pick(n=3): return rnd.choice(["H","V","D","C","R"]), rnd.choice(["smooth","undulating"])
def struct(n):
    kind, shape = kinds_pick(); pre, reg, lab = make_structure(kind, n, shape)
    assert sens_count(pre + " " + " ".join(reg)) == 0
    return kind, shape, pre.replace("Her figure", "Her body below the collarbones"), reg, lab
MAT_POOL = [k for k in MATKEYS if k not in BAN and k not in ("uvneon", "goldleaf")]
def pick_mats_here(n):
    while True:
        m = rnd.sample(MAT_POOL, n)
        if not ({"stone", "wood"} <= set(m)): return m
def craft_text(c):
    cn, cd, cb, cf = CRAFT_DB_FULL[c]; return f"{cn} ({cd}), wide {cb} bands following the contours of the body, with {cf} filling the space between bands", cn
def body_craft(n):
    crafts = rnd.sample(T.CRAFTS_39, n); texts = [craft_text(c)[0] for c in crafts]; names = [craft_text(c)[1] for c in crafts]
    if n == 1:
        return (f"Below the collarbones her whole body is painted in one traditional pattern: {texts[0]}, covering every inch of skin from the collarbones to the bottom of the frame without exception, the pattern reading as one continuous second skin with no gaps, nowhere on her body left bare, no fabric no seam no garment anywhere. ", f"공예 단일({names[0]})")
    kind, shape, pre, reg, lab = struct(n)
    sents = region_sents(reg, list(range(n)), texts, "is painted in")
    return (f"Below the collarbones her whole body is painted in {n} different traditional patterns, covering every inch of skin from the collarbones to the bottom of the frame without exception, the patterns reading as one continuous second skin with no gaps. {pre} {sents} {hz(shape, KINDKEY[kind])} The patterns of every region continue in full strength over her chest, shoulders and arms, nowhere on her body left bare, no fabric no seam no garment anywhere. ",
            f"공예 혼합 {n}종({'+'.join(names)}) · {STRUCT_KO[kind]}")
def body_mat(n):
    mats = pick_mats_here(n); texts = [mat_text(k)[0] for k in mats]; names = [MAT_KO[k] for k in mats]
    if n == 1:
        return (f"Below the collarbones her whole body is fused with one material instead of ordinary skin: {texts[0]}, covering every inch from the collarbones to the bottom of the frame without exception, the material reading as one continuous second skin with no gaps, nowhere on her body left bare, no fabric no seam no garment anywhere. ", f"재질 단일({names[0]})")
    kind, shape, pre, reg, lab = struct(n)
    sents = region_sents(reg, list(range(n)), texts, "carries")
    return (f"Below the collarbones her whole body is fused with {n} different materials instead of ordinary skin, covering every inch from the collarbones to the bottom of the frame without exception, the materials reading as one continuous second skin with no gaps. {pre} {sents} {hazy_mat(shape, STRUCT_KIND[kind])} The materials of every region continue in full strength over her chest, shoulders and arms, nowhere on her body left bare, no fabric no seam no garment anywhere. ",
            f"재질 혼합 {n}종({'+'.join(names)}) · {STRUCT_KO[kind]}")

def build(P, method, kind, n):
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC)+1)
    M = pick_metal(ci); G = rnd.choice(GEMS); F = rnd.choice(FORMS); bi = rnd.randrange(len(BODIES))
    hair = f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}"
    if method == "집중형": pierce = conc_chest(P, M, F)
    elif P == "P200": pierce = p200(M)
    else: pierce = recolor({"P50": g18.T50, "P100": g18.T100, "P150": g18.T150}[P], M)
    dense = P in ("P100", "P150", "P200")
    body_txt, body_label = (body_craft if kind == "craft" else body_mat)(n)
    metal_phrase = "mixed metal (yellow gold, silver, copper and rose gold, alternating piece by piece)" if M == "MX" else ("rose gold" if M == "MR" else MN[M].replace("-", " "))
    p = (f"Professional fashion photograph, bust shot. ONE woman, facing the camera straight on, her head level, both ears clearly visible on either side of her face, framed from the very top of her head to just below her chest, the frame cutting off beneath the chest. Her face sits large and sharp in the upper half of the frame, and her ear pieces are oversized so they read clearly at this distance. Mid 20s.\n\n"
         f"Subject: A real photograph of a strikingly beautiful adult {nat} woman — {fa}, {hair}. Her whole face, ears and neck are real living flesh with real pores and fine skin grain — a photograph of a real woman, not an illustration, not a render.\n\n"
         f"Piercings: {pierce}{DENS if dense else ''}{gem_text(G) if method == '집중형' else ''} {CARE.format(metal=metal_phrase)}\n\n"
         f"Physique: {BODIES[bi]}.\n\nBody: {body_txt}Real skin on the face, ears and neck ends cleanly at the base of the neck and across both collarbones, and everything below it is the body treatment described above.\n\n"
         f"Pose: arms relaxed at her sides, shoulders level, head level toward the camera.\n\n"
         f"Lighting: pure pitch black background. A soft frontal light on her face and ears, so the makeup and the glints on every piece of metal read clearly; a thin cool rim light along the hair and shoulders. 2:3 vertical 8K portrait.")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    low = p.lower()
    assert not re.search(r"[가-힣]", p) and "overhead" not in low and "it., " not in p and not re.search(r"\b(\w+) \1\b", p), (P, kind)
    if kind == "mat": assert not any(w in low for w in ("crystal", "blooms growing", "molten wax", "uv-reactive")), (P, kind)
    if M not in ("MG", "MR", "MX"): assert "gold" not in pierce.lower(), (P, M)
    desc = f"{re.sub(r'^[A-Z]+', '', HS[si-1])} · {re.sub(r'^[A-Z]+', '', HC[ci-1])} · 메이크업 {mk} · 금속 {MKO[M]} · {body_label} · 체형 {BODY_KO[bi]}"
    return p, desc, body_label
specs = [("P8","집중형","mat",3), ("P25","집중형","craft",3), ("P50","정의형","mat",3), ("P100","정의형","craft",3), ("P150","정의형","mat",1), ("P200","정의형","craft",1)]
items = [(P, m, k) + build(P, m, k, n) for P, m, k, n in specs]
order = list(range(6)); rnd.shuffle(order); no = {i: order.index(i)+1 for i in range(6)}; ranked = sorted(range(6), key=lambda i: no[i])
L = ["# LumineX · 피어싱 + 몸 처리 가슴 컷 시험 (6개, 정면)\n",
     "가슴 컷 피어싱에 바디페인팅(공예)·재질을 목선 아래부터 입혔습니다. 얼굴·귀·목은 실사 살이고, 몸 처리는 검증된 문장 구조(공예 혼합·재질 혼합·단일)만 썼습니다. 공예 3개·재질 3개이며, 피어싱이 많은 P150·P200은 프롬프트가 길어지지 않게 몸 처리를 단일로 했습니다. 금박·UV네온은 뺐습니다. P8·P25는 집중형(왼쪽 몰림, 정면에서는 화면 오른쪽), P50 이상은 정의형입니다. 메이크업·헤어컬러는 랜덤입니다. 번호는 섞여 있습니다.\n",
     "**알려주실 것**: P8·P25는 **피어싱 개수**를, P50~P200은 **성공/실패**를 적어 주세요. 피어싱이 눈에 띄지 않거나 몸 처리가 아예 안 나오면 실패입니다. 최대 3회. 예: `1: 9개 / 2: 22개 / 3: 성공 / 4: 실패`\n",
     "## 색인\n", "| 번호 | 단계 | 방식 | 구성 |", "|---|---|---|---|"]
for i in ranked: P, m, k, p, d, bl = items[i]; L.append(f"| {no[i]:02d} | {P} | {m} | {d} |")
L.append("")
for i in ranked: P, m, k, p, d, bl = items[i]; L += [f"## {no[i]:02d}. {P} 가슴 컷 · {bl}\n", "```", p, "```\n"]
open("/tmp/rep_out/LumineX_Pierce_Chest_Body_Round2.md", "w", encoding="utf-8").write("\n".join(L))
print("6개 저장")
for i in ranked: P, m, k, p, d, bl = items[i]; print(f"  {no[i]:02d} {P:<4} {m:<4} {len(p.split()):>4}단어 | {bl}")
