# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g18 = load("g18","gen18.py"); g4 = load("g4","gen4.py")
gd = load("gd","gen_demifig_pierce.py")
g3 = gd.g3; FULL_BODY = g4.BODY

REAL_FACE = ("Her whole face, ears and neck are real living flesh with real pores and fine skin grain, real living eyes with bright catchlights and genuine depth, individual hair strands catching the light — "
             "a photograph of a real face, not an illustration, not a render, not cel-shaded.")
LIGHT_TAIL = "shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait."
GLASS = "The glass is unmistakably glass: thick, crystal-clear and polished, with bright specular reflections sliding along every curved surface, sharp white highlights and dark refraction edges where the walls are thickest, tiny bubbles trapped in the glass itself."
DEPTH = ("Piercing depth: every bar and surface bar is embedded in the skin — its middle runs beneath the skin so only its two end studs show on the surface, the skin between them faintly raised over the hidden bar, with a small warm shadow at each end and nothing lying on top of the skin like a sticker. "
"Every ring passes through a small healed opening in the skin, the skin visible through the loop, and every stud sits through the skin with its back hidden. "
"Where a bar, ring or stud goes through the ear, the lip, the nostril or the brow, it passes through the real tissue with the skin wrapping snugly around it.")
def care(metal):
    return f"All jewelry is real {metal}, sitting in real, calm, healthy skin — no redness, no swelling, no irritation — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes."
T8 = g18.T8.replace("gold","rose-gold")

def setting_lines(a,b):
    return (f"Setting: a huge backdrop behind her washed with two coloured lights from behind — {a} on one side and {b} on the other, blending into a smooth gradient in the middle — glowing evenly, "
            f"marked with a few thin dark vertical lines spaced evenly across it so the bending of those lines inside her material body is unmistakable, and a glossy dark floor beneath her feet.")
def lighting(a,b):
    return f"Lighting: the glowing backdrop floods her material body from behind, so {a} passes through one side and {b} passes through the other, the vertical lines clearly visible bending inside the glass. A soft frontal light falls on her face, ears and any real leg parts. A thin cool rim light traces her whole figure."

NECK = ("A single straight, horizontal line runs across her body at underarm height, level with both armpits, passing just below her shoulders and across her back. "
        "Real skin above this line — her face, neck, both shoulders, and the very tops of both upper arms above this exact height. "
        "The glass vessel, already completely full of water right up to this same horizontal line, immediately below it — there is no empty glass anywhere, the water itself reaches exactly up to this line and no higher. "
        "Her entire chest, both breasts in full, sit below this line, whole and unbroken, made entirely of the glass vessel and the water inside it — the line passes above her chest, never through it. Shards interlock along this line only.")

def leg_material_desc(side, tier):
    return {
        "L0": f"her {side} leg entirely — thigh, knee, calf, ankle and foot — is part of the vessel above, ending in a glass sandal",
        "L1": f"her {side} thigh, only its very top near the hip, is part of the vessel above",
        "L2": f"her {side} thigh, down to just above the knee, is part of the vessel above",
        "L3": f"her {side} thigh and her entire {side} calf, all the way down to just above the ankle bone, are part of the vessel above",
        "L4": f"her entire {side} leg, foot and glass sandal are part of the vessel above, all the way to the base of each toe",
    }[tier]

def leg_transition(side, tier):
    if tier == "L0":
        return None
    if tier == "L1":
        return (f"On the {side} leg, exactly at the very top of the thigh, near the hip, the glass vessel ends in a perfectly flat, deliberately cut cross-section, exactly like a clean slice cut through a cast-glass sculpture — at that flat cut face, the full thickness of the glass wall and the clear water sealed inside it are visible edge-on, the cut always clean, deliberate and precise, never jagged or torn, always the finish of a sculpture. "
                f"Her real {side} leg is a separate thing entirely: it simply begins at that same height, flush against the cut face of the glass above it, sharing nothing with it — an ordinary, undisturbed real leg, with real skin, real pores and fine grain, warm in tone, completely opaque, never itself cut, never marked, as if it had always continued naturally from there, the entire thigh, knee, calf, ankle and foot all real.")
    if tier == "L2":
        return (f"On the {side} leg, a little above the knee, the glass vessel ends in a perfectly flat, deliberately cut cross-section, exactly like a clean slice cut through a cast-glass sculpture — at that flat cut face, the full thickness of the glass wall and the clear water sealed inside it are visible edge-on, the cut always clean, deliberate and precise, never jagged or torn, always the finish of a sculpture. "
                f"Her real {side} knee, calf and foot are a separate thing entirely: they simply begin at that same height, flush against the cut face of the glass above them, sharing nothing with it — an ordinary, undisturbed real leg, with real skin, real pores and fine grain, warm in tone, completely opaque, never itself cut, never marked, as if it had always continued naturally from there.")
    if tier == "L3":
        return (f"On the {side} leg, the glass continues, unbroken, down through the entire calf, narrowing naturally with the shape of the leg the whole way down, and ends only at the very last possible point — exactly just above the ankle bone, immediately before the bone itself would show — in a perfectly flat, deliberately cut cross-section, exactly like a clean slice cut through a cast-glass sculpture, never any higher up the leg than that exact point. "
                f"Her real {side} ankle bone and foot are a separate thing entirely: they simply begin at that same low point, flush against the cut face of the glass immediately above them, sharing nothing with it — an ordinary, undisturbed real ankle and foot, with real skin, real pores and fine grain, warm in tone, completely opaque, never itself cut, never marked, as if it had always continued naturally from there.")
    if tier == "L4":
        return (f"Her {side} foot, including its toes, is almost entirely made of the same glass vessel and clear water as the rest of that leg, standing in an extreme platform stiletto sandal carved from that same glass. "
                f"Only the last few millimetres at the very tip of each toe on the {side} foot are different — no wider than the toenail itself — where the real toenail and the tiny pad of real flesh just behind it are genuinely real, living flesh. Everything else on that foot — the rest of each toe, the whole foot, and the sandal — is entirely glass. "
                f"This tiny real tip on each toe is a separate thing entirely from the glass around it, sharing nothing with it — an ordinary, undisturbed real toe-tip, never itself cut, never marked. The glass foot and sandal end cleanly and deliberately right at the base of each of these real toe-tips.")

def leg_realpart(side, tier):
    return {
        "L0": "",
        "L1": f"her real {side} thigh, knee, calf, ankle and foot",
        "L2": f"her real {side} knee, calf, ankle and foot",
        "L3": f"her real {side} ankle and foot",
        "L4": f"only the tiny real toe-tips on her {side} foot",
    }[tier]

def shoe_note(side, tier):
    if tier in ("L0","L4"):
        return f"her {side} foot stands in a matching glass sandal, carved from the same clear material"
    else:
        return f"her real {side} foot stands in a real extreme platform stiletto sandal"

WATERS = {
 "rose": ("clear rose-pink water", "a soft rose pink", "a pale blush"),
 "sapphire": ("clear sapphire-blue water", "a deep royal blue", "a cool platinum silver"),
 "emerald": ("clear emerald-green water", "a deep forest green", "a bright turquoise"),
 "amethyst": ("clear amethyst-violet water", "a deep violet", "a cool lilac"),
 "citrine": ("clear citrine-gold water", "a warm golden amber", "a bright citrus yellow"),
 "crystal": ("perfectly clear, colourless water", "a soft platinum white", "a pale silver"),
 "ice": ("clear ice-blue water", "a cold arctic blue", "a pale icy white"),
 "coral": ("clear coral-pink water", "a warm coral pink", "a soft peach"),
}

def build(left_tier, right_tier, water_key, sty, bodykey):
    wdesc, bA, bB = WATERS[water_key]
    n,k,f = g3.face_of(sty)
    SUBJ = f"A real photograph of a strikingly beautiful adult {n} woman in {k} makeup — {f}. {REAL_FACE} On each ear a big silver hoop with a filigree silver drop."
    PIERCE = f"Piercings: {T8} {care('rose gold')}"

    left_mat = leg_material_desc("left", left_tier)
    right_mat = leg_material_desc("right", right_tier)
    left_trans = leg_transition("left", left_tier)
    right_trans = leg_transition("right", right_tier)
    left_real = leg_realpart("left", left_tier)
    right_real = leg_realpart("right", right_tier)

    orig = FULL_BODY[bodykey][1]
    parts = orig.rsplit(",", 1)
    phys = parts[0] + f", {left_mat}; {right_mat}."

    CONTENT = (f"The vessel is completely filled with {wdesc} from the underarm line down through whichever leg parts remain part of the vessel (as described below), with no hollow space and no air gap anywhere inside it (except any tiny real toe-tips noted below). "
               f"{GLASS} Both arms below the shoulder, both hands, and every finger and knuckle, are the same solid clear glass as the rest of the vessel, with no skin anywhere on them. Small bright fish and slow-drifting water plants in matching tones move freely through the whole filled volume — passing beside and between both hands and every finger, rising through her whole chest, winding around both hips, and drifting through whichever thigh and leg sections remain glass, never crowding, always with open water around each one.")

    trans_paras = []
    if left_trans: trans_paras.append(f"Left leg transition: {left_trans}")
    if right_trans: trans_paras.append(f"Right leg transition: {right_trans}")
    trans_block = "\n\n".join(trans_paras) if trans_paras else "Both legs stay entirely glass all the way to their glass sandals — no transition to real skin on either leg."

    real_paras = []
    if left_real: real_paras.append(f"Left leg (real part): {left_real}, with real skin texture, muscle and soft shadow in every crease. {shoe_note('left', left_tier)}.")
    if right_real: real_paras.append(f"Right leg (real part): {right_real}, with real skin texture, muscle and soft shadow in every crease. {shoe_note('right', right_tier)}.")
    if not real_paras:
        real_paras.append(f"Both feet: {shoe_note('left', left_tier)}; {shoe_note('right', right_tier)}.")
    real_block = "\n\n".join(real_paras)

    p = f"""Professional fashion photograph, full body dual-body portrait: left leg at tier {left_tier}, right leg at tier {right_tier}. ONE woman standing, angled 45 degrees toward the camera, the camera set back so her whole body fits in the frame from the top of her head to her feet, her face still sharp. Mid 20s.

Subject: {SUBJ}

{PIERCE}

Physique: {phys}

Material body (underarm line down through the torso and whichever leg sections remain glass): her body below the underarm line — her whole chest, both arms below the shoulder, both hands, belly, hips, and {left_mat}, and {right_mat} — is a sculpted vessel of thick, crystal-clear glass in the exact shape of that part of her body. {CONTENT}

Boundary 1 (skin to material, at underarm height, water reaching the same line): {NECK}

{trans_block}

{real_block}

{setting_lines(bA, bB)}

Pose: standing tall, body angled 45 degrees, feet planted apart, her left hand (solid glass, every finger and knuckle the same material) resting on her flared hip, her right arm held clear of her body with the hand (solid glass, every finger and knuckle the same material) relaxed at hip height, both hands well away from her face, head tilted slightly toward the camera.

{lighting(bA.split()[-1]+' light', bB.split()[-1]+' light')} {LIGHT_TAIL}"""
    return p

STYLES = ["슬라브 글램(러시아·동유럽)","강남언니","웨이쉰","프렌치 레드립(프랑스)","코갸루","소피아 로렌풍(이탈리아)","노르딕 발키리(노르웨이)","걸크러시"]
BODYKEYS = ["hgu","tent","top","ath","hgu","colo","tent","hgu"]

BATCH1 = [("L0","L1","rose",STYLES[0],BODYKEYS[0]),
          ("L0","L2","sapphire",STYLES[1],BODYKEYS[1]),
          ("L0","L3","emerald",STYLES[2],BODYKEYS[2]),
          ("L0","L4","amethyst",STYLES[3],BODYKEYS[3])]
BATCH2 = [("L1","L3","citrine",STYLES[4],BODYKEYS[4]),
          ("L2","L4","crystal",STYLES[5],BODYKEYS[5]),
          ("L3","L0","ice",STYLES[6],BODYKEYS[6]),
          ("L2","L1","coral",STYLES[7],BODYKEYS[7])]

ALL = []
for lt,rt,wk,sty,bk in BATCH1+BATCH2:
    p = build(lt,rt,wk,sty,bk)
    ALL.append((lt,rt,wk,sty,bk,p))
