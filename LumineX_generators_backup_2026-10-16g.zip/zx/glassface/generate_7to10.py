# -*- coding: utf-8 -*-
import json, re, sys, io, contextlib, importlib.util, os

sys.path.insert(0, '/home/claude/glassface')
from full_dicts import (face, CRAFT_DB_FULL, NAIL_SHAPE_EN_FULL, NAIL_FIN_EN_FULL,
 HAIR_EN_FULL, SHOE_EN_FULL, POSE_EN_FULL, AGE_EN_FULL, VIBE_EN_FULL,
 STYLE_MAP_FULL, CUSTOM_FACE_FULL, CUSTOM_LABEL_EN)
sys.path.insert(0, '/home/claude/register')
from body_full import BODY_FULL

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g3 = load("g3","gen3.py")

banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","snake","safety pin","gash"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    hits = [w for w in banned if w in p.lower() and w not in ("bite","snake")]
    assert not hits, (name,hits)
    risky = ['embroider','weav','woven','textile','stitch']
    rh = [w for w in risky if w in p.lower()]
    assert not rh, (name, "FABRIC_WORD", rh)
    lace_bad = re.findall(r'(?<!corset-)\blace\b(?!-up)', p.lower())
    assert not lace_bad, (name, "LACE")

D = json.load(open("/home/claude/diversity/register_7to10_1700.json"))

def makeup_label_of(key):
    if key in CUSTOM_FACE_FULL:
        return CUSTOM_LABEL_EN[key]
    sty = STYLE_MAP_FULL[key]
    n,k,f = g3.face_of(sty)
    return k

NUM_WORD = {7:"SEVEN",8:"EIGHT",9:"NINE",10:"TEN"}
TYPE_NAME = {7:"septet",8:"octet",9:"nonet",10:"decet"}

BODY_TAG_EN = {
"글래머아워글래스":"Glamour Hourglass","머슬아워글래스BBW":"Muscle Hourglass","헤비머슬":"Heavy Muscle","USSBBW":"USSBBW",
"아워글래스SSBBW":"Hourglass SSBBW","파워리프터":"Powerlifter","아마조네스":"Amazoness","슈퍼글래머":"Super Glamour",
"블랙글래머":"Black Glamour","레전드바스트":"Legend Bust","커브드바스트":"Curved Bust","브라질부티글램":"Brazilian Booty",
"폴리네시안여신":"Polynesian Goddess","누비안부티빌더":"Nubian Bootybuilder",
}

def person_tag(idx):
    mk_label = makeup_label_of(D["makeup"][idx])
    nnat, fa = face(D["makeup"][idx])
    bodykey = D["body"][idx]
    body_en = BODY_TAG_EN[bodykey]
    body_full_text = BODY_FULL[bodykey]
    cn, cd, cb, cf = CRAFT_DB_FULL[D["craft"][idx]]
    nail = f"{NAIL_SHAPE_EN_FULL[D['nail_s'][idx]]} nails ({NAIL_FIN_EN_FULL[D['nail_f'][idx]]})"
    hair = HAIR_EN_FULL[D["hair"][idx]]
    age = AGE_EN_FULL[D["age"][idx]]
    vibe = VIBE_EN_FULL[D["vibe"][idx]]
    pose = POSE_EN_FULL[D["pose"][idx]]
    shoe = SHOE_EN_FULL[D["shoe"][idx]]
    label = f"[{mk_label} / {body_en}]"
    tag = (f"{label}: {nnat} woman, {age}, {vibe}, {fa}, {hair} hair, {nail}. "
           f"An extraordinarily large woman, far beyond any real person. {body_full_text} "
           f"Correct proportion in hands/feet. Painted in {cn} ({cd}), covering her whole body below the jaw with no bare skin, face unpainted. "
           f"Pose: {pose}. Shoes: extreme {cb} {shoe}.")
    return tag, f"{mk_label}/{body_en}/{cn}"

def build(n, idxs):
    tags = []
    summary = []
    for idx in idxs:
        tag, s = person_tag(idx)
        tags.append(tag)
        summary.append(s)
    all_tags = "\n\n".join(tags)
    p = f"""Image format: a landscape-orientation photograph, 16:9 aspect ratio, significantly wider than it is tall, {NUM_WORD[n].lower()} women in a single row.

A photograph of {NUM_WORD[n]} women standing side by side in a single row at the same ground level on a plain seamless deep-charcoal backdrop, nothing else in the frame, each woman in her own distinct pose, generous horizontal spacing between each so every figure reads clearly and large within the frame, all real photographic skin with visible pores, no illustration finish, no CG sheen, all faces, hands and feet in correct proportion. The camera set back so all {n} fit comfortably within the wide frame from head to toe, 50mm lens at f/8, a single hard key light raking across all of them from one side, sharp focus head to toe on each — a real photograph, not an illustration, not CGI, not a render.

Left to right:
{all_tags}

Composition: each woman's own pose as described, inner arms not crossing her neighbours, every woman an extraordinarily large woman far beyond any real person, generous horizontal spacing so every figure reads clearly and large.

Lighting: the hard raking light carving every fold and curve on all {n}, catching each woman's own painted pattern distinctly. Shot on a Hasselblad X2D, 16:9 landscape 8K."""
    return p, summary

all_presets = []
idx_cursor = 0
stats = {}
for n in [7,8,9,10]:
    type_name = TYPE_NAME[n]
    lengths = []
    for slot in range(1, 51):
        idxs = list(range(idx_cursor, idx_cursor+n))
        p, summary = build(n, idxs)
        check(f"{type_name}_{slot}", p)
        key = f"la_core_{type_name}_{slot:02d}"
        all_presets.append({
            "key": key,
            "category": "🏺 Living Artifact · Core Formula",
            "title": f"Core {type_name.capitalize()} #{slot:02d}",
            "prompt": p,
            "meta": {"group_size": n, "aspect_ratio": "16:9", "format": "hybrid", "composition": summary}
        })
        lengths.append(len(p.split()))
        idx_cursor += n
    stats[type_name] = (min(lengths), max(lengths), sum(lengths)//len(lengths))

print("생성 완료:", len(all_presets), "개")
for t,(mn,mx,avg) in stats.items():
    print(f"  {t}: min={mn} max={mx} avg={avg}")

with open("/home/claude/register/la_core_7to10_bundle.json","w",encoding="utf-8") as f:
    json.dump(all_presets, f, ensure_ascii=False, indent=2)
print("번들 저장 완료")
