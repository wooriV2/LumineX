# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
_top = open('gen_craftblend_geo.py', encoding='utf-8').read().split("\nold = {")[0]
exec(_top)      # assemble, make_structure, hazy2, sens_count, validate, face_nohair, STRUCT_KO/KIND, pct(1%) ...
rnd.seed(20261010)

def down(p): return f"about {p}% of the way down her figure from the top"
def across(p): return f"about {p}% of the way across her figure from her left edge"
def hz(shape, kind):
    if kind == "dot":
        base = ("The patch edges are hazy and feathered — there is no visible outline at all. Around each patch, a transition zone about a hand's width wide lets the patch's pattern and the background pattern dissolve into each other, motifs from one thinning out as motifs from the other appear, density fading rather than stopping abruptly, never a hard edge.")
        noun = "Each patch edge follows a " + ("gently rippled outline rather than a perfect circle." if shape=="undulating" else "smooth, round outline.")
    else:
        base = ("The boundaries between regions are hazy and feathered — there is no visible line at all. Each transition zone is about a hand's width wide, and across it the neighbouring patterns dissolve into each other, motifs from one thinning out as motifs from the other appear, density fading rather than stopping abruptly, never a hard edge.")
        noun = "Each transition zone follows a " + ("gently undulating course, rippling softly rather than staying perfectly regular." if shape=="undulating" else "smooth, even course.")
    return f"{base} {noun} Even inside a transition zone the skin is never left bare: at every point one pattern, or a mixture of the two, fully covers it."

def spaced(k, lo, hi, gap):
    while True:
        v = sorted(pct(lo,hi) for _ in range(k))
        if all(v[i+1]-v[i] >= gap for i in range(k-1)): return v

# ---- 2단계 구조 5종: (pre, regions, seq(구역별 패턴 번호), 패턴 수 m, 라벨) ----
def s_mon(n, shape):
    x = pct(30,70)
    while True:
        yl, yr = pct(25,75), pct(25,75)
        if abs(yl-yr) >= 15: break
    pre = (f"Her figure is divided into {n} irregular rectangular areas by hazy transition zones running both vertically and horizontally. One vertical transition zone runs the full height of her figure {across(x)}. To her left of it, a horizontal transition zone crosses {down(yl)}; to her right of it, a different horizontal transition zone crosses {down(yr)}.")
    reg = ["the upper area to her left of the vertical zone, above the left horizontal zone","the lower area to her left of the vertical zone, below the left horizontal zone",
           "the upper area to her right of the vertical zone, above the right horizontal zone"]
    lab = f"비대칭 몬드리안 {n}구역 (세로 {x}%, 좌 가로 {yl}%, 우 가로 {yr}%"
    if n == 4:
        reg.append("the lower area to her right of the vertical zone, below the right horizontal zone"); lab += ")"
    else:
        x2 = pct(min(x+15,80), 88)
        pre += f" In the lower area to her right of the first vertical zone, a second vertical transition zone runs {across(x2)}."
        reg += ["the lower area to her right, between the first vertical zone and the second vertical zone","the lower area to her right, beyond the second vertical zone"]; lab += f", 우하 세로 {x2}%)"
    return pre, reg, list(range(n)), n, lab

def s_sg(shape):
    b1, b2 = pct(25,60), pct(40,80)
    if rnd.random() < 0.5:
        d, dko = "from the upper left edge of her figure to the lower right edge", "좌상→우하"
        e2, e3 = "upper right edge", "lower left edge"
        reg = ["the piece above the long diagonal and before the second branch (the upper left)","the piece above the long diagonal and beyond the second branch (the upper right)",
               "the piece below the long diagonal and before the third branch (the lower left)","the piece below the long diagonal and beyond the third branch (the lower right)"]
    else:
        d, dko = "from the upper right edge of her figure to the lower left edge", "우상→좌하"
        e2, e3 = "upper left edge", "lower right edge"
        reg = ["the piece above the long diagonal and before the second branch (the upper right)","the piece above the long diagonal and beyond the second branch (the upper left)",
               "the piece below the long diagonal and before the third branch (the lower right)","the piece below the long diagonal and beyond the third branch (the lower left)"]
    pre = (f"A long hazy transition zone runs diagonally {d}, as seen by the camera. A second transition zone branches off it about {b1}% of the way along its length and runs to the {e2}. A third transition zone branches off it about {b2}% of the way along its length and runs to the {e3}. Together the three zones divide her figure into 4 large irregular pieces.")
    return pre, reg, [0,1,2,3], 4, f"큰 조각 4구역·{dko}·분기 {b1}/{b2}%"

def s_dot(n, shape):
    k = n-1
    while True:
        pts = [(pct(20,80), pct(20,80)) for _ in range(k)]
        if all(((a[0]-b[0])**2+(a[1]-b[1])**2)**.5 >= 28 for i,a in enumerate(pts) for b in pts[i+1:]): break
    s = pct(18,28)
    pre = f"Her figure is covered mainly by one background pattern, with {k} large round patches of other patterns scattered irregularly across it, each patch roughly {s}% of her figure's width across."
    reg = ["the background: everything outside the round patches"] + [f"the round patch centred {down(d)} and {across(a)}" for d,a in pts]
    return pre, reg, list(range(n)), n, f"폴카도트 {n}구역 (패치 {k}개, 크기 {s}%)"

def s_stripe(orient, k, m, shape):
    seq = [i % m for i in range(k)]
    base = [round((i+1)*100/k) + rnd.randint(-3,3) for i in range(k-1)]
    if orient == "H":
        pre = f"Her figure is divided into {k} thick horizontal stripes by {k-1} hazy transition zones centred {', '.join(down(p) for p in base[:-1])} and {down(base[-1])}."
        reg = ["everything above the first transition zone"] + [f"the stripe between transition zone {i} and transition zone {i+1}" for i in range(1,k-1)] + ["everything below the last transition zone"]; ko="가로"
    elif orient == "V":
        pre = f"Her figure is divided into {k} thick vertical stripes by {k-1} hazy transition zones centred {', '.join(across(p) for p in base[:-1])} and {across(base[-1])}."
        reg = ["everything to her left of the first transition zone"] + [f"the stripe between transition zone {i} and transition zone {i+1}" for i in range(1,k-1)] + ["everything to her right of the last transition zone"]; ko="세로"
    else:
        d, dko = rnd.choice([("from the upper left to the lower right","좌상→우하"),("from the upper right to the lower left","우상→좌하")])
        pre = f"Her figure is divided into {k} thick diagonal stripes by {k-1} parallel hazy transition zones running {d} as seen by the camera, crossing the centre line of her figure {', '.join(down(p) for p in base[:-1])} and {down(base[-1])}."
        reg = ["everything on the upper side of the first diagonal transition zone"] + [f"the diagonal stripe between transition zone {i} and transition zone {i+1}" for i in range(1,k-1)] + ["everything on the lower side of the last diagonal transition zone"]; ko=f"대각({dko})"
    pre += f" The stripes alternate between {m} patterns in a repeating order."
    return pre, reg, seq, m, f"굵은 스트라이프 {ko} {k}줄·패턴 {m}종 ({'/'.join(map(str,base))}%)"

def s_chev(n, down_v, shape):
    lv = spaced(n-1, 20, 80, 18) if n>2 else [pct(30,70)]
    dirw, opp = ("down","upward") if down_v else ("up","downward")
    arm = "rounded" if shape=="undulating" else "straight"
    pre = (f"Her figure is divided into {n} chevron-shaped bands by {n-1} hazy transition zones, each shaped like a V pointing {dirw} with {arm} sides: "
           f"each zone runs from one side edge of her figure sloping {dirw}ward to the centre line, where it forms the tip of the V, then continues sloping {opp} to the opposite side edge. "
           f"The tips of the V shapes sit {', '.join(down(p) for p in lv)}.")
    reg = ["everything above the first V-shaped transition zone"] + [f"the chevron band between V-shaped zone {i} and V-shaped zone {i+1}" for i in range(1,n-1)] + [f"everything below the {'last' if n>2 else 'first'} V-shaped transition zone"]
    return pre, reg, list(range(n)), n, f"셰브론 {n}구역·V{'↓' if down_v else '↑'}·{'둥근' if shape=='undulating' else '직선'} ({'/'.join(map(str,lv))}%)"

def art_text(pre, reg, seq, m, crafts, kind, shape):
    texts=[]
    for c in crafts:
        cn,cd,cb,cf = CRAFT_DB_FULL[c]
        texts.append(f"{cn} ({cd}), wide {cb} bands following the contours of the body, dense {cf} filling the space between bands")
    sents=[]; first={}
    for i,pi in enumerate(seq):
        if pi in first: sents.append(f"Region {i+1} is {reg[i]}: it is painted in the same pattern as Region {first[pi]+1}.")
        else: first[pi]=i; sents.append(f"Region {i+1} is {reg[i]}: it is painted in {texts[pi]}.")
    return (f"Body Art: Her bare skin is painted with {m} different traditional patterns, each claiming its own region of her figure. {pre} {' '.join(sents)} {hz(shape, kind)} Pigment on living skin throughout, covering every inch of her body below the jaw with no bare skin anywhere, face unpainted.")

specs = [("MON",dict(n=4,shape="smooth")),("MON",dict(n=5,shape="smooth")),("MON",dict(n=4,shape="smooth")),
         ("SG",dict(shape="smooth")),("SG",dict(shape="smooth")),("SG",dict(shape="smooth")),
         ("DOT",dict(n=3,shape="smooth")),("DOT",dict(n=4,shape="undulating")),("DOT",dict(n=5,shape="smooth")),
         ("STR",dict(orient="H",k=4,m=2,shape="smooth")),("STR",dict(orient="V",k=5,m=3,shape="undulating")),("STR",dict(orient="D",k=4,m=3,shape="smooth")),
         ("CHV",dict(n=3,down_v=True,shape="smooth")),("CHV",dict(n=4,down_v=False,shape="undulating")),("CHV",dict(n=3,down_v=True,shape="undulating"))]
KO = {"MON":"비대칭 몬드리안","SG":"큰 조각 4개","DOT":"폴카도트","STR":"굵은 스트라이프","CHV":"셰브론"}
makeups = rnd.sample(T.MAKEUP_48, 18); bodies = (VOLBODY*3)[:18]; rnd.shuffle(bodies)
deck = list(T.CRAFTS_39); rnd.shuffle(deck)
def draw(n):
    global deck
    if len(deck) < n: deck = list(T.CRAFTS_39); rnd.shuffle(deck)
    g = deck[:n]; deck = deck[n:]; return g

items=[]; k=0
for typ, kw in specs:
    if typ=="MON": pre,reg,seq,m,lab = s_mon(kw["n"], kw["shape"]); kind="mon"
    elif typ=="SG": pre,reg,seq,m,lab = s_sg(kw["shape"]); kind="sg"
    elif typ=="DOT": pre,reg,seq,m,lab = s_dot(kw["n"], kw["shape"]); kind="dot"
    elif typ=="STR": pre,reg,seq,m,lab = s_stripe(kw["orient"],kw["k"],kw["m"],kw["shape"]); kind="str"
    else: pre,reg,seq,m,lab = s_chev(kw["n"],kw["down_v"],kw["shape"]); kind="chv"
    assert sens_count(pre+" "+" ".join(reg)) == 0, (typ, [w for w in SENS if re.search(r'\b'+w+r'\b', (pre+" ".join(reg)).lower())])
    crafts = draw(m); art = art_text(pre, reg, seq, m, crafts, kind, kw["shape"])
    p = assemble(makeups[k], bodies[k], art); validate(f"s2_{k}", p)
    items.append((KO[typ], f"{lab} · {'물결' if kw['shape']=='undulating' else '매끈'}", p, makeups[k], bodies[k], "+".join(crafts))); k+=1
# 대조군: 검증된 1단계 구조(새 방식, 3~4구역)
for kind, n, shape in [("H",3,"smooth"),("C",4,"undulating"),("R",3,"smooth")]:
    pre, reg, lab = make_structure(kind, n, shape); assert sens_count(pre+" "+" ".join(reg))==0
    crafts = draw(n); art = art_text(pre, reg, list(range(n)), n, crafts, {"H":"band","C":"conc","R":"rad"}[kind], shape)
    p = assemble(makeups[k], bodies[k], art); validate(f"s2c_{k}", p)
    items.append(("대조군(1단계)", lab, p, makeups[k], bodies[k], "+".join(crafts))); k+=1
assert len(items)==18

order=list(range(18)); rnd.shuffle(order); no={i:order.index(i)+1 for i in range(18)}; ranked=sorted(range(18), key=lambda i:no[i])
L=["# LumineX · SH 2단계 모양 바디페인팅 시험 18개 (솔로)\n",
   "2단계 모양 5종(비대칭 몬드리안·큰 조각 4개·폴카도트·굵은 스트라이프·셰브론) 3개씩 15개와, 이미 검증된 1단계 구조 대조군 3개입니다. 모양 이름은 프롬프트에 쓰지 않고 선·위치로만 적었습니다. **성공/실패만** 알려주세요(최대 3회, 1회/2회/3회/실패). 예: `03: 2회 / 07: 실패 / 나머지 1회`\n",
   "## 색인\n","| 번호 | 구분 | 구조·경계선 | 체형 | 메이크업 | 공예 구성 |","|---|---|---|---|---|---|"]
for i in ranked:
    g,lab,p,mk,bd,cr = items[i]; L.append(f"| {no[i]:02d} | {g} | {lab} | {bd} | {mk} | {cr} |")
L.append("")
for i in ranked:
    g,lab,p,mk,bd,cr = items[i]; L.append(f"## {no[i]:02d}. {g} — {lab} / {bd} / {mk}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_SH_Stage2_Test_18.md","w",encoding="utf-8").write("\n".join(L))
json.dump([{"no":no[i],"group":items[i][0],"label":items[i][1],"body":items[i][4],"makeup":items[i][3],"crafts":items[i][5]} for i in ranked], open("/home/claude/stage2_meta.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
ws=[(items[i][0], len(items[i][2].split())) for i in range(18)]
from collections import defaultdict
d=defaultdict(list)
for g,w in ws: d[g].append(w)
print("18개 저장 | 구분별 단어 수:", {g:(min(v),max(v)) for g,v in d.items()})
for i in ranked[:6]: print(f"  {no[i]:02d} {items[i][0]} | {items[i][1][:70]}")
