# -*- coding: utf-8 -*-
import re, sys, os, random, ast
os.chdir('/home/claude/glassface'); sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity'); sys.path.insert(0,'/home/claude/register')
src6 = open("gen_fix_ire_uv_6to10.py", encoding="utf-8").read()
def lit(name):
    for n in ast.parse(src6).body:
        if isinstance(n, ast.Assign) and getattr(n.targets[0], "id", "") == name: return ast.literal_eval(n.value)
IREZUMI_FULL, UV_FULL, POSES = lit("IREZUMI_FULL"), lit("UV_FULL"), lit("POSES")
ns = {"__name__": "ns"}; exec(open("gen_blend_540.py", encoding="utf-8").read().split("\nrnd = random.Random(20261004)")[0], ns)
face_nohair, T = ns["face_nohair"], ns["T"]
rnd = random.Random(20261701)
HAEJAE = ("Korean Haetae guardian fire beast bodypaint", "BLAZING CRIMSON orange fire beast guardian full torso both legs neck to ankle, VIVID GOLD mythological flame burst filling every gap, ELECTRIC RED beast detail both legs hip to toe", "Korean")
PHYS = [("plus size goddess", "most massive full-figure curves at absolute maximum, hips so wide beyond any proportion dominating entire frame, bust overwhelming gravity completely, thighs crushing together at maximum, waist snatched against impossible volume"),
        ("thick thigh temptress", "thighs so impossibly massively thick beyond all human anatomy crushing together at absolute maximum girth from hip to knee, hips wide and commanding beyond proportion, full heavy bust, waist dramatically snatched"),
        ("bubble butt goddess", "bubble butt so impossibly enormous projecting backward at maximum impossible distance defying all physics, hips so wide extending beyond frame, thighs crushing together at maximum, waist snatched to impossible minimum, full bust"),
        ("wide hip narrow waist", "hips so dramatically wide extending beyond frame, waist cinched to absolute impossible minimum, legs powerful and thick from massive hips, upper body slim"),
        ("latina curves", "most dramatic hourglass ratio ever simultaneously maximum enormous bust AND maximum enormous hips both flaring to absolute impossible extremes while waist cinched to impossible minimum, thighs so thick pressing together dominating"),
        ("pear goddess", "upper body dramatically slim making contrast with lower body utterly extreme, hips flaring to absolute maximum from impossibly slim waist, thighs massively thick dominating lower frame, bubble butt projecting dramatically backward at maximum"),
        ("super hourglass", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum beyond any proportion, most dramatic hourglass ratio ever recorded on any human body, thighs so thick pressing together"),
        ("amazon bombshell", "impossibly tall commanding frame with simultaneously the most massive full-figure curves, enormous powerful presence dominating the entire frame top to bottom, legs endlessly long massively thick and powerful")]
HAIRS = ["silver-streaked long curly waves cascading to shoulders", "silver-streaked vintage finger waves deep side part glamorous", "silver-white sleek bob jaw length", "silver-streaked sleek high ponytail taut", "silver-streaked long straight hair center part flowing", "silver-white blunt bob jaw length", "voluminous silver afro halo maximum", "silver micro braids to waist", "silver butterfly locs cascading", "silver-white natural hair swept into a high sculpted crown", "silver-white locs cascading to her waist", "long straight platinum-silver hair past her hips"]
SF_AGES = ["early 40s", "mid 40s", "late 40s", "early 50s"]
INTL = [("Latina", "warm golden-brown"), ("Brazilian", "warm deep bronze"), ("Nigerian", "rich deep brown"), ("Indian", "warm golden-brown"), ("Ethiopian", "smooth warm-brown"), ("Egyptian", "warm golden-bronze"), ("Italian", "warm olive"), ("Russian", "fair ivory cool"), ("French", "fair natural"), ("Japanese", "fair soft neutral"), ("Filipina", "warm tan"), ("Turkish", "warm olive"), ("Jamaican", "deep rich brown"), ("Samoan", "warm golden-bronze")]
BLACK = "THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky"
TONE = re.compile(r"skin|complexion|tanned|porcelain|\bfair\b|\bpale\b|\bolive\b|bronze|\btan\b|suntan|glow|dewy", re.I)
MK_KR = [m for m in T.MAKEUP_48 if face_nohair(m)[0] == "Korean"]
MK_ALL = list(T.MAKEUP_48)
def mk_line(mk):
    nat, fa = face_nohair(mk); parts = [x.strip() for x in fa.split(", ") if not TONE.search(x)]
    out = []; words = 0
    for x in parts:
        if words + len(x.split()) > 16 and out: break
        out.append(x); words += len(x.split())
    return ", ".join(out)
COLORS = ["CRIMSON", "GOLD", "VIOLET", "EMERALD", "CYAN", "MAGENTA", "GREEN", "ORANGE", "WHITE", "SILVER", "PINK", "YELLOW", "RED", "SCARLET", "BLUE", "AMBER"]
SHOES = ["platform thigh-high boots", "platform stilettos", "platform heels", "platform boots"]; NAILS = ["coffin", "stiletto", "almond"]
def two_colors(ink):
    found = []
    for w in re.findall(r"[A-Z]{3,}", ink):
        if w in COLORS and w.lower() not in found: found.append(w.lower())
    while len(found) < 2: found.append("silver")
    return found[:2]
def person(label, kind, mk_on, uv_ok, idx, section=None, black=None):
    mk = rnd.choice(MK_KR if kind == "K" else MK_ALL)
    age = rnd.choice(SF_AGES); phys, pdet = PHYS[idx % len(PHYS)] if idx is not None else rnd.choice(PHYS)
    hair = rnd.choice(HAIRS)
    if section is None:
        pool = ["ire", "ire", "uv"] if uv_ok else ["ire"]
        if kind == "K": pool = ["haetae", "ire"] + (["uv"] if uv_ok else [])
        section = rnd.choice(pool)
    if section == "ire": nm, ink = rnd.choice(IREZUMI_FULL); sec = f"{nm} irezumi"
    elif section == "uv": nm, ink = rnd.choice(UV_FULL); sec = f"UV neon {nm} irezumi"
    else: nm, ink, _ = HAEJAE; sec = nm
    if kind == "K": skin = "Korean silver fox goddess fair ivory complexion with a warm golden undertone elegant silver-era maturity"; use_black = False
    else: use_black = rnd.random() < 0.5 if black is None else black; nat, tone = rnd.choice(INTL); skin = BLACK if use_black else f"{nat} silver fox goddess {tone} complexion elegant silver-era maturity"
    mkt = f"{mk_line(mk)}, " if mk_on else ""
    head = f"{skin}, {age} silver fox goddess, {mkt}" if use_black else f"{skin}, {age}, {mkt}"
    desc = (f"{head}{phys} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pdet}, {hair} — full body {sec} covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. "
            f"Bold black ink outlines — {ink} — filling EVERY gap neck to ankle including both legs hip to ankle to toe, NO bare leg skin visible, NO airbrush NO gradient wash. Pose: {rnd.choice(POSES)}.")
    c1, c2 = two_colors(ink)
    shoe = f"{label}: {c1} {c2} {rnd.choice(SHOES)} 8 inch, extra long {rnd.choice(NAILS)} nails {c1} {c2} tips."
    return dict(text=f"{label}: {desc}\n{shoe}", desc=desc, hair=hair, shoe_line=shoe.split(": ", 1)[1], mk=mk, phys=phys, sec=sec, uv=(section == "uv"), kind=kind, age=age)
def people(n, kind, mk_on, labels):
    out = []; uv_used = False
    for i in range(n):
        P = person(labels[i], kind, mk_on, not uv_used, rnd.randrange(len(PHYS)) if n > 1 else None); uv_used |= P["uv"]; out.append(P)
    return out
def check(name, p):
    assert not re.search(r"[가-힣]", p), (name, "KOREAN")
    d = [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", p)]; assert not d, (name, d)
def wrap_solo(P):
    m = re.match(r"^(.*?) 8 inch, (extra long .*)$", P["shoe_line"]); assert m, P["shoe_line"]
    p = ("Professional fashion photograph, full body shot. ONE woman standing.\n\n" + P["desc"] + "\n"
         f"Footwear: {m.group(1)} 8 inch.\nNails: {m.group(2)}\nHair: {P['hair']}.\n\n"
         "MANDATORY pure pitch black void background only. ONE woman only. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle. Extreme high-gloss oil. 2:3 vertical 8K portrait. portrait 2:3 vertical.")
    check("solo", p); return p
def wrap_trio(Ps):
    names = ", ".join(P["phys"] for P in Ps)
    p = ("Professional fashion photograph, full body shot. THREE women standing side by side.\n" + "\n\n".join(P["text"] for P in Ps) +
         f"\n\nAll: extreme high-gloss oil. MANDATORY pure pitch black void background only. CRITICAL: all three women legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible on any leg anywhere. THREE completely different extreme physiques — {names} — must CLASH and DOMINATE every inch of frame. 8K portrait 3:4 vertical. portrait 2:3 vertical.")
    check("trio", p); return p
def wrap_decet(Ps):
    p = ("Professional fashion photograph, full body shot. TEN women standing side by side.\n\n" + "\n\n".join(P["text"] for P in Ps) +
         "\n\nEnvironment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.\nAll: extreme high-gloss oil. CRITICAL: all 10 women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere. TEN completely different extreme physiques must CONTRAST and DOMINATE every inch of frame. 8K 16:9 aspect ratio, significantly wider than it is tall.")
    check("decet", p); return p
def strip_mk(P_list_text):
    return P_list_text
def lab(Ps): return " / ".join(f"{P['mk']}·{P['phys']}·{P['sec']}" for P in Ps)
def regen_without_makeup(build_fn, seed_state, n, kind, labels, wrap):
    rnd.setstate(seed_state); return wrap(people(n, kind, False, labels))
items = []
# 1/2: 같은 솔로 (메이크업 O / X) — 같은 난수 상태에서 메이크업 유무만 다르게
st = rnd.getstate(); Ps = people(1, "I", True, ["ONE"]); items.append(("국제 실버폭스 솔로 · 메이크업 한 줄 O", lab(Ps), wrap_solo(Ps[0])))
rnd.setstate(st); Ps0 = people(1, "I", False, ["ONE"]); items.append(("같은 솔로 · 메이크업 한 줄 X (HOF 문법 그대로, 대조군)", lab(Ps0), wrap_solo(Ps0[0])))
st = rnd.getstate(); Ps = people(3, "I", True, ["LEFT", "CENTER", "RIGHT"]); items.append(("국제 실버폭스 3인 · 인물마다 메이크업 한 줄 O", lab(Ps), wrap_trio(Ps)))
rnd.setstate(st); Ps0 = people(3, "I", False, ["LEFT", "CENTER", "RIGHT"]); items.append(("같은 3인 · 메이크업 한 줄 X (대조군)", lab(Ps0), wrap_trio(Ps0)))
Ps = people(1, "K", True, ["ONE"]); items.append(("K-실버폭스 솔로 · 한국 메이크업 한 줄 · 한국 인물", lab(Ps), wrap_solo(Ps[0])))
Ps = people(10, "I", True, [f"#{i}" for i in range(1, 11)]); items.append(("국제 실버폭스 10인 · 인물마다 메이크업 한 줄 (#1~#10)", lab(Ps), wrap_decet(Ps)))
L = ["# LumineX · Silver Fox 시험 — HOF 맥시멀리스트 문법 + 메이크업 한 줄 (6개)\n",
     "**기준은 사용자님이 주신 HOF 실버폭스 프롬프트의 문법 그대로**입니다(인물 문단, 대문자 강조, `NO bare skin below neck ANYWHERE` 선언, 마무리 `CRITICAL` 문장). 이번에 바꾼 건 **메이크업 한 줄**(나이 바로 뒤, 체형 문장 앞)뿐이고, 메이크업 문장은 기존 48종에서 가져오되 **피부색 구절을 빼고** 눈·입술·눈썹 쪽만 16단어 안팎으로 줄였습니다. 은발·체형·섹션(이레즈미·UV네온(이미지당 1명)·한국 해태)·포즈·신발·손톱은 HOF·등록된 맥시멀리스트 생성기의 값 그대로입니다. 나이는 40대 초반~50대 초반입니다. 20대 대비 인물은 이번에 넣지 않았습니다.\n",
     "- **1·2번**은 같은 사람(체형·섹션·머리·포즈 동일)에 메이크업 한 줄만 있고 없고이고, **3·4번**도 같은 3인에서 같은 비교입니다.\n- **5번**은 K-실버폭스(한국 인물·한국 메이크업·한국 해태 바디페인팅 또는 이레즈미), **6번**은 10인(등록된 6~10인 마무리 문장 그대로)입니다.\n- **솔로(1·2·5번)는 등록된 솔로 형식 그대로**입니다: 위치 라벨 없음 → 인물 문단 → `Footwear:/Nails:/Hair:` 줄 → `MANDATORY ... ONE woman only ...` 마무리(2:3). 이전 파일에서 솔로에 `LEFT:`가 붙고 마무리가 제 임의 문장이던 오류를 고쳤습니다.\n",
     "**알려주실 것**: 번호마다 **성공/실패**와 **의상·맨살이 나온 인원 수**(없으면 `0명`, 생성이 안 되면 `생성 안 됨`). 최대 3회, 가장 나은 결과 기준. 예: `1: 0명 / 2: 0명 / 3: 1명 / 4: 0명 / 5: 생성 안 됨`\n",
     "## 색인 (메이크업·체형·섹션)\n", "| 번호 | 구성 | 인물별 메이크업·체형·섹션 |", "|---|---|---|"]
for k, (d, lb, p) in enumerate(items, 1): L.append(f"| {k:02d} | {d} | {lb} |")
L.append("")
for k, (d, lb, p) in enumerate(items, 1): L += [f"## {k:02d}. {d}\n", "```", p, "```\n"]
open("/mnt/user-data/outputs/LumineX_SF_HOF_1.md", "w", encoding="utf-8").write("\n".join(L))
print("6개 저장")
for k, (d, lb, p) in enumerate(items, 1): print(f"  {k:02d} {len(p.split()):>5}단어 | {d}")
