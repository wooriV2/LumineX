# -*- coding: utf-8 -*-
import re, sys
sys.path.insert(0, '.')
from full_dicts import face
banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","snake","safety pin","gash","crack","armor","armour","helmet","costume"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    hits = [w for w in banned if w in p.lower()]
    assert not hits, (name,hits)

# ---- 신규 이레즈미 문양(기존 6종 제외) ----
IREZUMI_NEW = [
 ("tiger", "BLAZING VIVID ORANGE tiger stripes wrapping the full torso both legs neck to ankle, STARK BLACK stripe detail and fierce tiger face motifs filling every gap"),
 ("hannya mask", "BLAZING CRIMSON hannya mask formations repeating across the full torso both legs neck to ankle, STARK GOLD horn and fang detail filling every gap"),
 ("fudo myo-o flames", "BLAZING ELECTRIC ORANGE flame formations wrapping the full torso both legs neck to ankle, VIVID GOLD ember detail filling every gap"),
 ("shishi lion-dog", "BLAZING DEEP GOLD shishi lion-dog mane formations across the full torso both legs neck to ankle, VIVID CRIMSON accent scales filling every gap"),
 ("great wave", "BLAZING DEEP COBALT wave crest formations sweeping the full torso both legs neck to ankle, STARK WHITE foam spray filling every gap"),
 ("bamboo forest", "BLAZING DEEP EMERALD bamboo stalks wrapping the full torso both legs neck to ankle, VIVID JADE leaf clusters filling every gap"),
 ("iris field", "BLAZING ELECTRIC VIOLET iris blossoms cascading the full torso both legs neck to ankle, VIVID EMERALD leaf blade detail filling every gap"),
 ("lotus pond", "BLAZING VIVID PINK lotus blooms across the full torso both legs neck to ankle, DEEP EMERALD lotus leaf formations filling every gap"),
 ("butterfly swarm", "BLAZING ELECTRIC INDIGO butterfly wing formations scattered across the full torso both legs neck to ankle, VIVID GOLD wing-vein detail filling every gap"),
 ("pine and crane", "BLAZING DEEP EMERALD pine branch formations across the full torso both legs neck to ankle, STARK WHITE crane pair soaring filling every gap"),
 ("water dragon", "BLAZING DEEP COBALT water dragon coiling the full torso both legs neck to ankle, VIVID SILVER scale highlights and wave-foam detail filling every gap"),
 ("phoenix solo", "BLAZING VIVID CRIMSON phoenix wing formations spreading the full torso both legs neck to ankle, ELECTRIC GOLD flame-feather detail filling every gap"),
 ("temple bell dragon", "BLAZING DEEP BRONZE temple-bell formations across the full torso both legs neck to ankle, VIVID GOLD dragon coil detail filling every gap"),
 ("firefly night", "BLAZING ELECTRIC INDIGO night-sky formations across the full torso both legs neck to ankle, VIVID GOLD firefly-light pinpoints filling every gap"),
 ("orchid", "BLAZING DEEP VIOLET orchid blossoms cascading the full torso both legs neck to ankle, VIVID EMERALD leaf detail filling every gap"),
 ("oni demon mask", "BLAZING CRIMSON oni mask formations repeating across the full torso both legs neck to ankle, STARK BLACK horn and brow detail filling every gap"),
 ("tengu feathers", "BLAZING DEEP CRIMSON feather formations sweeping the full torso both legs neck to ankle, VIVID GOLD plume-tip detail filling every gap"),
 ("raijin thunder drums", "BLAZING ELECTRIC VIOLET drum-ring formations across the full torso both legs neck to ankle, STARK GOLD lightning-crack-free spark detail filling every gap"),
 ("autumn maple storm", "BLAZING VIVID CRIMSON maple leaf formations swirling across the full torso both legs neck to ankle, VIVID GOLD leaf-vein detail filling every gap"),
 ("koi waterfall climb", "BLAZING DEEP CRIMSON koi formations ascending the full torso both legs neck to ankle, VIVID SILVER water-spray detail filling every gap"),
]
# ---- 신규 UV네온 문양(기존 7종 제외) ----
UV_NEW = [
 ("aurora curtain", "ELECTRIC GREEN aurora curtain formations rippling across the full torso both legs neck to ankle, VIVID VIOLET edge-glow detail filling every gap"),
 ("jellyfish bioluminescence", "ELECTRIC CYAN jellyfish-bell formations across the full torso both legs neck to ankle, VIVID MAGENTA tentacle-trail detail filling every gap"),
 ("DNA helix", "ELECTRIC MAGENTA double-helix formations spiraling the full torso both legs neck to ankle, VIVID CYAN rung-connector detail filling every gap"),
 ("circuit traces", "ELECTRIC GREEN circuit-trace formations branching across the full torso both legs neck to ankle, VIVID GOLD node-point detail filling every gap"),
 ("plasma vortex", "ELECTRIC VIOLET vortex formations swirling the full torso both legs neck to ankle, VIVID MAGENTA core-glow detail filling every gap"),
 ("solar flare", "ELECTRIC ORANGE flare formations erupting across the full torso both legs neck to ankle, VIVID GOLD corona-ray detail filling every gap"),
 ("meteor shower", "ELECTRIC CYAN streak formations sweeping the full torso both legs neck to ankle, VIVID WHITE trail-spark detail filling every gap"),
 ("glowing coral reef", "ELECTRIC MAGENTA coral-branch formations across the full torso both legs neck to ankle, VIVID CYAN polyp-glow detail filling every gap"),
 ("electric vein network", "ELECTRIC VIOLET vein-line formations branching across the full torso both legs neck to ankle, VIVID CYAN pulse-node detail filling every gap"),
 ("supernova burst", "ELECTRIC GOLD radial burst formations across the full torso both legs neck to ankle, VIVID MAGENTA shockwave-ring detail filling every gap"),
 ("magnetic field lines", "ELECTRIC CYAN field-line formations curving the full torso both legs neck to ankle, VIVID VIOLET pole-point detail filling every gap"),
 ("bioluminescent wave", "ELECTRIC CYAN wave-crest formations sweeping the full torso both legs neck to ankle, VIVID GREEN foam-glow detail filling every gap"),
 ("nebula birth cluster", "ELECTRIC MAGENTA gas-cloud formations swirling the full torso both legs neck to ankle, VIVID GOLD newborn-star pinpoints filling every gap"),
 ("radio pulse rings", "ELECTRIC CYAN concentric-ring formations radiating across the full torso both legs neck to ankle, VIVID VIOLET pulse-edge detail filling every gap"),
 ("ion storm", "ELECTRIC VIOLET charged-particle formations swirling the full torso both legs neck to ankle, VIVID CYAN arc-trail detail filling every gap"),
 ("geyser plasma eruption", "ELECTRIC GOLD plume formations erupting across the full torso both legs neck to ankle, VIVID ORANGE spray-ray detail filling every gap"),
 ("resonance web", "ELECTRIC MAGENTA web-strand formations crossing the full torso both legs neck to ankle, VIVID CYAN node-glow detail filling every gap"),
 ("wormhole tunnel", "ELECTRIC VIOLET tunnel-ring formations receding across the full torso both legs neck to ankle, VIVID MAGENTA event-edge detail filling every gap"),
 ("fractal energy burst", "ELECTRIC GREEN fractal-branch formations spreading the full torso both legs neck to ankle, VIVID GOLD node-point detail filling every gap"),
 ("firefly swarm", "ELECTRIC GOLD pinpoint-cluster formations scattered across the full torso both legs neck to ankle, VIVID GREEN glow-halo detail filling every gap"),
]

PHYSIQUES = [
 ("super hourglass", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum beyond any proportion, most dramatic hourglass ratio ever recorded on any human body, thighs so thick pressing together"),
 ("wide hip narrow", "hips so impossibly wide extending beyond frame creating the most extreme hip-to-waist ratio ever, waist cinched to absolute impossible minimum, upper body slim emphasizing the dramatic hip explosion"),
 ("BBW bombshell", "most massive full-figure BBW body ever at absolute maximum in every dimension, hips so wide beyond proportion dominating the entire frame, bust so enormous overwhelming gravity, waist deeply snatched despite impossible volume"),
 ("curvy petite", "smallest most compact frame possible yet curves exploding at absolute maximum in every direction, bubble butt projecting dramatically backward from the tiny frame, thighs so thick they dwarf the petite frame"),
]
HAIRS = ["long sleek jet-black hair cascading past hips","silver-white natural hair swept into a high sculpted crown","loose beach waves mid-length tousled","blunt collarbone-length bob thick heavy"]
POSES = ["strong hip pop right, both hands pressing sides of hips outward simultaneously arching back to extreme",
 "full frontal wide stance, both fists pressing outer hips outward to absolute maximum",
 "standing full height, both arms slightly spread commanding the frame",
 "back three-quarter turned, face over shoulder direct eye contact, bubble butt projected backward"]
AGES = ["early 30s","late 20s","mid 40s","late 30s"]

def irezumi_person(label, motif_idx, phy_idx):
    motif_name, motif_ink = IREZUMI_NEW[motif_idx]
    phy_name, phy_detail = PHYSIQUES[phy_idx]
    return (f"{label} (Irezumi track): THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {AGES[phy_idx]} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {HAIRS[phy_idx]} — full body {motif_name} irezumi covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Bold black ink outlines — {motif_ink}, NO airbrush NO gradient wash. Pose: {POSES[phy_idx]} — most extreme {phy_name} silhouette ever displayed. Footwear: platform boots 8 inch, extra long stiletto nails to match.")

def uvneon_person(label, motif_idx, phy_idx):
    motif_name, motif_ink = UV_NEW[motif_idx]
    phy_name, phy_detail = PHYSIQUES[phy_idx]
    return (f"{label} (UV Neon track): THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {AGES[phy_idx]} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, UV-reactive BLAZING {HAIRS[phy_idx]} — full body UV neon {motif_name} bodypaint covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Bold formations — BLAZING {motif_ink}, NO airbrush NO gradient wash. Pose: {POSES[phy_idx]} — most extreme {phy_name} silhouette ever displayed. Under her own dedicated UV blacklight spot, zero white light reaching her specifically. Footwear: platform boots 8 inch, extra long stiletto nails BLAZING NEON UV reactive tips.")

def build_quartet(ire_idx_pair, uv_idx_pair):
    b1 = irezumi_person("#1", ire_idx_pair[0], 0)
    b2 = irezumi_person("#2", ire_idx_pair[1], 1)
    b3 = uvneon_person("#3", uv_idx_pair[0], 2)
    b4 = uvneon_person("#4", uv_idx_pair[1], 3)
    body = "\n\n".join([b1,b2,b3,b4])
    return f"""Professional fashion photograph, full body shot. FOUR women standing side by side, #1 and #2 from the Irezumi track, #3 and #4 from the UV Neon track.

{body}

MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. Composition: each woman's own pose as described, inner arms not crossing her neighbours. Lighting: a single hard key light raking across #1 and #2 from one side, extreme high-gloss oil — a real photograph, not an illustration, not CGI, not a render; #3 and #4 each lit by their own dedicated UV blacklight spot so their neon formations glow at full intensity. Pattern density maximum on all four, zero bare skin from neck to ankle. Shot on a Hasselblad X2D, 4:5 aspect ratio."""

OUT = []
for i in range(10):
    ire_pair = (2*i % 20, (2*i+1) % 20)
    uv_pair = (2*i % 20, (2*i+1) % 20)
    p = build_quartet(ire_pair, uv_pair)
    check(f"q{i}", p)
    ire_names = f"{IREZUMI_NEW[ire_pair[0]][0]}+{IREZUMI_NEW[ire_pair[1]][0]}"
    uv_names = f"{UV_NEW[uv_pair[0]][0]}+{UV_NEW[uv_pair[1]][0]}"
    OUT.append((f"쿼르텟 {i+1} — 이레즈미({ire_names}) / UV네온({uv_names})", p))

for label,p in OUT:
    print(label, len(p.split()))

L = ["# LumineX · 신규 문양 검증 — 이레즈미2+UV네온2 쿼르텟 10개\n"]
for label,p in OUT:
    L.append(f"## {label}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_NewMotifs_Quartet10.md","w",encoding="utf-8").write("\n".join(L))
print("saved")
