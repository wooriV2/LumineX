# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g3 = load("g3","gen3.py"); g4 = load("g4","gen4.py")
BODY = g4.BODY

def build(sty, bk, ear, left, right, lightL, lightR):
    nat, mk, fc = g3.face_of(sty)
    bname, btext = BODY[bk]
    p = f"""Professional fashion photograph, full body shot, head to toe. ONE woman standing, angled 45 degrees toward the camera, the camera set back so her whole body fits in the frame from the top of her head to her feet, her face still sharp. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}. Her whole face, ears and neck are real living flesh with real pores and fine grain. {ear} All jewelry is real metal on real skin, healed, clean and calm.

Physique: {btext}

Vessel body: from the collarbones down, her body is not skin — it is a sculpted vessel of thick clear glass in the exact shape of her chest, belly, hips, arms, legs and hands, filled to the brim so nothing is hollow and there is no air gap. The glass walls are thick and polished, with crisp glints along every edge. {left} {right} The hands and feet are solid clear glass with tiny bubbles inside, every finger, knuckle and toe the same glass as its arm or leg.

Footwear: extreme platform stiletto sandals carved from solid clear glass, the glass running unbroken through the ankle, the instep and every toe, nothing painted on the foot.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, the glass vessel immediately below. A second jagged line runs down the centre of the body, between the hips and legs and down to the floor, where the two worlds meet, never horizontal. A few small shards of glass interlock along the lines and cast real shadows.

Pose: body angled 45 degrees, feet planted apart, her left hand (solid glass) resting on her flared hip, her right arm held clear of her body with the hand (solid glass) relaxed at hip height, well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal light on her face and ears; {lightL}; {lightR}; a thin cool rim light along the centre line. Only her face, ears and neck read as real skin. 2:3 vertical 8K portrait."""
    return p

A = build("웨이쉰","colo",
  "On each ear a big rose-gold hoop hangs clear of the neck down to the shoulder.",
  "The left half (left shoulder, the whole arm, half the chest and belly, the left hip and the whole left leg) is a night sky: the glass is filled with deep indigo, with soft nebula clouds in violet and rose, thousands of tiny stars, a few shooting meteors streaking through the arm and the leg, a pale crescent moon drifting inside the chest, and fine gold lines joining some of the stars into constellations.",
  "The right half is the deep sea: the glass is filled with dark teal water, with glowing jellyfish of different sizes drifting in the chest and the belly, small schools of luminous fish, slow kelp swaying up the leg, tiny bubbles rising and fine specks of plankton light suspended in the water.",
  "a strong violet-blue backlight from behind-left through the night-sky half so the stars and nebula glow from within",
  "a strong teal backlight from behind-right through the deep-sea half so the jellyfish and fish glow")

B = build("히메갸루","hgu",
  "On each ear a big gold hoop with a small pearl drop hangs clear of the neck down to the shoulder.",
  "The left half (left shoulder, the whole arm, half the chest and belly, the left hip and the whole left leg) is a greenhouse: the glass is filled with lush tropical plants, pink and white orchids, ferns, climbing vines with small hanging blossoms, dewdrops on the leaves, and a dozen butterflies fluttering among the flowers in the chest, the arm and the leg.",
  "The right half is a winter forest: the glass is filled with snow-covered fir trees standing in deep snow, fine snow drifting through the air, frost on the branches, and a few tiny warm lights glowing far among the trees.",
  "a soft warm pink-green backlight from behind-left through the greenhouse half so the flowers and butterflies glow",
  "a cold blue-white backlight from behind-right through the winter-forest half so the snow glows")

if __name__ == "__main__":
    for n, p in (("A", A), ("B", B)):
        print(n, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
    print(A); print("========"); print(B)
