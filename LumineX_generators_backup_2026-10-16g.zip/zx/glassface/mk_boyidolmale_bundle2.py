# -*- coding: utf-8 -*-
# 남성 바디페인팅 솔로 샘플 6개 (Core 바디페인팅 틀의 문단 구조, 남성 체형·문장)
import re, sys, random
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity"); sys.path.insert(0, "../../master")
_g = open("gen_pierce_statue.py", encoding="utf-8").read()
exec(_g[:_g.index("def build(")])
rnd.seed(20261207)
sys.path.insert(0, '../../bk')
import bg_library as _BG
import full_dicts as _F
OUTD = [b[0] for b in _BG.B if b[4]]
BODIES = {
 "V자 보디빌더": "An extraordinarily large and powerful man, far beyond any real person. A massive V-shaped torso: enormously broad shoulders with capped, rounded deltoids, a thick heavy chest, a deeply carved six-pack abdomen narrowing to a comparatively small waist, huge thick arms with split biceps and horseshoe triceps, wide flaring lats, and powerful thick quads and diamond calves. His head stays in correct proportion to his broad frame.",
 "린 애슬레틱": "A tall, lean, athletic man built like a swimmer. Broad shoulders tapering cleanly to a narrow waist, a defined chest, a visible eight-pack abdomen with sharp obliques, long strong arms with clear vein definition, and long lean muscular legs with defined calves. Nothing bulky, everything taut and sculpted.",
 "키 큰 슬렌더": "A very tall, slim, long-limbed man with a runway build. Straight shoulders, a flat lean chest, a flat defined stomach, slender strong arms and very long legs, lightly muscled and elegant, with visible collarbones and a narrow waist. His head stays in correct proportion to his long frame.",
 "파워리프터": "An extraordinarily large, thick, heavy and extremely strong man, far beyond any real person, built like a powerlifter. A huge barrel chest, enormously wide shoulders and back, a thick solid waist with a firm rounded belly over strong abs, massive arms, and enormous thick thighs and calves. Every part is large, dense and continuous rather than sharply cut.",
 "대형 헤비": "An extraordinarily large giant of a man, far beyond any real person, big-bellied with great size throughout. Broad powerful shoulders, a wide heavy chest, a large round soft belly hanging over a thick waist, thick strong arms, and wide heavy thighs beneath. Every curve is large, solid and continuous, with a warm, imposing bearing.",
 "클래식 머슬": "An extraordinarily large and powerful, classically muscular man, far beyond any real person, in the shape of a Greek statue. Wide shoulders, a full defined chest, a clean six-pack abdomen, strong rounded arms, and muscular thighs and calves, balanced and proportionate from head to toe, powerful and enormous.",
 "스트롱맨": "An extraordinarily massive, stocky strongman, far beyond any real person. A thick short neck, huge round shoulders, an enormously deep chest, a thick powerful midsection with a solid belly, tree-trunk arms, and huge thick legs planted wide. Heavy, dense and immovable, every part solid.",
 "중년 실버 아스레틱": "A fit mature man in his late 40s with an athletic, well-kept build. Broad shoulders, a firm defined chest, a flat strong abdomen with visible lines, strong forearms, and lean strong legs, with the quiet, assured bearing of a man who has trained for decades.",
}
NATS = [("Korean", "smooth fair skin with a warm undertone"), ("Korean", "luminous porcelain skin"), ("Chinese", "smooth fair skin with a neutral undertone"), ("Chinese", "light skin with a warm golden undertone"), ("Japanese", "smooth pale skin with a cool undertone"), ("Japanese", "smooth fair skin with a neutral undertone")]
FACE = ["a pretty-boy idol face with flawless smooth skin, large clear eyes, a slim jaw and soft full lips", "a youthful K-pop idol face with a small V-line jaw, bright double-lidded eyes and a straight nose", "a delicate beautiful-boy face with long lashes, a slim straight nose and a clean jawline", "a fresh-faced boy-group idol face with clear glowing skin, bright eyes and a gentle smile line", "a youthful boy-group center idol face with neat sharp brows, a slim nose and glossy full lips", "a pretty androgynous idol face with large doe eyes, a small chin and a soft jaw"]
BEARD = ["clean-shaven"]
MKU = [("dramatic black smoky eyeshadow with sharp winged eyeliner", "블랙 스모키 윙"), ("metallic gold glitter eyeshadow with defined lashes", "골드 글리터 아이"), ("graphic electric-blue eyeliner extended into bold wings", "그래픽 블루 라인"), ("deep plum smoky eyes with dark lashes", "플럼 스모키"), ("silver foil-lined eyes with a cool shimmer", "실버 포일 아이")]
MOOD = ["calm and cool", "intense and focused", "composed and elegant", "relaxed with a faint half-smile", "fierce and charismatic"]
HK = [h for h in T.HAIR_STYLE if h[:4] not in ("HSTT", "HSSB")]
AGES = ["in his early 20s", "in his early 20s", "in his mid 20s", "in his mid 20s", "in his late 20s"]
JTYPE_EN = {"JE":"earrings","JN":"necklaces","JB":"bracelets","JR":"rings","JA":"anklets","JH":"hair ornaments"}; JSING = {"JE":"earring","JN":"necklace","JB":"bracelet","JR":"ring","JA":"anklet","JH":"hair ornament"}; JMETAL_EN = {"JMG":"gold","JMS":"silver","JMR":"rose-gold","JMP":"platinum","JMX":"mixed-metal"}
JQ_SHORT = {"JQ1":"a single {m} {s}","JQ2":"two to three {m} {p}","JQ3":"four to six layered {m} {p}","JQ4":"seven to ten heavily stacked {m} {p}","JQ5":"an extreme maximalist stack of well over ten {m} {p}"}
def jewel():
    q = rnd.choice(list(JQ_SHORT)); m = JMETAL_EN[rnd.choice(list(JMETAL_EN))]; t = rnd.choice(list(JTYPE_EN)); return JQ_SHORT[q].format(m=m, s=JSING[t], p=JTYPE_EN[t])
def nails():
    return f"Long {NAIL_SHAPE_EN_FULL[rnd.choice(T.NAIL_SHAPES)]} nails, {NAIL_FIN_EN_FULL[rnd.choice(T.NAIL_FINISH)]} finish."
POSES = {"contra": "standing facing the camera with his weight on one leg, one hand resting on his hip and the other hand running through his hair",
         "stride": "walking toward the camera with a long confident stride, his arms swinging naturally at his sides",
         "over_shoulder": "standing in three-quarter back view with his hands on his hips, looking back over his shoulder at the camera",
         "profile_arm": "standing in profile with one arm raised and bent behind his head, face turned toward the camera",
         "wide": "standing in a wide power stance facing the camera, one arm extended out to the side and the other hand on his hip, chin lifted"}
NONPLAT = ["순수스틸레토펌프스", "발레힐", "니들힐", "싸이하이스틸레토부츠", "스컬프처럴힐", "앵클스트랩스틸레토"]
SHOECOL = ["gold", "black", "red", "silver", "white", "cobalt-blue", "hot-pink", "nude"]
def shoe_sentence(ko):
    en = re.sub(r'^extreme ', '', _F.SHOE_EN_FULL[ko]); col = rnd.choice(SHOECOL)
    return f"Extreme {col} {en} with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform."
BG = ["plain seamless deep-charcoal", "plain seamless mid-grey", "plain seamless deep-navy", "plain seamless warm-sand", "plain seamless dark-olive"]
def craft(c):
    cn, cd, cb, cf = CRAFT_DB_FULL[c]
    return f"{cn} ({cd}), wide {cb} bands following every deep crease and curving around the hips and thighs like contour lines, dense {cf} filling the space between every band", cn

import json, collections
import full_dicts as F

_NEWB = {
 "맨즈 피지크": "An extraordinarily tall and large man, far beyond any real person, with a men's physique build. Enormously broad shoulders with round capped deltoids, a wide upper chest tapering sharply to a very narrow waist in a dramatic V-taper, a lean sharply defined six-pack abdomen with visible obliques, thick strong arms, and long lean athletic legs that are muscular but not bulky. His head stays in correct proportion to his broad frame.",
 "머슬 모델": "An extraordinarily large and muscular man, far beyond any real person, built like a muscle model. Wide broad shoulders, a full thick defined chest, large rounded arms with clear biceps and triceps, a hard defined abdomen on a trim waist, wide flaring lats, and strong muscular thighs and calves in balance with the upper body. Powerful and imposing, yet lean and polished. His head stays in correct proportion to his broad frame.",
 "피트니스 모델": "A tall, extraordinarily well-built athletic man, far beyond any real person in size, built like a fitness model. Broad shoulders, a full athletic chest, a lean defined abdomen with a clear eight-pack, strong toned arms, a narrow waist, and long strong toned legs with defined calves. Large and powerful in frame, yet taut, lean and elegant rather than bulky. His head stays in correct proportion to his frame.",
}
MBODY_MAIN = ["V자 보디빌더", "클래식 머슬", "머슬 모델", "맨즈 피지크", "피트니스 모델"]
MBODY = MBODY_MAIN * 3 + ["파워리프터", "대형 헤비"]
BODIES.update(_NEWB)

for _k in MBODY: assert _k in BODIES, _k
BADCRAFT = {"CroatianHvar", "FinnishIittala", "UkrainianPysanka"}
CRAFTS = [c for c in T.CRAFTS_39 if c not in BADCRAFT]
PLAT = lambda k: k.startswith("플랫폼") or k.startswith("익스트림플랫폼")
POSE_ALL = [k for k in T.POSE_19 if k != "얼굴감싸기"]
POSE_GRP = ["정면와이드스탠스", "3/4각도", "뒷모습3/4", "걷는동작", "허리손", "머리넘기기"]
LAB = {2: ["LEFT", "RIGHT"], 3: ["LEFT", "CENTER", "RIGHT"]}
ART = ("{lab}Body Art: His bare skin is painted in {ct}. The paint is pigment sitting on living skin, so it distorts slightly over every muscle and bulge. The paint covers his whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of his hands, sides, back, rear, lower belly, knees, calves and the tops of his feet. His face is left unpainted and the pattern fades out at the neck with no hard line.")
def mpose(k):
    t = F.POSE_EN_FULL[k]
    return re.sub(r"\bherself\b", "himself", re.sub(r"\bher\b", "his", t))
def shoe_line(lab):
    k = rnd.choice(list(T.SHOES_24)); en = re.sub(r"^extreme ", "", F.SHOE_EN_FULL[k]); col = rnd.choice(["gold", "black", "red", "silver", "white", "cobalt-blue", "hot-pink", "nude"])
    if PLAT(k): return f"{lab}Footwear: Extreme {col} {en}, the platform soles rising far higher than his ankle bone, at least three times the thickness of an ordinary heel."
    return f"{lab}Footwear: Extreme {col} {en} with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform."
def person(lab, bkey, pose_keys):
    L = (lab + " ") if lab else ""
    nat, skin = rnd.choice(NATS); age = rnd.choice(AGES); mkt, mko = rnd.choice(MKU)
    hk = rnd.choice(HK); hc = rnd.choice(T.HAIR_COLOR)
    hair = f"{HAIR_COLOR_EN_FULL[hc]} hair styled in {HAIR_EN_FULL[hk]}"
    ck = rnd.choice(CRAFTS); ct, cn = craft(ck)
    face = rnd.choice(FACE)
    pk = rnd.choice(pose_keys)
    prefix = (lab + ": ") if lab else "Subject: "
    t = [f"{prefix}ONE real adult {nat} man {age}, his face exactly the same tone as his body, real skin texture with visible pores and fine grain, {face}, clean-shaven, {mkt}, {skin}, {rnd.choice(MOOD)}, {hair}, real living eyes, wearing {jewel()}. {nails()}",
         f"{L}Physique: {BODIES[bkey]} His arms, hands, legs and feet stay in correct proportion to each other.",
         ART.format(lab=L, ct=ct),
         f"{L}Pose: {mpose(pk)}.", shoe_line(L)]
    return "\n".join(t), dict(body=bkey, craft=cn, makeup=mko, hair=hk, haircolor=hc, pose=pk), cn
SKIN = "Real photographic skin — visible pores and fine grain, a taut surface with natural creases and shadow only where the muscle and flesh fold. No smooth illustration finish, no plastic CG sheen."
DECK = []
def build(n):
    _bid = rnd.choice(OUTD); BGD = _BG.desc(_bid); BGK = [b[2] for b in _BG.B if b[0] == _bid][0]
    BGD = re.sub(r"\bmaterial as her\b", "material as him", BGD); BGD = re.sub(r"\bher\b", "his", BGD)
    bodies = []
    while len(bodies) < n:
        if not DECK: DECK.extend(rnd.sample(MBODY, len(MBODY)))
        b = DECK.pop()
        if b not in bodies: bodies.append(b)
        else: DECK.insert(0, b)
    if n == 1:
        t, m, cn = person("", bodies[0], POSE_ALL); metas = [m]; cns = [cn]
        p = ("Image format: a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide.\n\n"
             f"A full-body photograph in {BGD}, shot on a medium format camera with an 85mm lens at f/8, in natural sunlight, sharp focus from head to toe, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n"
             + t + "\n\n" + f"Skin: {SKIN}\n\n"
             "Background & Lighting: the painted pattern catching the sunlight in sharp glints, the sunlight carving every muscle and fold.\n\n"
             "Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide. portrait 2:3 vertical.")
        asp = "2:3"
    else:
        blocks = []; metas = []; cns = []
        for lab, b in zip(LAB[n], bodies):
            t, m, cn = person(lab, b, POSE_GRP); blocks.append(t); metas.append(m); cns.append(cn)
        BGD = BGD.replace("completely empty of other people", "empty of any people other than the subjects").replace("made of the same material as him", "made of the same material as them")
        if n == 2:
            fmt = "a vertical portrait-orientation photograph, 4:5 aspect ratio, taller than it is wide"; asp = "4:5"; word = "TWO people standing side by side with generous spacing so every figure reads clearly and nobody's arms cross a neighbour"; cam = "the camera set back so both are visible from head to toe"; endl = "Vertical 4:5 portrait-orientation full-body photograph, taller than it is wide, all faces toward the camera."
        else:
            fmt = "a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide"; asp = "2:3"; word = "THREE people standing close side by side, shoulder to shoulder in a single row, with just enough spacing that every figure reads clearly and nobody's arms cross a neighbour"; cam = "the camera set back far enough that all three are visible from head to toe, the whole row filling the width of the tall frame"; endl = "Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide, all faces toward the camera."
        p = (f"Image format: {fmt}.\n\n"
             f"A full-body photograph in {BGD}, {word}, {cam}, shot on a medium format camera with an 85mm lens at f/8, in natural sunlight, sharp focus on every figure, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n"
             + "\n\n".join(blocks) + "\n\n" + f"Skin (everyone): {SKIN}\n\n"
             f"Background & Lighting: each painted pattern catching the sunlight in sharp glints, the sunlight carving every muscle and fold. {endl}")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), re.findall(r"\b(\w+) \1\b", p)
    assert not re.search(r"\b(her|she|woman|women|female)\b", p), re.findall(r".{25}\b(?:her|she|woman|women|female)\b.{10}", p)
    return p, bodies, metas, cns, BGK, asp
GN = {1: "Solo", 2: "Duo", 3: "Trio"}; GK = {1: "solo", 2: "duo", 3: "trio"}
COUNTS = {1: 50, 2: 25, 3: 25}
CAT = "🏺 Living Artifact · Boy Idol Male Body Formula"
rows = []; SEEN = set()
for gs in (1, 2, 3):
    i = 0
    while i < COUNTS[gs]:
        try: p, bodies, metas, cns, BGK, asp = build(gs)
        except AssertionError as e:
            continue
        if p in SEEN: continue
        SEEN.add(p); i += 1
        title = f"Boy Idol Male Body {GN[gs]} #{i:03d} · {' / '.join(bodies)} · " + " / ".join(cns)
        if len(title) > 103: title = f"Boy Idol Male Body {GN[gs]} #{i:03d} · {' / '.join(bodies)}"
        if len(title) > 103: title = f"Boy Idol Male Body {GN[gs]} #{i:03d}"
        rows.append({"key": f"la_boyidolmale_{GK[gs]}_{i:03d}", "category": CAT, "title": title, "prompt": p,
                     "meta": {"group_size": gs, "aspect_ratio": asp, "format": "boyidol-male-body", "background": BGK, "persons": metas}})
json.dump(rows, open("/mnt/user-data/outputs/la_boyidolmale_100_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(rows), max(len(r["title"]) for r in rows), len({r["key"] for r in rows}), len({r["title"] for r in rows}))
c = collections.Counter(m["body"] for r in rows for m in r["meta"]["persons"]); print(sorted(c.values()))
import statistics
for gs in (1, 2, 3):
    w = [len(r["prompt"].split()) for r in rows if r["meta"]["group_size"] == gs]; print(gs, int(statistics.mean(w)), max(w))
