# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g3 = load("g3","gen3.py"); g9 = load("g9","gen9.py"); g13 = load("g13","gen13.py")
DENS = g13.DENS

BASEREPS = [
 ("a big black-steel hoop, two smaller rings and a snake-bite ring on each side through the lower lip's edge, and five small hoops along the upper lip's edge",
  "a big black-steel hoop through the lower lip's edge with a snake-bite ring on each side, the upper lip and the front of the mouth kept clear"),
 ("five thick black-steel bars stacked", "six thick black-steel bars stacked"),
 ("four small studs up each temple", "five small studs up each temple"),
 ("a row of six small studs along each cheekbone", "a row of seven small studs along each cheekbone"),
 ("five small studs along each jaw", "six small studs along each jaw"),
]
def base_text():
    t = g9.P100
    for a, b in BASEREPS:
        assert a in t, a
        t = t.replace(a, b)
    return t

def prompt(sty, expr, ptext, metal_txt, gems, barbell):
    nat, mk, face = g3.face_of(sty)
    face += expr
    care = g13.CARE.format(metal=metal_txt)
    return f"""Professional fashion photograph, close-up beauty portrait. ONE woman, her face turned about 30 degrees toward the camera, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {face}. Real pores and fine skin grain, real living eyes with bright catchlights and genuine depth, individual hair strands catching the light — a photograph of a real face, not an illustration, not a render, not cel-shaded.

Piercings: {ptext}{DENS} {care}

Mouth: two small {gems} are bonded to the surface of two upper front teeth, tiny and bright, catching the light. A {barbell} passes through the middle of the tongue, the tongue tip raised playfully behind the upper teeth so both round ends of the barbell show and catch the light. The teeth are natural, white and clean, and the tongue is a healthy pink, calm and healed, with no blood and no swelling.

Lighting: a soft frontal beauty light on the face with a thin cool rim light along the hair, pure pitch black void background, shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait."""

# 히메갸루: 로즈골드 + 진주
t1 = base_text().replace("black-steel", "rose-gold").replace(
    "about one hundred real metal piercings", "about one hundred real rose-gold piercings with a few small pearl studs among them")
p1 = prompt("히메갸루", ", the lips parted in a sweet smile so the upper front teeth and the tip of the tongue show",
            t1, "rose gold with a few small pearl studs", "pale-pink crystals set in rose gold",
            "rose-gold barbell with two small pearl round ends")

# 야마바: 은 + 네온 아크릴, 광대뼈 스터드 제거(스티커 자리), 목 스터드·귀·턱선 보충
t2 = base_text()
t2 = t2.replace("a row of seven small studs along each cheekbone; ", "")
t2 = t2.replace("six small studs along each jaw", "seven small studs along each jaw; a column of four small studs down each side of the neck")
t2 = t2.replace("a full dense row of ten big hoops", "a full dense row of twelve big hoops")
t2 = t2.replace("black-steel", "silver").replace(
    "about one hundred real metal piercings", "about one hundred real silver piercings with a few neon-acrylic rings among them")
t2 = t2.replace("covering the face:", "covering the face and neck, with the cheeks kept clear for the stickers and the paint bands:")
p2 = prompt("야마바", ", the lips parted in a bold cheeky grin so the upper front teeth and the tip of the tongue show",
            t2, "silver with a few neon-acrylic rings", "clear crystals set in silver",
            "silver barbell with two small neon-pink acrylic round ends")

if __name__ == "__main__":
    for n, p in (("히메갸루", p1), ("야마바", p2)):
        print(n, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
    print(p1.split("Piercings:")[1].split("Mouth:")[0])
    print("=====")
    print(p2.split("Piercings:")[1].split("Mouth:")[0])
    print("=====")
    print(p2.split("Subject:")[1].split("Piercings:")[0])
