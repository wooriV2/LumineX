# -*- coding: utf-8 -*-
import re, sys, random, json
from collections import Counter
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_goldleaf_test.py', encoding='utf-8').read().split("\nspecs = [")[0])      # build_leaf, LEAF, make_struct, 덮어쓰기(꽃·수정·촛농·팔올림 제외), fix, check
rnd.seed(20261027)
TN={1:"solo",2:"duo",3:"trio",4:"quartet"}; TY={1:"Solo",2:"Duo",3:"Trio",4:"Quartet"}; ASPV={1:"2:3",2:"3:4",3:"4:5",4:"4:5"}
RANGE={1:(2,6),2:(2,6),3:(2,4),4:(2,3)}          # 이미지 전체 구역 수 12개 이하
P=[]
for g in [1,2,3,4]:
    for slot in range(1,31):
        key=f"la_leafmix_{TN[g]}_{slot:02d}"; n=rnd.randint(*RANGE[g]); assert g*n <= 12
        p, desc = build_leaf(g, n); p = fix(p); check(key, p, allow_uv=False, mat=True)
        assert f"Region {n}" in p and "metallic leaf" in p and "DARKEST BLACK" in p, key
        structs=[s.strip("[]").split(" / ")[0] for s in desc.split(" ; ")]
        P.append({"key":key,"category":"🏺 Living Artifact · Gold Leaf Color Mix Formula","title":f"Gold Leaf Mix {TY[g]} {n}-Color #{slot:02d} ({' / '.join(structs)})","prompt":p,
            "meta":{"group_size":g,"aspect_ratio":ASPV[g],"format":"goldleaf-color-mix","color_count":n,"layout":"geometry-hazy-v2","structures":structs}})
assert len(P)==120 and len({x["key"] for x in P})==120
json.dump(P, open("la_leafmix_geo_120_bundle.json","w",encoding="utf-8"), ensure_ascii=False, indent=2)
print("생성:", len(P), "개")
for g in [1,2,3,4]:
    ws=[len(x["prompt"].split()) for x in P if x["meta"]["group_size"]==g]; cs=Counter(x["meta"]["color_count"] for x in P if x["meta"]["group_size"]==g)
    print(f"  {TY[g]}: {min(ws)}~{max(ws)}단어 | 색 수 분포 {dict(sorted(cs.items()))}")
