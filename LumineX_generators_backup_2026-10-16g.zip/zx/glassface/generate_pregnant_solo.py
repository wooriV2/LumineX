# -*- coding: utf-8 -*-
import json, re, sys, os
sys.path.insert(0, '/home/claude/glassface')
from full_dicts import face, CRAFT_DB_FULL, NAIL_SHAPE_EN_FULL, NAIL_FIN_EN_FULL, SHOE_EN_FULL, HAIR_EN_FULL, AGE_EN_FULL, VIBE_EN_FULL
from body_full import BODY_PREGNANT, BODY_PREGNANT_MORE, BODY_PREGNANT_MUSCLE, BODY_PREGNANT_MUSCLE2

banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","snake","safety pin","gash"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    hits = [w for w in banned if w in p.lower() and w not in ("bite","snake")]
    assert not hits, (name,hits)
    risky = ['embroider','weav','woven','textile','stitch']
    rh = [w for w in risky if w in p.lower()]
    assert not rh, (name, "FABRIC_WORD", rh)
    lace_bad = re.findall(r'(?<!corset-)\blace\b(?!-up)', p.lower())
    assert not lace_bad, (name, "LACE")

ALL_PREG = {**BODY_PREGNANT, **BODY_PREGNANT_MORE, **BODY_PREGNANT_MUSCLE, **BODY_PREGNANT_MUSCLE2}
D = json.load(open("/home/claude/diversity/register_pregnant_solo_2750.json"))

GEM_EN = {"GD":"diamonds","GP":"pearls","GO":"opals","GA":"amethysts","GR":"rubies","GS":"sapphires","GX":"a mix of diamonds, pearls and sapphires"}
FORM_EN = {"FH":"hoops","FS":"studs","FB":"bars","FC":"clicker rings","FD":"drop dangles","FG":"segment rings","FX":"a mix of hoops, studs and drops"}
METAL_EN = {"MG":"gold","MR":"rose-gold","MS":"silver","MC":"copper","MBR":"brass","MBZ":"bronze","MX":"mixed metal"}
PCOUNT = {"P0":"0","P3":"3","P5":"5","P8":"8","P15":"15","P25":"25","P50":"50","P100":"100","P150":"150","P200":"200"}
JTYPE_EN = {"JE":"earrings","JN":"a necklace","JB":"a bracelet","JR":"a ring","JA":"an anklet","JH":"a hair ornament"}
JMETAL_EN = {"JMG":"gold","JMS":"silver","JMR":"rose-gold","JMP":"platinum","JMX":"mixed-metal"}
JQ_SHORT = {"JQ1":"a single piece","JQ2":"two to three pieces","JQ3":"four to six pieces, layered","JQ4":"seven to ten pieces, heavily stacked","JQ5":"well over ten pieces, an extreme maximalist stack"}
def pierce_phrase(p,c,g,f,s,m):
    if p == "P0": return "ears bare, no piercings"
    return f"{PCOUNT[p]} {FORM_EN[f]} piercings set with {GEM_EN[g]} in {METAL_EN[m]}-toned metal"

BELLY_BOOST = "larger and more dramatically rounded than an ordinary full-term pregnancy, projecting forward well beyond the line of her own chest"
POSES = [
 "standing frontal, both hands cradling the underside of her belly, chin level, calm commanding presence",
 "kneeling on both knees facing the camera directly, both hands resting lightly atop the dome of her belly, serene direct eye contact",
 "standing at a slight three-quarter angle, one hand resting on her own hip and the other beneath her belly's curve, composed radiant expression",
 "standing frontal, both arms raised overhead framing her silhouette, belly and bust both fully displayed, confident direct gaze",
 "kneeling on one knee, the other raised, one hand on the raised knee and the other cradling her belly, soft warm expression",
]

ASPECT = {1:"2:3",2:"3:4",3:"4:5",4:"4:5",5:"5:4",6:"16:9",7:"16:9",8:"16:9",9:"16:9",10:"16:9"}
NUM_WORD = {1:"ONE",2:"TWO",3:"THREE",4:"FOUR",5:"FIVE",6:"SIX",7:"SEVEN",8:"EIGHT",9:"NINE",10:"TEN"}
TYPE_NAME = {1:"solo",2:"duo",3:"trio",4:"quartet",5:"quintet",6:"sextet",7:"septet",8:"octet",9:"nonet",10:"decet"}

def person_block(idx, label, solo):
    nat, fa = face(D["makeup"][idx])
    bodykey = D["body"][idx]
    bodytext = ALL_PREG[bodykey].replace("a high, smoothly rounded pregnant belly", f"a high, smoothly rounded pregnant belly, {BELLY_BOOST},", 1)
    cn, cd, cb, cf = CRAFT_DB_FULL[D["craft"][idx]]
    nail = f"extra long {NAIL_SHAPE_EN_FULL[D['nail_s'][idx]]} nails, {NAIL_FIN_EN_FULL[D['nail_f'][idx]]} finish, {cb} tips"
    hair = HAIR_EN_FULL[D["hair"][idx]]
    age = AGE_EN_FULL[D["age"][idx]]
    vibe = VIBE_EN_FULL[D["vibe"][idx]]
    shoe = SHOE_EN_FULL[D["shoe"][idx]]
    pierce = pierce_phrase(D["pierce_p"][idx],D["pierce_c"][idx],D["pierce_g"][idx],D["pierce_f"][idx],D["pierce_s"][idx],D["pierce_m"][idx])
    jewelry = f"{JQ_SHORT[D['jq'][idx]]} of {JMETAL_EN[D['jmetal'][idx]]} {JTYPE_EN[D['jtype'][idx]]}"
    pose_desc = POSES[idx % 5]
    if solo:
        block = (f"{nat} woman, an adult, in her {age}, {vibe} expression, warm radiant skin tone, extraordinarily large pregnant physique far beyond any real person — {bodytext} "
                 f"Her face is a real living adult face, {fa}, {hair} hair, real pores, real living eyes, {pierce}, wearing {jewelry}. "
                 f"Full body painted in {cn}, {cd}, covering every inch of skin from neck to ankle without exception, the pattern reading as a continuous second skin with no gaps, wide {cb} bands following every deep crease and curving fully around her belly like contour lines circling a globe, the densest concentration of {cf} wrapping the belly's rounded surface as the pattern's natural centrepiece, the same density continuing in full strength over her bust, nowhere on her body left bare. "
                 f"Pose: {pose_desc}, her whole silhouette filling the frame from head to her extreme {cb} {shoe}, the platform soles rising far higher than her ankle bone.")
    else:
        block = (f"{label}: {nat}, in her {age}, {vibe} expression, warm radiant skin tone, extraordinarily large pregnant physique far beyond any real person — {bodytext} "
                 f"Her face is a real living adult face, {fa}, {hair} hair, real pores, real living eyes, {pierce}, wearing {jewelry}. "
                 f"Painted in {cn}, {cd}, covering every inch of skin from neck to ankle without exception, wide {cb} bands curving fully around her belly like contour lines circling a globe, the densest concentration of {cf} wrapping the belly's rounded surface as the pattern's centrepiece and continuing in full strength over her bust, nowhere left bare. "
                 f"Pose: {pose_desc}, extreme {cb} {shoe}, the platform soles rising far higher than her ankle bone.")
    return block, bodykey, cn

def build_solo(idx):
    block, bodykey, cn = person_block(idx, None, True)
    p = f"""Professional fashion photograph, full body shot. ONE woman standing or kneeling as described.

Subject: {block}

Background: a plain seamless deep-charcoal backdrop, nothing else in frame. Lighting: a single hard key light raking in from one side, sharp focus head to toe, realistic photographic grain, a real photograph not an illustration not CGI not a render. Pattern density maximum, zero bare skin from neck to ankle. 2:3 vertical 8K portrait, taller than it is wide."""
    return p, [f"{bodykey}/{cn}"]

def build_group(n, idxs):
    labels = [f"#{j+1}" for j in range(n)]
    blocks = []
    summary = []
    for j, idx in enumerate(idxs):
        block, bodykey, cn = person_block(idx, labels[j], False)
        blocks.append(block)
        summary.append(f"{bodykey}/{cn}")
    all_blocks = "\n\n".join(blocks)
    aspect = ASPECT[n]
    frame_note = ", significantly wider than it is tall" if n>=6 else ""
    p = f"""Professional fashion photograph, full body shot. {NUM_WORD[n]} women standing side by side, each an extraordinarily large pregnant woman, far beyond any real person.

{all_blocks}

Background: a plain seamless deep-charcoal backdrop, nothing else in frame. Composition: each woman's own pose as described, inner arms not crossing her neighbours, generous spacing so every figure reads clearly. Lighting: a single hard key light raking across all of them from one side, sharp focus head to toe on each, realistic photographic grain, a real photograph not an illustration not CGI not a render. Pattern density maximum, zero bare skin from neck to ankle on any of them. Shot on a Hasselblad X2D, {aspect} aspect ratio{frame_note}, 8K."""
    return p, summary

all_presets = []
idx_cursor = 0
stats = {}
for n in range(1, 11):
    type_name = TYPE_NAME[n]
    lengths = []
    for slot in range(1, 51):
        idxs = list(range(idx_cursor, idx_cursor+n))
        if n == 1:
            p, summary = build_solo(idxs[0])
        else:
            p, summary = build_group(n, idxs)
        check(f"preg_{type_name}_{slot}", p)
        key = f"la_preg_{type_name}_{slot:02d}"
        all_presets.append({
            "key": key,
            "category": "🤰 Living Artifact · Pregnant Formula",
            "title": f"Pregnant {type_name.capitalize()} #{slot:02d}",
            "prompt": p,
            "meta": {"group_size": n, "aspect_ratio": ASPECT[n], "format": "fused", "composition": summary}
        })
        lengths.append(len(p.split()))
        idx_cursor += n
    stats[type_name] = (min(lengths), max(lengths), sum(lengths)//len(lengths))

print("생성 완료:", len(all_presets), "개")
for t,(mn,mx,avg) in stats.items():
    print(f"  {t}: min={mn} max={mx} avg={avg}")

with open("/home/claude/register_preg/la_pregnant_solo_bundle.json","w",encoding="utf-8") as f:
    json.dump(all_presets, f, ensure_ascii=False, indent=2)
print("번들 저장 완료")
