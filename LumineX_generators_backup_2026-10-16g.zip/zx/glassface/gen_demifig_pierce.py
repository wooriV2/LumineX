# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g18 = load("g18","gen18.py"); g9 = load("g9","gen9.py"); g10 = load("g10","gen10.py")
g13 = load("g13","gen13.py"); g30 = load("g30","gen30.py")
g3 = g18.g3; MAT = g18.MAT
REAL_FACE = "Her whole face, ears and neck are real living flesh with real pores and fine skin grain — a photograph of a real face, not an illustration."
BIGEAR = "the biggest hoops hanging clear of the neck down to the shoulders"
DEPTH = ("Piercing depth: every bar and surface bar is embedded in the skin — its middle runs beneath the skin so only its two end studs show on the surface, the skin between them faintly raised over the hidden bar, with a small warm shadow at each end and nothing lying on top of the skin like a sticker. "
"Every ring passes through a small healed opening in the skin, the skin visible through the loop, and every stud sits through the skin with its back hidden. "
"Where a bar, ring or stud goes through the ear, the lip, the nostril or the brow, it passes through the real tissue with the skin wrapping snugly around it.")

POS = "a little below the middle of her thighs"  # 다리를 아주 조금 더 길게

INTRO = (f"Professional fashion photograph, demi-figure statue portrait. ONE woman, angled 45 degrees toward the camera, the camera framed tight and close so she nearly fills the frame edge to edge, with minimal empty space above her head or at the sides, a complete sculpted form from the top of her head down to two individually rounded, deliberately carved tips {POS} — where her sculpted form comes to an end, not where a camera frame happens to cut her off. Her face is large and sharp, and her ear pieces are oversized so they read clearly at this close distance.")

TIP = (f"{POS[0].upper()}{POS[1:]}, each thigh individually curves inward and rounds off into its own smooth, deeply polished tip — the two thighs stay clearly separate all the way down, never merging, fusing or tapering into a single base — no knees, no calves, no feet, nothing continues below either tip — the material simply reaching its natural end on each leg, exactly the way a solid gemstone carving is finished, both rounded tips resting side by side on the surface beneath her.")
TIP_VESSEL = (f"{POS[0].upper()}{POS[1:]}, each thigh individually curves inward and seals shut into its own smooth, rounded, closed tip — the two thighs stay clearly separate all the way down, never merging or fusing into a single base — no knees, no calves, no feet, nothing continues below either tip — the vessel simply comes to its natural end on each leg, both sealed rounded tips resting side by side on the surface beneath her.")

TRANS = ("Transmission: everything below the collarbones is a transparent material that light passes through, while her real face, ears and neck are opaque living flesh that no light passes through. The background and its light sources are visible straight through her body, bent, doubled and magnified by refraction and tinted by the material, with bright refraction edges, long caustic patterns on the floor and soft coloured shadows, so it is unmistakable that the body itself is the material and not paint or a drawing on skin. Her face, by contrast, is lit only from the front, with natural soft shadows and a solid skin tone, and stays completely opaque.")

def boundary(tw="tip"):
    return (f"Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. There is no line down the centre of her body. "
            f"The rounded {tw} at the end of each thigh is the material's own carved and polished finish, matching the rest of the body's surface exactly — never a jagged fracture, never a wound, never the edge of a photograph. Shards interlock along the collarbone line only.")

def setting(a,b):
    return (f"Setting: a huge backdrop behind her washed with two coloured lights from behind — {a} on one side and {b} on the other, blending into a smooth gradient in the middle — glowing evenly, with a few thin dark vertical lines across it so the bending of the background inside her body is obvious, and a glossy dark floor beneath her, both rounded thigh-tips resting directly on its polished surface and mirrored faintly in it.")

def lighting(a,b):
    return (f"Lighting: the glowing backdrop floods her body from behind, so {a} passes through one side and {b} passes through the other, tinting the material and throwing long coloured caustic patterns on the floor. A soft frontal light falls on her face and ears only; a thin cool rim light traces her whole figure down to her thigh-tips. Only her face, ears and neck read as real skin.")

def T1_solid(desc, inner):
    return (f"From the collarbones down, her whole body — shoulders, arms, hands, chest, belly, hips and both distinct thighs — is not painted, covered or clothed but physically made of one solid transparent material, "
            f"solid {desc}, with {inner}, carved as one solid sculpted mass like a statue, never hollow, with no seam and no skin anywhere, every wrist, palm, finger and knuckle the same material.")
def T2_vessel(content):
    GLASS = "The glass is unmistakably glass: thick, crystal-clear and polished, with bright specular reflections sliding along every curved surface, sharp white highlights and dark refraction edges where the walls are thickest, tiny bubbles trapped in the glass itself. Her shoulders, chest, belly, hips and both thighs keep their exact sculpted shapes as clear glass outlines, and a clean glass rim runs along the boundary where the vessel meets the neck."
    return (f"From the collarbones down, her whole body — shoulders, arms, hands, chest, belly, hips and both distinct thighs — is a sculpted vessel of thick, crystal-clear glass in the exact shape of her body, filled completely to the brim so nothing is hollow and there is no air gap. {GLASS} "
            f"The vessel holds ONE single world, unbroken and continuous through her whole chest, belly, hips and both thighs, with no split, no second world and no change of contents anywhere: {content}")
def T3_combined(desc, inner, objects):
    return (f"From the collarbones down, her whole body — shoulders, arms, hands, chest, belly, hips and both distinct thighs — is ONE solid, continuous block of {desc}, with {inner}, carved as one uniform sculpted mass, never hollow, never split down the centre. "
            f"Yet suspended deep within this solid stone, visible through it exactly like objects frozen inside a single flawless crystal, are {objects}, spread naturally from her chest down through her belly, hips and both thighs, each one fully embedded in the solid material with no cavity, no hollow chamber and no liquid around it — the stone itself grew solid around them. "
            f"The material reads as one unbroken solid mass throughout; the embedded shapes are simply what is visible deep inside it, not a separate vessel.")

def care(metal):
    return f"All jewelry is real {metal}, sitting in real skin that is healed, clean and calm — no blood, no redness, no swelling, no wound — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes."

def big_ears(txt, name):
    txt = txt.replace("on each ear a full dense row from lobe to top of big black-steel hoops, thick bars and stretched plugs",
                       f"on each ear a full dense row from lobe to top of oversized {name} hoops, thick bars and stretched plugs, " + BIGEAR)
    txt = txt.replace("on each ear a big black-steel hoop, a thick black-steel bar and a stretched black-steel plug",
                       f"on each ear a big {name} hoop, a thick {name} bar and a stretched {name} plug, " + BIGEAR)
    return txt

def prompt(tier, sty, physique, bodyblock, tip, metal_label, pierce_txt, backA, backB, glowA, glowB, tipword):
    n,k,f = g3.face_of(sty)
    return f"""{INTRO}

Subject: a strikingly beautiful adult {n} woman in {k} makeup — {f}. {REAL_FACE}

Piercings: {pierce_txt} {care(metal_label)}

{DEPTH}

Physique: {physique}

Body: {bodyblock} {tip}

{TRANS}

{boundary(tipword)}

{setting(backA,backB)}

Pose: her left hand (solid material) resting on her flared hip, her right arm held clear of her body with the hand (solid material) relaxed at hip height, both hands well away from her face, head tilted slightly toward the camera.

{lighting(glowA,glowB)} 2:3 vertical 8K portrait."""

# ---------------- 피어싱 텍스트 8단계 ----------------
T8  = g18.T8.replace("gold","rose-gold")
T25 = g18.T25.replace("rose-gold","gold")
T50 = g18.T50.replace("yellow-gold","black-steel")
def m(t, metal): return t.replace("black-steel", metal)
T100 = big_ears(g9.P100, "sapphire").replace("black-steel","sapphire")  # placeholder, real metal set later via metal var
T150 = big_ears(g10.P150, "silver").replace("black-steel","silver")
T200 = g30.pierce(200)
C1_ADD = g13.K1_CH
C2_ADD = g13.K2_CH
DENS = g13.DENS

def m2(base, metal, name_for_ear):
    t = base.replace("silver","XX").replace("sapphire","XX")
    t = t.replace("XX", metal)
    return big_ears(t, name_for_ear)

# 재사용 편의를 위해 원본에서 다시 만든다
T100b = big_ears(m(g9.P100, "gold"), "gold")
T150b = big_ears(m(g10.P150, "gold"), "gold")

SPEC = [
 ("P8","오네에갸루","T1",
  "A still-visible cinched waist beneath a full soft chest, wide curving hips, both thighs clearly separate and individually shaped.",
  ("aquamarine",), T8, "rose gold", "a soft teal", "a pale sea-green", "the teal light", "the sea-green light", "tip"),
 ("P25","아마갸루","T2",
  "A colossal chest wider than her shoulders, a waist that pulls in sharply beneath it, wide flaring hips, both thighs clearly separate and individually shaped.",
  ("rosegarden",), T25, "gold", "a warm rose pink", "a soft cream", "the rose light", "the cream light", "sealed tip"),
 ("P50","아게하","T3",
  "A colossal chest, a waist pulled in sharply, an enormous belly and colossal hips flaring again, both thighs clearly separate and individually shaped, on a grand statuesque scale.",
  ("sapphire","butterflies"), T50, "black steel", "a deep royal blue", "a cool silver", "the blue light", "the silver light", "tip"),
 ("P100","구풍","T1",
  "A colossal, statuesque chest, a broad heavy torso and wide statuesque hips, both thighs clearly separate and individually shaped, all on a grand imperial scale.",
  ("ruby",), T100b, "gold", "a deep crimson", "a warm gold", "the crimson light", "the gold light", "tip"),
 ("P150","인형 메이크업","T2",
  "Full soft shoulders, a rounded youthful chest, a soft curved belly and softly flared hips, both thighs clearly separate and individually shaped.",
  ("lilyfield",), T150b, "gold", "a pale lilac", "a soft mint", "the lilac light", "the mint light", "sealed tip"),
 ("P200","걸크러시","T3",
  "A colossal, sharply sculpted chest, a taut waist and colossal flaring hips, both thighs clearly separate and individually shaped, on a grand statuesque scale.",
  ("cobalt","shards"), T200, "black steel and silver", "a deep electric blue", "a cool white", "the blue light", "the white light", "tip"),
 ("P100+C1","강남언니","T1",
  "Her waist cinched to an impossible minimum, an enormous rounded rear and hips flaring to more than four times the width of that narrow waist, both thighs clearly separate and individually shaped.",
  ("rosequartz",), T100b + C1_ADD, "rose gold with pastel enamel and acrylic charms", "a soft blush pink", "a warm champagne", "the blush light", "the champagne light", "tip"),
 ("P150+C2","텔레노벨라 글램(멕시코·콜롬비아)","T2",
  "A colossal, statuesque chest, a full rounded belly and colossal flaring hips, both thighs clearly separate and individually shaped, on a grand statuesque scale.",
  ("fireflynight",), T150b + C2_ADD, "gold with many small charms", "a deep indigo night", "a warm firefly gold", "the indigo light", "the firefly-gold light", "sealed tip"),
]

CONTENTS = {
 "rosegarden": "a rose garden at dawn: red and white roses among dark green leaves, a few drifting petals, standing in the clear water that fills her body, denser near the chest and thinning toward the thighs.",
 "lilyfield": "pale mist drifting low over a field of white lilies: the lilies standing in clear water that fills her body, denser near the chest and thinning toward the thighs, with plenty of perfectly clear space between them.",
 "fireflynight": "a warm summer night: hundreds of small glowing fireflies and a scatter of tiny floating paper lanterns drifting in the clear water that fills her body, from her chest down through her thighs.",
}
OBJECTS = {
 "butterflies": "a dozen small, perfectly carved crystal butterflies with delicate translucent wings, each one a paler, brighter facet than the sapphire around it",
 "shards": "dozens of small, jagged clear quartz shards like frozen lightning bolts, each one a brighter, sharper facet than the cobalt glass around it",
}

OUT = []
for tier, sty, ttype, physique, matinfo, pierce_txt, metal, backA, backB, glowA, glowB, tipword in SPEC:
    dens = DENS if tier in ("P100","P150","P200","P100+C1","P150+C2") else ""
    ptxt = pierce_txt + dens
    if ttype == "T1":
        matname = matinfo[0]
        d,i = MAT[matname][1], MAT[matname][2]
        body = T1_solid(d,i); tip = TIP; tw = tipword
    elif ttype == "T2":
        content = CONTENTS[matinfo[0]]
        body = T2_vessel(content); tip = TIP_VESSEL; tw = tipword
    else:
        matname, objkey = matinfo
        d,i = MAT[matname][1], MAT[matname][2]
        body = T3_combined(d,i,OBJECTS[objkey]); tip = TIP; tw = tipword
    p = prompt(tier, sty, physique, body, tip, metal, ptxt, backA, backB, glowA, glowB, tw)
    OUT.append((tier, sty, ttype, matinfo, p))

if __name__ == "__main__":
    for tier, sty, ttype, matinfo, p in OUT:
        assert not re.search(r'[\uac00-\ud7a3]', p), tier
        print(tier, sty, ttype, matinfo, len(p.split()))
