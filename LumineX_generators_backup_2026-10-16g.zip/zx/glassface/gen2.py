# -*- coding: utf-8 -*-
import re, collections

MAT = {
 "amethyst":   ("자수정","amethyst crystal","internal facets and colour zoning, deep violet where thickest and pale lilac at every thin edge"),
 "sapphire":   ("사파이어","deep blue sapphire crystal","fine silky needle inclusions forming a soft star-like shimmer, near-midnight navy where thickest and pale cornflower at every thin edge"),
 "citrine":    ("시트린","golden-yellow citrine crystal","faint feathery inclusions and colour zoning, deep honey-gold where thickest and pale lemon at every thin edge"),
 "emerald":    ("에메랄드","deep green emerald crystal","a fine web of internal fractures and cloudy inclusions, deep forest green where thickest and pale spring green at every thin edge"),
 "aquamarine": ("아쿠아마린","clear sea-blue aquamarine crystal","long fine needle-like tubes at depth and clean facets, deep teal where thickest and pale sea-blue at every thin edge"),
 "rosequartz": ("장미석영","soft pink rose quartz","a soft milky haze and a faint star-like inner sheen, the pink deepest where thickest and nearly clear at every thin edge"),
 "carnelian":  ("카넬리안","orange-red carnelian","warm banded stripes of orange and red with a waxy luster, glowing brightest orange at every thin edge"),
 "alabaster":  ("설화석고","translucent alabaster","soft banded veining and a gentle inner glow, brightest where thinnest"),
 "jade":       ("비취","deep green jade","a waxy inner luster and fine cloudy inclusions, a soft green glow at every thin edge"),
 "moonstone":  ("월장석","milky moonstone","a milky opalescent haze with a pale blue sheen floating under the surface and shifting as the light moves"),
 "opal":       ("오팔","milky precious opal","a cloudy milky-white body with flashes of green, blue, magenta and orange deep inside, shifting with the light"),
 "amber":      ("호박","deep honey-gold amber","tiny trapped air bubbles and organic inclusions, glowing darkest gold where thickest"),
 "resin":      ("투명 레진","water-clear casting resin","perfectly clear with a hard glossy surface, tiny gold flakes and slow-rising air bubbles suspended deep inside"),
 "ice":        ("얼음","clear cast ice","internal fracture planes and a deep blue-white glow, frost gathering in every groove"),
 "glacial":    ("빙하 얼음","glacial ice","deep cyan where thickest, white streaks of compressed layers and trapped air bubbles, frost in every groove"),
 "ruby":       ("루비색 유리","deep ruby-red cast glass","slow internal swirls and a few tiny air bubbles, deepest crimson where thickest and pale rose at every thin edge"),
 "smoky":      ("스모키 블랙 유리","smoky black cast glass","smoky depth with slow swirls and faint bubbles, hard mirror highlights, darkest where thickest"),
 "rosepink":   ("로즈핑크 유리","pale rose-pink cast glass","soft internal swirls and tiny bubbles, deepest rose where thickest and nearly clear at every thin edge"),
 "cobalt":     ("코발트 블루 유리","deep cobalt-blue cast glass","slow internal swirls and tiny bubbles, near-navy where thickest and bright cobalt at every thin edge"),
 "egglass":    ("에메랄드 그린 유리","clear emerald-green cast glass","slow internal swirls and tiny bubbles, deep bottle-green where thickest and pale lime at every thin edge"),
 "murano":     ("무라노 유리","Murano glass","twisted ribbons of cobalt, red, yellow and white swirling through it with tiny gold flecks suspended between them"),
 "frosted":    ("서리 유리","milky frosted glass","light scattering softly through the whole thickness, a satin surface with no sharp reflection, glowing evenly from within"),
 "seaglass":   ("바다 유리","weathered sea glass","pale aqua-green frosted glass, softly pitted and tumbled with every edge rounded, a soft glow from within"),
}

BODY = {
 "bust":   ("바스트 퀸 BBW","A colossal chest far wider than her shoulders, each rounded half reaching past the outer line of her arms, broad soft shoulders, thick heavy arms."),
 "top":    ("톱헤비 아워글래스","A colossal chest far wider than her shoulders, curving forward as one enormous rounded mass, soft heavy shoulders, thick soft arms."),
 "hgu":    ("아워글래스 USSBBW","A colossal heavy chest wider than her shoulders, broad soft shoulders, thick heavy arms, her upper body filling the frame."),
 "hgs":    ("아워글래스 SSBBW","A colossal heavy chest, soft round shoulders, very thick soft arms, her upper body filling the frame."),
 "tent":   ("텐트폴 USSBBW","A giant frame flaring at the shoulders — lats spreading to shoulders more than four times a normal woman's width, massive rounded deltoids, a colossal chest projecting past the line of the shoulders, thick heavy arms."),
 "colo":   ("콜로설","A giantess on an even scale — massive rounded shoulders spanning more than four head-widths, huge thick arms, a colossal full chest, no single part standing out."),
}

# (번호, 카테고리, 스타일명, 국적, 얼굴서술, 피어싱)
S = []
def add(cat, name, nat, face, pierce): S.append((cat, name, nat, face, pierce))

# ---- 일본 갸루
add("일본 갸루","코갸루","Japanese ko-gyaru",
 "deeply sun-tanned bronze makeup over real skin, bold white eyeshadow across the lids, white glossy lips, a bright turquoise liner accent at the outer corners, long lashes, large eyes with bright real catchlights, long bleached blonde hair with sun-streaked highlights, a bright cheeky grin",
 "A thick silver septum ring hangs below the nose; on each ear a big silver hoop and one turquoise-enamel ring.")
add("일본 갸루","히메갸루","Japanese hime-gyaru",
 "fair porcelain skin, soft pink blush across the cheeks, sparkling pink eyeshadow, long curled lashes, large eyes with bright real catchlights, glossy candy-pink lips, huge voluminous light-brown curls with a big pink satin bow, a sweet princess-like smile",
 "On each ear a big gold hoop with a small pearl drop.")
add("일본 갸루","아게하","Japanese age-gyaru",
 "luminous glossy skin with a bright highlighter, thick black eyeliner, extremely long dramatic false lashes top and bottom, large eyes with bright real catchlights, glossy peach-pink lips, towering teased bleached-blonde hair, a confident sparkling expression",
 "On each ear a large gold chandelier-shaped hoop; a small gold stud in the left nostril.")
add("일본 갸루","오네에갸루","Japanese onee-gyaru",
 "smooth healthy skin, defined brown-mauve eyeshadow, a precise winged liner, full natural lashes, large eyes with bright real catchlights, softly contoured cheeks, glossy rose-nude lips, long sleek chestnut waves, a poised, mature, confident expression",
 "A thick gold hoop on each ear with one small pearl stud above it.")
add("일본 갸루","로리타 갸루","Japanese lolita-gyaru",
 "pale rosy skin, large round doll-like eyes enlarged by circle lenses with bright real catchlights, thick curled lashes with drawn-on lower lashes, soft pink and lilac eyeshadow, round pink blush, glossy cherry-pink lips, long honey-brown ringlets with a white lace headdress and satin bow on top, a sweet, playful smile",
 "A thick silver septum ring; on each ear a big silver hoop and one stretched gold-rimmed ear plug.")
add("일본 갸루","아마갸루","Japanese ama-gyaru",
 "fair skin, pastel pink and lilac eyeshadow, large round eyes enlarged by circle lenses with bright real catchlights, soft round blush, dewy pink lips, long light-brown hair in twin tails tied with pastel ribbons, a sweet, shy smile",
 "A big pastel-enamel hoop on each ear (pink on the left, lilac on the right) and a small silver heart stud in each upper ear.")
# ---- 일본 극단
add("일본 극단·서브컬처","야마바","Japanese yamanba-gyaru",
 "a deep bronze tan foundation over real skin, wide stark-white paint bands above and below both eyes lying on the lids and never across the eyeballs, neon pink and turquoise eyeshadow, long false lashes, large eyes with bright real catchlights, glossy white lips, small star and heart rhinestone stickers on the cheeks only, long teased neon pink and lime hair, a bold cheeky grin",
 "A big neon-acrylic hoop and a small silver star stud on each ear.")
add("일본 극단·서브컬처","만바","Japanese manba-gyaru",
 "a deep bronze tan foundation over real skin, thick white paint bands above and below both eyes lying on the lids and never across the eyeballs, silver glitter lines across the lids, heavy black liner, very long false lashes, large eyes with bright real catchlights, glossy white lips, small rhinestone stickers on the cheeks only, long bleached platinum hair with a neon streak, a fierce, playful expression",
 "A big silver hoop and a white-enamel ring on each ear.")
add("일본 극단·서브컬처","반바","Japanese banba-gyaru",
 "a deep bronze tan foundation over real skin, thick white paint bands above and below both eyes lying on the lids and never across the eyeballs, neon pink and lime paint strokes across the cheekbones, rhinestone and star stickers clustered on the cheeks and forehead only, long false lashes, large eyes with bright real catchlights, glossy white lips, long teased neon-pink and lime hair, a fierce, playful expression",
 "Two big multicolour acrylic hoops on each ear.")
add("일본 극단·서브컬처","비주얼계","Japanese visual-kei",
 "pale porcelain skin, deep smoky black eyeshadow blended far out beyond the eyes, a sharp black winged liner, long dramatic lashes, large eyes with bright real catchlights, glossy black lips, sharply contoured cheekbones, long teased jet-black hair with silver streaks, a cold, poised expression",
 "A thick black-steel bar through the outer end of the left eyebrow, clear of the eye; on each ear a big black-steel hoop.")
add("일본 극단·서브컬처","지뢰계","Japanese jirai-kei",
 "pale porcelain skin, pink-red eyeshadow smudged softly beneath both eyes, a delicate tear-track blush across the cheeks, large dark circle lenses with bright real catchlights, long lashes, glossy pink-red lips, long black hair in twin tails tied with pink and black ribbons under a blunt fringe, a hollow, dreamy expression",
 "A small silver ring at the corner of the lower lip; on each ear a big pink-and-black enamel heart hoop.")
add("일본 극단·서브컬처","야미카와","Japanese yamikawa",
 "pale, almost translucent skin, heavy pink-red eyeshadow smudged wide beneath both eyes like crying, faint tear-track blush running down the cheeks, large dark circle lenses with bright real catchlights, long lashes, glossy dark-cherry lips, long black hair in twin tails with pink and black ribbons under a blunt fringe, a hollow, half-lidded expression",
 "A thick black-steel ring through the left nostril; on each ear a thick black hoop with a fine silver chain drop.")
add("일본 극단·서브컬처","데코라","Japanese decora",
 "fair skin, bright pastel pink and yellow eyeshadow, thick lashes, large eyes with bright real catchlights, small star and heart stickers on the cheeks only, glossy candy-pink lips, long pastel rainbow hair in twin tails crowded with colourful plastic clips, ribbons and tiny toys kept on the hair, a bright, giddy grin",
 "On each ear a large primary-colour acrylic ring; a small star-shaped acrylic stud in the left nostril.")
# ---- 한국
add("한국","글래머러스 파티","Korean",
 "fair ivory skin, smoky eyes in champagne-gold glitter shadow, a sharp winged liner, full lashes, softly contoured cheekbones with a glowing highlight, large eyes with bright real catchlights, plump glossy gradient lips in deep rose, long sleek black waves, a confident, luminous expression",
 "On each ear a big gold hoop with a champagne-gold ball; a small gold stud in the right nostril.")
add("한국","걸크러시","Korean",
 "fair ivory skin, sharply angled thin brows, a razor-sharp winged cat-eye liner extending far past the outer corner, deep brown-black eyeshadow, long lashes, large eyes with bright real catchlights, strongly sculpted contour, a deep wine-red matte lip, long sleek black hair, a cold, commanding gaze",
 "A thick silver septum ring; on each ear a big silver hoop and a thick silver bar.")
add("한국","뱀파이어 다크","Korean",
 "pale porcelain skin, deep burgundy-black shadow smudged heavily beneath both eyes, sharp black liner, long dramatic lashes, large eyes with bright real catchlights, a glossy near-black wine lip, sharply contoured cheekbones, long straight jet-black hair, a cold, poised expression",
 "A small black-steel ring at the left corner of the lower lip; on each ear a thick black-steel bar and a pointed silver spike stud.")
add("한국","강남언니","Korean",
 "glowing dewy skin, a precise winged liner, softly defined brown eyeshadow, full natural lashes, large eyes with bright real catchlights, sculpted contour with a satin highlight, plump glossy rose-coral lips, long sleek chestnut waves, a poised, refined, confident expression",
 "A big gold hoop on each ear with one small pearl stud above it.")
add("한국","인형 메이크업","Korean",
 "flawless porcelain skin, very large round eyes enlarged by pale circle lenses with bright real catchlights, soft brown eyeshadow with a shimmer under the eyes, long curled lashes, round pink blush on the apples of the cheeks, small gradient rose-pink lips, long straight light-brown hair with a see-through fringe, a calm, doll-like expression",
 "A large pearl ball earring and a small ribbon-shaped silver stud on each ear.")
add("한국","한복 화보(연지곤지)","Korean",
 "fair porcelain skin, two round red yeonji blush circles painted on the cheeks and a small round red gonji dot at the centre of the forehead, clearly defined dark brows, softly lined eyes with bright real catchlights, small vivid red lips, glossy black hair braided and pinned into a low chignon with a red ribbon, a serene, dignified expression",
 "A gold knot-shaped drop earring with a red-enamel bead on each ear.")
# ---- 중국
add("중국","구풍","Chinese",
 "porcelain-pale skin, slender upswept willow-leaf brows, a fine red floral huadian mark painted on the forehead, softly flushed rosy cheeks, an upswept eyeliner tail, large eyes with bright real catchlights, a small vivid red lip, black hair in a high coiled updo with gold hairpins, a serene expression",
 "A big gold hoop on each ear with a small gold square knot and a red-enamel bead.")
add("중국","웨이쉰","Chinese",
 "clear fair skin, a warm rose-red wash blended across the outer corners of both eyes and drifting up toward the temples, the same flush spreading softly across the cheekbones and the bridge of the nose, slightly smudged, dewy highlights, soft brown-pink eyeshadow, large moist eyes with bright real catchlights and a faint glassy shine, moist rose-tinted lips, long black hair loosely tousled with a few strands across the face, a dreamy, half-lidded expression",
 "A big rose-gold hoop on each ear; a small rose-gold stud in the left nostril.")
add("중국","홍콩풍","Chinese",
 "fair matte skin with a soft powdery finish, thin sharply arched brows, soft brown and rose eyeshadow, a fine black liner with a small flick, long curled lashes, large eyes with bright real catchlights, a strong rose-red blush on the apples of the cheeks, deep glossy red lips with a defined edge, hair set in glossy voluminous old-film waves, a poised, glamorous expression",
 "A large vintage pearl clip-style earring on each ear.")
# ---- 국제
add("국제","락혼 글램(태국)","Thai",
 "flawless pale-golden skin, sharply defined dark brows, a precise black winged liner with a strong flick, warm brown-bronze eyeshadow, long dramatic lashes, large eyes with bright real catchlights, strong contour under the cheekbones, deep red glossy lips with a crisp edge, long glossy black waves, a poised, dramatic expression",
 "A thin gold ring through the left nostril; on each ear a big gold hoop with a chased-gold drop.")
add("국제","파케앙트 글램(필리핀)","Filipina",
 "warm tan skin, heavy sculpted contour and a glowing highlighter on the cheekbones, smoky bronze and gold glitter eyeshadow, dramatic long lashes, defined dark brows, large eyes with bright real catchlights, glossy coral-red lips, long voluminous chestnut waves, a bright, confident pageant smile",
 "A big gold hoop with a pearl on each ear; a small gold stud in the left nostril.")
add("국제","텔레노벨라 글램(멕시코·콜롬비아)","Latina",
 "warm golden-bronze skin, a sharp black winged liner, warm terracotta eyeshadow, heavy lashes, strong sculpted contour, large dark eyes with bright real catchlights, a deep berry lip, long voluminous dark-brown waves swept over one shoulder, a fiery, passionate expression",
 "A large gold hoop on each ear and a thin gold ring through the left nostril.")
add("국제","프렌치 레드립(프랑스)","French",
 "fair natural skin with a light dewy finish, softly brushed natural brows, a barely-there brown liner and fluttering lashes, no eyeshadow, soft natural colour on the cheeks, large eyes with bright real catchlights, a single bold classic red lip with a soft matte finish, long dark-brown hair in an effortless tousled updo, an unbothered, effortless expression",
 "A single thick gold hoop on each ear, nothing else.")
add("국제","슬라브 글램(러시아·동유럽)","Russian",
 "very fair, cool skin, sculpted feathered dark brows, a precise winged liner, soft taupe eyeshadow, long lashes, large pale eyes with bright real catchlights, strong contour and a bright highlighter along the cheekbones and nose bridge, glossy nude-pink lips, long straight platinum-blonde hair, a cold, striking expression",
 "A big silver hoop with a filigree silver drop on each ear.")
add("국제","인스타 글램(미국·영국)","American",
 "sun-kissed skin, heavily sculpted contour and a strong highlighter on the cheekbones, bold defined brows, long fluffy false lashes, shimmery bronze eyeshadow, large eyes with bright real catchlights, plump glossy nude lips with a defined lip-liner outline, long voluminous honey-blonde waves, a confident, camera-ready smile",
 "Two big gold hoops stacked on each ear.")
add("국제","서아프리카 파티·웨딩 글램","Nigerian",
 "rich deep brown skin with a golden highlighter glowing on the cheekbones, bold shimmering gold and emerald eyeshadow blended out toward the temples, dramatic long lashes, sharply defined brows, large eyes with bright real catchlights, a strong glossy fuchsia-pink lip, long braids piled into a high sculpted crown, a bright, joyful smile",
 "A big gold hoop with gold beads on each ear; a thin gold ring through the left nostril.")
add("국제","하베샤 화장(에티오피아·에리트레아)","Ethiopian",
 "smooth warm-brown skin, a bold thick black liner drawn around the whole eye and winged slightly at the outer corner, warm gold and brown eyeshadow, strongly defined softly arched brows, long lashes, large dark eyes with bright real catchlights, a natural warm rose-brown lip with a soft gloss, long black hair in fine neat braids swept back from the face, a serene, dignified expression",
 "A big silver filigree hoop on each ear.")
add("국제","요루바 신부 화장(나이지리아)","Yoruba Nigerian",
 "rich deep brown skin with a golden highlighter on the cheekbones, warm gold and bronze eyeshadow blended up to the brow bone, sharply defined arched brows, a precise winged liner, long dramatic lashes, large eyes with bright real catchlights, a deep wine-red glossy lip, a large sculpted gele head-wrap of stiff gold-and-cream fabric folded high above her head, a poised, joyful, radiant expression",
 "A big gold hoop with a red-enamel bead on each ear.")
add("국제","소피아 로렌풍(이탈리아)","Italian",
 "warm olive skin, thick strongly arched dark brows, a long black liner winging up and out at the outer corner of each eye, soft brown eyeshadow, long lashes, large dark eyes with bright real catchlights, a deep red lip with a defined edge, thick glossy dark-brown hair set in a high backcombed style, a smouldering, confident expression",
 "A large pearl drop and a gold clip on each ear.")
add("국제","화환 화장(우크라이나)","Ukrainian",
 "fair, luminous skin, round warm red blush high on the cheeks, dark strongly defined straight brows, soft brown eyeshadow, long lashes, large blue-grey eyes with bright real catchlights, a natural deep rose lip, long light-brown hair in a thick braid over one shoulder, and a wreath of real red poppies, blue cornflowers and wheat ears sitting on top of the head, a warm, calm expression",
 "A big silver hoop with a red-enamel bead on each ear.")
add("국제","스칸디 프로스트(스웨덴)","Swedish",
 "very pale, cool skin, a soft white-silver highlighter along the cheekbones, nose bridge and brow bones, pale icy-blue eyeshadow with a fine silver shimmer, pale softly brushed blonde brows, curled light-brown-tipped lashes, large pale-blue eyes with bright real catchlights, a sheer frosted pale-pink lip, long straight platinum-blonde hair, a cool, calm, faraway expression",
 "A big smooth silver hoop on each ear; a small silver ring through the outer end of the left eyebrow.")
add("국제","브리티시 모드(영국)","British",
 "pale, matte, porcelain skin, a bold black graphic crease line drawn high above each eyelid, very thick false lashes on the top lids, small painted lash strokes beneath each lower lid, pale lilac-white eyeshadow, large eyes with bright real catchlights, natural brows, a pale peachy-white lip, a sleek black bob with a blunt fringe, a cool, wide-eyed, doll-like expression",
 "A large flat geometric silver disc earring on each ear.")
add("국제","발칸 글램(루마니아·불가리아)","Romanian",
 "warm fair-olive skin, thick dark straight-edged brows, a heavy black liner smoked out at the outer corners, deep brown shadow blended up to the crease, long dense lashes, large dark eyes with bright real catchlights, sculpted contour, a deep red matte lip with a crisp edge, long dark-brown hair in glossy voluminous waves, an intense, proud expression",
 "A thick gold hoop with a gold coin drop on each ear; a thin gold ring through the left nostril.")
add("국제","노르딕 발키리(노르웨이)","Norwegian",
 "fair skin with a light scatter of freckles, strong straight defined dark-blonde brows, warm bronze shadow across the lids, a fine brown liner, long lashes, large pale-blue eyes with bright real catchlights, soft contour, a muted red-brown lip, long pale-blonde hair in two thick braids and a braided crown, a fierce, steady, commanding expression",
 "A thick silver knotted hoop on each ear; a small silver bar through the outer end of the left eyebrow.")

assert len(S) == 37, len(S)

ENG = ["ko-gyaru","hime-gyaru","age-gyaru","onee-gyaru","lolita-gyaru","ama-gyaru",
 "yamanba","manba","banba","visual-kei","jirai-kei","yamikawa","decora",
 "glamorous party","girl-crush","dark vampire","Gangnam-eonni","doll","hanbok-editorial",
 "guofeng","weixun","Hong Kong-style",
 "lakorn-drama glam","pageant glam","telenovela glam","French red-lip","Slavic glam","Instagram glam","West African party-glam",
 "Habesha","Yoruba bridal","1960s Italian film-star","folk-portrait","Scandi frost","1960s mod","Balkan glam","Nordic valkyrie"]
assert len(ENG) == 37, len(ENG)


# 재질 쌍 (왼쪽, 오른쪽)
PAIRS = [
 ("amber","glacial"),("amethyst","citrine"),("ruby","jade"),("smoky","alabaster"),("emerald","rosequartz"),("rosepink","aquamarine"),
 ("ice","carnelian"),("amber","cobalt"),("opal","egglass"),("alabaster","ruby"),("rosequartz","smoky"),("moonstone","sapphire"),("murano","amethyst"),
 ("aquamarine","carnelian"),("smoky","citrine"),("frosted","ruby"),("jade","rosepink"),("rosequartz","cobalt"),("emerald","amber"),
 ("sapphire","carnelian"),("seaglass","amethyst"),("cobalt","alabaster"),
 ("egglass","citrine"),("resin","sapphire"),("jade","carnelian"),("opal","jade"),("moonstone","emerald"),("amber","smoky"),("murano","aquamarine"),
 ("alabaster","emerald"),("glacial","ruby"),("frosted","sapphire"),("aquamarine","rosepink"),("seaglass","murano"),("resin","amethyst"),("citrine","cobalt"),("ice","egglass"),
]
assert len(PAIRS) == 37, len(PAIRS)

# 체형 배정: bust 8, top 8, hgu 7, hgs 5, tent 5, colo 4
BODYSEQ = ["bust","top","hgu","tent","colo","hgs","bust","top","hgu","hgs","tent","colo","bust","top","hgu","hgs","tent","bust","top","hgu","colo","hgs","bust","top","hgu","tent","bust","top","hgu","hgs","tent","bust","top","hgu","hgs","colo","tent"]
# 정렬 확인
cnt = collections.Counter(BODYSEQ)
assert len(BODYSEQ) == 37, len(BODYSEQ)

WHITISH = {"alabaster","moonstone","opal","frosted","seaglass","rosequartz","resin","ice","glacial"}
for i,(a,b) in enumerate(PAIRS,1):
    assert a != b
    assert {a,b} != {"ice","glacial"} and not ({"ice","glacial"} <= {a,b})
    assert not ({"moonstone","opal"} <= {a,b})
    assert not (a in WHITISH and b in WHITISH), (i,a,b)

def build(idx):
    cat, name, nat, face, pierce = S[idx]
    a, b = PAIRS[idx]
    bk = BODYSEQ[idx]
    bname, btext = BODY[bk]
    an, adesc, ainner = MAT[a]
    bn, bdesc, binner = MAT[b]
    mk = ENG[idx]
    if idx < 13:
        nat = 'Japanese'
    p = f"""Professional fashion photograph, bust shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head to just below her chest, the frame cutting off beneath the chest. Her face sits large and sharp in the upper half of the frame. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {face}. {pierce} All jewelry is opaque metal, pearl or enamel. Her whole face, ears and neck are real living flesh with real pores and fine skin grain — a photograph of a real face, not an illustration.

Physique: {btext}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest): solid {adesc}, with {ainner}. Right half: solid {bdesc}, with {binner}. Each is carved as one sculpted mass like a statue, solid all the way through and never hollow, the chest two great rounded masses with the groove between them cut into the material. The arms flow into the chest with no seam, and every wrist, palm, finger and knuckle is the same material as its arm, with no skin texture on any hand.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the chest and out of the bottom of the frame where the two materials meet, never horizontal. Shards interlock along the lines only, every broken edge solid all the way through.

Pose: body angled 45 degrees, her left hand (solid material) held low at the frame edge beside her chest, her right hand (solid material) held at chest height clear of her body, well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal light on her face only; a strong backlight through each half so both sides glow from within with visible depth; a thin cool rim light along the centre line. 2:3 vertical 8K portrait."""
    return name, cat, bname, an, bn, p

out = []
for i in range(37):
    out.append(build(i))

# 통계
mc = collections.Counter()
for a,b in PAIRS:
    mc[a]+=1; mc[b]+=1
print("재질 사용 횟수:", {MAT[k][0]:v for k,v in sorted(mc.items(), key=lambda x:-x[1])})
print("체형:", {BODY[k][0]:v for k,v in cnt.items()})
wc = [len(o[5].split()) for o in out]
print("단어수 min/avg/max:", min(wc), sum(wc)//len(wc), max(wc))
# 한글 누출 검사
for o in out:
    if re.search(r'[\uac00-\ud7a3]', o[5]):
        print("KOREAN LEAK:", o[0])
import pickle
pickle.dump(out, open("out.pkl","wb"))
