# -*- coding: utf-8 -*-
import re, sys, random, json
from collections import Counter
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_twomix_alt_test.py', encoding='utf-8').read().split("\nmk = rnd.sample(T.MAKEUP_48, 6)")[0])        # craft_prompt, mat_prompt (2혼합 번갈아 배치)
exec(open('gen_mixtrack_geo_test.py', encoding='utf-8').read().split("\nspecs = [")[0])                                 # build_mix, person_pm ... (임산부·맥시)
rnd.seed(20261017)
def pct(lo, hi, step=1): return rnd.randrange(lo, hi+1, step)

# ---- 공통 덮어쓰기: 꽃·수정 제외, 석재+목재 동시 제외, 팔 올린 자세 제외 ----
BAN = {"botanical","crystal","wax"}
UV_TAKEN = [False]
def pick_ex(n, allow_uv):
    allow_uv = allow_uv and not UV_TAKEN[0]          # 이미지당 UV네온 인물은 1명까지
    pool = [m for m in MATKEYS if m not in BAN and (allow_uv or m != "uvneon")]
    while True:
        m = rnd.sample(pool, n)
        if not ({"stone","wood"} <= set(m)):
            if "uvneon" in m: UV_TAKEN[0] = True
            return m
def pick_noUV(n): return pick_ex(n, False)
def pick_mats_nosw(n): return pick_ex(n, True)
def pick_mats(n): return pick_ex(n, True)
UV_FULL[:] = [x for x in UV_FULL if "crystal" not in x[0].lower() and "crystal" not in x[1].lower()]
POSES[:] = [p for p in POSES if "overhead" not in p]                 # 임산부 포즈
POSES_MX[:] = [p for p in POSES_MX if "overhead" not in p]           # 맥시멀리스트 포즈
FRONT_POSES[:] = [p for p in FRONT_POSES if p != "양팔위로"]          # 공예 포즈

_bm, _mp = build_mix, mat_prompt
def build_mix(*a, **k):
    UV_TAKEN[0] = False
    return _bm(*a, **k)
def mat_prompt(*a, **k):
    UV_TAKEN[0] = False
    return _mp(*a, **k)

def fix(p):
    p = re.sub(r"\.\s*, no fabric", ", no fabric", p)
    p = p.replace(",,", ",")
    return dd(p)
def check(key, p, allow_uv, mat=True):
    validate(key, p)
    low = p.lower()
    if mat: assert "crystal" not in low and "blooms growing" not in low and "molten wax" not in low, key
    assert "overhead" not in low, key
    assert not re.search(r",\s*,", p) and "it.," not in p, key
    assert not re.search(r'(?<!corset-)\blace\b(?!-up)', low), key
    assert allow_uv or "UV" not in p, key
    assert not [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", p) if m.group(1).lower() not in ("had","that")], key
    assert "never left bare" in p, key
    assert p.count("UV-reactive neon bodypaint") <= 1, key

TN={1:"solo",2:"duo",3:"trio"}; TY={1:"Solo",2:"Duo",3:"Trio"}; TKO={1:"솔로",2:"듀오",3:"트리오"}
old = {x["key"]: x for x in json.load(open("la_blend_540_bundle.json", encoding="utf-8"))}
HAIRW = re.compile(r'\b(hair|braid|braids|braided|bun|ponytail|twin|bangs|fringe|locs|afro|bob|updo|curls|waves|ringlets|pigtails)\b', re.I)
CLAUSES = sorted({c.strip() for m in T.MAKEUP_48 for c in face(m)[1].split(',') if HAIRW.search(c)}, key=len, reverse=True)

# ================= A. 2혼합 교체 (공예 90 + 재질 90) =================
A=[]
for track in ["craft","mat"]:
    for gs in [1,2,3]:
        for slot in range(1,31):
            key = f"la_{'craftblend' if track=='craft' else 'matblend'}2_{TN[gs]}_{slot:02d}"; assert key in old
            n = rnd.choice([3,4]); kinds = rnd.sample(["H","V","D","C","R"] if n==4 else ["H","V","D","C"], gs)
            if track == "craft": p, desc = craft_prompt(gs, n, kinds, rnd.sample(T.MAKEUP_48, gs), rnd.sample(VOLBODY, gs))
            else: p, desc = mat_prompt(gs, n, kinds)
            p = fix(p); check(key, p, allow_uv=(track=="mat"), mat=(track=="mat"))
            assert "alternate between 2" in p and not any(c in p for c in CLAUSES), key
            structs = re.findall(r"\[([^/]+?) / ", desc)
            A.append({"key":key,"category":"🏺 Living Artifact · Craft Blend Formula" if track=="craft" else "🏺 Living Artifact · Material Blend Formula",
                "title":f"{'Craft' if track=='craft' else 'Material'} Blend 2-Mix {TY[gs]} #{slot:02d} ({' / '.join(structs)})","prompt":p,
                "meta":{"group_size":gs,"aspect_ratio":ASP[gs],"format":"craft-blend" if track=="craft" else "material-blend","mix_count":2,"regions":n,"layout":"geometry-hazy-alt-v2","structures":structs}})
assert len(A)==180

# ================= B. 임산부 재질 블렌드 (신규 180) =================
B=[]
for mixn in [3,4]:
    for gs in [1,2,3]:
        for slot in range(1,31):
            key=f"la_pregmat{mixn}_{TN[gs]}_{slot:02d}"
            p, desc = build_pm(gs, mixn, rnd.sample(T.MAKEUP_48, gs)); p = fix(p); check(key, p, allow_uv=False)
            assert not any(c in p for c in CLAUSES), key
            structs = [s.split(" / ")[0].strip("[") for s in desc.split(" ; ")]
            B.append({"key":key,"category":"🤰 Living Artifact · Pregnant Material Blend Formula",
                "title":f"Pregnant Material Blend {mixn}-Mix {TY[gs]} #{slot:02d} ({' / '.join(structs)})","prompt":p,
                "meta":{"group_size":gs,"aspect_ratio":ASPECT[gs],"format":"fused-material-blend","mix_count":mixn,"layout":"geometry-hazy-v2","structures":structs}})
assert len(B)==180

# ================= C. 임산부 × 맥시멀리스트 트랙 혼합 (신규 120) =================
C=[]
for mixn in [3,4]:
    for gs in [2,3]:
        for slot in range(1,31):
            key=f"la_trackmix{mixn}_{TN[gs]}_{slot:02d}"
            tracks = ["임산부","맥시"] if gs==2 else rnd.choice([["임산부","맥시","맥시"],["임산부","임산부","맥시"]])
            tracks = rnd.sample(tracks, len(tracks))
            p, desc = build_mix(tracks, mixn); p = fix(p); check(key, p, allow_uv=True)
            structs = [d.strip("[]").split(" / ")[0] for d in desc.split(" ; ")]
            C.append({"key":key,"category":"🏺 Living Artifact · Pregnant × Maximalist Mix Formula",
                "title":f"Track Mix {mixn}-Mix {TY[gs]} #{slot:02d} ({' / '.join(structs)})","prompt":p,
                "meta":{"group_size":gs,"aspect_ratio":ASP[gs],"format":"track-mix-material","mix_count":mixn,"layout":"geometry-hazy-v2","tracks":tracks,"structures":structs}})
assert len(C)==120

for name, data in [("la_twomix_geo2_180_bundle.json",A),("la_pregmat_geo_180_bundle.json",B),("la_trackmix_geo_120_bundle.json",C)]:
    assert len({x["key"] for x in data})==len(data)
    json.dump(data, open(name,"w",encoding="utf-8"), ensure_ascii=False, indent=2)
print("생성 완료: A", len(A), "/ B", len(B), "/ C", len(C))
for tag,data in [("A 2혼합",A),("B 임산부재질",B),("C 트랙혼합",C)]:
    for g in sorted({x["meta"]["group_size"] for x in data}):
        ws=[len(x["prompt"].split()) for x in data if x["meta"]["group_size"]==g]
        print(f"  {tag} {TKO[g]}: {min(ws)}~{max(ws)}단어")
print("C 트랙 구성:", dict(Counter("+".join(x["meta"]["tracks"]) for x in C)))
mc=Counter()
for x in A+B+C:
    for m in MATKEYS:
        pass
print("꽃·수정·팔올림 문구 잔존: 0 (검증 통과)")
