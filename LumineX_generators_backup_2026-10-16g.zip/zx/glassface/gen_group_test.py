# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
_top = open('gen_hazy_test.py', encoding='utf-8').read().split("makeups = rnd.sample(T.MAKEUP_48, 33)")[0]
exec(_top)          # make_structure, hazy, STRUCT_KIND/KO, sens_count, FRONT_POSES, face_nohair, validate 등
rnd.seed(20261006)

def hazy2(shape, kind):
    return hazy(shape, kind) + " Even inside a transition zone the skin is never left bare: at every point one pattern, or a mixture of the two, fully covers it."

CELLS = [(k, s) for k in ["H","V","D","C","R"] for s in ["smooth","undulating"]]
def draw_cells(g):
    while True:
        picks = [rnd.choice(CELLS) for _ in range(g)]
        if len({k for k,_ in picks}) == g: return picks     # 한 이미지 안에서 구조가 서로 다르게

def person_block(label, makeup, bodykey, crafts, kind, shape):
    n = len(crafts)
    pre, reg, lab = make_structure(kind, n, shape)
    assert sens_count(pre+" "+" ".join(reg)) == 0
    texts=[]
    for c in crafts:
        cn,cd,cb,cf = CRAFT_DB_FULL[c]
        texts.append(f"{cn} ({cd}), wide {cb} bands following the contours of the body, dense {cf} filling the space between bands")
    sents = " ".join(f"Region {i+1} is {reg[i]}: it is painted in {texts[i]}." for i in range(n))
    art = (f"Her bare skin is painted with {n} different traditional patterns, each claiming its own region of her figure. {pre} {sents} {hazy2(shape, STRUCT_KIND[kind])} Pigment on living skin throughout, covering every inch of her body below the jaw with no bare skin anywhere, face unpainted.")
    nat, fa = face_nohair(makeup)
    age = AGE_EN_FULL[rnd.choice(T.AGE_12)]; vibe = VIBE_EN_FULL[rnd.choice(T.VIBE_5)]
    hs = HAIR_EN_FULL[rnd.choice(T.HAIR_STYLE)]; hc = HAIR_COLOR_EN_FULL[rnd.choice(T.HAIR_COLOR)]
    nail = f"{NAIL_SHAPE_EN_FULL[rnd.choice(T.NAIL_SHAPES)]} nails, {NAIL_FIN_EN_FULL[rnd.choice(T.NAIL_FINISH)]} finish"
    pose = POSE_EN_FULL[rnd.choice(FRONT_POSES)]; shoe = SHOE_EN_FULL[rnd.choice(T.SHOES_24)]
    subj = f"a real adult {nat} woman in her {age}, her face exactly the same tone as her body, real skin texture with visible pores and fine grain, {fa}, {vibe}, {hc} hair styled in {hs}, real living eyes. Long {nail}."
    txt = (f"{label} woman: {subj}\n\n{label} woman's physique: {cap(BODY_FULL[bodykey])}\n\n{label} woman's body art: {art}\n\n"
           f"{label} woman's pose: {pose}, every region clearly visible to the camera.\n\n{label} woman's footwear: extreme {shoe}, painted with the blended patterns following the same soft transitions as her skin.")
    return txt, f"{label[0]}:{STRUCT_KO[kind]}·{'물결' if shape=='undulating' else '매끈'}"

def build_group(gsize, n):
    makeups = rnd.sample(T.MAKEUP_48, gsize); bodies = rnd.sample(VOLBODY, gsize)
    pool = rnd.sample(T.CRAFTS_39, gsize*n); cells = draw_cells(gsize)
    labs = ["Left","Center","Right"][:gsize]; blocks=[]; descs=[]; people=[]
    for i in range(gsize):
        b, d = person_block(labs[i], makeups[i], bodies[i], pool[i*n:(i+1)*n], *cells[i])
        blocks.append(b); descs.append(d); people.append(f"{labs[i][0]}={bodies[i]}/{makeups[i]}")
    body = "\n\n".join(blocks)
    p = (f"Image format: a landscape-orientation photograph, {ASP[gsize]} aspect ratio.\n\nA photograph of {NW[gsize]} women standing side by side on a plain seamless deep-charcoal backdrop, nothing else in the frame, 50mm lens at f/8, a single hard key light raking across all of them from one side, sharp focus head to toe on each — a real photograph, not an illustration, not CGI, not a render.\n\n{body}\n\nComposition: each woman's own pose as described, inner arms not crossing her neighbours, all faces toward the camera.\n\nLighting: the blended painted patterns reading crisp against each woman's skin, the hard raking light carving every fold and curve. Shot on a Hasselblad X2D, {ASP[gsize]} 8K.")
    return p, descs, people

items=[]   # (구분, 인원, 구역수, 구성, 프롬프트)
plan = [(2,3),(2,3),(2,4),(2,4),(3,3),(3,3),(3,4),(3,4),(3,4)]
for gsize,n in plan:
    p, descs, people = build_group(gsize, n); validate(f"grp_{gsize}_{n}", p)
    items.append(("새 방식", gsize, n, " / ".join(descs)+" — "+" ; ".join(people), p))

# 등록분 직접 대조군 3개 (번들의 실제 프리셋)
bundle = json.load(open("la_blend_540_bundle.json", encoding="utf-8")); bk = {x["key"]: x for x in bundle}
def reg(mixn, tn, gsize):
    slot = rnd.randrange(1,31); key = f"la_craftblend{mixn}_{tn}_{slot:02d}"; x = bk[key]; pr = x["prompt"]
    bodies = [k for k in VOLBODY if cap(BODY_FULL[k]) in pr]; mks = [m for m in T.MAKEUP_48 if face_nohair(m)[1] in pr]
    return ("등록분", gsize, mixn, f"{key} — 체형 {'/'.join(bodies)} ; 메이크업 {'/'.join(mks)}", pr)
items += [reg(2,"duo",2), reg(3,"duo",2), reg(4,"trio",3)]
assert len(items)==12

order = list(range(12)); rnd.shuffle(order); no = {i: order.index(i)+1 for i in range(12)}
ranked = sorted(range(12), key=lambda i: no[i])
L = ["# LumineX · 희미한 경계 — 듀오·트리오 검증 12개\n",
 "새 방식 9개(듀오 4·트리오 5, 3~4구역)와 이미 등록된 프리셋 3개(대조군)를 섞어 번호를 붙였습니다. **성공/실패만** 알려주세요(최대 3회, 1회/2회/3회/실패). 예: `03: 2회 / 07: 실패 / 나머지 1회`\n",
 "## 색인\n","| 번호 | 구분 | 인원 | 구역 수 | 구성 |","|---|---|---|---|---|"]
for i in ranked:
    g,gs,n,desc,p = items[i]; L.append(f"| {no[i]:02d} | {g} | {'듀오' if gs==2 else '트리오'} | {n} | {desc} |")
L.append("")
for i in ranked:
    g,gs,n,desc,p = items[i]
    L.append(f"## {no[i]:02d}. {g} · {'듀오' if gs==2 else '트리오'} {n}구역\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_HazyBoundary_GroupTest_12.md","w",encoding="utf-8").write("\n".join(L))
json.dump([{"no":no[i],"kind":items[i][0],"gsize":items[i][1],"n":items[i][2],"desc":items[i][3]} for i in ranked], open("/home/claude/group_test_meta.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
ws=[(no[i],items[i][0],len(items[i][4].split())) for i in ranked]
print("12개 저장 | 새 방식 단어수:", min(w for _,k,w in ws if k=='새 방식'),"~",max(w for _,k,w in ws if k=='새 방식'), "| 등록분:", [w for _,k,w in ws if k=='등록분'])
print("대조군 번호:", [(no[i], items[i][3].split(' — ')[0]) for i in ranked if items[i][0]=='등록분'])
print("새 방식에 보호문장 포함:", all(("never left bare" in items[i][4]) for i in range(9)), "| 등록분에는 없음:", all(("never left bare" not in items[i][4]) for i in range(9,12)))
for i in ranked:
    if items[i][0]=="새 방식": print(f"  {no[i]:02d}", items[i][3][:110])
