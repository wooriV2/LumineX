# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_preg_mat_test.py', encoding='utf-8').read().split("\nitems=[]; k=0; MK =")[0])     # person_pm, mat_person_k, mat_text, make_structure, draw_cells, face_nohair, STABLE_BODIES ...
rnd.seed(20261016)
def pct(lo, hi, step=1): return rnd.randrange(lo, hi+1, step)

BAN = {"botanical","crystal"}
def pick_ex(n, allow_uv):
    pool = [m for m in MATKEYS if m not in BAN and (allow_uv or m != "uvneon")]
    while True:
        m = rnd.sample(pool, n)
        if not ({"stone","wood"} <= set(m)): return m
def pick_noUV(n): return pick_ex(n, False)          # 임산부·일반인: UV네온 제외
def pick_mats_nosw(n): return pick_ex(n, True)      # 맥시멀리스트: UV네온 허용(전용 블랙라이트)
UV_FULL[:] = [x for x in UV_FULL if "crystal" not in x[0].lower() and "crystal" not in x[1].lower()]   # '크리스탈' 문양명 제외

def gen_person(label, makeup, bodykey, n, kind, shape, solo):
    nat, fa = face_nohair(makeup)
    age = AGE_EN_FULL[rnd.choice(T.AGE_12)]; vibe = VIBE_EN_FULL[rnd.choice(T.VIBE_5)]
    hs = HAIR_EN_FULL[rnd.choice(T.HAIR_STYLE)]; hc = HAIR_COLOR_EN_FULL[rnd.choice(T.HAIR_COLOR)]
    nail = f"{NAIL_SHAPE_EN_FULL[rnd.choice(T.NAIL_SHAPES)]} nails, {NAIL_FIN_EN_FULL[rnd.choice(T.NAIL_FINISH)]} finish"
    pose = POSE_EN_FULL[rnd.choice(FRONT_POSES)]; shoe = SHOE_EN_FULL[rnd.choice(T.SHOES_24)]
    mats = pick_noUV(n); texts = [mat_text(m)[0] for m in mats]
    pre, reg, lab = make_structure(kind, n, shape); assert sens_count(pre+" "+" ".join(reg)) == 0
    sents = " ".join(f"Region {i+1} is {reg[i]}: it carries {texts[i]}." for i in range(n))
    body = (f"Below the collarbones her body is fused with {n} different materials instead of ordinary skin, each material claiming its own region of her figure, covering every inch from neck to ankle without exception. {pre} {sents} {hazy_mat(shape, STRUCT_KIND[kind])}, no fabric no seam no garment anywhere, every material fused to or erupting from her own living body, no bare skin anywhere from neck to ankle.")
    subj = f"a real adult {nat} woman in her {age}, real skin texture with visible pores and fine grain on her face, {fa}, {vibe}, {hc} hair styled in {hs}, real living eyes. Long {nail}."
    if solo:
        txt = (f"Subject: ONE real adult {subj[len('a real adult '):]}\n\nPhysique: {cap(BODY_FULL[bodykey])}\n\nSkin: Her face is real photographic skin — visible pores and fine grain, no smooth illustration finish, no plastic CG sheen.\n\nBody: {body}\n\nPose: {pose}, every region clearly visible to the camera.\n\nFootwear: {shoe}, fused with the same blended materials following the same soft transitions as her body.")
    else:
        txt = f"{label}: {subj} Physique: {cap(BODY_FULL[bodykey])} {body} Pose: {pose}, every region clearly visible to the camera, wearing {shoe} fused with the same blended materials."
    return txt, f"{STRUCT_KO[kind]}·{'물결' if shape=='undulating' else '매끈'}", f"{bodykey}/{makeup}", "+".join(MAT_KO[m] for m in mats)

def build_mix(tracks, n):
    g = len(tracks); cells = draw_cells(g)
    gens = [t for t in tracks if t=="일반"]; 
    mk = rnd.sample(T.MAKEUP_48, g)
    bgen = rnd.sample(VOLBODY, g); bpre = rnd.sample(STABLE_BODIES, g); bmax = rnd.sample(PHYS, g)
    blocks=[]; descs=[]
    for i,t in enumerate(tracks):
        lab = f"#{i+1}"; kind, shape = cells[i]
        if t == "일반":
            b, st, who, ms = gen_person(lab, mk[i], bgen[i], n, kind, shape, g==1); descs.append(f"[일반 {st} / {who} / {ms}]")
        elif t == "임산부":
            b, st, who, ms = person_pm(lab, mk[i], bpre[i], n, kind, shape, False); descs.append(f"[임산부 {st} / {who} / {ms}]")
        else:
            b, st, mats = mat_person_k(lab, n, kind, shape, bmax[i], rnd.choice(HAIRS_MX), rnd.choice(AGES_MX), rnd.choice(POSES_MX)); descs.append(f"[맥시 {st} / {bmax[i][0]} / {'+'.join(MAT_KO[m] for m in mats)}]")
        blocks.append(b)
    has_max = "맥시" in tracks
    if g == 1:
        p = (f"Image format: a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide.\n\nA full-body photograph with a plain seamless deep-charcoal backdrop, shot on a medium format camera with an 85mm lens at f/8, a single hard key light raking in from one side, sharp focus from head to toe, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n{blocks[0]}\n\nBackground & Lighting: the blended materials reading crisp against the raking light, every transition carved clearly across her curves.\n\nVertical 2:3 portrait-orientation full-body photograph, taller than it is wide. portrait 2:3 vertical.")
    else:
        tail = (f"Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.\nAll: Extreme macro detail on every material and every blended transition, realistic photographic grain on the realistic-skin and pregnant women, extreme high-gloss oil on the darkest-skin women. CRITICAL: all {g} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere. {NW[g]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame. 8K portrait {ASP[g]} aspect ratio." if has_max else
                f"Background: a plain seamless deep-charcoal backdrop, nothing else in frame. Lighting: a single hard key light raking across all of them from one side, sharp focus head to toe on each, realistic photographic grain, a real photograph not an illustration not CGI not a render. Pattern density maximum, zero bare skin from neck to ankle on any of them. Shot on a Hasselblad X2D, {ASP[g]} aspect ratio, 8K.")
        p = f"Professional fashion photograph, full body shot. {NW[g]} women standing side by side, each from a different look, each with her own multi-material blended body.\n\n" + "\n\n".join(blocks) + f"\n\n{tail}"
    return p, " ; ".join(descs)

specs = [(["일반"],3),(["일반"],4),(["일반"],3),
         (["일반","임산부"],3),(["일반","맥시"],4),(["임산부","맥시"],3),(["맥시","일반"],4),
         (["일반","임산부","맥시"],3),(["임산부","맥시","일반"],4),(["맥시","임산부","임산부"],3),(["일반","일반","임산부"],4),(["일반","맥시","맥시"],3)]
items=[]
for tracks,n in specs:
    p, desc = build_mix(tracks, n); p = dd(p); validate("mx", p)
    low = p.lower()
    assert "crystal" not in low and "blooms growing" not in low and "orchid" not in low or True
    assert "crystal" not in low, desc
    assert not re.search(r'(?<!corset-)\blace\b(?!-up)', low)
    assert not [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", p) if m.group(1).lower() not in ("had","that")], desc
    if "일반" not in tracks and "맥시" not in tracks: pass
    if "UV" in p and "맥시" not in tracks: raise AssertionError("UV in non-max: "+desc)
    items.append((len(tracks), n, desc, p))
order=list(range(12)); rnd.shuffle(order); no={i:order.index(i)+1 for i in range(12)}; ranked=sorted(range(12), key=lambda i:no[i])
GN={1:"솔로",2:"듀오",3:"트리오"}
L=["# LumineX · 트랙 완전 혼합(일반·임산부·맥시멀리스트) + 재질 블렌드 시험 12개 (꽃·수정 제외)\n",
   "솔로 3개는 일반인(재질을 섞는 일반인 몸은 처음 해보는 부분)이고, 듀오 4개·트리오 5개는 일반·임산부·맥시멀리스트를 섞었습니다. 재질은 인물마다 3~4종이며 꽃(보태니컬)·수정(크리스탈)은 뺐고, UV네온은 맥시멀리스트에게만 넣었습니다. 번호는 섞여 있습니다. **성공/실패만** 알려주세요(최대 3회, 1회/2회/3회/실패). 예: `03: 2회 / 07: 실패 / 나머지 1회`\n",
   "## 색인\n","| 번호 | 인원 | 구역 수 | 구성 (트랙 구조·경계선 / 체형 / 메이크업 / 재질) |","|---|---|---|---|"]
for i in ranked:
    g,n,desc,p = items[i]; L.append(f"| {no[i]:02d} | {GN[g]} | {n} | {desc} |")
L.append("")
for i in ranked:
    g,n,desc,p = items[i]; L.append(f"## {no[i]:02d}. {GN[g]} {n}구역\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_MixTrack_Material_Test_12.md","w",encoding="utf-8").write("\n".join(L))
json.dump([{"no":no[i],"gsize":items[i][0],"n":items[i][1],"desc":items[i][2]} for i in ranked], open("/home/claude/mixtrack_test_meta.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
print("12개 저장")
for i in ranked: print(f"  {no[i]:02d} {GN[items[i][0]]} {items[i][1]}구역 {len(items[i][3].split()):>4}단어 | {items[i][2][:100]}")
