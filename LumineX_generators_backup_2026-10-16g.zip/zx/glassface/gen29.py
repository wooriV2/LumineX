# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g28 = load("g28","gen28.py"); g3 = g28.g3
HIP_BODY = g28.HIP_BODY; CARE = g28.CARE; SPEC = g28.SPEC

BODY_RULE = "All body jewelry is real opaque metal set in real skin that is healed, clean and calm — no blood, no redness, no swelling, no wound, the skin around each piece smooth and unbroken — with a small natural warm shadow under each piece."

def body_text(tier, M):
    b8  = f"In her navel sits a real {M} barbell with a small pearl drop."
    b25 = f" Two {M} surface bars lie flat across the skin over the front of the hip bones, one on each side, only their two end studs showing."
    b50 = f" A row of three small domed {M} jewels on anchored posts sits along each shoulder cap, and several of her fingers carry real {M} rings."
    b100 = f" A vertical ladder of five small {M} rings runs up each side of her waist like corset lacing, two thick {M} surface bars lie across each upper arm, and a fine {M} chain loops from the navel barbell to the hip bars."
    b150 = f" Two more {M} surface bars lie across each forearm, a real {M} ring circles each wrist, a few surface bars sit a hand's breadth below the collarbones, and two more fine chains loop across her belly."
    charm1 = " About ten small light charms — a tiny star, a heart, a ribbon bow, a small teddy-bear charm, a short bead string and a rhinestone bottle in pastel enamel and acrylic — hang on short fine chains from the navel barbell, the hip-bar studs and the ear hoops, all generic and light, none near the eyes."
    charm2 = " About twenty small light charms — tiny stars, hearts, ribbon bows, teddy-bear charms, bead strings, pearl strings, small bells and rhinestone bottles in enamel, acrylic and pearl — hang on short fine chains from the navel barbell, the hip-bar studs, the waist rings, the wrist rings and the ear hoops, all generic and light, none near the eyes."
    t = {"8": b8, "25": b8+b25, "50": b8+b25+b50, "100": b8+b25+b50+b100,
         "150": b8+b25+b50+b100+b150, "K1": b8+b25+b50+b100+charm1, "K2": b8+b25+b50+b100+b150+charm2}
    return t[tier]

OUT = []
for tier, sty, bk, a, b, face_p, mcode, mtxt, label, flevel in SPEC:
    nat, mk, fc = g3.face_of(sty)
    bname, btext = HIP_BODY[bk]
    fp = g28.metalize(face_p, mcode) if mcode in ("rose-gold","silver") else face_p
    M = mcode
    bt = body_text(tier, M)
    p = f"""Professional fashion photograph, three-quarter body shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head down through the hips, the frame cutting off across the upper thighs so no knees, lower legs or feet are visible. Her face sits in the upper part of the frame, and her ear pieces are oversized so they read clearly at this distance. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}. She is a real living woman: real pores and fine skin grain on her face and body, real living eyes with bright catchlights, individual hair strands catching the light — a photograph of a real person, not an illustration, not a render.

Clothing: she wears a plain black matte stretch cropped tank top with thin straps and a low-rise fitted black stretch skirt, leaving her shoulders, arms, waist, navel and hips bare.

Physique: {btext}

Face piercings: {fp} {CARE.format(metal=mtxt)}

Body piercings: {bt} {BODY_RULE}

Pose: body angled 45 degrees, her left hand resting on her flared hip, her right hand held clear of her body at hip height, well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal beauty light on her face, shoulders and waist, so the makeup and the glints on every piece of metal read clearly, with a thin cool rim light along her hair and shoulders, shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait."""
    OUT.append((tier, sty, bname, label, flevel, p))

if __name__ == "__main__":
    for t, s, bn_, l, fl, p in OUT:
        print(t, s, bn_, l, fl, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
