# -*- coding: utf-8 -*-
import re, sys, random, json
from collections import Counter
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_final3.py', encoding='utf-8').read().split("\n# ================= A.")[0])     # 덮어쓰기(꽃·수정·촛농·팔올림 제외, UV 1명)·build_A·fix·check
rnd.seed(20261102)
old = json.load(open("la_matblend_geo_180_bundle.json", encoding="utf-8"))
BAD = {"botanical","crystal","wax"}
aff = [x for x in old if any(set(ms) & BAD for ms in x["meta"]["materials"])]
TY={1:"Solo",2:"Duo",3:"Trio"}; ASPV={1:"2:3",2:"3:4",3:"4:5"}
new=[]
for x in aff:
    key=x["key"]; mixn=x["meta"]["mix_count"]; g=x["meta"]["group_size"]; slot=int(key.rsplit("_",1)[1])
    UV_TAKEN[0] = False
    p, descs, allm = build_A(g, mixn); p = fix(p); check(key, p, allow_uv=True, mat=True)
    assert all(not ({"stone","wood"} <= set(ms)) and not (set(ms) & BAD) for ms in allm)
    mats_ko = " / ".join("+".join(MAT_KO[m] for m in ms) for ms in allm)
    new.append({"key":key,"category":x["category"],"title":f"Material Blend {mixn}-Mix {TY[g]} #{slot:02d} ({' / '.join(descs)} | {mats_ko})","prompt":p,
        "meta":{"group_size":g,"aspect_ratio":x["meta"]["aspect_ratio"],"format":"material-blend","mix_count":mixn,"layout":"geometry-hazy-v2","structures":descs,"materials":allm}})
assert len(new)==len(aff)==134 and len({n["key"] for n in new})==134
json.dump(new, open("la_matblend_replace_134_bundle.json","w",encoding="utf-8"), ensure_ascii=False, indent=2)
print("생성:", len(new), "개 (기존 키에 덮어쓰기)")
for g in [1,2,3]:
    ws=[len(n["prompt"].split()) for n in new if n["meta"]["group_size"]==g]; ow=[len(o["prompt"].split()) for o in aff if o["meta"]["group_size"]==g]
    print(f"  {TY[g]}: 새 {min(ws)}~{max(ws)}단어 (기존 {min(ow)}~{max(ow)})")
mc=Counter(m for n in new for ms in n["meta"]["materials"] for m in ms); print("재질 사용:", dict(sorted(mc.items(), key=lambda kv:-kv[1])))
print("꽃·수정·촛농 잔존 인물:", sum(1 for n in new for ms in n["meta"]["materials"] if set(ms)&BAD), "| UV 2명 이상 이미지:", sum(n["prompt"].count("UV-reactive neon bodypaint")>=2 for n in new))
