# -*- coding: utf-8 -*-
import re, sys, random, json, io, contextlib, importlib.util
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_pierce_face.py', encoding='utf-8').read().split("\nspecs = [")[0])     # EXPOSED·pick_metal·MN·MKO·GKO·gem_text·CARE·face_nohair ...
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()): spec.loader.exec_module(m)
    return m
g18 = load("g18", "gen18.py"); DENS = g18.DENS
rnd.seed(20261109)

def recolor(t, M):
    m = MN[M]
    return re.sub(r"yellow gold|gold", m, t)
def conc_chest(P, M, f):
    m = MN[M]; e = ear_noun(f)
    if P == "P8":
        return (f"All eight piercings gather on the left side of her face and ear, and the right side stays bare: on the left ear five pieces — a huge {m} {e} hanging clear of the neck down to the shoulder, a wide {m} ear cuff, two smaller {m} rings and a small {m} stud at the top; "
                f"two thin {m} bars pass through the outer end of the left eyebrow; a small {m} ring passes through the left nostril.")
    return (f"All twenty-five piercings gather mostly on the left side of her face, and the right side stays almost bare: on the left ear eight oversized pieces — a huge {m} {e} hanging clear of the neck down to the shoulder, a wide {m} ear cuff, three smaller {m} rings, two thick {m} bars and a small {m} stud up to the top; "
            f"one small {m} stud sits in the right ear; four thin {m} bars pass through the outer half of the left eyebrow; two small {m} rings pass through the left nostril and a thick {m} septum ring hangs below the nose; "
            f"a {m} hoop passes through the left edge of the lower lip with a {m} snake-bite ring beside it and a small {m} ring at the left edge of the upper lip; a {m} Medusa stud sits above the lips; a {m} labret stud and a small {m} ring sit on the chin; three small {m} studs run along the left jaw.")
def p200(M):
    t = g18.T150.replace("about one hundred and fifty", "about two hundred").replace("covering the face and neck", "covering the face, neck and shoulders").replace("ten fine gold chains", "twelve fine gold chains")
    t = t.replace("; and twelve fine", "; a row of six small gold studs along each collarbone, a small gold stud on each shoulder and a column of five small studs down each upper arm; and twelve fine")
    assert "collarbone" in t
    return recolor(t, M)
BODIES = ["a full, curvy bust with soft broad shoulders and an hourglass figure", "a very large, heavy bust with soft rounded shoulders", "strong broad shoulders, defined arms and a full bust", "a petite frame with a surprisingly full bust"]
BODY_KO = {0: '풍만한 가슴·넓은 어깨(아워글래스)', 1: '매우 큰 가슴·둥근 어깨', 2: '넓은 어깨·단단한 팔·풍만한 가슴', 3: '작은 체구에 풍만한 가슴'}
def build(P, method):
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC)+1)
    M = pick_metal(ci); G = rnd.choice(GEMS); F = rnd.choice(FORMS); bi = rnd.randrange(len(BODIES)); body = BODIES[bi]
    hair = f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}"
    if method == "집중형": pierce = conc_chest(P, M, F)
    elif P == "P200": pierce = p200(M)
    else: pierce = recolor({"P50": g18.T50, "P100": g18.T100, "P150": g18.T150}[P], M)
    dense = P in ("P100", "P150", "P200")
    metal_phrase = "mixed metal (yellow gold, silver, copper and rose gold, alternating piece by piece)" if M == "MX" else ("rose gold" if M == "MR" else MN[M].replace("-", " "))
    p = (f"Professional fashion photograph, bust shot. ONE woman, facing the camera straight on, her head level, both ears clearly visible on either side of her face, framed from the very top of her head to just below her chest, the frame cutting off beneath the chest. Her face sits large and sharp in the upper half of the frame, and her ear pieces are oversized so they read clearly at this distance. Mid 20s.\n\n"
         f"Subject: A real photograph of a strikingly beautiful adult {nat} woman — {fa}, {hair}. Her whole face, ears, neck, shoulders and arms are real living flesh with real pores and fine skin grain — a photograph of a real woman, not an illustration, not a render.\n\n"
         f"Physique: {body}.\n\nClothing: a black matte stretch crop tank top covering her chest, her shoulders and arms bare.\n\n"
         f"Piercings: {pierce}{DENS if dense else ''}{gem_text(G) if method == '집중형' else ''} {CARE.format(metal=metal_phrase)}\n\n"
         f"Pose: arms relaxed at her sides, shoulders level, head level toward the camera.\n\n"
         f"Lighting: pure pitch black background. A soft frontal light on her face and ears, so the makeup and the glints on every piece of metal read clearly; a thin cool rim light along the hair and shoulders. 2:3 vertical 8K portrait.")
    p = dd(p).replace(",,", ",")
    assert not re.search(r"[가-힣]", p), (P, M)
    if M not in ("MG", "MR", "MX"): assert "gold" not in pierce.lower(), (P, M)
    desc = f"{re.sub(r'^[A-Z]+', '', HS[si-1])} · {re.sub(r'^[A-Z]+', '', HC[ci-1])} · 메이크업 {mk} · 금속 {MKO[M]} · 체형 {BODY_KO[bi]}"
    return p, desc
specs = [("P8","집중형"),("P25","집중형"),("P50","정의형"),("P100","정의형"),("P150","정의형"),("P200","정의형")]
items = [(P, m) + build(P, m) for P, m in specs]
order = list(range(6)); rnd.shuffle(order); no = {i: order.index(i)+1 for i in range(6)}; ranked = sorted(range(6), key=lambda i: no[i])
L = ["# LumineX · 피어싱 가슴 컷 시험 1라운드 (6개, 정면)\n",
     "정면을 바라보는 가슴 컷(머리 위부터 가슴 아래까지)입니다. 피어싱만으로 구성했고 의상은 검은 무광 크롭탱크입니다. 귀 장식은 크게 키웠습니다. P8·P25는 지난 비교 시험의 **비대칭 집중형**(왼쪽 몰림 — 정면에서는 화면 오른쪽에 보입니다)을, P50 이상은 부위·밀도를 정의한 **정의형**을 썼습니다. 메이크업·헤어컬러는 랜덤이고 헤어스타일은 귀가 드러나는 노출형이며, 금속색은 머리색과 대비되게 골랐습니다. 번호는 섞여 있습니다.\n",
     "**알려주실 것**: P8·P25(집중형)는 지난번처럼 **피어싱 개수**를, P50~P200은 **성공/실패**(피어싱이 눈에 띄지 않으면 실패)를 적어 주세요. 최대 3회. 예: `1: 9개 / 2: 22개 / 3: 성공 / 4: 실패`\n",
     "## 색인\n", "| 번호 | 단계 | 방식 | 구성 |", "|---|---|---|---|"]
for i in ranked: P, m, p, d = items[i]; L.append(f"| {no[i]:02d} | {P} | {m} | {d} |")
L.append("")
for i in ranked: P, m, p, d = items[i]; L += [f"## {no[i]:02d}. {P} 가슴 컷 · {m}\n", "```", p, "```\n"]
open("/tmp/rep_out/LumineX_Pierce_Chest_Round1.md", "w", encoding="utf-8").write("\n".join(L))
print("6개 저장")
for i in ranked: P, m, p, d = items[i]; print(f"  {no[i]:02d} {P:<4} {m:<4} {len(p.split()):>3}단어 | {d}")
