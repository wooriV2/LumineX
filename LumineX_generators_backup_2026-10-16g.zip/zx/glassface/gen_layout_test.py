# -*- coding: utf-8 -*-
import re, sys, random
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
_src = open('gen_blend_540.py', encoding='utf-8').read().split("\n# ============================================================\n# 생성 + 검증")[0]
exec(_src)          # validate, mat_text, pick_mats, PHYS, HAIRS_MX, AGES_MX, POSES_MX, face_nohair, cap, VOLBODY 등
rnd.seed(8080)

SOFT = ("Wherever any two regions meet, the boundary is soft and irregular rather than a straight line, the {things} interweaving and overlapping gradually across a blended border a few inches wide, elements of each scattered into the neighbouring region, density fading rather than stopping abruptly")

# 레이아웃 풀: (id, 한글이름, 서두문장(선택), [구역별 부위 설명])
LAYOUTS = {
 2: [
  ("torso_limbs","몸통 vs 팔다리","",["her torso from the base of her neck down to her hips — chest, belly, back and flanks","both of her arms and both of her legs in full, down to the fingertips and toes"]),
  ("radial_core","중심핵 vs 바깥쪽","",["a rounded core centred on her chest and belly, spreading outward across her ribs and hips","everything beyond that core — her shoulders, both arms, thighs, calves and feet"]),
  ("diag_mirror","대각선(오른쪽 어깨→왼쪽 힙)","A single soft diagonal line runs from her RIGHT shoulder down to her LEFT hip.",["the upper-left side of that diagonal — her neck, left shoulder, left arm, upper left chest and left flank","the lower-right side of that diagonal — her right arm, right chest, belly, right hip and both legs"]),
  ("knee_split","무릎 기준 상하","",["everything above her knees — her whole upper body, both arms, hips and thighs","both lower legs from the knees down to the feet"]),
 ],
 3: [
  ("h_bands","가로 3단","",["her shoulders, upper chest and both arms in full down to the fingertips","her ribs, belly, waist and hips","both legs in full from the thighs down to the feet"]),
  ("v_strips","세로 3줄","",["her entire left side — left shoulder and arm, left flank, left hip and the whole left leg","a central strip running down the middle of her body — throat, sternum, belly and the inner thighs","her entire right side — right shoulder and arm, right flank, right hip and the whole right leg"]),
  ("torso_arms_legs","몸통/팔/다리","",["her torso from the collarbones to the hips","both arms in full from the shoulders to the fingertips","both legs in full from the hips to the toes"]),
  ("concentric3","동심 3겹","",["a core centred on her chest and belly","a middle ring around that core — her shoulders, upper arms, hips and thighs","the outer extremities — her forearms, hands, calves and feet"]),
  ("asym_blocks","비대칭 블록","",["her left shoulder, left arm and upper left chest","her right chest, right arm, belly and waist","her hips and both legs in full"]),
  ("upper_plus_legs","상체 + 다리 각각","",["her whole upper body — chest, belly, back and both arms","her entire left leg from the hip to the foot","her entire right leg from the hip to the foot"]),
 ],
 4: [
  ("quadrants","4분면","",["her upper-left quadrant — left shoulder, left arm and the left side of her chest","her upper-right quadrant — right shoulder, right arm and the right side of her chest","her lower-left quadrant — left hip, the left side of her belly and the whole left leg","her lower-right quadrant — right hip, the right side of her belly and the whole right leg"]),
  ("h_bands4","가로 4단","",["her shoulders, upper chest and upper arms","her ribs, belly, waist, hips and forearms","both thighs","both calves and feet"]),
  ("chest_belly_arms_legs","가슴/배·힙/팔/다리","",["her chest and shoulders","her belly, waist and hips","both arms in full from the shoulders to the fingertips","both legs in full from the hips to the toes"]),
  ("concentric4","동심 4겹","",["a core at her chest and belly","a ring around that core — her ribs, shoulders and hips","her upper arms and thighs","her forearms, hands, calves and feet"]),
  ("x_triangles","X자 교차 삼각형","Two soft diagonal lines cross at her navel, dividing her body into four triangles.",["the top triangle — her neck, shoulders and upper chest","the bottom triangle — her pelvis and both legs","the left triangle — her left arm and left flank","the right triangle — her right arm and right flank"]),
 ],
}

FRONT_POSES = [p for p in ["정면와이드스탠스","3/4각도","허리손","머리넘기기","양팔위로","런지자세","걷는동작","옆모습"] if p in POSE_EN_FULL]

def region_block(n, layout, texts, item_fmt):
    lid, ko, pre, regions = layout
    intro = f"her body carries {n} different {'materials' if item_fmt=='mat' else 'painted patterns'} at once, each claiming its own region of her body."
    if pre: intro += " " + pre
    sents = " ".join(item_fmt_fn(i, regions[i], texts[i], item_fmt) for i in range(n))
    return f"{intro} {sents} " + SOFT.format(things="materials" if item_fmt=='mat' else "patterns")

def item_fmt_fn(i, region, text, fmt):
    if fmt == "mat":
        return f"Region {i+1} is {region}: it carries {text}."
    return f"Region {i+1} is {region}: it is painted in {text}."

def build_A(n, layout):
    mats = pick_mats(n)
    items = [mat_text(m) for m in mats]; texts = [t for t,_ in items]
    pn, pd = rnd.choice(PHYS); hair = rnd.choice(HAIRS_MX); age = rnd.choice(AGES_MX)
    pose = rnd.choice(POSES_MX)
    uv = "uvneon" in mats
    light = " A standard hard key light illuminates most of her body; a separate dedicated UV blacklight illuminates the UV-reactive region specifically, making it glow at full intensity while the rest reads under normal light." if uv else ""
    rb = region_block(n, layout, texts, "mat")
    p = (f"Professional fashion photograph, full body shot. ONE woman standing.\n\nTHE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair} — {rb}, no fabric no seam no garment anywhere, every material fused to or erupting from her own living skin, covering her completely with no bare skin anywhere from neck to ankle. Pose: {pose}, every region clearly visible to the camera — most extreme {pn} silhouette ever displayed.{light}\nextreme platform heels/boots blending the relevant materials at her feet, extra long nails each matching whichever region that hand falls in.\n\nMANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. ONE woman only. Extreme macro detail on every material and every blended transition. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle. 2:3 vertical 8K portrait. portrait 2:3 vertical.")
    return p, pn, "+".join(MAT_KO[m] for m in mats)

def build_B(n, layout):
    makeup = rnd.choice(T.MAKEUP_48); bodykey = rnd.choice(VOLBODY); crafts = rnd.sample(T.CRAFTS_39, n)
    nat, fa = face_nohair(makeup)
    age = AGE_EN_FULL[rnd.choice(T.AGE_12)]; vibe = VIBE_EN_FULL[rnd.choice(T.VIBE_5)]
    hs = HAIR_EN_FULL[rnd.choice(T.HAIR_STYLE)]; hc = HAIR_COLOR_EN_FULL[rnd.choice(T.HAIR_COLOR)]
    nail = f"{NAIL_SHAPE_EN_FULL[rnd.choice(T.NAIL_SHAPES)]} nails, {NAIL_FIN_EN_FULL[rnd.choice(T.NAIL_FINISH)]} finish"
    pose = POSE_EN_FULL[rnd.choice(FRONT_POSES)]; shoe = SHOE_EN_FULL[rnd.choice(T.SHOES_24)]
    texts = []
    for c in crafts:
        cn,cd,cb,cf = CRAFT_DB_FULL[c]
        texts.append(f"{cn} ({cd}), wide {cb} bands following the contours of the body, dense {cf} filling the space between bands")
    rb = region_block(n, layout, texts, "craft")
    p = (f"Image format: a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide.\n\nA full-body photograph with a plain seamless deep-charcoal backdrop, shot on a medium format camera with an 85mm lens at f/8, a single hard key light raking in from one side, sharp focus from head to toe, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n"
         f"Subject: ONE real adult {nat} woman in her {age}, her face exactly the same tone as her body, real skin texture with visible pores and fine grain, {fa}, {vibe}, {hc} hair styled in {hs}, real living eyes. Long {nail}.\n\n"
         f"Physique: {cap(BODY_FULL[bodykey])}\n\n"
         f"Skin: Real photographic skin — visible pores and fine grain, a smooth taut surface with natural creases and shadow only where the flesh folds. No smooth illustration finish, no plastic CG sheen.\n\n"
         f"Body Art: Her bare skin is painted — {rb}, pigment on living skin throughout, covering every inch of her body below the jaw with no bare skin anywhere, face unpainted.\n\n"
         f"Pose: {pose}, every region clearly visible to the camera.\n\nFootwear: extreme {shoe}, painted with the blended patterns following the same soft transitions as her skin.\n\n"
         f"Background & Lighting: the blended painted patterns reading crisp against her skin, the hard raking light carving every fold and curve.\n\nVertical 2:3 portrait-orientation full-body photograph, taller than it is wide. portrait 2:3 vertical.")
    return p, bodykey, makeup, "+".join(crafts)

outA=[]; outB=[]
for n in [2,3,4]:
    for lay in LAYOUTS[n]:
        pA, phys, ms = build_A(n, lay); validate(f"A_{n}_{lay[0]}", pA)
        outA.append((f"{n}혼합 · {lay[1]} — {phys} / 재질: {ms}", pA))
        pB, body, mk, cr = build_B(n, lay); validate(f"B_{n}_{lay[0]}", pB)
        outB.append((f"{n}혼합 · {lay[1]} — {body} / {mk} / 공예: {cr}", pB))

for name,out,title in [("Material",outA,"재질(맥시멀리스트)"),("Craft",outB,"바디페인팅 공예(실사)")]:
    L=[f"# LumineX · 경계 레이아웃 다양화 테스트 — {title}, 솔로 {len(out)}개\n\n각 항목은 구역별 부위를 직접 지정합니다(대각선 문구 없음). 제목 형식: 혼합수 · 레이아웃 — 체형 / (메이크업) / 구성\n"]
    for label,p in out:
        L.append(f"## {label}\n"); L.append("```"); L.append(p); L.append("```\n")
    open(f"/tmp/rep_out/LumineX_BoundaryLayouts_Test_{name}.md","w",encoding="utf-8").write("\n".join(L))
print("A:", len(outA), "B:", len(outB))
for (la,pa),(lb,pb) in zip(outA,outB):
    print(f"{la.split(' — ')[0]:<28} A {len(pa.split())}단어 / B {len(pb.split())}단어")
print("diagonal 문구 잔존:", sum(("diagonally" in p) for _,p in outA+outB), "(대각선 레이아웃 2개만 'diagonal' 사용)")
