# -*- coding: utf-8 -*-
import re, sys, os, random, json, collections
os.chdir('/home/claude/glassface'); sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
def load(path):
    src = open(path, encoding="utf-8").read().split("\nspecs = [")[0].split("\nitems = []")[0]; ns = {"__name__": "ns"}; exec(src, ns); return ns
C = load('gen_pierce_waist.py'); M_ = load('gen_pierce_method.py'); GR = load('gen_pierce_group.py')
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 20261211
for k, ns in enumerate((C, M_, GR)): ns["rnd"].seed(SEED + k)
R = random.Random(SEED + 99)
CARE2 = "All jewelry is real {metal}, sitting in real, calm, healthy skin — no redness, no swelling, no irritation — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes."
DEPTH = ("Piercing depth: every bar and surface bar is embedded in the skin — its middle runs beneath the skin so only its two end studs show on the surface, the skin between them faintly raised over the hidden bar, with a small warm shadow at each end and nothing lying on top of the skin like a sticker. "
         "Every ring passes through a small healed opening in the skin, the skin visible through the loop, and every stud sits through the skin with its back hidden. Where a bar, ring or stud goes through the ear, the lip, the nostril or the brow, it passes through the real tissue with the skin wrapping snugly around it.")
C["CARE"] = CARE2; M_["CARE"] = CARE2
REAL_FACE = "Her whole face, ears and neck are real living flesh with real pores and fine skin grain, real living eyes with bright catchlights and genuine depth, individual hair strands catching the light — a photograph of a real face, not an illustration, not a render, not cel-shaded."
SKIN_B = ("Her neck, the hollows above her collarbones and the tops of her shoulders carry the same real living skin as her face: visible pores and fine skin grain, a soft sheen of natural skin oils on the highest planes, faint fine peach-fuzz hairs catching the rim light along the neck and shoulder line, gentle tonal variation with a natural warm flush at the base of the neck and across the collarbones, and the fine natural creases of a real neck — never airbrushed, never smooth like plastic.")
C.update(CARE2=CARE2, DEPTH=DEPTH, REAL_FACE=REAL_FACE, SKIN_B=SKIN_B)
JQ = {1: "a single piece", 2: "two to three pieces", 3: "four to six pieces, layered", 4: "seven to ten pieces, heavily stacked", 5: "well over ten pieces, an extreme maximalist stack"}
JMET = {"JMG": "gold", "JMS": "silver", "JMR": "rose-gold", "JMP": "platinum", "JMX": "mixed-metal"}
C.update(JQ=JQ, JMET=JMET)
TRACKS = r'''
def metal_phrase(M): return "mixed metal (yellow gold, silver, copper and rose gold, alternating piece by piece)" if M == "MX" else ("rose gold" if M == "MR" else MN[M].replace("-", " "))
def text_conc_face(P, M, F):
    m = MN[M]; e = ear_noun(F)
    if P == "P8":
        return (f"All eight piercings gather on the left side of her face, and the right side stays bare: on the left ear five pieces — a big {m} {e} in the lobe, two smaller {m} rings above it, a thick {m} bar and a small {m} stud at the top; two thin {m} bars pass through the outer end of the left eyebrow; a small {m} ring passes through the left nostril.")
    return (f"All twenty-five piercings gather mostly on the left side of her face, and the right side stays almost bare: on the left ear eight pieces — a big {m} {e} in the lobe, three smaller {m} rings above it, two thick {m} bars and two small {m} studs up to the top; one small {m} stud sits in the right ear; four thin {m} bars pass through the outer half of the left eyebrow; two small {m} rings pass through the left nostril and a thick {m} septum ring hangs below the nose; "
            f"a {m} hoop passes through the left edge of the lower lip with a {m} snake-bite ring beside it and a small {m} ring at the left edge of the upper lip; a {m} Medusa stud sits above the lips; a {m} labret stud and a small {m} ring sit on the chin; three small {m} studs run along the left jaw.")
def p200_face(M):
    t = g18.T150.replace("about one hundred and fifty", "about two hundred").replace("covering the face and neck", "covering the face, neck and shoulders").replace("ten fine gold chains", "twelve fine gold chains")
    t = t.replace("; and twelve fine", "; a row of six small gold studs along each collarbone; and twelve fine"); assert "collarbone" in t
    return recolor(t, M)
def face_pierce(P, M, F):
    if P in ("P3", "P5", "P15"): return pierce_text(P, M, F)
    if P in ("P8", "P25"): return text_conc_face(P, M, F)
    if P == "P200": return p200_face(M)
    return recolor({"P50": g18.T50, "P100": g18.T100, "P150": g18.T150}[P], M)
def pierce_of(P, M, F):
    if P in ("P8", "P25"): return conc_chest(P, M, F)
    return recolor({"P50": g18.T50, "P100": g18.T100}[P], M)
def hair_str():
    si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC)+1); return f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}", ci, si
FACE_FRAME = "framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp."
BLACKTONES = {"블루블랙": "THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky", "에보니 브라운": "DEEP EBONY BROWN SKIN, a rich dark complexion with warm brown undertones", "올리브": "WARM OLIVE SKIN, a smooth golden-olive complexion", "포셀린": "FLAWLESS PORCELAIN PALE SKIN, a luminous fair complexion with a cool rosy undertone", "알라바스터": "ALABASTER SNOW-WHITE SKIN, an extremely pale, almost translucent Nordic complexion with a cool pink undertone"}
MATKO2 = {"irezumi": "이레즈미", "glass": "스테인드글라스"}
def jewel_text(q, jm):
    m = JMET[jm]; return f"Jewelry: besides the piercings she wears {JQ[q]} of {m} necklaces and chains resting on her neck and collarbones, and {JQ[q]} of {m} hair ornaments set in her hair, all of it real, without covering her eyes, her face or her piercings."
def maximalist(frame, P, tone, matkey, jew):
    method = "집중형" if P in ("P8", "P25") else "정의형"
    hair, ci, si = hair_str(); pn, pd = rnd.choice(PHYS); age = rnd.choice(AGES_MX); M = rnd.choice(["MG", "MS", "MX", "MR", "MC", "MBZ"]); F = rnd.choice(FORMS); G = rnd.choice(GEMS)
    pierce = (face_pierce if frame == "face" else pierce_of)(P, M, F); dense = P in ("P100", "P150", "P200")
    skin = f"{BLACKTONES[tone]}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair}"
    sub = f"Subject: A real photograph of a striking adult woman — {skin}. Real pores and fine skin grain on her skin, a soft sheen of natural oils, large eyes with bright real catchlights, full lips, a bold, commanding expression — a photograph of a real face, not an illustration, not a render. {REAL_FACE.split('— ')[0]}"
    if frame == "face": pre = f"Professional fashion photograph, close-up beauty portrait. ONE woman, facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face, {FACE_FRAME} Mid 20s."
    elif frame == "chest": pre = "Professional fashion photograph, bust shot. ONE woman, facing the camera straight on, her head level, both ears clearly visible on either side of her face, framed from the very top of her head to just below her chest, the frame cutting off beneath the chest. Her face sits large and sharp in the upper half of the frame, and her ear pieces are oversized so they read clearly at this distance. Mid 20s."
    else: pre = "Professional fashion photograph, waist shot. ONE woman, facing the camera straight on, her head level, both ears clearly visible on either side of her face, framed from the very top of her head down to just below her navel, the frame cutting off across her lower belly. Her face sits in the upper part of the frame, large enough to read every piercing, and her ear pieces are oversized so they read clearly at this distance. Mid 20s."
    body = ""; mname = "얼굴만"
    if frame != "face":
        text = mat_text(matkey)[0]; mname = MATKO2[matkey]
        body = f"\n\nBody: Below the collarbones her whole body is fused with one material instead of ordinary skin: {text}, covering every inch from the collarbones to the bottom of the frame without exception, the material reading as one continuous second skin with no gaps, nowhere on her body left bare, no fabric no seam no garment anywhere. Real skin on the face, ears and neck ends cleanly at the base of the neck and across both collarbones, and everything below it is the body treatment described above."
    jt = ("\n\n" + jewel_text(*jew)) if jew else ""
    p = (f"{pre}\n\n{sub}\n\nPiercings: {pierce}{DENS if dense else ''}{gem_text(G)} {CARE2.format(metal=metal_phrase(M))}\n\n{DEPTH}{jt}{body}\n\n"
         f"Lighting: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. A soft frontal light on her face and ears, so the glints on every piece of metal read clearly against her skin; a thin cool rim light along the hair and shoulders. 2:3 vertical 8K portrait.")
    return p, f"맥시멀리스트 · 피부톤 {tone} · 재질 {mname} · 체형 {pn} · 금속 {MKO[M]}" + (f" · 쥬얼리 JQ{jew[0]}" if jew else ""), M
def pregnant_waist(P):
    method = "집중형" if P in ("P8", "P25") else "정의형"
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); hair, ci, si = hair_str(); M = pick_metal(ci); G = rnd.choice(GEMS); F = rnd.choice(FORMS); bk = rnd.choice(STABLE_BODIES); craft = rnd.choice(T.CRAFTS_39); ctext, cname = craft_text(craft)
    body = ALL_PREG[bk].replace("a high, smoothly rounded pregnant belly", f"a high, smoothly rounded pregnant belly, {BELLY_BOOST},", 1)
    pose = "standing tall, one hand cradling the underside of her belly and the other relaxed at her side, head level toward the camera"
    pierce = (conc_chest(P, M, F) if method == "집중형" else recolor({"P50": g18.T50, "P100": g18.T100}[P], M)); dense = P == "P100"
    paint = (f"Below the collarbones her whole body is painted in one traditional pattern: {ctext}, covering every inch of skin from the collarbones to the bottom of the frame without exception, the pattern reading as one continuous second skin with no gaps. The bands of the pattern curve fully around her belly like contour lines circling a globe, the rounded surface of her belly staying fully covered, with the same density continuing in full strength over her bust, nowhere on her body left bare, no fabric no seam no garment anywhere.")
    p = (f"Professional fashion photograph, waist shot. ONE woman, facing the camera straight on, her head level, both ears clearly visible on either side of her face, framed from the very top of her head down to just below her pregnant belly, the frame cutting off beneath the belly. Her face sits in the upper part of the frame, large enough to read every piercing, and her ear pieces are oversized so they read clearly at this distance. Mid 20s.\n\n"
         f"Subject: A real photograph of a strikingly beautiful adult {nat} woman — {fa}, {hair}. {REAL_FACE} {SKIN_B}\n\n"
         f"Piercings: {pierce}{DENS if dense else ''}{gem_text(G) if method == '집중형' else ''} {CARE2.format(metal=metal_phrase(M))}\n\n{DEPTH}\n\n"
         f"Physique: extraordinarily large pregnant physique far beyond any real person — {body}\n\nBody: {paint} Real skin on the face, ears and neck ends cleanly at the base of the neck and across both collarbones, and everything below it is the body treatment described above.\n\n"
         f"Pose: {pose}.\n\nLighting: a plain seamless deep-charcoal backdrop, nothing else in frame. A soft frontal light on her face and ears, so the makeup and the glints on every piece of metal read clearly; a thin cool rim light along the hair and shoulders. 2:3 vertical 8K portrait.")
    return p, f"임산부 · 공예 {cname} · 체형 {bk} · 메이크업 {mk} · 금속 {MKO[M]}", M
def general_face(P):
    a = M_face_attrs(); M = a["M"]; F = a["F"]
    method = "집중형" if P in ("P8", "P25") else "정의형"
    pierce = face_pierce(P, M, F) + (DENS if P in ("P100", "P150", "P200") else "")
    p = M_assemble(a, pierce)
    assert "\n\nLighting:" in p; p = p.replace("\n\nLighting:", "\n\n" + DEPTH + "\n\nLighting:", 1)
    return p, f"일반 · {re.sub(r'^[A-Z]+', '', HS[a['si']-1])} · {re.sub(r'^[A-Z]+', '', HC[a['ci']-1])} · 메이크업 {a['mk']} · 금속 {MKO[M]}·보석 {GKO[a['G']]}", M
'''
exec(TRACKS, C)
C["M_face_attrs"] = M_["face_attrs"]; C["M_assemble"] = M_["assemble"]
C["pierce_text"] = M_["pierce_text"]; C["ear_noun"] = M_["ear_noun"]
# 얼굴 컷 일반의 DENS는 NS_METH가 아니라 C의 DENS를 쓴다
P_ALL = ["P3", "P5", "P8", "P15", "P25", "P50", "P100", "P150", "P200"]
def dd_check(p, tag):
    p = C["dd"](p).replace(",,", ",").replace(".,", ",")
    _d = [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", p)]
    assert not re.search(r"[가-힣]", p) and not _d, (tag, _d)
    low = p.lower(); assert "overhead" not in low, tag
    return p
MKEY = {"mat": "재질", "craft": "공예"}
def solo(track, frame, P, idx, extra):
    method = "집중형" if P in ("P8", "P25") else "정의형"
    if track == "일반" and frame == "face": p, d, M = C["general_face"](P); sd = "얼굴만"
    elif track == "일반" and frame == "chest":
        kind, n = extra; p, d, bl = C["build"](P, method, kind, n); sd = bl
        assert "\n\nPhysique:" in p; p = p.replace("\n\nPhysique:", "\n\n" + DEPTH + "\n\nPhysique:", 1)
    elif track == "일반" and frame == "waist":
        kind, n, navel = extra; p, d, bl = C["build_waist"](P, method, kind, n, navel); sd = bl
        assert "\n\nPhysique:" in p; p = p.replace("\n\nPhysique:", "\n\n" + DEPTH + "\n\nPhysique:", 1)
    elif track == "임산부": p, d, M = C["pregnant_waist"](P); sd = "공예 단일"
    else:
        tone, matkey, jew = extra; p, d, M = C["maximalist"](frame, P, tone, matkey, jew); sd = ""
    p = dd_check(p, (track, frame, P))
    fko = {"face": "얼굴 컷", "chest": "가슴 컷", "waist": "허리 컷"}[frame]
    title = f"Piercing Frame Solo #{idx:03d} ({track} {fko} · {P} {method} · {d})"
    meta = {"group_size": 1, "aspect_ratio": "2:3", "format": "piercing-frame", "track": track, "frame": frame, "piercing": P}
    if track == "맥시멀리스트": meta["tone"] = extra[0]
    return title, p, meta
def cycle(lst, n): return [lst[i % len(lst)] for i in range(n)]
plan = []
for P in cycle(P_ALL, 30): plan.append(("일반", "face", P, None))
for P, kind, n in zip(cycle(["P8", "P25", "P50", "P100", "P150", "P200"], 30), cycle(["craft", "mat"], 30), [3 if q in ("P8","P25","P50","P100") and i % 3 else 1 for i, q in enumerate(cycle(["P8", "P25", "P50", "P100", "P150", "P200"], 30))]):
    plan.append(("일반", "chest", P, (kind, 1 if P in ("P150", "P200") else n)))
for i, P in enumerate(cycle(["P8", "P25", "P50", "P100"], 30)): plan.append(("일반", "waist", P, (["craft", "mat"][i % 2], 3 if i % 3 else 1, P != "P8")))
for P in cycle(["P25", "P50", "P100"], 50): plan.append(("임산부", "waist", P, None))
TONES = ["블루블랙", "에보니 브라운", "올리브", "포셀린", "알라바스터"]
for i in range(30):
    tone = TONES[i % 5]; P = R.choice(["P3", "P5", "P8", "P15", "P25", "P50"] if tone == "알라바스터" else P_ALL)
    jew = (R.randint(1, 5), R.choice(list(JMET))) if R.random() < 0.5 else None
    plan.append(("맥시멀리스트", "face", P, (tone, None, jew)))
for i in range(20): plan.append(("맥시멀리스트", "chest", ["P50", "P100"][i % 2], (TONES[i % 4], ["irezumi", "glass"][(i // 2) % 2], None)))
for i in range(20): plan.append(("맥시멀리스트", "waist", ["P25", "P50"][i % 2], (TONES[i % 4], ["irezumi", "glass"][(i // 2) % 2], None)))
R.shuffle(plan)
N_DUO, N_TRIO = (60, 30) if len(sys.argv) < 3 else (int(sys.argv[2]), int(sys.argv[3]))
if len(sys.argv) > 4: plan = plan[:int(sys.argv[4])]
items = []; seen = set(); fails = collections.Counter()
CAT = "🏺 Living Artifact · Piercing Frame Formula"
def add(key, t, p, m):
    assert p not in seen; seen.add(p); items.append({"key": key, "category": CAT, "title": t, "prompt": p, "meta": m})
n = 0
for track, frame, P, extra in plan:
    for attempt in range(8):
        try: t, p, m = solo(track, frame, P, n + 1, extra); break
        except (AssertionError, KeyError, ValueError) as e: fails[str(e)[:70]] += 1
    else: raise SystemExit(f"실패: {track} {frame} {P} {fails.most_common(3)}")
    n += 1; add(f"la_pframe_solo_{n:03d}", t, p, m)
def crop_group(kind, g, idx):
    if kind == "face_duo":
        frame = "face"; people = [("일반", R.choice(["P8", "P25", "P50", "P100"]), None, None) for _ in range(2)]
    elif kind == "chest_duo":
        frame = "chest"; people = [("일반", R.choice(["P25", "P50"]), None, "craft"), ("맥시", R.choice(["P50", "P100"]), None, R.choice(["irezumi", "glass"]))]
    else:
        frame = "chest"; people = [("일반", R.choice(["P25", "P50"]), None, "craft"), ("일반", "P50", None, R.choice(["irezumi", "craft"])), ("맥시", R.choice(["P50", "P100"]), None, R.choice(["irezumi", "glass"]))]
    people = [(tr, P, "집중형" if P in ("P8", "P25") else "정의형", bk) for tr, P, _, bk in people]
    p, d = GR["crop_group"](frame, people); p = dd_check(p, kind)
    nm = {2: "Duo", 3: "Trio"}[g]; fko = {"face": "얼굴 컷", "chest": "가슴 컷"}[frame]
    title = f"Piercing Frame {nm} #{idx:03d} ({fko} · {d})"
    return title, p, {"group_size": g, "aspect_ratio": {2: "3:4", 3: "4:5"}[g], "format": "piercing-frame", "track": "혼합" if frame == "chest" else "일반", "frame": frame, "piercing": "/".join(x[1] for x in people)}
for kind, g, cnt, tag in (("face_duo", 2, N_DUO // 3, "duo"), ("chest_duo", 2, N_DUO - N_DUO // 3, "duo"), ("chest_trio", 3, N_TRIO, "trio")):
    base = len([i for i in items if i["key"].startswith(f"la_pframe_{tag}_")])
    for j in range(cnt):
        for attempt in range(8):
            try: t, p, m = crop_group(kind, g, base + j + 1); break
            except (AssertionError, KeyError, ValueError) as e: fails[str(e)[:70]] += 1
        else: raise SystemExit(f"그룹 실패 {kind} {fails.most_common(3)}")
        add(f"la_pframe_{tag}_{base+j+1:03d}", t, p, m)
out = "/tmp/la_pframe_geo_bundle.json" if len(sys.argv) > 4 else "/mnt/user-data/outputs/la_pframe_geo_300_bundle.json"
json.dump(items, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
wc = [len(x["prompt"].split()) for x in items]
print("저장:", out, "| 항목:", len(items), "| 재시도 사유:", dict(fails.most_common(4)))
print("단어 수 min/avg/max:", min(wc), sum(wc)//len(wc), max(wc))
print("트랙/프레임:", sorted(collections.Counter((x["meta"]["track"], x["meta"]["frame"], x["meta"]["group_size"]) for x in items).items()))
print("단계(솔로):", sorted(collections.Counter(x["meta"]["piercing"] for x in items if x["meta"]["group_size"] == 1).items()))
