# -*- coding: utf-8 -*-
import re, sys, os, random, json, collections
os.chdir('/home/claude/glassface'); sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
def load(path):
    ns = {"__name__": "ns"}; exec(open(path, encoding="utf-8").read().split("\nspecs = [")[0], ns); return ns
S = load('gen_pierce_statue.py'); X = load('gen_pierce_mixstatue2.py'); Y = load('gen_pierce_torsosplit.py'); GR = load('gen_pierce_group.py')
DARK = [("ebony", "deep black ebony wood, densely fine-grained, polished to a hard, glass-like satin sheen, completely opaque"),
        ("wenge", "dark wenge wood, a deep near-black wood finely striped with narrow gold-tan pinstripes running through it, polished to a hard satin sheen, completely opaque"),
        ("purpleheart", "deep violet purpleheart wood, a dense hardwood of rich purple with fine straight grain, polished to a hard satin sheen, completely opaque")]
for ns in (S, X, Y, GR): ns["WOODS"][:] = DARK
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 20261210
for k, ns in enumerate((S, X, Y, GR)): ns["rnd"].seed(SEED + k)
R = random.Random(SEED + 99)
FRKO = {"hip": "힙컷", "demi": "데미스탯", "tq": "쓰리쿼터"}
# ----- 공통 문장 -----
ANCH = "not cel-shaded.\n\nPiercings:"
COMMON = ("visible pores and fine skin grain, a soft sheen of natural skin oils on the highest planes, faint fine peach-fuzz hairs catching the rim light, gentle tonal variation with a natural warm flush, and the fine natural creases of a real neck — never airbrushed, never smooth like plastic. ")
SKIN = {"up": "Her neck carries the same real living skin as her face: " + COMMON + "Like any real person she is slightly asymmetrical: a few small natural beauty marks and freckles scattered unevenly, one side of her neck very slightly warmer and more freckled than the other.",
        "cur": "Her neck, the hollows above her collarbones and the tops of her shoulders carry the same real living skin as her face: " + COMMON + "Like any real person she is slightly asymmetrical: a few small natural beauty marks and freckles scattered unevenly, one side of her neck and shoulder very slightly warmer and more freckled than the other.",
        "low": "Her neck, collarbones, shoulders and the upper chest above the line carry the same real living skin as her face: " + COMMON + "Like any real person she is slightly asymmetrical: a few small natural beauty marks and freckles scattered unevenly, one side of her neck and shoulder very slightly warmer and more freckled than the other."}
BASE_BODY = "From the collarbones down, her whole body — shoulders, arms, hands,"
B_OLD = "a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below."
def rep(p, a, b):
    assert a in p, a[:70]; return p.replace(a, b)
def boundary_variant(p, pos):
    p = rep(p, ANCH, "not cel-shaded. " + SKIN[pos] + "\n\nPiercings:")
    if pos == "cur": return p
    if pos == "up":
        p = rep(p, BASE_BODY, "From the base of the neck down, her whole body — shoulders, arms, hands,")
        p = rep(p, "everything below the collarbones", "everything below her neck")
        p = rep(p, B_OLD, "a sharp jagged line runs around the base of the neck, just above the collarbones — real skin above it (only her face and neck), material immediately below, the collarbones and shoulders already part of the material.")
        return rep(p, "Shards interlock along the collarbone line only.", "Shards interlock along the neck line only.")
    p = rep(p, BASE_BODY, "Below the V-shaped line described in the boundary, her whole body — both arms from the shoulder joint down, hands,")
    p = rep(p, "everything below the collarbones", "everything below that V-shaped line")
    p = rep(p, "while her real face, ears and neck are", "while her real face, ears, neck, collarbones, shoulders and upper chest are")
    p = rep(p, B_OLD, "a sharp jagged line runs from under each arm up across the front of each shoulder and dips in a shallow V to the centre of her upper chest — real skin above it (her face, neck, collarbones, shoulders and upper chest), material immediately below.")
    p = rep(p, "Shards interlock along the collarbone line only.", "Shards interlock along that V-shaped line only.")
    return rep(p, "Only her face, ears and neck read as real skin.", "Only her face, ears, neck, shoulders and upper chest read as real skin.")
POSE_RE = re.compile(r"Pose: standing tall,.*?toward the camera\.", re.S)
EAR_POSE = "Pose: standing tall, body angled 45 degrees, her left hand resting on her flared hip, her right hand gently tucking a lock of hair back behind her right ear so the ear and its piercings show clearly, head tilted slightly toward the camera."
JQ = {1: "a single piece", 2: "two to three pieces", 3: "four to six pieces, layered", 4: "seven to ten pieces, heavily stacked", 5: "well over ten pieces, an extreme maximalist stack"}
JMET = {"JMG": "gold", "JMS": "silver", "JMR": "rose-gold", "JMP": "platinum", "JMX": "mixed-metal"}
def jewelry(types, q, jm):
    m = JMET[jm]; parts = []
    for t in types:
        if t == "N": parts.append(f"{JQ[q]} of {m} necklaces and chains resting on her neck, collarbones and upper chest")
        if t == "B": parts.append(f"{JQ[q]} of {m} bracelets and bangles on both wrists")
        if t == "R": parts.append(f"{JQ[q]} of {m} rings on her fingers")
        if t == "H": parts.append(f"{JQ[q]} of {m} hair ornaments set in her hair")
    return "Jewelry: besides the piercings she wears " + "; ".join(parts) + ", all of it real, sitting on and over the material of her body and her real neck and hair without covering her eyes, her face or her piercings."
JKO = {"N": "목걸이", "B": "팔찌", "R": "반지", "H": "헤어 장식"}
CLEAR_KEYS = list(S["HIGHCLEAR"]); T2_KEYS = list(S["CONTENTS"]); T3_MK = ["sapphire", "cobalt", "amethyst", "citrine"]; T3_OK = list(S["OBJECTS"])
def pick_single(frame):
    kinds = ["T1", "T2", "T3"] if frame == "hip" else ["T1", "T2", "T3", "stone", "wood", "T1", "stone", "wood"]
    k = R.choice(kinds)
    if k == "T1": return k, R.choice(CLEAR_KEYS)
    if k == "T2": return k, R.choice(T2_KEYS)
    if k == "T3": return k, (R.choice(T3_MK), R.choice(T3_OK))
    return k, R.randrange(4 if k == "stone" else 3)
KIND_KO = {"stone": "석재", "wood": "목재", "T1": "단일 투명", "T2": "수조", "T3": "내용물 투명"}
PLEV = {"hip": ["P25", "P50", "P100", "P150", "P200"], "demi": ["P8", "P25", "P50", "P100", "P150"], "tq": ["P8", "P25", "P50", "P100"]}
def phys_tag(p):
    m = re.search(r"Physique: (.*?)\n", p); w = re.sub(r"^(A|An)\s+", "", m.group(1)).split()[:4]; return " ".join(w).strip(",—-")
def finish(p, jew, ear):
    if jew:
        types, q, jm = jew; assert "\n\nPhysique:" in p; p = p.replace("\n\nPhysique:", "\n\n" + jewelry(types, q, jm) + "\n\nPhysique:", 1)
    if ear: assert POSE_RE.search(p); p = POSE_RE.sub(EAR_POSE, p, count=1)
    p = S["dd"](p).replace(",,", ",").replace(".,", ",")
    _d = [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", p)]
    assert not re.search(r"[가-힣]", p) and not _d, _d
    return p
def solo(frame, structure, P, idx):
    method = "집중형" if P in ("P8", "P25") else "정의형"
    if structure == "single":
        kind, key = pick_single(frame); P2 = P if P in ("P8", "P25", "P50", "P100") else "P100"
        p, d, mname = S["build"](frame, P2, method if P2 in ("P8", "P25") else "정의형", kind, key); P = P2
        pos = R.choice(["up", "cur", "low"]) if kind in ("T1", "stone", "wood") else "cur"
        p = boundary_variant(p, pos); sdesc = f"{KIND_KO[kind]}({mname}) · 경계 {dict(up='쇄골 위', cur='쇄골선', low='겨드랑이 V자')[pos]}"; meta_struct = "single"
    elif structure == "mix5":
        p, d, pk = X["build"](frame, P, method); p = boundary_variant(p, "cur"); sdesc = f"5재질 혼합 · {pk}"; meta_struct = "mix5"
    else:
        orient = R.choice(["H", "V", "D"]); p, d, pk = Y["build"](frame, P, method, orient); p = boundary_variant(p, "cur"); sdesc = f"몸통 3조각 · {pk}"; meta_struct = "split3"
    jew = None
    if R.random() < 0.6:
        types = R.sample(["N", "B", "R", "H"], R.choice([2, 3, 4])); jew = (types, R.randint(1, 5), R.choice(list(JMET)))
    ear = R.random() < 0.2
    p = finish(p, jew, ear)
    jko = ("쥬얼리 " + "·".join(JKO[t] for t in jew[0]) + f" JQ{jew[1]}") if jew else "쥬얼리 없음"
    title = f"Piercing Statue Solo #{idx:03d} ({FRKO[frame]} · {P} {method} · {sdesc} · 체형 {phys_tag(p)} · {d} · {jko}{' · 귀 보이기' if ear else ''})"
    meta = {"group_size": 1, "aspect_ratio": "2:3", "format": "piercing-statue", "frame": frame, "piercing": P, "structure": meta_struct, "jewelry": bool(jew), "pose": "ear" if ear else "stand"}
    return title, p, meta
def group(g, idx):
    frame = R.choice(["demi", "tq"]); people = []
    for _ in range(g):
        P = R.choice(["P8", "P25", "P50"]); method = "집중형" if P in ("P8", "P25") else "정의형"
        kind, key = pick_single(frame); people.append((P, method, kind, key))
    p, d = GR["stat_group"](frame, people)
    p = S["dd"](p).replace(",,", ",").replace(".,", ",")
    _d = [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", p)]; assert not re.search(r"[가-힣]", p) and not _d, _d
    nm = {2: "Duo", 3: "Trio"}[g]
    title = f"Piercing Statue {nm} #{idx:03d} ({FRKO[frame]} · {d})"
    meta = {"group_size": g, "aspect_ratio": {2: "3:4", 3: "4:5"}[g], "format": "piercing-statue", "frame": frame, "piercing": "/".join(x[0] for x in people), "structure": "single-each", "jewelry": False, "pose": "stand"}
    return title, p, meta
# ----- 배정 -----
plan = []
for structure in ("single", "mix5", "split3"):
    alloc = {"single": {"hip": 20, "demi": 25, "tq": 25}, "mix5": {"hip": 20, "demi": 25, "tq": 25}, "split3": {"hip": 20, "demi": 30, "tq": 20}}[structure]
    for frame, n in alloc.items():
        lv = PLEV[frame]
        for i in range(n): plan.append(("solo", frame, structure, lv[i % len(lv)]))
R.shuffle(plan)
N_DUO, N_TRIO = (60, 30) if len(sys.argv) < 3 else (int(sys.argv[2]), int(sys.argv[3]))
if len(sys.argv) > 4: plan = plan[:int(sys.argv[4])]
items = []; seen = set(); fails = collections.Counter()
def add(key, cat, t, p, m):
    assert p not in seen; seen.add(p); items.append({"key": key, "category": cat, "title": t, "prompt": p, "meta": m})
CAT = "🏺 Living Artifact · Piercing Statue Formula"
n = 0
for kind, frame, structure, P in plan:
    for attempt in range(6):
        try: t, p, m = solo(frame, structure, P, n + 1); break
        except (AssertionError, KeyError) as e: fails[str(e)[:60]] += 1
    else: raise SystemExit(f"실패: {frame} {structure} {P} {fails.most_common(3)}")
    n += 1; add(f"la_pstatue_solo_{n:03d}", CAT, t, p, m)
for g, cnt, tag in ((2, N_DUO, "duo"), (3, N_TRIO, "trio")):
    for j in range(cnt):
        for attempt in range(6):
            try: t, p, m = group(g, j + 1); break
            except (AssertionError, KeyError) as e: fails[str(e)[:60]] += 1
        else: raise SystemExit(f"그룹 실패 {g} {fails.most_common(3)}")
        add(f"la_pstatue_{tag}_{j+1:03d}", CAT, t, p, m)
out = "/tmp/la_pstatue_geo_bundle.json" if len(sys.argv) > 4 else "/mnt/user-data/outputs/la_pstatue_geo_300_bundle.json"
json.dump(items, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
wc = [len(x["prompt"].split()) for x in items]
print("저장:", out, "| 항목:", len(items), "| 재시도 사유:", dict(fails))
print("단어 수 min/avg/max:", min(wc), sum(wc)//len(wc), max(wc))
print("구조:", collections.Counter(x["meta"]["structure"] for x in items), "| 프레임:", collections.Counter(x["meta"]["frame"] for x in items))
print("단계:", sorted(collections.Counter(x["meta"]["piercing"] for x in items if x["meta"]["group_size"] == 1).items()))
print("쥬얼리:", sum(x["meta"]["jewelry"] for x in items), "| 귀 포즈:", sum(x["meta"]["pose"] == "ear" for x in items))
