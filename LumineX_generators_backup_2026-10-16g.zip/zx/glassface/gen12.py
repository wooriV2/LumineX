# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g3 = load("g3","gen3.py"); g11 = load("g11","gen11.py")

DENS = " The piercings are packed so densely that the rows touch and overlap, leaving only hairline gaps of bare skin between them, until the face reads as a single armour of metal; the eyes and eyelids stay clear."
CARE = "All jewelry is real {metal}, sitting in real skin that is healed, clean and calm — no blood, no redness, no swelling, no wound — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes."

def clean(txt):
    # 투명 재질 버전의 잔여 문구 제거(피어싱 문장은 그대로 사용)
    return txt.replace(" hairline gaps of bare material", " hairline gaps of bare skin")

METAL = {
 "P3":"yellow gold","P5":"rose gold","P9":"polished copper","P18":"antique brass with a few neon-acrylic accents",
 "P50":"silver","P100":"bronze with a few turquoise-enamel rings","P150":"mixed metal (yellow gold, silver, copper, rose gold and black steel, alternating piece by piece) with a few pearl studs",
}
LABEL = {"P3":"금","P5":"로즈골드","P9":"동(구리)","P18":"황동 + 네온 아크릴","P50":"은","P100":"청동 + 터키석색 에나멜","P150":"혼합 금속 + 진주"}
PTS = {"P3":"2~4","P5":"4~5","P9":"9","P18":"18","P50":"약 50","P100":"약 100","P150":"약 150"}

OUT = []
for tier, sty, a, b, pierce, lipp, metal_ko, dense in g11.SPEC:
    nat, mk, face = g3.face_of(sty)
    pierce = pierce.replace(g11.DENS, "")   # 밀도 문장은 실사용으로 다시 붙임
    pierce = clean(pierce)
    p = f"""Professional fashion photograph, close-up beauty portrait. ONE woman, her face turned about 30 degrees toward the camera, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {face}. Real pores and fine skin grain, real living eyes with bright catchlights and genuine depth, individual hair strands catching the light — a photograph of a real face, not an illustration, not a render, not cel-shaded.

Piercings: {pierce}{DENS if dense else ''} {CARE.format(metal=METAL[tier])}

Lighting: a soft frontal beauty light on the face with a thin cool rim light along the hair, pure pitch black void background, shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait."""
    OUT.append((tier, sty, LABEL[tier], p))

if __name__ == "__main__":
    for t, s, l, p in OUT:
        print(t, s, l, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
