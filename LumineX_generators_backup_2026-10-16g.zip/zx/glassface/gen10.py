# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re, copy
spec = importlib.util.spec_from_file_location("g9","gen9.py"); g9 = importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(io.StringIO()):
    spec.loader.exec_module(g9)
g = g9.g; OLD = g9.OLD; NEW = g9.NEW

P150 = ("An extreme, overwhelming armour of about one hundred and fifty real metal piercings covering the face and neck: a thick black-steel septum ring with a smaller ring above it, three black-steel rings through each nostril and a small stud at the tip of the nose; two straight black-steel bars across the bridge of the nose between the brows; "
 "six thick black-steel bars stacked through the outer half of each eyebrow; three rows of five small black-steel studs across the forehead above the brows; six small studs up each temple on the bone, well clear of the eyes; two rows of six small studs along each cheekbone; a black-steel Medusa stud above the lips with a small stud on each side of it; "
 "a big black-steel hoop, four smaller rings and a snake-bite ring on each side through the lower lip's edge, and six small hoops along the upper lip's edge; a black-steel labret stud and five rings through the chin; six small studs along each jaw; a column of five small studs down each side of the neck; "
 "on each ear a full dense row of twelve big hoops, thick bars, stretched plugs, helix rings and studs from lobe to top; and ten fine black-steel chains looping from the ear hoops to the nostril rings and the septum ring.")
r = copy.deepcopy(g.ROWS[6]); r["tier"] = "P150"; r["pierce"] = P150
_, an, bn, p = g.build(r)
assert OLD in p
p = p.replace(OLD, NEW)
print(len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
