# -*- coding: utf-8 -*-
exec(open('gen_tests_batch.py', encoding='utf-8').read().split("# ================= A.")[0])
for k, ns in enumerate((S, X, C)): ns["rnd"].seed(20261230 + k)
R = random.Random(20261331)
dd = S["dd"]
def strip_solid(t): return re.sub(r"^solid\s+", "", t)
LEG_A = " (no shins, no ankles and no real skin legs of any kind — below each rounded tip there is only the glossy floor)"
LEG_B = LEG_A + " Every part of both legs belongs to the sculpture and is made entirely of its material: not a single part of her legs is real skin."
FLOOR_OLD = "and a glossy dark floor beneath her."
FLOOR_B = "and a glossy dark floor, visible directly beneath each rounded leg tip with nothing in between."
def reinforce(p, level, kind):
    anchor = "nothing continues below either tip" if kind == "single" else "both rounded tips resting side by side on the surface beneath her."
    assert anchor in p, anchor
    if kind == "single":
        p = p.replace(anchor, anchor + LEG_A, 1)
        if level == "B":
            end = "both rounded tips resting side by side on the surface beneath her."; assert end in p
            p = p.replace(end, end + " Every part of both legs belongs to the sculpture and is made entirely of its material: not a single part of her legs is real skin.", 1)
    else: p = p.replace(anchor, anchor + (LEG_A if level == "A" else LEG_B).replace(" (", " Below each rounded tip there is nothing at all — ", 1).replace(")", ";", 1) if False else anchor + " Below each rounded tip there is nothing at all — no shins, no ankles, no feet and no real skin legs; only the glossy floor." + ("" if level == "A" else " Every part of both legs belongs to the sculpture and is made entirely of its materials: not a single part of her legs is real skin."), 1)
    if level == "B": assert FLOOR_OLD in p; p = p.replace(FLOOR_OLD, FLOOR_B, 1)
    return p
items = []
# --- 쓰리쿼터: 인어 비늘 단일 (A 약 / B 강)
for lvl in ("A", "B"):
    txt = strip_solid(C["mat_text"]("scale_mermaid")[0])
    S["STONES"][:] = [("scale mermaid", txt)]
    p, d, mname = S["build"]("tq", "P50", "정의형", "stone", 0)
    assert "one solid opaque stone, solid " in p; p = p.replace("one solid opaque stone, solid ", "one solid opaque sculpted mass, solid ", 1)
    p = add_skin(p); p = reinforce(p, lvl, "single"); p = dd_check(p, ("mermaid", lvl), dd)
    items.append((f"쓰리쿼터 · 인어 비늘 단일 · P50 · 보강 {'약(A)' if lvl == 'A' else '강(B)'}", p))
# --- 쓰리쿼터: 5재질 혼합 P150 (A 약 / B 강)
for lvl in ("A", "B"):
    p, d, pk = X["build"]("tq", "P150", "정의형"); p = add_skin(p); p = reinforce(p, lvl, "mix"); p = dd_check(p, ("tqmix", lvl), dd)
    items.append((f"쓰리쿼터 · 5재질 혼합 · P150 · 보강 {'약(A)' if lvl == 'A' else '강(B)'}", p))
# --- 흑요암 이음새 (V1 강화 / V2 더 강화), 데미스탯
OBS = {"V1": "polished black obsidian stone carved as a mosaic of many large fitted sections, divided by wide, bright molten-gold seams about the width of a finger running between every section, a dense network of gold lines covering her whole body from the collarbones to the thigh tips",
       "V2": "polished black obsidian stone carved as a mosaic of many large fitted sections, divided by wide, bright molten-gold seams about the width of a finger running between every section, a dense network of gold lines covering her whole body from the collarbones to the thigh tips; the gold seams glow and catch the light as strongly as the black stone does, so the gold reads clearly from far away and makes up about one fifth of the whole body's surface"}
for v in ("V1", "V2"):
    S["STONES"][:] = [("obsidian gold", OBS[v])]
    p, d, mname = S["build"]("demi", "P50", "정의형", "stone", 0)
    assert "one solid opaque stone, solid " in p; p = p.replace("one solid opaque stone, solid ", "one solid opaque sculpted mass, solid ", 1)
    p = add_skin(p); p = dd_check(p, ("obsidian", v), dd)
    items.append((f"데미스탯 · 흑요암+금빛 이음새 · P50 · 이음새 강화 {'1단계' if v == 'V1' else '2단계'}", p))
ent = shuffled(items, 41)
write_md("LumineX_Test_TqObsidianFix.md", "LumineX · 쓰리쿼터 맨살 다리 보강 + 흑요암 금빛 이음새 강화 시험 (6개)",
         "**쓰리쿼터 4개**는 맨살 다리가 나왔던 두 경우(인어 비늘 단일, 5재질 혼합 P150)를 **약한 보강(A)**과 **강한 보강(B)**으로 나눴습니다. A는 \"다리 끝 아래에는 정강이·발목·발·맨살 다리가 전혀 없고 바닥만 있다\"는 문장을 더했고, B는 A에 \"다리 전체가 조각 재질이고 맨살이 한 곳도 없다\"는 문장과 \"바닥이 다리 끝 바로 아래에 보인다\"는 배경 문장을 더했습니다. **흑요암 2개**(데미스탯)는 금빛 이음새를 \"손가락 폭의 밝은 금빛 이음새가 모든 조각 사이를 지나 몸 전체에 촘촘한 망을 이룬다\"(1단계)와 \"금빛이 검은 돌만큼 강하게 빛나 멀리서도 읽히고 몸 표면의 약 5분의 1을 차지한다\"(2단계)로 강화했습니다. 번호는 섞여 있습니다.",
         "**알려주실 것**: 번호마다 **성공/실패**. 실패하면 이유 한마디(**맨살 다리 나옴 / 금빛 이음새가 여전히 적음 / 생성 안 됨**). 최대 3회. 예: `1: 성공 / 3: 실패(맨살 다리 나옴)`", None, ent)
print(open("/mnt/user-data/outputs/LumineX_Test_TqObsidianFix.md", encoding="utf-8").read().count("\n## 0"), "개 | 색인:")
for no, d, _ in ent: print(" ", no, d)
