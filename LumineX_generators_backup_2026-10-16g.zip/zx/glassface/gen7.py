# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re, copy
spec = importlib.util.spec_from_file_location("g5","gen5.py"); g = importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(io.StringIO()):
    spec.loader.exec_module(g)

OLD = "All jewelry is real opaque metal, pearl, enamel or acrylic, passing through drilled openings in the carved material (through real flesh for the lips), never turning into the material, and kept clear of the eyeballs."
NEW = "All jewelry is real opaque metal, pearl, enamel or acrylic, passing through drilled openings in the carved material (through real flesh for the lips), never turning into the material. Brow bars stay on the brow bone, all kept clear of the eyeballs. Piercings on the centre line hang across the jagged line and stay bright real metal on both halves."

V = copy.deepcopy(g.ROWS[6]); V["tier"] = "아주 많이"
V["pierce"] = ("A thick black-steel septum ring hangs below the nose, with a black-steel ring through each nostril; two thick black-steel bars pass through the outer half of each eyebrow; "
 "a black-steel Medusa stud sits above the lips; a big black-steel hoop passes through the lower lip's edge with a snake-bite ring on each side; a black-steel labret stud sits beneath the lower lip; "
 "on each ear a big black-steel hoop, a thick black-steel bar and a stretched black-steel plug.")
L = copy.deepcopy(g.ROWS[8]); L["tier"] = "아주 많이"
L["pierce"] = ("A thick silver septum ring hangs below the nose, with a silver ring through each nostril; two thick silver bars pass through the outer half of each eyebrow; "
 "a silver Medusa stud sits above the lips; a big silver hoop passes through the lower lip's edge with a snake-bite ring on each side; a silver labret stud sits beneath the lower lip; "
 "on each ear a big silver hoop, a thick silver bar and a stretched gold-rimmed plug.")

OUT = []
for r in (V, L):
    _, an, bn, p = g.build(r)
    assert OLD in p
    OUT.append((r, an, bn, p.replace(OLD, NEW)))

if __name__ == "__main__":
    for r, an, bn, p in OUT:
        print("###", r["ko"], an, bn, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
        print(p.split("Piercings:")[1].split("Lines:")[0])
