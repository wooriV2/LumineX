# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_pierce_statue.py', encoding='utf-8').read().split("\nspecs = [")[0])     # MAT·STONES·WOODS·OBJECTS·REAL_FACE·DEPTH·CARE2·FR·FRKO·PHYS·BACKS·HIGHCLEAR·conc_chest·recolor·g18·DENS ...
rnd.seed(20261114)
GLASS = "unmistakably glass: thick, crystal-clear and polished, bright specular reflections, sharp white highlights, tiny trapped bubbles"
WATER = ["turquoise", "pale rose-pink", "soft amber", "pale lilac", "sea-green"]
THIGH_WORLD = ["a scattered handful of pale pink cherry-blossom petals drifting slowly inside it, never crowding, mostly open clear water around each one",
               "a loose scatter of tiny warm glowing fireflies drifting slowly inside it, mostly open clear water around each one",
               "a few white lily blossoms floating slowly inside it, never crowding, mostly open clear water around each one"]
TXT = {"stone": "carved stone", "wood": "carved wood", "T1": "clear crystal", "T2": "a glass vessel full of water", "T3": "solid glass holding embedded objects"}
def part_text(part, kind, st):
    """part: 'Left arm' 등. 반환: (문장, 한글 라벨)"""
    arm = part.endswith("arm")
    end = "every wrist, palm, finger and knuckle the same material" if arm else None
    if kind == "stone":
        n, d = st["stone"]; s = f"carved from ONE solid block of {d}, completely opaque" + (", every wrist, palm, finger and knuckle the same stone" if arm else "") + ". No light passes through it — only reflections on its polished surface."
        return s, f"석재({n})"
    if kind == "wood":
        n, d = st["wood"]; s = f"carved from ONE solid block of {d}, completely opaque" + (", every wrist, palm, finger and knuckle the same wood" if arm else "") + ", the grain running unbroken through it. No light passes through it — only reflections on its polished surface."
        return s, f"목재({n})"
    if kind == "T1":
        k = st["T1"]; d, i = MAT[k][1], MAT[k][2]
        s = f"solid transparent material, solid {d}, with {i}, one continuous carved mass, never hollow" + (", every wrist, palm, finger and knuckle the same material" if arm else "") + ". Light passes straight through it; the backdrop is visibly bent inside it."
        return s, f"투명({MAT[k][0]})"
    if kind == "T2":
        if part == "Torso":
            s = f"a sculpted vessel of thick, crystal-clear glass ({GLASS}) in the exact shape of her torso, filled completely to the brim with plain, perfectly clear {st['water']} water — no hollow space and no air gap anywhere inside it; no fish, no plants, no objects, just clear water throughout. Light passes through; the backdrop is visibly bent inside it."
            return s, f"수조({st['water']} 물)"
        s = f"a sculpted vessel of the same clear glass ({GLASS}), completely filled to the brim with clear water holding {st['world']}. It curves inward and seals shut into its own smooth, rounded, closed tip, the water continuing unbroken down to that tip. Light passes through; the backdrop is visibly bent inside it."
        return s, "수조(내용물 물)"
    mk, ok = st["T3"]; d, i = MAT[mk][1], MAT[mk][2]
    s = f"carved from ONE solid block of {d}, with {i}, never hollow, never split; suspended deep within it, visible through it like objects frozen inside a single flawless crystal, are {OBJECTS[ok][1]}, each one fully embedded in the solid material with no cavity and no liquid around it. Light passes through the solid material; the backdrop is visibly bent inside it."
    return s, f"내용물({MAT[mk][0]}+{OBJECTS[ok][0]})"

def build(frame, P, method):
    pname, pos, part = FR[frame]; fk = FRKO[frame]
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC)+1)
    M = pick_metal(ci); G = rnd.choice(GEMS); F = rnd.choice(FORMS); phys = rnd.choice(PHYS); (ba, bb) = rnd.choice(BACKS)
    hair = f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}"
    def p200s(M):
        t = g18.T150.replace("about one hundred and fifty", "about two hundred").replace("covering the face and neck", "covering the face, neck and shoulders").replace("ten fine gold chains", "twelve fine gold chains")
        t = t.replace("; and twelve fine", "; a row of six small gold studs along each collarbone and a small gold stud on each shoulder; and twelve fine")
        assert "collarbone" in t; return recolor(t, M)
    pierce = conc_chest(P, M, F) if method == "집중형" else (p200s(M) if P == "P200" else recolor({"P50": g18.T50, "P100": g18.T100, "P150": g18.T150}[P], M))
    dense = P in ("P100", "P150", "P200")
    # 부위별 재질 배정: 팔은 석재·목재·단일투명 중, 나머지(몸통·허벅지 2)는 남은 3종
    arms = rnd.sample(["stone", "wood", "T1"], 2); rest = [t for t in ["stone", "wood", "T1", "T2", "T3"] if t not in arms]; rnd.shuffle(rest)
    assign = {"Left arm": arms[0], "Right arm": arms[1], "Torso": rest[0], "Left thigh": rest[1], "Right thigh": rest[2]}
    st = {"stone": rnd.choice(STONES), "wood": rnd.choice(WOODS), "T1": rnd.choice(HIGHCLEAR), "T3": (rnd.choice(["sapphire", "cobalt", "amethyst", "citrine"]), rnd.choice(list(OBJECTS))), "water": rnd.choice(WATER), "world": rnd.choice(THIGH_WORLD)}
    texts = {}; labels = {}
    for pt, kd in assign.items(): texts[pt], labels[pt] = part_text(pt, kd, st)
    leg_label = "thigh"
    tip_solid = "ends in its own smooth, deeply polished rounded tip, finished the way a carved sculpture is finished"
    summary = (f"her left arm {TXT[assign['Left arm']]}, her right arm {TXT[assign['Right arm']]}, her torso {TXT[assign['Torso']]}, her left thigh {TXT[assign['Left thigh']]} and her right thigh {TXT[assign['Right thigh']]}")
    phys2 = phys.rstrip(".") + f", {summary}."
    def leg(pt, side):
        extra = "" if assign[pt] == "T2" else f" The {side} thigh {tip_solid}."
        return f"{pt} (hip down to its tip, {pos}): {texts[pt]}{extra}"
    NECK = ("A single straight, horizontal line runs across her body at underarm height, level with both armpits. Real skin above this line — her face, neck, both shoulders, and the very tops of both upper arms. "
            "Below this line, five completely different materials meet at her body's natural joints (both shoulders, both hips), each keeping its own distinct appearance right up to where it touches its neighbour, never blending into it. "
            "At the underarm line itself, the material immediately below rises in a small raised step above her skin, casting a crisp shadow. Shards interlock along this line only.")
    opaque = [pt for pt, kd in assign.items() if kd in ("stone", "wood")]; clear = [pt for pt, kd in assign.items() if kd not in ("stone", "wood")]
    metal_phrase = "mixed metal (yellow gold, silver, copper and rose gold, alternating piece by piece)" if M == "MX" else ("rose gold" if M == "MR" else MN[M].replace("-", " "))
    p = (f"Professional fashion photograph, {pname.replace(' portrait','')} five-material portrait: real face and neck, and a sculpted body made of five different materials — {summary}. ONE woman, angled 45 degrees toward the camera, framed so her whole sculpted form is visible from the top of her head down to two individually rounded, deliberately carved tips {pos}, her face in natural scale with her body — never an oversized close-up crop of just the face. Where her sculpted form comes to an end at her {part}, it is because the sculpture itself ends there, not because a camera frame happens to cut her off.\n\n"
         f"Subject: A real photograph of a strikingly beautiful adult {nat} woman — {fa}, {hair}. {REAL_FACE}\n\n"
         f"Piercings: {pierce}{DENS if dense else ''}{gem_text(G) if method == '집중형' else ''} {CARE2.format(metal=metal_phrase)}\n\n{DEPTH}\n\n"
         f"Physique: {phys2}\n\nBoundary (skin to material, at underarm height): {NECK}\n\n"
         f"Left arm (shoulder to hand): {texts['Left arm']}\n\nRight arm (shoulder to hand): {texts['Right arm']}\n\nTorso (chest, belly, hips): {texts['Torso']}\n\n{leg('Left thigh', 'left')}\n\n{leg('Right thigh', 'right')}\n\n"
         f"Where each material meets its neighbour (left shoulder, right shoulder, left hip, right hip), the two distinct materials sit flush against each other with a thin, clean seam, deliberate and precise, never jagged or torn — always the finish of a sculpture, each material keeping its own colour, clarity and surface completely separate from the one beside it. Both thighs stay clearly separate all the way down, never merging into a single base, both rounded tips resting side by side on the surface beneath her.\n\n"
         f"Setting: a huge backdrop behind her washed with two coloured lights from behind — {ba} on one side and {bb} on the other, blending into a smooth gradient in the middle — glowing evenly, marked with a few thin dark vertical lines so the bending of those lines is visible wherever the body is transparent, and a glossy dark floor beneath her.\n\n"
         f"Pose: standing tall, body angled 45 degrees, her left hand resting on her flared hip, her right arm held clear of her body with the hand relaxed at hip height, both hands well away from her face, head tilted slightly toward the camera.\n\n"
         f"Lighting: two large softboxes rake across her body from either side, so {ba} light glances off the left half and {bb} light glances off the right half — passing straight through the transparent parts ({', '.join(p_.lower() for p_ in clear)}), while only reflecting off the opaque parts ({', '.join(p_.lower() for p_ in opaque)}). A soft frontal light falls on her face and ears. Shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait.")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), (frame, P)
    if M not in ("MG", "MR", "MX"): assert "gold" not in pierce.lower(), (frame, P, M)
    parts_ko = " · ".join(f"{k_}{labels[k_]}" for k_ in ["Left arm", "Right arm", "Torso", "Left thigh", "Right thigh"])
    parts_ko = parts_ko.replace("Left arm", "왼팔 ").replace("Right arm", "오른팔 ").replace("Torso", "몸통 ").replace("Left thigh", "왼허벅지 ").replace("Right thigh", "오른허벅지 ")
    desc = f"{re.sub(r'^[A-Z]+', '', HS[si-1])} · {re.sub(r'^[A-Z]+', '', HC[ci-1])} · 메이크업 {mk} · 금속 {MKO[M]}"
    return p, desc, parts_ko
specs = [("hip","P50","정의형"), ("hip","P100","정의형"), ("demi","P25","집중형"), ("demi","P50","정의형"), ("tq","P8","집중형"), ("tq","P25","집중형")]
items = [(fr, P, m) + build(fr, P, m) for fr, P, m in specs]
order = list(range(6)); rnd.shuffle(order); no = {i: order.index(i)+1 for i in range(6)}; ranked = sorted(range(6), key=lambda i: no[i])
L = ["# LumineX · 재질 혼합 프레임 컷 + 피어싱 한도 시험 — 힙컷·데미스탯·쓰리쿼터 (6개)\n",
     "한 몸 안에서 재질을 섞었습니다. 검증된 **5재질 패치워크 구조**(왼팔·오른팔·몸통·왼허벅지·오른허벅지가 어깨·엉덩이 관절에서 맞닿고 각자 다른 재질)를 이 프레임에 맞춰 썼고, 조각 자체가 허벅지·무릎에서 매끈하게 끝납니다. 재질은 **석재·목재·단일 투명·수조 투명·내용물 투명 5종이 한 몸에 하나씩** 들어가며, 어느 부위에 어느 재질인지는 무작위입니다(팔은 석재·목재·단일 투명만). 얼굴·귀·목은 실사 살입니다. 각 프레임에서 한도로 추정한 단계의 위아래를 한 개씩 넣었습니다(힙컷 P50·P100, 데미스탯 P25·P50, 쓰리쿼터 P8·P25). P8·P25는 집중형(왼쪽 몰림, 정면 화면에서는 오른쪽), P50 이상은 정의형입니다. 번호는 섞여 있습니다.\n",
     "**알려주실 것**: 집중형(P8·P25)은 **얼굴·귀 피어싱 개수만** 세어 주시고, P50 이상은 **성공/실패**(얼굴·귀 피어싱이 눈에 띄지 않거나 재질 부위가 안 나뉘면 실패)로 적어 주세요. 최대 3회. 예: `1: 9개 / 2: 실패 / 3: 성공`\n",
     "## 색인\n", "| 번호 | 프레임 | 단계 | 방식 | 부위별 재질 | 얼굴 |", "|---|---|---|---|---|---|"]
for i in ranked: fr, P, m, p, d, pk = items[i]; L.append(f"| {no[i]:02d} | {FRKO[fr]} | {P} | {m} | {pk} | {d} |")
L.append("")
for i in ranked: fr, P, m, p, d, pk = items[i]; L += [f"## {no[i]:02d}. {FRKO[fr]} · {P} · 재질 혼합\n", "```", p, "```\n"]
open("/tmp/rep_out/LumineX_Pierce_MixedStatue_Round1.md", "w", encoding="utf-8").write("\n".join(L))
print("6개 저장")
for i in ranked: fr, P, m, p, d, pk = items[i]; print(f"  {no[i]:02d} {FRKO[fr]:<4} {P:<4} {m:<4} {len(p.split()):>4}단어 | {pk}")
