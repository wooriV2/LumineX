# -*- coding: utf-8 -*-
import re, sys, os, random, json
os.chdir('/home/claude/glassface'); sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
def load(path):
    src = open(path, encoding="utf-8").read().split("\nspecs = [")[0].split("\nitems = []")[0]; ns = {"__name__": "ns"}; exec(src, ns); return ns
S = load('gen_pierce_statue.py'); X = load('gen_pierce_mixstatue2.py'); C = load('gen_pierce_waist.py')
DARK = [("ebony", "deep black ebony wood, densely fine-grained, polished to a hard, glass-like satin sheen, completely opaque"),
        ("wenge", "dark wenge wood, a deep near-black wood finely striped with narrow gold-tan pinstripes running through it, polished to a hard satin sheen, completely opaque"),
        ("purpleheart", "deep violet purpleheart wood, a dense hardwood of rich purple with fine straight grain, polished to a hard satin sheen, completely opaque")]
for ns in (S, X): ns["WOODS"][:] = DARK
for k, ns in enumerate((S, X, C)): ns["rnd"].seed(20261220 + k)
R = random.Random(20261299)
CARE2 = "All jewelry is real {metal}, sitting in real, calm, healthy skin — no redness, no swelling, no irritation — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes."
SKIN_B = ("Her neck, the hollows above her collarbones and the tops of her shoulders carry the same real living skin as her face: visible pores and fine skin grain, a soft sheen of natural skin oils on the highest planes, faint fine peach-fuzz hairs catching the rim light along the neck and shoulder line, gentle tonal variation with a natural warm flush at the base of the neck and across the collarbones, and the fine natural creases of a real neck — never airbrushed, never smooth like plastic. "
          "Like any real person she is slightly asymmetrical: a few small natural beauty marks and freckles scattered unevenly, one side of her neck and shoulder very slightly warmer and more freckled than the other.")
ANCH = "not cel-shaded.\n\nPiercings:"
def add_skin(p): assert ANCH in p; return p.replace(ANCH, "not cel-shaded. " + SKIN_B + "\n\nPiercings:", 1)
def dd_check(p, tag, dd):
    p = dd(p).replace(",,", ",").replace(".,", ",")
    _d = [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", p)]
    assert not re.search(r"[가-힣]", p) and not _d, (tag, _d)
    return p
def write_md(fn, title, intro, ask, rows, items):
    L = [f"# {title}\n", intro + "\n", ask + "\n", "## 색인\n", "| 번호 | 구성 |", "|---|---|"]
    for no, desc, _ in items: L.append(f"| {no:02d} | {desc} |")
    L.append("")
    for no, desc, p in items: L += [f"## {no:02d}. {desc}\n", "```", p, "```\n"]
    open("/mnt/user-data/outputs/" + fn, "w", encoding="utf-8").write("\n".join(L))
def shuffled(entries, seed):
    rr = random.Random(seed); order = list(range(len(entries))); rr.shuffle(order); no = {i: order.index(i) + 1 for i in range(len(entries))}
    return sorted([(no[i], entries[i][0], entries[i][1]) for i in range(len(entries))])
dd = S["dd"]
# ================= A. 앉기 앵클컷 =================
X["FR"]["ankle"] = ("ankle-cut statue portrait", "just above her ankle bones", "ankles"); S["FR"]["ankle"] = X["FR"]["ankle"]; X["FRKO"]["ankle"] = "앵클컷"
SEATS = {"bench": "She sits on a long, low black lacquered bench.", "chair": "She sits on a simple black wooden chair.", "ledge": "She sits on a deep stone window ledge, with a tall window behind her letting in cool light.", "floor": "She sits directly on the glossy dark floor."}
POSES = {"앉기 1: 긴 의자, 상체를 세우고 다리 일자로": ("bench", "Pose: sitting upright on a long, low bench with her back straight, both legs extended straight forward side by side, her left hand resting on the bench beside her hip and her right hand resting on top of her leg, both hands well away from her face, head tilted slightly toward the camera."),
         "앉기 2: 의자 끝, 상체를 앞으로 기울임": ("chair", "Pose: sitting on the front edge of a plain chair, leaning her upper body slightly forward, both forearms resting on her legs, her hands loosely clasped well away from her face, both legs extended forward, head tilted slightly toward the camera."),
         "앉기 3: 창가 턱, 한 손을 턱에": ("ledge", "Pose: sitting on a deep window ledge with her back against the window frame, both legs extended forward along the ledge, one hand resting lightly under her chin and the other resting on her leg, head tilted slightly toward the camera."),
         "기대기: 바닥에 앉아 두 손으로 뒤를 짚고": ("floor", "Pose: sitting on the floor with her upper body leaning back, both hands planted behind her on the floor, both legs extended straight forward side by side, head tilted slightly toward the camera.")}
POSE_RE = re.compile(r"Pose: standing tall,.*?toward the camera\.", re.S)
def ankle_seated(pname, P):
    method = "집중형" if P in ("P8", "P25") else "정의형"
    seat, pose = POSES[pname]
    p, d, pk = X["build"]("ankle", P, method)
    p = p.replace("thighs", "legs").replace("thigh", "leg").replace("Thighs", "Legs").replace("Thigh", "Leg")
    p = add_skin(p)
    p = p.replace("framed so her whole sculpted form is visible", "framed so her whole seated sculpted form is visible", 1)
    END_OLD = "Both legs stay clearly separate all the way down, never merging into a single base, both rounded tips resting side by side on the surface beneath her."
    assert END_OLD in p, "END_OLD"
    p = p.replace(END_OLD, "Both legs extend forward and stay clearly separate along their whole length, never merging into a single mass, each ending in its own rounded, polished tip just above the ankle that stops cleanly in front of her — a finished sculpture's end, never cut off.")
    FLOOR_OLD = "and a glossy dark floor beneath her."; assert FLOOR_OLD in p
    p = p.replace(FLOOR_OLD, f"and a glossy dark floor beneath her. {SEATS[seat]} The seat is a separate object, clearly distinct from her body, and her sculpted form does not merge into it.", 1)
    assert POSE_RE.search(p); p = POSE_RE.sub(pose, p, count=1)
    p = dd_check(p, pname, dd)
    return p, f"앵클컷 · {pname.split(':')[0]} · {P} {method} · {pk[:60]}"
A_specs = [("앉기 1: 긴 의자, 상체를 세우고 다리 일자로", "P25"), ("앉기 2: 의자 끝, 상체를 앞으로 기울임", "P25"), ("앉기 3: 창가 턱, 한 손을 턱에", "P25"), ("기대기: 바닥에 앉아 두 손으로 뒤를 짚고", "P25"), ("앉기 1: 긴 의자, 상체를 세우고 다리 일자로", "P8"), ("앉기 2: 의자 끝, 상체를 앞으로 기울임", "P50")]
A = []
for pn, P in A_specs:
    p, d = ankle_seated(pn, P); A.append((d, p))
write_md("LumineX_Test_AnkleSeated.md", "LumineX · 앉기 앵클컷 시험 — 다리를 뻗는 포즈를 앵클컷 문장으로 (6개)",
         "앞선 포즈 시험에서 다리를 앞으로 뻗는 앉기 계열이 **발목 컷으로 생성**되는 걸 확인했습니다. 이번에는 **글도 발목 끝으로** 맞췄습니다(`just above her ankle bones`, 두 다리가 앞으로 뻗어 둥근 끝으로 끝남). 몸은 5재질 혼합이고 살 문장 B가 들어 있습니다. 얼굴이 작아지는 구도라 피어싱은 **P8·P25·P50**만 넣었습니다. 번호는 섞여 있습니다.",
         "**알려주실 것**: 번호마다 **성공/실패**. 실패하면 이유 한마디(**다리가 잘림 / 의자와 몸이 합쳐짐 / 피어싱 묻힘 / 생성 안 됨**). P8·P25는 개수까지 안 세셔도 됩니다. 최대 3회. 예: `1: 성공 / 3: 실패(의자와 합쳐짐)`", None, shuffled(A, 31))
# ================= B. 맥시멀리스트 메이크업 축 =================
TRK = re.search(r"TRACKS = r'''(.*?)'''\nexec\(TRACKS, C\)", open("gen_bundle_frame.py", encoding="utf-8").read(), re.S).group(1)
C.update(CARE2=CARE2, DEPTH=S["DEPTH"], REAL_FACE=S["REAL_FACE"], SKIN_B=SKIN_B, JQ={1: ""}, JMET={"JMG": "gold"})
exec(TRK, C)
C["pierce_text"] = load('gen_pierce_method.py')["pierce_text"]; C["ear_noun"] = load('gen_pierce_method.py')["ear_noun"]
TONEWORDS = re.compile(r"skin|complexion|tanned|porcelain|\bfair\b|\bpale\b|\bolive\b|bronze|tan\b|suntan", re.I)
def makeup_clauses(mk):
    nat, fa = S["face_nohair"](mk)
    parts = [x.strip() for x in fa.split(", ")]; keep = [x for x in parts if not TONEWORDS.search(x)]
    return ", ".join(keep), len(parts) - len(keep)
B_specs = [("블루블랙", "P50"), ("블루블랙", "P100"), ("에보니 브라운", "P50"), ("블루블랙", "P100"), ("올리브", "P50"), ("포셀린", "P100")]
mks = R.sample(list(S["T"].MAKEUP_48), 6)
B = []
for (tone, P), mk in zip(B_specs, mks):
    mkt, dropped = makeup_clauses(mk)
    p, d, M = C["maximalist"]("face", P, tone, None, None)
    old = ", full lips, a bold, commanding expression"
    assert old in p; p = p.replace(old, f", full lips, {mkt}, a bold, commanding expression", 1)
    p = dd_check(p, (tone, mk), dd)
    assert not TONEWORDS.search(mkt), mkt
    B.append((f"블루블랙 기준 · 피부톤 {tone} · {P} · 메이크업 {mk}", p))
write_md("LumineX_Test_MaxMakeup.md", "LumineX · 맥시멀리스트 메이크업 축 시험 — 검은 피부 얼굴 컷에 메이크업 48종 중 6종 (6개)",
         "지금까지 맥시멀리스트 얼굴 컷은 메이크업 없이 피부톤만 바꿨습니다. 이번에는 **메이크업 6종**(눈·입술·블러시 등)을 넣어 피어싱이 묻히지 않는지 확인합니다. 기존 메이크업 문장에서 **피부색 구절(예: \"fair porcelain skin\")은 빼고** 눈·입술·눈썹 쪽만 붙였습니다. 피부톤은 블루블랙 중심이고 에보니 브라운·올리브·포셀린도 한 개씩, 피어싱은 P50·P100입니다. 번호는 섞여 있습니다.",
         "**알려주실 것**: 번호마다 **성공/실패**. 실패하면 이유 한마디(**피어싱 묻힘 / 메이크업이 안 보임 / 피부톤이 바뀜 / 생성 안 됨**). 최대 3회. 예: `1: 성공 / 4: 실패(피부톤이 바뀜)`", None, shuffled(B, 32))
# ================= C. 한도 3칸 =================
C_specs = [("demi", "P200"), ("tq", "P150"), ("tq", "P200")]; Cc = []
for fr, P in C_specs:
    method = "정의형"; p, d, pk = X["build"](fr, P, method); p = add_skin(p); p = dd_check(p, (fr, P), dd)
    Cc.append((f"{ {'demi': '데미스탯', 'tq': '쓰리쿼터'}[fr] } · {P} 정의형 · 5재질 혼합 · {pk[:70]}", p))
write_md("LumineX_Test_Limits3.md", "LumineX · 프레임별 한도 확정 시험 — 데미스탯 P200, 쓰리쿼터 P150·P200 (3개)",
         "재질 프레임 한도가 시험한 최고 단계(힙컷 P200, 데미스탯 P150, 쓰리쿼터 P100)까지 모두 통과해서 **아직 못 찾은 칸 3개**를 확인합니다. 몸은 5재질 혼합, 살 문장 B가 들어 있습니다.",
         "**알려주실 것**: 번호마다 **성공/실패**. 실패하면 이유 한마디(**피어싱이 안 읽힘 / 재질 구조가 무너짐 / 생성 안 됨**). 최대 3회. 예: `1: 성공 / 2: 성공 / 3: 실패(피어싱이 안 읽힘)`", None, shuffled(Cc, 33))
# ================= D. 재질 종류 확대 =================
MT = S["mat_text"] if "mat_text" in S else C["mat_text"]
NEWMAT = {"glass": ("스테인드글라스", "T1"), "obsidian": ("흑요암+금빛 이음새", "stone"), "scale_koi": ("비늘(잉어)", "stone"), "scale_dragon": ("비늘(용)", "stone"), "scale_mermaid": ("비늘(인어)", "stone"), "irezumi": ("이레즈미", "stone")}
D_specs = [("demi", "glass"), ("demi", "obsidian"), ("tq", "scale_koi"), ("demi", "scale_dragon"), ("tq", "scale_mermaid"), ("demi", "irezumi")]
D = []
for fr, mkey in D_specs:
    ko, kind = NEWMAT[mkey]; txt = re.sub(r"^solid\s+", "", C["mat_text"](mkey)[0])
    if kind == "T1":
        S["MAT"]["_new"] = ("stained glass", txt, "dark lead-line seams webbing between every pane"); p, d, mname = S["build"](fr, "P50", "정의형", "T1", "_new")
    else:
        S["STONES"][:] = [(mkey.replace("_", " "), txt if mkey != "irezumi" else "smooth polished pale marble completely covered from the collarbones down by traditional irezumi tattoo designs in bold black ink outlines with ELECTRIC GOLD and CRIMSON dragon and phoenix imagery, extreme high-gloss finish")]
        p, d, mname = S["build"](fr, "P50", "정의형", "stone", 0)
        assert "one solid opaque stone, solid " in p; p = p.replace("one solid opaque stone, solid ", "one solid opaque sculpted mass, solid ", 1)
    p = add_skin(p); p = dd_check(p, (fr, mkey), dd)
    D.append((f"{ {'demi': '데미스탯', 'tq': '쓰리쿼터'}[fr] } · P50 · 단일 재질 {ko}", p))
write_md("LumineX_Test_NewMaterials.md", "LumineX · 재질 종류 확대 시험 — 스테인드글라스·흑요암금·비늘·이레즈미 조각 (6개)",
         "지금까지 조각 구조는 석재·목재·투명 계열만 시험했습니다. **스테인드글라스, 흑요암+금빛 이음새, 비늘 3종(잉어·용·인어), 이레즈미**를 몸 전체 단일 재질로 넣었습니다(이레즈미는 피부 문신이라 \"흰 대리석 위에 이레즈미 문양\"으로 썼습니다). 모두 P50, 살 문장 B가 들어 있습니다. 번호는 섞여 있습니다.",
         "**알려주실 것**: 번호마다 **성공/실패**. 실패하면 이유 한마디(**재질이 안 읽힘 / 살처럼 나옴 / 생성 안 됨**). 최대 3회. 예: `1: 성공 / 4: 실패(살처럼 나옴)`", None, shuffled(D, 34))
for fn in ("LumineX_Test_AnkleSeated.md", "LumineX_Test_MaxMakeup.md", "LumineX_Test_Limits3.md", "LumineX_Test_NewMaterials.md"):
    t = open("/mnt/user-data/outputs/" + fn, encoding="utf-8").read(); print(fn, "|", t.count("\n## 0"), "개 | 단어", len(t.split()))
