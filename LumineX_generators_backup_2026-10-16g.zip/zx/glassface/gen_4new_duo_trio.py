# -*- coding: utf-8 -*-
import re, random
banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","safety pin","gash","crack"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    hits = [w for w in banned if w in p.lower()]
    assert not hits, (name,hits)

PHYSIQUES = [
 ("super hourglass", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum beyond any proportion, most dramatic hourglass ratio ever recorded on any human body, thighs so thick pressing together"),
 ("wide hip narrow", "hips so impossibly wide extending beyond frame creating the most extreme hip-to-waist ratio ever, waist cinched to absolute impossible minimum, upper body slim emphasizing the dramatic hip explosion"),
 ("BBW bombshell", "most massive full-figure BBW body ever at absolute maximum in every dimension, hips so wide beyond proportion dominating the entire frame, bust so enormous overwhelming gravity, waist deeply snatched despite impossible volume"),
 ("curvy petite", "smallest most compact frame possible yet curves exploding at absolute maximum in every direction, bubble butt projecting dramatically backward from the tiny frame, thighs so thick they dwarf the petite frame"),
 ("amazon bombshell", "impossibly tall commanding frame with simultaneously the most massive full-figure curves, enormous powerful presence dominating the entire frame top to bottom, legs endlessly long massively thick and powerful"),
 ("latina curves", "most dramatic hourglass ratio ever, simultaneously maximum enormous bust AND maximum enormous hips both flaring to absolute impossible extremes while the waist is cinched to impossible minimum"),
]
HAIRS = ["long sleek jet-black hair cascading past hips","silver-white natural hair swept into a high sculpted crown","loose beach waves mid-length tousled","blunt collarbone-length bob thick heavy","silver-white locs cascading to her waist","curtain bangs long straight hair sweeping past the shoulders"]
POSES = ["strong hip pop right, both hands pressing sides of hips outward simultaneously arching back to extreme",
 "full frontal wide stance, both fists pressing outer hips outward to absolute maximum",
 "standing full height, both arms slightly spread commanding the frame",
 "back three-quarter turned, face over shoulder direct eye contact, bubble butt projected backward",
 "strong hip pop left, both hands pressing outer hips outward arching back to extreme",
 "full frontal, both hands framing the face, chin raised"]
AGES = ["early 20s","late 20s","early 30s","mid 30s","late 30s","mid 40s"]

def ice_mat(c1,c2):
    return (f"full body frost crystals growing directly out of her own skin covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, every crystal point erupting outward from beneath the surface of her living skin in true three-dimensional relief, each facet catching its own individual glint and casting its own small hard shadow onto the skin and onto neighbouring crystals, nothing lying flat. Dense branching clusters — BLAZING {c1} frost crystal formations erupting across the full torso both legs neck to ankle, VIVID {c2} rime detail filling every remaining gap with real depth and texture, each crystal sharply faceted and distinct, NO airbrush NO gradient wash, NO flat printed surface anywhere")

def wax_mat(c1,c2):
    return (f"full body molten wax flowing and set directly over her own skin covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not a printed pattern, this is real wax that has flowed down every curve and hardened in place, each drip and pooled ridge standing in true three-dimensional relief, casting its own small soft shadow, nothing lying flat. Dense flowing drips — BLAZING {c1} molten wax streams pooling and hardening across the full torso both legs neck to ankle, VIVID {c2} translucent drip-ridges catching the light filling every remaining gap with real depth and texture, each ridge glossy and rounded exactly like real set wax, NO airbrush NO gradient wash, NO flat printed surface anywhere")

def butterfly_mat(c1,c2):
    return (f"her own skin itself covered in microscopic butterfly-wing scales covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not fabric, not a garment, not a printed pattern, this is the real cellular structure of her own skin forming thousands of tiny overlapping scales exactly like a butterfly wing under magnification, each scale individually distinct catching its own glint, nothing lying flat as one smooth sheet. Dense overlapping scale fields — BLAZING {c1} iridescent scale formations shifting across the full torso both legs neck to ankle, VIVID {c2} scale-edge detail filling every remaining gap with real texture, NO airbrush NO gradient wash, NO flat printed surface anywhere")

def obsidian_mat():
    return ("full body polished obsidian stone fused directly to her own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, this is solid glossy black stone curving to follow her body's true three-dimensional shape, with molten gold seams running between dozens of fitted stone sections, each seam standing in a thin raised ridge catching its own bright glint and casting its own small shadow, nothing lying flat. Dense fitted sections — BLAZING glossy jet-black obsidian surface across the full torso both legs neck to ankle, VIVID MOLTEN GOLD seams branching and converging densely with no plain stone section left ungilded, NO airbrush NO gradient wash, NO flat printed surface anywhere")

MATERIALS = {
 "ice": (ice_mat, [("ELECTRIC ICE-BLUE","SILVER-WHITE"),("ELECTRIC CYAN","PALE SILVER"),("ELECTRIC WHITE-BLUE","FROSTED SILVER")], "ice crystal", "extra long nails, tiny ice crystal points erupting at each tip"),
 "wax": (wax_mat, [("DEEP CRIMSON","AMBER"),("DEEP EMERALD","GOLD"),("DEEP VIOLET","ROSE")], "wax", "extra long nails, tiny wax drip tips at each nail"),
 "butterfly": (butterfly_mat, [("ELECTRIC BLUE","BLACK"),("ELECTRIC EMERALD","GOLD"),("ELECTRIC VIOLET","MAGENTA")], "scale", "extra long nails, the same iridescent scale shimmer at each tip"),
 "obsidian": (None, None, "obsidian", "extra long nails, glossy black with gold seam tips"),
}

def person_block(mat_key, idx, label):
    phy_name, phy_detail = PHYSIQUES[idx % len(PHYSIQUES)]
    age = AGES[idx % len(AGES)]; hair = HAIRS[idx % len(HAIRS)]; pose = POSES[idx % len(POSES)]
    if mat_key == "obsidian":
        mat_text = obsidian_mat()
        surface_word = "obsidian"
    else:
        fn, colorlist, surface_word, _ = MATERIALS[mat_key]
        c1,c2 = colorlist[idx % len(colorlist)]
        mat_text = fn(c1,c2)
    nail_text = MATERIALS[mat_key][3]
    prefix = f"{label}: " if label else ""
    return (f"{prefix}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {hair} — {mat_text}. Pose: {pose} — most extreme {phy_name} silhouette ever displayed.\n"
            f"{prefix}extreme platform heels entirely encrusted with the same {surface_word}, {nail_text}.")

def build_duo(mat_key, seed):
    rnd_offset = seed
    b1 = person_block(mat_key, rnd_offset, "LEFT")
    b2 = person_block(mat_key, rnd_offset+1, "RIGHT")
    return f"""Professional fashion photograph, full body shot. TWO women standing side by side.

{b1}

{b2}

Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.
All: Extreme macro detail on every surface texture and shadow. CRITICAL: both women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere, every element standing in true relief, nothing flat. TWO completely different extreme physiques must CONTRAST and DOMINATE every inch of frame. 8K portrait 3:4 vertical."""

def build_trio(mat_key, seed):
    rnd_offset = seed
    b1 = person_block(mat_key, rnd_offset, "LEFT")
    b2 = person_block(mat_key, rnd_offset+1, "CENTER")
    b3 = person_block(mat_key, rnd_offset+2, "RIGHT")
    return f"""Professional fashion photograph, full body shot. THREE women standing side by side.

{b1}

{b2}

{b3}

Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.
All: Extreme macro detail on every surface texture and shadow. CRITICAL: all three women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere, every element standing in true relief, nothing flat. THREE completely different extreme physiques must CONTRAST and DOMINATE every inch of frame. 8K portrait 4:5 vertical."""

MAT_KO = {"ice":"얼음/서리 결정","wax":"왁스(촛농)","butterfly":"나비날개 비늘","obsidian":"흑요암+금빛 이음새"}
OUT = []
for mat_key in ["ice","wax","butterfly","obsidian"]:
    for i in range(2):
        seed = i*10
        d = build_duo(mat_key, seed)
        check(f"{mat_key}_duo{i}", d)
        OUT.append((f"{MAT_KO[mat_key]} — 듀오 {i+1}", d))
    for i in range(2):
        seed = i*10+3
        t = build_trio(mat_key, seed)
        check(f"{mat_key}_trio{i}", t)
        OUT.append((f"{MAT_KO[mat_key]} — 트리오 {i+1}", t))

for label,p in OUT:
    print(label, len(p.split()))

L = ["# LumineX · 신규 4종(얼음/왁스/나비날개/흑요암) — 듀오2·트리오2씩\n"]
for label,p in OUT:
    L.append(f"## {label}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_4NewMaterials_Duo2Trio2.md","w",encoding="utf-8").write("\n".join(L))
print("saved", len(OUT))
