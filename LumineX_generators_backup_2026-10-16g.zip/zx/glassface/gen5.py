# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
spec = importlib.util.spec_from_file_location("g3","gen3.py"); g = importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(io.StringIO()):
    spec.loader.exec_module(g)
MAT = dict(g.MAT)
_n = MAT["smoky"]; MAT["smoky"] = (_n[0], _n[1], "smoky depth, slow swirls and faint bubbles, hard mirror highlights, darkest where thickest")
_n = MAT["murano"]; MAT["murano"] = (_n[0], _n[1], "twisted ribbons of cobalt, red, yellow and white swirling through it and tiny gold flecks suspended between them")
_n = MAT["carnelian"]; MAT["carnelian"] = (_n[0], _n[1], "warm banded stripes of orange and red and a waxy luster, glowing brightest orange at every thin edge")

RULE = "Every piercing is real opaque metal, pearl, enamel or acrylic, passing through a clean drilled opening in the carved material and never turning into it, all kept clear of the eyeballs"
RULE_LIPS = "; those in the lips pass through real flesh"

ROWS = [
 dict(tier="적게", ko="프렌치 레드립", nat="French", mk="French red-lip", a="sapphire", b="citrine",
  eyes="soft grey-green irises", gaze="an unbothered, effortless gaze",
  lips="a single bold classic red matte real lipstick sitting on real skin, held in a relaxed, slightly parted line",
  lashes="fluttering lashes carved as fine raised fibres along each lid and softly brushed natural brows carved as fine grooves",
  hair="the effortless tousled updo is carved as loose, sculpted locks piled high with a few strands falling at the temples, each lock a chiselled ribbon of solid material with a polished surface",
  makeup="Almost no colour: a soft natural glow lies deep within the cheeks, and the brows and lids are simply the material's own tone. The red of the lips is the only strong colour on the face.",
  pierce="A single thick gold hoop on each ear, nothing else.", lipp=False, orn=""),
 dict(tier="적게", ko="구풍", nat="Chinese", mk="guofeng", a="jade", b="ruby",
  eyes="dark brown irises", gaze="a serene, composed gaze",
  lips="a small vivid red real lipstick sitting on real skin, the mouth closed and calm",
  lashes="long lashes carved as fine raised fibres and slender upswept willow-leaf brows carved as fine raised lines, an upswept eyeliner tail carved as a thin dark line at each outer corner",
  hair="the high coiled updo is carved as smooth sculpted coils piled above the crown, each coil a chiselled band of solid material",
  makeup="A small red floral huadian mark is inlaid flush at the centre of the forehead as a tiny facet of vivid red colour, and a soft rosy flush glows deep within each cheek.",
  pierce="A big gold hoop with a small red-enamel bead on each ear.", lipp=False,
  orn="A few slender gold hairpins are pushed into the carved updo. They are real metal and stay exactly so."),
 dict(tier="적게", ko="히메갸루", nat="Japanese", mk="hime-gyaru", a="rosepink", b="egglass",
  eyes="light brown irises enlarged by pale circle lenses", gaze="a sweet, warm gaze",
  lips="a glossy candy-pink real lipstick sitting on real skin, curved in a sweet princess-like smile",
  lashes="long curled lashes carved as fine raised fibres along each lid",
  hair="the huge voluminous curls are carved as big sculpted spiral ringlets falling around the face and behind the ears, each curl a chiselled coil of solid material with a polished surface",
  makeup="Sparkling pink bands of shimmer run through the surface of the carved lids, and a soft pink glow lies deep within each cheek.",
  pierce="A big gold hoop with a small pearl drop on each ear.", lipp=False,
  orn="A big pink satin bow sits on top of the carved head. It is real fabric, soft and matte, and stays exactly so."),
 dict(tier="적당히", ko="락혼 글램", nat="Thai", mk="lakorn-drama glam", a="emerald", b="carnelian",
  eyes="deep brown irises", gaze="a poised, dramatic gaze",
  lips="a deep red glossy real lipstick with a crisp defined edge sitting on real skin",
  lashes="long dramatic lashes carved as fine raised fibres, sharply defined brows carved as crisp raised lines, and a precise black winged liner carved as a strong flick at each outer corner",
  hair="the long glossy waves are carved as soft sculpted waves falling around the face and behind the ears, each a chiselled ribbon of solid material with a polished surface",
  makeup="Warm brown-bronze bands blend up the carved lids, and a strong sculpted contour runs under each cheekbone as a deeper tone within the carving.",
  pierce="A thin gold ring passes through the left nostril; a thin gold ring passes through the outer end of the left eyebrow; on each ear a big gold hoop with a chased-gold drop.", lipp=False, orn=""),
 dict(tier="적당히", ko="노르딕 발키리", nat="Norwegian", mk="Nordic valkyrie", a="glacial", b="cobalt",
  eyes="pale blue irises", gaze="a fierce, steady, commanding gaze",
  lips="a muted red-brown real lipstick with a matte finish sitting on real skin, held in a firm line",
  lashes="long lashes carved as fine raised fibres and strong straight defined brows carved as crisp raised lines",
  hair="the two thick braids and the braided crown are carved as sculpted plaits, each strand of the weave a chiselled rope of solid material",
  makeup="A light scatter of freckles lies across the cheeks and the bridge of the nose as tiny darker specks of colour deep within the material, and a warm bronze band blends across each carved lid.",
  pierce="A small silver ring passes through the left nostril; a small silver bar passes through the outer end of the left eyebrow; on each ear a thick silver knotted hoop.", lipp=False, orn=""),
 dict(tier="적당히", ko="야마바", nat="Japanese", mk="yamanba", a="murano", b="aquamarine",
  eyes="dark irises", gaze="a bold, cheeky gaze",
  lips="a glossy white real lipstick sitting on real skin, grinning boldly",
  lashes="long dramatic false lashes carved as fine raised fibres along each lid",
  hair="the long teased hair is carved as tall, teased sculpted locks standing above the crown and falling around the face, each lock a chiselled ribbon of solid material",
  makeup="Wide bands of stark milky white run through the surface of the carved lids above and below each eye socket, never across the eyeball, with neon pink and turquoise veins of colour inside the carving. A few small star and heart shapes sit on the cheeks as inlaid facets of pale material, flush with the surface.",
  pierce="A small silver ring passes through the left nostril; a thick silver bar passes through the outer end of the left eyebrow; on each ear a big neon-acrylic hoop and a small silver star stud.", lipp=False,
  orn="A few small colourful plastic hair clips sit on top of the head. They are real plastic, bright and matte, and stay exactly so."),
 dict(tier="많이", ko="비주얼계", nat="Japanese", mk="visual-kei", a="smoky", b="alabaster",
  eyes="dark irises", gaze="a cold, poised gaze",
  lips="a glossy near-black real lipstick sitting on real skin, held in a cold, closed line",
  lashes="long dramatic lashes carved as fine raised fibres and a sharp black winged liner carved as a fine dark line running out from each outer corner",
  hair="the long teased jet-black hair is carved as long, sharp sculpted sheets and shards falling around the face and behind the ears, each a chiselled panel of solid material",
  makeup="Deep smoky darkness blends far out around the carved eyelids as a darker tone running through the surface, and sharply sculpted cheekbones are carved as deeper hollows.",
  pierce="A thick black-steel septum ring hangs below the nose; two thick black-steel bars pass through the outer end of the left eyebrow; a black-steel hoop passes through the lower lip's edge; a black-steel labret stud sits beneath the lower lip; on each ear a big black-steel hoop and a thick black-steel bar.", lipp=True, orn=""),
 dict(tier="많이", ko="뱀파이어 다크", nat="Korean", mk="dark vampire", a="amethyst", b="amber",
  eyes="dark irises", gaze="a cold, poised gaze",
  lips="a glossy near-black wine real lipstick sitting on real skin, held in a cold, poised line",
  lashes="long dramatic lashes carved as fine raised fibres along each lid and a sharp black liner carved as a fine dark line at each outer corner",
  hair="the long straight jet-black hair is carved as long smooth sculpted sheets falling straight around the face and behind the ears, each a chiselled panel of solid material with fine grooves running its length like strands",
  makeup="A deep burgundy-black shadow smudges heavily beneath both carved eye sockets as a darker tone within the material, and sharply contoured cheekbones are carved as deeper hollows.",
  pierce="A thick black-steel septum ring hangs below the nose; two thick black-steel bars pass through the outer end of the left eyebrow; a small black-steel ring passes through the left corner of the lower lip; a black-steel labret stud sits beneath the lower lip; on each ear a thick black-steel bar and a pointed silver spike stud.", lipp=True, orn=""),
 dict(tier="많이", ko="로리타 갸루", nat="Japanese", mk="lolita-gyaru", a="rosequartz", b="sapphire",
  eyes="dark irises enlarged by pale circle lenses", gaze="a sweet, playful gaze",
  lips="a glossy cherry-pink real lipstick sitting on real skin, curved in a sweet, playful smile",
  lashes="thick curled lashes carved as fine raised fibres along each lid and the drawn-on lower lashes as thin carved lines beneath",
  hair="the long honey-brown ringlets are carved as thick sculpted spiral ringlets falling around the face and behind the ears, each curl a chiselled coil of solid material with a polished surface",
  makeup="Soft pink and lilac bands of pearly shimmer sit within the surface of the carved lids, and a round pink glow lies deep within each cheek.",
  pierce="A thick silver septum ring hangs below the nose; two thick silver bars pass through the outer end of the left eyebrow; a big silver hoop passes through the lower lip's edge; a silver labret stud sits beneath the lower lip; on each ear a big silver hoop and one stretched gold-rimmed ear plug.", lipp=True,
  orn="A white lace headdress with a satin bow sits on top of the carved head. It is real lace and fabric, soft and matte, and stays exactly so."),
]

def build(r):
    an, adesc, ainner = MAT[r["a"]]; bn, bdesc, binner = MAT[r["b"]]
    orn = ("\n\nOrnaments: " + r["orn"]) if r["orn"] else ""
    rule = "All jewelry is real opaque metal, pearl, enamel or acrylic, passing through drilled openings in the carved material" + (" (through real flesh for the lips)" if r["lipp"] else "") + ", never turning into the material, and kept clear of the eyeballs."
    p = f"""Professional fashion photograph, close-up portrait. ONE woman, her face turned about 30 degrees toward the camera, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there so no chest, arms or hands are visible. Mid 20s.

Subject: A photograph of a strikingly beautiful adult {r['nat']} woman's head and neck in {r['mk']} makeup. Living flesh exists in exactly three places on this head and nowhere else: the left eyeball, the right eyeball and the lips. Everything else — the skin under each eye, the cheeks, the nose from bridge to tip and the nostrils, the philtrum, the chin, jaw, forehead, temples, ears, the whole neck and all the hair — is carved solid transparent material with no pores or skin grain, one continuous carved sculpture like a statue's head. Split down the exact centre line of the forehead, the bridge of the nose and the parting of the hair: everything to the left, including the left side of the chin and neck down to the collarbone and all the hair on the left, is solid {adesc}, with {ainner}; everything to the right, mirrored, is solid {bdesc}, with {binner}. The area beneath each eye, each cheek, each side of the nose and each nostril is that side's material, never skin. The nose is carved material, never a real nose. The material is solid all the way through, never hollow.

Hair: {r['hair']}. It grows straight out of the carved scalp with no seam, one solid mass of the same material, parted down the centre where the two materials meet.

Eyes: only the two eyeballs are real, razor-sharp macro-quality photographed eyes: {r['eyes']}, a real wet cornea and iris with every fibre in crisp focus, a real black pupil, a fine real white with tiny vessels, a moist tear film, two bright catchlights on each cornea, {r['gaze']}, sharper than anything else in the frame. The eyelid skin, the skin beneath the eye and at the corner are carved material, with {r['lashes']}. The real eye sits in a clean seat inside the socket opening and never spreads beyond it.

Lips: the lips are the only other living flesh — one unbroken real photographed mouth, not split down the centre, soft and moist with real lip lines, {r['lips']}. The real flesh ends cleanly at the mouth corners, the philtrum above and the chin below, and the carved material begins at once — the cheek beside the mouth, the philtrum and the chin have no living skin.

Makeup in the material: it is colour inside and on the carved forms, never paint on skin. {r['makeup']}

Piercings: {r['pierce']} {rule}{orn}

Lines: a jagged wandering line runs down the exact centre of the head from the parting, down the forehead and nose bridge to the base of the nose, stopping above the lips, and starts again below the lips down the chin and throat, never crossing the lips. A second jagged line runs around the base of the neck and across both collarbones where the frame cuts off. Shards interlock along the lines only.

Head tilted slightly toward the camera, chin lifted a little. Pure pitch black background. A soft frontal light on the eyes and lips; a strong backlight through each half so the face, neck and hair glow from within; a thin cool rim light along the centre line. 2:3 vertical 8K portrait."""
    return r, an, bn, p

OUT = [build(r) for r in ROWS]
if __name__ == "__main__":
    for r, an, bn, p in OUT:
        print(r["tier"], r["ko"], an, "×", bn, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
