# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g3 = load("g3","gen3.py"); MAT = g3.MAT if hasattr(g3,'MAT') else load("g2","gen2.py").MAT
g2 = load("g2","gen2.py"); MAT = g2.MAT
REAL_FACE = "Her whole face, ears and neck are real living flesh with real pores and fine grain."

BUST_INTRO = """Professional fashion photograph, sculpted bust portrait. {plural}presented exactly in the classical convention of a carved portrait bust or herm — no arms, no hands, the shoulders tapering smoothly down into a solid, deliberately shaped base that rests on a low dark plinth barely visible in the black, the cut always the clean, polished line of a display bust, never a wound, never torn, nothing organic at the edge. {facepos}, large and sharp, filling the upper half of the frame."""

GLASS_BUST = ("The glass is unmistakably glass: thick, crystal-clear and polished, with bright specular reflections sliding along every curved surface, sharp white highlights and dark refraction edges where the walls are thickest, tiny bubbles trapped in the glass itself. The shoulders and chest keep their exact sculpted shapes as clear glass outlines, and a clean glass rim runs along the boundary where the vessel meets the neck.")

def T1_solid(desc, inner):
    return (f"Below the neck, her entire visible form — shoulders and chest — is not painted, covered or clothed but physically made of ONE solid, transparent material, solid {desc}, with {inner}. "
            f"It is carved as one continuous sculpted mass, exactly like a bust cut from a single flawless block of gemstone, never hollow, with no seam, no second material and nothing suspended within it — pure, uniform stone throughout, polished to a soft gloss.")

def T2_vessel(content):
    return (f"Below the neck, her entire visible form — shoulders and chest — is a sculpted vessel of thick, crystal-clear glass in the exact shape of a bust, filled completely to the brim so nothing is hollow and there is no air gap. {GLASS_BUST} "
            f"The vessel holds ONE single world, unbroken and continuous through the whole chest and shoulders, with no split, no second world and no change of contents anywhere: {content}")

def T3_combined(desc, inner, objects):
    return (f"Below the neck, her entire visible form — shoulders and chest — is ONE solid, continuous block of {desc}, with {inner}, carved as one uniform sculpted mass, never hollow, never split down the centre. "
            f"Yet suspended deep within this solid stone, visible through it exactly like objects frozen inside a single flawless crystal, are {objects}, each one fully embedded in the solid material with no cavity, no hollow chamber and no liquid around it — the stone itself grew solid around them. "
            f"The material reads as one unbroken solid mass throughout; the embedded shapes are simply what is visible deep inside it, not a separate vessel.")

def T4_split(descA, innerA, descB, innerB):
    return (f"Below the neck, her entire visible form — shoulders and chest — is split down the exact centre into two solid transparent materials, with nothing beneath and no skin anywhere. "
            f"Left half (left shoulder and half the chest): solid {descA}, with {innerA}. Right half: solid {descB}, with {innerB}. Each half is carved as one solid sculpted mass, never hollow, the groove between the two sides of the chest cut into the material itself.")

def T5_splitvessel(contentA, contentB):
    return (f"Below the neck, her entire visible form — shoulders and chest — is a sculpted vessel of thick, crystal-clear glass split down the exact centre, filled completely to the brim on both sides so nothing is hollow and there is no air gap. {GLASS_BUST} "
            f"The left half holds one world: {contentA} The right half holds a second, different world: {contentB}")

def boundary_single():
    return "Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below, the only place where real flesh gives way to the sculpted form. Shards interlock along this line only, every edge solid all the way through."

def boundary_split():
    return ("Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs straight down the exact centre of the chest where the two halves meet, never horizontal. "
            "Shards interlock along both lines only, every edge solid all the way through.")

def solo_prompt(sty, ear, bodyline, bodyblock, split, glow):
    n, k, f = g3.face_of(sty)
    intro = BUST_INTRO.format(plural="ONE woman's head, neck and shoulders, ", facepos="Her face is angled 45 degrees toward the camera")
    bnd = boundary_split() if split else boundary_single()
    return f"""{intro}

Subject: A real photograph of a strikingly beautiful adult {n} woman in {k} makeup — {f}. {REAL_FACE} {ear}

Physique: {bodyline}

{bodyblock}

{bnd}

Lighting: pure pitch black background. A soft frontal light on her face and ears only, keeping her natural skin tone. {glow} Only her face, ears and neck read as real skin. 2:3 vertical 8K portrait."""

def duo_prompt(sty1, sty2, ear1, ear2, body1, body2, block1, block2, split1, split2, glow1, glow2):
    n1, k1, f1 = g3.face_of(sty1); n2, k2, f2 = g3.face_of(sty2)
    intro = BUST_INTRO.format(plural="TWO women's heads, necks and shoulders standing shoulder to shoulder, ", facepos="Both faces are angled slightly toward the camera")
    bnd1 = boundary_split() if split1 else boundary_single()
    bnd2 = boundary_split() if split2 else boundary_single()
    return f"""{intro} Each woman's bust is independent, and her own material never mixes with the other's, even where their shoulders touch.

The left woman: a strikingly beautiful adult {n1} woman in {k1} makeup — {f1}. {REAL_FACE} {ear1} Physique: {body1} {block1.replace('Below the neck','Below her neck')} {bnd1.replace('Boundary:','Her boundary:')}

The right woman: a strikingly beautiful adult {n2} woman in {k2} makeup — {f2}. {REAL_FACE} {ear2} Physique: {body2} {block2.replace('Below the neck','Below her neck')} {bnd2.replace('Boundary:','Her boundary:')}

Where the two busts meet at the shoulder, the two materials press against each other and stay completely distinct, never blending or mixing.

Lighting: pure pitch black background. A soft frontal light on both faces and ears only, keeping their natural skin tones. {glow1} {glow2} Only their faces, ears and necks read as real skin. 3:4 vertical 8K portrait."""

# ================= SOLO 5 =================
# S1: single solid material, no content, no split
d,i = MAT["citrine"][1], MAT["citrine"][2]
S1 = solo_prompt("텔레노벨라 글램(멕시코·콜롬비아)",
  "On each ear a large gold hoop.",
  "A colossal, statuesque chest and broad rounded shoulders, carved on the same grand scale as the rest of the bust.",
  T1_solid(d,i), False,
  "A strong warm golden backlight from directly behind floods the whole solid citrine so it glows amber-gold from within, with sharp internal light rays and a soft halo bleeding around her silhouette; a thin warm rim light traces her shoulders.")

# S2: vessel, single content, no split
CONTENT_HIME = "a sky full of drifting cherry blossoms: countless pale pink petals and a few whole blossoms turn slowly in the clear water that fills the bust, catching the light as they drift, with plenty of perfectly clear space between them."
d2 = T2_vessel(CONTENT_HIME)
S2 = solo_prompt("히메갸루",
  "On each ear a big gold hoop with a small pearl drop.",
  "Full soft shoulders and a rounded, youthful chest.",
  d2, False,
  "A strong soft pink backlight from directly behind floods the whole glass vessel so the drifting petals glow like stained glass, with bright refraction edges along every curve of her shoulders and chest; a thin rose-gold rim light traces her silhouette.")

# S3: combined single material WITH embedded content, no split
d3desc, d3inner = MAT["amethyst"][1], MAT["amethyst"][2]
OBJ = "dozens of small, perfectly carved crystal stars and tiny five-petalled crystal flowers, each one a paler, brighter facet than the amethyst around it"
S3block = T3_combined(d3desc, d3inner, OBJ)
S3 = solo_prompt("발칸 글램(루마니아·불가리아)",
  "On each ear a thick gold hoop with a gold coin drop.",
  "A broad, powerful chest and strong sculpted shoulders on a grand, statuesque scale.",
  S3block, False,
  "A strong violet backlight from directly behind floods the whole solid amethyst so it glows deep purple, and the embedded crystal stars and flowers catch extra points of brighter light, as though each one were its own tiny lantern inside the stone; a thin lilac rim light traces her silhouette.")

# S4: split two solid materials
dA,iA = MAT["sapphire"][1], MAT["sapphire"][2]
dB,iB = MAT["ruby"][1], MAT["ruby"][2]
S4block = T4_split(dA,iA,dB,iB)
S4 = solo_prompt("걸크러시",
  "On each ear a thick black-steel hoop.",
  "A colossal, sharply sculpted chest and broad shoulders, split evenly on both sides.",
  S4block, True,
  "A strong deep-blue backlight floods the sapphire half and a strong crimson backlight floods the ruby half, each glowing from within with a hard, jewel-bright light; a thin cool rim light traces the centre seam and both shoulders.")

# S5: split two vessel contents
CA = "a coral reef: clear turquoise water filled with branching pink coral, small bright fish and a scatter of rising bubbles."
CB = "a rainforest canopy: dense green ferns, hanging orchids and a single bright macaw perched among broad wet leaves."
S5block = T5_splitvessel(CA,CB)
S5 = solo_prompt("파케앙트 글램(필리핀)",
  "On each ear a big gold hoop with a pearl.",
  "A full, rounded chest and soft broad shoulders on a grand, statuesque scale.",
  S5block, True,
  "A strong turquoise backlight floods the reef half so the coral and fish glow, and a strong green-gold backlight floods the rainforest half so the leaves and macaw glow; a thin cool rim light traces the centre seam and both shoulders.")

SOLO = [("S1","단일 투명 재질(무내용물)","텔레노벨라·시트린(통짜)",S1),
        ("S2","내용물 단일(무재질 구분, 단일 세계)","히메갸루·벚꽃잎 물(단일 유리 그릇)",S2),
        ("S3","단일 투명재질 + 내용물(비분할, 결합형)","발칸·자수정 속에 크리스털 별·꽃",S3),
        ("S4","단일 투명재질 2개(좌우 분할, 무내용물)","걸크러시·사파이어×루비색 유리",S4),
        ("S5","내용물 투명재질 2개(좌우 분할, 무재질구분)","파케앙트·산호초×열대우림",S5)]

# ================= DUO 5 =================
d_em, i_em = MAT["emerald"][1], MAT["emerald"][2]
CONT_TULIP = "a field of tulips at dawn: red, yellow and white tulips standing in clear water that fills the bust, with pale morning mist drifting low between the stems."
D1 = duo_prompt("소피아 로렌풍(이탈리아)","웨이쉰",
  "On each ear a large real pearl drop with a gold clip.","On each ear a big rose-gold hoop.",
  "A full, elegant chest and soft rounded shoulders.", "A soft, youthful chest and gently sloped shoulders.",
  T1_solid(d_em,i_em), T2_vessel(CONT_TULIP), False, False,
  "A strong deep-green backlight floods the emerald woman so she glows from within, with sharp jewel-bright highlights along her shoulders.",
  "A strong soft rose backlight floods the tulip woman's glass vessel so the flowers glow like stained glass along her shoulders.")

d_ambD, i_ambD = MAT["amber"][1], MAT["amber"][2]
d_jd, i_jd = MAT["jade"][1], MAT["jade"][2]
OBJ2 = "a dozen tiny carved crystal fireflies and small five-pointed crystal stars, each one glowing a shade brighter than the amber around it"
D2 = duo_prompt("노르딕 발키리(노르웨이)","강남언니",
  "On each ear a thick silver knotted hoop.","On each ear a big rose-gold hoop.",
  "A powerful, broad chest and strong statuesque shoulders.", "An elegant, refined chest and soft narrow shoulders.",
  T3_combined(d_ambD,i_ambD,OBJ2), T1_solid(d_jd,i_jd), False, False,
  "A strong warm golden backlight floods the amber woman so the embedded fireflies and stars glow like tiny lanterns inside the stone.",
  "A strong soft green backlight floods the jade woman so she glows from within, smooth and uniform.")

CONT_DEEP = "the deep sea: dark teal water filled with a few large glowing jellyfish drifting slowly, their long tendrils trailing through the clear water that fills the bust."
d_opl, i_opl = MAT["opal"][1], MAT["opal"][2]
OBJ3 = "a scatter of tiny carved crystal moths and pale crystal moons, each one catching its own soft point of light inside the milky stone"
D3 = duo_prompt("요루바 신부 화장(나이지리아)","야마바",
  "On each ear a big gold hoop with a red-enamel bead.","On each ear a big neon-acrylic hoop and a small silver star stud.",
  "A colossal, rounded chest and broad soft shoulders.", "A full, youthful chest and rounded shoulders.",
  T2_vessel(CONT_DEEP), T3_combined(d_opl,i_opl,OBJ3), False, False,
  "A strong teal-blue backlight floods the deep-sea vessel so the jellyfish glow softly through the water.",
  "A strong milky-white backlight floods the opal woman so she glows with soft internal flashes of colour, and the embedded moths and moons catch their own brighter points of light.")

dA2,iA2 = MAT["jade"][1], MAT["jade"][2]
dB2,iB2 = MAT["ruby"][1], MAT["ruby"][2]
CONT_GAL = "a weightless galaxy: thousands of tiny bright stars and thin glowing ribbons of violet and rose nebula suspended in the clear glass, with a pale crescent moon drifting among them."
D4 = duo_prompt("홍콩풍","코갸루",
  "On each ear a large vintage pearl clip earring.","On each ear a big silver hoop with a small turquoise-enamel bead.",
  "An elegant, statuesque chest and soft sculpted shoulders, split evenly down the centre.", "A bright, youthful chest and rounded shoulders.",
  T4_split(dA2,iA2,dB2,iB2), T2_vessel(CONT_GAL), True, False,
  "A strong green backlight floods her jade half and a strong crimson backlight floods her ruby half, each glowing from within with a hard, jewel-bright light.",
  "A strong violet-blue backlight floods the galaxy woman's glass vessel so the stars and nebula glow softly through her shoulders and chest.")

CA2 = "a sun-drenched savanna at midday: golden grass and a single acacia tree standing in clear amber-tinted air that fills the bust, with a pale sun overhead."
CB2 = "a starlit night: deep indigo sky filled with countless tiny stars and a low crescent moon, clear and cold."
d_cit,i_cit = MAT["citrine"][1], MAT["citrine"][2]
D5 = duo_prompt("하베샤 화장(에티오피아·에리트레아)","로리타 갸루",
  "On each ear a big silver filigree hoop.","On each ear a big silver hoop.",
  "A full, rounded chest and broad soft shoulders, split evenly down the centre by day and by night.", "A sweet, youthful chest and rounded shoulders.",
  T5_splitvessel(CA2,CB2), T1_solid(d_cit,i_cit), True, False,
  "A strong warm gold backlight floods her day half and a strong deep-blue backlight floods her night half, each glowing softly through the vessel.",
  "A strong warm golden backlight floods the citrine woman so she glows amber from within, smooth and uniform.")

DUO = [("D1","단일재질(에메랄드) + 내용물단일(튤립밭)","소피아 로렌풍 + 웨이쉰",D1),
       ("D2","결합형(호박+반딧불이) + 단일재질(비취)","노르딕 발키리 + 강남언니",D2),
       ("D3","내용물단일(심해) + 결합형(오팔+나방·달)","요루바 신부 + 야마바",D3),
       ("D4","분할재질(비취×루비) + 내용물단일(은하)","홍콩풍 + 코갸루",D4),
       ("D5","분할내용물(사바나×별밤) + 단일재질(시트린)","하베샤 + 로리타 갸루",D5)]

ALL = [(n,t,d,p,'solo') for n,t,d,p in SOLO] + [(n,t,d,p,'duo') for n,t,d,p in DUO]
if __name__ == "__main__":
    for n,t,d,p,kind in ALL:
        assert not re.search(r'[\uac00-\ud7a3]', p), n
        print(n, kind, t, len(p.split()))
