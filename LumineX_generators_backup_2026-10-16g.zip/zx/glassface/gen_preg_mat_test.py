# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_preg_geo_test.py', encoding='utf-8').read().split("\nDUP = re.compile")[0])     # 임산부 상수·STABLE_BODIES·person_preg·build_new ...
exec(open('gen_matblend_geo.py', encoding='utf-8').read().split("\nold = {")[0])               # mat_text, pick_mats_nosw, hazy_mat, MAT_KO ...
rnd.seed(20261015)
def pct(lo, hi, step=1): return rnd.randrange(lo, hi+1, step)
DUPFIX = re.compile(r"\b(VIVID|BLAZING|extreme|dense|formations) \1\b")
def dd(t):
    while True:
        t, n = DUPFIX.subn(r"\1", t)
        if not n: return t
def pick_noUV(n):
    while True:
        m = pick_mats_nosw(n)
        if "uvneon" not in m: return m          # UV네온은 전용 블랙라이트가 필요해 임산부 포맷(차콜 배경)과 충돌하므로 이번 시험에서 제외

def person_pm(label, makeup, bodykey, n, kind, shape, solo):
    nat, fa = face_nohair(makeup)
    row = rnd.randrange(len(D["makeup"]))
    age = AGE_EN_FULL[D["age"][row]]; vibe = VIBE_EN_FULL[D["vibe"][row]]; shoe = SHOE_EN_FULL[D["shoe"][row]]
    pierce = pierce_phrase(D["pierce_p"][row],D["pierce_c"][row],D["pierce_g"][row],D["pierce_f"][row],D["pierce_s"][row],D["pierce_m"][row])
    jewelry = f"{JQ_SHORT[D['jq'][row]]} of {JMETAL_EN[D['jmetal'][row]]} {JTYPE_EN[D['jtype'][row]]}"
    hair = f"{HAIR_COLOR_EN_FULL[rnd.choice(T.HAIR_COLOR)]} hair styled in {HAIR_EN_FULL[rnd.choice(T.HAIR_STYLE)]}"
    bodytext = ALL_PREG[bodykey].replace("a high, smoothly rounded pregnant belly", f"a high, smoothly rounded pregnant belly, {BELLY_BOOST},", 1)
    pose = rnd.choice(POSES)
    mats = pick_noUV(n); texts = [mat_text(m)[0] for m in mats]
    pre, reg, lab = make_structure(kind, n, shape); assert sens_count(pre+" "+" ".join(reg)) == 0
    sents = " ".join(f"Region {i+1} is {reg[i]}: it carries {texts[i]}." for i in range(n))
    body = (f"{'Full body fused' if solo else 'Fused'} with {n} different materials instead of ordinary skin below the collarbones, each material claiming its own region of her figure, covering every inch from neck to ankle without exception, the materials reading as one continuous second skin with no gaps. "
            f"{pre} {sents} {hazy_mat(shape, STRUCT_KIND[kind])} The materials of every region curve fully around her belly like contour lines circling a globe, the rounded surface of her belly staying fully covered as part of whichever region it falls in, with the same density continuing in full strength over her bust, nowhere on her body left bare, no fabric no seam no garment anywhere. ")
    head = (f"{nat} woman, an adult, in her {age}, {vibe} expression" if solo else f"{label}: {nat}, in her {age}, {vibe} expression")
    block = (f"{head}, warm radiant skin tone, extraordinarily large pregnant physique far beyond any real person — {bodytext} "
             f"Her face is a real living adult face, {fa}, {hair}, real pores, real living eyes, {pierce}, wearing {jewelry}. {body}"
             f"Pose: {pose}, " + (f"her whole silhouette filling the frame from head to her {shoe}, the platform soles rising far higher than her ankle bone." if solo else f"her {shoe}, the platform soles rising far higher than her ankle bone."))
    return block, f"{STRUCT_KO[kind]}·{'물결' if shape=='undulating' else '매끈'}", f"{bodykey}/{makeup}", "+".join(MAT_KO[m] for m in mats)

def build_pm(gsize, n, mk):
    bodies = rnd.sample(STABLE_BODIES, gsize); cells = draw_cells(gsize); blocks=[]; descs=[]
    for i in range(gsize):
        b, st, who, ms = person_pm(f"#{i+1}", mk[i], bodies[i], n, cells[i][0], cells[i][1], gsize==1)
        blocks.append(b); descs.append(f"[{st} / {who} / {ms}]")
    if gsize == 1:
        p = (f"Professional fashion photograph, full body shot. ONE woman standing or kneeling as described.\n\nSubject: {blocks[0]}\n\nBackground: a plain seamless deep-charcoal backdrop, nothing else in frame. Lighting: a single hard key light raking in from one side, sharp focus head to toe, realistic photographic grain, a real photograph not an illustration not CGI not a render. Pattern density maximum, zero bare skin from neck to ankle. 2:3 vertical 8K portrait, taller than it is wide.")
    else:
        p = (f"Professional fashion photograph, full body shot. {NUM_WORD[gsize]} women standing side by side, each an extraordinarily large pregnant woman, far beyond any real person.\n\n" + "\n\n".join(blocks) +
             f"\n\nBackground: a plain seamless deep-charcoal backdrop, nothing else in frame. Composition: each woman's own pose as described, inner arms not crossing her neighbours, generous spacing so every figure reads clearly. Lighting: a single hard key light raking across all of them from one side, sharp focus head to toe on each, realistic photographic grain, a real photograph not an illustration not CGI not a render. Pattern density maximum, zero bare skin from neck to ankle on any of them. Shot on a Hasselblad X2D, {ASPECT[gsize]} aspect ratio, 8K.")
    return p, " ; ".join(descs)

items=[]; k=0; MK = rnd.sample(T.MAKEUP_48, 18)
for gsize, n in [(1,3),(1,4),(1,3),(2,3),(2,4),(2,4),(3,3),(3,3),(3,4)]:
    p, desc = build_pm(gsize, n, MK[k:k+gsize]); k += gsize
    p = dd(p); validate(f"pm_{gsize}_{n}", p)
    assert not re.search(r'(?<!corset-)\blace\b(?!-up)', p.lower()) and "UV" not in p
    assert not [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", p) if m.group(1).lower() not in ("had","that")], desc
    items.append(("새 방식(재질)", gsize, n, desc, p))
bund = {x["key"]: x for x in json.load(open("la_pregblend_geo_180_bundle.json", encoding="utf-8"))}
for tn, mixn, gs in [("solo",4,1),("duo",3,2),("trio",4,3)]:
    key = f"la_pregblend{mixn}_{tn}_{rnd.randrange(1,31):02d}"; x = bund[key]
    items.append(("등록분(공예)", gs, mixn, f"{key} — 구조: {' / '.join(x['meta']['structures'])}", x["prompt"]))
assert len(items)==12
order=list(range(12)); rnd.shuffle(order); no={i:order.index(i)+1 for i in range(12)}; ranked=sorted(range(12), key=lambda i:no[i])
GN={1:"솔로",2:"듀오",3:"트리오"}
L=["# LumineX · 임산부 몸에 재질 섞기 시험 12개\n",
   "새 방식(재질) 9개(솔로 3·듀오 3·트리오 3, 재질 3~4종)와 방금 등록한 임산부 블렌드(공예 버전) 3개(대조군)를 섞어 번호를 붙였습니다. 임산부 문장 구조는 같고, 공예 패턴 대신 재질이 들어간 것만 다릅니다. **성공/실패만** 알려주세요(최대 3회, 1회/2회/3회/실패). 예: `03: 2회 / 07: 실패 / 나머지 1회`\n",
   "## 색인\n","| 번호 | 구분 | 인원 | 구역 수 | 구성 (구조·경계선 / 체형 / 메이크업 / 재질) |","|---|---|---|---|---|"]
for i in ranked:
    g,gs,n,desc,p = items[i]; L.append(f"| {no[i]:02d} | {g} | {GN[gs]} | {n} | {desc} |")
L.append("")
for i in ranked:
    g,gs,n,desc,p = items[i]; L.append(f"## {no[i]:02d}. {g} · {GN[gs]}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_PregMaterial_Test_12.md","w",encoding="utf-8").write("\n".join(L))
json.dump([{"no":no[i],"kind":items[i][0],"gsize":items[i][1],"n":items[i][2],"desc":items[i][3]} for i in ranked], open("/home/claude/pregmat_test_meta.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
print("12개 저장")
for gs in [1,2,3]:
    nw=[len(it[4].split()) for it in items if it[0].startswith("새") and it[1]==gs]; rg=[len(it[4].split()) for it in items if it[0].startswith("등록") and it[1]==gs]
    print(f"  {GN[gs]}: 새 방식 {nw} / 대조군 {rg}")
print("대조군 번호:", [(no[i], items[i][3].split(' — ')[0]) for i in ranked if items[i][0].startswith('등록')])
for i in ranked:
    if items[i][0].startswith("새"): print(f"  {no[i]:02d} {GN[items[i][1]]} {items[i][2]}구역 | {items[i][3][:120]}")
