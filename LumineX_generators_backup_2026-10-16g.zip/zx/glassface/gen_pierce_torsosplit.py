# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_pierce_mixstatue2.py', encoding='utf-8').read().split("\nspecs = [")[0])
def kinds_of(n): return rnd.sample(["stone", "wood", "T1", "T3"], n)
def torso_split(orient):
    lv = spaced(2, 28, 78, 22)
    if orient == "H":
        pre = f"The torso, from the underarm line down to where the thighs begin, is divided into 3 stacked pieces by 2 straight horizontal seams, about {lv[0]}% and {lv[1]}% of the way down it."
        names = ["Torso piece 1 (the topmost piece, above the first seam)", "Torso piece 2 (the middle piece, between the two seams)", "Torso piece 3 (the lowest piece, below the second seam, reaching the bottom of the torso)"]; ko = "가로 3단"
    elif orient == "V":
        pre = f"The torso, from the underarm line down to where the thighs begin, is divided into 3 side-by-side pieces by 2 straight vertical seams, about {lv[0]}% and {lv[1]}% of the way across it from the left of the picture to the right."
        names = ["Torso piece 1 (the piece on the left of the picture, left of the first seam)", "Torso piece 2 (the middle piece, between the two seams)", "Torso piece 3 (the piece on the right of the picture, right of the second seam)"]; ko = "세로 3등분"
    else:
        d, dk = rnd.choice(DIRS)
        pre = f"The torso, from the underarm line down to where the thighs begin, is divided into 3 diagonal pieces by 2 parallel straight diagonal seams running {d} as seen by the camera, crossing the centre line of the torso about {lv[0]}% and {lv[1]}% of the way down it."
        names = ["Torso piece 1 (the piece above the first diagonal seam)", "Torso piece 2 (the diagonal band between the two seams)", "Torso piece 3 (the piece below the second diagonal seam, reaching the bottom of the torso)"]; ko = f"대각 3조각({dk})"
    assert sens_count(re.sub(r"\btorso\b|\bthighs\b", "", (pre + " " + " ".join(names)).lower())) == 0, (pre, names)
    return pre, names, ko
def build(frame, P, method, orient):
    pname, pos, part = FR[frame]
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC)+1)
    M = pick_metal(ci); G = rnd.choice(GEMS); F = rnd.choice(FORMS); phys = rnd.choice(PHYS); (ba, bb) = rnd.choice(BACKS)
    hair = f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}"
    def p200s(M):
        t = g18.T150.replace("about one hundred and fifty", "about two hundred").replace("covering the face and neck", "covering the face, neck and shoulders").replace("ten fine gold chains", "twelve fine gold chains")
        t = t.replace("; and twelve fine", "; a row of six small gold studs along each collarbone and a small gold stud on each shoulder; and twelve fine")
        return recolor(t, M)
    pierce = conc_chest(P, M, F) if method == "집중형" else (p200s(M) if P == "P200" else recolor({"P50": g18.T50, "P100": g18.T100, "P150": g18.T150}[P], M))
    dense = P in ("P100", "P150", "P200")
    arms = rnd.sample(["stone", "wood", "T1"], 2); th = ["T2", rnd.choice(["stone", "wood", "T1", "T3"])]; rnd.shuffle(th)
    limbs = {"Left arm": arms[0], "Right arm": arms[1], "Left thigh": th[0], "Right thigh": th[1]}
    st = {"stone": rnd.choice(STONES), "wood": rnd.choice(WOODS), "T1": rnd.choice(HIGHCLEAR), "T3": (rnd.choice(["sapphire", "cobalt", "amethyst", "citrine"]), rnd.choice(list(OBJECTS))), "water": rnd.choice(WATER), "world": rnd.choice(THIGH_WORLD)}
    st2 = {"stone": rnd.choice([x for x in STONES if x != st["stone"]]), "wood": rnd.choice([x for x in WOODS if x != st["wood"]]), "T1": rnd.choice([x for x in HIGHCLEAR if x != st["T1"]]),
           "T3": (rnd.choice(["sapphire", "cobalt", "amethyst", "citrine"]), rnd.choice(list(OBJECTS))), "water": st["water"], "world": st["world"]}
    texts = {}; labels = {}
    for pt, kd in limbs.items(): texts[pt], labels[pt] = part_text(pt, kd, st)
    tkinds = kinds_of(3); pre, pnames, tko = torso_split(orient)
    ttexts = []; tlabels = []
    for kd in tkinds:
        s_, l_ = part_text("Torso piece", kd, st2); ttexts.append(s_); tlabels.append(l_)
    tip_solid = "ends in its own smooth, deeply polished rounded tip, finished the way a carved sculpture is finished"
    summary = (f"her left arm {TXT[limbs['Left arm']]}, her right arm {TXT[limbs['Right arm']]}, her torso split into three pieces ({TXT[tkinds[0]]}, {TXT[tkinds[1]]} and {TXT[tkinds[2]]}), her left thigh {TXT[limbs['Left thigh']]} and her right thigh {TXT[limbs['Right thigh']]}")
    phys2 = phys.rstrip(".") + f", {summary}."
    def leg(pt, side):
        extra = "" if limbs[pt] == "T2" else f" The {side} thigh {tip_solid}."
        return f"{pt} (hip down to its tip, {pos}): {texts[pt]}{extra}"
    NECK = ("A single straight, horizontal line runs across her body at underarm height, level with both armpits. Real skin above this line — her face, neck, both shoulders, and the very tops of both upper arms. "
            "Below this line, completely different materials meet at her body's natural joints (both shoulders, both hips) and at the seams inside the torso, each keeping its own distinct appearance right up to where it touches its neighbour, never blending into it. "
            "At the underarm line itself, the material immediately below rises in a small raised step above her skin, casting a crisp shadow. Shards interlock along this line only.")
    torso_block = f"Torso (underarm line down to where the thighs begin): {pre} " + " ".join(f"{pnames[i]}: {ttexts[i]}" for i in range(3))
    opaque = [k for k, kd in limbs.items() if kd in ("stone", "wood")] + [f"torso piece {i+1}" for i, kd in enumerate(tkinds) if kd in ("stone", "wood")]
    clear = [k for k, kd in limbs.items() if kd not in ("stone", "wood")] + [f"torso piece {i+1}" for i, kd in enumerate(tkinds) if kd not in ("stone", "wood")]
    metal_phrase = "mixed metal (yellow gold, silver, copper and rose gold, alternating piece by piece)" if M == "MX" else ("rose gold" if M == "MR" else MN[M].replace("-", " "))
    p = (f"Professional fashion photograph, {pname.replace(' portrait','')} multi-material portrait: real face and neck, and a sculpted body made of different materials — {summary}. ONE woman, angled 45 degrees toward the camera, framed so her whole sculpted form is visible from the top of her head down to two individually rounded, deliberately carved tips {pos}, her face in natural scale with her body — never an oversized close-up crop of just the face. Where her sculpted form comes to an end at her {part}, it is because the sculpture itself ends there, not because a camera frame happens to cut her off.\n\n"
         f"Subject: A real photograph of a strikingly beautiful adult {nat} woman — {fa}, {hair}. {REAL_FACE}\n\n"
         f"Piercings: {pierce}{DENS if dense else ''}{gem_text(G) if method == '집중형' else ''} {CARE2.format(metal=metal_phrase)}\n\n{DEPTH}\n\n"
         f"Physique: {phys2}\n\nBoundary (skin to material, at underarm height): {NECK}\n\n"
         f"Left arm (shoulder to hand): {texts['Left arm']}\n\nRight arm (shoulder to hand): {texts['Right arm']}\n\n{torso_block}\n\n{leg('Left thigh', 'left')}\n\n{leg('Right thigh', 'right')}\n\n"
         f"Where each material meets its neighbour (left shoulder, right shoulder, left hip, right hip, and every seam inside the torso), the two distinct materials sit flush against each other with a thin, clean seam, deliberate and precise, never jagged, torn or blended — always the finish of a sculpture, each material keeping its own colour, clarity and surface completely separate from the one beside it. Both thighs stay clearly separate all the way down, never merging into a single base, both rounded tips resting side by side on the surface beneath her.\n\n"
         f"Setting: a huge backdrop behind her washed with two coloured lights from behind — {ba} on one side and {bb} on the other, blending into a smooth gradient in the middle — glowing evenly, marked with a few thin dark vertical lines so the bending of those lines is visible wherever the body is transparent, and a glossy dark floor beneath her.\n\n"
         f"Pose: standing tall, body angled 45 degrees, her left hand resting on her flared hip, her right arm held clear of her body with the hand relaxed at hip height, both hands well away from her face, head tilted slightly toward the camera.\n\n"
         f"Lighting: two large softboxes rake across her body from either side, so {ba} light glances off the left half and {bb} light glances off the right half — passing straight through the transparent parts ({', '.join(x.lower() for x in clear)}), while only reflecting off the opaque parts ({', '.join(x.lower() for x in opaque)}). A soft frontal light falls on her face and ears. Shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait.")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    _d = [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", p)]
    assert not re.search(r"[가-힣]", p) and not _d, (frame, P, _d)
    if M not in ("MG", "MR", "MX"): assert "gold" not in pierce.lower(), (frame, P, M)
    parts_ko = f"왼팔 {labels['Left arm']} · 오른팔 {labels['Right arm']} · 몸통 [{tko}] {tlabels[0]} / {tlabels[1]} / {tlabels[2]} · 왼허벅지 {labels['Left thigh']} · 오른허벅지 {labels['Right thigh']}"
    desc = f"{re.sub(r'^[A-Z]+', '', HS[si-1])} · {re.sub(r'^[A-Z]+', '', HC[ci-1])} · 메이크업 {mk} · 금속 {MKO[M]}"
    return p, desc, parts_ko
specs = []
