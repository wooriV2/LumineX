# -*- coding: utf-8 -*-
import re, sys, random, json
exec(open('mk_blendnew.py', encoding='utf-8').read().split("items = []")[0])
rnd.seed(20261701)
out = []
for i in range(8):
    kind = rnd.choice(["V", "D", "C", "R"]); shape = rnd.choice(["smooth", "undulating"]); n = 3
    for _ in range(100):
        mats = pick_mats(n); texts = [mat_text(m)[0] for m in mats]
        pre, reg, lab = make_structure(kind, n, shape)
        if sens_count(pre + " " + " ".join(reg)) != 0: continue
        sents = " ".join(f"Region {j+1} is {reg[j]}: it carries {texts[j]}." for j in range(n))
        uv = "uvneon" in mats
        light = " A standard hard key light illuminates most of her body; a separate dedicated UV blacklight illuminates the UV-reactive region specifically, making it glow at full intensity while the rest reads under normal light." if uv else ""
        core = (f"her body carries {n} different materials at once, each claiming its own region of her figure. {pre} {sents} {hazy_mat(shape, STRUCT_KIND[kind])}, no fabric no seam no garment anywhere, every material fused to or erupting from her own living skin, covering her completely with no bare skin anywhere from neck to ankle.{light}")
        if re.search(r"[가-힣]", core) or re.search(r"\b(\w+) \1\b", core): continue
        break
    out.append(dict(core=core, mats=[MAT_KO[m] for m in mats], rhine="rhine" in mats, struct=f"{STRUCT_KO[kind]}·{'물결' if shape=='undulating' else '매끈'}"))
json.dump(out, open("/tmp/claude-0/-home-claude/62db5eea-2487-540b-9935-a7df06448e2a/scratchpad/bk/cores8.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for o in out: print(o["struct"], o["mats"], len(o["core"].split()))
