# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g3 = load("g3","gen3.py"); g6 = load("g6","gen6.py"); g9 = load("g9","gen9.py"); g10 = load("g10","gen10.py")

DENS = " The piercings are packed so densely that the rows touch and overlap, leaving only hairline gaps of bare skin between them, until the face reads as a single armour of metal; the eyes and eyelids stay clear."
CARE = "All jewelry is real {metal}, sitting in real skin that is healed, clean and calm — no blood, no redness, no swelling, no wound — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes."
CHARM_RULE = " All charms are light, small and generic (no branded or licensed characters), hanging from the rings on short fine chains, never pulling the skin, none near the eyes or brows, and none hanging lower than the collarbones."

# ---- 피어싱 문구 ----
T8 = ("On each ear a gold knot-shaped drop with a red-enamel bead, a small gold hoop, a small pearl stud and a tiny gold stud.")
T25 = ("A thin rose-gold septum ring hangs below the nose with a smaller ring above it, and a rose-gold ring passes through each nostril; two thin rose-gold bars pass through the outer end of each eyebrow; a rose-gold Medusa stud sits above the lips; "
       "a rose-gold hoop passes through the lower lip's edge with a snake-bite ring on each side and one small ring beside it; a rose-gold labret stud and one ring pass through the chin; one small rose-gold stud sits on each jaw; "
       "on each ear a big rose-gold hoop, a thick bar, a helix ring and a small stud.")
T50 = g6.V["pierce"].replace("black-steel", "yellow-gold")
T100 = g9.P100.replace("black-steel", "silver")
T150 = g10.P150.replace("black-steel ", "").replace(
    "about one hundred and fifty real metal piercings covering the face and neck",
    "about one hundred and fifty real piercings in black steel and silver, alternating piece by piece, covering the face and neck")

K1_CH = (" From the ear hoops (three on each ear), from the big lower-lip hoop, from the nose ring and from the chin ring hang about ten small light charms on short fine chains — a tiny star, a heart, a ribbon bow, a small teddy-bear charm, a short bead string, a small acrylic letter tag and a rhinestone bottle in pastel enamel and acrylic — each swinging clear of the face." + CHARM_RULE)
K2_CH = (" From the ear hoops (three on each ear), from the big lower-lip hoop, from the nose ring and from the chin ring hang about twenty small light charms on short fine chains — tiny stars, hearts, ribbon bows, small teddy-bear charms, bead strings, pearl strings, small bells, safety pins, feathers, tassels, acrylic letter tags and rhinestone bottles in pastel enamel, acrylic and pearl — each swinging clear of the face. A fine chain curtain hangs in loops from the ear hoops along the jawline, never across the cheeks or eyes, and a thin chain is draped over the hair from ear to ear." + CHARM_RULE)

# ---- 스타일 ----
def face(name):
    return g3.face_of(name)
Y2K = ("Korean", "Y2K retro",
 "fair ivory skin, bright baby-blue and lavender eyeshadow spread across the whole lid up to the brow bone, silver pearl glitter on the lids, very thin high-arched brows, long lashes, large eyes with bright real catchlights, glossy frosted-pink lips, a small glitter highlight on the cheekbones, long straight silver-lilac hair with two thin front strands, a playful pout")

SPEC = [
 ("8",  "한복 화보(연지곤지)", T8,   "금 + 진주 + 붉은 에나멜", "gold with pearl and red enamel", False, ""),
 ("25", "강남언니",           T25,  "로즈골드", "rose gold", False, ""),
 ("50", "글래머러스 파티",    T50,  "옐로 골드", "yellow gold", False, ""),
 ("100","걸크러시",           T100, "은", "silver", True, ""),
 ("150","뱀파이어 다크",      T150, "검은 스틸 + 은", "black steel and silver", True, ""),
 ("K1", "Y2K 레트로",         T50.replace("yellow-gold","silver"), "은 + 파스텔 참", "silver with pastel enamel and acrylic charms", False, K1_CH),
 ("K2", "인형 메이크업",      T100.replace("silver ", "").replace("about one hundred real metal piercings covering the face", "about one hundred real piercings in gold and silver, alternating piece by piece, with a few pearl studs among them, covering the face"), "금·은 + 진주 + 참 다수", "gold, silver and pearl with many small charms", True, K2_CH),
]

OUT = []
for tier, sty, pierce, label, metal, dense, charms in SPEC:
    if sty == "Y2K 레트로":
        nat, mk, fc = Y2K
    else:
        nat, mk, fc = face(sty)
    text = pierce + charms + (DENS if dense else "")
    p = f"""Professional fashion photograph, close-up beauty portrait. ONE woman, her face turned about 30 degrees toward the camera, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}. Real pores and fine skin grain, real living eyes with bright catchlights and genuine depth, individual hair strands catching the light — a photograph of a real face, not an illustration, not a render, not cel-shaded.

Piercings: {text} {CARE.format(metal=metal)}

Lighting: a soft frontal beauty light on the face with a thin cool rim light along the hair, pure pitch black void background, shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait."""
    OUT.append((tier, sty, label, p))

if __name__ == "__main__":
    for t, s, l, p in OUT:
        print(t, s, l, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
