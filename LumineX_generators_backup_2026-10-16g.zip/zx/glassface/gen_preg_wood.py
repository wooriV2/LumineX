# -*- coding: utf-8 -*-
import re, sys, random
sys.path.insert(0,'.')
from full_dicts import face
from body_full import BODY_PREGNANT, BODY_PREGNANT_MORE

banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","safety pin","gash","crack"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    hits = [w for w in banned if w in p.lower()]
    assert not hits, (name,hits)

ALL_PREG = {**BODY_PREGNANT, **BODY_PREGNANT_MORE}
PREG_KEYS = list(ALL_PREG.keys())
BELLY_BOOST = "larger and more dramatically rounded than an ordinary full-term pregnancy, projecting forward well beyond the line of her own chest"

WOOD = {
 "walnut": "rich dark walnut wood grain, BLAZING deep warm-brown grain with VIVID honey-gold highlight streaks",
 "oak": "pale golden oak wood grain, BLAZING warm honey-blonde grain with VIVID amber highlight streaks",
 "mahogany": "rich reddish mahogany wood grain, BLAZING deep red-brown grain with VIVID copper highlight streaks",
 "ebony": "deep black ebony wood grain, BLAZING glossy jet-black grain with VIVID dark-brown highlight streaks",
}
WOOD_KO = {"walnut":"월넛","oak":"오크","mahogany":"마호가니","ebony":"에보니"}
WOODKEYS = list(WOOD.keys())

MAKEUP = ['락혼글램','강남언니','구풍','인스타글램','아마갸루','스페인플라멩코글램','BollywoodGlam','글래머러스파티','홍콩풍']

rnd = random.Random(9988)

def face_c(sty):
    custom = {"락혼글램":("American","bold smoky eyes, a deep red lip, edgy rock-and-roll glam"),
              "아마갸루":("Japanese","dark tan skin, heavy white eyeliner, glittery eyeshadow, a glossy pale lip"),
              "글래머러스파티":("American","bold smoky eyes, a glossy nude lip, glamorous party makeup")}
    if sty in custom: return custom[sty]
    return face(sty)

def wood_person(idx, label, woods):
    nat, fa = face_c(MAKEUP[idx % 9])
    bodykey = PREG_KEYS[idx % len(PREG_KEYS)]
    bodytext = ALL_PREG[bodykey].replace("a high, smoothly rounded pregnant belly", f"a high, smoothly rounded pregnant belly, {BELLY_BOOST},", 1)
    n = len(woods)
    texts = [WOOD[w] for w in woods]
    prefix = f"{label} woman" if label else "Subject"
    lp = f"{label} woman's " if label else ""
    if n == 2:
        zones = f"her upper body (collarbones to waistline, including her bust) carries {texts[0]}. From her waistline down over her belly and both legs to the ankle carries {texts[1]}. Rather than a sharp boundary, the two wood grains blend gradually into each other across her waistline, each grain's streaks scattering into the other's territory, density fading rather than stopping abruptly"
    else:
        zone_sent = " ".join(f"{texts[i]} dominates zone {i+1}." for i in range(n))
        zones = f"her body carries {n} different wood grains at once, each claiming roughly an equal irregular share of her body — one zone wrapping her belly as its own centrepiece — rather than any straight line. {zone_sent} Wherever any two zones meet, the boundary is soft and diagonal rather than a straight line, the grains blending gradually across an irregular border a few inches wide"
    return (f"{prefix}: {nat}, in her early-to-mid 30s, confident radiant expression, warm skin tone, extraordinarily large pregnant physique far beyond any real person — {bodytext} Her face is a real living adult face, {fa}, long dark wavy hair, real pores, real living eyes. {lp}body is fused with real wood instead of ordinary skin below the collarbones: {zones}, every grain following the true curve of her body and belly, no fabric no seam no garment anywhere, covering her completely with no bare skin anywhere from neck to ankle. {lp}pose: standing frontal, both hands cradling the underside of her belly, the different wood zones clearly visible across her body.\n"
            f"{lp}footwear: extreme platform heels carved from the same blended wood grains.")

NUM_WORD = {1:"ONE",2:"TWO",3:"THREE"}
ASPECT = {1:"2:3",2:"3:4",3:"4:5"}
LABELS3 = ["Left","Center","Right"]

def build(gsize, woods_per_person, seed_base):
    labels = LABELS3[:gsize] if gsize>1 else [None]
    blocks = [wood_person(seed_base+i, labels[i], woods_per_person[i]) for i in range(gsize)]
    body = "\n\n".join(blocks)
    if gsize == 1:
        return f"""Image format: a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide.

A full-body photograph on a plain seamless deep-charcoal backdrop, shot on a medium format camera with an 85mm lens at f/8, a single hard key light raking in from one side, sharp focus from head to toe, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.

{body}

Background & Lighting: the blended wood grains reading crisp and warm against the raking light, every streak and transition carved clearly across her belly and curves.

Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide. portrait 2:3 vertical."""
    else:
        return f"""Image format: a landscape-orientation photograph, {ASPECT[gsize]} aspect ratio.

A photograph of {NUM_WORD[gsize]} pregnant women standing side by side on a plain seamless deep-charcoal backdrop, 50mm lens at f/8, a single hard key light raking across all of them from one side, sharp focus head to toe on each — a real photograph, not an illustration, not CGI, not a render.

{body}

Composition: each woman's own pose, inner arms not crossing her neighbours, all faces toward the camera.

Lighting: the blended wood grains reading crisp and warm against the raking light on each woman. Shot on a Hasselblad X2D, {ASPECT[gsize]} 8K."""

rnd = random.Random(44556)
GNAME = {1:"솔로",2:"듀오",3:"트리오"}
OUT = []
seed = 0
for mixn in [2,3,4]:
    for gsize in [1,2,3]:
        woods_per_person = []
        for i in range(gsize):
            woods = rnd.sample(WOODKEYS, min(mixn,4))
            woods_per_person.append(woods)
        p = build(gsize, woods_per_person, seed)
        seed += gsize
        check(f"pw_{mixn}_{gsize}", p)
        desc = " / ".join("+".join(WOOD_KO[w] for w in ws) for ws in woods_per_person)
        OUT.append((f"{mixn}개 목재혼합 {GNAME[gsize]}(임산부) — {desc}", p))

for label,p in OUT:
    print(label, len(p.split()))

L = ["# LumineX · 임산부 — 목재만 2/3/4종 혼합 솔로·듀오·트리오 각 1개\n"]
for label,p in OUT:
    L.append(f"## {label}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_Pregnant_WoodOnly_Mix_9.md","w",encoding="utf-8").write("\n".join(L))
print("saved", len(OUT))
