# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
spec = importlib.util.spec_from_file_location("g3","gen3.py"); g = importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(io.StringIO()):
    spec.loader.exec_module(g)
MAT, face_of = g.MAT, g.face_of

BODY = {
 "colo": ("콜로설","A towering giantess on an even scale at full head-to-toe height — massive rounded shoulders, huge thick arms, a colossal full chest, a broad heavy torso with a large smooth rounded belly, wide solid hips, enormous columnar thighs running long into thick calves and long legs to the floor. No single part stands out more than another."),
 "bust": ("바스트 퀸 BBW","A towering woman standing full height on long legs, never short or squat. A colossal chest far wider than her shoulders, each rounded half reaching past the outer line of her arms and resting on a big rounded belly, broad soft shoulders, thick heavy arms, soft wide hips and colossal soft thighs running long into thick calves."),
 "hgu": ("아워글래스 USSBBW","A towering hourglass woman of extraordinary volume standing tall on long legs, never short or squat. A colossal heavy chest wider than her shoulders, a waistline that still pulls in sharply even at this size, then an enormous belly of massive rounded folds and colossal wide hips flaring out again, massive thick thighs pressing together and running long to the floor."),
 "tent": ("텐트폴 USSBBW","A towering tentpole USSBBW woman standing tall on long legs, never short or squat. Shoulders more than four times a normal woman's width, massive rounded deltoids, a colossal chest projecting past the shoulders, a broad heavy torso with a big round belly, no waist at all, hips as broad as the shoulders, thighs running long into thick calves and long legs to the floor."),
 "top": ("톱헤비 아워글래스","A towering top-heavy hourglass woman standing tall on long legs, never short or squat. A colossal chest far wider than her shoulders curving forward as one enormous rounded mass, a waist that pulls in sharply below it, enormous round hips flaring out to more than twice the width of her shoulders, colossal thick thighs pressing together down to the knees and thick calves running long to the floor."),
 "ath": ("애슬리트 USSBBW","A towering, immensely powerful woman standing full height on long legs, never short or squat, the body of a world's strongest woman under a thick layer of soft fat — enormously broad thick shoulders, massive arms, a colossal chest, a huge barrel torso with a big round belly, no waist at all, colossal wide hips and tree-trunk thighs running long to the floor. The muscle is huge but rounded and buried."),
}

ROWS = [
 # 스타일, 체형, L, R, 얼굴 피어싱, 배꼽, 신발종류
 ("야마바","colo","glacial","amethyst",
  "A big neon-acrylic hoop and a small silver star stud on each ear.",
  "a neon-acrylic star dangling from a silver barbell","platform stiletto boots"),
 ("히메갸루","bust","rosepink","sapphire",
  "On each ear a big gold hoop with a small pearl drop; a thin gold ring passes through the left nostril.",
  "a pearl drop on a gold barbell","platform stiletto sandals"),
 ("요루바 신부 화장(나이지리아)","hgu","emerald","amber",
  "A thin gold ring passes through the left nostril; on each ear a big gold hoop with a red-enamel bead.",
  "a gold barbell with a small red-enamel bead","platform stiletto sandals"),
 ("화환 화장(우크라이나)","tent","citrine","cobalt",
  "A small silver bar runs through the outer end of the left eyebrow, clear of the eye; on each ear a big silver hoop with a red-enamel bead.",
  "a silver barbell with a small red-enamel bead","platform stiletto sandals"),
 ("비주얼계","top","alabaster","ruby",
  "A thick black-steel septum ring hangs below the nose; a thick black-steel bar runs through the outer end of the left eyebrow, clear of the eye; on each ear a big black-steel hoop.",
  "a black-steel barbell with a small silver spike hanging from it","platform stiletto boots"),
 ("아게하","ath","murano","aquamarine",
  "On each ear a large gold chandelier-shaped hoop; a small gold stud sits in the left nostril; a gold hoop passes through the lower lip's edge.",
  "a gold chain ending in a small gold ball","platform stiletto sandals"),
]

def build(row):
    name, bk, a, b, pierce, navel, shoe = row
    nat, mk, face = face_of(name)
    bname, btext = BODY[bk]
    an, adesc, ainner = MAT[a]; bn, bdesc, binner = MAT[b]
    p = f"""Professional fashion photograph, full body shot, head to toe. ONE woman standing, angled 45 degrees toward the camera, the camera set back so her whole body fits in the frame from the top of her head to her feet, her face still sharp. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {face}. Real jewelry: {pierce} In the carved hollow of her navel hangs {navel}. All jewelry is opaque metal, pearl, enamel or acrylic. Her whole face, ears and neck are real living flesh with real pores and fine skin grain — a photograph of a real face, not an illustration.

Physique: {btext}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest, belly, left hip and the whole left leg down through the foot): solid {adesc}, with {ainner}. Right half: solid {bdesc}, with {binner}. Each is carved as one solid sculpted mass like a statue, never hollow, the chest, belly folds and creases cut into the material itself as grooves. The arms flow into the torso and the torso into the legs with no seam. Every wrist, palm, finger and knuckle is the same material as its arm, and every toe and the sole of each foot is the same material as its leg, with no skin texture on any hand or foot.

Footwear: extreme {shoe} carved from the same material as the leg each one sits under, the material running unbroken through the ankle, the instep and every toe, nothing painted on the foot.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the body, between the hips and legs and down to the floor, where the two materials meet, never horizontal. The navel jewel stays bright real opaque metal and never turns transparent. Shards interlock along the lines only, every edge solid all the way through.

Pose: body angled 45 degrees, feet planted apart, her left hand (solid material) resting on her flared hip, her right arm held clear of her body with the hand (solid material) relaxed at hip height, well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal light on her face only; a strong backlight through each half so both sides glow from within; a thin cool rim light along the centre line. 2:3 vertical 8K portrait."""
    return name, bname, an, bn, p

OUT = [build(r) for r in ROWS]
if __name__ == "__main__":
    for x in OUT:
        wc = len(x[4].split())
        korean = bool(re.search(r'[\uac00-\ud7a3]', x[4]))
        print(x[0], x[1], x[2], "×", x[3], wc, "KOREAN" if korean else "")
