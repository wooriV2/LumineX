# -*- coding: utf-8 -*-
import re, sys, random, json
from collections import Counter
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_retest.py', encoding='utf-8').read().split("\nitems=[]; MK =")[0])      # build_p2, build_gf, fix, check ... (시험에서 통과한 문장 구조 그대로)
rnd.seed(20261020)
TN={1:"solo",2:"duo",3:"trio"}; TY={1:"Solo",2:"Duo",3:"Trio"}; TKO={1:"솔로",2:"듀오",3:"트리오"}
HAIRW = re.compile(r'\b(hair|braid|braids|braided|bun|ponytail|twin|bangs|fringe|locs|afro|bob|updo|curls|waves|ringlets|pigtails)\b', re.I)
CLAUSES = sorted({c.strip() for m in T.MAKEUP_48 for c in face(m)[1].split(',') if HAIRW.search(c)}, key=len, reverse=True)

D2=[]   # 임산부 2혼합 90 (기존 카테고리 Pregnant Blend Formula에 키 추가)
for g in [1,2,3]:
    for slot in range(1,31):
        key=f"la_pregblend2_{TN[g]}_{slot:02d}"; n=rnd.choice([3,4])
        p, desc = build_p2(g, n, rnd.sample(T.MAKEUP_48, g)); p=fix(p); check(key, p, allow_uv=False, mat=False)
        assert not any(c in p for c in CLAUSES) and "alternate between 2" in p, key
        structs=[s.strip("[]").split(" / ")[0] for s in desc.split(" ; ")]
        D2.append({"key":key,"category":"🤰 Living Artifact · Pregnant Blend Formula","title":f"Pregnant Blend 2-Mix {TY[g]} #{slot:02d} ({' / '.join(structs)})","prompt":p,
            "meta":{"group_size":g,"aspect_ratio":ASPECT[g],"format":"fused-blend","mix_count":2,"regions":n,"layout":"geometry-hazy-alt-v2","structures":structs}})
assert len(D2)==90 and len({x["key"] for x in D2})==90

E=[]    # 일반인 재질 블렌드 180 (신규 카테고리)
for mixn in [3,4]:
    for g in [1,2,3]:
        for slot in range(1,31):
            key=f"la_genmat{mixn}_{TN[g]}_{slot:02d}"
            p, desc = build_gf(g, mixn, rnd.sample(T.MAKEUP_48, g)); p=fix(p); check(key, p, allow_uv=False, mat=True)
            assert not any(c in p for c in CLAUSES) and "UV" not in p, key
            structs=[s.strip("[]").split(" / ")[0] for s in desc.split(" ; ")]
            E.append({"key":key,"category":"🏺 Living Artifact · General Material Blend Formula","title":f"General Material Blend {mixn}-Mix {TY[g]} #{slot:02d} ({' / '.join(structs)})","prompt":p,
                "meta":{"group_size":g,"aspect_ratio":ASPECT[g],"format":"fused-material-blend","mix_count":mixn,"layout":"geometry-hazy-v2","structures":structs}})
assert len(E)==180 and len({x["key"] for x in E})==180
json.dump(D2, open("la_pregblend2_geo_90_bundle.json","w",encoding="utf-8"), ensure_ascii=False, indent=2)
json.dump(E, open("la_genmat_geo_180_bundle.json","w",encoding="utf-8"), ensure_ascii=False, indent=2)
print("생성: D 임산부2혼합", len(D2), "/ E 일반인재질", len(E))
for tag,data in [("D 임산부 2혼합",D2),("E 일반인 재질",E)]:
    for g in sorted({x["meta"]["group_size"] for x in data}):
        ws=[len(x["prompt"].split()) for x in data if x["meta"]["group_size"]==g]; print(f"  {tag} {TKO[g]}: {min(ws)}~{max(ws)}단어")
st=Counter(s.split("·")[0].strip().split(" ")[0] for x in E for s in x["meta"]["structures"]); print("E 구조 분포:", dict(st))
