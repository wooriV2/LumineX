# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_pierce_chest_body.py', encoding='utf-8').read().split("\nspecs = [")[0])     # body_craft·body_mat·conc_chest·p200·recolor·g18·DENS·CARE·... 
rnd.seed(20261111)
WBODIES = ["a very narrow waist with a flat, smooth belly, wide hips and a full bust", "a muscular hourglass with a firm, smooth belly and strong arms", "a tall, powerful frame with a smooth, softly rounded belly and a full bust"]
WBODY_KO = ["아주 잘록한 허리·매끈한 배·넓은 힙", "근육형 아워글래스·단단한 배", "크고 힘 있는 체형·매끈하게 둥근 배"]
def build_waist(P, method, kind, n, navel):
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC)+1)
    M = pick_metal(ci); G = rnd.choice(GEMS); F = rnd.choice(FORMS); bi = rnd.randrange(len(WBODIES))
    hair = f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}"
    if method == "집중형": pierce = conc_chest(P, M, F)
    elif P == "P200": pierce = p200(M)
    else: pierce = recolor({"P50": g18.T50, "P100": g18.T100, "P150": g18.T150}[P], M)
    dense = P in ("P100", "P150", "P200")
    body_txt, body_label = (body_craft if kind == "craft" else body_mat)(n)
    m = MN[M]
    navel_txt = f" A {m} ring passes through the rim of her navel, the navel itself a deep dimple set in the smooth swell of her belly." if navel else ""
    metal_phrase = "mixed metal (yellow gold, silver, copper and rose gold, alternating piece by piece)" if M == "MX" else ("rose gold" if M == "MR" else m.replace("-", " "))
    p = (f"Professional fashion photograph, waist shot. ONE woman, facing the camera straight on, her head level, both ears clearly visible on either side of her face, framed from the very top of her head down to just below her navel, the frame cutting off across her lower belly. Her face sits in the upper part of the frame, large enough to read every piercing, and her ear pieces are oversized so they read clearly at this distance. Mid 20s.\n\n"
         f"Subject: A real photograph of a strikingly beautiful adult {nat} woman — {fa}, {hair}. Her whole face, ears and neck are real living flesh with real pores and fine skin grain — a photograph of a real woman, not an illustration, not a render.\n\n"
         f"Piercings: {pierce}{DENS if dense else ''}{gem_text(G) if method == '집중형' else ''}{navel_txt} {CARE.format(metal=metal_phrase)}\n\n"
         f"Physique: {WBODIES[bi]}.\n\nBody: {body_txt}Real skin on the face, ears and neck ends cleanly at the base of the neck and across both collarbones, and everything below it, down to the bottom of the frame, is the body treatment described above.\n\n"
         f"Pose: arms relaxed at her sides, shoulders level, head level toward the camera.\n\n"
         f"Lighting: pure pitch black background. A soft frontal light on her face and ears, so the makeup and the glints on every piece of metal read clearly; a thin cool rim light along the hair and shoulders. 2:3 vertical 8K portrait.")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    low = p.lower()
    assert not re.search(r"[가-힣]", p) and "overhead" not in low and not re.search(r"\b(\w+) \1\b", p), (P, kind)
    if kind == "mat": assert not any(w in low for w in ("crystal", "blooms growing", "molten wax", "uv-reactive")), (P, kind)
    if M not in ("MG", "MR", "MX"): assert "gold" not in pierce.lower() and "gold" not in navel_txt, (P, M)
    desc = f"{re.sub(r'^[A-Z]+', '', HS[si-1])} · {re.sub(r'^[A-Z]+', '', HC[ci-1])} · 메이크업 {mk} · 금속 {MKO[M]} · {body_label} · 체형 {WBODY_KO[bi]}{' · 배꼽 링' if navel else ''}"
    return p, desc, body_label
specs = [("P8","집중형","mat",3,False), ("P25","집중형","craft",3,True), ("P25","집중형","mat",1,True), ("P50","정의형","craft",3,True), ("P100","정의형","mat",3,True), ("P150","정의형","craft",1,True)]
items = [(P, m, k, nv) + build_waist(P, m, k, n, nv) for P, m, k, n, nv in specs]
order = list(range(6)); rnd.shuffle(order); no = {i: order.index(i)+1 for i in range(6)}; ranked = sorted(range(6), key=lambda i: no[i])
L = ["# LumineX · 피어싱 + 몸 처리 허리 컷 시험 (6개, 정면)\n",
     "머리 위부터 배꼽 바로 아래까지의 정면 허리 컷입니다. 얼굴이 가슴 컷보다 작아지는 프레임이라 **P150에서 얼굴 피어싱이 뭉개지는지**도 확인합니다(P150은 한 개). 몸 처리는 가슴 컷과 같은 검증된 문장(공예·재질, 혼합·단일)을 목선 아래부터 입혔습니다. P25 이상에는 **배꼽 링 1개**를 넣었습니다(배가 매끈한 체형만 사용, 배꼽이 움푹 들어간 표현 포함). 금박·UV네온은 뺐습니다. P8·P25는 집중형(왼쪽 몰림, 정면에서는 화면 오른쪽), P50 이상은 정의형입니다. 번호는 섞여 있습니다.\n",
     "**알려주실 것**: P8·P25(집중형)는 **얼굴·귀 피어싱 개수만** 세어 주시고, 배꼽 링은 있었는지 O/X를 따로 적어 주세요(P25 이상). P50 이상은 **성공/실패**(피어싱이 눈에 띄지 않거나 몸 처리가 안 나오면 실패)입니다. 최대 3회. 예: `1: 9개 / 2: 22개, 배꼽 O / 3: 성공, 배꼽 X`\n",
     "## 색인\n", "| 번호 | 단계 | 방식 | 구성 |", "|---|---|---|---|"]
for i in ranked: P, m, k, nv, p, d, bl = items[i]; L.append(f"| {no[i]:02d} | {P} | {m} | {d} |")
L.append("")
for i in ranked: P, m, k, nv, p, d, bl = items[i]; L += [f"## {no[i]:02d}. {P} 허리 컷 · {bl}\n", "```", p, "```\n"]
open("/tmp/rep_out/LumineX_Pierce_Waist_Round1.md", "w", encoding="utf-8").write("\n".join(L))
print("6개 저장")
for i in ranked: P, m, k, nv, p, d, bl = items[i]; print(f"  {no[i]:02d} {P:<4} {m:<4} {len(p.split()):>4}단어 | {bl}{' | 배꼽' if nv else ''}")
