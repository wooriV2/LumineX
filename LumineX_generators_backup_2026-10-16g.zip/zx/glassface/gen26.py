# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g25 = load("g25","gen25.py")
caustic, growth = g25.caustic, g25.growth

C4 = caustic("파케앙트 글램(필리핀)","hgu","sapphire","carnelian",
  "On each ear a big gold hoop with a pearl.",
  "she stands on a polished, wet black stone floor in front of a dark charcoal wall, lit by one hard cool light from the upper right behind her. The light passes through her transparent body and throws deep blue and warm orange patches of caustic light onto the wet floor around her feet, and her whole glowing body is mirrored in a soft reflection in the wet floor, the coloured light rippling in it.")
C5 = caustic("슬라브 글램(러시아·동유럽)","top","jade","amethyst",
  "On each ear a big silver hoop with a filigree silver drop.",
  "she stands on a worn pale stone floor in front of a bare stone wall in an old hall. Through a tall arched window behind her left a strong hard beam of golden sunlight falls across the room, with fine dust drifting in it. The beam passes through her transparent body and throws long caustic shadows — green patches from the jade side and violet patches from the amethyst side — across the floor and the wall, each with bright bending edges of concentrated light.")
C6 = caustic("요루바 신부 화장(나이지리아)","ath","ruby","amber",
  "On each ear a big gold hoop with a red-enamel bead.",
  "she stands on a deep teal painted floor in front of a deep teal painted wall, lit by one hard warm light from the left behind her. The light passes through her transparent body and throws long caustic shadows across the floor and the wall — warm coral-red patches from the ruby glass side and golden-orange patches from the amber side glowing against the teal, and where they overlap they blend into bright orange, each with bright bending edges of concentrated light.")

V4 = growth("발칸 글램(루마니아·불가리아)","bust","tent","citrine","cobalt",
  "On each ear a thick gold hoop with a gold coin drop hangs clear of the neck down to the shoulder.",
  "Growth",
  "real plants grow out of the material below the collarbones, rooted in fine cracks inside the material, their pale roots visible as threads through it. On the left citrine, dark green ivy with pale veins climbs from the shoulder and winds down the upper arm, a few tendrils curling. On the right cobalt glass, long hanging clusters of white-and-lilac wisteria cascade from the shoulder and drape down over the arm and the edge of the chest. The leaves and flowers are real and soft. The plants grow only from the shoulders, arms and chest — never on the neck, the face or the hair, and never covering the hands.",
  "")
V5 = growth("인스타 글램(미국·영국)","waist","uss","amethyst","jade",
  "Two big gold hoops stacked on each ear hang clear of the neck.",
  "Growth",
  "real plants grow out of the material below the collarbones, rooted in fine cracks inside the material, their pale roots visible as threads through it. On the left amethyst, three tall sunflowers with bright yellow petals and dark centres rise on green stems from the shoulder and the upper arm. On the right jade, a small cluster of white daisies with yellow centres rises from the shoulder and the edge of the chest. The leaves and petals are real and soft. The plants grow only from the shoulders, arms and chest — never on the neck, the face or the hair, and never covering the hands.",
  "")
V6 = growth("소피아 로렌풍(이탈리아)","waist","hgu","aquamarine","smoky",
  "On each ear a large pearl drop with a gold clip.",
  "Growth",
  "real water plants grow out of the material below the collarbones, rooted in fine cracks inside the material, their pale roots visible as threads through it. On the left aquamarine, two pink lotus flowers, one open and one in bud, rise on tall green stems with round lotus leaves from the shoulder and the upper arm. On the right smoky glass, white water lilies rest on the shoulder and the edge of the chest with flat green lily pads and a few water droplets on the petals. The leaves and petals are real and soft. The plants grow only from the shoulders, arms and chest — never on the neck, the face or the hair, and never covering the hands.",
  "")

A2 = growth("스칸디 프로스트(스웨덴)","waist","hgs","egglass","sapphire",
  "On each ear a big smooth silver hoop hangs clear of the neck down to the shoulder.",
  "Perched creatures",
  "small living creatures rest and drift around the material as if it were a garden statue at dusk, real, alive and still. On the left emerald glass, two iridescent blue-green dragonflies with transparent wings perch on the shoulder cap and the upper arm. On the right sapphire, a dozen fireflies drift and rest along the arm and the shoulder, each a soft warm glowing point of light whose glow reflects in the crystal. The creatures stay well away from her face and neck and never cover the boundary line or the piercings.",
  "")
A3 = growth("텔레노벨라 글램(멕시코·콜롬비아)","bust","colo","citrine","amethyst",
  "On each ear a large gold hoop hangs clear of the neck down to the shoulder.",
  "Perched creatures",
  "living creatures and flowers share the material, real, alive and still. On the left citrine, a real climbing vine with small red trumpet flowers grows from the shoulder and winds down the upper arm, rooted in fine cracks inside the material, and a small green-and-ruby hummingbird hovers in mid-air beside the shoulder with its wings blurred and its long beak dipped into one of the flowers. On the right amethyst, two small blue butterflies rest on the shoulder and one on the back of the raised right hand. The creatures and flowers stay well away from her face and neck, never cover the hands and never cover the boundary line.",
  "")
A4 = growth("서아프리카 파티·웨딩 글램","waist","musc","ruby","jade",
  "On each ear a big gold hoop with gold beads hangs clear of the neck down to the shoulder.",
  "Perched creatures",
  "small living creatures rest on the material as if it were a garden statue, real, alive and still. On the left ruby glass, two small bright-green tree frogs sit on the shoulder cap and the upper arm, their tiny toes resting on the material and their bright eyes open. On the right jade, five red ladybugs with black spots crawl along the arm and the shoulder, and a small snail with a spiral shell rests on the back of the raised right hand. The creatures are small, stay well away from her face and neck, and never cover the boundary line or the piercings.",
  "")

ITEMS = [
 ("C4","반사 바닥","전신","파케앙트 · 아워글래스 USSBBW · 사파이어 × 카넬리안 · 젖은 검은 돌바닥에 비친 몸"),
 ("C5","창문 빛줄기","전신","슬라브 · 톱헤비 아워글래스 · 비취 × 자수정 · 오래된 석조 홀, 아치 창의 햇살"),
 ("C6","청록 벽 그림자","전신","요루바 · 애슬리트 USSBBW · 루비색 유리 × 호박 · 청록색 벽과 바닥에 산호·주황 그림자"),
 ("V4","식물 D(아이비·등나무)","가슴","발칸 · 텐트폴 · 시트린(아이비) × 코발트 유리(등나무)"),
 ("V5","식물 E(해바라기·데이지)","허리","인스타 · USSBBW · 자수정(해바라기) × 비취(데이지)"),
 ("V6","식물 F(연꽃·수련)","허리","소피아 · 아워글래스 USSBBW · 아쿠아마린(연꽃) × 스모키 유리(수련)"),
 ("A2","동물 B(잠자리·반딧불이)","허리","스칸디 · 아워글래스 SSBBW · 에메랄드 그린 유리(잠자리) × 사파이어(반딧불이)"),
 ("A3","동물 C(벌새·나비)","가슴","텔레노벨라 · 콜로설 · 시트린(트럼펫 꽃과 벌새) × 자수정(나비)"),
 ("A4","동물 D(청개구리·무당벌레)","허리","서아프리카 · 머슬 아워글래스 · 루비색 유리(청개구리) × 비취(무당벌레와 달팽이)"),
]
PROMPTS = [C4, C5, C6, V4, V5, V6, A2, A3, A4]
if __name__ == "__main__":
    for (n,t,f,d), p in zip(ITEMS, PROMPTS):
        print(n,t,f,len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
