# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_pierce_waist.py', encoding='utf-8').read().split("\nspecs = [")[0])     # body_craft·body_mat·conc_chest·p200·recolor·g18·DENS·CARE·pick_metal·...
rnd.seed(20261112)
LBODIES = ["a very narrow waist with a flat, smooth belly, wide hips and thick thighs", "a muscular hourglass with a firm, smooth belly and strong thighs", "a tall, powerful frame with a smooth, softly rounded belly, full hips and thick thighs"]
LBODY_KO = ["아주 잘록한 허리·넓은 힙·굵은 허벅지", "근육형 아워글래스·단단한 허벅지", "크고 힘 있는 체형·풍성한 힙·굵은 허벅지"]
FRAMES = {
 "hip":  ("힙컷(허벅지 위까지)", "hip shot", "framed from the very top of her head down to the tops of her thighs, the frame cutting off across her upper thighs"),
 "demi": ("데미스탯(허벅지 중간까지)", "three-quarter shot", "framed from the very top of her head down to the middle of her thighs, the frame cutting off across her mid-thighs"),
 "tq":   ("쓰리쿼터(무릎 위까지)", "three-quarter-length shot", "framed from the very top of her head down to just above her knees, the frame cutting off just above the knees"),
}
def build_long(frame, P, method, kind, n):
    fk, fname, fsent = FRAMES[frame]
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC)+1)
    M = pick_metal(ci); G = rnd.choice(GEMS); F = rnd.choice(FORMS); bi = rnd.randrange(len(LBODIES))
    hair = f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}"
    if method == "집중형": pierce = conc_chest(P, M, F)
    else: pierce = recolor({"P50": g18.T50, "P100": g18.T100}[P], M)
    dense = P == "P100"; m = MN[M]
    body_txt, body_label = (body_craft if kind == "craft" else body_mat)(n)
    body_pierce = f" A {m} ring passes through the rim of her navel, the navel itself a deep dimple set in the smooth swell of her belly, and a small {m} surface bar sits on each hip bone."
    metal_phrase = "mixed metal (yellow gold, silver, copper and rose gold, alternating piece by piece)" if M == "MX" else ("rose gold" if M == "MR" else m.replace("-", " "))
    p = (f"Professional fashion photograph, {fname}. ONE woman, facing the camera straight on, her head level, both ears clearly visible on either side of her face, {fsent}. Her face sits at the top of the frame, small but sharp, and her ear pieces are oversized so they read clearly at this distance. Mid 20s.\n\n"
         f"Subject: A real photograph of a strikingly beautiful adult {nat} woman — {fa}, {hair}. Her whole face, ears and neck are real living flesh with real pores and fine skin grain — a photograph of a real woman, not an illustration, not a render.\n\n"
         f"Piercings: {pierce}{DENS if dense else ''}{gem_text(G) if method == '집중형' else ''}{body_pierce} {CARE.format(metal=metal_phrase)}\n\n"
         f"Physique: {LBODIES[bi]}.\n\nBody: {body_txt}Real skin on the face, ears and neck ends cleanly at the base of the neck and across both collarbones, and everything below it, down to the bottom of the frame, is the body treatment described above.\n\n"
         f"Pose: standing tall, arms relaxed at her sides, shoulders level, legs together, head level toward the camera.\n\n"
         f"Lighting: pure pitch black background. A soft frontal light on her face and ears, so the makeup and the glints on every piece of metal read clearly; a thin cool rim light along the hair and shoulders. 2:3 vertical 8K portrait.")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    low = p.lower()
    assert not re.search(r"[가-힣]", p) and "overhead" not in low and not re.search(r"\b(\w+) \1\b", p), (frame, P)
    if kind == "mat": assert not any(w in low for w in ("crystal", "blooms growing", "molten wax", "uv-reactive")), (frame, P)
    if M not in ("MG", "MR", "MX"): assert "gold" not in pierce.lower() and "gold" not in body_pierce, (frame, P, M)
    desc = f"{re.sub(r'^[A-Z]+', '', HS[si-1])} · {re.sub(r'^[A-Z]+', '', HC[ci-1])} · 메이크업 {mk} · 금속 {MKO[M]} · {body_label} · 체형 {LBODY_KO[bi]}"
    return p, desc, body_label, fk
specs = [("hip","P50","정의형","mat",3), ("hip","P100","정의형","craft",1), ("demi","P25","집중형","craft",3), ("demi","P50","정의형","mat",1), ("tq","P8","집중형","mat",3), ("tq","P25","집중형","craft",3)]
items = [(fr, P, m) + build_long(fr, P, m, k, n) for fr, P, m, k, n in specs]
order = list(range(6)); rnd.shuffle(order); no = {i: order.index(i)+1 for i in range(6)}; ranked = sorted(range(6), key=lambda i: no[i])
L = ["# LumineX · 피어싱 프레임 한도 시험 — 힙컷·데미스탯·쓰리쿼터 (6개, 정면 크롭)\n",
     "프레임이 이름보다 길게 나온다는 생성 결과에 맞춰 프레임 문장을 썼습니다(힙컷=허벅지 위까지, 데미스탯=허벅지 중간까지, 쓰리쿼터=무릎 위까지). 실사 몸에 몸 처리(공예·재질)를 입혔고, 귀 장식은 크게 키웠습니다. 각 프레임에서 한도로 추정한 단계의 위아래를 한 개씩 넣었습니다(힙컷 P50·P100, 데미스탯 P25·P50, 쓰리쿼터 P8·P25). 배꼽 링과 양쪽 골반뼈 서피스 바를 넣었습니다. P8·P25는 집중형(왼쪽 몰림, 정면에서는 화면 오른쪽), P50 이상은 정의형입니다. 금박·UV네온은 뺐습니다. 번호는 섞여 있습니다.\n",
     "**알려주실 것**: 집중형(P8·P25)은 **얼굴·귀 피어싱 개수만** 세어 주시고, P50 이상은 **성공/실패**(얼굴·귀 피어싱이 눈에 띄지 않거나 몸 처리가 안 나오면 실패)로 적어 주세요. 모든 컷에서 **배꼽 링과 골반뼈 바가 보였는지 O/X**도 적어 주세요. 최대 3회. 예: `1: 9개, 배꼽 O, 골반뼈 X / 2: 실패, 배꼽 O, 골반뼈 O`\n",
     "## 색인\n", "| 번호 | 프레임 | 단계 | 방식 | 구성 |", "|---|---|---|---|---|"]
for i in ranked: fr, P, m, p, d, bl, fk = items[i]; L.append(f"| {no[i]:02d} | {fk} | {P} | {m} | {d} |")
L.append("")
for i in ranked: fr, P, m, p, d, bl, fk = items[i]; L += [f"## {no[i]:02d}. {fk} · {P} · {bl}\n", "```", p, "```\n"]
open("/tmp/rep_out/LumineX_Pierce_LongFrames_Round1.md", "w", encoding="utf-8").write("\n".join(L))
print("6개 저장")
for i in ranked: fr, P, m, p, d, bl, fk = items[i]; print(f"  {no[i]:02d} {fr:<4} {P:<4} {m:<4} {len(p.split()):>4}단어 | {bl}")
