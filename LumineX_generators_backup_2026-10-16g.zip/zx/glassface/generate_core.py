# -*- coding: utf-8 -*-
import json, re, sys, io, contextlib, importlib.util, os

sys.path.insert(0, '/home/claude/glassface')
from full_dicts import (face, CRAFT_DB_FULL, NAIL_SHAPE_EN_FULL, NAIL_FIN_EN_FULL,
 HAIR_EN_FULL, SHOE_EN_FULL, POSE_EN_FULL, AGE_EN_FULL, VIBE_EN_FULL)
sys.path.insert(0, '/home/claude/register')
from body_full import BODY_FULL

banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","snake","safety pin","gash"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    hits = [w for w in banned if w in p.lower() and w not in ("bite","snake")]
    assert not hits, (name,hits)

D = json.load(open("/home/claude/diversity/register_1050.json"))

def person_block(i, label, solo=False):
    nnat, fa = face(D["makeup"][i])
    bodykey = D["body"][i]
    cn, cd, cb, cf = CRAFT_DB_FULL[D["craft"][i]]
    nail = f"{NAIL_SHAPE_EN_FULL[D['nail_s'][i]]} nails, {NAIL_FIN_EN_FULL[D['nail_f'][i]]} finish"
    hair = HAIR_EN_FULL[D["hair"][i]]
    age = AGE_EN_FULL[D["age"][i]]
    vibe = VIBE_EN_FULL[D["vibe"][i]]
    pose = POSE_EN_FULL[D["pose"][i]]
    shoe = SHOE_EN_FULL[D["shoe"][i]]
    if solo:
        block = f"""Subject: ONE real adult {nnat} woman in her {age}, her face exactly the same tone as her body, real skin texture with visible pores and fine grain, {fa}, {vibe}, {hair} hair, real living eyes. Long {nail}.

Physique: An extraordinarily large woman, far beyond any real person. {BODY_FULL[bodykey]}

Skin: Real photographic skin — visible pores and fine grain, a smooth taut surface with natural creases and shadow only where the flesh folds, faint stretch marks where the great curves have expanded. No smooth illustration finish, no plastic CG sheen.

Body Art: Her bare skin is painted in {cn} — {cd}, wide {cb} bands following every deep crease and curving around the hips and thighs like contour lines, dense {cf} filling the space between every band. The paint is pigment sitting on living skin, so it distorts slightly over every bulge. The paint covers her whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of her hands, sides, back, rear, lower belly, knees, calves and the tops of her feet. Her face is left unpainted and the pattern fades out at the neck with no hard line.

Pose: {pose}.

Footwear: Extreme {cb} {shoe}, the platform soles rising far higher than her ankle bone, at least three times the thickness of an ordinary heel."""
    else:
        block = f"""{label} woman: a real adult {nnat} woman in her {age}, her face exactly the same tone as her body, real skin texture with visible pores, {fa}, {vibe}, {hair} hair, real living eyes. Long {nail}.

{label} woman's physique: An extraordinarily large woman, far beyond any real person. {BODY_FULL[bodykey]}

{label} woman's body art: painted in {cn} — {cd}, wide {cb} bands following every deep crease, dense {cf} filling the space between bands, pigment on living skin, covering her whole body below the jaw with no bare skin anywhere, face unpainted, pattern fading at the neck.

{label} woman's pose: {pose}.

{label} woman's footwear: extreme {cb} {shoe}, the platform soles rising far higher than her ankle bone, at least three times the thickness of an ordinary heel."""
    return block, nnat, bodykey, cn

RATIO = {1:("2:3","vertical"),2:("3:4","landscape"),3:("4:5","landscape"),4:("4:5","landscape"),5:("5:4","landscape"),6:("16:9","landscape")}
NUM_WORD = {1:"ONE",2:"TWO",3:"THREE",4:"FOUR",5:"FIVE",6:"SIX"}
LABELS = {
 1: ["Subject"],
 2: ["Left","Right"],
 3: ["Left","Center","Right"],
 4: ["Far-left","Left","Right","Far-right"],
 5: ["Far-left","Left","Center","Right","Far-right"],
 6: ["Far-left","Left","Center-left","Center-right","Right","Far-right"],
}
TYPE_NAME = {1:"solo",2:"duo",3:"trio",4:"quartet",5:"quintet",6:"sextet"}

def build_solo(idx, slot_no):
    aspect, orient = RATIO[1]
    block, nnat, bodykey, cn = person_block(idx, None, solo=True)
    p = f"""Image format: a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide.

A full-body photograph with a plain seamless deep-charcoal backdrop, shot on a medium format camera with an 85mm lens at f/8, a single hard key light raking in from one side, sharp focus from head to toe, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.

{block}

Background & Lighting: the painted pattern catching the light in sharp glints, the hard raking light carving every fold and curve.

Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide. portrait 2:3 vertical."""
    return p, [f"{nnat}/{bodykey}/{cn}"]

def build_group(n, idxs, slot_no):
    aspect, orient = RATIO[n]
    labels = LABELS[n]
    blocks = []
    summary = []
    for j, idx in enumerate(idxs):
        block, nnat, bodykey, cn = person_block(idx, labels[j], solo=False)
        blocks.append(block)
        summary.append(f"{nnat}/{bodykey}/{cn}")
    all_blocks = "\n\n".join(blocks)
    wide_note = "significantly wider than it is tall, " if aspect=="16:9" else ""
    p = f"""Image format: a landscape-orientation photograph, {aspect} aspect ratio, {wide_note}{NUM_WORD[n].lower()} women in a single row.

A photograph of {NUM_WORD[n]} women standing side by side on a plain seamless deep-charcoal backdrop, nothing else in the frame, generous horizontal spacing between each so every figure reads clearly and large within the frame, the camera set back so all {n} fit comfortably within the frame from head to toe, 50mm lens at f/8, a single hard key light raking across all of them from one side, sharp focus head to toe on each — a real photograph, not an illustration, not CGI, not a render.

{all_blocks}

Composition: each woman's own pose as described, inner arms not crossing her neighbours, all faces toward the camera, generous spacing so every figure reads clearly.

Skin (all): real photographic skin, visible pores and fine grain, natural creases and shadow only where the flesh folds, no illustration finish, no CG sheen.

Lighting: the hard raking light carving every fold and curve on all {n}, catching each woman's own painted pattern distinctly. Shot on a Hasselblad X2D, {aspect} {orient} 8K."""
    return p, summary

all_presets = []
idx_cursor = 0
stats = {}
for n in [1,2,3,4,5,6]:
    type_name = TYPE_NAME[n]
    lengths = []
    for slot in range(1, 51):
        idxs = list(range(idx_cursor, idx_cursor+n))
        if n == 1:
            p, summary = build_solo(idxs[0], slot)
        else:
            p, summary = build_group(n, idxs, slot)
        check(f"{type_name}_{slot}", p)
        key = f"la_core_{type_name}_{slot:02d}"
        all_presets.append({
            "key": key,
            "category": "🏺 Living Artifact · Core Formula",
            "title": f"Core {type_name.capitalize()} #{slot:02d}",
            "prompt": p,
            "meta": {"group_size": n, "aspect_ratio": RATIO[n][0], "composition": summary}
        })
        lengths.append(len(p.split()))
        idx_cursor += n
    stats[type_name] = (min(lengths), max(lengths), sum(lengths)//len(lengths))

print("생성 완료:", len(all_presets), "개")
for t,(mn,mx,avg) in stats.items():
    print(f"  {t}: min={mn} max={mx} avg={avg}")

with open("/home/claude/register/la_core_bundle.json","w",encoding="utf-8") as f:
    json.dump(all_presets, f, ensure_ascii=False, indent=2)
print("번들 저장 완료: la_core_bundle.json")
