# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_final3.py', encoding='utf-8').read().split("\n# ================= A.")[0])     # face_nohair·T·HAIR_*_EN_FULL·dd·GEM_EN·METAL_EN ...
rnd.seed(20261107)
HS = T.HAIR_STYLE; HC = T.HAIR_COLOR
EXPOSED = [4,5,7,8,11,13,15,17,18,19,20,21,24,28,30,31]; COVER_OK = [1,2,3,26,27]        # 1-based 인덱스(핸드오프 21-1 분류)
WARM_LIGHT = {8,10,11,12,14,18,24,29}; COOL_LIGHT = {13,15,16,21,22,23,30}
GEMS = ["GD","GP","GO","GA","GR","GS","GX"]; FORMS = ["FH","FS","FB","FC","FD","FG","FX"]
EAR = {"FH":"hoop","FS":"stud","FB":"bar","FC":"clicker ring","FD":"drop dangle","FG":"segment ring"}
MN = {"MG":"yellow-gold","MR":"rose-gold","MS":"silver","MC":"copper","MBR":"antique-brass","MBZ":"bronze","MX":"mixed-metal"}
MKO = {"MG":"금","MR":"로즈골드","MS":"은","MC":"구리","MBR":"황동","MBZ":"청동","MX":"혼합"}
GKO = {"GD":"다이아몬드","GP":"진주","GO":"오팔","GA":"자수정","GR":"루비","GS":"사파이어","GX":"혼합"}
FKO = {"FH":"후프","FS":"스터드","FB":"바","FC":"클리커","FD":"드롭","FG":"세그먼트","FX":"혼합"}
def pick_metal(ci):
    if ci in WARM_LIGHT: return rnd.choice(["MS","MX"])
    if ci in COOL_LIGHT: return rnd.choice(["MG","MR","MC","MBZ","MBR"])
    return rnd.choice(list(MN))
def ear_noun(f):
    return EAR[f] if f != "FX" else rnd.choice(list(EAR.values()))
def pierce_text(P, M, f):
    m = MN[M]; mm = f"{m}"; e1, e2, e3 = ear_noun(f), ear_noun(f), ear_noun(f)
    if P == "P3": return f"A thick polished {mm} {e1} on each ear and one small {mm} stud above the left one."
    if P == "P5": return f"A big {mm} {e1} on each ear with a small {mm} stud above it on the left; a small {mm} ring passes through the left nostril; a thin {mm} bar passes through the outer end of the left eyebrow."
    if P == "P8": return f"On each ear three pieces: a big {mm} {e1} in the lobe, a smaller {mm} ring above it and a small {mm} stud at the top; a small {mm} stud sits in the left nostril; a thin {mm} bar passes through the outer end of the left eyebrow."
    if P == "P15": return (f"On each ear four pieces: a big {mm} {e1} in the lobe, a smaller {mm} ring above it, a thick {mm} bar and a small {mm} stud at the top; a small {mm} ring passes through each nostril; a thin {mm} bar passes through the outer end of each eyebrow; "
                           f"a {mm} hoop passes through the lower lip's edge; a {mm} labret stud sits beneath the lower lip with a small {mm} ring below it.")
    return (f"On each ear four pieces: a big {mm} {e1} in the lobe, a smaller {mm} ring above it, a thick {mm} bar and a small {mm} stud at the top; a thick {mm} septum ring hangs below the nose, a small {mm} ring passes through each nostril and a straight {mm} bar crosses the bridge of the nose between the brows; "
            f"two thin {mm} bars pass through the outer end of each eyebrow; a {mm} Medusa stud sits above the lips; a big {mm} hoop passes through the lower lip's edge with a {mm} snake-bite ring on each side and a small {mm} ring at the upper lip's edge; "
            f"a {mm} labret stud and a small {mm} ring sit on the chin; a small {mm} stud sits along each jaw.")
CARE = "All jewelry is real {metal}, sitting in real skin that is healed, clean and calm — no blood, no redness, no swelling, no wound — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes."
def gem_text(G): return " Each piece carries small " + ("mixed gemstones (diamond, pearl, opal, amethyst, ruby and sapphire) set into alternating pieces" if G=="GX" else f"{GEM_EN[G]} set into the metal") + "."

def build(P, cover=False, si=None):
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk)
    si = si or rnd.choice(COVER_OK if cover else EXPOSED); ci = rnd.randrange(1, len(HC)+1)
    M = pick_metal(ci); G = rnd.choice(GEMS); F = rnd.choice(FORMS)
    hair = f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}" + (", tucked back behind both ears so that every ear piercing is fully visible" if cover else "")
    metal_phrase = "mixed metal (yellow gold, silver, copper and rose gold, alternating piece by piece)" if M == "MX" else MN[M].replace("-", " ") if M != "MR" else "rose gold"
    pierce = pierce_text(P, M, F) + gem_text(G)
    p = (f"Professional fashion photograph, close-up beauty portrait. ONE woman, facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp. Mid 20s.\n\n"
         f"Subject: A real photograph of a strikingly beautiful adult {nat} woman — {fa}, {hair}. Real pores and fine skin grain, real living eyes with bright catchlights and genuine depth, individual hair strands catching the light — a photograph of a real face, not an illustration, not a render, not cel-shaded.\n\n"
         f"Piercings: {pierce} {CARE.format(metal=metal_phrase)}\n\n"
         f"Lighting: a soft frontal beauty light on the face with a thin cool rim light along the hair, pure pitch black void background, shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait.")
    p = dd(p).replace(",,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), P
    desc = f"{re.sub(r'^[A-Z]+', '', HS[si-1])}{'(가림형+귀 넘김)' if cover else '(노출형)'} · {re.sub(r'^[A-Z]+', '', HC[ci-1])} · 메이크업 {mk} · 금속 {MKO[M]}·보석 {GKO[G]}·형태 {FKO[F]}"
    return p, desc

specs = [("P3",False),("P5",False),("P8",False),("P15",False),("P25",False),("P8",True)]
STY = rnd.sample(EXPOSED, 5) + [rnd.choice(COVER_OK)]
items = [(P, cv) + build(P, cv, STY[k]) for k, (P, cv) in enumerate(specs)]
order = list(range(6)); rnd.shuffle(order); no = {i: order.index(i)+1 for i in range(6)}; ranked = sorted(range(6), key=lambda i: no[i])
L = ["# LumineX · 피어싱 얼굴 컷 시험 1라운드 (6개) — 정면 컷\n",
     "정면을 바라보는 얼굴 클로즈업이라 양쪽 귀가 모두 보입니다. 피어싱만으로 구성했습니다(쥬얼리·네일·바디페인팅 없음). 메이크업 48종·헤어컬러 30종은 랜덤이고, 헤어스타일은 귀가 드러나는 노출형 16종 중에서 뽑았습니다. 금속색은 머리색과 대비되게 골랐고 보석·형태는 랜덤입니다. 한 개(P8 가림형)는 귀를 가리기 쉬운 헤어에 \"귀 뒤로 넘김\" 문장을 붙인 대조입니다. 번호는 섞여 있습니다. **성공/실패만** 알려주세요(최대 3회). 생성됐어도 **피어싱이 눈에 띄지 않으면 실패**로 쳐 주세요. 예: `3: 2회 / 5: 실패 / 나머지 1회`\n",
     "## 색인\n", "| 번호 | 단계 | 구성 (헤어 · 헤어컬러 · 메이크업 · 금속·보석·형태) |", "|---|---|---|"]
for i in ranked: P, cv, p, desc = items[i]; L.append(f"| {no[i]:02d} | {P} | {desc} |")
L.append("")
for i in ranked: P, cv, p, desc = items[i]; L += [f"## {no[i]:02d}. {P} 얼굴 컷{' (가림형 대조)' if cv else ''}\n", "```", p, "```\n"]
open("/tmp/rep_out/LumineX_Pierce_Face_Round1_Front.md", "w", encoding="utf-8").write("\n".join(L))
print("6개 저장")
for i in ranked: P, cv, p, desc = items[i]; print(f"  {no[i]:02d} {P:<3} {len(p.split()):>3}단어 | {desc}")
