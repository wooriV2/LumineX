# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
src = open('gen_matblend_geo_test.py', encoding='utf-8').read().split("\nitems=[]")[0]
exec(src)
rnd.seed(20261601)
sys.path.insert(0, "/tmp/claude-0/-home-claude/62db5eea-2487-540b-9935-a7df06448e2a/scratchpad/master")
import mdefs as _D
SEL = ["BBW bombshell", "super glamour", "amazon bombshell", "muscular hourglass BBW", "legendary bust", "curved bust", "latina curves", "super hourglass", "black glamour", "Brazilian booty glam", "hourglass bombshell"]
PHYS = [(b[0], b[1]) for b in _D.BODIES if b[0] in SEL]
assert len(PHYS) == len(SEL)
NEWM = ["ice", "feather", "circuit", "nacre", "wing", "mirror"]
MAT_KO.update({"ice": "얼음·서리", "feather": "깃털", "circuit": "회로·사이버", "nacre": "진주층", "wing": "곤충 날개", "mirror": "거울 파편"})
_mt0 = mat_text
ICE = ["pale glacier-blue ice plates and white hoarfrost", "deep sapphire-blue clear ice plates and white hoarfrost"]
FEA = ["glossy raven-black plumage with an oil-slick purple and green sheen", "snow-white plumage with blush-pink tips"]
CIR = [("matte black circuit-board surface with gold copper traces", "electric cyan light pulses racing along the traces and small glowing LED points"), ("glossy white ceramic circuit-board surface with silver traces", "magenta light pulses racing along the traces and small glowing LED points")]
NAC = [("milky pearl-white nacre with pink and aqua lustre", "soft rainbow sheen sliding across each tile"), ("black Tahitian-pearl nacre with green and violet lustre", "soft peacock-green and violet sheen sliding across each tile")]
WIN = [("iridescent green-gold and violet dragonfly-wing membranes", "dark vein networks and tiny scale-dust shimmer along the wing edges"), ("iridescent electric-blue morpho butterfly-wing membranes", "dark vein networks and tiny scale-dust shimmer along the wing edges")]
MIR = [("silver mirror shards", "bright white glints off the shard edges and a few shards tinted gold and rose"), ("gold-tinted mirror shards", "bright white glints off the shard edges and a few shards tinted rose and silver")]
def mat_text(key):
    if key == "ice":
        b = rnd.choice(ICE)
        return f"a body-wide shell of clear and frosted ice fused to her form, thick translucent ice plates and crusted hoarfrost with sharp feathery frost crystals growing outward along every curve, clear icicles hanging from the edges, BLAZING {b}, VIVID crisp white frost crystals fanning out from the edges", "ice"
    if key == "feather":
        b = rnd.choice(FEA)
        return f"layers of real feathers overlapping like plumage, every feather with its own shaft and fine barbs ruffling at the edges and casting small shadows on the feathers below, BLAZING {b}, VIVID long sweeping quill feathers and loose down floating around her", "feather"
    if key == "circuit":
        b, a = rnd.choice(CIR)
        return f"a dense printed-circuit surface grown over her skin, raised copper traces and solder pads running in tidy right-angled lines over every curve, tiny rectangles of black silicon chips set into the surface, BLAZING {b}, VIVID {a}", "circuit"
    if key == "nacre":
        b, a = rnd.choice(NAC)
        return f"overlapping mother-of-pearl nacre tiles set edge to edge over her skin, each tile with a fine edge and a soft milky lustre that shifts through rainbow colours across every curve, BLAZING {b}, VIVID {a}", "nacre"
    if key == "wing":
        b, a = rnd.choice(WIN)
        return f"thin translucent insect-wing membranes layered over her skin like overlapping dragonfly and butterfly wings, a network of fine dark veins and cells running through each wing, wing edges fringed with tiny scales, BLAZING {b}, VIVID {a}", "wing"
    if key == "mirror":
        b, a = rnd.choice(MIR)
        return f"hundreds of broken mirror shards of all sizes mosaicked over her skin, each shard with sharp straight edges set at a different angle and reflecting a different piece of the surroundings, thin dark grout lines between the shards, BLAZING {b}, VIVID {a}", "mirror"
    return _mt0(key)
FORCE = [None]
def pick_mats(n):
    while True:
        k = FORCE[0]
        rest = rnd.sample([m for m in MATKEYS if m not in NEWM], n - 1)
        mats = [k] + rest; rnd.shuffle(mats)
        if {"stone", "wood"} <= set(mats): continue
        return mats
items = []
PLAN = [(1, 3, "ice"), (1, 4, "feather"), (2, 3, "circuit"), (2, 3, "nacre"), (3, 3, "wing"), (3, 4, "mirror")]
BUST = ("legendary bust", "curved bust", "latina curves")
for sd in range(20261603, 20261800):
    rnd.seed(sd); items = []
    for gsize, n, k in PLAN:
        FORCE[0] = k
        for attempt in range(80):
            p, descs = build_mat(gsize, n)
            if not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p): break
        validate(f"nb6_{gsize}_{n}", p)
        items.append((gsize, n, " ; ".join(f"[{d}]" for d in descs), p))
    if sum(any(x in it[2] for x in BUST) for it in items) >= 3 and sum(any(x in it[2] for x in ("BBW bombshell", "super glamour", "amazon bombshell", "muscular hourglass BBW")) for it in items) >= 2: break
print("seed", sd)
GN = {1: "솔로", 2: "듀오", 3: "트리오"}
L = ["# 재질 블렌드(1인 몸 구역별 재질 섞기) + 새 재질 6종 — 솔로 2 · 듀오 2 · 트리오 2 (체형: 부피 큰 · 바스트 · 극심한 허리-힙)\n", "기존 Material Blend 틀(검은 피부·검은 배경, 구역 구조, 경계 흐림) 그대로이고, 구역 재질 중 하나가 새 재질(얼음·서리 / 깃털 / 회로·사이버 / 진주층 / 곤충 날개 / 거울 파편)입니다. 나머지 구역은 기존 재질에서 랜덤입니다. 번호별로 성공/실패만 알려주세요.\n"]
for i, (gs, n, desc, p) in enumerate(items, 1):
    L.append(f"## {i}. {GN[gs]} {n}혼합 · {desc}\n\n```\n{p}\n```\n")
open("/mnt/user-data/outputs/LumineX_MatBlend_New6_BigBust_Solo_Duo_Trio.md", "w", encoding="utf-8").write("\n".join(L))
for gs, n, desc, p in items: print(GN[gs], len(p.split()), desc[:200])
