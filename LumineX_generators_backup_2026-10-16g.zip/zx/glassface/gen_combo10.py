# -*- coding: utf-8 -*-
import re, sys
sys.path.insert(0, '.')
from full_dicts import face, NAIL_SHAPE_EN_FULL, NAIL_FIN_EN_FULL, HAIR_EN_FULL, SHOE_EN_FULL, POSE_EN_FULL, AGE_EN_FULL, VIBE_EN_FULL, CRAFT_DB_FULL
from body_full import BODY_FULL, BODY_PREGNANT, BODY_PREGNANT_MORE

banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","snake","safety pin","gash","crack","armor","armour","helmet","costume"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    low = p.lower()
    hits = [w for w in banned if re.search(r'\b'+w+r'\b', low)]
    assert not hits, (name,hits)
    risky = ['embroider','weav','woven','textile','stitch']
    rh = [w for w in risky if w in low]
    assert not rh, (name, "FABRIC_WORD", rh)
    lace_bad = re.findall(r'(?<!corset-)\blace\b(?!-up)', low)
    assert not lace_bad, (name, "LACE")

ALL_PREG = {**BODY_PREGNANT, **BODY_PREGNANT_MORE}
GEM_EN = {"GD":"diamonds","GP":"pearls","GO":"opals","GA":"amethysts","GR":"rubies","GS":"sapphires","GX":"mixed gems"}
FORM_EN = {"FH":"hoops","FS":"studs","FB":"bars","FC":"clicker rings","FD":"drop dangles","FG":"segment rings","FX":"mixed"}
METAL_EN = {"MG":"gold","MR":"rose-gold","MS":"silver","MC":"copper","MBR":"brass","MBZ":"bronze","MX":"mixed"}
PCOUNT = {"P0":"0","P3":"3","P5":"5","P8":"8"}
JTYPE_EN = {"JE":"earrings","JN":"a necklace","JB":"a bracelet","JR":"a ring","JA":"an anklet","JH":"a hair ornament"}
JMETAL_EN = {"JMG":"gold","JMS":"silver","JMR":"rose-gold","JMP":"platinum","JMX":"mixed-metal"}
JQ_SHORT = {"JQ1":"a single piece","JQ2":"two to three pieces","JQ3":"four to six pieces","JQ4":"seven to ten pieces, stacked"}
def pierce_phrase(p,f,g,m):
    if p=="P0": return "ears bare, no piercings"
    return f"{PCOUNT[p]} {FORM_EN[f]} piercings with {GEM_EN[g]} in {METAL_EN[m]}-toned metal"
BELLY_BOOST = "larger and more dramatically rounded than an ordinary full-term pregnancy, projecting forward well beyond the line of her own chest"

FACE_CUSTOM = {
 "아게하": ("Japanese","gyaru-style tan skin, heavy false lashes, glittery eyeshadow, glossy pale lip"),
 "한복화보": ("Korean","flawless porcelain skin, soft rose-pink lips, delicate graceful eye makeup"),
 "만바": ("Japanese","deep tan skin, bold white eyeliner, colorful glittery eyeshadow, a glossy nude lip"),
 "지뢰계": ("Japanese","pale skin, dark smoky eyes, red-toned makeup, a melancholic wistful expression"),
 "코갸루": ("Japanese","tan skin, loose white socks aesthetic makeup, glossy brown lip, playful eyes"),
 "아마갸루": ("Japanese","dark tan skin, heavy white eyeliner, glittery eyeshadow, a glossy pale lip"),
 "프렌치레드립": ("French","fair skin, a classic matte red lip, subtle winged eyeliner"),
 "GermanGlam": ("German","fair skin, sculpted contour, a nude glossy lip, polished blonde brows"),
 "레바논웨딩글램": ("Lebanese","olive skin, dramatic smoky eyes, a glossy nude lip, elaborate bridal glam"),
 "파케앙트글램": ("Filipina","warm golden-tan skin, dramatic smoky eyes, a glossy nude-brown lip"),
 "소피아로렌풍": ("Italian", "warm olive skin, dramatic winged eyeliner, a deep red lip"),
 "강남언니": ("Korean", "flawless porcelain skin, soft gradient lips, elegant refined eyeliner"),
 "화환화장": ("Thai", "warm golden-tan skin, a soft coral lip, delicate floral garland worn in her hair"),
 "웨이쉰": ("Chinese", "porcelain-pale skin, soft pink blush, a sweet dewy lip"),
}
def face_c(sty):
    if sty in FACE_CUSTOM: return FACE_CUSTOM[sty]
    return face(sty)

# ===== 바디페인팅 =====
BP_DATA = {
 "makeup": ["아게하","한복화보","만바","지뢰계","BollywoodGlam","AoDaiGlam"],
 "body": ["레전드바스트","브라질부티글램","블랙글래머","USSBBW","슈퍼글래머","아워글래스SSBBW"],
 "craft": ["IslamicGeometric","SpanishAndalusian","GeorgianMinonkari","FinnishIittala","IndianMughal","CroatianHvar"],
 "shoe": ["익스트림플랫폼버클부츠","익스트림플랫폼하이힐","익스트림플랫폼싸이하이부츠","익스트림플랫폼클리어힐","익스트림플랫폼레이스업샌들","익스트림플랫폼웨지"],
 "pose": ["3/4각도","양무릎꿇고정면","뒷모습3/4","얼굴감싸기","완전뒷모습","벽에기대기"],
 "nail_s": ["NS스퀘어","NR라운드","NA아몬드","NO오벌","NT스틸레토","NC코핀"],
 "nail_f": ["FC크롬","FT글리터","FH홀로그래픽","FG글로시","FM매트","FT글리터"],
 "hair": ["HSPT포니테일","HSTT트윈테일","HSC컬","HSU업두","HSW웨이브","HSB브레이드"],
 "age": ["A50M","A50E","A50L","A40M","A20E","A40E"],
 "vibe": ["VCH시크한","VC귀여운","VP청순한","VS섹시한","VPR도발적인","VC귀여운"],
}
bp_counter = [0]
def bp_block(label):
    i = bp_counter[0] % 6
    bp_counter[0] += 1
    nat, fa = face_c(BP_DATA["makeup"][i])
    bodykey = BP_DATA["body"][i]
    bodytext = BODY_FULL[bodykey]
    cn, cd, cb, cf = CRAFT_DB_FULL[BP_DATA["craft"][i]]
    nail = f"{NAIL_SHAPE_EN_FULL[BP_DATA['nail_s'][i]]} nails, {NAIL_FIN_EN_FULL[BP_DATA['nail_f'][i]]} finish"
    hair = HAIR_EN_FULL[BP_DATA["hair"][i]]; age = AGE_EN_FULL[BP_DATA["age"][i]]; vibe = VIBE_EN_FULL[BP_DATA["vibe"][i]]
    pose = POSE_EN_FULL[BP_DATA["pose"][i]]; shoe = SHOE_EN_FULL[BP_DATA["shoe"][i]]
    return (f"{label} (Bodypaint track): a real adult {nat} woman in her {age}, her face exactly the same tone as her body, real skin texture with visible pores, {fa}, {vibe}, {hair} hair, real living eyes. Long {nail}. "
            f"An extraordinarily large woman, far beyond any real person. {bodytext} "
            f"Painted in {cn} ({cd}), wide {cb} bands following every deep crease, dense {cf} filling the space between bands, pigment on living skin, covering her whole body below the jaw with no bare skin anywhere, face unpainted. "
            f"Pose: {pose}. Footwear: extreme {cb} {shoe}.")

# ===== 임산부 =====
PREG_BODIES = ['임산부글래머','임산부콜로설','임산부풀텀트윈즈','임산부USSBBW','임산부아워글래스SSBBW','임산부슈퍼글래머']
PREG_DATA = {
 "makeup": ["레바논웨딩글램","파케앙트글램","소피아로렌풍","강남언니","화환화장","웨이쉰"],
 "body": PREG_BODIES,
 "craft": ["TurkishIznik","GeorgianMinonkari","PortugueseAzulejo","UkrainianPysanka","MoroccanZellige","YorubaAdireEleko"],
 "shoe": ["익스트림플랫폼하이힐","익스트림플랫폼스퀘어토힐","익스트림플랫폼버클부츠","익스트림플랫폼클리어힐","익스트림플랫폼레이스업샌들","익스트림플랫폼웨지"],
 "nail_s": ["NS스퀘어","NT스틸레토","NA아몬드","NC코핀","NR라운드","NO오벌"],
 "nail_f": ["FG글로시","FH홀로그래픽","FC크롬","FT글리터","FM매트","FG글로시"],
 "hair": ["HSU업두","HSS스트레이트","HSC컬","HSW웨이브","HSB브레이드","HSBN번"],
 "age": ["A40E","A30L","A30M","A20E","A40L","A30E"],
 "vibe": ["VC귀여운","VPR도발적인","VCH시크한","VS섹시한","VP청순한","VC귀여운"],
 "pierce_p": ["P3","P5","P0","P8","P3","P5"],
 "pierce_f": ["FB","FG","FD","FH","FC","FB"],
 "pierce_g": ["GP","GD","GR","GS","GA","GO"],
 "pierce_m": ["MS","MX","MBZ","MG","MC","MBR"],
 "jq": ["JQ4","JQ1","JQ2","JQ3","JQ4","JQ1"],
 "jtype": ["JN","JH","JE","JB","JR","JA"],
 "jmetal": ["JMR","JMG","JMS","JMP","JMX","JMR"],
}
preg_counter = [0]
def preg_block(label):
    i = preg_counter[0] % 6
    preg_counter[0] += 1
    nat, fa = face_c(PREG_DATA["makeup"][i])
    bodykey = PREG_DATA["body"][i]
    bodytext = ALL_PREG[bodykey].replace("a high, smoothly rounded pregnant belly", f"a high, smoothly rounded pregnant belly, {BELLY_BOOST},", 1)
    cn, cd, cb, cf = CRAFT_DB_FULL[PREG_DATA["craft"][i]]
    nail = f"{NAIL_SHAPE_EN_FULL[PREG_DATA['nail_s'][i]]} nails, {NAIL_FIN_EN_FULL[PREG_DATA['nail_f'][i]]} finish"
    pierce = pierce_phrase(PREG_DATA["pierce_p"][i], PREG_DATA["pierce_f"][i], PREG_DATA["pierce_g"][i], PREG_DATA["pierce_m"][i])
    jewelry = f"{JQ_SHORT[PREG_DATA['jq'][i]]} of {JMETAL_EN[PREG_DATA['jmetal'][i]]} {JTYPE_EN[PREG_DATA['jtype'][i]]}"
    return (f"{label} (Pregnant track): {nat}, in her {AGE_EN_FULL[PREG_DATA['age'][i]]}, {VIBE_EN_FULL[PREG_DATA['vibe'][i]]} expression, warm radiant skin tone, extraordinarily large pregnant physique far beyond any real person — {bodytext} "
            f"Her face is a real living adult face, {fa}, {HAIR_EN_FULL[PREG_DATA['hair'][i]]} hair, real pores, {pierce}, wearing {jewelry}. "
            f"Painted in {cn}, {cd}, covering every inch of skin from neck to ankle, wide {cb} bands curving fully around her belly, the densest concentration of {cf} wrapping the belly as centrepiece and continuing over her bust, nowhere left bare. "
            f"Pose: standing frontal, both hands cradling the underside of her belly, extreme {cb} {SHOE_EN_FULL[PREG_DATA['shoe'][i]]}.")

PHYSIQUES = [
 ("super hourglass", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum beyond any proportion, most dramatic hourglass ratio ever recorded on any human body, thighs so thick pressing together"),
 ("wide hip narrow", "hips so impossibly wide extending beyond frame creating the most extreme hip-to-waist ratio ever, waist cinched to absolute impossible minimum, upper body slim emphasizing the dramatic hip explosion"),
 ("BBW bombshell", "most massive full-figure BBW body ever at absolute maximum in every dimension, hips so wide beyond proportion dominating the entire frame, bust so enormous overwhelming gravity, waist deeply snatched despite impossible volume"),
 ("curvy petite", "smallest most compact frame possible yet curves exploding at absolute maximum in every direction, bubble butt projecting dramatically backward from the tiny frame, thighs so thick they dwarf the petite frame"),
 ("amazon bombshell", "impossibly tall commanding frame with simultaneously the most massive full-figure curves, enormous powerful presence dominating the entire frame top to bottom, legs endlessly long massively thick and powerful"),
]
HAIRS = ["long sleek jet-black hair cascading past hips","silver-white natural hair swept into a high sculpted crown","loose beach waves mid-length tousled","blunt collarbone-length bob thick heavy","silver-white locs cascading to her waist"]
POSES_M = ["strong hip pop right, both hands pressing sides of hips outward simultaneously arching back to extreme",
 "full frontal wide stance, both fists pressing outer hips outward to absolute maximum",
 "standing full height, both arms slightly spread commanding the frame",
 "back three-quarter turned, face over shoulder direct eye contact, bubble butt projected backward",
 "strong hip pop left, both hands pressing outer hips outward arching back to extreme"]
AGES_M = ["early 30s","late 20s","mid 40s","late 30s","mid 50s"]

IREZUMI_POOL = [
 ("dragon phoenix", "BLAZING ELECTRIC GOLD dragon coiling the full torso and both legs neck to ankle, VIVID CRIMSON phoenix wings spreading across the full chest"),
 ("koi sakura", "BLAZING CRIMSON koi ascending spiral full torso both legs neck to ankle, VIVID PINK sakura petal cascade filling every gap"),
 ("chrysanthemum", "BLAZING DEEP GOLD chrysanthemum blooms enormous layered petals full torso both legs neck to ankle, VIVID EMERALD leaf lattice filling every gap"),
 ("wisteria", "BLAZING ELECTRIC VIOLET wisteria cascading full torso both legs neck to ankle, STARK WHITE highlight detail filling every gap"),
 ("plum crane", "BLAZING VIVID CRIMSON plum blossom storm full torso both legs neck to ankle, VIVID GOLD crane pair soaring filling every gap"),
 ("peony", "BLAZING VIVID PINK peony blooms cascading full torso both legs neck to ankle, ELECTRIC GOLD centre highlights filling every gap"),
 ("tiger", "BLAZING VIVID ORANGE tiger stripes wrapping the full torso both legs neck to ankle, STARK BLACK stripe detail and fierce tiger face motifs filling every gap"),
 ("great wave", "BLAZING DEEP COBALT wave crest formations sweeping the full torso both legs neck to ankle, STARK WHITE foam spray filling every gap"),
 ("bamboo forest", "BLAZING DEEP EMERALD bamboo stalks wrapping the full torso both legs neck to ankle, VIVID JADE leaf clusters filling every gap"),
 ("orchid", "BLAZING DEEP VIOLET orchid blossoms cascading the full torso both legs neck to ankle, VIVID EMERALD leaf detail filling every gap"),
]
UV_POOL = [
 ("cosmic nebula", "ELECTRIC MAGENTA nebula cloud formations swirling across the chest and upper body, VIVID NEON CYAN plasma stream formations flowing down both legs, BLAZING NEON GOLD star cluster formations filling every gap"),
 ("lightning web", "ELECTRIC EMERALD lightning bolt formations branching across the full torso both legs neck to ankle, VIVID NEON YELLOW spark burst formations filling every gap"),
 ("crystal lattice", "ELECTRIC VIOLET geometric lattice facets full torso both legs to ankle, prismatic crystal faces refracting CYAN light"),
 ("ocean wave", "ELECTRIC CYAN ocean wave formations flowing organically full torso both legs neck to ankle, VIVID WHITE seafoam accent filling every gap"),
 ("aurora curtain", "ELECTRIC GREEN aurora curtain formations rippling across the full torso both legs neck to ankle, VIVID VIOLET edge-glow detail filling every gap"),
 ("DNA helix", "ELECTRIC MAGENTA double-helix formations spiraling the full torso both legs neck to ankle, VIVID CYAN rung-connector detail filling every gap"),
 ("plasma vortex", "ELECTRIC VIOLET vortex formations swirling the full torso both legs neck to ankle, VIVID MAGENTA core-glow detail filling every gap"),
 ("meteor shower", "ELECTRIC CYAN streak formations sweeping the full torso both legs neck to ankle, VIVID WHITE trail-spark detail filling every gap"),
 ("supernova burst", "ELECTRIC GOLD radial burst formations across the full torso both legs neck to ankle, VIVID MAGENTA shockwave-ring detail filling every gap"),
 ("magnetic field lines", "ELECTRIC CYAN field-line formations curving the full torso both legs neck to ankle, VIVID VIOLET pole-point detail filling every gap"),
]

ire_ctr = [0]
def irezumi_block(label):
    i = ire_ctr[0]; ire_ctr[0] += 1
    motif_name, motif_ink = IREZUMI_POOL[i % len(IREZUMI_POOL)]
    phy_name, phy_detail = PHYSIQUES[i % 5]
    return (f"{label} (Irezumi track): THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {AGES_M[i%5]} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {HAIRS[i%5]} — full body {motif_name} irezumi covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Bold black ink outlines — {motif_ink}, NO airbrush NO gradient wash. Pose: {POSES_M[i%5]} — most extreme {phy_name} silhouette ever displayed. Footwear: platform boots 8 inch, extra long stiletto nails to match.")

uv_ctr = [0]
def uvneon_block(label):
    i = uv_ctr[0]; uv_ctr[0] += 1
    motif_name, motif_ink = UV_POOL[i % len(UV_POOL)]
    phy_name, phy_detail = PHYSIQUES[(i+2) % 5]
    return (f"{label} (UV Neon track): THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {AGES_M[(i+2)%5]} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, UV-reactive BLAZING {HAIRS[(i+2)%5]} — full body UV neon {motif_name} bodypaint covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Bold formations — BLAZING {motif_ink}, NO airbrush NO gradient wash. Pose: {POSES_M[(i+2)%5]} — most extreme {phy_name} silhouette ever displayed. Under her own dedicated UV blacklight spot, zero white light reaching her specifically. Footwear: platform boots 8 inch, extra long stiletto nails BLAZING NEON UV reactive tips.")

GLASS_COLORS = [("ELECTRIC CRIMSON","VIVID GOLD"),("ELECTRIC VIOLET","VIVID CYAN"),("ELECTRIC EMERALD","VIVID GOLD"),("ELECTRIC MAGENTA","VIVID SILVER")]
glass_ctr = [0]
def glass_block(label):
    i = glass_ctr[0]; glass_ctr[0] += 1
    phy_name, phy_detail = PHYSIQUES[i % 5]
    c1,c2 = GLASS_COLORS[i % len(GLASS_COLORS)]
    return (f"{label} (Stained Glass track): THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {AGES_M[i%5]} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {HAIRS[i%5]} — full body stained glass covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is solid thick glass fused directly to her form, not a garment, made of hundreds of small individual panes each no larger than a coin, densely packed edge to edge, never large sheets, each tiny pane curving to follow her body's true shape with real physical thickness, dark lead-line seams webbing between every pane, each seam standing in a small raised ridge casting its own shadow, never flat. BLAZING {c1} and VIVID {c2} panes alternating in a dense irregular mosaic, bright light passing through each tiny pane with sharp refraction glints, NO airbrush NO gradient wash. Pose: {POSES_M[i%5]} — most extreme {phy_name} silhouette ever displayed. Footwear: leaded-glass platform boots 8 inch, the same dense small-pane mosaic continuing onto the shoe, extra long stiletto nails to match.")

LEAF_COLORS = [("ELECTRIC CRIMSON","GOLD"),("ELECTRIC VIOLET","CYAN"),("ELECTRIC EMERALD","GOLD"),("ELECTRIC MAGENTA","SILVER")]
gold_ctr = [0]
def goldleaf_block(label):
    i = gold_ctr[0]; gold_ctr[0] += 1
    phy_name, phy_detail = PHYSIQUES[i % 5]
    c1,c2 = LEAF_COLORS[i % len(LEAF_COLORS)]
    return (f"{label} (Gold Leaf track): THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {AGES_M[i%5]} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {HAIRS[i%5]} — full body applied {c1} leaf covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Thin irregular metallic sheets — BLAZING {c1} leaf with fine natural creases and overlapping seams, VIVID {c2} undertone glinting through the thinnest points, a soft warm metallic sheen filling every gap, NO airbrush NO gradient wash. Pose: {POSES_M[i%5]} — most extreme {phy_name} silhouette ever displayed. Footwear: platform boots 8 inch, extra long stiletto nails to match.")

FLOWERS = [("peony","CRIMSON","EMERALD"),("orchid","VIOLET","GOLD"),("sakura","PINK","GOLD"),("lotus","PINK","JADE")]
bot_ctr = [0]
def botanical_block(label):
    i = bot_ctr[0]; bot_ctr[0] += 1
    phy_name, phy_detail = PHYSIQUES[i % 5]
    flower,c1,c2 = FLOWERS[i % len(FLOWERS)]
    return (f"{label} (Botanical track): THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {AGES_M[i%5]} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, hair threaded through with real trailing vines — full body living {flower} growing directly from her own skin covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not a printed pattern, not a dress, every stem rooted directly into her living skin and every petal standing up in true three-dimensional relief casting its own small shadow, nothing lying flat. BLAZING {c1} {flower} blossoms in full three-dimensional bloom, VIVID {c2} leaves and curling tendrils filling every remaining gap with real depth and texture, NO airbrush NO gradient wash, NO flat printed surface anywhere. Pose: {POSES_M[i%5]} — most extreme {phy_name} silhouette ever displayed. Footwear: extreme platform heels entirely overgrown with the same living {flower} blooms and vines, extra long nails with tiny petals embedded at each tip.")

TRACK_FN = {"bp": bp_block, "preg": preg_block, "ire": irezumi_block, "uv": uvneon_block, "glass": glass_block, "gold": goldleaf_block, "bot": botanical_block}
TRACK_KO = {"bp":"바디페인팅","preg":"임산부","ire":"이레즈미","uv":"UV네온","glass":"스테인드글라스","gold":"금박","bot":"보태니컬"}
LABELS = ["#1","#2","#3","#4","#5"]
NUM_WORD = {3:"THREE",4:"FOUR",5:"FIVE"}
ASPECT = {3:"4:5",4:"4:5",5:"5:4"}

def reset_all():
    bp_counter[0]=0; preg_counter[0]=0; ire_ctr[0]=0; uv_ctr[0]=0; glass_ctr[0]=0; gold_ctr[0]=0; bot_ctr[0]=0

def build_combo(track_keys):
    n = len(track_keys)
    labels = LABELS[:n]
    blocks = [TRACK_FN[track_keys[i]](labels[i]) for i in range(n)]
    body = "\n\n".join(blocks)
    return f"""Professional fashion photograph, full body shot. {NUM_WORD[n]} women standing side by side, each from a different Living Artifact track.

{body}

MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. Composition: each woman's own pose as described, inner arms not crossing her neighbours. Lighting: a single hard key light raking across all bodypaint/pregnant/irezumi/stained-glass/gold-leaf/botanical women from one side, realistic photographic grain where applicable, extreme high-gloss oil on maximalist tracks — a real photograph, not an illustration, not CGI, not a render; any UV Neon track woman additionally lit by her own dedicated UV blacklight spot. Pattern density maximum on all {n}, zero bare skin from neck to ankle. Shot on a Hasselblad X2D, {ASPECT[n]} aspect ratio."""

COMBOS = [
 ("Trio", ("preg","gold","bot")), ("Trio", ("preg","gold","bot")),
 ("Quartet", ("bp","preg","ire","uv")), ("Quartet", ("bp","preg","ire","uv")),
 ("Quartet", ("ire","uv","glass","gold")), ("Quartet", ("ire","uv","glass","gold")),
 ("Quintet", ("bp","preg","ire","uv","glass")), ("Quintet", ("bp","preg","ire","uv","glass")),
 ("Quintet", ("ire","uv","glass","gold","bot")), ("Quintet", ("ire","uv","glass","gold","bot")),
]

OUT = []
for idx,(label_type, combo) in enumerate(COMBOS):
    reset_all()
    p = build_combo(combo)
    check(f"combo{idx}", p)
    combo_ko = "+".join(TRACK_KO[t] for t in combo)
    OUT.append((f"{label_type} #{idx%2+1} — {combo_ko}", p))

for label,p in OUT:
    print(label, len(p.split()))

L = ["# LumineX · 지정 트랙 조합 10개\n"]
for label,p in OUT:
    L.append(f"## {label}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_SpecifiedCombos_10.md","w",encoding="utf-8").write("\n".join(L))
print("saved")
