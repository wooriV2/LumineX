# -*- coding: utf-8 -*-
import re, random, json, sys
sys.path.insert(0, '.')
from full_dicts import SCALE_ANIMAL_DB

banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","safety pin","gash","crack"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    low = p.lower()
    hits = [w for w in banned if w in low]
    assert not hits, (name,hits)

PHYSIQUES = [
 ("super hourglass", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum beyond any proportion, most dramatic hourglass ratio ever recorded on any human body, thighs so thick pressing together"),
 ("wide hip narrow", "hips so impossibly wide extending beyond frame creating the most extreme hip-to-waist ratio ever, waist cinched to absolute impossible minimum, upper body slim emphasizing the dramatic hip explosion"),
 ("BBW bombshell", "most massive full-figure BBW body ever at absolute maximum in every dimension, hips so wide beyond proportion dominating the entire frame, bust so enormous overwhelming gravity, waist deeply snatched despite impossible volume"),
 ("curvy petite", "smallest most compact frame possible yet curves exploding at absolute maximum in every direction, bubble butt projecting dramatically backward from the tiny frame, thighs so thick they dwarf the petite frame"),
 ("amazon bombshell", "impossibly tall commanding frame with simultaneously the most massive full-figure curves, enormous powerful presence dominating the entire frame top to bottom, legs endlessly long massively thick and powerful"),
 ("latina curves", "most dramatic hourglass ratio ever, simultaneously maximum enormous bust AND maximum enormous hips both flaring to absolute impossible extremes while the waist is cinched to impossible minimum"),
 ("hourglass bombshell", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum, thighs pressing together, every curve maximized at once"),
 ("powerlifter bombshell", "immense powerful thighs and shoulders built with real strength, a thick solid waist, overwhelming muscular bulk layered with soft curves everywhere"),
]
HAIRS = ["long sleek jet-black hair cascading past hips","silver-white natural hair swept into a high sculpted crown","loose beach waves mid-length tousled","blunt collarbone-length bob thick heavy","silver-white locs cascading to her waist","curtain bangs long straight hair sweeping past the shoulders","two thick goddess braids","high ponytail swept sleek"]
POSES = ["strong hip pop right, both hands pressing sides of hips outward simultaneously arching back to extreme",
 "full frontal wide stance, both fists pressing outer hips outward to absolute maximum",
 "standing full height, both arms slightly spread commanding the frame",
 "back three-quarter turned, face over shoulder direct eye contact, bubble butt projected backward",
 "strong hip pop left, both hands pressing outer hips outward arching back to extreme",
 "full frontal, both hands framing the face, chin raised",
 "three-quarter angle, one hand on the outer hip, the other raised overhead"]
AGES = ["early 20s","late 20s","early 30s","mid 30s","late 30s","mid 40s","early 50s","mid 50s"]

CRYSTAL_COLORS = [
 ("ICE BLUE", "SILVER-WHITE", "ice crystal"), ("ROSE QUARTZ PINK", "SOFT GOLD", "rose quartz crystal"),
 ("AMETHYST VIOLET", "DEEP GOLD", "amethyst crystal"), ("CITRINE YELLOW", "AMBER", "citrine crystal"),
 ("EMERALD GREEN", "GOLD", "emerald crystal"), ("SMOKY GREY", "CHARCOAL", "smoky quartz crystal"),
 ("SAPPHIRE BLUE", "SILVER", "sapphire crystal"), ("RUBY RED", "GOLD", "ruby crystal"),
 ("TOPAZ ORANGE", "BRONZE", "topaz crystal"), ("CLEAR WHITE", "PRISMATIC RAINBOW", "clear quartz crystal"),
]

rnd = random.Random(42042)
def rpick(pool): return rnd.choice(pool)

def crystal_block(label, idx):
    phy_name, phy_detail = PHYSIQUES[idx % 8]
    c1,c2,surface = rpick(CRYSTAL_COLORS)
    age = AGES[idx % 8]; hair = HAIRS[idx % 8]; pose = POSES[idx % 7]
    mat = (f"full body {surface} clusters growing directly out of her own skin covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, every crystal point erupting outward from beneath the surface of her living skin in true three-dimensional relief, each facet catching its own individual glint and casting its own small hard shadow onto the skin and onto neighbouring crystals, nothing lying flat. Dense overlapping clusters — BLAZING {c1} crystal points erupting across the full torso both legs neck to ankle, VIVID {c2} mineral veins and undertone glinting through the thinnest points filling every remaining gap with real depth and texture, each facet sharply faceted and distinct, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    prefix = f"{label}: " if label else ""
    return (f"{prefix}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {hair} — {mat}. Pose: {pose} — most extreme {phy_name} silhouette ever displayed.\n"
            f"{prefix}extreme platform heels entirely encrusted with the same erupting {surface} clusters, extra long stiletto nails with tiny individual crystal points erupting at each tip.")

def scale_block(label, idx):
    phy_name, phy_detail = PHYSIQUES[idx % 8]
    animal = rpick(list(SCALE_ANIMAL_DB.keys()))
    shape, colorlist = SCALE_ANIMAL_DB[animal]
    c1,c2 = rpick(colorlist)
    age = AGES[idx % 8]; hair = HAIRS[idx % 8]; pose = POSES[idx % 7]
    mat = (f"her own skin itself covered in {shape} covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not fabric, not a garment, not a printed pattern, this is the real cellular structure of her own skin, each scale casting its own small shadow on the scales beneath it, nothing lying flat as one smooth sheet. Dense overlapping fields — BLAZING {c1} scale formations shifting across the full torso both legs neck to ankle, VIVID {c2} scale-edge detail filling every remaining gap with real texture, every scale catching the light with a sharp shifting glint as the angle changes, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    prefix = f"{label}: " if label else ""
    return (f"{prefix}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {hair} — {mat}. Pose: {pose} — most extreme {phy_name} silhouette ever displayed.\n"
            f"{prefix}extreme platform heels covered in the same scale texture, the shimmer continuing unbroken onto the shoe, extra long stiletto nails with the same iridescent shimmer at each tip."), animal

NUM_WORD = {1:"ONE",2:"TWO",3:"THREE"}
ASPECT = {1:"2:3",2:"3:4",3:"4:5"}
LABELS3 = ["#1","#2","#3"]

def build(material, n, slot_base):
    labels = LABELS3[:n] if n>1 else [None]
    blocks = []
    animals_used = []
    for i in range(n):
        idx = slot_base*3+i
        if material == "crystal":
            blocks.append(crystal_block(labels[i], idx))
        else:
            b, a = scale_block(labels[i], idx)
            blocks.append(b); animals_used.append(a)
    body = "\n\n".join(blocks)
    if n == 1:
        bg = "MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. ONE woman only."
    else:
        bg = f"Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.\nAll:"
    detail = "Extreme macro detail on every crystal facet and shadow." if material=="crystal" else "Extreme macro detail on every individual scale and shadow."
    critical = f"CRITICAL: all {n} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere, every element standing in true relief, nothing flat. {NUM_WORD[n]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame." if n>1 else "Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
    p = f"""Professional fashion photograph, full body shot. {NUM_WORD[n]} wom{"a" if n==1 else "e"}n standing{" side by side" if n>1 else ""}.

{body}

{bg} {detail} {critical} 8K portrait {ASPECT[n]} aspect ratio."""
    return p, animals_used

TYPE_NAME = {1:"solo",2:"duo",3:"trio"}
all_presets = []
for material in ["crystal","scale"]:
    for n in [1,2,3]:
        type_name = TYPE_NAME[n]
        for slot in range(1,31):
            p, animals = build(material, n, slot)
            check(f"{material}_{type_name}_{slot}", p)
            key = f"la_{material}_{type_name}_{slot:02d}"
            cat = "🏺 Living Artifact · Crystal Formula" if material=="crystal" else "🏺 Living Artifact · Scale Formula"
            title_extra = f" ({'/'.join(animals)})" if animals else ""
            all_presets.append({
                "key": key, "category": cat,
                "title": f"{material.capitalize()} {type_name.capitalize()} #{slot:02d}{title_extra}",
                "prompt": p, "meta": {"group_size": n, "aspect_ratio": ASPECT[n], "material": material}
            })

print("생성:", len(all_presets))
with open("/home/claude/glassface/la_180_bundle.json","w",encoding="utf-8") as f:
    json.dump(all_presets, f, ensure_ascii=False, indent=2)
print("저장 완료")
