# -*- coding: utf-8 -*-
import re
O = "/mnt/user-data/outputs/"
def blocks(f): return re.findall(r"```\n(.*?)\n```", open(O + f, encoding="utf-8").read(), re.S)
def sub(t, a, b):
    assert t.count(a) == 1, a; return t.replace(a, b)
THREE = "She has three breasts: a matching pair in the usual place and a third full breast centred directly below the pair, the same size, shape and skin as the others, the three together forming a gentle triangle, all three fully covered by the body art"
iz = blocks("LumineX_Irezumi_ProvenFormat_3.md")[0]
iz = sub(iz, "the single defining feature of her frame, every other curve secondary to it.", "the single defining feature of her frame, every other curve secondary to it. " + THREE + ".")
iz = sub(iz, "Pose: both hands framing her own face.", "Pose: standing squarely facing the camera, both hands resting on her outer hips so the chest is fully visible.")
uv = blocks("LumineX_UVNeon_SoloDuoTrio_Test.md")[0]
uv = sub(uv, "hips AND bust simultaneously flaring to absolute maximum beyond any proportion,", "hips AND bust simultaneously flaring to absolute maximum beyond any proportion, with three breasts — a matching pair in the usual place and a third full breast centred directly below the pair, all three the same size and shape and all fully covered by the UV bodypaint,")
bp = blocks("LumineX_Bodypaint_Spiral_Honeycomb_2.md")[0]
bp = sub(bp, "A full, rounded bust,", "Three full, rounded breasts — a matching pair in the usual place and a third centred directly below the pair, all the same size and shape, together forming a gentle triangle, all three fully covered by the painted pattern —")
o = ["# 가슴 3개 시험 3개 — 바디페인팅 / 이레즈미 / UV네온\n", "각 트랙의 기존 성공 프롬프트에 가슴 3개 문장만 추가했습니다 (가슴 한 쌍 + 그 아래 가운데 하나, 전부 문양으로 덮임). 정면 서기로 가슴이 보이게 했습니다. 번호별로 정상/이상만 알려주세요. 이상이면 가슴이 몇 개로 나왔는지 한 줄만 적어주세요.\n",
     "## 1. 바디페인팅(프랙탈 스파이럴) · 한국 · 20대 · 아워글래스 · 메이크업 윙 라이너+로즈코랄 립 · 가슴 3개\n\n```\n" + bp + "\n```\n",
     "## 2. 이레즈미 · 한국 · 40대 · 레전드 바스트 · 메이크업 샴페인 골드 글리터 스모키+로즈 그라데이션 립 · 가슴 3개\n\n```\n" + iz + "\n```\n",
     "## 3. UV네온 코스믹 네뷸러 · 블루블랙 피부 · 30대 · 슈퍼 아워글래스 · 가슴 3개\n\n```\n" + uv + "\n```\n"]
open(O + "LumineX_ThreeBreasts_Test3.md", "w", encoding="utf-8").write("\n".join(o)); print("ok")
