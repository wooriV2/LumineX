# -*- coding: utf-8 -*-
# 단계 메이크업 풀: 이미 보낸 단계 시험 파일에서 메이크업 문구를 추출한다 (검증된 문구 그대로).
import re, json
import cjk_face_lib as C
OUT = "/mnt/user-data/outputs/"
FILES = {"코갸루": ["Kogyaru_Intensity5", "Kogyaru_Extreme6"], "마이코": ["Maiko_Intensity5"], "경극": ["PekingOpera_Intensity5"],
         "혼례(연지곤지)": ["KoreanBride_Intensity5"], "둔황 비천풍": ["Dunhuang_Intensity5"], "글래스 스킨": ["GlassSkin_Intensity5"],
         "비주얼계 블랙립": ["BL_Visual_Intensity5"], "고스 블랙립": ["BL_Goth_Intensity5"], "비닐 블랙립": ["BL_Vinyl_Intensity5"],
         "립온리 블랙": ["BL_LipOnly_Intensity5"], "뱀파이어 다크": ["BL_Vampire_Intensity5"],
         "클래식 레드립": ["RL_Classic_3"], "와인 레드립": ["RL_Wine_3"], "코랄 립": ["RL_Coral_3"], "푸시아 립": ["RL_Fuchsia_3"], "블러드 립": ["RL_Blood_3"]}
def extract(fn):
    s = open(OUT + f"LumineX_{fn}.md", encoding="utf-8").read(); res = []
    for m in re.finditer(r"^## (.+?)\n\n```\n(.*?)\n```", s, re.M | re.S):
        lab, t = m.group(1), m.group(2)
        hit = None
        for ex, ph in C.EXPR.items():
            if ", " + ph in t: hit = ph; break
        assert hit, (fn, lab)
        a = t.index(C.PFX) + len(C.PFX); b = t.index(", " + hit)
        res.append((lab, t[a:b], C.TAN in t))
    return res
POOL = {k: [x for fn in v for x in extract(fn)] for k, v in FILES.items()}
if __name__ == "__main__":
    for k, v in POOL.items():
        print("##", k)
        for lab, mk_, tan in v: print("  ", lab, "| TAN" if tan else "|", mk_[:110])
