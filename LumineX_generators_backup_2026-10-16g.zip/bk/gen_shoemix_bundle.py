# -*- coding: utf-8 -*-
# Persona Mix 300: 컨셉(재질 짝짓기) · 새 포즈 · 보호 스타일 헤어 · 메두사 뱀 머리 · 앵글 5종을 섞은 번들
import re, random, sys, json, collections
sys.path.insert(0, "../bg")
src6 = open("gen_persona6.py", encoding="utf-8").read()
exec(src6[:src6.index("PERS = {}")])
rg = random.Random(20261150)
PERS = {}
orig_disp3 = disp3
SNAKE = "a mass of dozens of thick coiling snakes carved from the same {m}, each snake with a detailed head, open eyes and a flicking tongue, writhing around her head and falling down her back, the snakes are her hair"
def disp4(label, kind, pick, phys, age, pose, eth, heel_in):
    pe = PERS.get(label)
    HAIRO[0] = pe[1] if pe else None
    t, info, nm = orig_disp3(label, kind, pick, phys, age, pose, eth, heel_in)
    if pe and pe[1] and kind not in NEWV and kind not in PAINT:
        t, n = re.subn(r', ([^,—]+?) hair — ', f', {pe[1]} — ', t, count=1); assert n == 1
    if pe and pe[0]:
        t, n = re.subn(r" goddess, ", f", {pe[0]}, ", t, count=1); assert n == 1
    return t, info, nm
ns2["person"] = disp4
CAMD = {"base": ("기본(허리 높이)", None),
 "high": ("하이앵글 70도", "Full-length steep high-angle shot taken from far above with a long telephoto lens, the camera directly above and in front of her angled roughly seventy degrees downward as if from a high ceiling or drone, flat telephoto compression with natural proportions and no wide-angle distortion, the whole figure from head to boots fully visible,"),
 "side": ("측면", "Full-length side view with the camera at waist height, her body in clean profile,"),
 "low": ("극단 로우앵글", "Full-length EXTREME worm's-eye view shot with the camera placed on the floor at boot level and tilted steeply upward, the towering heels and boots huge in the foreground, her legs rising in exaggerated perspective and her head far above at the top of the frame,"),
 "tq": ("극단 3/4 앵글", "Full-length EXTREME three-quarter view from the far front-left, her whole body turned a full sixty degrees away from the camera with her shoulders and hips twisted, the camera at waist height and pushed close for strong foreshortening,")}
CAMBASE = "Full-length wide shot from a moderate distance with the camera at waist height,"
def pick_angle(n):
    if n >= 4: ks, ws = ["base", "high", "side"], [55, 30, 15]
    else: ks, ws = ["base", "high", "low", "side", "tq"], [38, 20, 15, 15, 12]
    return rg.choices(ks, ws)[0]
ETHD = {e[0]: e for e in ETH}
CAT = "🏺 Living Artifact · Shoe Mix Formula"
def draw_picks(kinds):
    picks = []
    for idx, k in enumerate(kinds):
        lab = f"#{idx+1}" if len(kinds) > 1 else None
        if k == "bodypaint": picks.append(rg.choice(BP))
        elif k == "irezumi": picks.append(rg.choice(IR))
        elif k == "uvneon": picks.append(rg.choice(UV))
        elif k == "wood": picks.append(rg.choice(WOODS))
        elif k == "stone": picks.append(rg.choice(STONES))
        else:
            v = rg.choice(NEWV[k]); CUR_VAR[(lab, k)] = v; picks.append(v)
    return picks
def pick_name(k, p):
    if k in NEWV: return f"{KO[k]} {p[7]}"
    if k == "bodypaint": return KO[k] + " " + re.search(r"painted in (.+?) —", p[0]).group(1)
    if k in ("irezumi", "uvneon"): return KO[k] + " " + re.search(r"full body (.+?) (?:irezumi|bodypaint)", p[0]).group(1)
    if k == "wood": return f"목재 {p[0]}"
    if k == "stone": return f"석재 {p[0]}"
    return KO[k]

LI = {"golden": "golden hour warm backlight, skin luminosity, glowing", "octa": "professional octabox strobe, high-contrast glamour lighting",
      "neon": "multi-colored neon edge glow, cyberpunk light", "chiaro": "dramatic chiaroscuro, deep shadows and sharp highlights",
      "beauty": "soft beauty dish light, even flattering illumination", "hard": "harsh direct strobe, body muscle definition emphasis",
      "fog": "volumetric fog cinematic light, atmospheric mood", "rim": "strong rim backlight, silhouette definition, halo effect",
      "moon": "moonlight, silvery blue natural light, mysterious outdoor glow", "pink": "pink neon accent light, rose-toned atmospheric glow, fashion editorial lighting",
      "fire": "firelight, warm flickering flames, dramatic orange glow", "sun": "harsh direct sunlight, strong sharp shadows, high contrast"}
TM = {"blue": ("blue hour just before dawn, mystical pre-sunrise light, cool blue atmospheric glow", ["rim", "fog", "moon"]),
      "morning": ("morning golden hour, soft warm early sunlight, fresh dewy atmosphere", ["golden", "rim", "fog"]),
      "noon": ("midday harsh sunlight, strong direct light, sharp shadows, high contrast", ["sun"]),
      "afternoon": ("late afternoon warm sunlight, relaxed golden atmosphere, soft shadows", ["golden", "rim"]),
      "dusk": ("dusk twilight, dramatic sunset colors, sky ablaze with color", ["rim", "golden", "fire"]),
      "night": ("deep midnight, a dark sky overhead, mysterious nocturnal atmosphere", ["moon", "neon", "pink", "fire"])}
MD = ["dark glamour mood, intense dramatic atmosphere, powerful editorial energy", "dreamy ethereal mood, soft romantic atmosphere, fantasy editorial",
      "high fashion editorial mood, cold sophisticated atmosphere, sharp luxury", "bohemian free-spirited mood, natural earthy atmosphere, artistic editorial",
      "retro pin-up mood, vintage glamour atmosphere, classic playful editorial", "cyberpunk glamour mood, futuristic neon atmosphere, dystopian editorial",
      "romantic mood, soft warm atmosphere, tender feminine editorial", "powerful commanding mood, intense dominant atmosphere, fierce editorial",
      "mysterious alluring mood, enigmatic atmosphere, captivating editorial", "luxury opulent mood, sophisticated elegant atmosphere, high-end editorial",
      "playful vibrant mood, energetic joyful atmosphere, fresh editorial", "serene tranquil mood, peaceful calm atmosphere, meditative editorial"]
INDOOR_L = ["octa", "beauty", "chiaro", "hard", "neon", "pink", "rim", "fire"]
KEEP = ", every person's whole figure from the boots to the top of her head clearly lit and fully visible with every material detail sharp"

KEEP = ', every person\'s whole figure from the boots to the top of her head clearly lit and fully visible with every material detail sharp'

FORM_X = ["thigh-high platform stiletto boots", "strappy platform stiletto sandals", "pointed platform stiletto pumps", "knee-high lace-up platform stiletto boots", "platform stiletto corset-lace boots", "platform stiletto knee-high boots", "platform stiletto peep-toe heels", "extreme platform square-toe heels", "ankle-strap platform stilettos",
          "extreme platform lace-up sandals", "extreme platform thigh-skimming boots", "platform stiletto ankle boots", "platform stiletto cross-strap sandals", "platform stiletto studded boots",
          "platform stiletto Mary Janes", "platform stiletto slingbacks", "backless platform stiletto mule pumps"]
FORM[:] = FORM_X
ns2["FORM"][:] = FORM_X
KOF = ["허벅지 위 플랫폼 부츠", "스트랩 샌들", "포인티드 펌프스", "레이스업 부츠", "코르셋 레이스 부츠", "무릎 부츠", "피프토 힐", "스퀘어토 힐", "앵클 스트랩", "레이스업 샌들", "허벅지 스키밍 부츠", "앵클 부츠", "크로스 스트랩 샌들", "스터드 부츠", "메리제인", "슬링백", "뮬 펌프스"]
PHF = ["extreme platform sneakers with enormous chunky soles", "chunky block-heel pumps with a thick square heel", "solid wedge-heel sandals", "knee-high mega platform boots", "extreme chunky platform sandals"]
KOFLAT = ["플랫폼 스니커즈", "청키 블록힐", "웨지 샌들", "메가 플랫폼 부츠", "청키 플랫폼 샌들"]
NOPF = ["a monolithic rubber sole column a full forty inches thick from the floor up to the ankle, the whole sneaker built on this towering sole",
        "a thick square block heel a full forty inches tall and a thick hidden platform under the toes",
        "one solid wedge sole a full forty inches tall at the heel sloping down to a tall platform under the toes",
        "a monolithic platform sole a full forty inches thick, the whole boot built on this towering sole",
        "a monolithic chunky sole a full forty inches thick with a thick strap-covered platform, the whole sandal built on this towering sole"]
# ---- 전체 축 확장 (Core 정의 + 기존 정의 전부) ----
sys.path.insert(0, "/tmp/claude-0/-home-claude/62db5eea-2487-540b-9935-a7df06448e2a/scratchpad/zfull/glassface")
ZF_DIR = sys.path[0]
import os as _os; _cw = _os.getcwd(); _os.chdir(sys.path[0]); import full_dicts as FD, body_full as BF; _os.chdir(_cw)
FORM_X += ["platform high-heel mules", "extreme platform buckled boots", "plain stiletto pumps", "ballet heels", "needle heels", "thigh-high stiletto boots", "sculptural heels", "ankle-strap stilettos"]
KOF += ["플랫폼 뮬", "버클 부츠", "순수 스틸레토 펌프스", "발레 힐", "니들 힐", "싸이하이 스틸레토 부츠", "스컬프처럴 힐", "앵클 스트랩 스틸레토"]
FORM[:] = FORM_X; ns2["FORM"][:] = FORM_X
PHF.append("extreme platform wedges"); KOFLAT.append("플랫폼 웨지")
NOPF.append("a massive wedge-shaped platform sole a full forty inches tall at the heel rising from a thick platform under the toes")
AGES[:] = list(FD.AGE_EN_FULL.values()); ns2["AGES"][:] = AGES
NS8 = ["stiletto", "coffin", "almond", "curved talon", "ballerina", "square", "oval", "round"]
for _o in (NAILSHAPE, ns2["NAILSHAPE"]): _o[:] = NS8
ENB = {"글래머아워글래스": "glamour hourglass", "머슬아워글래스BBW": "muscular hourglass BBW", "헤비머슬": "heavy muscle", "USSBBW": "USSBBW", "아워글래스SSBBW": "hourglass SSBBW",
       "파워리프터": "powerlifter", "아마조네스": "amazoness", "슈퍼글래머": "super glamour", "블랙글래머": "black glamour", "레전드바스트": "legendary bust", "커브드바스트": "curved bust",
       "브라질부티글램": "Brazilian booty glam", "폴리네시안여신": "Polynesian goddess", "누비안부티빌더": "Nubian booty builder", "글래머": "glamour", "콜로설": "colossal", "풀텀트윈즈": "full-term twins"}
def _cl(x):
    x = x.replace(" — ", ", ").replace("—", ",")
    x = re.sub(r"\.\s+([A-Z])", lambda m: "; " + m.group(1).lower(), x)
    x = re.sub(r"\s+,", ",", x); x = re.sub(r",\s*,", ",", x)
    return x.strip().rstrip(".").strip()
BODYALL = list(ns["PH0"]); BLINK = {}
for k, v in BF.BODY_FULL.items(): BODYALL.append((ENB[k], _cl(v)))
for dd in (BF.BODY_PREGNANT, BF.BODY_PREGNANT_MUSCLE, BF.BODY_PREGNANT_MORE):
    for k, v in dd.items(): BODYALL.append(("pregnant " + ENB[k.replace("임산부", "")], _cl(v)))
BLINK = {"black glamour": {"ebony", "blue-black"}, "Nubian booty builder": {"ebony", "blue-black"}, "Polynesian goddess": {"Polynesian"}, "Brazilian booty glam": {"Latina"}}
assert len(BODYALL) == 36, len(BODYALL)
HST = list(FD.HAIR_EN_FULL.values()); HCL = list(FD.HAIR_COLOR_EN_FULL.values()); assert len(HST) == 31 and len(HCL) == 30
SIMPLE = {"sleek straight", "wavy", "curly", "braided"}
ART = {"high ponytail": "a high ponytail", "elegant updo": "an elegant updo", "low bun": "a low bun", "twin-tail": "twin-tails",
       "half-up, top section lifted with the length flowing loose below": "half-up with the top section lifted and the length flowing loose below"}
def mkhair():
    st = rg.choice(HST); co = rg.choice(HCL)
    if st in SIMPLE: return f"{st} hair coloured {co}", st
    return f"hair coloured {co} worn as {ART.get(st, st)}", st
_src = open(ZF_DIR + "/gen_fix_ire_uv_6to10.py", encoding="utf-8").read(); _ns = {}
exec(re.search(r"IREZUMI_FULL = \[.*?\n\]\n", _src, re.S).group(0), _ns); exec(re.search(r"UV_FULL = \[.*?\n\]\n", _src, re.S).group(0), _ns)
_HEAD = "covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE."
def _pre(t): return t if t.startswith("BLAZING") else "BLAZING " + t
def _col(mat):
    seg = mat.split("ANYWHERE", 1)[1]; out = []
    for r in re.findall(r"\b[A-Z]{3,}(?:[ -][A-Z]{3,})*\b", seg):
        r = r.lower()
        if r not in out: out.append(r)
    return out[:3]
IR[:] = []; UV[:] = []
for _n, _t in _ns["IREZUMI_FULL"]:
    _m = f"full body {_n} irezumi {_HEAD} Bold black ink outlines — {_pre(_t)}, NO airbrush NO gradient wash."; IR.append((_m, _col(_m)))
for _n, _t in _ns["UV_FULL"]:
    _m = f"full body UV neon {_n} bodypaint {_HEAD} Bold formations — {_pre(_t)}, NO airbrush NO gradient wash."; UV.append((_m, _col(_m)))
BP[:] = []
for _k, (_cn, _cd, _cb, _cf) in FD.CRAFT_DB_FULL.items():
    _art = f"painted in {_cn} — {_cd}, wide {_cb} bands following every deep crease, dense {_cf} filling the space between bands, pigment on living skin, covering her whole body below the jaw with no bare skin anywhere, face unpainted, pattern fading at the neck."
    for _sk, _sv in FD.SHOE_EN_FULL.items():
        if "clear" in _sv: continue
        BP.append((_art, f"{_cb} {_sv}"))
assert len(FD.CRAFT_DB_FULL) == 41 and len(BP) == 41 * 23, (len(FD.CRAFT_DB_FULL), len(BP))
assert len(IR) == 26 and len(UV) == 27 and all(len(c) >= 2 for _, c in IR + UV)
POSE_BAD = {"한쪽무릎꿇기", "의자앉기", "바닥옆으로기대기", "계단에앉기", "점프동작", "양무릎꿇고정면"}
CORE_POSES = list(FD.POSE_EN_FULL.values())
FKEY = {"한쪽무릎꿇기": "kneel1", "의자앉기": "seat", "계단에앉기": "seat", "바닥옆으로기대기": "recline", "점프동작": "jump", "양무릎꿇고정면": "kneel2"}
POSE_FLOOR = {FD.POSE_EN_FULL[k]: v for k, v in FKEY.items()}
FLIFT = {"kneel1": "one knee resting on the floor while her raised leg lifts the towering forty-inch {h} high into plain view, her legs stretched impossibly long",
         "seat": "seated with her legs stretched impossibly long and extended out in front of her so the towering forty-inch {h} project into plain view",
         "recline": "reclining with her legs stretched impossibly long and extended along the floor, the towering forty-inch {h} raised and clearly in view",
         "jump": "caught high in the air with her legs stretched impossibly long and the towering forty-inch {h} trailing far below her",
         "kneel2": "kneeling with her legs folded beneath her and the towering forty-inch {h} rising high behind her, clearly in view"}
BAL_PH = "ballet boots with a rigid sharply pointed toe box encasing the whole foot like a ballerina's pointe shoe"
BAL_NO = "a razor-thin tapered heel spike attached to the back of the boot behind the ankle and angled backward, NOT touching the floor, NO platform and NO thick sole anywhere under the foot"
BAL_POSE = "standing perfectly upright and tall in a pointe stance with both legs pressed together and arms relaxed at her sides, looking straight at the camera"
HEELS = "a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform"
LIFT = "her feet arched fully vertical on the very tips of her toes like a dancer on pointe, her legs stretched impossibly long and her whole body lifted far above the ground on them as if standing on stilts"
TAIL = "so the extreme heel height reads at a glance, the towering heels clearly separating the boot soles from the floor"
import random as _rd
_RS = _rd.Random(20261159)
FAM = [("green", r"green|emerald|jade|celadon|malachite|olive|mint|sage|lime"), ("blue", r"blue|cobalt|navy|indigo|azure|cyan|turquoise|teal|sapphire|lapis|aqua"),
       ("red", r"red|crimson|scarlet|ruby|vermilion|cherry|burgundy|wine"), ("pink", r"pink|rose|magenta|blush|fuchsia"),
       ("purple", r"violet|purple|lavender|amethyst|plum|lilac|orchid"), ("orange", r"orange|copper|tangerine|rust|terracotta|amber|caramel|honey|apricot"),
       ("yellow", r"yellow|gold|golden|saffron|champagne|mustard"), ("white", r"white|cream|ivory|pearl|porcelain|alabaster|snow"),
       ("silver", r"silver|grey|gray|platinum|steel|pewter"), ("brown", r"brown|mahogany|walnut|chestnut|tan|bronze|tawny|wood|teak|cherrywood"),
       ("dark", r"black|obsidian|onyx|ebony|jet|charcoal|dark")]
SHC = {"green": ["emerald green", "mint green", "sage green"], "blue": ["cobalt blue", "sky blue", "turquoise"], "red": ["cherry red", "coral red", "scarlet red"],
       "pink": ["blush pink", "hot pink", "rose pink"], "purple": ["lavender", "orchid purple", "violet"], "orange": ["caramel tan", "copper-orange", "apricot"],
       "yellow": ["gold", "champagne gold", "butter yellow"], "white": ["ivory white", "pearl white", "nude beige"], "silver": ["silver", "pearl grey", "metallic platinum"],
       "brown": ["caramel tan", "cognac", "nude beige"], "dark": ["cherry red", "gold", "ivory white", "nude beige"], "none": ["cherry red", "gold", "ivory white", "nude beige"]}
METAL = {"gold", "champagne gold", "silver", "metallic platinum", "copper-orange"}
LEATH = ["glossy patent leather", "smooth polished leather", "high-shine leather", "satin-finish leather"]
FAMCOUNT = collections.Counter()
_RX = re.compile(r"(?<=Footwear: )([^\n]*?) (?:made of|carved from) the same [^,]+?(?=, each with)")
def _family(seg):
    seg = seg.lower(); best = None
    m = re.search(r"blazing ([^,]{3,120})", seg)
    for scope in ([m.group(1)] if m else []) + [seg]:
        pos = []
        for name, rx in FAM:
            mm = re.search(r"\b(?:%s)" % rx, scope)
            if mm and name != "dark": pos.append((mm.start(), name))
        if pos: return min(pos)[1]
    return "dark" if re.search(r"black|obsidian|onyx|ebony|charcoal", seg) else "none"
def realshoes(t):
    lines = t.split("\n"); seg = ""
    for i, l in enumerate(lines):
        if "physique THE MOST EXTREME" in l:
            j = l.find("Dense fitted sections"); seg = l[j if j >= 0 else l.find(" — full body"):]
            seg = seg.split("Pose:")[0]
        if "Footwear: " in l and _RX.search(l):
            fam = _family(seg); FAMCOUNT[fam] += 1
            c = _RS.choice(SHC[fam]); mt = "metallic leather" if c in METAL else _RS.choice(LEATH)
            lines[i] = _RX.sub(lambda m: m.group(1) + f" in solid {c} {mt}", l, count=1)
    return "\n".join(lines)
NATURAL = "a natural relaxed stance with her weight settled on her feet"
def softlift(t):
    t = t.replace(HEELS, "a very tall razor-thin tapered heel and a hidden front platform")
    t = t.replace(LIFT, NATURAL)
    t = t.replace("her whole body lifted far above the ground on them as if standing on stilts", NATURAL)
    t = re.sub(r", the whole (sneaker|boot|sandal) built on this towering sole", "", t)
    t = re.sub(r"(a|one) ((?:monolithic|massive|thick|solid)[\w\- ]*?) (?:a full forty inches|very) (thick|tall)\b", r"\1 very \3 \2", t)
    t = re.sub(r"a full forty inches (thick|tall)", r"very \1", t)
    t = t.replace("towering forty-inch ", "towering ")
    return t
BOOTEND = "down to the top edge of her boots"
def bootfit(t):
    lines = t.split("\n"); bi = None; nb = 0; nf = 0
    for i, l in enumerate(lines):
        if "physique THE MOST EXTREME" in l: bi = i
        if "Footwear: " in l:
            nf += 1
            ft = l.split("Footwear: ", 1)[1].split(", each with")[0]
            if "boot" in ft and bi is not None:
                nb += 1
                lines[bi] = re.sub(r"\bto ankles?\b", BOOTEND, lines[bi])
    t = "\n".join(lines)
    if nb:
        end = BOOTEND if nb == nf else "down to the ankles or to the top edge of the boots"
        t = t.replace("zero bare skin anywhere from neck to ankle", "zero bare skin anywhere from neck " + end)
        t = t.replace("from hip to ankle to toe", "from hip " + end)
    return t
def floorfix(t, poses, cls):
    keys = [POSE_FLOOR.get(p) for p in poses]
    if not any(keys): return t
    it = iter(keys); h = "soles" if cls == "flat" else "heels"
    def f(m):
        k = next(it)
        return FLIFT[k].format(h=h) if k else m.group(0)
    t, nn = re.subn(re.escape(LIFT), f, t); assert nn == len(poses), (nn, len(poses))
    t = t.replace(TAIL, f"so the extreme height reads at a glance, the towering {h} clearly in view")
    return t
def postshoe(t, cls, n):
    if cls == "stil":
        return re.sub(r"thigh-high platform stiletto boots entirely", lambda m: rg.choice(FORM_X) + " entirely", t), []
    idx = [0] * n if cls == "ballet" else [rg.randrange(len(PHF)) for _ in range(n)]
    c1 = [0]
    def f1(m):
        i = idx[c1[0]]; c1[0] += 1
        ph = BAL_PH if cls == "ballet" else PHF[i]
        if m.group(1): return m.group(1) + ph + m.group(3)
        return ph + " entirely"
    t = re.sub(r"(heels of the most absurdly extreme height imaginable, )([^,]+?)( (?:made of|carved from) the same)|thigh-high platform stiletto boots entirely", f1, t)
    assert c1[0] == n, (c1[0], n)
    c2 = [0]
    def f2(m):
        i = idx[c2[0]]; c2[0] += 1
        return BAL_NO if cls == "ballet" else NOPF[i]
    t = re.sub(re.escape(HEELS), f2, t); assert c2[0] == n, (c2[0], n)
    if cls == "ballet":
        t = t.replace("Footwear: heels of the most absurdly extreme height imaginable, ", "Footwear: the most absurdly extreme ballet boots imaginable, ")
        t = t.replace(LIFT, "her feet arched fully vertical with the tip of each pointed toe resting directly on the floor like a dancer on pointe, her legs stretched impossibly long in one unbroken vertical line straight down to the floor")
        t = t.replace(TAIL, "so her extreme height reads at a glance, the tip of each pointed boot clearly touching the floor")
        return t, [-1]
    t = t.replace(LIFT, "her whole body lifted far above the ground on them as if standing on stilts")
    t = t.replace("Footwear: heels of the most absurdly extreme height imaginable, ", "Footwear: shoes of the most absurdly extreme height imaginable, ")
    t = t.replace(TAIL, "so her extreme height reads at a glance, the towering soles clearly lifting her far above the floor")
    t = t.replace("the towering heels and boots huge in the foreground", "the towering soles huge in the foreground")
    return t, idx
ALLP = list(NEWPOSES); [ALLP.append(p) for p in list(POSES) + CORE_POSES if p not in ALLP]
print('바닥 포즈', len(POSE_FLOOR), '포즈', len(ALLP), '체형', len(BODYALL), '헤어', len(HST), 'x', len(HCL), '나이', len(AGES), '네일', len(NS8), '신발', len(FORM_X), '+', len(PHF))
CLS = {}
for n_ in range(1, 6):
    if n_ == 1: L = ["stil"] * 33 + ["ballet"] * 9 + ["flat"] * 18
    elif n_ == 2: L = ["stil"] * 36 + ["ballet"] * 6 + ["flat"] * 18
    else: L = ["stil"] * 42 + ["flat"] * 18
    rg.shuffle(L)
    for k_, c_ in enumerate(L, 1): CLS[(n_, k_)] = c_
UV_IN = ["neon", "pink", "chiaro"]
out = []; seen = set()
for n in range(1, 6):
    for kk in range(1, 61):
        for attempt in range(600):
            kinds = [ALLK[(kk - 1) % len(ALLK)]] if n == 1 else rg.sample(ALLK, n)
            cls = CLS[(n, kk)]
            if cls != 'stil' and 'bodypaint' in kinds:
                if n == 1: cls = 'stil'
                else: continue
            PERS.clear(); CUR_VAR.clear()
            picks = draw_picks(kinds)
            ang = 'base' if cls == 'ballet' else pick_angle(n)
            used = []; eths = [None] * n; concepts = [None] * n
            for idx, k in enumerate(kinds):
                if k in P and rg.random() < 0.8:
                    ko, en, ethn = rg.choice(P[k])
                    if ethn not in used: used.append(ethn); eths[idx] = ETHD[ethn]; concepts[idx] = (ko, en)
            rest = [e for e in ETH if e[0] not in used]; rg.shuffle(rest)
            for idx in range(n):
                if eths[idx] is None: eths[idx] = rest.pop()
            infos_p = []
            for idx, k in enumerate(kinds):
                lab = f"#{idx+1}" if n > 1 else None
                ethn = eths[idx][0]; con = concepts[idx]; hb = None
                hb, hst = mkhair()
                if ethn in ("ebony", "blue-black"): hb = rg.choice(HAIRB); hst = hb.split(" in ")[0]
                if con and con[0] == "메두사": hb = SNAKE.format(m=picks[idx][1])
                PERS[lab] = (con[1] if con else None, hb)
                tag = [KO[k] + (f"={con[0]}" if con else "")]
                tag.append("뱀 머리" if (con and con[0] == "메두사") else hst)
                infos_p.append("·".join(tag))
            physs = []
            for idx in range(n):
                while True:
                    c = rg.choice(BODYALL); lk_ = BLINK.get(c[0].replace("pregnant ", ""))
                    if (lk_ is None or eths[idx][0] in lk_) and c not in physs: physs.append(c); break
            ages = [rg.choice(AGES) for _ in range(n)]
            okp = [p for p in ALLP if not (ang != "base" and ("camera" in p or "back" in p))]
            poses = rg.sample(okp, n)
            if cls == 'ballet': poses = [BAL_POSE] * n
            bid, wx = BGL.pick(rg, n); outdoor = BGL.BG[bid][4]
            uv = "uvneon" in kinds
            tk = None
            if outdoor and (uv or rg.random() < 0.7): tk = "night" if uv else rg.choice(list(TM)); wx = None
            if tk: lk = rg.choice(TM[tk][1]); tphrase = TM[tk][0]
            else: lk = rg.choice(INDOOR_L if not outdoor else ["golden", "rim", "fog", "beauty", "sun"]); tphrase = ""
            if uv and not tk: lk = rg.choice(UV_IN)
            if uv and tk: lk = rg.choice(["moon", "neon", "pink"])
            if bid == "pool" and rg.random() < 0.5: lk = "rim"
            mood = rg.choice(MD)
            scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
            if tk in ("blue", "dusk", "night"): scene = re.sub(r"\b(sunlit|sunny|bright|midday) ", "", scene)
            HEELMODE[0] = "forty" if (cls != "stil" or n >= 2 or rg.random() < 0.55 or kinds[0] not in NEWV) else "relative"
            ns2["JR"].seed(rg.randrange(10**9))
            t, infos = build3(kinds, picks, physs, ages, poses, eths, scene)
            if cls != "ballet": t = floorfix(t, poses, cls)
            t, fidx = postshoe(t, cls, n)
            t = realshoes(t)
            if cls != "ballet": t = softlift(t)
            t = bootfit(t)
            t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as " + ("her" if n == 1 else "any of them") + ".", 1)
            if CAMD[ang][1]:
                t, nn = re.subn(re.escape(CAMBASE), CAMD[ang][1], t, count=1)
                if nn != 1: continue
            if cls == 'flat': t = t.replace('the towering heels and boots huge in the foreground', 'the towering soles huge in the foreground')
            add = LI[lk] + (", " + tphrase if tphrase else "") + ", " + mood + (KEEP if (tk in ("blue", "dusk", "night") or lk in ("chiaro", "moon", "fire", "neon", "pink") or uv) else "")
            t, nn = re.subn(r", bright and evenly lit, shadows soft,", ", " + add + ",", t, count=1)
            if nn != 1: continue
            if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t) or t in seen: continue
            fort = t.count("forty inches"); assert fort == 0 and "forty" not in t, (fort, n, HEELMODE, kinds)
            assert t.count("Jewelry:") == n and "completely empty of other people" in t
            break
        else: raise SystemExit(f"fail {n} {kk}")
        seen.add(t)
        mats = " / ".join(pick_name(k, p) for k, p in zip(kinds, picks))
        if cls == "stil": shoes = [f for f in re.findall("|".join(re.escape(x) for x in sorted(FORM_X, key=len, reverse=True)), t)]; shoeko = "/".join(KOF[FORM_X.index(f)] for f in shoes) or "스틸레토"
        elif cls == "ballet": shoes = ["ballet boots"] * n; shoeko = "발레 부츠"
        else: shoes = [PHF[i] for i in fidx]; shoeko = "/".join(KOFLAT[i] for i in fidx)
        hko = {"flat": "밑창 아주 두꺼움", "ballet": "발끝 서기"}.get(cls) or "힐 아주 높음"
        mshort = mood.split(" mood")[0]
        out.append({"key": f"la_sm_{TYPEN[n]}_{kk:02d}", "category": CAT,
                    "title": f"ShoeMix {TYPEN[n].capitalize()} #{kk:02d} (신발 {shoeko} · {TKO[n]} · {' / '.join(infos_p)} · {mats} · 앵글 {CAMD[ang][0]} · 조명 {lk} · 시간대 {tk or '없음'} · 분위기 {mshort} · 체형 {', '.join(x[0] for x in physs)} · 인종 {', '.join(e[0] for e in eths)} · {' ‖ '.join(infos)} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko} · 몸 주얼리)",
                    "prompt": t, "meta": {"group_size": n, "aspect_ratio": ASP[n], "format": "shoemix", "shoe_class": cls, "shoes": shoes, "kinds": kinds, "concepts": [c[0] if c else None for c in concepts], "angle": ang, "poses": poses,
                                          "lighting": lk, "time_of_day": tk, "mood": mshort, "physiques": [x[0] for x in physs], "ethnicity": [e[0] for e in eths], "background": bid, "weather": wx[0] if wx else None,
                                          "heel_mode": HEELMODE[0], "jewelry": True}})
assert len(out) == 300 and len({p["key"] for p in out}) == 300
json.dump(out, open(O + "la_shoemix_300_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(out), collections.Counter(p["meta"]["group_size"] for p in out))
print(collections.Counter(p["meta"]["angle"] for p in out))
print(collections.Counter(p["meta"]["lighting"] for p in out))
print(collections.Counter(p["meta"]["time_of_day"] for p in out))
print(collections.Counter(k for p in out for k in p["meta"]["kinds"]).most_common())
print(len({p["meta"]["background"] for p in out}), "배경", min(len(p["prompt"].split()) for p in out), max(len(p["prompt"].split()) for p in out))

print(collections.Counter(p["meta"]["shoe_class"] for p in out))
print(collections.Counter(f for p in out for f in p["meta"]["shoes"]).most_common())
import re as _r
bad = [p["key"] for p in out if p["meta"]["shoe_class"] != "stil" and _r.search(r"stiletto|razor-thin tapered heel a full|tips of her toes|towering heels", p["prompt"].replace(BAL_NO, ""))]
print("residual", bad[:10], len(bad))

print("신발 색 계열", FAMCOUNT.most_common())
