# -*- coding: utf-8 -*-
# Persona Mix 300: 컨셉(재질 짝짓기) · 새 포즈 · 보호 스타일 헤어 · 메두사 뱀 머리 · 앵글 5종을 섞은 번들
import re, random, sys, json, collections
sys.path.insert(0, "../bg")
src6 = open("gen_persona6.py", encoding="utf-8").read()
exec(src6[:src6.index("PERS = {}")])
rg = random.Random(20261110)
PERS = {}
orig_disp3 = disp3
SNAKE = "a mass of dozens of thick coiling snakes carved from the same {m}, each snake with a detailed head, open eyes and a flicking tongue, writhing around her head and falling down her back, the snakes are her hair"
def disp4(label, kind, pick, phys, age, pose, eth, heel_in):
    pe = PERS.get(label)
    HAIRO[0] = pe[1] if pe else None
    t, info, nm = orig_disp3(label, kind, pick, phys, age, pose, eth, heel_in)
    if pe and pe[1] and kind not in NEWV and kind not in PAINT:
        t, n = re.subn(r', ([^,—]+?) hair — ', f', {pe[1]} — ', t, count=1); assert n == 1
    if pe and pe[0]:
        t, n = re.subn(r" goddess, ", f", {pe[0]}, ", t, count=1); assert n == 1
    return t, info, nm
ns2["person"] = disp4
CAMD = {"base": ("기본(허리 높이)", None),
 "high": ("하이앵글 70도", "Full-length steep high-angle shot taken from far above with a long telephoto lens, the camera directly above and in front of her angled roughly seventy degrees downward as if from a high ceiling or drone, flat telephoto compression with natural proportions and no wide-angle distortion, the whole figure from head to boots fully visible,"),
 "side": ("측면", "Full-length side view with the camera at waist height, her body in clean profile,"),
 "low": ("극단 로우앵글", "Full-length EXTREME worm's-eye view shot with the camera placed on the floor at boot level and tilted steeply upward, the towering heels and boots huge in the foreground, her legs rising in exaggerated perspective and her head far above at the top of the frame,"),
 "tq": ("극단 3/4 앵글", "Full-length EXTREME three-quarter view from the far front-left, her whole body turned a full sixty degrees away from the camera with her shoulders and hips twisted, the camera at waist height and pushed close for strong foreshortening,")}
CAMBASE = "Full-length wide shot from a moderate distance with the camera at waist height,"
def pick_angle(n):
    if n >= 4: ks, ws = ["base", "high", "side"], [55, 30, 15]
    else: ks, ws = ["base", "high", "low", "side", "tq"], [38, 20, 15, 15, 12]
    return rg.choices(ks, ws)[0]
ETHD = {e[0]: e for e in ETH}
CAT = "🏺 Living Artifact · Light Mix Formula"
def draw_picks(kinds):
    picks = []
    for idx, k in enumerate(kinds):
        lab = f"#{idx+1}" if len(kinds) > 1 else None
        if k == "bodypaint": picks.append(rg.choice(BP))
        elif k == "irezumi": picks.append(rg.choice(IR))
        elif k == "uvneon": picks.append(rg.choice(UV))
        elif k == "wood": picks.append(rg.choice(WOODS))
        elif k == "stone": picks.append(rg.choice(STONES))
        else:
            v = rg.choice(NEWV[k]); CUR_VAR[(lab, k)] = v; picks.append(v)
    return picks
def pick_name(k, p):
    if k in NEWV: return f"{KO[k]} {p[7]}"
    if k == "wood": return f"목재 {p[0]}"
    if k == "stone": return f"석재 {p[0]}"
    return KO[k]

LI = {"golden": "golden hour warm backlight, skin luminosity, glowing", "octa": "professional octabox strobe, high-contrast glamour lighting",
      "neon": "multi-colored neon edge glow, cyberpunk light", "chiaro": "dramatic chiaroscuro, deep shadows and sharp highlights",
      "beauty": "soft beauty dish light, even flattering illumination", "hard": "harsh direct strobe, body muscle definition emphasis",
      "fog": "volumetric fog cinematic light, atmospheric mood", "rim": "strong rim backlight, silhouette definition, halo effect",
      "moon": "moonlight, silvery blue natural light, mysterious outdoor glow", "pink": "pink neon accent light, rose-toned atmospheric glow, fashion editorial lighting",
      "fire": "firelight, warm flickering flames, dramatic orange glow", "sun": "harsh direct sunlight, strong sharp shadows, high contrast"}
TM = {"blue": ("blue hour just before dawn, mystical pre-sunrise light, cool blue atmospheric glow", ["rim", "fog", "moon"]),
      "morning": ("morning golden hour, soft warm early sunlight, fresh dewy atmosphere", ["golden", "rim", "fog"]),
      "noon": ("midday harsh sunlight, strong direct light, sharp shadows, high contrast", ["sun"]),
      "afternoon": ("late afternoon warm sunlight, relaxed golden atmosphere, soft shadows", ["golden", "rim"]),
      "dusk": ("dusk twilight, dramatic sunset colors, sky ablaze with color", ["rim", "golden", "fire"]),
      "night": ("deep midnight, a dark sky overhead, mysterious nocturnal atmosphere", ["moon", "neon", "pink", "fire"])}
MD = ["dark glamour mood, intense dramatic atmosphere, powerful editorial energy", "dreamy ethereal mood, soft romantic atmosphere, fantasy editorial",
      "high fashion editorial mood, cold sophisticated atmosphere, sharp luxury", "bohemian free-spirited mood, natural earthy atmosphere, artistic editorial",
      "retro pin-up mood, vintage glamour atmosphere, classic playful editorial", "cyberpunk glamour mood, futuristic neon atmosphere, dystopian editorial",
      "romantic mood, soft warm atmosphere, tender feminine editorial", "powerful commanding mood, intense dominant atmosphere, fierce editorial",
      "mysterious alluring mood, enigmatic atmosphere, captivating editorial", "luxury opulent mood, sophisticated elegant atmosphere, high-end editorial",
      "playful vibrant mood, energetic joyful atmosphere, fresh editorial", "serene tranquil mood, peaceful calm atmosphere, meditative editorial"]
INDOOR_L = ["octa", "beauty", "chiaro", "hard", "neon", "pink", "rim", "fire"]
KEEP = ", every person's whole figure from the boots to the top of her head clearly lit and fully visible with every material detail sharp"

KEEP = ', every person\'s whole figure from the boots to the top of her head clearly lit and fully visible with every material detail sharp'

FORM_X = ["thigh-high platform stiletto boots", "strappy platform stiletto sandals", "pointed platform stiletto pumps", "knee-high lace-up platform stiletto boots", "platform stiletto ballet boots",
          "platform stiletto corset-lace boots", "platform stiletto knee-high boots", "platform stiletto peep-toe heels", "extreme platform square-toe heels", "ankle-strap platform stilettos",
          "extreme platform lace-up sandals", "extreme platform thigh-skimming boots", "platform stiletto ankle boots", "platform stiletto cross-strap sandals", "platform stiletto studded boots",
          "platform stiletto Mary Janes", "platform stiletto slingbacks", "backless platform stiletto mule pumps"]
FORM[:] = FORM_X
UV_IN = ["neon", "pink", "chiaro"]
out = []; seen = set()
SIZES = [1, 1]
PH = ["ballet heel boots whose rigid sharply pointed toe box encases the whole foot like a ballerina's pointe shoe"] * 2
NOPLAT = ["a razor-thin tapered heel spike a full forty inches tall attached to the back of the boot behind the ankle, NO platform at all, she stands fully en pointe like a ballerina, balanced on the very tip of the pointed toe box with her toes pointing straight down at the floor and her foot a perfectly straight vertical continuation of the shin", "a razor-thin tapered heel spike a full forty inches tall attached to the back of the boot behind the ankle, NO platform at all, she stands fully en pointe like a ballerina, balanced on the very tip of the pointed toe box with her toes pointing straight down at the floor and her foot a perfectly straight vertical continuation of the shin, the ball of her foot and the sole NEVER lying flat or touching the ground, only the tiny tip of the toe box touches the floor while the high heel spike hangs in the air behind her ankle"]
for kk, n in enumerate(SIZES, 1):
    if True:
        for attempt in range(600):
            FORM[:] = [PH[kk-1]]; FORM_X[:] = [PH[kk-1]]; kinds = rg.sample([k for k in ALLK if k != 'bodypaint'], n)
            PERS.clear(); CUR_VAR.clear()
            picks = draw_picks(kinds)
            ang = pick_angle(n)
            used = []; eths = [None] * n; concepts = [None] * n
            for idx, k in enumerate(kinds):
                if k in P and rg.random() < 0.8:
                    ko, en, ethn = rg.choice(P[k])
                    if ethn not in used: used.append(ethn); eths[idx] = ETHD[ethn]; concepts[idx] = (ko, en)
            rest = [e for e in ETH if e[0] not in used]; rg.shuffle(rest)
            for idx in range(n):
                if eths[idx] is None: eths[idx] = rest.pop()
            infos_p = []
            for idx, k in enumerate(kinds):
                lab = f"#{idx+1}" if n > 1 else None
                ethn = eths[idx][0]; con = concepts[idx]; hb = None
                if ethn in ("ebony", "blue-black"): hb = rg.choice(HAIRB)
                if con and con[0] == "메두사": hb = SNAKE.format(m=picks[idx][1])
                if con or hb: PERS[lab] = (con[1] if con else None, hb)
                tag = [KO[k] + (f"={con[0]}" if con else "")]
                if hb: tag.append("뱀 머리" if (con and con[0] == "메두사") else hb.split(" in ")[0])
                infos_p.append("·".join(tag))
            physs = []
            while len(physs) < n:
                c = rg.choices(BIG5, W5)[0]
                if c not in physs: physs.append(c)
            ages = [rg.choice(AGES) for _ in range(n)]
            okp = [p for p in NEWPOSES if not (ang != "base" and ("camera" in p or "back" in p))]
            poses = rg.sample(okp, n)
            bid, wx = BGL.pick(rg, n); outdoor = BGL.BG[bid][4]
            uv = "uvneon" in kinds
            tk = None
            if outdoor and (uv or rg.random() < 0.7): tk = "night" if uv else rg.choice(list(TM)); wx = None
            if tk: lk = rg.choice(TM[tk][1]); tphrase = TM[tk][0]
            else: lk = rg.choice(INDOOR_L if not outdoor else ["golden", "rim", "fog", "beauty", "sun"]); tphrase = ""
            if uv and not tk: lk = rg.choice(UV_IN)
            if uv and tk: lk = rg.choice(["moon", "neon", "pink"])
            if bid == "pool" and rg.random() < 0.5: lk = "rim"
            mood = rg.choice(MD)
            scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
            if tk in ("blue", "dusk", "night"): scene = re.sub(r"\b(sunlit|sunny|bright|midday) ", "", scene)
            HEELMODE[0] = "forty"
            ns2["JR"].seed(rg.randrange(10**9))
            t, infos = build3(kinds, picks, physs, ages, poses, eths, scene)
            t = re.sub(r"thigh-high platform stiletto boots entirely", lambda m: rg.choice(FORM_X) + " entirely", t)
            t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as " + ("her" if n == 1 else "any of them") + ".", 1)
            t = re.sub(r"(heels of the most absurdly extreme height imaginable, )(.+?)( (?:made of|carved from) the same)", lambda m: m.group(1) + PH[kk-1] + m.group(3), t)
            t, nn = re.subn(r"a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform", NOPLAT[kk-1], t); assert nn == 1, nn
            if CAMD[ang][1]:
                t, nn = re.subn(re.escape(CAMBASE), CAMD[ang][1], t, count=1)
                if nn != 1: continue
            add = LI[lk] + (", " + tphrase if tphrase else "") + ", " + mood + (KEEP if (tk in ("blue", "dusk", "night") or lk in ("chiaro", "moon", "fire", "neon", "pink") or uv) else "")
            t, nn = re.subn(r", bright and evenly lit, shadows soft,", ", " + add + ",", t, count=1)
            if nn != 1: continue
            if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t) or t in seen: continue
            fort = t.count("forty inches"); assert fort == (n if HEELMODE[0] == "forty" else 0), (fort, n, HEELMODE, kinds)
            assert t.count("Jewelry:") == n and "completely empty of other people" in t
            break
        else: raise SystemExit(f"fail {n} {kk}")
        seen.add(t)
        mats = " / ".join(pick_name(k, p) for k, p in zip(kinds, picks))
        hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
        mshort = mood.split(" mood")[0]
        out.append({"key": f"la_lm_{TYPEN[n]}_{kk:02d}", "category": CAT,
                    "title": f"LightMix {TYPEN[n].capitalize()} #{kk:02d} ({TKO[n]} · {' / '.join(infos_p)} · {mats} · 앵글 {CAMD[ang][0]} · 조명 {lk} · 시간대 {tk or '없음'} · 분위기 {mshort} · 체형 {', '.join(x[0] for x in physs)} · 인종 {', '.join(e[0] for e in eths)} · {' ‖ '.join(infos)} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko} · 몸 주얼리)",
                    "prompt": t, "meta": {"group_size": n, "aspect_ratio": ASP[n], "format": "lightmix", "kinds": kinds, "concepts": [c[0] if c else None for c in concepts], "angle": ang, "poses": poses,
                                          "lighting": lk, "time_of_day": tk, "mood": mshort, "physiques": [x[0] for x in physs], "ethnicity": [e[0] for e in eths], "background": bid, "weather": wx[0] if wx else None,
                                          "heel_mode": HEELMODE[0], "jewelry": True}})

o = ["# 발레 부츠 en pointe + 뒤에 붙은 힐 (솔로 2개, 문구 2단계)\n", "이전 시험은 발레 부츠에 '12인치 숨은 앞굽'이 같이 들어가 서로 충돌했다. 이번에는 앞굽 문구를 빼고 '앞굽 없음, 발끝이 뾰족한 한 점, 발이 정강이부터 수직 한 줄'로 바꿨다. 문구 3단계(뾰족 부츠 / 종아리 포인트슈즈형 / 허벅지 포인트슈즈형). 나머지는 번들과 같은 전체 랜덤(바디페인팅은 신발 문구가 달라 제외). 참고: 신발 형태 풀을 5종 → 18종으로 늘렸다(뮬, 앵클 스트랩, 앵클 부츠, 피프토, 코르셋 레이스업, 슬링백, 메리제인, 사각 토, 스터드 부츠, 크로스 스트랩 샌들 등). 바디페인팅은 원래 다양해서 그대로. 나머지(재질·인원·인종·체형·포즈·네일·주얼리·헤어·컨셉·앵글·배경·조명·시간대·분위기)는 Light Mix 번들과 같은 전체 랜덤.\n"]
for i, p in enumerate(out, 1):
    shoes = re.findall(r"Footwear: (?:heels of the most absurdly extreme height imaginable, |the most absurdly extreme heels imaginable — )?([^,—]{5,80}?)(?: made of| carved| entirely|,| in )", p["prompt"])
    o.append(f"## {i}. {p['key'].replace('la_lm_','')} · {p['title'][len('LightMix '):][:250]}\n\n신발: {' / '.join(shoes)}\n\n```\n{p['prompt']}\n```\n")
open(O + "LumineX_Ballet2b.md", "w", encoding="utf-8").write("\n".join(o))
for p in out: print(p["meta"]["kinds"], p["meta"]["group_size"], len(p["prompt"].split()))
