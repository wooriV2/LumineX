import re,random
exec(open('mk_trio_arch.py',encoding='utf-8').read().split("SPECS=")[0])
ns2={}
g=open('gen_fs2.py',encoding='utf-8').read()
exec(compile(g[:g.index('if __name__=="__main__":')],'gfs2','exec'),ns2)
ns2['tusk_flag']=False
ARCHF={n:f for n,f,c in ns2['ARCH']}
R=random.Random(20261019)
it=ns2['build2'](1,'arch','브랫츠 돌',ARCHF['브랫츠 돌'],R)
s=it['prompt']
for a,b in SW: s=s.replace(a,b)
s=s.replace("..",".")
assert not re.search(r"[가-힣]",s)
o=["# LumineX — 인원수별 비교 3개 (브랫츠 유형, 1인 · 2인 · 3인)\n","- 같은 브랫츠 유형 문단(사실감 구조 적용). 1인은 단독 컷 틀, 2·3인은 그룹 틀(일반 인물은 눈·입술 강조). 색·머리는 뽑기마다 다를 수 있습니다.","- 비교할 것은 브랫츠 인물의 피부(잔털·주름·고무 느낌)입니다. 정상/이상 대신 '1번 > 2번 > 3번' 식으로 피부가 가장 사실적인 순서만 알려주세요.\n","## 1. 1인\n\n```\n"+s+"\n```\n"]
print(1,len(s.split()))
ear,h,bg="iron",2,BGN[0]
for i,spec in ((2,[("arch","브랫츠 돌"),("eye",EYEP[1][0])]),(3,[("arch","브랫츠 돌"),("eye",EYEP[1][0]),("lip","체리 립")])):
    rr=random.Random(77)
    for tr in range(300):
        try: t,labs,dup=group3(rr.randrange(10**7),spec,"front",ear,h,bg)
        except AssertionError: continue
        mk=[l.split(" · ")[4] for l in labs if "유형 고유 메이크업" not in l]
        if len(set(mk))<len(mk) or sum(m=="메이크업 없음" for m in mk)>1: continue
        break
    t=real(t,spec); assert not re.search(r"[가-힣]",t)
    o.append(f"## {i}. {i}인\n\n```\n{t}\n```\n"); print(i,len(t.split()))
open(OUT+'LumineX_ArchReal_N123_3.md','w',encoding='utf-8').write("\n".join(o))
