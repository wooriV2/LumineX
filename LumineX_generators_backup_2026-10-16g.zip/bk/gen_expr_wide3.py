# -*- coding: utf-8 -*-
import random, re
import cjk_face_lib as C
NEW = {"놀란": "eyes opened very wide with the whites showing above and below the irises, brows lifted high, lips parted in a round open O, staring straight into the camera, a startled, astonished expression",
       "호기심 어린": "round bright eyes opened wide and sparkling, brows raised a little, lips slightly parted, gazing straight at the camera with eager interest, a curious, inquisitive expression",
       "광기 어린": "eyes opened extremely wide with the whites showing all around the irises, a fixed unblinking stare, brows raised, a wide stretched grin showing teeth, a manic, unhinged expression"}
C.EXPR.update(NEW)
f, mk = C.load(); src = [x for x in f if x["meta"]["piercing"] == "P25"][0]
src = dict(src, prompt=C.strip_piercing(src["prompt"]))
CASES = [("한국", "Korean", "20대", "놀란"), ("일본", "Japanese", "아이돌", "호기심 어린"), ("중국", "Chinese", "20대", "광기 어린")]
o = ["# 눈 큰 표정 3종 시험 (P0, 메이크업 없음)\n", "한중일 하나씩입니다. 번호별로 정상/이상만 알려주세요. 얼굴이 서양인 쪽으로 쏠리면 그것도 한 줄 적어주세요.\n"]
for i, (kr, en, grp, ex) in enumerate(CASES, 1):
    t = C.build(src, en, grp, ex, None, mk, random.Random(30 + i))
    assert not re.search(r"[가-힣]", t) and "piercing" not in t.lower().replace("piercing direct", "")
    o.append(f"## {i}. {kr} · {grp} · {ex} · P0 · 메이크업 없음\n\n```\n{t}\n```\n")
open("/mnt/user-data/outputs/LumineX_Expr_WideEye3.md", "w", encoding="utf-8").write("\n".join(o))
print(o[2][-1400:])
