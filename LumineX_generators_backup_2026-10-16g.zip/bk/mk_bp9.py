# -*- coding: utf-8 -*-
# 일반 바디페인팅 솔로 × 9체형(기존 3 + 새 6) — Material Mix 틀, 나머지 축 기본 랜덤
_m = open("mk_mixnew3.py", encoding="utf-8").read()
exec(_m[:_m.index('OLD = ["bodypaint"')], globals())
exec(open("newbody_defs.py", encoding="utf-8").read(), globals())
POSES = [p for p in POSES if "arms crossed under her bust" not in p and "framing the face" not in p]
import sys
sys.path.insert(0, "../master")
import mdefs as _D
OLDB = ["curved bust", "super hourglass", "legendary bust"]
PH = [(b[0], b[1]) for n_ in OLDB for b in _D.BODIES if b[0] == n_] + [(nm, desc) for nm, ko, kod, desc in NB]
KOB = {"curved bust": "커브드 바스트", "super hourglass": "슈퍼 아워글래스", "legendary bust": "레전더리 바스트", **{nm: ko for nm, ko, kod, desc in NB}}
rg = random.Random(20261701); rr.seed(20261701); ns2["JR"].seed(20261701)
SEEN = set()
o = ["# LumineX — 일반 바디페인팅 × 9체형 (기존 3 + 새 6)\n", "Material Mix의 일반 바디페인팅(bodypaint) 솔로 틀에 체형만 지정했고, 나이·포즈·인종·배경·힐·네일·주얼리·메이크업은 기본 랜덤입니다. 번호별로 성공/실패만 알려주세요.\n"]
for gi, ph in enumerate(PH, 1):
    for attempt in range(800):
        CUR_VAR.clear()
        v = rg.choice(BP)
        age = rg.choice(AGES); pose = rg.choice(POSES); eth = rg.sample(ETH, 1)
        bid, wx = BGL.pick(rg, 1); scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
        ns2["JR"].seed(rg.randrange(10**9))
        t, infos = build3(["bodypaint"], [v], [ph], [age], [pose], eth, scene)
        t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as her.", 1)
        if not chk(t) or re.search(r"\b(foil|lens|sticker|doll)\b", t, re.I) or t in SEEN: continue
        if t.count("Jewelry:") != 1 or t.count("forty inches") != (1 if HEELMODE[0] == "forty" else 0): continue
        SEEN.add(t); break
    else: raise SystemExit("fail")
    hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
    tag = "신규" if ph[0] not in OLDB else "기존"
    o.append(f"## {gi}. {KOB[ph[0]]}({ph[0]}) [{tag}] · 바디페인팅 · 인종 {eth[0][0]} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko}\n\n```\n{t}\n```\n")
    print(gi, ph[0], len(t.split()), t.count("forty inches"))
open(O + "LumineX_BodyPaint_Bodies9.md", "w", encoding="utf-8").write("\n".join(o))
