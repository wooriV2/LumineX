# -*- coding: utf-8 -*-
# 목재·석재 혼합 + 모든 축(연령·인종·체형·자세·머리·최극단 힐·최장 네일·표면 패턴·메이크업·표정·렌즈/마이크로더멀/스티커/헤나, 피어싱 제외) 샘플 6개
import re, random
import gen_cjk_v2 as G, cjk_face_lib as C
O = "/mnt/user-data/outputs/"
s = open("gen_woodstone_600.py", encoding="utf-8").read(); ns = {}
exec(s[:s.index("rr = random.Random(20261009)")], ns)
WOODS, STONES, check, BIG, AGES, HAIRS0, POSES0, SETS, SETKO, NUM, ASP, HEELT, BODYLIFT, CAM = (ns[k] for k in ["WOODS", "STONES", "check", "BIG", "AGES", "HAIRS", "POSES", "SETS", "SETKO", "NUM", "ASP", "HEELT", "BODYLIFT", "CAM"])
rr = random.Random(20261010)
POSES = POSES0 + ["one hand sweeping her hair back, the other resting on her hip, one leg crossed in front to show the boot", "walking confidently toward the camera, shoulders back, chin lifted",
                  "hands clasped behind her head, elbows wide, hips thrust to one side", "one hand on her waist, the other lifted to her chin, weight on one leg",
                  "standing tall, arms crossed under her bust, chin raised, looking down at the camera", "leaning a shoulder against the doorway, one knee bent, a hand on her thigh",
                  "turned in profile, back arched, looking over her shoulder, one hand on her hip"]
COLORS = ["jet-black", "natural black", "dark brown", "chestnut brown", "chocolate brown", "ash brown", "auburn", "honey blonde", "golden blonde", "balayage", "platinum silver", "rose pink", "deep burgundy", "teal", "copper red", "lavender"]
STYLES = ["long straight", "long wavy", "long curly", "high ponytail", "sculpted updo", "half-up half-down", "top bun", "blunt bob", "shaggy layered", "wolf cut", "waist-length braids", "voluminous curls", "sleek slicked-back"]
def hair(): return f"{rr.choice(STYLES)} {rr.choice(COLORS)} hair"
ETH = [("blue-black", "THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky", "the face of a real Black woman with strong, striking features, a broad nose and full lips", None),
       ("ebony", "a deep ebony-brown complexion", "the face of a real Black woman with strong, striking features, a broad nose and full lips", None),
       ("Korean", "a luminous light-neutral complexion with a soft peach-beige undertone", f"the face of a real Korean woman ({C.FE['Korean']})", "강남언니"),
       ("Chinese", "a luminous warm-ivory complexion", f"the face of a real Chinese woman ({C.FE['Chinese']})", "홍콩풍"),
       ("Japanese", "a luminous porcelain-fair complexion with a cool-pink undertone", f"the face of a real Japanese woman ({C.FE['Japanese']})", "지뢰계"),
       ("Latina", "a warm caramel complexion", "the face of a real Latina woman with high cheekbones, large dark eyes and full lips", None),
       ("Indian", "a warm golden-brown complexion", "the face of a real Indian woman with large almond eyes, strong brows and a defined nose", None),
       ("Middle Eastern", "a warm olive complexion", "the face of a real Middle Eastern woman with large dark eyes, strong arched brows and a straight nose", None),
       ("Slavic", "a fair porcelain complexion with a cool undertone", "the face of a real Russian woman with high cheekbones, light eyes and a defined jaw", None),
       ("Polynesian", "a warm bronze-brown complexion", "the face of a real Polynesian woman with a broad face, full lips and large dark eyes", None)]
SAFE = ["인스타글램", "글래스 스킨", "걸크러시", "클래식 레드립", "와인 레드립", "푸시아 립", "코랄 립", "잉크 블랙립", "비닐 블랙립", "립온리 블랙", "비주얼계 블랙립"]
PALE = re.compile(r"pale|porcelain|ivory|fair|milky|white complexion|deathly|tan\b", re.I)
BANNED = ["blood", "wound", "fracture", "spike", "bite", "biting", "doll", "spalt", "rot", "decay", "fungus", "fungal", "worm", "safety pin", "gash", "crack"]
def face(eth):
    nm, skin, feat, local = eth
    for _ in range(200):
        st = local if (local and rr.random() < 0.4) else rr.choice(SAFE)
        age_g = "20대"; ex = rr.choice(list(C.EXPR.keys()))
        if ex in ("놀란", "광기 어린") and rr.random() < 0.3: pass
        slots = rr.sample(["lens", "micro", "sticker", "henna"], rr.choice([2, 3]))
        try: t, title, m = G.make(random.Random(rr.random()), "한국", age_g, ex, style=st, slots=slots)
        except AssertionError: continue
        a = t.index("catchlights, full lips, ") + len("catchlights, full lips, "); b = t.index(" — a photograph of a real")
        seg = t[a:b].strip()
        if nm in ("blue-black", "ebony", "Indian", "Polynesian") and PALE.search(seg): continue
        if seg.lower().count("contact lens") > 2 or any(w in seg.lower() for w in BANNED): continue
        return feat, seg, f"{ex} · {m['makeup_label'] if m['makeup'] else '메이크업 없음'}" + "".join(" · " + x for x in m["info"])
    raise SystemExit("fail face")
PAT = ["fine gold inlay lines tracing every joint between the sections", "mother-of-pearl flowers inlaid into the sections", "silver filigree inlay curling across the sections",
       "carved relief of vines and leaves across the surface of every section", "a carved geometric lattice relief across every section", "thin brass inlay lines running along the grain of every section",
       "carved relief of waves across the surface of every section", "tiny inlaid gemstones set along the joints"]
NAILSHAPE = ["stiletto", "coffin", "almond", "curved talon", "ballerina"]; NAILLEN = ["as long as her whole hand", "longer than her middle finger", "a full hand-length past her fingertips", "as long as her forearm is wide"]
FORM = ["thigh-high platform stiletto boots", "strappy platform stiletto sandals", "pointed platform stiletto pumps", "knee-high lace-up platform stiletto boots", "platform stiletto ballet boots"]
def person(label, kind, pick, phys, age, pose, eth, heel_in):
    nm, desc, base, acc = pick; pn, pd = phys; p = f"{label}: " if label else ""
    nmw = nm if (kind == "wood" and nm.endswith("wood")) or kind == "stone" else nm + " wood"
    pat = rr.choice(PAT)
    if kind == "wood":
        dw = desc if desc.endswith("wood") else desc + " wood"
        mat = (f"full body {dw} carved directly over her own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not a printed pattern, this is solid carved wood curving to follow her body's true three-dimensional shape, divided into dozens of fitted carved sections whose grain changes direction from one section to the next, each joint standing in a thin raised ridge catching its own soft glint and casting its own small shadow, nothing lying flat. Dense fitted sections — {base}, {acc}, with {pat}, polished to a warm satin sheen, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    else:
        mat = (f"full body {desc} fused directly to her own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, this is solid stone curving to follow her body's true three-dimensional shape, divided into dozens of fitted stone sections, each joint standing in a thin raised ridge catching its own bright glint and casting its own small shadow, nothing lying flat. Dense fitted sections — {base}, {acc}, with {pat}, high-gloss polished, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    feat, seg, info = face(eth)
    skin = eth[1]
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} carved from the same {nmw}, each with a razor-thin tapered heel a full {rr.choice(HEELT)} tall and a twelve-inch hidden front platform, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, carved from the same {nmw} with a high polish."
    fc = f"{p}Face: her face and ears are NOT carved — they are real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face, {seg}."
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair()} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    return "\n".join([body, shoe, nails, fc]), info, nmw
def build(kinds, picks, physs, ages, poses, eths, setting):
    n = len(picks); labels = [f"#{i+1}" for i in range(n)] if n > 1 else [None]; infos = []
    blocks = []
    for i in range(n):
        b, info, _ = person(labels[i], kinds[i], picks[i], physs[i], ages[i], poses[i], eths[i], None); blocks.append(b); infos.append(info)
    env = f"{setting}, bright and evenly lit, shadows soft, the whole floor and surroundings clearly visible and in focus, NO dark background NO black void."
    if n == 1: tail = f"Background: {env} ONE woman only. Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
    else: tail = f"Environment: {env}\nAll: Extreme macro detail on every surface texture and shadow. CRITICAL: all {n} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere, every element standing in true relief, nothing flat. {NUM[n]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame."
    t = f"""Professional fashion photograph, full body shot. {NUM[n]} wom{"a" if n == 1 else "e"}n standing{" side by side" if n > 1 else ""}.

{chr(10).join(chr(10) + x if False else x for x in ["\n\n".join(blocks)])}

{tail}{CAM} 8K portrait {ASP[n]} aspect ratio."""
    return t, infos
PLAN = [(1, ["wood"]), (1, ["stone"]), (2, ["wood", "stone"]), (2, ["stone", "wood"]), (3, ["wood", "stone", "wood"]), (3, ["stone", "wood", "stone"])]
o = ["# 목재·석재 혼합 — 모든 축 샘플 6개 (피어싱 제외)\n", "연령·인종(얼굴)·체형·자세·머리·최극단 힐(신발 형태 다양)·최장 네일·표면 패턴·메이크업·표정·렌즈/마이크로더멀/스티커/헤나를 모두 넣고, 듀오·트리오는 목재와 석재를 섞었습니다. 번호별로 정상/이상만 알려주세요.\n"]
for i, (n, kinds) in enumerate(PLAN, 1):
    for attempt in range(30):
        picks = [rr.choice(WOODS if k == "wood" else STONES) for k in kinds]
        if len({p[0] for p in picks}) < n: continue
        physs = rr.sample(BIG, n); ages = [rr.choice(AGES) for _ in range(n)]; poses = [rr.choice(POSES) for _ in range(n)]; eths = rr.sample(ETH, n)
        si = rr.randrange(8)
        t, infos = build(kinds, picks, physs, ages, poses, eths, SETS[si])
        try: check(f"f{i}", t)
        except AssertionError: continue
        if re.search(r"\b(\w+) \1\b", t) or re.search(r"[가-힣]", t): continue
        break
    else: raise SystemExit("fail")
    ti = f"{['','솔로','듀오','트리오'][n]} · " + " / ".join(f"{'목재' if k=='wood' else '석재'} {p[0]}" for k, p in zip(kinds, picks)) + " · 체형 " + ", ".join(x[0] for x in physs) + " · 인종 " + ", ".join(e[0] for e in eths) + " · " + " ‖ ".join(infos) + f" · 배경 {SETKO[si]} · 최극단 힐·최장 네일"
    o.append(f"## {i}. {ti}\n\n```\n{t}\n```\n"); print(i, ti[:300], len(t.split()))
open(O + "LumineX_WoodStone_AllAxes6.md", "w", encoding="utf-8").write("\n".join(o))
