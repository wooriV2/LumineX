# -*- coding: utf-8 -*-
# 한중일 얼굴컷 v2 샘플: 메이크업 × 피어싱/쥬얼리 × 마이크로더멀 × 스티커 × 헤나 × 렌즈 랜덤 (포인트는 최대 3종)
import random, re, sys
import cjk_face_lib as C, sf_blend_lib as L
from ladder_pool import POOL
F, MK = C.load(); MK.update(C.BLACK_MK)
NATS = {"한국": "Korean", "중국": "Chinese", "일본": "Japanese"}
STEP_IDX = {"코갸루": [1,2,3,4,5], "마이코": [1,2,3,4], "경극": [1,2,3,4], "혼례(연지곤지)": [1,2,3,4], "둔황 비천풍": [1,2,3,4], "글래스 스킨": [1,2,3,4],
            "비주얼계 블랙립": [2,4], "고스 블랙립": [2,4], "비닐 블랙립": [2,4], "립온리 블랙": [2,4], "뱀파이어 다크": [2,4],
            "클래식 레드립": [1,2], "와인 레드립": [1,2], "코랄 립": [1,2], "푸시아 립": [1,2], "블러드 립": [1,2]}
ORIG = ["강남언니", "인스타글램", "구풍", "홍콩풍", "아마갸루", "걸크러시", "지뢰계", "야마바", "만바", "반바", "아게하", "펑크 블랙립", "잉크 블랙립"]
FACEPAINT = {"경극", "마이코", "혼례(연지곤지)", "둔황 비천풍"}
DARKSTEP = {"비주얼계 블랙립", "고스 블랙립", "비닐 블랙립", "립온리 블랙", "뱀파이어 다크", "블러드 립"}
DARKORIG = C.DARK
STYLES = list(STEP_IDX) + ORIG
def pick_makeup(rr, style=None):
    if style is None and rr.random() < 0.12: return None
    if style == "NONE": return None
    style = style or rr.choice(STYLES)
    if style in STEP_IDX:
        lab, txt, tan = POOL[style][rr.choice(STEP_IDX[style])]
        lab = lab.split(" (")[0]
        return dict(style=style, label=f"{style} {lab}", text=txt, tan=tan, dark=style in DARKSTEP, facepaint=style in FACEPAINT)
    raw = MK[style].strip().rstrip(",").strip(); mode = rr.choice(["포인트", "강화"])
    txt = (C.INT + raw) if mode == "강화" else raw
    return dict(style=style, label=f"{style}({mode})", text=txt, tan=style in C.TAN_STYLES, dark=style in DARKORIG, facepaint=False)

GEM_SHAPES = ["heart", "star", "four-leaf clover", "crescent moon", "butterfly", "round"]
GEM_COLORS = ["clear", "pink", "ruby-red", "emerald-green", "sapphire-blue", "gold", "amethyst-purple"]
STK = [("야광 별", {"ck"}, "three small glow-in-the-dark star stickers on the cheekbone, softly glowing neon green-blue against the dark"),
       ("야광 하트·별", {"ck", "tp"}, "five tiny glow-in-the-dark heart and star stickers scattered on the cheekbones and temple, softly glowing neon pink and blue"),
       ("나비", {"tp", "ck"}, "two small iridescent butterfly stickers, one at the outer corner of the eye on the temple and one on the cheekbone"),
       ("금박 나뭇잎", {"tp", "ck"}, "three small gold foil stickers shaped like tiny leaves, one at the temple and two on the cheekbone"),
       ("동물 실루엣", {"ck", "tp"}, "three small cat and rabbit silhouette stickers on the cheekbones and temple"),
       ("네잎클로버", {"tp", "ck"}, "three small green four-leaf clover stickers, one at the temple and two on the cheekbone"),
       ("금박 별(관자놀이)", {"tp"}, "four small gold foil star stickers, two at each temple"),
       ("야광 초승달(관자놀이)", {"tp"}, "a small glow-in-the-dark crescent moon sticker at each temple, softly glowing neon blue-green against the dark"),
       ("이마 눈", {"fh"}, "a single small evil-eye sticker at the center of the forehead, well above the brows")]
LENS_COL = [("아이스블루", "ice-blue"), ("코발트 블루", "deep cobalt-blue"), ("에메랄드", "vivid emerald-green"), ("형광 라임", "neon lime-green"), ("앰버", "glowing amber-gold"),
            ("바이올렛", "vivid violet-purple"), ("크림슨 레드", "intense crimson-red"), ("핫핑크", "hot-pink"), ("순백", "pure opaque white"), ("오렌지 파이어", "fiery orange"), ("터쿼이즈", "bright turquoise")]
LENS_PUP = [("둥근 동공", "round natural pupils"), ("고양이눈", "a vertical slit cat-eye pupil"), ("큰 동공", "a greatly enlarged dilated pupil"),
            ("방사형 무늬", "a radiating sunburst iris pattern"), ("두꺼운 외곽 링", "a thick dark outer ring and round natural pupils"), ("하트 동공", "a heart-shaped pupil")]
LQ = "fully opaque and solidly saturated across the whole iris with no natural brown showing through, the colour bright and unmistakable, with a darker limbal ring"
LTAIL = "sitting naturally on the irises and clear of the eyelids"
HENNA = [("붉은 갈색", "deep reddish-brown"), ("금색", "metallic gold"), ("흰색", "pure white")]

def art(c): return ("an " if c[0] in "aeiou" else "a ") + c
W = {"pierce": 3, "lens": 0.6, "micro": 1.4, "sticker": 1.4, "henna": 1}
def wsample(rr, opts, k):
    pool = list(opts); res = []
    for _ in range(min(k, len(pool))):
        c = rr.choices(pool, [W[o] for o in pool])[0]; res.append(c); pool.remove(c)
    return res
KO_S = {"heart": "하트", "star": "별", "four-leaf clover": "네잎클로버", "crescent moon": "초승달", "butterfly": "나비", "round": "라운드"}
KO_C = {"clear": "투명", "pink": "핑크", "ruby-red": "루비", "emerald-green": "에메랄드", "sapphire-blue": "사파이어", "gold": "골드", "amethyst-purple": "자수정"}
def make(rr, nat, grp, expr, style=None, slots=None, pier_level=None, nacc=None, must=None, pier_min=False):
    mkp = pick_makeup(rr, style)
    dark = bool(mkp and mkp["dark"]); fp = bool(mkp and mkp["facepaint"])
    mtxt = mkp["text"] if mkp else ""
    free = {"fh": not re.search(r"forehead|huadian|gonji", mtxt), "ck": True, "tp": True}
    can_lens = "lens" not in mtxt.lower()
    hasstk = "sticker" in mtxt.lower()
    opts = ["pierce", "lens"] + ([] if fp else ([] if hasstk else ["micro", "sticker"]) + (["henna"] if free["fh"] else []))
    if not can_lens: opts.remove("lens")
    k = nacc if nacc is not None else rr.choice([2, 3])
    if slots is not None: chosen = slots
    elif must: chosen = list(must) + wsample(rr, [o for o in opts if o not in must], max(0, k - len(must)))
    else: chosen = wsample(rr, opts, k)
    M = dict(piercing="P0", jewelry=False, micro=None, sticker=None, henna=None, lens=None)
    parts = [mtxt.strip().rstrip(",")] if mtxt else []; info = []; acc = []
    pier = "pierce" in chosen
    if pier:
        lv = pier_level or rr.choice(["P50", "P100", "P150"] if dark else (["P25", "P50"] if pier_min else ["P3", "P8", "P15", "P25", "P50"]))
        cands = [x for x in F if x["meta"]["piercing"] == lv]; src = rr.choice(cands)
        jew = "Jewelry:" in src["prompt"]; info.append(f"피어싱 {lv}" + ("+쥬얼리" if jew else "")); M["piercing"] = lv; M["jewelry"] = jew
    else:
        src = [x for x in F if x["meta"]["piercing"] == "P25"][0]
    clr = " and clear of the piercings" if pier else ""
    zone_ck = zone_fh = zone_tp = False
    if "micro" in chosen:
        sh, co = rr.choice(GEM_SHAPES), rr.choice(GEM_COLORS)
        pl = rr.choice(["A", "A+B", "C"] if free["fh"] else ["A", "C"])
        where = {"A": "a row of five small gems along each cheekbone", "A+B": "a row of five small gems along each cheekbone and one larger gem at the center of the forehead", "C": "a cluster of three small gems at each temple"}[pl]
        zone_ck |= "A" in pl; zone_fh |= "B" in pl; zone_tp |= pl == "C"
        shp = "round faceted" if sh == "round" else f"{sh}-shaped"
        parts.append(f"microdermal {co} {shp} gems pressed deep into the skin: {where}, each gem sitting on a tiny hidden metal base implanted beneath the skin and pressing firmly down so the skin around every gem is visibly pushed in, forming a clear small dimple with a soft raised ring of flesh bulging around its edge, a small natural warm shadow in each dimple, calm healthy skin with no redness or swelling, all gems well clear of the eyes" + clr)
        info.append(f"마이크로더멀 {KO_C[co]} {KO_S[sh]}"); M["micro"] = f"{KO_C[co]} {KO_S[sh]}"
    if "sticker" in chosen:
        ok = [s for s in STK if (("fh" not in s[1]) or (free["fh"] and not zone_fh)) and not ("ck" in s[1] and zone_ck) and not ("tp" in s[1] and zone_tp and s[1] != {"tp", "ck"})]
        ok = [s for s in STK if not (("ck" in s[1]) and zone_ck) and not (("tp" in s[1]) and zone_tp) and not ("fh" in s[1] and (zone_fh or not free["fh"]))]
        s = rr.choice(ok); parts.append(s[2] + ", all stickers flat on the skin, clear of the eyes and lids" + clr); info.append(f"스티커 {s[0]}"); M["sticker"] = s[0]
        zone_fh |= "fh" in s[1]
    if "henna" in chosen and not zone_fh:
        hn = rr.choice(HENNA); parts.append(f"fine {hn[1]} henna mehndi line patterns of vines and dots painted across the forehead only, well clear of the eyes and brows"); info.append(f"헤나 {hn[0]}"); M["henna"] = hn[0]
    if "lens" in chosen:
        if rr.random() < 0.2:
            (n1, c1), (n2, c2) = rr.sample(LENS_COL, 2); p1, p2 = rr.choice(LENS_PUP), rr.choice(LENS_PUP)
            parts.insert(1 if mtxt else 0, f"odd-eyed with two clearly different lenses: her left eye has {art(c1)} coloured contact lens with {p1[1]}, {LQ}, and her right eye has {art(c2)} coloured contact lens with {p2[1]}, {LQ}, {LTAIL}, the two eye colours both bright and clearly different from each other")
            info.append(f"렌즈 오드아이 {n1}({p1[0]})|{n2}({p2[0]})"); M["lens"] = f"오드아이 {n1}({p1[0]})|{n2}({p2[0]})"
        else:
            (n1, c1), p1 = rr.choice(LENS_COL), rr.choice(LENS_PUP)
            parts.insert(1 if mtxt else 0, f"vivid {c1} coloured contact lenses with {p1[1]}, both eyes the same, {LQ}, {LTAIL}")
            info.append(f"렌즈 {n1}({p1[0]})"); M["lens"] = f"{n1}({p1[0]})"
    comp = ", ".join(parts)
    src2 = dict(src)
    if not pier: src2["prompt"] = C.strip_piercing(src["prompt"])
    t = C.build(src2, NATS[nat], grp, expr, "x" if comp else None, {"x": comp}, rr)
    if mkp and mkp["tan"]:
        sk = [v for v in L.SKIN.values() if v in t]; assert len(sk) == 1; t = t.replace(sk[0], C.TAN)
    if "micro" in chosen:
        g = ", so the glints on every piece of metal read clearly against her skin"
        if g in t: t = t.replace(g, ", so the glints on every piece of metal and every gem read clearly against her skin")
        else:
            a = "A soft frontal light on her face and ears"; assert t.count(a) == 1; t = t.replace(a, a + ", so the gems catch the light")
    assert not re.search(r"[가-힣]", t), re.findall(r".{30}[가-힣]+.{10}", t)
    assert not re.search(r"silver[ -](fox|white|era|hair|grey|gray)", t.lower())
    title = f"{nat} · {grp} · {expr} · 메이크업 {mkp['label'] if mkp else '없음'}" + "".join(" · " + x for x in info)
    return t, title, dict(M, makeup=mkp["style"] if mkp else None, makeup_label=mkp["label"] if mkp else None, tan=bool(mkp and mkp["tan"]), dark=dark, acc=info, slots=chosen, info=info)

if __name__ == "__main__":
    plan = [("한국", "20대"), ("일본", "아이돌"), ("중국", "30대"), ("한국", "아이돌"), ("일본", "30대"), ("중국", "20대")]
    STY = ["코갸루", "글래스 스킨", "비주얼계 블랙립", "와인 레드립", "홍콩풍", "걸크러시"]
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    rr0 = random.Random(seed); exprs = rr0.sample(list(C.EXPR), 6)
    o = ["# 한중일 얼굴컷 v2 번들 샘플 6개 — 메이크업 × 포인트 랜덤 (최대 3종)\n", "체형은 전부 극단적 모래시계로 동일합니다. 피어싱·마이크로더멀·스티커·헤나·렌즈 중 2~3종이 무작위로 붙었습니다.\n"]
    for i, ((nat, grp), ex) in enumerate(zip(plan, exprs), 1):
        t, title, meta = make(random.Random(seed * 100 + i), nat, grp, ex, style=STY[i-1])
        o.append(f"## {i}. {title}\n\n```\n{t}\n```\n"); print(i, title)
    open("/mnt/user-data/outputs/LumineX_CJK_Face_V2_Samples6.md", "w", encoding="utf-8").write("\n".join(o))
