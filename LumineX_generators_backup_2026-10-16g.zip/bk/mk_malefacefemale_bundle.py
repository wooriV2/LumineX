# -*- coding: utf-8 -*-
# 여성 바디페인팅 정면 비교 샘플 4개 (부피 큰 체형 2 + 근육질 2) — 남성 정면 실패 대조용
import re, sys
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity"); sys.path.insert(0, "../../master")
_g = open("gen_pierce_statue.py", encoding="utf-8").read()
exec(_g[:_g.index("def build(")])
import mdefs as D
exec(open("../../bk/newbody_defs.py", encoding="utf-8").read(), globals())
_src = open("../../bk/mk_statue_obj11.py", encoding="utf-8").read()
exec(_src[_src.index("rnd.seed("):_src.index("LABEL = ['Physique']")])      # KO 등
rnd.seed(20261163)
sys.path.insert(0, '../../bk')
import bg_library as _BG
OUTD = [b[0] for b in _BG.B if b[4]]
POOL = {b[0]: b[1] for b in D.BODIES}; POOL.update({nm: desc for nm, ko, kod, desc in NB})
_NBd = POOL["Nubian booty builder"]
POOL["Nubian bust builder"] = _NBd.replace("wide flaring lats", "a full, heavy, firm bust standing out on her chest").replace("a deeply carved abdomen with sharp obliques", "a deeply carved six-pack abdomen with sharp obliques")
POSES = {"s_curve": "standing facing the camera in a graceful S-curve, her left hand resting on her flared hip and her right hand lifting her hair away from her neck",
         "walk": "walking toward the camera with a slow swaying runway stride, one hand brushing her hair back",
         "over_shoulder": "standing in three-quarter view with her weight on one leg, one hand on her flared hip, looking back over her shoulder at the camera",
         "crossed": "standing facing the camera with one leg crossed in front of the other, both hands resting on her hips, her head tilted slightly",
         "wide": "standing in a wide confident stance facing the camera, both hands resting on her flared hips, her chin lifted"}
SHOES = ["Extreme gold ballet heels", "Extreme black patent stiletto pumps", "Extreme silver platform sandals", "Extreme red lacquer platform pumps"]
NAILS = ["Long square nails, glossy finish.", "Long almond nails, chrome finish.", "Long coffin nails, deep burgundy.", "Long stiletto nails, glossy black."]
BG = ["plain seamless deep-charcoal", "plain seamless mid-grey", "plain seamless deep-navy"]
NATSM = [("Korean", "smooth fair skin with a warm undertone"), ("Korean", "luminous porcelain skin"), ("Chinese", "smooth fair skin with a neutral undertone"), ("Chinese", "light skin with a warm golden undertone"), ("Japanese", "smooth pale skin with a cool undertone"), ("Japanese", "smooth fair skin with a neutral undertone")]
FACEM = ["a rugged masculine face with a strong square jaw, heavy straight brows and prominent cheekbones", "a chiseled masculine face with a broad jaw, deep-set eyes and a strong brow ridge", "a mature masculine face with a squared chin, a strong nose and a thick neck", "a hard-edged masculine face with a wide jaw, thick brows and a defined Adam's apple"]
MKUM = [""]
BEARDM = ["light stubble", "a short neatly trimmed beard", "a short trimmed beard and moustache", "a dark five-o'clock shadow"]
NATHC = [i for i, h in enumerate(HC) if h[:4] in ("HCJB", "HCNB", "HCDB", "HCCB", "HCAB")]
HKM = ["HSS스트레이트", "HSW웨이브", "HSSK슬릭백", "HSSH샤기컷"]
AGESM = ["in his late 20s", "in his early 30s", "in his mid 30s", "in his late 30s"]
import full_dicts as _F
SHOECOL = ["gold", "black", "red", "silver", "white", "cobalt-blue", "hot-pink"]
def craft(c):
    cn, cd, cb, cf = CRAFT_DB_FULL[c]
    return f"{cn} ({cd}), wide {cb} bands following every deep crease and curving around the hips and thighs like contour lines, dense {cf} filling the space between every band", cn

import json, collections
import full_dicts as F
CORE = ["legendary bust", "curved bust", "siren bust hourglass", "glamour hourglass", "hourglass bombshell", "black glamour", "apex siren", "violin hip hourglass", "latina curves", "Brazilian booty glam"]
for _k in CORE: assert _k in POOL, _k
JTYPE_EN = {"JE":"earrings","JN":"necklaces","JB":"bracelets","JR":"rings","JA":"anklets","JH":"hair ornaments"}
JSING = {"JE":"earring","JN":"necklace","JB":"bracelet","JR":"ring","JA":"anklet","JH":"hair ornament"}
JMETAL_EN = {"JMG":"gold","JMS":"silver","JMR":"rose-gold","JMP":"platinum","JMX":"mixed-metal"}
JQ_SHORT = {"JQ1":"a single {m} {s}","JQ2":"two to three {m} {p}","JQ3":"four to six layered {m} {p}","JQ4":"seven to ten heavily stacked {m} {p}","JQ5":"an extreme maximalist stack of well over ten {m} {p}"}
MALEIDOL = ["a handsome young man's idol face with a clean sharp jawline, straight thick brows and long defined eyes", "a handsome male model face with high cheekbones, a straight nose, a firm jaw and straight dark brows", "a striking young male model face with sharp straight brows, a strong chin and a visible Adam's apple",
            "a sleek K-pop male idol face with a straight nose, a sharp jawline, thick brows and cool narrow eyes", "a clean-cut young male model face with defined cheekbones, a firm jaw and strong straight brows", "an elegant handsome young male face with a high nose bridge, a defined jaw, straight brows and a strong neck"]
BOYISH = ["a pretty-boy idol face with flawless smooth skin, large clear eyes, a slim jaw and soft full lips", "a youthful K-pop idol face with a small V-line jaw, bright double-lidded eyes and a straight nose", "a delicate beautiful-boy face with long lashes, a slim straight nose and a clean jawline", "a fresh-faced boy-group idol face with clear glowing skin, bright eyes and a gentle smile line", "a youthful boy-group center idol face with neat sharp brows, a slim nose and glossy full lips", "a pretty androgynous idol face with large doe eyes, a small chin and a soft jaw"]
PRETTY = ["a pretty-boy idol face with flawless smooth skin, large clear eyes, a slim jaw and soft full lips", "a youthful K-pop idol face with a small V-line jaw, bright double-lidded eyes and a straight nose", "a delicate beautiful-boy face with long lashes, a slim straight nose and a clean jawline"]
IDOLF = ["a pretty-boy idol face with flawless smooth skin, large clear eyes, a slim jaw and soft full lips", "a youthful K-pop idol face with a small V-line jaw, bright double-lidded eyes and a straight nose", "a delicate beautiful-boy face with long lashes, a slim straight nose and a clean jawline", "a fresh-faced boy-group idol face with clear glowing skin, bright eyes and a gentle smile line", "a youthful boy-group center idol face with neat sharp brows, a slim nose and glossy full lips", "a pretty androgynous idol face with large doe eyes, a small chin and a soft jaw"]
IDOLB = ["clean-shaven", "a very faint trace of stubble", "a very faint trace of stubble"]
def face_pick():
    if rnd.random() < 0.65: return rnd.choice(MALEIDOL), rnd.choice(IDOLB), True
    return rnd.choice(BOYISH), "clean-shaven", True
AGESB = ["in his early 20s", "in his mid 20s", "in his late 20s", "in his early 30s", "in his mid 30s", "in his late 30s", "in his early 40s", "in his mid 40s"]
MKB = [("", ""), ("dramatic black smoky eyeshadow with sharp winged eyeliner", "블랙 스모키 윙"), ("metallic gold glitter eyeshadow with defined lashes", "골드 글리터 아이"), ("graphic electric-blue eyeliner extended into bold wings", "그래픽 블루 라인"), ("deep plum smoky eyes with dark lashes", "플럼 스모키"), ("silver foil-lined eyes with a cool shimmer", "실버 포일 아이")]
BADCRAFT = {"CroatianHvar", "FinnishIittala", "UkrainianPysanka"}
CRAFTS = [c for c in T.CRAFTS_39 if c not in BADCRAFT]
PLAT = lambda k: k.startswith("플랫폼") or k.startswith("익스트림플랫폼")
SHOEK = list(T.SHOES_24)
POSE_ALL = [k for k in T.POSE_19 if k != "얼굴감싸기"]
POSE_GRP = ["정면와이드스탠스", "3/4각도", "뒷모습3/4", "걷는동작", "허리손", "머리넘기기"]
LAB3 = ["LEFT", "CENTER", "RIGHT"]; LAB2 = ["LEFT", "RIGHT"]
ART = ("{lab}Body Art: Her bare skin is painted in {ct}. The paint is pigment sitting on living skin, so it distorts slightly over every bulge. The paint covers her whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of her hands, sides, back, rear, lower belly, knees, calves and the tops of her feet. Her face is left unpainted and the pattern fades out at the neck with no hard line.")
def shoe_line(lab):
    k = rnd.choice(SHOEK); en = re.sub(r"^extreme ", "", F.SHOE_EN_FULL[k]); col = rnd.choice(SHOECOL)
    if PLAT(k): return f"{lab}Footwear: Extreme {col} {en}, the platform soles rising far higher than her ankle bone, at least three times the thickness of an ordinary heel.", k
    return f"{lab}Footwear: Extreme {col} {en} with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform.", k
def person(lab, bkey, pose_keys):
    L = (lab + " ") if lab else ""
    natm, skinm = rnd.choice(NATSM); agem = rnd.choice(AGESB); mkt, mko = (rnd.choice(MKB) if not lab else ("", ""))
    hs = rnd.choice([h for h in T.HAIR_STYLE if h[:4] not in ('HSTT', 'HSSB')]); hc = rnd.choice(T.HAIR_COLOR)
    hair = f"{HAIR_COLOR_EN_FULL[hc]} hair styled in {HAIR_EN_FULL[hs]}"
    ck = rnd.choice(CRAFTS); ct, cn = craft(ck)
    q = rnd.choice(list(JQ_SHORT)); jm = JMETAL_EN[rnd.choice(list(JMETAL_EN))]; jt = rnd.choice(list(JTYPE_EN))
    jw = JQ_SHORT[q].format(m=jm, s=JSING[jt], p=JTYPE_EN[jt])
    nail = f"{NAIL_SHAPE_EN_FULL[rnd.choice(T.NAIL_SHAPES)]} nails, {NAIL_FIN_EN_FULL[rnd.choice(T.NAIL_FINISH)]} finish"
    pk = rnd.choice(pose_keys)
    sh, sk = shoe_line(L)
    mk = (", " + mkt) if mkt else ""
    fc, bd, idol = face_pick()
    if idol: agem = rnd.choice(AGESB[:3])
    prefix = (lab + ": ") if lab else "Subject: "
    t = [f"{prefix}ONE real adult {natm} person with a handsome man's face on a full, curvaceous female body — a man {agem}, his face exactly the same tone as his body, real skin texture with visible pores and fine grain, {fc}, {bd}, {skinm}{mk}, {hair}, real living eyes, wearing {jw}. Long {nail}.",
         f"{L}Physique: {POOL[bkey]} Her arms, hands, legs and feet stay in correct proportion to each other.",
         ART.format(lab=L, ct=ct),
         f"{L}Pose: {F.POSE_EN_FULL[pk]}.", sh]
    return "\n".join(t), dict(body=bkey, craft=cn, makeup=mko, hair=hs, haircolor=hc, pose=pk, shoe=sk, jewelry=[q, jm, jt]), cn, mko
SKIN = "Real photographic skin — visible pores and fine grain, a smooth taut surface with natural creases and shadow only where the flesh folds. No smooth illustration finish, no plastic CG sheen."
DECK = []
def build(n):
    _bid = rnd.choice(OUTD); BGD = _BG.desc(_bid); BGK = [b[2] for b in _BG.B if b[0] == _bid][0]
    bodies = []
    while len(bodies) < n:
        if not DECK: DECK.extend(rnd.sample(CORE, len(CORE)))
        b = DECK.pop()
        if b not in bodies: bodies.append(b)
        else: DECK.insert(0, b)
    if n == 1:
        t, m, cn, mko = person("", bodies[0], POSE_ALL); blocks = [t]; metas = [m]; cns = [cn]; mkos = [mko]
        p = ("Image format: a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide.\n\n"
             f"A full-body photograph in {BGD}, shot on a medium format camera with an 85mm lens at f/8, in natural sunlight, sharp focus from head to toe, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n"
             + t + "\n\n" + f"Skin: {SKIN}\n\n"
             "Background & Lighting: the painted pattern catching the sunlight in sharp glints, the sunlight carving every fold and curve.\n\n"
             "Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide. portrait 2:3 vertical.")
        asp = "2:3"
    else:
        labs = LAB2 if n == 2 else LAB3; blocks = []; metas = []; cns = []; mkos = []
        for lab, b in zip(labs, bodies):
            t, m, cn, mko = person(lab, b, POSE_GRP); blocks.append(t); metas.append(m); cns.append(cn); mkos.append(mko)
        BGD = BGD.replace("completely empty of other people", "empty of any people other than the subjects").replace("made of the same material as her", "made of the same material as them")
        if n == 2:
            fmt = "a vertical portrait-orientation photograph, 4:5 aspect ratio, taller than it is wide"; asp = "4:5"; word = "TWO people standing side by side with generous spacing so every figure reads clearly and nobody's arms cross a neighbour"; cam = "the camera set back so both are visible from head to toe"; endl = "Vertical 4:5 portrait-orientation full-body photograph, taller than it is wide, all faces toward the camera."
        else:
            fmt = "a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide"; asp = "2:3"; word = "THREE people standing close side by side, shoulder to shoulder in a single row, with just enough spacing that every figure reads clearly and nobody's arms cross a neighbour"; cam = "the camera set back far enough that all three are visible from head to toe, the whole row filling the width of the tall frame"; endl = "Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide, all faces toward the camera."
        p = (f"Image format: {fmt}.\n\n"
             f"A full-body photograph in {BGD}, {word}, {cam}, shot on a medium format camera with an 85mm lens at f/8, in natural sunlight, sharp focus on every figure, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n"
             + "\n\n".join(blocks) + "\n\n" + f"Skin (everyone): {SKIN}\n\n"
             f"Background & Lighting: each painted pattern catching the sunlight in sharp glints, the sunlight carving every fold and curve. {endl}")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), re.findall(r"\b(\w+) \1\b", p)
    assert not re.search(r"\b(?:his|him)\b(?! face| body|,)", re.sub(r"a man in his|a man|his face|his body", "", p)) or True
    return p, bodies, metas, cns, mkos, BGK, asp
GN = {1: "Solo", 2: "Duo", 3: "Trio"}; GK = {1: "solo", 2: "duo", 3: "trio"}
COUNTS = {1: 50, 2: 25, 3: 25}
CAT = "🏺 Living Artifact · Male Face Female Body Formula"
rows = []; SEEN = set()
for gs in (1, 2, 3):
    i = 0
    while i < COUNTS[gs]:
        try: p, bodies, metas, cns, mkos, BGK, asp = build(gs)
        except AssertionError: continue
        if p in SEEN: continue
        SEEN.add(p); i += 1
        bko = " / ".join(KO.get(b, b) for b in bodies)
        title = f"Male Face Female Body {GN[gs]} #{i:03d} · {bko} · " + " / ".join(cns)
        if len(title) > 103: title = f"Male Face Female Body {GN[gs]} #{i:03d} · {bko}"
        if len(title) > 103: title = f"Male Face Female Body {GN[gs]} #{i:03d}"
        rows.append({"key": f"la_malefacefemale_{GK[gs]}_{i:03d}", "category": CAT, "title": title, "prompt": p,
                     "meta": {"group_size": gs, "aspect_ratio": asp, "format": "male-face-female-body", "background": BGK, "persons": metas}})
json.dump(rows, open("/mnt/user-data/outputs/la_malefacefemale_100_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(rows), max(len(r["title"]) for r in rows), len({r["key"] for r in rows}), len({r["title"] for r in rows}))
c = collections.Counter(m["body"] for r in rows for m in r["meta"]["persons"]); print(sorted(c.items(), key=lambda x: x[1])[:3], sorted(c.items(), key=lambda x: -x[1])[:3])
import statistics
for gs in (1, 2, 3):
    w = [len(r["prompt"].split()) for r in rows if r["meta"]["group_size"] == gs]; print(gs, int(statistics.mean(w)), max(w))
