import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
from cover_lib import SAFE
HEAD="Professional fashion photograph, close-up beauty portrait. ONE woman, facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp. Mid 20s."
HEAD_W=HEAD.replace("down to the base of her neck and the tops of her collarbones, the frame cutting off there","down to her collarbones and the tops of her shoulders, the frame cutting off there, so the earrings fully hang in view")
TAIL=" Every feature is exaggerated but beautiful, balanced and refined, in harmony with the rest of her face, never distorted, never grotesque. Real skin fine grain and a soft sheen of natural oils on her face, ears and neck, individual hair strands catching the light — a photograph of a real woman, not an illustration, not a render."
SK="The skin around every piece is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
IRON="rough black cast iron with a hammered, pitted, matte surface"
def sub(txt): return "Subject: "+txt+TAIL


ANG_TXT="her head turned about forty-five degrees to her left in a three-quarter view, her eyes still looking straight into the camera, one ear and the turned cheek clearly visible, and from this angle the full projection of her lips from her face is clearly visible,"
H45=HEAD.replace("facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face,",ANG_TXT)
assert H45!=HEAD
def lipsub(face,lips):
    return sub("A real photograph of a strikingly beautiful adult woman, mid 20s, "+face+" Her lips are the star of her face: "+lips+" Her eyes are large and bright with bright real catchlights and a round natural pupil, her skin flawless and glowing, a small refined nose and a soft defined jaw. A confident, alluring gaze into the camera.")
CUPID=lipsub("a Western woman with long glossy black hair parted in the middle and fair skin.","she has 'cupid's bow lips': an extremely sharply defined cupid's bow, with two high, crisp peaks on the upper lip and a deep, clean central dip forming a perfect M-shaped upper lip line, moderately full lips with razor-clean edges, in satin deep berry-red, elegant and precise.")
FLIP=lipsub("a Korean woman with soft layered brown hair and fair skin with a pink blush.","she has a 'lip flip': her upper lip is gently rolled outward and upward, so a wide band of the soft pink inner part of the upper lip shows above the lip line and the upper lip looks fuller and flared without extra volume, slightly relaxed, in glossy nude-pink, balanced with a full lower lip.")
LIFT=lipsub("a woman with warm olive skin and long honey-brown waves.","she has a 'lip lift': a short, lifted space between the base of the nose and the upper lip, the upper lip curled up and outward, a high, gently smiling upper lip line with a sliver of her upper front teeth showing between softly parted lips, in glossy soft coral, youthful and fresh.")
def gold(): return "Piercings: Exactly four piercings in total, only on the ear and nostril visible in this view: on the visible ear a large gold hoop with small diamonds in the lobe and two gold studs with diamonds up the rim; and one gold stud with a diamond in the nostril wing. Each piece is large and clearly visible, and nothing else on the face is pierced, her lips carry no piercing. "+SK+" All jewelry is real polished yellow gold set with clear diamonds,"+SAFE
def pearl(): return "Piercings: Exactly four piercings in total, only on the ear and nostril visible in this view: on the visible ear a large pastel-pink enamel hoop in the lobe and two small pearl studs up the rim; and one small pearl stud in the nostril wing. Each piece is large and clearly visible, and nothing else on the face is pierced, her lips carry no piercing. "+SK+" All jewelry is real polished gold with pastel-pink enamel and white pearls,"+SAFE
def steel(): return "Piercings: Exactly four piercings in total, only on the ear and nostril visible in this view: on the visible ear a large black steel hoop in the lobe and two black steel studs up the rim; and one black steel ring around the nostril wing. Each piece is large and clearly visible, and nothing else on the face is pierced, her lips carry no piercing. "+SK+" All jewelry is real blackened steel,"+SAFE
def anime_p(): return "Piercings: Exactly eight piercings in total, cute and colourful: on each ear a large glossy pastel-pink enamel hoop in the lobe and three small star-shaped studs in pastel enamel up the rim, symmetrical on both sides. Each piece is large and clearly visible, and nothing else on the face is pierced. "+SK+" All jewelry is real polished gold with pastel enamel and small gems,"+SAFE
V=[("큐피드 보우 립 (45도) — 서양인·검은 직모·새틴 딥 베리 립 · 골드+다이아 4",CUPID,gold(),H45,True),
   ("립 플립 (45도) — 한국·브라운 레이어드·글로시 누드 핑크 립 · 진주+핑크 에나멜 4",FLIP,pearl(),H45,True),
   ("립 리프트 (45도) — 올리브 피부·허니 브라운 웨이브·글로시 코랄 립 · 블랙 스틸 4",LIFT,steel(),H45,True)]
o=["# LumineX — 큐피드 보우 립·립 플립·립 리프트 (45도) 3종\n","- 45도 구도는 입술 돌출과 얼굴을 같이 보이게 하려는 것. 피어싱은 보이는 쪽 귀·콧볼 4개만(3/4 구도에서 피어싱이 사라지는 경향 대비), 입술 피어싱 없음.","- 정상/이상(+ 입술 모양 또는 눈 특징이 보이는지)만 번호로 알려주세요.\n"]
for i,(lab,sj,p,h,tq) in enumerate(V,1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(81000+i*100+tr),"한국","20대","도도한",style="NONE",slots=["pierce"],pier_level="P5"); break
        except AssertionError: continue
    else: raise SystemExit(i)
    ps=t.split("\n\n")
    depth=[x for x in ps if x.startswith("Piercing depth:")][0]; light=[x for x in ps if x.startswith("Lighting:")][0]
    if tq:
        light,n=re.subn(r"A soft frontal light on her face and ears","A soft key light from the front and slightly to the side on her face",light,count=1); assert n==1
    new="\n\n".join([h,sj,p,depth,light]); assert not re.search(r"[가-힣]",new)
    o.append(f"## {i}. {lab}\n\n```\n{new}\n```\n")
open('/mnt/user-data/outputs/LumineX_Lips45_CupidFlipLift_3.md','w',encoding='utf-8').write("\n".join(o)); print("ok")
