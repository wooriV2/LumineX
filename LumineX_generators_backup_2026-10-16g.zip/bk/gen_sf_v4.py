# -*- coding: utf-8 -*-
# 맥시멀리스트 틀 + 패턴 풀 확장(이레즈미26·UV27·바디페인팅 공예41·스테인드글라스·금박·식물·해태) + 신발24·헤어16·손톱 확장.
import json, re, random, difflib, sys
sys.path.insert(0, "/home/claude/glassface"); sys.path.insert(0, "/home/claude/diversity")
from sfv2_lib import HAIRS6, SF_AGES, HAEJAE, two_colors, SHOES, NAILS
from full_dicts import CRAFT_DB_FULL, SHOE_EN_FULL, NAIL_SHAPE_EN_FULL, NAIL_FIN_EN_FULL
D = json.load(open("/mnt/user-data/outputs/la_maximalist_bundle.json", encoding="utf-8"))
BLACK = "THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky"
KFACE = "Korean silver fox goddess luminous warm golden-olive complexion elegant silver-era maturity"
NUM = {2: "TWO", 3: "THREE", 4: "FOUR", 5: "FIVE"}
CAT = {"ire": "Irezumi", "uv": "UV Neon", "glass": "Stained Glass", "gold": "Gold Leaf", "bot": "Botanical"}
HAIR16 = ["silver-white sleek straight hair falling past her shoulders", "silver-white loose waves cascading to her waist", "silver-white voluminous curls framing her face",
          "silver-white hair in a sleek high ponytail", "silver-white hair in an elegant updo", "silver-white half-up hair, top section lifted with the length flowing loose below",
          "silver-white hair in a low bun", "silver-white chin-length bob", "silver-white layered tousled shag cut", "silver-white layered wolf cut with curtain bangs",
          "silver-white flat glossy finger waves styled close to the scalp", "silver-white intricate fishtail braid", "silver-white crown braid wrapping around the head",
          "silver-white low chignon knot at the nape", "silver-white vintage victory rolls framing the face", "silver-white sleek wet-look hair slicked straight back"]
HDR = re.compile(r"^#(\d+): " + re.escape(BLACK) + r", ((?:early|mid|late) \d0s) goddess, (.+? physique) THE MOST EXTREME")
PLAIN = "platform boots 8 inch, extra long stiletto nails to match."
UVSH = "platform boots 8 inch, extra long stiletto nails BLAZING NEON UV reactive tips."
def pool(sec, n): return [p for p in D if CAT[sec] in p["category"] and f"{NUM[n]} women standing" in p["prompt"]]
def persons_of(p): return [b for b in p.split("\n\n")[1:] if re.match(r"#\d+: ", b)]
def phys_of(b): return HDR.match(b.split("\n", 1)[0]).group(3)
def pat_of(b): return re.search(r"full body (.+?) covering", b).group(1)
def ink_of(b):
    m = re.search(r"(?:Bold black ink outlines|Bold formations|Thin irregular metallic sheets) — (.*?), NO airbrush", b, re.S)
    return m.group(1) if m else b
def craft_person(base, rnd, seen):
    while True:
        k = rnd.choice(list(CRAFT_DB_FULL)); nm, desc, pal, scroll = CRAFT_DB_FULL[k]
        if nm not in seen: break
    a, b = (pal.split("-and-") + ["gold"])[:2] if "-and-" in pal else (pal.split("-")[0], "gold")
    a, b = a.split("-")[-1], b.split("-")[-1]
    if a == b: b = "crimson" if a != "crimson" else "gold"
    A, B = a.upper(), b.upper()
    ink = f"{desc}, BLAZING {A} and VIVID {B} bands following every deep curve of her body, dense {scroll} filling every gap"
    base = re.sub(r"full body .+? irezumi covering", f"full body {nm} bodypaint covering", base, count=1)
    base = re.sub(r"(Bold black ink outlines — ).*?(, NO airbrush)", lambda m: "Bold formations — " + ink + m.group(2), base, count=1, flags=re.S)
    return base, nm, (a, b)
def haetae_person(base):
    base = re.sub(r"full body .+? irezumi covering", f"full body {HAEJAE[0]} covering", base, count=1)
    return re.sub(r"(Bold black ink outlines — ).*?(, NO airbrush)", lambda m: m.group(1) + HAEJAE[1] + m.group(2), base, count=1, flags=re.S)
def pick_persons(secs, kind, rnd, n_src):
    seen = set(); out = []
    for s in secs:
        for _ in range(500):
            if s in ("bp", "haetae"):
                src = rnd.choice(pool("ire", n_src)); b = rnd.choice(persons_of(src["prompt"]))
                if phys_of(b) in seen: continue
                if s == "bp": b, nm, cols = craft_person(b, rnd, seen); seen.add(nm)
                else: b = haetae_person(b); nm, cols = HAEJAE[0], None
            else:
                src = rnd.choice(pool(s, n_src)); b = rnd.choice(persons_of(src["prompt"]))
                if phys_of(b) in seen or pat_of(b) in seen: continue
                cols = None
            seen.add(phys_of(b)); seen.add(pat_of(b)); out.append((s, b, cols)); break
        else: raise RuntimeError(s)
    return out
def conv(block, num, age, hair, kind):
    first, rest = (block.split("\n", 1) + [""])[:2]
    m = HDR.match(first); assert m, first[:120]
    head = (f"#{num}: {BLACK}, {age} silver fox goddess, {m.group(3)} THE MOST EXTREME" if kind == "I" else f"#{num}: {KFACE}, {age}, {m.group(3)} THE MOST EXTREME")
    first = head + first[m.end():]
    i = first.index(" — full body"); j = first.rfind(", ", 0, i); oh = first[j + 2:i]
    assert re.search(r"hair|braid|loc|afro|bob|crop|ponytail|bun|wave|curl|crown|updo|cut|tresses", oh, re.I), oh
    first = first[:j + 2] + hair + first[i:]
    rest = re.sub(r"^#\d+: ", f"#{num}: ", rest, flags=re.M)
    return first, rest
def render(n, plist, ages, kind, ext, seed):
    r2 = random.Random(seed); hairs = r2.sample(HAIR16 if ext else HAIRS6, n); shoes = r2.sample(list(SHOE_EN_FULL.values()), n)
    out = []; lab = []
    for k, ((s, b, cols), age, hair, shoe) in enumerate(zip(plist, ages, hairs, shoes), 1):
        first, rest = conv(b, k, age, hair, kind)
        if ext:
            shape = r2.choice(list(NAIL_SHAPE_EN_FULL.values())); fin = r2.choice(list(NAIL_FIN_EN_FULL.values()))
            if rest == f"#{k}: {PLAIN}":
                c = list(cols) if cols else two_colors(ink_of(b))
                rest = f"#{k}: {c[0]} {c[1]} {shoe}, extra long {shape} {fin} nails {c[0]} {c[1]} tips."
            elif rest == f"#{k}: {UVSH}": rest = f"#{k}: {shoe}, extra long {shape} {fin} nails BLAZING NEON UV reactive tips."
        out.append(first + ("\n" + rest if rest else ""))
        lab.append(f"{phys_of(b).replace(' physique','')}·{age}·{pat_of(first.replace(chr(10),' ') if False else first)}·{hair.replace('silver-white ','').replace('silver-streaked ','')}")
    return out, lab
IRE = {p["meta"]["group_size"]: p for p in D if "Irezumi" in p["category"] and p["meta"]["group_size"] in (1, 2, 3, 4, 5) and p["key"].endswith("_01")}
def frame(n, out):
    src = IRE[n]["prompt"]; blocks = src.split("\n\n")
    if n == 1:
        body = re.sub(r"^#\d+: ", "", out[0], flags=re.M)
        return "Professional fashion photograph, full body shot. ONE woman standing.\n\n" + body + "\n\n" + blocks[-1]
    tail = "\n\n".join(b for b in blocks[1:] if not re.match(r"#\d+: ", b))
    return blocks[0] + "\n\n" + "\n\n".join(out) + "\n\n" + tail
def check(name, t):
    assert not re.search(r"[가-힣]", t); d = [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", t)]; assert not d, (name, d)
def make(name, kind, secs, seed, ext=True, ages=None, plist=None):
    n = len(secs); rnd = random.Random(seed)
    if plist is None: plist = pick_persons(secs, kind, rnd, 4 if n <= 4 else 5)
    if ages is None: ages = rnd.sample(SF_AGES, 4) + [rnd.choice(SF_AGES)]; ages = ages[:n]
    out, lab = render(n, plist, ages, kind, ext, seed); t = frame(n, out).replace("VIVID VIVID", "VIVID"); check(name, t)
    if kind == "K": assert "DARKEST BLACK" not in t
    return t, lab, plist, ages
# ---- 시료 정의 ----
S = []
def add(name, kind, secs, seed, ext=True, same_as=None):
    if same_as is None: t, lab, pl, ag = make(name, kind, secs, seed, ext)
    else: t, lab, pl, ag = make(name, kind, secs, seed, ext, S[same_as][5], S[same_as][6]) if False else make(name, kind, secs, seed, ext, S[same_as][6], S[same_as][5])
    S.append([name, lab, t, kind, secs, pl, ag, seed, ext])
add("국제 솔로 · 바디페인팅(공예) · 확장", "I", ["bp"], 101)
add("K 듀오 · 바디페인팅 + 이레즈미 · 확장", "K", ["bp", "ire"], 102)
add("국제 트리오 · 이레즈미 + UV + 바디페인팅 · 확장", "I", ["ire", "uv", "bp"], 103)
add("같은 트리오 · 신발·헤어·손톱 기존값 (비교)", "I", ["ire", "uv", "bp"], 103, False, same_as=2)
add("K 쿼르텟 · 바디페인팅 + 스테인드글라스 + 이레즈미 + UV · 확장", "K", ["bp", "glass", "ire", "uv"], 105)
add("국제 퀸텟 · 금박 + 식물 + 바디페인팅 + 이레즈미 + UV · 확장", "I", ["gold", "bot", "bp", "ire", "uv"], 106)
add("같은 퀸텟 · 신발·헤어·손톱 기존값 (비교)", "I", ["gold", "bot", "bp", "ire", "uv"], 106, False, same_as=5)
add("K 퀸텟 · 해태 + 바디페인팅 + 이레즈미 + UV + 식물 · 확장", "K", ["haetae", "bp", "ire", "uv", "bot"], 108)
for i, s in enumerate(S, 1): print(i, len(s[2].split()), s[0]); print("   ", s[1])
import pickle; pickle.dump([(s[0], s[1], s[2]) for s in S], open("v4_items.pkl", "wb"))
