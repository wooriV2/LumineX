# -*- coding: utf-8 -*-
# 여성 바디페인팅 정면 비교 샘플 4개 (부피 큰 체형 2 + 근육질 2) — 남성 정면 실패 대조용
import re, sys
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity"); sys.path.insert(0, "../../master")
_g = open("gen_pierce_statue.py", encoding="utf-8").read()
exec(_g[:_g.index("def build(")])
import mdefs as D
exec(open("../../bk/newbody_defs.py", encoding="utf-8").read(), globals())
_src = open("../../bk/mk_statue_obj11.py", encoding="utf-8").read()
exec(_src[_src.index("rnd.seed("):_src.index("LABEL = ['Physique']")])      # KO 등
rnd.seed(20261024)
POOL = {b[0]: b[1] for b in D.BODIES}; POOL.update({nm: desc for nm, ko, kod, desc in NB})
_NBd = POOL["Nubian booty builder"]
POOL["Nubian bust builder"] = _NBd.replace("wide flaring lats", "a full, heavy, firm bust standing out on her chest").replace("a deeply carved abdomen with sharp obliques", "a deeply carved six-pack abdomen with sharp obliques")
POSES = {"front_arms": "standing tall facing the camera straight on, arms relaxed at her sides, weight even on both feet",
         "front_hips": "standing in a wide stance facing the camera straight on, both hands resting on her flared hips",
         "front_hip1": "standing facing the camera straight on, her left hand resting on her flared hip and her right arm relaxed at her side",
         "front_hair": "standing facing the camera straight on with her weight on one leg, one hand running through her hair, the other arm relaxed at her side"}
SHOES = ["Extreme gold ballet heels", "Extreme black patent stiletto pumps", "Extreme silver platform sandals", "Extreme red lacquer platform pumps"]
NAILS = ["Long square nails, glossy finish.", "Long almond nails, chrome finish.", "Long coffin nails, deep burgundy.", "Long stiletto nails, glossy black."]
BG = ["plain seamless deep-charcoal", "plain seamless mid-grey", "plain seamless deep-navy"]
NATSM = [("Korean", "smooth fair skin with a warm undertone"), ("Korean", "luminous porcelain skin"), ("Chinese", "smooth fair skin with a neutral undertone"), ("Chinese", "light skin with a warm golden undertone"), ("Japanese", "smooth pale skin with a cool undertone"), ("Japanese", "smooth fair skin with a neutral undertone")]
FACEM = ["a refined idol face with a clean sharp jawline and long defined eyes", "a handsome model face with high cheekbones and a straight nose", "a soft-featured idol face with large clear eyes and a defined jaw", "a striking model face with sharp brows and a narrow chin"]
MKUM = ["natural idol makeup with soft brown eyeshadow and a tinted lip", "light smoky eyeliner and glossy skin", "glass-skin makeup with a faint shimmer on the cheekbones", ""]
HKM = ["HSS스트레이트", "HSW웨이브", "HSSK슬릭백", "HSSH샤기컷", "HSWF울프컷", "HSPX픽시컷", "HSTN탑노트"]
AGESM = ["in his early 20s", "in his mid 20s", "in his late 20s", "in his early 30s"]
import full_dicts as _F
SHOECOL = ["gold", "black", "red", "silver", "white", "cobalt-blue", "hot-pink"]
def craft(c):
    cn, cd, cb, cf = CRAFT_DB_FULL[c]
    return f"{cn} ({cd}), wide {cb} bands following every deep crease and curving around the hips and thighs like contour lines, dense {cf} filling the space between every band", cn
def build(bkey, PK):
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC) + 1)
    hair = f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}"
    c = rnd.choice(T.CRAFTS_39); ct, cn = craft(c)
    natm, skinm = rnd.choice(NATSM); agem = rnd.choice(AGESM); mm = rnd.choice(MKUM); mkm = (', ' + mm) if mm else ''
    hairm = f"{HAIR_COLOR_EN_FULL[HC[rnd.randrange(1, len(HC)+1)-1]]} hair styled in {HAIR_EN_FULL[rnd.choice(HKM)]}"
    p = (f"Image format: a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide.\n\n"
         f"A full-body photograph with a {rnd.choice(BG)} backdrop, shot on a medium format camera with an 85mm lens at f/8, a single hard key light raking in from one side, sharp focus from head to toe, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n"
         f"Subject: ONE real adult {natm} person with a handsome man's face on a full, curvaceous female body — a man {agem}, his face exactly the same tone as his body, real skin texture with visible pores and fine grain, {rnd.choice(FACEM)}, clean-shaven, {skinm}{mkm}, {hairm}, real living eyes. {rnd.choice(NAILS)}\n\n"
         f"Physique: {POOL[bkey]} Her arms, hands, legs and feet stay in correct proportion to each other.\n\n"
         f"Skin: Real photographic skin — visible pores and fine grain, a smooth taut surface with natural creases and shadow only where the flesh folds. No smooth illustration finish, no plastic CG sheen.\n\n"
         f"Body Art: Her bare skin is painted in {ct}. The paint is pigment sitting on living skin, so it distorts slightly over every bulge. The paint covers her whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of her hands, sides, back, rear, lower belly, knees, calves and the tops of her feet. Her face is left unpainted and the pattern fades out at the neck with no hard line.\n\n"
         f"Pose: {POSES[PK]}.\n\n"
         f"Footwear: Extreme {rnd.choice(SHOECOL)} thigh-high stiletto boots, the heels rising far higher than her ankle bone, at least three times the height of an ordinary heel.\n\n"
         f"Background & Lighting: the painted pattern catching the light in sharp glints, the hard raking light carving every fold and curve.\n\n"
         f"Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide. portrait 2:3 vertical.")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), re.findall(r"\b(\w+) \1\b", p)
    return p, f"{KO.get(bkey, bkey)} · {cn} · 메이크업 {mk}"
PLAN = [("USSBBW", "front_hips"), ("Nubian bust builder", "front_hips"), ("hourglass SSBBW", "front_hips")]
L = ["# LumineX — 여성 몸 + 남성 얼굴 실험 3종\n", "여성 Core 체형에 한중일 아이돌/모델 남성 얼굴을 얹은 실험입니다(정면 양손 허리, 싸이하이 부츠). 번호별로 성공/실패만 알려주세요.\n"]
for n, (b, pk) in enumerate(PLAN, 1):
    p, d = build(b, pk); L.append(f"## {n}. 여성 바디페인팅 · {d} · 포즈 {pk}\n\n```\n{p}\n```\n"); print(n, d, pk, len(p.split()))
open("/mnt/user-data/outputs/LumineX_Female_BodyPaint_MaleFaceFemaleBody3.md", "w", encoding="utf-8").write("\n".join(L))
