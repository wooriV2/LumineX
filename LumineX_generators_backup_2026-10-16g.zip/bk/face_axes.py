# -*- coding: utf-8 -*-
import random, re
FACEPAINT = {"경극", "마이코", "혼례(연지곤지)", "둔황 비천풍"}
LIGHTMK = {None, "", "글래스 스킨", "인스타글램", "강남언니"}
HDR = "facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face,"
LIT = "A soft frontal light on her face and ears"
KEY = "A soft key light from the front and slightly to the side on her face"
ANG = {"3/4 회전(왼쪽)": ("her head turned about forty-five degrees to her left in a three-quarter view, her eyes still looking straight into the camera, one ear and the turned cheek clearly visible,", KEY),
       "3/4 회전(오른쪽)": ("her head turned about forty-five degrees to her right in a three-quarter view, her eyes still looking straight into the camera, one ear and the turned cheek clearly visible,", KEY),
       "숙이고 올려보기": ("her head tilted slightly down with the chin tucked and her eyes looking up at the camera from beneath her brows, the camera at eye level, both ears still visible,", LIT),
       "고개 살짝 기울임": ("her head tilted a little to one side, her eyes looking straight into the camera, both ears clearly visible,", LIT)}
TEAR2 = "a small dark beauty mark just below the outer corner of her left eye like a tear mole, a second tiny beauty mark above the right corner of her upper lip, each one a clearly visible dot of real skin pigment"
TEAR3 = "a small dark beauty mark just below the outer corner of her left eye like a tear mole, a second tiny beauty mark above the right corner of her upper lip, and a third on her left cheekbone, each one a clearly visible dot of real skin pigment"
FRK = "a dense scatter of natural freckles across the bridge of her nose and both cheeks, individual tan-brown freckles clearly visible through the skin and not covered by any makeup"
MOLE = {"눈물점+입술점": TEAR2, "눈물점+입술점+광대점": TEAR3, "주근깨": FRK}
def sub(t, a, b):
    assert t.count(a) == 1, a; return t.replace(a, b)
def apply(seed, t, m, expr, tong, p_ang=0.4, p_mole=0.4):
    rr = random.Random(seed); ang = mole = None
    if tong: return t, None, None
    pier = m["piercing"] != "P0"; fp = m["makeup"] in FACEPAINT
    if rr.random() < p_ang:
        opts = [a for a in ANG if not (pier and a.startswith("3/4"))]
        if expr == "도도한": opts = [a for a in opts if a != "숙이고 올려보기"]
        ang = rr.choice(opts)
    if not fp and rr.random() < p_mole:
        cheek = bool(m["micro"] or m["sticker"])
        kinds = ["눈물점+입술점"] if cheek else ["눈물점+입술점", "눈물점+입술점+광대점"]
        if not cheek and not m["tan"] and m["makeup"] in LIGHTMK: kinds.append("주근깨")
        mole = rr.choice(kinds)
    if ang: t = sub(t, HDR, ANG[ang][0]); t = sub(t, LIT, ANG[ang][1])
    if mole: t = sub(t, "catchlights, full lips, ", "catchlights, full lips, " + MOLE[mole] + ", ")
    assert not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t)
    return t, ang, mole
