import re,sys
sys.path.insert(0,'.')
src=open('mk_anime_crack2.py',encoding='utf-8').read()
exec(src.split("S=[(\"피어싱 많음")[0].replace("exec(src.split(\"S=[(\\\"right\\\",IRON\")[0])","exec(src.split(\"S=[(\\\"right\\\",IRON\")[0])"))
def STYLE3(a):
    r="left" if a=="right" else "right"
    return (f"Style: The whole image is a real photograph of a real woman, except for one part of her face. Her neck, collarbones, shoulders, the background and the {r} side of her face are real photographic skin, hair and light. A jagged, irregular crack runs down the exact centre line of her face like a crack in glass, from the hairline above the middle of her forehead, between her eyes, down the middle of the bridge and tip of her nose, through the middle of her lips, to the middle of her chin, never cutting through either eye and never wandering more than a few millimetres from the centre line, so the nose and the lips are each split evenly in half. Everything {a} of the crack is a high-quality Japanese anime illustration with clean cel shading, crisp line art and vibrant colours: her {a} eye, brow, cheek, the {a} half of her nose, the {a} half of her lips, her {a} ear with every earring and piercing on it, and the hair above them. The crack ends at her chin and does not continue onto her neck, which is entirely real. It is one woman, one face, one pose: the anime part has the same shape, size and position as the real face it replaces, as if part of a photographed face has broken away to show a drawing beneath.")
def PIERCE3(a,body):
    r="left" if a=="right" else "right"
    return body+f" Everything on the anime {a} side of the crack is drawn: the ear itself, every ring, stud and bar on it and every chain and weight hanging from it are flat cel-shaded anime art with crisp outlines and painted highlights, never a photograph and never real metal. Only the pieces on the real {r} side are real metal with real reflections, real weight and real contact shadows on real skin. The pieces on both sides are identical in shape and size, and the eyes and eyelids stay clear."
def FRAG3(a):
    return FRAG(a).replace(" Nothing drawn appears anywhere on the real side, and nothing real appears inside the anime part except the metal described below."," Nothing drawn appears anywhere on the real side, and nothing real appears inside the anime part, not even the ear or the jewelry.")
def trim(t):
    for a,b in [
     (" It is one woman, one face, one pose: the anime part has the same shape, size and position as the real face it replaces, as if part of a photographed face has broken away to show a drawing beneath."," The anime part has the same shape, size and position as the real face it replaces, as if part of a photographed face has broken away to show a drawing beneath."),
     (", framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp.",", framed from the top of her head to the tops of her collarbones. Her face is large and sharp."),
     ("Everything on the anime right side of the crack is drawn: the ear itself, every ring, stud and bar on it and every chain and weight hanging from it are flat cel-shaded anime art with crisp outlines and painted highlights, never a photograph and never real metal. Only the pieces on the real left side are real metal with real reflections, real weight and real contact shadows on real skin. The pieces on both sides are identical in shape and size, and the eyes and eyelids stay clear.","On the anime right side the ear and every ring, stud, bar, chain and weight on it are flat cel-shaded drawing with crisp outlines and painted highlights, never real metal. Only the pieces on the real left side are real metal with real reflections, weight and contact shadows. Both sides match in shape and size, and the eyes stay clear."),
     (" Every piece sits in calm, healthy, fully healed skin with no redness, no swelling and no irritation, and stays at least a finger's width from the eyeballs; no chain or bar crosses the eyes."," Every piece sits in calm, healed skin with no redness or swelling, at least a finger's width from the eyeballs."),
     ("The breaking itself is photographic: real broken edges with real depth and real shadow, not drawn. The drawn pieces show a raw torn edge where the flat colour simply ends, with no ink line around the break itself, and each lifted fragment casts a real photographic shadow with soft falloff. ","The breaking itself is photographic: real broken edges with real depth and real shadow. The drawn pieces show a raw torn edge where the flat colour simply ends, with no ink line, and each lifted fragment casts a real photographic shadow. "),
     (", so the glints on every piece of metal read clearly",""),
    ]:
        t=t.replace(a,b)
    return t
def build3(subject,pier,a="right"):
    return trim("\n\n".join([HEAD,STYLE3(a),subject,pier+SAFE,FRAG3(a),LIGHT]))
def subj3(hair,eye,extra=""):
    s=SUBJ("right",hair,eye).replace("an anime-drawn lip half with a tiny fang at the corner of the mouth","an anime-drawn nose half and lip half with a tiny fang at the corner of the mouth")
    return s+(" "+extra if extra else "")
RU2=RU
S=[("피어싱 많음 · 금 피어싱 갑옷(약 100개)",build3(subj3("long straight jet-black hair swept back","a sharp upturned anime eye with a cold iris and crisp highlights"),PIERCE3("right",P_C))),
   ("진한 메이크업 · 비주얼계 블랙립 5단계(극한)",build3(subj3("long straight silver-white hair","a huge glittering anime eye with a star-shaped pupil","Her makeup is the same on both sides, real on the real side and drawn in anime style on the anime side: "+MK+"."),PIERCE3("right",IRON))),
   ("러시안 립 극한 (입술 가운데로 균열, 양쪽 모두 극단 입술)",build3(subj3("long straight pastel-pink hair with a blunt fringe","a huge sparkling anime eye with a heart-shaped pupil","Her lips are the star of her face and are split down the middle by the crack: the real half is a real photographic lip and the anime half is the same extreme lip drawn in anime style: "+RU+"."),PIERCE3("right",IRON)))]
S[2]=(S[2][0],S[2][1].replace("real lips with fine vertical lines","real lips").replace(", and an anime-drawn nose half and lip half with a tiny fang at the corner of the mouth",", and an anime-drawn nose half and lip half"))
o=["# LumineX — 쪼개진 얼굴 v2: 피어싱 많음 · 진한 메이크업 · 러시안 립 (3개)\n","- 고친 점: ① 균열을 얼굴 정중앙(코 뿌리·코끝·입술 가운데·턱 가운데)으로 옮겨 코와 입술이 반반씩 갈라지게 함 ② 애니 쪽의 귀·귀걸이·추·사슬은 전부 그림이라고 명시하고 \"애니 쪽에는 실사가 없다\"는 예외 문구 삭제 ③ 러시안 립은 입술 가운데로 균열이 지나가 양쪽 모두 극단 입술(실사/애니).","- 정상/이상(+ 애니 쪽 귀·귀걸이가 그림인지, 코·입술이 반반인지, 러시안 립이 양쪽 다 나오는지)만 번호로 알려주세요.\n"]
for i,(lab,t) in enumerate(S,1):
    assert not re.search(r"[가-힣]",t) and "three-quarter" not in t
    o.append(f"## {i}. {lab}\n\n```\n{t}\n```\n"); print(i,len(t.split()))
open(OUT+'LumineX_FaceCrack_Fix_3.md','w',encoding='utf-8').write("\n".join(o))
