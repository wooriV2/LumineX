# -*- coding: utf-8 -*-
# 글래스페이스 사전에서 메이크업만 추출(헤어·표정·피어싱·렌즈 문장 제거) → gen_cjk_v2.MK/STYLES 확장
NEW_MK = {
 "히메갸루": "soft pink blush across the cheeks, sparkling pink eyeshadow, long curled lashes, large eyes with bright real catchlights, glossy candy-pink lips",
 "오네에갸루": "defined brown-mauve eyeshadow, a precise winged liner, full natural lashes, large eyes with bright real catchlights, softly contoured cheeks, glossy rose-nude lips",
 "로리타 갸루": "large round eyes with bright real catchlights, thick curled lashes with drawn-on lower lashes, soft pink and lilac eyeshadow, round pink blush, glossy cherry-pink lips",
 "야미카와": "heavy pink-red eyeshadow smudged wide beneath both eyes like crying, faint tear-track blush running down the cheeks, large eyes with bright real catchlights, long lashes, glossy dark-cherry lips",
 "데코라": "bright pastel pink and yellow eyeshadow, thick lashes, large eyes with bright real catchlights, small star and heart shapes painted on the cheeks only, glossy candy-pink lips",
 "웨이쉰": "a warm rose-red wash blended across the outer corners of both eyes and drifting up toward the temples, the same flush spreading softly across the cheekbones and the bridge of the nose, slightly smudged, dewy highlights, soft brown-pink eyeshadow, large moist eyes with bright real catchlights and a faint glassy shine, moist rose-tinted lips",
 "한복 화보": "two round red yeonji blush circles painted on the cheeks and a small round red gonji dot at the centre of the forehead, clearly defined dark brows, softly lined eyes with bright real catchlights, small vivid red lips",
 "브리티시 모드": "a bold black graphic crease line drawn high above each eyelid, very thick false lashes on the top lids, small painted lash strokes beneath each lower lid, soft lilac-white eyeshadow, large eyes with bright real catchlights, natural brows, a soft peachy-white lip",
}
def extend(G):
    for k, v in NEW_MK.items():
        G.MK[k] = v
        if k not in G.STYLES: G.STYLES.append(k)
    return list(NEW_MK)
