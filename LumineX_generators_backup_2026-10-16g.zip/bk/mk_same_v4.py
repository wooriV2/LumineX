import re,random,sys
sys.path.insert(0,'.')
exec(open('mk_group_v2.py',encoding='utf-8').read().split('if __name__=="__main__":')[0])
R=random.Random(20261028)
EYEN=[n for n,c in EYEP]
LIPN=[n for n,c in LIPP if not n.startswith("러시안")]
RU=[n for n,c in LIPP if n.startswith("러시안")]
SETS=[("눈 주인공만 4인 (서로 다른 눈 4종)",[("eye",x) for x in R.sample(EYEN,4)],"front"),
      ("입술 주인공만 4인 (러시안 립 제외, 서로 다른 입술 4종)",[("lip",x) for x in R.sample(LIPN,4)],"q45"),
      ("유형 섞기 4인 (바비 + 브랫츠 + 서큐버스 + 인어)",[("arch","바비 인형(핑크 머리)"),("arch","브랫츠 돌"),("arch","서큐버스"),("arch","인어 세이렌")],"front"),
      ("유형 + 부위 섞기 5인 (바비 + 브랫츠 + 서큐버스 + 눈 주인공 + 러시안 립)",[("arch","바비 인형(금발)"),("arch","브랫츠 돌"),("arch","서큐버스"),("eye",R.choice(EYEN)),("lip",R.choice(RU))],"front")]
o=["# LumineX — 같은 주인공 부위끼리 · 섞기 샘플 4개\n",
"- 1 눈 주인공만 4인 · 2 입술 주인공만 4인(45도) · 3 유형 4종 섞기 · 4 유형 + 부위 섞기 5인. 귀 장식은 인물마다 다른 종류, 메이크업은 서로 다르게(메이크업 없음 최대 1명), 한 장면·같은 배경입니다.",
"- 정상/이상은 번호로, 이상이면 한 줄만(예: 얼굴이 쌍둥이처럼 같음 · 귀 장식이 같음 · 피부가 고무 같음 · 주인공 부위 차이가 안 보임 · 인물 #번호).\n"]
for idx,(lab,spec,mode) in enumerate(SETS,1):
    n=len(spec); bg=R.choice(BGN)
    for tr in range(900):
        try: t,labs,dup=group5(R.randrange(10**7),spec,mode,bg)
        except AssertionError: continue
        if dup and dup.split()[0].lower() not in("had","that"): continue
        mk=[l.split(" · ")[4] for l in labs if "유형 고유 메이크업" not in l]
        if len(set(mk))<len(mk) or sum(x=="메이크업 없음" for x in mk)>1: continue
        break
    else: raise SystemExit(("fail",idx))
    t,nB=real2(t); t,k,k2=shorten(t); t=re.sub(r"  +"," ",t); assert not re.search(r"[가-힣]",t)
    o.append(f"## {idx}. {lab} · 배경 {bg}"+(" · 45도" if mode!="front" else " · 정면"))
    for j,l in enumerate(labs,1): o.append(f"- #{j}: {l}")
    o.append(f"- 길이: {len(t.split())}단어\n\n```\n{t}\n```\n"); print(idx,n,len(t.split()),[x[1] for x in spec],[l.split(" · ")[-1] for l in labs])
open(OUT+'LumineX_SameStar_Mixed_4.md','w',encoding='utf-8').write("\n".join(o))
