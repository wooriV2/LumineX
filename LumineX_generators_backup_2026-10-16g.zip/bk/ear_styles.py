import re,random
SEG_OLD="each opening holding its own very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel"
METALS={
"gold":("rough-cast matte yellow gold with a hammered, uneven, unpolished surface like a raw gold ingot","gold"),
"bronze":("dark brown bronze with a rough cast, uneven surface and green-black patina","bronze"),
"iron":("blackened rough cast iron with a hammered, uneven surface","iron"),
"tin":("dull matte pitted pewter-grey tin with a rough hammered surface","tin"),
"brass":("dull dark brass with a rough cast, uneven surface","brass"),
"silver":("tarnished dark silver with a rough, hammered, unpolished matte surface","silver"),
"copper":("oxidized dark copper with a rough cast, uneven surface","copper"),
"lead":("dull matte blue-grey lead with a pitted, scarred surface","lead")}
SHORTM={"gold":"rough-cast matte yellow gold","bronze":"dark patinated bronze","iron":"blackened cast iron","tin":"dull pewter-grey tin","brass":"dull dark brass","silver":"tarnished dark silver","copper":"oxidized dark copper","lead":"dull blue-grey lead"}
KOR={"gold":"금","bronze":"청동","iron":"철","tin":"주석","brass":"황동","silver":"은","copper":"구리","lead":"납"}
SHAPES=["a round bell","a chunky hexagonal nut-shaped weight with a round hole through the centre","a cube-shaped block","a square-sided cowbell","a barrel-shaped weight","a hammer head","a teardrop-shaped sinker","a bell-shaped weight like a small temple bell with a flared rim","a ship's anchor","a miniature anvil","a pyramid-shaped lump"]
CHAIN=["shortest","short","medium","long","longer","longest"]
FORMS=[
"a gigantic multi-tier waterfall chandelier earring, a large classic round O-ring hoop in the lobe with three stacked tiers of marquise and teardrop gem drops cascading from it, each tier wider than the last, as wide as her palm and as long as her hand, hanging freely in the air down to the level of her collarbone and no lower",
"an enormous oval hoop earring almost the size of her palm, thick polished metal set with a continuous line of gems, with a long drop of three graduated teardrop gems hanging freely in the air from its base down to the level of her collarbone and no lower",
"a gigantic chain-curtain earring: a large round O-ring hoop in the lobe from which six fine chains of different lengths fall in a shimmering fringe, each chain ending in a gem drop, the longest reaching the level of her collarbone and no lower, and the fringe as wide as her palm",
"a gigantic geometric chandelier earring, a large round O-ring hoop in the lobe with a pyramid of nested triangles, squares and hexagons hanging from it, a gemstone dangling from every corner, as wide as her palm and hanging freely in the air down to the level of her collarbone and no lower"]
FORMS.append("a huge dome-shaped bell earring as large as her palm, with rows of tiny gem and pearl drops hanging from its rim, hanging freely in the air down to the level of her collarbone and no lower")
FORMLAB=["폭포형 샹들리에","초대형 후프+드롭","체인 커튼","기하학 샹들리에","종 모양 자므카형"]
def items(rr,mode,metal,k):
    shapes=rr.sample(SHAPES,k); out=[]
    if mode=="mix":
        ms=[]
        while len(ms)<k:
            pool=list(METALS); rr.shuffle(pool); ms+=pool
        ms=ms[:k]
    else: ms=[metal]*k
    ch=CHAIN[:]
    for i,(s,m) in enumerate(zip(shapes,ms)):
        c=ch[min(i*len(ch)//k,len(ch)-1)] if k>1 else "long"
        out.append((f"{SHORTM[m]} " if mode=="mix" else "")+f"{s} on a {c} chain")
    return out
OLDL="Because the load is shared between two openings, each earlobe is stretched only into a firm, moderately long, healthy loop of skin that hangs just past her jaw; the lobe does not sag, droop, collapse or hang down to her shoulder, her head stays upright, and the skin stays smooth and intact, fully healed, with no tearing, no wound, no blood and no redness."
NEWL="Because the load is shared between two openings, the weight gently pulls each earlobe down a little into a slightly elongated, soft, healthy loop of skin, only a small natural droop that is just enough to show how heavy the weights are; the lobe never stretches long, never tears or collapses and never hangs down to her neck or shoulder, her head stays upright, and the skin stays smooth and intact, fully healed, with no tearing, no wound, no blood and no redness."
def apply_ear(t,mode,nw,rr,w,HW2,COL2,metal_th,label):
    t2,l2=_apply_ear(t,mode,nw,rr,w,HW2,COL2,metal_th,label)
    NEWC="the chains hanging freely in the air, clear of her neck and shoulders, with even the longest chain and its weight ending no lower than the level of her collarbones, never below them and never resting on her chest or body"
    return t2.replace(OLDL,NEWL).replace("the long chains reaching down along her neck to her collarbones",NEWC),l2
def _apply_ear(t,mode,nw,rr,w,HW2,COL2,metal_th,label):
    """mode: iron|mix|one|earring|combo. returns (t, label)"""
    if mode=="iron": return t,label
    a=t.index("All the ear weights hang from the bottoms of these two iron rings")
    col=COL2[nw]; hw=HW2.format(col=col); b=t.index(hw)+len(hw)
    one=rr.choice(list(METALS)) if mode=="one" else None
    lobe=" Because the load is shared between two openings, each earlobe is stretched only into a firm, moderately long, healthy loop of skin that hangs just past her jaw; the lobe does not sag, droop, collapse or hang down to her shoulder, her head stays upright, and the skin stays smooth and intact, fully healed, with no tearing, no wound, no blood and no redness."
    assert lobe.strip() in hw
    big=("Every single weight is a massive, dense, solid lump of metal as big as a fist or larger, rough and matte and unpolished with no shine and no delicate or thin parts; its size does NOT shrink just because there are many of them: the last weight is exactly as big, as thick and as heavy-looking as the first. Each weight alone looks like it weighs several kilograms, each chain is pulled bar-straight and taut, and at a glance every single one looks crushingly, unmistakably heavy, the long chains reaching down along her neck to her collarbones.")
    if mode in ("mix","one"):
        L=items(rr,mode,one,nw); R=items(rr,mode,one,nw)
        what=("each of a different shape and a different metal, all of them rough, hammered, matte and unpolished, each hanging on its own thick heavy chain of the same metal as the weight" if mode=="mix" else "each of a different shape, all of them "+METALS[one][0]+", each hanging on its own thick heavy chain of the same metal")
        heavy=(f"All the ear weights hang from the bottoms of these two iron rings, and they are not counted in the piercing total: on each ear there are exactly {w(nw)} separate massive weights, {what}: on the left ear "+", ".join(L)+"; on the right ear "+", ".join(R)+". "
          f"On each ear the two iron rings each carry their own column of weights, the two columns holding {col} weights, hanging side by side on chains of different lengths and staggered at different heights so every weight is fully visible and none hides another. "+big+lobe)
        t=t[:a]+heavy+t[b:]
        if mode=="mix":
            tail="while the hanging weights are always rough, matte, unpolished heavy metal in mixed materials (lead, tin, gold, silver, bronze, copper, brass and iron),"; lab=f"혼합 금속 추 {nw}개/귀"
        else:
            tail=f"while the hanging weights are always rough, matte, unpolished {METALS[one][1]},"; lab=f"{KOR[one]} 추 {nw}개/귀"
        assert "while the hanging weights are always black cast iron," in t
        t=t.replace("while the hanging weights are always black cast iron,",tail)
        t=t.replace("Every single weight is an enormous, dense, completely solid, squat, blunt lump of rough black cast iron","Every single weight is a massive, dense, solid lump of metal")
    else:
        fa,fb=rr.sample(range(len(FORMS)),2)
        if globals().get('FORCE') is not None: fa=FORCE
        if mode=="earring":
            assert SEG_OLD in t
            t=t.replace(SEG_OLD,f"the lower opening holding {FORMS[fa]}, and the upper opening holding a large classic round hoop earring")
            a=t.index("All the ear weights hang from the bottoms of these two iron rings"); b=t.index(hw)+len(hw)
            t=t[:a].rstrip()+t[b:]
            t=t.replace(", while the hanging weights are always black cast iron,",",")
            t=t.replace("so the weights fully hang in view","so the long earrings fully hang in view").replace("(not counting the hanging weights)","(not counting the hanging drops)")
            t=t.replace("the long chains reaching down","the long earrings reaching down")
            lab="대형 귀걸이 "+FORMLAB[fa]
        else:
            assert SEG_OLD in t
            t=t.replace(SEG_OLD,f"the upper opening holding {FORMS[fa]}, and the lower opening holding one very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel")
            a=t.index("All the ear weights hang from the bottoms of these two iron rings"); b=t.index(hw)+len(hw)
            k=5; L=items(rr,"mix",None,k); R=items(rr,"mix",None,k)
            heavy=(f"The ornate earring and the weights hang side by side from the two openings without touching or hiding each other. All the ear weights hang from the bottom of the lower iron ring, and they are not counted in the piercing total: on each ear there are exactly {w(k)} separate massive weights, each of a different shape and a different metal, all of them rough, hammered, matte and unpolished, each hanging on its own thick heavy chain of the same metal as the weight: on the left ear "+", ".join(L)+"; on the right ear "+", ".join(R)+". "
              f"On each ear the lower iron ring carries its own column of {k} weights on chains of different lengths, staggered at different heights so every weight is fully visible and none hides another. "+big+lobe.replace("the load is shared between two openings","the load is shared between two openings"))
            t=t[:a]+heavy+t[b:]
            t=t.replace("while the hanging weights are always black cast iron,","while the hanging weights are always rough, matte, unpolished heavy metal in mixed materials (lead, tin, gold, silver, bronze, copper, brass and iron),")
            lab="귀걸이+혼합 금속 추 5개 "+FORMLAB[fa]
    # label swap
    label=re.sub(r"귀 추 \d+개/귀 2구멍",lab+" 2구멍" if mode in("mix","one") else lab,label)
    return t,label
