import re,random,json
exec(open('mk_trio_arch.py',encoding='utf-8').read().split("SPECS=")[0])
d=json.load(open(OUT+'la_facesculpt_300_bundle_v3cand.json',encoding='utf-8'))
def pick(pred):
    return [x for x in d if pred(x)]
bz=pick(lambda x:x['meta']['kind']=='arch' and '브랫츠' in x['title'] and x['meta']['ear_mode'] in('mix','one'))[0]
lp=pick(lambda x:x['meta']['kind']=='lip' and x['meta']['ear_mode']=='mix')[0]
o=["# LumineX — 압축·유형 사실감 적용 샘플 4개 (1인 2 · 2인 · 3인)\n","- 귀 추 문장의 재질 반복 압축(단일 금속·혼합·귀걸이+추 모드), 유형 인물 사실감 구조(인형·airbrushed·poreless 단어 제거 + 모공 문장) 적용. 번들 후보 `la_facesculpt_300_bundle_v3cand.json`에서 그대로 뽑은 것입니다.","- 정상/이상 대신, 피부(잔털·주름·고무 느낌)가 사실적인 정도를 번호별로 한 줄만 알려주세요.\n"]
n=0
for lab,x in (("1인 · 브랫츠 유형",bz),("1인 · 입술 강조 일반 인물",lp)):
    n+=1; o.append(f"## {n}. {lab} · {x['title']}\n\n```\n{x['prompt']}\n```\n"); print(n,len(x['prompt'].split()),x['meta']['ear_mode'])
for spec in ([("arch","바비 인형(금발)"),("eye",EYEP[1][0])],[("arch","브랫츠 돌"),("eye",EYEP[1][0]),("lip","체리 립")]):
    rr=random.Random(91)
    ear,h,bg="mix",2,BGN[0]
    for tr in range(300):
        try: t,labs,dup=group3(rr.randrange(10**7),spec,"front",ear,h,bg)
        except AssertionError: continue
        mk=[l.split(" · ")[4] for l in labs if "유형 고유 메이크업" not in l]
        if len(set(mk))<len(mk) or sum(m=="메이크업 없음" for m in mk)>1: continue
        break
    t=real(t,spec); n+=1
    o.append(f"## {n}. {len(spec)}인 · "+" + ".join(nm for k,nm in spec)+f"\n\n```\n{t}\n```\n"); print(n,len(t.split()))
open(OUT+'LumineX_Compressed_Samples_4.md','w',encoding='utf-8').write("\n".join(o))
