# -*- coding: utf-8 -*-
# 여성 바디페인팅 정면 비교 샘플 4개 (부피 큰 체형 2 + 근육질 2) — 남성 정면 실패 대조용
import re, sys
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity"); sys.path.insert(0, "../../master")
_g = open("gen_pierce_statue.py", encoding="utf-8").read()
exec(_g[:_g.index("def build(")])
import mdefs as D
exec(open("../../bk/newbody_defs.py", encoding="utf-8").read(), globals())
_src = open("../../bk/mk_statue_obj11.py", encoding="utf-8").read()
exec(_src[_src.index("rnd.seed("):_src.index("LABEL = ['Physique']")])      # KO 등
rnd.seed(20261041)
sys.path.insert(0, '../../bk')
import bg_library as _BG
OUTD = [b[0] for b in _BG.B if b[4]]
POOL = {b[0]: b[1] for b in D.BODIES}; POOL.update({nm: desc for nm, ko, kod, desc in NB})
_NBd = POOL["Nubian booty builder"]
POOL["Nubian bust builder"] = _NBd.replace("wide flaring lats", "a full, heavy, firm bust standing out on her chest").replace("a deeply carved abdomen with sharp obliques", "a deeply carved six-pack abdomen with sharp obliques")
POSES = {"s_curve": "standing facing the camera in a graceful S-curve, her left hand resting on her flared hip and her right hand lifting her hair away from her neck",
         "walk": "walking toward the camera with a slow swaying runway stride, one hand brushing her hair back",
         "over_shoulder": "standing in three-quarter view with her weight on one leg, one hand on her flared hip, looking back over her shoulder at the camera",
         "crossed": "standing facing the camera with one leg crossed in front of the other, both hands resting on her hips, her head tilted slightly",
         "wide": "standing in a wide confident stance facing the camera, both hands resting on her flared hips, her chin lifted"}
SHOES = ["Extreme gold ballet heels", "Extreme black patent stiletto pumps", "Extreme silver platform sandals", "Extreme red lacquer platform pumps"]
NAILS = ["Long square nails, glossy finish.", "Long almond nails, chrome finish.", "Long coffin nails, deep burgundy.", "Long stiletto nails, glossy black."]
BG = ["plain seamless deep-charcoal", "plain seamless mid-grey", "plain seamless deep-navy"]
NATSM = [("Korean", "smooth fair skin with a warm undertone"), ("Korean", "luminous porcelain skin"), ("Chinese", "smooth fair skin with a neutral undertone"), ("Chinese", "light skin with a warm golden undertone"), ("Japanese", "smooth pale skin with a cool undertone"), ("Japanese", "smooth fair skin with a neutral undertone")]
FACEM = ["a rugged masculine face with a strong square jaw, heavy straight brows and prominent cheekbones", "a chiseled masculine face with a broad jaw, deep-set eyes and a strong brow ridge", "a mature masculine face with a squared chin, a strong nose and a thick neck", "a hard-edged masculine face with a wide jaw, thick brows and a defined Adam's apple"]
MKUM = [""]
BEARDM = ["light stubble", "a short neatly trimmed beard", "a short trimmed beard and moustache", "a dark five-o'clock shadow"]
NATHC = [i for i, h in enumerate(HC) if h[:4] in ("HCJB", "HCNB", "HCDB", "HCCB", "HCAB")]
HKM = ["HSS스트레이트", "HSW웨이브", "HSSK슬릭백", "HSSH샤기컷"]
AGESM = ["in his late 20s", "in his early 30s", "in his mid 30s", "in his late 30s"]
import full_dicts as _F
SHOECOL = ["gold", "black", "red", "silver", "white", "cobalt-blue", "hot-pink"]
def craft(c):
    cn, cd, cb, cf = CRAFT_DB_FULL[c]
    return f"{cn} ({cd}), wide {cb} bands following every deep crease and curving around the hips and thighs like contour lines, dense {cf} filling the space between every band", cn

JMETAL_EN = {"JMG":"gold","JMS":"silver","JMR":"rose-gold","JMP":"platinum","JMX":"mixed-metal"}
JSING = {"JE":"earring","JN":"necklace","JB":"bracelet","JR":"ring","JA":"anklet","JH":"hair ornament"}
JTYPE_EN = {"JE":"earrings","JN":"necklaces","JB":"bracelets","JR":"rings","JA":"anklets","JH":"hair ornaments"}
JQ_SHORT = {"JQ1":"a single {m} {s}","JQ2":"two to three {m} {p}","JQ3":"four to six layered {m} {p}","JQ4":"seven to ten heavily stacked {m} {p}","JQ5":"an extreme maximalist stack of well over ten {m} {p}"}
LAB = ["LEFT", "CENTER", "RIGHT"]
def person(i, n, bkey, PK):
    natm, skinm = rnd.choice(NATSM); agem = rnd.choice(AGESM)
    hairm = f"{HAIR_COLOR_EN_FULL[HC[rnd.choice(NATHC)]]} hair styled in {HAIR_EN_FULL[rnd.choice(HKM)]}"
    c = rnd.choice(T.CRAFTS_39); ct, cn = craft(c)
    _q = rnd.choice(list(JQ_SHORT)); _m = JMETAL_EN[rnd.choice(list(JMETAL_EN))]; _t = rnd.choice(list(JTYPE_EN))
    jw = JQ_SHORT[_q].format(m=_m, s=JSING[_t], p=JTYPE_EN[_t])
    lab = LAB[i] if n == 3 else ["LEFT", "RIGHT"][i]
    t = (f"{lab}: ONE real adult {natm} person with a handsome man's face on a full, curvaceous female body — a man {agem}, his face exactly the same tone as his body, real skin texture with visible pores and fine grain, {rnd.choice(FACEM)}, {rnd.choice(BEARDM)}, {skinm}, {hairm}, real living eyes, wearing {jw}. {rnd.choice(NAILS)}\n"
         f"{lab} Physique: {POOL[bkey]} Her arms, hands, legs and feet stay in correct proportion to each other.\n"
         f"{lab} Body Art: Her bare skin is painted in {ct}. The paint is pigment sitting on living skin, so it distorts slightly over every bulge. The paint covers her whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of her hands, sides, back, rear, lower belly, knees, calves and the tops of her feet. Her face is left unpainted and the pattern fades out at the neck with no hard line.\n"
         f"{lab} Pose: {POSES[PK]}.\n"
         f"{lab} Footwear: Extreme {rnd.choice(SHOECOL)} thigh-high stiletto boots with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform.")
    return t, cn
def build(plan):
    n = len(plan)
    _bid = rnd.choice(OUTD); BGD = _BG.desc(_bid); BGK = [b[2] for b in _BG.B if b[0] == _bid][0]
    BGD = BGD.replace("completely empty of other people", "empty of any people other than the subjects").replace("made of the same material as her", "made of the same material as them")
    blocks, cns = [], []
    for i, (bkey, pk) in enumerate(plan):
        t, cn = person(i, n, bkey, pk); blocks.append(t); cns.append(cn)
    fmt = "a vertical portrait-orientation photograph, 4:5 aspect ratio, taller than it is wide" if n == 2 else "a horizontal landscape-orientation photograph, 3:2 aspect ratio, wider than it is tall"
    word = "TWO people" if n == 2 else "THREE people"
    p = (f"Image format: {fmt}.\n\n"
         f"A full-body photograph in {BGD}, {word} standing side by side with generous spacing so every figure reads clearly and nobody's arms cross a neighbour, the camera set back so all of them are visible from head to toe, shot on a medium format camera with an 85mm lens at f/8, in natural sunlight, sharp focus on every figure, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n"
         + "\n\n".join(blocks) + "\n\n"
         f"Skin (everyone): Real photographic skin — visible pores and fine grain, a smooth taut surface with natural creases and shadow only where the flesh folds. No smooth illustration finish, no plastic CG sheen.\n\n"
         f"Background & Lighting: each painted pattern catching the sunlight in sharp glints, the sunlight carving every fold and curve. {fmt.split(',')[0].capitalize()}, full-body, all faces toward the camera.")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), re.findall(r"\b(\w+) \1\b", p)
    return p, " + ".join(f"{KO.get(b, b)}({cn})" for (b, _), cn in zip(plan, cns)), BGK
PLANS = [("듀오", [("legendary bust","s_curve"),("siren bust hourglass","over_shoulder")]),
         ("듀오", [("glamour hourglass","crossed"),("curved bust","wide")]),
         ("트리오", [("legendary bust","wide"),("hourglass bombshell","s_curve"),("glamour hourglass","over_shoulder")]),
         ("트리오", [("siren bust hourglass","crossed"),("curved bust","s_curve"),("hourglass bombshell","wide")])]
L = ["# LumineX — 여성 체형 + 남성 얼굴 듀오·트리오 (야외, 주얼리 포함, 40인치 싸이하이 부츠)\n", "사람마다 여성 Core 체형 + 남성적인 얼굴 + 서로 다른 바디페인팅 패턴·주얼리입니다. 번호별로 성공/실패만 알려주세요(실패는 한 줄 이유만).\n"]
for n, (kind, plan) in enumerate(PLANS, 1):
    p, d, bk = build(plan); L.append(f"## {n}. {kind} · {d} · 배경 {bk}\n\n```\n{p}\n```\n"); print(n, kind, d, bk, len(p.split()))
open("/mnt/user-data/outputs/LumineX_Female_BodyPaint_MasculineFace_DuoTrio4.md", "w", encoding="utf-8").write("\n".join(L))
