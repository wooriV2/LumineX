# -*- coding: utf-8 -*-
# 전체 재질 섞기 시험 4개: 바디페인팅(core)·이레즈미·UV네온 + 목재·석재 + 새 재질 6종 + 배경 라이브러리 + 주얼리·메이크업·40인치 힐
import re, random, sys, json
sys.path.insert(0, "../bg")
import bg_library as BGL
src = open("gen_matmix4.py", encoding="utf-8").read()
exec(src[:src.index("W5 = [")])
O = "/mnt/user-data/outputs/"
L = lambda f: {p["key"]: p for p in json.load(open(O + f, encoding="utf-8"))}
core, mxb = L("la_core_bundle.json"), L("la_maximalist_bundle.json")
def colors(line):
    seg = line.split("ANYWHERE", 1)[1].split("Pose:", 1)[0]
    out = []
    for r in re.findall(r"\b[A-Z]{3,}(?:[ -][A-Z]{3,})*\b", seg):
        r = r.lower()
        if r not in out: out.append(r)
    return out[:3]
# 풀: 바디페인팅(문양, 신발 설명) / 이레즈미 / UV 인물별 재질문장
BP = []
for k, p in core.items():
    if not re.match(r"la_core_(duo|trio|quartet|quintet)_", k): continue
    arts = dict(re.findall(r"^(\S+(?: \S+)?) woman's body art: (.*)$", p["prompt"], re.M))
    shoes = dict(re.findall(r"^(\S+(?: \S+)?) woman's footwear: extreme (.*?), the platform soles", p["prompt"], re.M))
    for lab in arts:
        if lab in shoes and "painted in" in arts[lab]: BP.append((arts[lab], re.sub(r"^extreme ", "", shoes[lab])))
IR, UV = [], []
for k, p in mxb.items():
    m = re.match(r"la_(irezumi|uvneon)_(duo|trio|quartet|quintet)_", k)
    if not m: continue
    for l in p["prompt"].split("\n"):
        if re.match(r"#\d: THE ABSOLUTE", l) and "full body" in l and "Pose:" in l:
            mat = l[l.index("full body"):l.index(" Pose:")]
            try: cols = colors(l)
            except Exception: continue
            if len(cols) >= 2: (IR if m.group(1) == "irezumi" else UV).append((mat, cols))
print("풀:", len(BP), len(IR), len(UV))
SPOT = ", lit by her own dedicated UV blacklight spot with zero white light reaching her specifically, every formation glowing at maximum intensity"
def cj(c): return f"{c[0]} and {c[1]}" if len(c) < 3 else f"{c[0]}, {c[1]} and {c[2]}"
PAINT = {"bodypaint", "irezumi", "uvneon"}
def person_paint(label, kind, pick, phys, age, pose, eth):
    pn, pd = phys; p = f"{label}: " if label else ""
    if kind == "bodypaint":
        art, shoe_desc = pick
        mat = art.rstrip("."); shoe_txt = f"the most absurdly extreme heels imaginable — {shoe_desc}"; nailc = "painted in the same colours as her body art"
    else:
        mat0, cols = pick
        mat = mat0.rstrip(".") + (SPOT if kind == "uvneon" else "")
        shoe_txt = f"thigh-high platform stiletto boots entirely in the exact same colours as her own body art — {cj(cols)} — {NOTDARK}"; nailc = "painted in the same colours as her body art"
        if kind == "uvneon": nailc += " with UV reactive tips"
    feat, seg, info = face(eth); skin = eth[1]
    skin = skin.replace("THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky", "a deep blue-black complexion")
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair()} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    shoe = f"{p}Footwear: {shoe_txt}, each with {HEEL_}, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, {nailc}."
    fc = f"{p}Face: her face and ears are NOT painted — they are real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    return "\n".join([body, shoe, nails, jw, fc]), info
HEEL_ = "a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform"
NOTDARK = "NOT black, NOT dark, NOT plain — the footwear must be a bright, saturated, glossy colour taken straight from her own body art"
def disp2(label, kind, pick, phys, age, pose, eth, heel_in):
    if kind in PAINT:
        t, info = person_paint(label, kind, pick, phys, age, pose, eth); return t, info, kind
    if kind in NEW:
        t, info = person_new(label, kind, phys, age, pose, eth); return t, info, NEW[kind][3]
    return orig_person(label, kind, pick, phys, age, pose, eth, heel_in)
ns2["person"] = disp2
build2 = ns2["build"]
BIG5 = [ns["PH0"][k] for k in (2, 4, 5, 0, 6)]; W5 = [0.34, 0.2, 0.16, 0.14, 0.16]
rg = random.Random(20261011)
KO = {"bodypaint": "바디페인팅", "irezumi": "이레즈미", "uvneon": "UV네온", "wood": "목재", "stone": "석재", "jade": "옥", "porcelain": "도자기", "bronze": "청동", "lacquer": "옻칠", "amber": "호박", "coral": "산호·조개"}
PLAN = [("duo", ["bodypaint", "jade"], "spring_cherry", 0), ("trio", ["irezumi", "wood", "porcelain"], "museum", 1), ("quartet", ["uvneon", "stone", "lacquer", "coral"], "art_museum", 3), ("quintet", ["irezumi", "bodypaint", "bronze", "amber", "wood"], "great_wall", 2)]
o = ["# 전체 재질 섞기 시험 — 바디페인팅·이레즈미·UV네온 + 목재·석재 + 새 재질 (4개)\n",
     "한 장면에서 인물마다 다른 재질/트랙을 입히고, 배경은 새 라이브러리, 몸 주얼리·메이크업만 얼굴·40인치 힐·신발 색 일치를 모두 넣었습니다. 바디페인팅·이레즈미·UV네온 인물은 얼굴이 칠해지지 않은 맨얼굴(메이크업만)이고 신발은 몸 패턴 색입니다. UV네온 인물은 밝은 장면 안에서 자기 전용 블랙라이트 조명을 받는 방식입니다(위험도 가장 높음). 번호별로 정상/이상만 알려주세요. 이상이면 한 줄(예: UV 인물이 안 빛남, 트랙끼리 번짐, 재질 한 명 빠짐, 배경 이상).\n"]
for i, (g, kinds, bid, wxi) in enumerate(PLAN, 1):
    n = len(kinds); wx = BGL.WX[wxi]
    scene = BGL.BG[bid][3] + (f", {wx[1]}" if BGL.BG[bid][5] else "")
    for attempt in range(200):
        physs = []
        while len(physs) < n:
            c = rg.choices(BIG5, W5)[0]
            if c not in physs: physs.append(c)
        picks = []
        for k in kinds:
            picks.append(rg.choice(BP) if k == "bodypaint" else rg.choice(IR) if k == "irezumi" else rg.choice(UV) if k == "uvneon" else rg.choice(WOODS) if k == "wood" else rg.choice(STONES) if k == "stone" else None)
        ages = [rg.choice(AGES) for _ in range(n)]; poses = [rg.choice(POSES) for _ in range(n)]; eths = rg.sample(ETH, n)
        ns2["JR"].seed(rg.randrange(10**9))
        t, infos = build2(kinds, picks, physs, ages, poses, eths, scene)
        t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as any of them.", 1)
        if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t): continue
        break
    else: raise SystemExit("fail")
    assert t.count("forty inches") == n and t.count("Jewelry:") == n and "completely empty of other people" in t, (t.count("forty inches"), t.count("Jewelry:"))
    mats = " / ".join(KO[k] for k in kinds)
    o.append(f"## {i}. {g} · {mats} · 배경 {BGL.BG[bid][2]}{' · '+wx[0] if BGL.BG[bid][5] else ''} · 체형 {', '.join(x[0] for x in physs)} · 인종 {', '.join(e[0] for e in eths)} · {' ‖ '.join(infos)}\n\n```\n{t}\n```\n"); print(i, g, mats, bid, len(t.split()))
open(O + "LumineX_MatMixAll4.md", "w", encoding="utf-8").write("\n".join(o))
