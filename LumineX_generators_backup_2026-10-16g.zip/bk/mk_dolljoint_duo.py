# -*- coding: utf-8 -*-
# 인형 관절 듀오 30: 인형끼리(서로 다른 종류 15쌍 × 2), Material Mix 듀오 틀, 배꼽 펜던트 수정
import re, random, sys, json, collections, itertools
_s = open("mk_doll3.py", encoding="utf-8").read()
exec(_s[:_s.index("rg = random.Random(")])
_jw0 = ns2["jewel"]
ns2["jewel"] = lambda p: _jw0(p).replace("a small pendant at her navel", "a small pendant resting on her belly plate")
_n = open("mk_new_bundles.py", encoding="utf-8").read()
exec(_n[_n.index("HEAD = "):_n.index("# ---------- 오토마톤")])   # HEAD, DJ, doll(), BJDacc(), DOLLS
TUP = lambda v: (v["nm"], v["desc"], v["solid"], v["nmw"], v["base"], v["acc"], v["fin"], v["tag"])
KINDS = list(DOLLS); use = collections.Counter()
CAT = "🏺 Living Artifact · Doll Joint Formula"
rg = random.Random(20261110); rr.seed(20261110); ns2["JR"].seed(20261110)
pairs = list(itertools.combinations(KINDS, 2)) * 2; rg.shuffle(pairs)
out = []; seen = set()
for n, (ka, kb) in enumerate(pairs, 1):
    picks = []
    for k in (ka, kb):
        vs = DOLLS[k]; picks.append(vs[use[k] % len(vs)]); use[k] += 1
    for attempt in range(500):
        CUR_VAR.clear(); CUR_VAR[("#1", "doll")] = TUP(picks[0]); CUR_VAR[("#2", "doll")] = TUP(picks[1])
        physs = []
        while len(physs) < 2:
            c = rg.choices(BIG5, W5)[0]
            if c not in physs: physs.append(c)
        ages = [rg.choice(AGES) for _ in range(2)]; poses = [rg.choice(POSES) for _ in range(2)]; eths = rg.sample(ETH, 2)
        bid, wx = BGL.pick(rg, 2); scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty"; ns2["JR"].seed(rg.randrange(10**9))
        t, infos = build3(["doll", "doll"], [TUP(picks[0]), TUP(picks[1])], physs, ages, poses, eths, scene)
        t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as any of them.", 1)
        if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t) or t in seen or "navel" in t.lower(): continue
        break
    else: raise SystemExit("fail")
    assert t.count("forty inches") == 2 and t.count("Jewelry:") == 2
    seen.add(t)
    out.append({"key": f"la_dolljoint_duo_{n:03d}", "category": CAT,
                "title": f"DollJoint Duo #{n:03d} (인형 듀오 · {picks[0]['tag']} + {picks[1]['tag']} · 체형 {', '.join(x[0] for x in physs)} · 인종 {', '.join(e[0] for e in eths)} · {' ‖ '.join(infos)} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · 힐 40인치 · 몸 주얼리)",
                "prompt": t, "meta": {"group_size": 2, "aspect_ratio": ASP[2], "format": "dolljoint_duo", "kinds": [ka, kb], "variants": [picks[0]["tag"], picks[1]["tag"]], "physiques": [x[0] for x in physs], "ethnicity": [e[0] for e in eths],
                                      "background": bid, "weather": wx[0] if wx else None, "heel_mode": "forty", "jewelry": True}})
assert len(out) == 30 and len({p["key"] for p in out}) == 30
json.dump(out, open(O + "la_dolljoint_duo_30_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
wc = [len(p["prompt"].split()) for p in out]
print(len(out), min(wc), max(wc), sum(wc)//len(wc), collections.Counter(k for p in out for k in p["meta"]["kinds"]).most_common(), len({p["meta"]["background"] for p in out}), "배경", len({p["prompt"] for p in out}), "고유")
