# -*- coding: utf-8 -*-
import json, re, random, sys, collections
sys.path.insert(0, ".")
import sf_blend_lib as L, apply_face_k as F
OUT = "/mnt/user-data/outputs/"
L.CONT = " — full body "
B = json.load(open(OUT + "la_180_bundle.json", encoding="utf-8"))
SRC = [p for p in B if p["key"].startswith("la_crystal_") and not p["key"].startswith("la_crystal_trio")]
assert len(SRC) == 60
CAT = {"K": "🏺 Living Artifact · K-Silverfox Quartz Formula", "I": "🏺 Living Artifact · Silverfox Quartz Formula"}
KN = {"K": "la_ksilverfox_quartz", "I": "la_silverfox_quartz"}
KT = {"K": "K-Silverfox Quartz", "I": "Silverfox Quartz"}
def dedupe(t): return re.sub(r"\b(\w+) \1\b", r"\1", t)
out = []; cnt = collections.Counter()
for kind in "KI":
    for gs, nm in ((1, "solo"), (2, "duo")):
        src = [p for p in SRC if p["meta"]["group_size"] == gs]
        for i, p in enumerate(src, 1):
            t = dedupe(p["prompt"])
            t2, n = L.convert_prompt(t, kind, seed=hash((kind, p["key"])) % 10**6 if False else sum(map(ord, kind + p["key"])) * 7)
            assert n == gs
            cols = re.findall(r"full body ([a-z ]+?) crystal clusters", t2)
            phys = re.findall(r"(?:\d, |goddess, |, )([a-z/ ]+?) physique THE MOST", t2)
            phys = re.findall(r"([A-Za-z/ ]+?) physique THE MOST", t2)
            phys = [x.split(", ")[-1].strip() for x in phys]
            ttl = f"{KT[kind]} {nm.capitalize()} #{i:02d} ({'한국' if kind=='K' else '국제'} · 석영 전원 · 체형 {'/'.join(phys)} · 색 {'/'.join(cols)})"
            key = f"{KN[kind]}_{nm}_{i:02d}"
            m = {"group_size": gs, "aspect_ratio": p["meta"]["aspect_ratio"], "format": "silverfox-quartz", "kind": kind, "material": "crystal", "source": p["key"], "colors": cols}
            out.append({"key": key, "category": CAT[kind], "title": ttl, "prompt": t2, "meta": m}); cnt[(kind, nm)] += 1
print(cnt, len(out))
print("face applied", F.apply_bundle(out))
# 검증
for p in out:
    t = p["prompt"]
    assert not re.search(r"[가-힣]", t); assert not re.search(r"\b(\w+) \1\b", t)
    if p["meta"]["kind"] == "K": assert "DARKEST BLACK" not in t and "Korean silver fox goddess" in t
    else: assert "silver fox goddess" in t and "Korean" not in t
    assert t.count("silver-white") >= p["meta"]["group_size"]
    assert "hazy" not in t
print(len(set(p["key"] for p in out)), "unique keys")
json.dump(out, open(OUT + "la_silverfox_quartz_120_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(out[0]["title"]); print(out[70]["title"])
rr = random.Random(5)
pick = [("I","solo"),("I","solo"),("I","duo"),("K","solo"),("K","duo"),("K","duo")]
o = ["# 실버폭스 Quartz(석영) 샘플 6개 (솔로·듀오)\n"]; used=set()
for n, (k, nm) in enumerate(pick, 1):
    c = [p for p in out if p["meta"]["kind"] == k and f"_{nm}_" in p["key"] and p["key"] not in used and (not used or True)]
    # 색 다양하게: 이미 쓴 색 제외
    c2 = [p for p in c if not (set(p["meta"]["colors"]) & usedc)] if (usedc := globals().get("usedc", set())) is not None else c
    p = rr.choice(c2 or c); used.add(p["key"]); usedc |= set(p["meta"]["colors"])
    o.append(f"## {n}. {p['title']}\n\n키 `{p['key']}`\n\n```\n{p['prompt']}\n```\n")
    print(n, p["key"], p["meta"]["colors"])
open(OUT + "LumineX_SF_Quartz_Test6.md", "w", encoding="utf-8").write("\n".join(o))
