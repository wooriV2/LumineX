# -*- coding: utf-8 -*-
import random, re
import gen_cjk_v2 as G
O = "/mnt/user-data/outputs/"
HDR = "facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face,"
LIT = "A soft frontal light on her face and ears;"
def sub(t, a, b):
    assert t.count(a) == 1, a; return t.replace(a, b)
def mk(seed, nat, grp, expr, style, head=None, mole=None):
    rr = random.Random(seed); t, title, m = G.make(rr, nat, grp, expr, style=style, slots=[])
    if head: t = sub(t, HDR, head[0]); t = sub(t, LIT, head[1])
    if mole: t = sub(t, "catchlights, full lips, ", "catchlights, full lips, " + mole + ", ")
    assert not re.search(r"[가-힣]", t); return t, title
THREEQ = ("her head turned about forty-five degrees to her left in a three-quarter view, her eyes still looking straight into the camera, one ear and the turned cheek clearly visible,",
          "A soft key light from the front and slightly to the side on her face;")
LOWER = ("her head tilted slightly down with the chin tucked and her eyes looking up at the camera from beneath her brows, the camera at eye level, both ears still visible,",
         "A soft frontal light on her face and ears;")
TEAR = "a small dark beauty mark just below the outer corner of her left eye like a tear mole, a second tiny beauty mark above the right corner of her upper lip, and a third on her left cheekbone, each one a clearly visible dot of real skin pigment"
FRK = "a dense scatter of natural freckles across the bridge of her nose and both cheeks, individual tan-brown freckles clearly visible through the skin and not covered by any makeup"
S = [("고개 3/4 회전 · 정면 응시", mk(21, "일본", "아이돌", "귀여운", "글래스 스킨", head=THREEQ)),
     ("고개 숙이고 올려보는 시선", mk(22, "한국", "30대", "섹시한", "와인 레드립", head=LOWER)),
     ("눈물점 + 입술 위 점 + 광대 점", mk(23, "중국", "30대", "고혹적인", "클래식 레드립", mole=TEAR)),
     ("주근깨 (코·양 뺨, 메이크업 없음)", mk(24, "한국", "20대", "발랄한", "NONE", mole=FRK))]
o = ["# 얼굴 컷 추가 재료 시험 4개 (각도 2 · 점/주근깨 2)\n", "번호별로 정상/이상만 알려주세요.\n"]
for i, (ax, (t, ti)) in enumerate(S, 1):
    o.append(f"## {i}. {ti} · 아워글래스 · {ax}\n\n```\n{t}\n```\n"); print(i, ti, ax)
open(O + "LumineX_Face_AngleMole4.md", "w", encoding="utf-8").write("\n".join(o))
