import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
from cover_lib import SAFE
IRON="rough black cast iron with a hammered, pitted, matte surface"
W=["a solid rough cube-shaped block","a solid rough cannonball","a chunky solid hexagonal block","a solid thick rectangular ingot block","a short thick solid cylinder stump","a solid pyramid-shaped lump with a wide base","a small solid kettlebell with a thick short handle","a solid squat hammer head block","a thick solid disc like a weight plate","a solid rough boulder-like lump"]
COL={8:"3, 3 and 2",10:"4, 3 and 3"}
def ears(nw,rr):
    return "; ".join(f"on the {s} ear "+", ".join(f"{x} on its own thick chain of heavy black iron links" for x in rr.sample(W,nw)) for s in ("left","right"))
def eartxt(nw,rr):
    return ("each earlobe carries a single very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel, passing through one large healed opening in the stretched lobe; all the ear weights hang from the bottom of this one ring, exactly "+("eight" if nw==8 else "ten")+" separate massive solid weights on each ear, each of a different shape: "+ears(nw,rr)+f". On each ear the chains hang in three side-by-side columns of {COL[nw]} weights, staggered at different heights so every weight is fully visible and none hides another. Every ear weight is an enormous, dense, completely solid, squat, blunt lump of rough black cast iron, as big as a fist or larger, with no thin parts, no arms and no hollow parts, and its size does NOT shrink just because there are many of them: the last weight is exactly as big, as thick and as heavy-looking as the first. Each weight alone looks like it weighs several kilograms, each chain is pulled bar-straight and taut, and at a glance every single one looks crushingly, unmistakably heavy. Together they drag each earlobe down hard into a very long, thin, taut, stretched loop of skin that hangs past the jaw and down the neck to the level of her collarbones, her head tilting slightly under the load; the stretch is long but natural and the loop stays smooth and intact, fully healed")
TUSK=("a single thick, solid, sharp tusk of "+IRON+" as thick as her thumb in the middle passes straight through the septum, the thin soft wall between the nostrils, and sweeps out sideways only a little past the outer edges of her nostril wings, no wider than the outer corners of her mouth, in a short, smooth boar-tusk curve, its two ends rising gently upward and tapering to sharp points, the tips ending far below her eyes at the height of her nostrils; the tusk sits clearly above her upper lip and does not touch or cover her lips, and nothing hangs from it")
CHIN=("one thick, heavy iron ring as wide as a large coin through the skin of the chin, just beneath her lower lip, and from the bottom of this one chin ring hang three separate massive solid weights of rough black cast iron, each on its own thick, heavy chain of black iron links of a different length, hanging side by side down along her chin and throat onto her neck and chest: a squat solid cube-shaped block, a solid rough cannonball and a chunky solid hexagonal block; each weight is as big as a fist or larger, dense, solid and blunt with no thin parts, and the chains are pulled bar-straight and taut, and her lips stay fully bare and visible")
LIP=("a traditional stretched lip plate in the lower lip, in the style of the lip plates worn in Ethiopia: her lower lip has been stretched around a large round hole in its centre until the lip itself is only a thin, smooth, taut loop of soft pink-red lip flesh, like a rubber band, that circles the hole all the way around, and the hole is completely filled by a thick round plate of "+IRON+" as wide as two of her fingers laid side by side, so the viewer sees, from the outside to the inside, her chin, then the full ring of stretched lip flesh, then the dark metal plate in the middle; the ring of lip flesh is clearly visible on every side of the plate, with the plate's edge sunk into it and its flat face turned toward the viewer; the loop of lip hangs down from her mouth, so her upper lip, her teeth line and the corners of her mouth stay fully bare and visible above it, and nothing hangs from the plate")
SK="The skin around every piece is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
def mk(nw,third,label,rr):
    if third is None:
        return ("Piercings: Exactly three piercings in total, and nowhere else: first, "+eartxt(nw,rr)+" (two earlobe rings in total); second, "+TUSK+". "+SK+" Her eyebrows, lips, chin, nostrils and the upper parts of her ears carry no piercing at all. All jewelry is real blackened cast iron,"+SAFE)
    return ("Piercings: Exactly four piercings in total, and nowhere else: first, "+eartxt(nw,rr)+" (two earlobe rings in total); second, "+TUSK+"; third, "+third+". "+SK+" Her eyebrows, nostrils and the upper parts of her ears carry no piercing at all. All jewelry is real blackened cast iron,"+SAFE)
CFG=[(8,CHIN,"귀 추 8개/귀 + 작아진 무쇠 엄니 + 턱 링 추 3개","chest"),(10,None,"귀 추 10개/귀(쇄골까지) + 작아진 무쇠 엄니","shoulder")]
NA=[("한국","20대","도도한"),("일본","20대","군림하는")]
FR={"chest":"down to the middle of her chest, the frame cutting off there, so the weights and chains fully hang in view","shoulder":"down to her collarbones and the tops of her shoulders, the frame cutting off there, so the weights fully hang in view"}
o=["# LumineX — 귀 무쇠 추 + 작아진 무쇠 엄니 합본 v2 (2개)\n","- 수정: 엄니 크기를 입꼬리 너비 이내로 축소, 립 플레이트 삭제, 10개/귀 귓볼 늘어짐은 쇄골까지로 단축. 1번: 귀 8개/귀 + 엄니 + 턱 링 추 3개. 2번: 귀 10개/귀 + 엄니.","- 정상/이상(+ 엄니 크기, 귀 추 개수, 턱 추 3개)만 번호로 알려주세요.\n"]
for i,((nw,third,lab,fr),(nat,grp,ex)) in enumerate(zip(CFG,NA),1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(86000+i*100+tr),nat,grp,ex,style="NONE",slots=["pierce"],pier_level="P3"); break
        except AssertionError: continue
    else: raise SystemExit(i)
    old=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    t=re.sub(r'\n\nJewelry:[^\n]*','',t.replace(old,mk(nw,third,lab,random.Random(87000+i))))
    t,nn=re.subn(r'down to the base of her neck and the tops of her collarbones, the frame cutting off there',FR[fr],t,count=1); assert nn==1
    t=t.replace("\n\nLighting:","\n\nHair: her hair is swept back behind both ears, leaving both ears, her jawline and her neck fully visible so every iron weight hangs in clear view.\n\nLighting:",1)
    assert not re.search(r"[가-힣]",t)
    o.append(f"## {i}. {lab} — {title}\n\n```\n{t}\n```\n")
open('/mnt/user-data/outputs/LumineX_EarWeights_Tusk_Combo_v2_2.md','w',encoding='utf-8').write("\n".join(o)); print("ok")
