import re,random
exec(open('mk_trio_arch.py',encoding='utf-8').read().split("SPECS=")[0])
BAR=["바비 인형(금발)","바비 인형(갈색 머리)","바비 인형(핑크 머리)"]
SETS=[("바비만 3인",[("arch",n) for n in BAR],"mix",2),
      ("브랫츠만 3인",[("arch","브랫츠 돌")]*3,"one",2),
      ("바비 2 + 브랫츠 2 (4인)",[("arch",BAR[0]),("arch","브랫츠 돌"),("arch",BAR[2]),("arch","브랫츠 돌")],"mix",2)]
def sig(p):
    a=re.search(r"with ([\w -]+) streaks",p); b=re.search(r"in (?:vivid )?([\w -]+?) doll-eye contact lenses",p)
    return (a.group(1) if a else None, b.group(1) if b else None)
o=["# LumineX — 같은 유형끼리 다인 컷 샘플 3개 (바비 · 브랫츠)\n","- 같은 유형 안에서 머리 색·렌즈 색·피어싱 단계가 서로 다르게 나오도록 뽑았습니다(브랫츠는 줄무늬 색과 렌즈 색이 겹치지 않게). 유형 인물 사실감 구조와 일반 문장 B가 적용돼 있습니다.","- 정상/이상은 번호로, 이상이면 한 줄만(예: 얼굴이 쌍둥이처럼 같다 / 한 명이 다른 유형으로 나옴 / 고무 느낌).\n"]
R=random.Random(20261020)
for idx,(lab,spec,ear,h) in enumerate(SETS,1):
    n=len(spec); bg=R.choice(BGN)
    for tr in range(600):
        try: t,labs,dup=group3(R.randrange(10**7),spec,"front",ear,h,bg)
        except AssertionError: continue
        ps=re.findall(r"(?<=\n\n#\d: ).*?(?=\n\n#\d )",t,re.S)
        brz=[sig(p) for p,(k,nm) in zip(ps,spec) if nm=="브랫츠 돌"]
        if len(set(x[0] for x in brz))<len(brz) or len(set(x[1] for x in brz))<len(brz): continue
        pl=[l.split(" · ")[5] for l in labs]
        if len(set(pl))<min(len(pl),3): continue
        break
    else: raise SystemExit(("fail",idx))
    t=real(t,spec); assert not re.search(r"[가-힣]",t)
    o.append(f"## {idx}. {lab} · 귀 {ear} · 배경 {bg}")
    for j,l in enumerate(labs,1): o.append(f"- #{j}: {l}")
    o.append("\n```\n"+t+"\n```\n"); print(idx,n,len(t.split()),brz)
open(OUT+'LumineX_SameType_Group_3.md','w',encoding='utf-8').write("\n".join(o))
