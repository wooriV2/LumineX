import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
def run_until(fn,marker):
    src=open(fn).read(); src=src[:src.index(marker)]
    ns={}; exec(compile(src,fn,'exec'),ns); return ns
HL=run_until('heavy_ladder.py','PL=[')
M2=run_until('random_mix2.py','rr=random.Random(')
NSC=run_until('combo_C.py','CFG=')
w=HL['w']; pl=HL['pl']; rim=HL['rim']; ears=HL['ears']; HW=HL['HW']; COL=HL['COL']; SAFE=HL['SAFE']; counts=HL['counts']; HENNA=HL['HENNA']; STICK=HL['STICK']; TH=HL['TH']
EYES=M2['EYES']; LIPS=M2['LIPS']; NOSES=M2['NOSES']; JAWS=M2['JAWS']; MATS=M2['MATS']
OUT='/mnt/user-data/outputs/'
SK="The skin around every piece is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
WEIGHT="carrying one massive solid weight of rough black cast iron with a hammered, pitted, matte surface, a squat solid cube-shaped block as big as a fist, which hangs below her chin onto her neck and looks crushingly heavy; the chain is thin enough that both of her lips stay clearly visible on either side of it, and the weight pulls the chain bar-straight and taut"
def tuskcore(mat):
    return ("a single thick, solid, sharp tusk of "+mat[1]+" as thick as her thumb in the middle passes straight through the lower part of the septum, the thin soft wall between the nostrils, and sweeps out sideways just beneath her nostril wings, only as far as their outer edges and not one bit further, in a short, smooth boar-tusk curve, its two ends rising clearly upward and tapering to needle-sharp points, the tips ending far below her eyes at the height of her nostrils; the tusk sits clearly above her upper lip and does not touch or cover her lips")
HW2=("On each ear the two iron rings each carry their own column of weights, the two columns holding {col} weights, hanging side by side on chains of different lengths and staggered at different heights so every weight is fully visible and none hides another. Every single weight is an enormous, dense, completely solid, squat, blunt lump of rough black cast iron, as big as a fist or larger, with no thin parts, no arms and no hollow parts; its size does NOT shrink just because there are many of them: the last weight is exactly as big, as thick and as heavy-looking as the first. Each weight alone looks like it weighs several kilograms, each chain is pulled bar-straight and taut, and at a glance every single one looks crushingly, unmistakably heavy, the long chains reaching down along her neck to her collarbones. Because the load is shared between two openings, each earlobe is stretched only into a firm, moderately long, healthy loop of skin that hangs just past her jaw; the lobe does not sag, droop, collapse or hang down to her shoulder, her head stays upright, and the skin stays smooth and intact, fully healed, with no tearing, no wound, no blood and no redness.")
COL2={8:'4 and 4',9:'5 and 4',10:'5 and 5'}
def para2(N,nw,metal,gems,deco,rr,pat=None,mat=None,zero=(),minimal=False):
    c=counts(N)
    for k in zero: c[k]=0
    seg=[]
    if pat:
        core=tuskcore(mat)
        if pat=="A": seg.append(core+"; from the exact middle of the tusk a thick iron connector ring hangs down, and from this ring a thick, heavy chain of black iron links drops straight down in front of her mouth and chin, "+WEIGHT)
        elif pat=="B": seg.append(core+"; from the exact middle of the tusk a thick iron connector ring hangs down, and from it a short, thick chain of a few heavy black iron links drops straight down in front of her closed mouth and is fastened to a thick iron ring through the middle of her lower lip's edge, a plain round ring as wide as a large coin, and from this lip ring a thick, heavy chain of black iron links continues straight down in front of her chin, "+WEIGHT)
        else: seg.append(core+"; nothing hangs from the tusk")
    else:
        seg.append(("a single large " if c["sep"]==1 else f"{w(c['sep'])} separate ")+"septum ring"+("" if c["sep"]==1 else "s")+" of different sizes and shapes through the thin soft wall between the nostrils, in a short stack that ends above the upper lip")
    h=c["nos"]//2
    if h: seg.append(f"{pl(h,'small ring')} wrapping snugly around each nostril wing")
    if c['bri']: seg.append(f"{pl(c['bri'],'straight bar')} across the bridge of the nose, from just below the inner ends of the brows (well clear of the eyes) down to the middle of the nose, each with a gem cap at both ends")
    h=c["brow"]//2
    if h: seg.append(f"{pl(h,'small bar or ring')} through each eyebrow, all on the brow bone above the eyes and never on the eyelids")
    if c['ul']: seg.append(f"{pl(c['ul'],'small hoop or stud')} along the edge of the upper lip")
    if pat!="B" and c['ll']: seg.append(f"{pl(c['ll'],'small hoop or stud')} across the lower lip's edge")
    if pat=="C": seg.append(NSC['CHIN'].rstrip('.'))
    elif c['chin']: seg.append(f"{pl(c['chin'],'small ring or stud')} on the chin")
    h=c["ear"]//2
    seg.append(f"on each ear, two separate large healed openings in the earlobe, one below the other with a clear gap of bare skin between them, each opening holding its own very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel, and above them sit {rim(h-1)}")
    if c['fh']: seg.append(f"{pl(c['fh'],'small stud')} across the lower half of the forehead just above the brows in even rows, leaving the upper forehead free")
    h=c["tmp"]//2
    if h: seg.append(f"{pl(h,'small stud')} on each temple bone, well clear of the eyes")
    h=c["chk"]//2
    if h: seg.append(f"{pl(h,'small stud')} along each cheekbone, well clear of the eyes")
    tot=sum(c.values())+(1 if pat else 0)
    dens=("The piercings are packed so densely that the rows touch and overlap, leaving only hairline gaps of bare skin between them, until the face reads as a single armour of metal; the eyes and eyelids stay clear. " if N>=100 else "The pieces are spread over the whole face in clear rows so every one reads individually, with bare skin between them; the eyes and eyelids stay clear. ")
    heavy=f"All the ear weights hang from the bottoms of these two iron rings, and they are not counted in the piercing total: on each ear there are exactly {w(nw)} separate massive solid weights, each of a different shape: "+ears(nw,rr)+". "+HW2.format(col=COL2[nw])
    tail=f" The face and ear jewelry is real {metal} set with {gems}"
    if pat: tail+=f", the tusk and its rings are real {mat[2]}, while the connector ring, the chains and all the hanging weights are always black cast iron,"
    else: tail+=", while the hanging weights are always black cast iron,"
    if minimal:
        es=[x for x in seg if x.startswith("on each ear")][0]
        return ("Piercings: Only the ears are pierced, and nowhere else on the face: "+es+". The left and right sides are balanced. Her lips, nose, eyebrows, chin, forehead, temples and cheeks carry no piercing at all, so the shape of her lips stays completely clear and unobstructed. "+deco+" "+heavy+f" The ear jewelry is real {metal} set with {gems}, while the hanging weights are always black cast iron,"+SAFE),c["ear"]
    return (f"Piercings: A face fully covered with real piercings, about {w(tot)} in total (not counting the hanging weights), spread over every area so that no area is empty: "+"; ".join(seg)+". The left and right sides are balanced. "+dens+deco+" "+heavy+tail+SAFE),tot
HDR="facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face,"
LIT="A soft frontal light on her face and ears;"
ANG45="her head turned about forty-five degrees to her left in a three-quarter view, her eyes still looking straight into the camera, one ear and the turned cheek clearly visible, and from this angle the full projection of her lips from her face is clearly visible,"
KEY="A soft key light from the front and slightly to the side on her face;"
FR_OLD="down to the base of her neck and the tops of her collarbones, the frame cutting off there"
FR={"sh":"down to the line of her shoulders, the frame cutting off just below them, so the weights fully hang in view","ch":"down to the middle of her chest, the frame cutting off there, so the weights and chains fully hang in view"}
def build(i,seed,nat,grp,expr,star,item,N,nw,v,deco,pat,zero,style='NONE',minimal=False):
    rr=random.Random(seed); jaw=rr.choice(JAWS); nose=rr.choice(NOSES); mat=rr.choice(MATS) if pat else None
    metal,gems=TH[v]
    for tr in range(80):
        try: t,title,meta=G.make(random.Random(seed*7+tr),nat,grp,expr,style=style,slots=["pierce","lens"],pier_level="P150" if N>=100 else ("P50" if N>=50 else "P25")); break
        except AssertionError: continue
    else: raise SystemExit("gen fail")
    pp=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    new,tot=para2(N,nw,metal,gems,deco,random.Random(seed+5),pat,mat,zero,minimal)
    t=re.sub(r'\n\nJewelry:[^\n]*','',t.replace(pp,new))
    sj=[x for x in t.split("\n\n") if x.startswith("Subject:")][0]
    if star=="eye": star_s=f"her eyes are the star of her face (the shape, size and lenses described here override the eyes of her makeup, while the colours of her eyeshadow and liner follow her makeup): {item[1].format(lens='coloured')}"
    else: star_s=f"her lips are the star of her face (the shape, size and projection described here override the lips of her makeup, while the lip colour and finish follow her makeup and ignore any lip colour named here): {item[1]}"
    add=f" Her face has been surgically sculpted far beyond her natural look, and these changes override her natural features: {star_s}; her nose: {nose[1]}; her jawline and chin: {jaw[1]}. Every feature is exaggerated but beautiful, balanced and refined, in harmony with the rest of her face, never distorted, never grotesque."
    t=t.replace(sj,sj+add)
    fr=FR["ch"] if pat else FR["sh"]
    t,n=re.subn(re.escape(FR_OLD),fr,t,count=1); assert n==1
    if star=="lip":
        t=t.replace(HDR,ANG45,1); t=t.replace(LIT,KEY,1)
    t=t.replace("\n\nLighting:","\n\nHair: her hair is swept back behind both ears, leaving both ears, her jawline and her neck fully visible so every hanging piece is in clear view.\n\nLighting:",1)
    assert not re.search(r"[가-힣]",t)
    ang="정면" if star=="eye" else "45도"
    lab=f"{nat} · {grp} · {expr} · {item[0]} · {nose[0]} · {jaw[0]} · {ang} · P{N}({v})+귀 추 {nw}개/귀"+(f" · 엄니({mat[0]}) 패턴{pat}" if pat else "")+(" · 헤나" if "Henna" in deco else "")+(" · 스티커" if "Stickers" in deco else "")+f" · {title.split(' · ')[-1]} · 피어싱 합계 약 {tot}개"
    return lab,t
BOTH=HENNA+' '+STICK
