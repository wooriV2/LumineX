# -*- coding: utf-8 -*-
# 신규 영역 4종 샘플(각 2개): 우주·성운 / 용암·마그마 / 털실·펠트 / 수묵·서예 — mk_new_bundles 틀, 전 축 기본 랜덤
_src = open("mk_new_bundles.py", encoding="utf-8").read()
exec(_src[:_src.index('if __name__')])
LEAD = "body curving to follow her body's true three-dimensional shape, "
T_NEB = LEAD + "a deep cosmos of swirling luminous gas clouds and dust lanes in rich overlapping layers, thousands of tiny bright stars embedded across every curve, a few large brilliant stars with soft cross-shaped glints, thin glowing constellation lines linking the brightest stars across her torso and legs, glowing softly from within, nothing lying flat. Dense cosmic surface — {base}, {acc}, {fin}, completely opaque, NO flat printed surface anywhere"
T_LAVA = LEAD + "a rough crust of cooled black volcanic rock broken into jagged plates, with bright glowing molten lava seeping through every crack between the plates, thick lava dripping and streaming down her body in glowing rivers that pool in glowing puddles around her feet, heat shimmer rising from her skin, nothing lying flat. Dense volcanic surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_KNIT = LEAD + "knitted entirely from thick soft chunky wool yarn, every stitch clearly visible as rows of interlocking loops, ribbed and cabled panels following her curves, loose fuzzy fibres and a few dangling yarn ends, nothing lying flat. Dense knitted surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_FELT = LEAD + "made entirely of dense needle-felted wool felt, a soft fuzzy surface with visible fibres, hand-stitched seams in contrasting thread following her curves, felt appliqué shapes sewn on with small visible stitches, nothing lying flat. Dense felted surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_INK = LEAD + "brushed with thick sumi ink like a calligraphy sculpture, bold sweeping brush strokes with wet bleeding edges and soft grey ink washes, large flowing calligraphic characters sweeping around her torso and down both legs, the thickest strokes standing in glossy raised relief, nothing lying flat. Dense ink-brushed surface — {base}, {acc}, {fin}, completely opaque, NO flat printed surface anywhere"
def V(tag, desc, solid, nmw, T, base, acc, fin): return dict(tag=tag, desc=desc, solid=solid, nmw=nmw, T=T, base=base, acc=acc, fin=fin)
VS = [
 V("우주·성운 보라", "glowing violet nebula starfield", "starfield", "glowing nebula starfield", T_NEB,
   "BLAZING deep indigo-violet and magenta nebula clouds across the full torso both legs neck to ankle",
   "VIVID tiny white and gold stars and thin gold constellation lines linking the brightest stars", "softly glowing"),
 V("우주·성운 청록", "glowing cyan galaxy starfield", "starfield", "glowing galaxy starfield", T_NEB,
   "BLAZING electric cyan-blue and deep teal galaxy clouds with a bright rose-pink spiral core across the full torso both legs neck to ankle",
   "VIVID tiny white stars and thin silver-white constellation lines linking the brightest stars", "softly glowing"),
 V("용암 현무암", "cracked black basalt and molten lava", "volcanic rock", "black basalt and molten lava", T_LAVA,
   "BLAZING matte black basalt crust plates across the full torso both legs neck to ankle",
   "VIVID bright orange-red molten lava glowing in every crack, with a few white-hot yellow veins", "rough volcanic"),
 V("용암 흑요석", "cracked glossy obsidian and golden molten lava", "volcanic glass", "obsidian and molten lava", T_LAVA,
   "BLAZING glossy black obsidian crust plates across the full torso both legs neck to ankle",
   "VIVID golden-yellow molten lava glowing in every crack, with white-hot veins and drifting orange embers", "glassy volcanic"),
 V("털실 니트", "chunky hand-knitted wool", "knitted wool", "chunky wool yarn", T_KNIT,
   "BLAZING thick cream-white chunky wool knit across the full torso both legs neck to ankle",
   "VIVID bold stripes in coral-red and mustard-yellow, deep cable-knit panels and a few fuzzy pom-poms", "soft matte woolly"),
 V("펠트 공예", "needle-felted wool felt craft", "felted wool", "wool felt", T_FELT,
   "BLAZING soft mint-green wool felt across the full torso both legs neck to ankle",
   "VIVID bubblegum-pink and sunny-yellow felt appliqué flowers and dots sewn on with contrasting thread", "soft matte fuzzy"),
 V("수묵 흑백", "black sumi ink on pale rice paper", "ink-brushed paper", "black ink lacquer", T_INK,
   "BLAZING pale rice-paper white across the full torso both legs neck to ankle covered in bold black sumi ink brush strokes",
   "VIVID a few small vermilion-red seal stamps among the sweeping calligraphic characters", "wet glossy ink"),
 V("수묵 적묵금박", "red and black ink on cream rice paper with gold leaf", "ink-brushed paper", "black ink lacquer", T_INK,
   "BLAZING warm cream rice-paper white across the full torso both legs neck to ankle covered in vermilion-red and black ink brush strokes",
   "VIVID gold-leaf flecks scattered among the sweeping calligraphic characters", "wet glossy ink"),
]
def chk(t): return not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t) and "navel" not in t.lower()
rg = random.Random(20261116); rr.seed(20261116); ns2["JR"].seed(20261116)
o1 = ["# 신규 영역 샘플 8개 — 우주·성운(1,2) · 용암·마그마(3,4) · 털실·펠트(5,6) · 수묵·서예(7,8)\n", "Material Mix와 같은 기본 랜덤입니다(체형·나이·포즈·인종·배경·힐·네일·주얼리). 번호별로 정상/이상만 알려주세요. 이상이면 한 줄만요.\n"]
for i, v in enumerate(VS, 1):
    for _ in range(500):
        phys = rg.choices(BIG5, W5)[0]; age = rg.choice(AGES); pose = rg.choice(POSES); eth = rg.sample(ETH, 1)[0]
        bid, wx = BGL.pick(rg, 1); scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
        ns2["JR"].seed(rg.randrange(10**9))
        mat = HEAD.format(desc=v["desc"], solid=v["solid"]) + v["T"].format(base=v["base"], acc=v["acc"], fin=v["fin"])
        body, info = assemble(mat, v["nmw"], "part of the figure", phys, age, pose, eth)
        env = f"{scene}, bright and evenly lit, shadows soft, the whole floor and surroundings clearly visible and in focus, NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as her."
        tail = f"Background: {env} ONE woman only. Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
        t = f"Professional fashion photograph, full body shot. ONE woman standing.\n\n{body}\n\n{tail}{CAM} 8K portrait {ASP[1]} aspect ratio."
        if chk(t): break
    hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
    o1.append(f"## {i}. {v['tag']} 솔로 · 체형 {phys[0]} · 인종 {eth[0]} · {info} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko}\n\n```\n{t}\n```\n")
    print(i, len(t.split()), t.count("forty inches"))
open(O + "LumineX_New4_Sample_8.md", "w", encoding="utf-8").write("\n".join(o1))
