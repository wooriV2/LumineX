import re,random
s=open('mk_file7.py',encoding='utf-8').read()
exec(s[:s.index('CFG=[')])
TX={n:t for n,t,c in EYE}
LINER=re.compile(r"a razor-sharp black liner follows the entire shape and ends in a very long, fine point[^;]*;")
PLAIN="the outline of each eye is crisp and clean, defined only by her natural dark lashes and the edge of her lids, with no eyeshadow and no eyeliner;"
OUTS=[]
rr=random.Random(8888)
for name,nat in (("양쪽 트임 6배+큰 눈","한국"),("양쪽 트임 8배+거대한 눈","일본")):
    text=TX[name]; assert LINER.search(text); text=LINER.sub(PLAIN,text)
    for tr in range(400):
        r2=random.Random(rr.randrange(10**9))
        nw=r2.choice([8,9,10]); deco=r2.choice(["",HENNA,STICK,BOTH])
        # force nationality by retrying the base draw
        probe=random.Random(r2.getstate()[1][0]); 
        try:
            t,lab,lt,nw=base(r2,25,("tmp","brow","bri"),False,deco,nw,style0="NONE")
        except AssertionError: continue
        if not lab.startswith(nat): continue
        sj=subj(t); jaw=r2.choice(JAWS); nose=r2.choice(NOSES)
        star=f"her eyes are the star of her face (the shape, size and lenses described here override the eyes of her makeup, and she wears no eyeshadow and no eyeliner at all): {text.format(lens='coloured') if '{lens}' in text else text}"
        add=f" Her face has been surgically sculpted far beyond her natural look, and these changes override her natural features: {star}; her nose: {nose[1]}; her jawline and chin: {jaw[1]}. Every feature is exaggerated but beautiful, balanced and refined, in harmony with the rest of her face, never distorted, never grotesque."
        t=t.replace(sj,sj+add)
        mode=wchoice(r2,[("iron",35),("mix",40),("one",25)],1)[0]
        t,lab2=finish(t,mode,nw,r2,lab+f" · 귀 추 {nw}개/귀 2구멍",None)
        h=r2.choice([1,2,3])
        if h==1: t=t.replace("and above them sit","and above it sit")
        try: t,lab2=holes(t,h,lab2)
        except AssertionError: continue
        lab2=re.sub(r" · 귀 구멍 \d개","",lab2).replace(" 2구멍",f" {h}구멍")
        if re.search(r"[가-힣]",t) or "{" in t or "zero separate" in t: continue
        d=re.search(r"\b(\w+) \1\b",t)
        if d and d.group(1).lower() not in("had","that"): continue
        if re.search(r"liner|eyeshadow",t.replace("no eyeshadow and no eyeliner","")): 
            m=re.findall(r"[^.;]{0,80}(?:liner|eyeshadow)[^.;]{0,60}",t.replace("no eyeshadow and no eyeliner","")); print("LINER LEFT",m[:3]); continue
        t=re.sub(r"  +"," ",t)
        OUTS.append((f"{name} · {nat}인 · 아이섀도·아이라이너 없음 · "+lab2,t)); print(len(OUTS),len(t.split()),lab2[:80]); break
    else: raise SystemExit("fail")
o=["# LumineX — 양쪽 트임 큰 눈 수수 메이크업 (2개)\n","- 1 양쪽 트임 6배(한국), 2 양쪽 트임 8배(일본). 아이섀도·아이라이너 없음, 눈매 윤곽은 속눈썹과 눈꺼풀 선으로만 표현했습니다. 정상/이상 번호만 알려주세요.\n"]
for i,(title,p) in enumerate(OUTS,1): o.append(f"## {i}. {title}\n\n```\n{p}\n```\n")
open(OUT+'LumineX_BothCanthus_Plain_2.md','w',encoding='utf-8').write("\n".join(o))
