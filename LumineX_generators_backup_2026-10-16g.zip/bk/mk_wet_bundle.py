# -*- coding: utf-8 -*-
# 신규 영역 4종 샘플(각 2개): 우주·성운 / 용암·마그마 / 털실·펠트 / 수묵·서예 — mk_new_bundles 틀, 전 축 기본 랜덤
_src = open("mk_new_bundles.py", encoding="utf-8").read()
exec(_src[:_src.index('if __name__')])
LEAD = "body curving to follow her body's true three-dimensional shape, "
T_WET = LEAD + "a continuous glossy wet-look coating over her entire body, thick sheets and streams of liquid running down every curve in glistening rivulets, countless beads and droplets clinging to the surface and dripping from her chin, fingertips, hips and knees, razor-sharp bright specular highlights along every curve, nothing lying flat. Dense wet surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
def V(tag, desc, solid, nmw, T, base, acc, fin): return dict(tag=tag, desc=desc, solid=solid, nmw=nmw, T=T, base=base, acc=acc, fin=fin)
VS = [
 V("젖은 광택 · 브론즈 오일", "oil-drenched glistening bronze", "wet-look", "glistening wet bronze", T_WET,
   "BLAZING deep metallic bronze-gold pigment across the full torso both legs neck to ankle, drenched in thick clear body oil",
   "VIVID golden oil streaming in long slow rivulets and heavy oil droplets hanging from every curve", "mirror-wet glossy"),
 V("젖은 광택 · 샤워 크림슨", "shower-drenched glistening crimson", "wet-look", "glistening wet crimson", T_WET,
   "BLAZING saturated crimson-red pigment across the full torso both legs neck to ankle, soaked under a running shower",
   "VIVID streams of clear water cascading from above in sheets and bright round water beads clinging everywhere, with a fine mist of spray in the air", "mirror-wet glossy"),
 V("젖은 광택 · 빗속 블랙", "rain-drenched glistening jet-black", "wet-look", "glistening wet black", T_WET,
   "BLAZING deep jet-black pigment across the full torso both legs neck to ankle, soaked by pouring rain",
   "VIVID silver rain streaking down in bright lines, white highlights glittering on every water bead and rivulet, and splashes bursting around her feet", "mirror-wet glossy"),
]
def chk(t): return not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t) and "navel" not in t.lower()

import sys
sys.path.insert(0, "../master")
import mdefs as D
import mk_newmakeup as NM
G0 = face.__globals__["G"]; _orig_pm = G0.pick_makeup
NM.extend(G0)
NEWV["wetpaint"] = []
NEWV["crystalp"] = []
MODEMAP = {}
MODEKO = {"both": "머리+얼굴 젖음", "hair": "머리만 젖음", "none": "안 젖음"}
_prev_nv = person_nv
def person_nv(label, key, phys, age, pose, eth):
    if key not in ("wetpaint", "crystalp"): return _prev_nv(label, key, phys, age, pose, eth)
    v = CUR_VAR[(label, key)]; nmw = v["nmw"]; nm = "the wet paint"
    pn, pd = phys; p = f"{label}: " if label else ""
    md = MODEMAP.get(label, "none")
    hairtxt = hair() + (", soaking wet, slicked and clinging in wet strands" if md in ("hair", "both") else "")
    sheen = "water droplets beading across her skin and a wet glistening sheen" if md == "both" else "a soft sheen of natural oils"
    mat = v["mat"] if "mat" in v else HEAD.format(desc=v["desc"], solid=v["solid"]) + v["T"].format(base=v["base"], acc=v["acc"], fin=v["fin"])
    feat, seg, info = face(eth); skin = eth[1]
    hl = HEEL_ if HEELMODE[0] == "forty" else HEEL_REL
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of the same {nmw}, each with {hl}, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, made of the same {nmw} with a high polish."
    fc = f"{p}Face: her face and ears are NOT {nm} — they are real living flesh with real pores, {sheen} and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hairtxt} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    return "\n".join([body, shoe, nails, jw, fc]), info

LIQE = {"샤워": "shower", "오일": "oil", "빗속": "rain"}
LIQ = {"샤워": ("soaked under a running shower", VS[1]["acc"], "mirror-wet glossy", None),
       "오일": ("drenched in thick clear body oil", VS[0]["acc"], "mirror-wet glossy", None),
       "빗속": ("soaked by pouring rain", VS[2]["acc"], "mirror-wet glossy", "outdoor")}
COLS = {  # key: (영어 형용사, base 색 문장, 한글)
 "jet-black": ("jet-black", "BLAZING deep jet-black pigment across the full torso both legs neck to ankle", "블랙", "black"),
 "midnight-blue": ("midnight-blue", "BLAZING deep midnight-blue pigment across the full torso both legs neck to ankle", "미드나이트 블루", "navy"),
 "deep emerald": ("deep emerald", "BLAZING deep emerald-green pigment across the full torso both legs neck to ankle", "딥 에메랄드", "emerald"),
 "burgundy": ("burgundy", "BLAZING deep burgundy-wine pigment across the full torso both legs neck to ankle", "버건디", "burgundy"),
 "cobalt": ("cobalt", "BLAZING cobalt-blue pigment across the full torso both legs neck to ankle", "코발트", "cobalt"),
 "crimson": ("crimson", "BLAZING saturated crimson-red pigment across the full torso both legs neck to ankle", "크림슨", "crimson"),
 "bronze": ("bronze", "BLAZING deep metallic bronze-gold pigment across the full torso both legs neck to ankle", "브론즈", "bronze"),
}
def solid_v(key, liq):
    adj, base, ko, nmc = COLS[key]; how, acc, fin, _ = LIQ[liq]
    return V(f"젖은 {ko}", f"{LIQE[liq]}-drenched glistening {adj}", "wet-look", f"glistening wet {nmc}", T_WET, f"{base}, {how}", acc, fin)
CRY = {"rose": ("ROSE QUARTZ PINK", "SOFT GOLD", "rose quartz crystal", "로즈쿼츠"), "smoky": ("SMOKY GREY", "CHARCOAL", "smoky quartz crystal", "스모키쿼츠")}
def crystal_v(key):
    c1, c2, sh, ko = CRY[key]
    mat = (f"full body {sh} clusters growing directly out of her own skin covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, every crystal point erupting outward from beneath the surface of her living skin in true three-dimensional relief, each facet catching its own individual glint and casting its own small hard shadow onto the skin and onto neighbouring crystals, nothing lying flat. Dense overlapping clusters — BLAZING {c1} crystal points erupting across the full torso both legs neck to ankle, VIVID {c2} mineral veins and undertone glinting through the thinnest points filling every remaining gap with real depth and texture, each facet sharply faceted and distinct, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    return dict(tag=f"석영 {ko}", nmw=sh, mat=mat, desc=sh, solid="crystal")
# (이름, 인원, 액체, [(종류, 키)])  종류: solid=젖은 단색, bodypaint/irezumi/uvneon=일반(젖지 않은) 바디페인팅

import json, collections
from retitle import agg, mk_clean, pose_ko
# ── B_INS / SEAT (극단 체형) ──
_g = open("../master/gen_extreme.py", encoding="utf-8").read()
exec(_g[_g.index("B_INS = ("):_g.index("PAINT_S")])
exec(_g[_g.index("SEAT = ["):_g.index("for _p in SEAT")])
EXTREME = ("USSBBW", "hourglass SSBBW")
BODIES22 = [b for b in D.BODIES if not b[0].startswith("pregnant")]
assert len(BODIES22) == 22
def phys_of(b, solo):
    if b[0] in EXTREME:
        return (b[0], b[1] + "; " + B_INS.format(edge=", her body so wide that her hips nearly touch the left and right edges of the frame" if solo else ""))
    return (b[0], b[1])
# ── 액체 표 (시험을 통과한 문구를 그대로 사용) ──
_s10 = open("mk_wet10.py", encoding="utf-8").read(); exec(_s10[_s10.index("VD = ["):_s10.index("G0 = face.__globals__")])
_s7 = open("mk_wet7.py", encoding="utf-8").read(); _seg = _s7[_s7.index(' V("C1'):]; _seg = _seg[:_seg.index("\n]")]; exec("P3 = [" + _seg + "\n]")
def _lq(ko, v, bg):
    how = v["base"].split("neck to ankle, ", 1)[1]
    return dict(ko=ko, adj=v["desc"].split(" glistening ")[0], how=how, acc=v["acc"], fin=v["fin"], bg=bg)
WINTER = ("겨울 눈 광장", "겨울 설원", "얼음 동굴")
LQ = {"rain": _lq("빗속", VS[2], "rain"), "shower": _lq("샤워", VS[1], None), "oil": _lq("오일", VS[0], None),
      "pool": _lq("풀사이드", P3[0], ("옥상 테라스", "야외 테라스", "여름 해변", "하얀 안뜰")), "splash": _lq("물 튀김", P3[1], "outdoor"),
      "sea": _lq("파도 물보라", P3[2], ("바닷가 산책로", "여름 해변", "해안 절벽", "항구 등대")),
      "champagne": _lq("샴페인", VD[0], None), "fog": _lq("안개·이슬", VD[1], ("숲길", "대나무 숲", "열대 정글 보드워크", "폭포 전망대", "라벤더 들판", "봄 정원 테라스")),
      "ice": _lq("얼음 녹은 물", VD[2], WINTER), "milk": _lq("우유", VD[3], None), "honey": _lq("꿀", VD[4], None)}
BASE3 = ["rain", "shower", "oil"]; OTHER8 = ["pool", "splash", "sea", "champagne", "fog", "ice", "milk", "honey"]
COLORS7 = ["jet-black", "midnight-blue", "deep emerald", "burgundy", "cobalt", "crimson", "bronze"]
DARK5 = ["jet-black", "midnight-blue", "deep emerald", "burgundy", "cobalt"]
def wet_v(lk, ck):
    adj, base, ko, nmc = COLS[ck]; L = LQ[lk]
    return V(f"{L['ko']} {ko}", f"{L['adj']} glistening {adj}", "wet-look", f"glistening wet {nmc}", T_WET, f"{base}, {L['how']}", L["acc"], L["fin"])
def bg_ok(lk, bid, wx):
    rule = LQ[lk]["bg"]; name = BGL.BG[bid][2]; out = BGL.BG[bid][4]
    if lk == "rain": return bool(out) and name not in WINTER and (wx is not None and wx[0] in ("흐린 낮", "비 갠 뒤"))
    if rule is None: return True
    if rule == "outdoor": return bool(out)
    return name in rule
STY = ['코갸루', '마이코', '경극', '혼례(연지곤지)', '둔황 비천풍', '글래스 스킨', '강남언니', '인스타글램', '구풍', '홍콩풍', '아마갸루', '걸크러시', '지뢰계', '야마바', '만바', '반바', '아게하',
       '히메갸루', '오네에갸루', '로리타 갸루', '야미카와', '데코라', '웨이쉰', '브리티시 모드']
G0.pick_makeup = (lambda _r, style=None: _orig_pm(_r, style=_r.choice(STY)))
MODES = ["both", "hair", "none"]; MODEKO = {"both": "머리+얼굴 젖음", "hair": "머리만 젖음", "none": "안 젖음"}
WETHAIR = ", soaking wet, slicked and clinging in wet strands"; WETSHEEN = "water droplets beading across her skin and a wet glistening sheen"
PART = ["irezumi", "bodypaint", "crystal", "jade", "porcelain", "bronze", "lacquer", "amber", "coral", "wood", "stone"]
POOLP = {"bodypaint": BP, "irezumi": IR}
_hair0 = hair
SERIES = "Wet"; CAT = "🏺 Living Artifact · Wet Look Formula"; PREF = "la_wet_"
NAMES = {1: "solo", 2: "duo", 3: "trio", 4: "quartet", 5: "quintet"}; KOCNT = {1: "솔로", 2: "듀오", 3: "트리오", 4: "쿼르텟", 5: "퀸텟"}
rg = random.Random(20261210); rr.seed(20261210); ns2["JR"].seed(20261210)
SEEN = set()

def solo(lk, ck, mode):
    for attempt in range(800):
        b = rg.choice(BODIES22); phys = phys_of(b, True); age = rg.choice(AGES); eth = rg.sample(ETH, 1)[0]
        pose = rg.choice(SEAT) if (b[0] in EXTREME and rg.random() < 0.7) else rg.choice(POSES)
        bid, wx = BGL.pick(rg, 1)
        if not bg_ok(lk, bid, wx): continue
        scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
        ns2["JR"].seed(rg.randrange(10**9))
        v = wet_v(lk, ck)
        mat = HEAD.format(desc=v["desc"], solid=v["solid"]) + v["T"].format(base=v["base"], acc=v["acc"], fin=v["fin"])
        g = globals(); g["hair"] = (lambda: _hair0() + WETHAIR) if mode in ("hair", "both") else _hair0
        body, info = assemble(mat, v["nmw"], "part of the figure", phys, age, pose, eth)
        g["hair"] = _hair0
        if mode == "both": body = body.replace("a soft sheen of natural oils", WETSHEEN, 1)
        env = f"{scene}, bright and evenly lit, shadows soft, the whole floor and surroundings clearly visible and in focus, NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as her."
        tail = f"Background: {env} ONE woman only. Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
        t = f"Professional fashion photograph, full body shot. ONE woman standing.\n\n{body}\n\n{tail}{CAM} 8K portrait {ASP[1]} aspect ratio."
        if not chk(t) or t in SEEN: continue
        if t.count("forty inches") != (1 if HEELMODE[0] == "forty" else 0): continue
        SEEN.add(t)
        mk = mk_clean(info.replace("메이크업 ", "", 1).split(" · ")[0])
        return dict(t=t, n=1, bodies=[b[0]], eths=[eth[0]], poses=[pose], bid=bid, wx=wx, heel=HEELMODE[0], mk=[mk],
                    mats=[f"{LQ[lk]['ko']} {COLS[ck][2]}"], liqs=[lk], cols=[ck], modes=[mode], partners=[], kind="solid", asp=ASP[1])
    raise SystemExit("fail solo")

def group(n, lk, wet_cols, partners, modes):
    """wet_cols: 젖은 사람 색 목록, partners: 파트너 종류 목록(마른 재질). 순서는 섞는다."""
    for attempt in range(800):
        order = [("w", c) for c in wet_cols] + [("p", p) for p in partners]
        rg.shuffle(order)
        CUR_VAR.clear(); MODEMAP.clear(); picks = []; kinds = []; mats = []; wi = 0
        for idx, (typ, key) in enumerate(order):
            lab = f"#{idx+1}"
            if typ == "w":
                v = wet_v(lk, key); CUR_VAR[(lab, "wetpaint")] = v; picks.append(v); kinds.append("wetpaint"); MODEMAP[lab] = modes[wi]; wi += 1
                mats.append(f"{LQ[lk]['ko']} {COLS[key][2]}")
            elif key == "crystal":
                v = crystal_v(rg.choice(list(CRY))); CUR_VAR[(lab, "crystalp")] = v; picks.append(v); kinds.append("crystalp"); mats.append(v["tag"])
            elif key in ("jade", "porcelain", "bronze", "lacquer", "amber", "coral"):
                v = rg.choice(NEWV[key]); CUR_VAR[(lab, key)] = v; picks.append(v); kinds.append(key); mats.append(f"{KO[key]} {v[7]}")
            elif key == "wood":
                p_ = rg.choice(WOODS); picks.append(p_); kinds.append(key); mats.append("목재 " + p_[0])
            elif key == "stone":
                p_ = rg.choice(STONES); picks.append(p_); kinds.append(key); mats.append("석재 " + p_[0])
            else:
                picks.append(rg.choice(POOLP[key])); kinds.append(key); mats.append(KO[key])
        bs = []
        while len(bs) < n:
            c = rg.choice(BODIES22)
            if c[0] not in [x[0] for x in bs]: bs.append(c)
        physs = [phys_of(b, False) for b in bs]
        ages = [rg.choice(AGES) for _ in range(n)]; poses = [rg.choice(POSES) for _ in range(n)]; eths = rg.sample(ETH, n)
        bid, wx = BGL.pick(rg, n)
        if not bg_ok(lk, bid, wx): continue
        scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty"
        ns2["JR"].seed(rg.randrange(10**9))
        t, infos = build3(list(kinds), picks, physs, ages, poses, eths, scene)
        t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as any of them.", 1)
        if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t) or "navel" in t.lower() or t in SEEN: continue
        SEEN.add(t)
        asp = re.search(r"(\d+:\d+) aspect ratio", t); asp = asp.group(1) if asp else None
        mks = [mk_clean(i.replace("메이크업 ", "", 1).split(" · ")[0]) for i in infos]
        wmodes = [MODEMAP[f"#{i+1}"] for i, (typ, _) in enumerate(order) if typ == "w"]
        return dict(t=t, n=n, bodies=[b[0] for b in bs], eths=[e[0] for e in eths], poses=poses, bid=bid, wx=wx, heel=HEELMODE[0], mk=mks, mats=mats,
                    liqs=[lk] * len(wet_cols), cols=list(wet_cols), modes=wmodes, partners=list(partners), kind=("mixed" if partners else "solid"), asp=asp)
    raise SystemExit("fail group")

def make_title(r, k):
    n = r["n"]
    body = r["bodies"][0] if n == 1 else agg(r["bodies"])
    if n == 1: mat = r["mats"][0]
    else:
        wet = [m for m, kk in zip(r["mats"], range(len(r["mats"]))) if m.split(" ")[0] in {LQ[x]["ko"] for x in LQ}]
        dry = [m for m in r["mats"] if m not in wet]
        liq = LQ[r["liqs"][0]]["ko"]; cols = [m[len(liq) + 1:] for m in wet]
        mat = f"{liq} " + "+".join(cols) + (" + " + agg(dry) if dry else "")
    poses = pose_ko(r["poses"][0]) if n == 1 else ""
    bg = BGL.BG[r["bid"]][2]; mk = agg(r["mk"])
    return " · ".join(x for x in [f"{SERIES} {KOCNT[n]} #{k:03d}", body, mat, poses, bg, mk] if x)

# ── 계획 ──
solo_plan = []
bag = []
for lk in BASE3: bag += [(lk, COLORS7[i % 7]) for i in range(20)]
for i, lk in enumerate(OTHER8):
    cnt = 8 if i < 4 else 7
    bag += [(lk, DARK5[j % 5]) for j in range(cnt)]
rg.shuffle(bag); assert len(bag) == 120
group_plan = {2: (20, 20), 3: (20, 20), 4: (10, 10), 5: (10, 10)}
out = []
def add(r, n, k):
    key = f"{PREF}{NAMES[n]}_{k:03d}"
    meta = {"group_size": n, "aspect_ratio": r["asp"], "format": "wetlook", "kind": r["kind"], "liquids": r["liqs"], "colors": r["cols"], "partners": r["partners"], "hair_modes": r["modes"],
            "physiques": r["bodies"], "ethnicity": r["eths"], "poses": r["poses"], "background": r["bid"], "weather": r["wx"][0] if r["wx"] else None, "heel_mode": r["heel"], "jewelry": True}
    out.append({"key": key, "category": CAT, "title": make_title(r, k), "prompt": r["t"], "meta": meta})
modes_cycle = []
def next_mode():
    global modes_cycle
    if not modes_cycle: modes_cycle = MODES[:]; rg.shuffle(modes_cycle)
    return modes_cycle.pop()
for k, (lk, ck) in enumerate(bag, 1): add(solo(lk, ck, next_mode()), 1, k)
for n, (ns_, nm_) in group_plan.items():
    items = []
    for j in range(ns_ + nm_):
        mixed = (j % 2 == 1)
        if not mixed:
            lk = rg.choice(BASE3); cols = rg.sample(COLORS7, n)
            items.append(group(n, lk, cols, [], [next_mode() for _ in range(n)]))
        else:
            w = rg.randint(1, n - 1); parts = rg.sample(PART, n - w)
            pool = [c for c in COLORS7 if not (c == "bronze" and "bronze" in parts)]
            items.append(group(n, "oil", rg.sample(pool, w), parts, [next_mode() for _ in range(w)]))
    for k, r in enumerate(items, 1): add(r, n, k)
assert len(out) == 240 and len({p["key"] for p in out}) == 240
json.dump(out, open(O + "la_wet_240_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(out), collections.Counter(p["meta"]["group_size"] for p in out))
