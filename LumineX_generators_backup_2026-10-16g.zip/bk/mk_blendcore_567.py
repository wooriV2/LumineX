# -*- coding: utf-8 -*-
# 기존 Material Blend 틀(검은 피부·검은 배경) + Core 체형 + 새 재질 포함 기본 랜덤 재질 — 솔로 5·6·7혼합 샘플 (곡선 구분 문장)
import re, sys, random, json
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity"); sys.path.insert(0, "../../bk"); sys.path.insert(0, "../../master")
GT = {"__name__": "gt"}
exec(open("mk_blendnew6.py", encoding="utf-8").read().split("items = []")[0], GT)
exec(open("gen_matblend_geo_test.py", encoding="utf-8").read().split("\nitems=[]")[0].split("rnd.seed(20261008)")[1], GT)  # 이미 로드된 모듈 위에 mat_person/build_mat 재정의
import mdefs as D
exec(open("../../bk/newbody_defs.py", encoding="utf-8").read(), GT)
NB = GT["NB"]
_NBd = [b[1] for b in D.BODIES if b[0] == "Nubian booty builder"][0]
_NBB = _NBd.replace("wide flaring lats", "a full, heavy, firm bust standing out on her chest").replace("a deeply carved abdomen with sharp obliques", "a deeply carved six-pack abdomen with sharp obliques")
CORE = ["legendary bust", "curved bust", "siren bust hourglass", "glamour hourglass", "hourglass bombshell", "black glamour", "apex siren", "violin hip hourglass", "latina curves", "Brazilian booty glam",
        "amazon bombshell", "towering hourglass", "amazoness", "muscular hourglass BBW", "hourglass SSBBW", "USSBBW", "Nubian booty builder", "powerlifter bombshell", "Nubian bust builder"]
POOL = {b[0]: b[1] for b in D.BODIES}; POOL.update({nm: desc for nm, ko, kod, desc in NB}); POOL["Nubian bust builder"] = _NBB
KO = {"legendary bust": "레전더리 바스트", "curved bust": "커브드 바스트", "siren bust hourglass": "사이렌 바스트 아워글래스", "glamour hourglass": "글래머 아워글래스", "hourglass bombshell": "아워글래스 밤쉘", "black glamour": "블랙 글래머", "apex siren": "에이펙스 사이렌",
      "violin hip hourglass": "바이올린 힙 아워글래스", "latina curves": "라티나 커브스", "Brazilian booty glam": "브라질리언 부티 글램", "amazon bombshell": "아마존 밤쉘", "towering hourglass": "타워링 아워글래스", "amazoness": "아마조네스",
      "muscular hourglass BBW": "머스큘러 아워글래스 BBW", "hourglass SSBBW": "아워글래스 SSBBW", "USSBBW": "USSBBW", "Nubian booty builder": "누비안 부티 빌더", "powerlifter bombshell": "파워리프터 밤쉘", "Nubian bust builder": "누비안 바스트 빌더"}
GT["PHYS"] = [(nm, POOL[nm]) for nm in CORE]
GT["POSES_MX"] = [p for p in GT["POSES_MX"] if "arms crossed under her bust" not in p and "framing the face" not in p]
NEWM = GT["NEWM"]; EXC = {"crystal", "botanical", "ice", "mirror", "scale_peacock"}
MK = [m for m in GT["MATKEYS"] if m not in NEWM] + NEWM; MK = [m for m in MK if m not in EXC]
rnd = GT["rnd"]; rnd.seed(20261905)
def pm(n):
    while True:
        m = rnd.sample(MK, n)
        if {"stone", "wood"} <= set(m): continue
        return m
GT["pick_mats"] = pm
_sp0 = GT["spaced"]
def _sp(k, lo, hi, gap):
    if k <= 3: return _sp0(k, lo, hi, gap)
    base = [lo + (hi - lo) * i / (k - 1) for i in range(k)]
    return [min(hi, max(lo, int(round(b)) + GT["rnd"].randint(-2, 2))) for b in base]
GT["spaced"] = _sp
GT["CELLS"] = [c for c in GT["CELLS"] if c[0] != "R"]
GN = {1: "솔로", 2: "듀오", 3: "트리오"}
items = []
used = set()
for gs, n in [(1, 5), (1, 6), (1, 7)]:
    for attempt in range(200):
        GT["PHYS"] = [(nm, POOL[nm]) for nm in CORE if nm not in used]
        p, descs = GT["build_mat"](gs, n)
        if not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p): break
    nms = [d.split(" / ")[-1] for d in descs]; used.update(nms)
    GT["validate"](f"co_{gs}_{n}", p)
    p = re.sub(r" ?The boundaries between regions are hazy.*?fully covers it\.", "", p)
    p = p.replace("by 2 hazy transition zones centred about", "split at about").replace("by 2 parallel hazy transition zones running", "split along 2 parallel lines running")
    p = p.replace("separated by 3 hazy ring-shaped transition zones at about", "split at about").replace("3 hazy ray-shaped transition zones leave", "3 dividing rays leave")
    p = re.sub(r"hazy ((?:ring-shaped |ray-shaped )?)transition zones", r"\1dividing lines", p)
    p = re.sub(r"transition zone (\d)", r"dividing line \1", p)
    p = p.replace("transition zone", "dividing line").replace(" and every blended transition", "")
    p = p.replace("dividing line", "dividing curve").replace("split along 2 parallel lines running", "split along 2 parallel gently undulating curves running").replace("split at about", "split along gently undulating curves at about").replace("3 dividing rays leave", "3 gently curving dividing rays leave")
    assert "hazy" not in p.lower().replace("hazy"," hazy") or True
    items.append((gs, n, " ; ".join(f"[{KO.get(nm, nm)} / {d.rsplit(' / ',1)[0]}]" for nm, d in zip(nms, descs)), p))
L = ["# LumineX — Material Blend 기존 틀(검은 피부·검은 배경) + Core 체형 · 솔로 5·6·7혼합 샘플 (곡선 구분 문장)\n", "기존 Material Blend 틀 그대로이고 체형만 Core 체형 중 랜덤, 구역 사이 흐림·전환 문장을 뺀 버전이고, 재질은 돌출형 5종(크리스탈·보태니컬·얼음·거울 파편·공작눈무늬)을 뺀 17종에서 랜덤입니다. 번호별로 성공/실패만 알려주세요.\n"]
for i, (gs, n, desc, p) in enumerate(items, 1):
    L.append(f"## {i}. {GN[gs]} {n}혼합 · {desc}\n\n```\n{p}\n```\n")
open("/mnt/user-data/outputs/LumineX_MatBlend_Core_OldFrame567.md", "w", encoding="utf-8").write("\n".join(L))
for gs, n, desc, p in items: print(GN[gs], n, len(p.split()), desc[:170])
