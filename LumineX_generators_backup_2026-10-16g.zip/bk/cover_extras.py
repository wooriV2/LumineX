import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
SAFE=" sitting in real, calm, healthy skin — no redness, no swelling, no irritation — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes."
ON=["zero","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen"]
TN=["","","twenty","thirty","forty","fifty","sixty","seventy","eighty","ninety"]
def w(n):
    if n<20: return ON[n]
    if n<100: return TN[n//10]+("-"+ON[n%10] if n%10 else "")
    return ON[n//100]+" hundred"+(" and "+w(n%100) if n%100 else "")
CAP=dict(sep=3,nos=8,bri=4,brow=20,ul=10,ll=16,chin=10,ear=60,fh=20,tmp=20,chk=32)  # sum 203
def counts(N):
    f=N/203.0; c={}
    for k,v in CAP.items():
        n=max(1,round(v*f))
        if k in("nos","brow","ear","tmp","chk") and n%2: n+=1
        c[k]=min(v,n)
    return c
def ear_txt(n):
    if n<=4: return f"{w(n)} pieces: a big hoop in the lobe"+(" and smaller rings and studs up the rim" if n>1 else "")
    a,b,c=max(1,round(n*.2)),max(1,round(n*.4)),max(1,round(n*.25)); d=max(0,n-a-b-c)
    return f"{w(n)} pieces: {w(a)} graduated hoops down the lobe, {w(b)} rings and studs along the helix rim, {w(c)} studs and small bars across the upper cartilage"+(f" and {w(d)} pieces in the conch and tragus" if d else "")
def pl(n,s): return f"{w(n)} {s}"+("s" if n>1 else "")
def para(N,metal,gems,deco_note):
    c=counts(N); seg=[]
    seg.append(("a single large " if c["sep"]==1 else f"{w(c['sep'])} separate ")+"septum ring"+("" if c["sep"]==1 else "s")+" of different sizes and shapes (round, triangle, square) through the thin soft wall between the nostrils, in a short stack that ends above the upper lip")
    h=c["nos"]//2; seg.append(f"{pl(h,'small ring')} wrapping snugly around each nostril wing")
    seg.append(f"{pl(c['bri'],'straight bar')} across the bridge of the nose, stacked from just below the inner ends of the brows (well clear of the eyes) down to the middle of the nose, each with a gem cap at both ends")
    h=c["brow"]//2; seg.append(f"{pl(h,'small bar or ring')} through each eyebrow, all on the brow bone above the eyes and never on the eyelids")
    seg.append(f"{pl(c['ul'],'small hoop or stud')} along the edge of the upper lip")
    seg.append(f"{pl(c['ll'],'small hoop or stud')} across the lower lip's edge")
    seg.append(f"{pl(c['chin'],'small ring or stud')} on the chin")
    h=c["ear"]//2; seg.append(f"on each ear {ear_txt(h)}, the biggest hoops hanging clear of the neck down to the shoulders")
    seg.append(f"{pl(c['fh'],'small stud')} across the lower half of the forehead just above the brows in even rows, leaving the upper forehead free")
    h=c["tmp"]//2; seg.append(f"{pl(h,'small stud')} on each temple bone, well clear of the eyes")
    h=c["chk"]//2; seg.append(f"{pl(h,'small stud')} along each cheekbone, well clear of the eyes")
    tot=sum(c.values())
    dens=("The piercings are packed so densely that the rows touch and overlap, leaving only hairline gaps of bare skin between them, until the face reads as a single armour of metal; the eyes and eyelids stay clear. " if N>=100 else "The pieces are spread over the whole face in clear rows so every one reads individually, with bare skin between them; the eyes and eyelids stay clear. ")
    return (f"Piercings: A face fully covered with real piercings, about {w(N)} in total, spread over every area so that no area is empty: "+"; ".join(seg)+". The left and right sides are balanced and mirrored. "+dens+deco_note+f" All jewelry is real {metal} set with {gems},"+SAFE),tot
HENNA="Henna: fine metallic gold henna mehndi line patterns of vines and dots are painted across the upper forehead near the hairline only, above the forehead studs, well clear of the eyes and brows."
STICK="Stickers: five tiny glow-in-the-dark heart and star stickers are scattered flat on the skin of the lower cheeks and the jawline below the cheekbone studs, clear of the piercings, the eyes and the lips."
JEW={50:"seven to ten pieces, heavily stacked",100:"well over ten pieces, an extreme maximalist stack",150:"well over ten pieces, an extreme maximalist stack",200:"well over ten pieces, an extreme maximalist stack"}
NA=[("한국","20대","섹시한"),("일본","아이돌","도도한"),("중국","20대","고혹적인"),("한국","아이돌","군림하는"),("일본","30대","카리스마 있는"),("중국","30대","냉혹한"),("한국","20대","발랄한"),("일본","20대","몽환적인")]
o=["# LumineX — 얼굴 전체 채우기 P50·P100·P150·P200 × 2 (주얼리·렌즈·헤나/스티커 포함, 8개)\n","- 한도 반영: 코 사이 최대 3개(윗입술 위에서 끝나는 짧은 스택), 귀 한쪽 최대 30개, 나머지 부위는 1차 최대치 비율로 축소(총 합계 약 203개 = P200).","- A = 화려 다색 + 헤나(윗 이마) + 렌즈 + 목걸이·헤어 장식, B = 수수 단색 + 스티커(아래 볼·턱선) + 렌즈 + 목걸이·헤어 장식. 이마 피어싱은 아래쪽 반만 두고 헤나 자리를 비움. 콧볼은 감싸는 훅. 메이크업 없음.","- 정상/이상(+ 렌즈·헤나·스티커가 보이는지)만 번호로 알려주세요.\n"]
k=0
for N in (50,100,150,200):
    for tag in ("A","B"):
        nat,grp,ex=NA[k]; k+=1
        for tr in range(60):
            try: t,title,meta=G.make(random.Random(47000+k*100+tr),nat,grp,ex,style="NONE",slots=["pierce","lens"],pier_level="P150" if N>=100 else "P50"); break
            except AssertionError: continue
        else: raise SystemExit("fail")
        A=(tag=="A")
        metal,gems=(("mixed gold, silver and rose gold","glossy multicoloured enamel and rainbow gemstones") if A else ("yellow gold","clear diamonds, a simple one-colour palette"))
        pp=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
        new,tot=para(N,metal,gems,HENNA if A else STICK)
        t=re.sub(r'\n\nJewelry:[^\n]*','',t.replace(pp,new))
        jm="multicoloured" if A else "gold"
        jew=f"\n\nJewelry: besides the piercings she wears {JEW[N]} of {jm} necklaces and chains resting on her neck and collarbones, and {JEW[N]} of {jm} hair ornaments set in her hair, all of it real, without covering her eyes, her face or her piercings."
        t=t.replace("\n\nLighting:",jew+"\n\nLighting:",1)
        assert not re.search(r"[가-힣]",t)
        o.append(f"## P{N}-{tag} ({'화려 다색·헤나' if A else '수수 단색·스티커'}) — {title} · 합계 약 {tot}개\n\n```\n{t}\n```\n"); print(N,tag,tot,len(t.split()))
open('/mnt/user-data/outputs/LumineX_FaceCover_Extras_P50to200_8.md','w',encoding='utf-8').write("\n".join(o))
