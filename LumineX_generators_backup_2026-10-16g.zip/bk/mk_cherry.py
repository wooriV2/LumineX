import re,random
src=open('random_mix5_lib.py').read(); ns={}; exec(compile(src,'lib','exec'),ns)
G=ns['G']; build=ns['build']; OUT=ns['OUT']
FACEPAINT={"마이코","경극","혼례(연지곤지)","둔황 비천풍"}
ALLOW=[x for x in G.STYLES if x not in FACEPAINT]
def lipdesc(fn,i):
    b=re.findall(r"```\n(.*?)\n```",open(OUT+fn,encoding='utf-8').read(),re.S)[i]
    sj=[p for p in b.split("\n\n") if p.startswith("Subject:")][0]
    return re.search(r"Her lips are the star of her face: she has (.*?)\. Her eyes are large",sj,re.S).group(1)
C0=lipdesc('LumineX_AnimeEye_Lips45_4.md',2)
C1=("'cherry lips' in a slightly stronger version: the fullness concentrated in the centre of the upper and lower lips as two plump, round, cherry-like pads, only a little fuller and rounder than natural full lips, the whole mouth staying small and neat in size with the corners left slim and untouched, glossy cherry-red with a small bright white highlight on the top of each pad, youthful, sweet, perfectly symmetrical, never huge, never duck-like, never smudged past the lip line")
C2=("'cherry lips' with a clearly rounder, puffier cherry shape: the fullness concentrated in the centre of the upper and lower lips as two plump, round, cherry-like pads that are clearly puffier than natural lips, yet the mouth as a whole stays small and compact, no taller than a finger's width and with the corners left slim and untouched, glossy cherry-red with a small bright white highlight on the top of each pad, youthful, sweet, perfectly symmetrical, never huge, never duck-like, never smudged past the lip line")
rr=random.Random(77)
o=["# LumineX — 체리 립 크기 재조정 2단계 (45도 · 기본 랜덤 메이크업 · 귀 추 2구멍)\n","- +1이 너무 커서 입 전체는 작고 단정하게 두고 체리 모양의 둥글고 도톰함만 키움. 1: 채택 때 체리 립보다 살짝 강하게, 2: 동그랗고 더 통통하게(입은 작게). 나머지 구성은 시험 6개 때와 동일.","- 정상/이상(+ 크기가 적당한지)만 번호로 알려주세요.\n"]
for k,(name,t) in enumerate([("체리 립 +0.5",C1),("체리 립 +1(입은 작게)",C2)],1):
    sty=rr.choice(ALLOW)
    lab,txt=build(k,9100+k*29,"일본","아이돌","귀여운","lip",(name,t),25,9,"귀여움","",None,(),sty,True)
    o.append(f"## {k}. 메이크업 {sty} · {lab}\n\n```\n{txt}\n```\n"); print(k,sty,lab[:100])
open(OUT+'LumineX_CherryLips_Resize_2.md','w',encoding='utf-8').write("\n".join(o))
