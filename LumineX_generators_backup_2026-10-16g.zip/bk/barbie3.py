import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
HEAD="Professional fashion photograph, close-up beauty portrait. ONE woman, facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp. Mid 20s."
def subj(hair,eye,mk):
    return ("Subject: A real photograph of a strikingly beautiful adult Western woman, mid 20s, with the face of a living Barbie doll pushed to its extreme — flawless, poreless porcelain-smooth skin with a soft rosy blush high on the apple cheeks, "+hair+". Her eyes are gigantic: perfectly round, very wide-set, extra-large doll eyes with a huge visible iris, "+eye+", both eyes exactly the same, fully opaque and solidly saturated, with a darker limbal ring and a round natural pupil, bright real catchlights and genuine depth, framed by extremely long, thick, dramatically curled false lashes top and bottom and high, softly arched eyebrows. Her lips are extremely plump: huge, round, voluptuous, high-volume lips in glossy "+mk+", projecting visibly forward from her face, with a very pronounced cupid's bow and a full, pillowy lower lip, softly closed in a sweet faint smile. A tiny, perfectly straight nose with a delicate upturned tip, high rounded apple cheeks, and a small soft pointed chin. Real skin fine grain and a soft sheen of natural oils on her face, ears and neck, individual hair strands catching the light — a photograph of a real woman's face, not an illustration, not a render. Every enhanced feature is exaggerated but beautiful, balanced and refined, in harmony with the rest of her face, never distorted, never grotesque; it reads as the most perfect, most doll-like adult woman's face imaginable.")
V=[("금발 · 파란 눈 · 핑크 글로시 립","long, voluminous, glossy platinum-blonde waves with a soft fringe falling past her shoulders","vivid sky-blue doll-eye contact lenses that make the iris look enormous","baby-pink gloss"),
   ("갈색 머리 · 보라빛 파란 눈 · 코랄 립","long, glossy chestnut-brown curls past her shoulders","violet-blue doll-eye contact lenses that make the iris look enormous","coral-pink gloss"),
   ("핑크 머리 · 연한 초록 눈 · 로즈 립","long, glossy pastel-pink wavy hair past her shoulders","pale mint-green doll-eye contact lenses that make the iris look enormous","rose-red gloss")]
o=["# LumineX — 서양인 바비 인형 얼굴 3종 (극단 눈·입술) × 피어싱 P5\n","- 눈: 지름이 큰 동그란 인형 눈 + 큰 홍채 렌즈 + 속눈썹, 입술: 앞으로 튀어나온 초대형 도톰 입술. 균형 잡힌 예쁜 극단(어글리 방지 문장 포함). 피어싱은 기존 P5 그대로.","- 정상/이상(+ 눈·입술이 극단적으로 나오는지)만 번호로 알려주세요.\n"]
for i,(lab,hair,eye,mk) in enumerate(V,1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(77000+i*100+tr),"한국","20대","도도한",style="NONE",slots=["pierce"],pier_level="P5"); break
        except AssertionError: continue
    else: raise SystemExit(i)
    ps=t.split("\n\n")
    rest=[p for p in ps if p.startswith(("Piercings:","Piercing depth:","Lighting:"))]
    assert len(rest)==3
    new="\n\n".join([HEAD,subj(hair,eye,mk)]+rest)
    assert not re.search(r"[가-힣]",new)
    o.append(f"## {i}. {lab} — 서양인 · 20대 · 바비 인형 · 글로시 립 메이크업 · 피어싱 P5\n\n```\n{new}\n```\n")
open('/mnt/user-data/outputs/LumineX_BarbieWestern_3.md','w',encoding='utf-8').write("\n".join(o)); print("ok", len(new.split()))
