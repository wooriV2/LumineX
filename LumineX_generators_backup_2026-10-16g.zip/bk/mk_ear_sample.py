import re,random
src=open('gen_facesculpt.py',encoding='utf-8').read(); src=src[:src.index("rr=random.Random(20261013)")]
ns={}; A='''        minimal=True; deco=rr.choice(["",HENNA,HENNA])'''
assert A in src
src=src.replace(A,'''        zero=("ul","ll","chin","tmp","bri"); deco=rr.choice(["",HENNA,STICK,BOTH])''')
exec(compile(src,'gf','exec'),ns)
lib=ns['ns']; HW2=lib['HW2']; COL2=lib['COL2']; w=lib['w']
exec(open('ear_styles.py',encoding='utf-8').read())
TEXT={}
for n,t,c in ns['EYEITEMS']+ns['CAN']+ns['LIPITEMS']: TEXT[n]=t
ARCHF={n:f for n,f,c in ns['ARCH']}
SPEC=[("eye","사이렌 눈 +1","mix"),("lip","러시안 립 초과장","one"),("eye","애교살 초극대","earring"),("lip","러시안 립 극한","earring"),("eye","후디드 아이 +1","combo"),("lip","체리 립","mix")]
o=["# LumineX — 귀 스타일 변주 확인 샘플 6개 (혼합 금속 추 · 단일 금속 추 · 대형 귀걸이 · 귀걸이+추)\n",
"- 얼굴 주인공(눈/립)은 기존 Face Sculpt와 같고(립 주인공은 입술·턱만 비우고 코·눈썹·이마·광대에 살짝 피어싱), 귀 쪽이 바뀝니다. 귓볼은 무게로 살짝만 자연스럽게 처지고, 사슬·추·귀걸이는 쇄골 높이를 넘지 않고 공중에 매달리게 했습니다. 1·6 혼합 금속 추(납·주석·금·은·청동·구리·황동·철을 추마다 섞음), 2 단일 금속 추, 3·4 일반 대형 귀걸이, 5 귀걸이+혼합 금속 추를 한 귀에 같이.",
"- 정상/이상 번호만 알려주세요 (이상이면 귀 쪽이 이상한지 얼굴 쪽이 이상한지만 한 마디).\n"]
rr=random.Random(7777)
for i,(kind,name,mode) in enumerate(SPEC,1):
    for tr in range(60):
        r2=random.Random(rr.randrange(10**9))
        text=ARCHF[name] if kind=="arch" else TEXT[name]
        tx=text(r2) if callable(text) else text
        try: it=ns['build'](i,r2,kind,name,tx)
        except AssertionError: continue
        if it["meta"]["tusk"]: continue
        nw=it["meta"]["ear_weights"]; p=it["prompt"]
        if kind=="lip":
            k="the eyes and eyelids stay clear."; assert k in p
            p=p.replace(k,k+" Her lips and chin carry no piercing at all, so the shape of her lips stays completely clear and unobstructed.",1)
        try: p2,lab=apply_ear(p,mode,nw,random.Random(rr.randrange(10**9)),w,HW2,COL2,None,it["title"])
        except AssertionError as e: continue
        if re.search(r"[가-힣]",p2) or re.search(r"\b(\w+) \1\b",p2) and re.search(r"\b(\w+) \1\b",p2).group(1).lower() not in("had","that"): continue
        break
    else: raise SystemExit(("fail",i))
    o.append(f"## {i}. {lab}\n\n```\n{p2}\n```\n")
    print(i,mode,len(p2.split()))
open(ns['OUT']+'LumineX_FaceSculpt_EarStyles_6_v3.md','w',encoding='utf-8').write("\n".join(o))
