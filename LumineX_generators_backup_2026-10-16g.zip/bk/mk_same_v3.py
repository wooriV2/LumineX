import re,random,sys
sys.path.insert(0,'.')
exec(open('mk_group_v2.py',encoding='utf-8').read().split('if __name__=="__main__":')[0])
RU=["러시안 립 과장","러시안 립 초과장","러시안 립 초과장+1","러시안 립 판타지 한계","러시안 립 초초과장","러시안 립 극한"]
SETS=[("서큐버스만 4인",[("arch","서큐버스")]*4,"front",False),
      ("인어 세이렌만 4인",[("arch","인어 세이렌")]*4,"front",False),
      ("러시안 립 자매 4인 (강도 서로 다름)",None,"q45",True)]
R=random.Random(20261027)
o=["# LumineX — 같은 유형끼리 4인 샘플 3개 (서큐버스 · 인어 · 러시안 립 자매)\n",
"- 서큐버스만 · 인어 세이렌만 · 러시안 립 자매(4명 모두 입술이 주인공, 강도 단계는 서로 다른 4종을 뽑음, 45도). 귀 장식은 인물마다 다른 종류, 피어싱 테마는 3종 중 최소 3가지, 한 장면·같은 배경입니다.",
"- 정상/이상은 번호로, 이상이면 한 줄만(예: 얼굴이 쌍둥이처럼 같음 · 귀 장식이 같음 · 피부가 고무 같음 · 입술 강도 차이가 안 보임 · 인물 #번호).\n"]
def sigp(p): return re.sub(r"\s+"," ",p[:400])
for idx,(lab,spec,mode,lip) in enumerate(SETS,1):
    if lip: spec=[("lip",x) for x in R.sample(RU,4)]
    n=len(spec); bg=R.choice(BGN)
    for tr in range(900):
        try: t,labs,dup=group5(R.randrange(10**7),spec,mode,bg)
        except AssertionError: continue
        if dup and dup.split()[0].lower() not in("had","that"): continue
        if lip:
            mk=[l.split(" · ")[4] for l in labs]
            if len(set(mk))<len(mk) or sum(x=="메이크업 없음" for x in mk)>1: continue
        pl=[l.split(" · ")[5] for l in labs]
        if not lip and len(set(pl))<3: continue
        if not lip:
            ps=re.findall(r"(?<=\n\n#\d: ).*?(?=\n\n#\d )",t,re.S)
            hs=[(re.search(r"long straight ([\w -]+?) hair|hair in ([\w -]+?) falling",p) or [None]).groups() if re.search(r"long straight ([\w -]+?) hair|hair in ([\w -]+?) falling",p) else None for p in ps]
            if None in hs or len(set(hs))<len(hs): continue
        break
    else: raise SystemExit(("fail",idx))
    t,nB=real2(t); t,k,k2=shorten(t); t=re.sub(r"  +"," ",t); assert not re.search(r"[가-힣]",t)
    o.append(f"## {idx}. {lab} · 배경 {bg}"+(" · 45도" if mode!="front" else " · 정면"))
    for j,l in enumerate(labs,1): o.append(f"- #{j}: {l}")
    o.append(f"- 길이: {len(t.split())}단어\n\n```\n{t}\n```\n"); print(idx,n,len(t.split()),pl,[l.split(" · ")[-1] for l in labs])
open(OUT+'LumineX_SameType_Group_Succubus_Mermaid_Ru_3.md','w',encoding='utf-8').write("\n".join(o))
