# -*- coding: utf-8 -*-
import re, random, sys
_s = open("mk_doll3.py", encoding="utf-8").read()
exec(_s[:_s.index("rg = random.Random(")])
rg = random.Random(int(sys.argv[1]) if len(sys.argv) > 1 else 20261024)
AUTO = [
 V("brass", "polished brass clockwork automaton", "polished brass", "brass",
   "BLAZING warm polished brass plates across the full torso both legs neck to ankle",
   "VIVID silver gears and tiny red ruby bearings turning inside the cut-out windows, deep blue-green verdigris joints standing out sharply against the brass, a small brass wind-up key turning slowly at her side", "bright polished", "황동 오토마톤"),
 V("porcelain", "white porcelain automaton with gold gears", "glazed porcelain", "glazed porcelain",
   "BLAZING glossy white porcelain plates painted with fine blue flowers across the full torso both legs neck to ankle",
   "VIVID gold gears and tiny gold cogs turning inside the cut-out windows, copper-red joints standing out sharply against the white, a small gold wind-up key turning slowly at her side", "high-gloss glazed", "도자기 오토마톤"),
 V("enamel", "black enamel automaton with silver gears", "black enamel", "black enamel",
   "BLAZING mirror-black enamel plates inlaid with silver filigree across the full torso both legs neck to ankle",
   "VIVID silver gears and white pearl bearings turning inside the cut-out windows, bright gold joints standing out sharply against the black, a small silver wind-up key turning slowly at her side", "mirror-gloss enamelled", "흑칠 오토마톤"),
]
NEWV["auto"] = AUTO
_prev2 = person_nv
def person_nv(label, key, phys, age, pose, eth):
    if key != "auto": return _prev2(label, key, phys, age, pose, eth)
    nm, desc, solid, nmw, base, acc, fin, tag = CUR_VAR[(label, key)]
    pn, pd = phys; p = f"{label}: " if label else ""
    mat = (f"full body {desc} body fused directly to her own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, this is a solid {solid} automaton body curving to follow her body's true three-dimensional shape, divided into fitted {nm} plates, with round cut-out windows on her torso, hips and thighs showing meshing gears turning inside, and at her neck, shoulders, elbows, wrists, hips, knees and ankles every plate ends in a round exposed hinge joint with a thin dark gap and its own small shadow, nothing lying flat. Dense fitted plates — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    feat, seg, info = face(eth); skin = eth[1]
    hl = HEEL_ if HEELMODE[0] == "forty" else HEEL_REL
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of the same {nmw}, each with {hl}, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, made of the same {nmw} with a high polish."
    fc = f"{p}Face: her face and ears are NOT part of the automaton body — they are real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair()} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    return "\n".join([body, shoe, nails, jw, fc]), info
def chk(t): return not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t)
# ---- 오토마톤 3
o1 = ["# 오토마톤(태엽·기계 인형) 샘플 3개 — 황동 · 도자기+금 기어 · 흑칠+은 기어\n", "Material Mix와 같은 기본 랜덤입니다(관절은 몸과 대비색). 번호별로 정상/이상만 알려주세요. 이상이면 한 줄만요.\n"]
for i, v in enumerate(AUTO, 1):
    for _ in range(300):
        physs = [rg.choices(BIG5, W5)[0]]; CUR_VAR.clear(); CUR_VAR[(None, "auto")] = v
        ages = [rg.choice(AGES)]; poses = [rg.choice(POSES)]; eths = rg.sample(ETH, 1)
        bid, wx = BGL.pick(rg, 1); scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
        ns2["JR"].seed(rg.randrange(10**9))
        t, infos = build3(["auto"], [v], physs, ages, poses, eths, scene)
        t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as her.", 1)
        if chk(t): break
    o1.append(f"## {i}. {v[7]} 솔로 · 체형 {physs[0][0]} · 인종 {eths[0][0]} · {infos[0]} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''}\n\n```\n{t}\n```\n")
    print("auto", i, len(t.split()))
open(O + "LumineX_Automaton_Sample_3.md", "w", encoding="utf-8").write("\n".join(o1))
# ---- 미니어처 3
CONT = [
 ("snow globe", "a large round glass snow globe standing on a polished carved wooden base on a table, filled with clear water and slowly falling white snow", "a small rocky mound at the bottom of the globe", "twelve centimetres"),
 ("music box", "an antique wooden music box standing open on a table, its mirrored lid raised behind her and a brass comb-and-cylinder mechanism beside her", "the small round turntable stage at the centre of the box, reflected in the mirrored lid", "ten centimetres"),
 ("terrarium", "a tall glass dome terrarium standing on a table, filled with deep green moss, tiny ferns and softly glowing mushrooms", "a mossy stone in the middle of the terrarium", "twelve centimetres"),
]
BODYK = ["jade", "porcelain", "bronze", "lacquer", "amber", "coral"]; rg.shuffle(BODYK)
o2 = ["# 미니어처 샘플 3개 — 스노우볼 · 오르골 · 테라리움 속 작은 그녀(몸은 검증된 재질)\n", "기본 랜덤(체형·인종·나이·포즈·헤어·네일·주얼리·배경)은 그대로, 구도만 접사 사진으로 바꿨습니다. 번호별로 정상/이상만 알려주세요. 이상이면 한 줄만요(예: 사람 크기가 큼, 용기 안에 없음).\n"]
for i, (cn, cd, base_, size) in enumerate(CONT, 1):
    key = BODYK[i-1]
    for _ in range(300):
        physs = rg.choices(BIG5, W5)[0]; CUR_VAR.clear(); v = rg.choice(NEWV[key]); CUR_VAR[(None, key)] = v
        age = rg.choice(AGES); pose = rg.choice(POSES); eth = rg.sample(ETH, 1)[0]
        bid, wx = BGL.pick(rg, 1); scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "relative"; ns2["JR"].seed(rg.randrange(10**9))
        body, info = person_nv(None, key, physs, age, pose, eth)
        head = f"Professional macro photograph of {cd}. Inside it stands ONE tiny woman only {size} tall, standing on {base_}, perfectly proportioned and scaled down like a collector's figurine, yet alive with real detail."
        tail = f"Background: {scene}, softly blurred far behind the {cn}, bright and evenly lit. ONE woman only. Shot on a macro lens at f/4 with shallow depth of field, the tiny woman razor sharp and every glass reflection, droplet and shadow clearly visible. Extreme macro detail on every surface texture. 8K portrait {ASP[1]} aspect ratio."
        t = f"{head}\n\n{body}\n\n{tail}"
        if chk(t): break
    o2.append(f"## {i}. {cn} · 몸 {KO[key]} {v[7]} · 체형 {physs[0]} · 인종 {eth[0]} · {info} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''}\n\n```\n{t}\n```\n")
    print("mini", i, key, len(t.split()))
open(O + "LumineX_Miniature_Sample_3.md", "w", encoding="utf-8").write("\n".join(o2))
