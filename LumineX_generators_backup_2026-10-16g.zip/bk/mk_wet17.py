# -*- coding: utf-8 -*-
# 신규 영역 4종 샘플(각 2개): 우주·성운 / 용암·마그마 / 털실·펠트 / 수묵·서예 — mk_new_bundles 틀, 전 축 기본 랜덤
_src = open("mk_new_bundles.py", encoding="utf-8").read()
exec(_src[:_src.index('if __name__')])
LEAD = "body curving to follow her body's true three-dimensional shape, "
T_WET = LEAD + "a continuous glossy wet-look coating over her entire body, thick sheets and streams of liquid running down every curve in glistening rivulets, countless beads and droplets clinging to the surface and dripping from her chin, fingertips, hips and knees, razor-sharp bright specular highlights along every curve, nothing lying flat. Dense wet surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
def V(tag, desc, solid, nmw, T, base, acc, fin): return dict(tag=tag, desc=desc, solid=solid, nmw=nmw, T=T, base=base, acc=acc, fin=fin)
VS = [
 V("젖은 광택 · 브론즈 오일", "oil-drenched glistening bronze", "wet-look", "glistening wet bronze", T_WET,
   "BLAZING deep metallic bronze-gold pigment across the full torso both legs neck to ankle, drenched in thick clear body oil",
   "VIVID golden oil streaming in long slow rivulets and heavy oil droplets hanging from every curve", "mirror-wet glossy"),
 V("젖은 광택 · 샤워 크림슨", "shower-drenched glistening crimson", "wet-look", "glistening wet crimson", T_WET,
   "BLAZING saturated crimson-red pigment across the full torso both legs neck to ankle, soaked under a running shower",
   "VIVID streams of clear water cascading from above in sheets and bright round water beads clinging everywhere, with a fine mist of spray in the air", "mirror-wet glossy"),
 V("젖은 광택 · 빗속 블랙", "rain-drenched glistening jet-black", "wet-look", "glistening wet black", T_WET,
   "BLAZING deep jet-black pigment across the full torso both legs neck to ankle, soaked by pouring rain",
   "VIVID silver rain streaking down in bright lines, white highlights glittering on every water bead and rivulet, and splashes bursting around her feet", "mirror-wet glossy"),
]
def chk(t): return not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t) and "navel" not in t.lower()

import sys
sys.path.insert(0, "../master")
import mdefs as D
import mk_newmakeup as NM
G0 = face.__globals__["G"]; _orig_pm = G0.pick_makeup
NM.extend(G0)
NEWV["wetpaint"] = []
NEWV["crystalp"] = []
MODEMAP = {}
MODEKO = {"both": "머리+얼굴 젖음", "hair": "머리만 젖음", "none": "안 젖음"}
_prev_nv = person_nv
def person_nv(label, key, phys, age, pose, eth):
    if key not in ("wetpaint", "crystalp"): return _prev_nv(label, key, phys, age, pose, eth)
    v = CUR_VAR[(label, key)]; nmw = v["nmw"]; nm = "the wet paint"
    pn, pd = phys; p = f"{label}: " if label else ""
    md = MODEMAP.get(label, "none")
    hairtxt = hair() + (", soaking wet, slicked and clinging in wet strands" if md in ("hair", "both") else "")
    sheen = "water droplets beading across her skin and a wet glistening sheen" if md == "both" else "a soft sheen of natural oils"
    mat = v["mat"] if "mat" in v else HEAD.format(desc=v["desc"], solid=v["solid"]) + v["T"].format(base=v["base"], acc=v["acc"], fin=v["fin"])
    feat, seg, info = face(eth); skin = eth[1]
    hl = HEEL_ if HEELMODE[0] == "forty" else HEEL_REL
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of the same {nmw}, each with {hl}, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, made of the same {nmw} with a high polish."
    fc = f"{p}Face: her face and ears are NOT {nm} — they are real living flesh with real pores, {sheen} and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hairtxt} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    return "\n".join([body, shoe, nails, jw, fc]), info

LIQE = {"샤워": "shower", "오일": "oil", "빗속": "rain"}
LIQ = {"샤워": ("soaked under a running shower", VS[1]["acc"], "mirror-wet glossy", None),
       "오일": ("drenched in thick clear body oil", VS[0]["acc"], "mirror-wet glossy", None),
       "빗속": ("soaked by pouring rain", VS[2]["acc"], "mirror-wet glossy", "outdoor")}
COLS = {  # key: (영어 형용사, base 색 문장, 한글)
 "jet-black": ("jet-black", "BLAZING deep jet-black pigment across the full torso both legs neck to ankle", "블랙", "black"),
 "midnight-blue": ("midnight-blue", "BLAZING deep midnight-blue pigment across the full torso both legs neck to ankle", "미드나이트 블루", "navy"),
 "deep emerald": ("deep emerald", "BLAZING deep emerald-green pigment across the full torso both legs neck to ankle", "딥 에메랄드", "emerald"),
 "burgundy": ("burgundy", "BLAZING deep burgundy-wine pigment across the full torso both legs neck to ankle", "버건디", "burgundy"),
 "cobalt": ("cobalt", "BLAZING cobalt-blue pigment across the full torso both legs neck to ankle", "코발트", "cobalt"),
 "crimson": ("crimson", "BLAZING saturated crimson-red pigment across the full torso both legs neck to ankle", "크림슨", "crimson"),
 "bronze": ("bronze", "BLAZING deep metallic bronze-gold pigment across the full torso both legs neck to ankle", "브론즈", "bronze"),
}
def solid_v(key, liq):
    adj, base, ko, nmc = COLS[key]; how, acc, fin, _ = LIQ[liq]
    return V(f"젖은 {ko}", f"{LIQE[liq]}-drenched glistening {adj}", "wet-look", f"glistening wet {nmc}", T_WET, f"{base}, {how}", acc, fin)
CRY = {"rose": ("ROSE QUARTZ PINK", "SOFT GOLD", "rose quartz crystal", "로즈쿼츠"), "smoky": ("SMOKY GREY", "CHARCOAL", "smoky quartz crystal", "스모키쿼츠")}
def crystal_v(key):
    c1, c2, sh, ko = CRY[key]
    mat = (f"full body {sh} clusters growing directly out of her own skin covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, every crystal point erupting outward from beneath the surface of her living skin in true three-dimensional relief, each facet catching its own individual glint and casting its own small hard shadow onto the skin and onto neighbouring crystals, nothing lying flat. Dense overlapping clusters — BLAZING {c1} crystal points erupting across the full torso both legs neck to ankle, VIVID {c2} mineral veins and undertone glinting through the thinnest points filling every remaining gap with real depth and texture, each facet sharply faceted and distinct, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    return dict(tag=f"석영 {ko}", nmw=sh, mat=mat, desc=sh, solid="crystal")
# (이름, 인원, 액체, [(종류, 키)])  종류: solid=젖은 단색, bodypaint/irezumi/uvneon=일반(젖지 않은) 바디페인팅
PLAN = [
 ("혼합 듀오 C", 2, "오일", [("solid", "burgundy"), ("bodypaint", None)]),
 ("혼합 듀오 D", 2, "오일", [("crystal", "rose"), ("solid", "jet-black")]),
]
STY = ['코갸루', '걸크러시', '글래스 스킨', '홍콩풍', '강남언니', '인스타글램', '구풍', '오네에갸루', '웨이쉰', '히메갸루', '만바']
G0.pick_makeup = (lambda _r, style=None: _orig_pm(_r, style=_r.choice(STY)))
rg = random.Random(20261202); rr.seed(20261202); ns2["JR"].seed(20261202)
WINTER = ('겨울 눈 광장', '겨울 설원', '얼음 동굴')
POOLP = {"bodypaint": BP, "irezumi": IR, "uvneon": UV}
o1 = ["# 젖은 광택(wet-look) 혼합 듀오 2개 — UV네온 제외, 1번은 일반 바디페인팅 · 2번은 석영(로즈쿼츠)과 섞음\n", "Material Mix와 같은 기본 랜덤입니다(체형·나이·포즈·인종·배경·힐·네일·주얼리). 번호별로 정상/이상만 알려주세요. 이상이면 한 줄만요.\n"]
for gi, (gname, n, liq, items) in enumerate(PLAN, 1):
    for attempt in range(500):
        MODEMAP.clear(); wl = [idx for idx, (k, _) in enumerate(items) if k == "solid"]
        ms = ["both", "hair", "none"]; rg.shuffle(ms)
        for j, idx in enumerate(wl): MODEMAP[f"#{idx+1}"] = ms[j % 3] if len(wl) >= 3 else rg.choice(ms)
        CUR_VAR.clear(); picks = []; kinds = []; names = []
        for idx, (k, key) in enumerate(items):
            if k == "solid":
                v = solid_v(key, liq); CUR_VAR[(f"#{idx+1}", "wetpaint")] = v; picks.append(v); kinds.append("wetpaint"); names.append(v["tag"] + "(" + MODEKO[MODEMAP[f"#{idx+1}"]] + ")")
            elif k == "crystal":
                v = crystal_v(key); CUR_VAR[(f"#{idx+1}", "crystalp")] = v; picks.append(v); kinds.append("crystalp"); names.append(v["tag"])
            else:
                picks.append(rg.choice(POOLP[k])); kinds.append(k); names.append("일반 " + KO[k])
        physs = []
        while len(physs) < n:
            c = rg.choices(BIG5, W5)[0]
            if c not in physs: physs.append(c)
        ages = [rg.choice(AGES) for _ in range(n)]; poses = [rg.choice(POSES) for _ in range(n)]; eths = rg.sample(ETH, n)
        bid, wx = BGL.pick(rg, n)
        if LIQ[liq][3] == "outdoor":
            while (not BGL.BG[bid][4]) or BGL.BG[bid][2] in WINTER: bid, wx = BGL.pick(rg, n)
        scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
        ns2["JR"].seed(rg.randrange(10**9))
        t, infos = build3(list(kinds), picks, physs, ages, poses, eths, scene)
        t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as any of them.", 1)
        if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t) or "navel" in t.lower(): continue
        break
    else: raise SystemExit("fail group")
    hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
    o1.append(f"## {gi}. {gname} · {liq} · {' / '.join(names)} · 체형 {', '.join(x[0] for x in physs)} · 인종 {', '.join(e[0] for e in eths)} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko}\n\n```\n{t}\n```\n")
    print(gi, n, len(t.split()), t.count("forty inches"))
open(O + "LumineX_WetLook_Duo2b.md", "w", encoding="utf-8").write("\n".join(o1))
