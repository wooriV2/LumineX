import re,random
exec(open('new_lib.py',encoding='utf-8').read())
TEXT={}
for n,t,c in ns['EYEITEMS']+ns['CAN']+ns['LIPITEMS']: TEXT[n]=t
def subj(t): return [x for x in t.split("\n\n") if x.startswith("Subject:")][0]
def finish(t,mode,nw,rr,lab):
    global FORCE
    FORCE=None
    return apply_ear(t,mode,nw,random.Random(rr.randrange(10**9)),w,HW2,COL2,None,lab)
def plain(t,nw):
    a=t.index("All the ear weights hang from the bottoms of these two iron rings"); hw=HW2.format(col=COL2[nw]); b=t.index(hw)+len(hw)
    t=t[:a].rstrip()+t[b:]
    assert SEG_OLD in t
    t=t.replace(SEG_OLD,"each opening holding its own large classic round hoop earring of a moderate size, a plain metal ring with nothing hanging from it")
    t=t.replace("so the weights fully hang in view","so both ears are fully in view").replace(" (not counting the hanging weights)","").replace(", while the hanging weights are always black cast iron,",",").replace("every hanging piece is in clear view","every piece is in clear view")
    return t
rr=random.Random(8080)
OUTS=[]
REALT=" Her whole face, ears and neck are real living flesh with real pores and fine skin grain, real living eyes with bright catchlights and genuine depth, individual hair strands catching the light"
# ---- macro
def macro(kind,name,mode):
    for tr in range(80):
        r2=random.Random(rr.randrange(10**9))
        try:
            it=ns['build'](1,r2,kind,name,TEXT[name])
        except AssertionError: continue
        if it["meta"]["tusk"]: continue
        s=[x for x in it["prompt"].split("\n\n") if x.startswith("Subject:")][0]
        s=s.replace(". Real pores and fine skin grain on her skin, a soft sheen of natural oils, large eyes with bright real catchlights, full lips, ",", ").replace("hourglass physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — most dramatic hourglass ratio ever, simultaneously maximum enormous bust AND maximum enormous hips both flaring to absolute impossible extremes while the waist is cinched to impossible minimum, ","")
        s=re.sub(r" — a photograph of a real (\w+) woman's face \(.*?\), not an illustration"," — a photograph of a real \\1 woman's face, not an illustration",s)
        s=s.replace("catching the light  Her face","catching the light. Her face")
        if kind=="eye":
            hd="Professional fashion photograph, extreme macro close-up of a woman's eyes. ONE woman facing the camera straight on, her head level, the frame cropped tightly from the middle of her forehead down to the top of her cheekbones so that both eyes and both eyebrows fill the whole frame, every eyelash, the pattern of each coloured lens and the texture of the eyelids razor sharp. Early 20s."
            pier="Piercings: none appear within this tight crop; the skin around her eyes is bare, clean and real."
            lit="Lighting: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. A soft frontal light with a small bright catchlight reflecting in each iris, so the lens pattern, the lashes and the sheen of the makeup read clearly. 3:2 horizontal 8K."
        else:
            hd="Professional fashion photograph, extreme macro close-up of a woman's lips. ONE woman, her head turned about forty-five degrees to her left in a three-quarter view, the frame cropped tightly from just under her nose down to the middle of her chin so that her lips fill the whole frame, and from this angle the full projection of her lips from her face is clearly visible, every fine line and the gloss of the lips razor sharp. Early 20s."
            pier="Piercings: none appear within this tight crop; the skin around her lips is bare, clean and real."
            lit="Lighting: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. A soft key light from the front and slightly to the side, with a bright specular highlight along the top of each lip and on the dome of the lower lip. 3:2 horizontal 8K."
        t="\n\n".join([hd,s,pier,lit])
        if re.search(r"[가-힣]",t): continue
        d=re.search(r"\b(\w+) \1\b",t)
        if d and d.group(1).lower() not in("had","that"): continue
        return t,it["title"]
    raise SystemExit("fail macro")
for kind,name in (("eye","양쪽 트임 8배+거대한 눈"),("lip","러시안 립 극한")):
    t,ti=macro(kind,name,None)
    OUTS.append((f"매크로 컷 · {name} ({'눈만' if kind=='eye' else '입술만 45도'}) · "+ti.split('(',1)[1].rstrip(')')[:80],t)); print(len(OUTS),len(t.split()))
# ---- face types
TYPES=[
("구체관절 인형","A real photograph of a strikingly beautiful adult woman, mid 20s, styled as a living ball-jointed doll: flawless matte porcelain-resin skin with a soft powdery finish and a faint pink blush high on the cheeks, perfectly symmetrical features, enormous glassy doll eyes in pale violet doll-eye contact lenses with a huge iris, both eyes exactly the same, fully opaque and solidly saturated, with a darker limbal ring and bright real catchlights, long fine lashes, tiny rosebud lips in soft rose, a small neat nose, a thin precise doll-joint seam line running along each side of her jaw and a small round ball-joint seam at the base of her neck, long silky pale-lavender hair with neat blunt bangs. Real skin fine grain still visible — a photograph of a real woman's face, not an illustration, not a render. Every enhanced feature is exaggerated but beautiful, balanced and refined, never distorted, never grotesque."),
("금이 간 도자기 인형","A real photograph of a strikingly beautiful adult woman, mid 20s, styled as a cracked porcelain doll mended with gold: glossy glazed white porcelain-like skin with a cool blue undertone, fine hairline cracks running across her forehead, left cheek and chin, each crack mended with a thin bright line of gold in the kintsugi way, with a few tiny chips edged in gold, large dark glassy eyes with bright real catchlights and long lashes, deep red lips, her black hair pinned in a tight low bun. Real skin fine grain still visible under the glaze — a photograph of a real woman's face, not an illustration, not a render. Every enhanced feature is exaggerated but beautiful, balanced and refined, never distorted, never grotesque."),
("마네킹","A real photograph of a strikingly beautiful adult woman, mid 20s, styled and made up as a high-fashion store mannequin: perfectly even warm-ivory skin with a smooth matte-gloss lacquered finish, sharply sculpted cheekbones and a stylised small nose, painted-on high arched brows, glossy lacquered red lips, eyes with a fixed, glassy, unblinking stare in pale grey doll-eye contact lenses with bright catchlights, a fine seam line at each temple, and a sleek moulded black lacquer bob that looks sculpted and shiny. Real skin fine grain still faintly visible — a photograph of a real woman's face, not an illustration, not a render. Every enhanced feature is exaggerated but beautiful, balanced and refined, never distorted, never grotesque."),
("사이보그","A real photograph of a strikingly beautiful adult woman, mid 20s, styled as a sleek cyborg: smooth flawless skin, a clean mechanical seam line running from her left temple down the cheek to the jaw, the panel along her left cheek in brushed chrome with fine engraved lines, her left eye a mechanical iris ring glowing cyan with a tiny aperture pattern, her right eye a natural-looking eye in a matching cyan contact lens, both with bright real catchlights, glossy deep plum lips, and silver-white hair slicked sleekly back. Real skin fine grain still visible on the right side of her face — a photograph of a real woman's face, not an illustration, not a render. Every enhanced feature is exaggerated but beautiful, balanced and refined, never distorted, never grotesque.")]
for (nm,txt),mode in zip(TYPES,("mix","earring","iron","mix")):
    for tr in range(80):
        r2=random.Random(rr.randrange(10**9))
        try:
            nw=r2.choice([8,9,10])
            t,lab,lt,nw=base(r2,25,(),True,r2.choice(["",HENNA]),nw)
            sj=subj(t); t=t.replace(sj,"Subject: "+txt)
            t,lab2=finish(t,mode,nw,r2,lab+f" · 귀 추 {nw}개/귀 2구멍")
        except AssertionError: continue
        if re.search(r"[가-힣]",t): continue
        d=re.search(r"\b(\w+) \1\b",t)
        if d and d.group(1).lower() not in("had","that"): continue
        break
    else: raise SystemExit("fail type")
    OUTS.append((f"얼굴 유형 · {nm} · 유형 고유 메이크업 · 귀만 피어싱 · {lab2.split(' · ')[-1]}",t)); print(len(OUTS),len(t.split()))
# ---- neck
NECK=[("스파이크 초커(가시 칼라)","Neck: around the base of her neck she wears a wide black leather collar studded with chrome cone spikes, with a large O-ring at its centre, sitting flat and snug against her skin."),
("금 넥링 스택","Neck: a tall stack of thin polished gold neck rings coils around her neck from its base up to just under her jaw, lengthening her neck, each ring flat and snug against the one below it, with her skin smooth between the base of the stack and her collarbones.")]
for nm,txt in NECK:
    for tr in range(80):
        r2=random.Random(rr.randrange(10**9))
        try:
            nw=8
            t,lab,lt,nw=base(r2,25,("tmp","brow","bri"),False,r2.choice(["",HENNA]),nw)
            t=t.replace(FR["sh"],"down to the middle of her chest, the frame cutting off there, so her whole neck and collar are in clear view",1)
            t=plain(t,nw)
            t=t.replace("\n\nHair:","\n\n"+txt+"\n\nHair:",1)
            assert txt in t
        except AssertionError: continue
        if re.search(r"[가-힣]",t): continue
        d=re.search(r"\b(\w+) \1\b",t)
        if d and d.group(1).lower() not in("had","that"): continue
        break
    else: raise SystemExit("fail neck")
    OUTS.append((f"목·쇄골 컷 · {nm} (귀는 기본 후프) · {lab}",t)); print(len(OUTS),len(t.split()))
o=["# LumineX — 새 축 시험 샘플 파일 2 (8개)\n","- 1~2 매크로 컷(눈만 / 입술만), 3~6 얼굴 유형(구체관절 인형·금이 간 도자기 인형·마네킹·사이보그), 7~8 목·쇄골 컷(가슴 중간까지 프레임, 귀는 기본 후프).","- 정상/이상 번호만 알려주세요.\n"]
for i,(title,p) in enumerate(OUTS,1): o.append(f"## {i}. {title}\n\n```\n{p}\n```\n")
open(OUT+'LumineX_NewAxes_Test_File2.md','w',encoding='utf-8').write("\n".join(o))
