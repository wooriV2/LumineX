# -*- coding: utf-8 -*-
# 힐 숫자 A/B(40인치 표기 vs 몸 기준 비교) + 몸 주얼리 추가 — 6개
import re, random
src = open("gen_woodstone_full10.py", encoding="utf-8").read()
head = src[:src.index("PLAN = [")]
head = head.replace('rr = random.Random(20261010)', 'rr = random.Random(20261018)')
# 힐 문구를 모드에 따라 분기
old = 'each with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform, {BODYLIFT}."'
assert old in head
head = head.replace(old, '{HEELPH()}, {BODYLIFT}."')
# 주얼리 줄 추가
old2 = 'return "\\n".join([body, shoe, nails, fc]), info, nmw'
assert old2 in head
head = head.replace(old2, 'return "\\n".join([body, shoe, nails] + ([f"{p}Jewelry: {jewel(p)}"] if JEWEL else []) + [fc]), info, nmw')
exec(head)
MODE = "num"; JEWEL = False; JR = random.Random(77)
def HEELPH():
    if MODE == "num": return "each with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform"
    return "each with a razor-thin tapered heel taller than her entire shin from ankle to knee and a towering hidden front platform"
JW = ["a long layered gold necklace falling between her breasts", "a wide gold waist chain resting over the carved curve of her hips", "thick polished gold bangles stacked on both wrists",
      "a delicate silver body chain draped across her collarbones and down her torso", "sculpted gold armbands high on both upper arms", "a pearl choker and a long strand of pearls hanging low on her chest",
      "a gold belly chain with a small pendant at her navel", "a fine gold chain looped around her thigh above the knee", "heavy gold rings on every finger"]
def jewel(p):
    a = JR.sample(JW, 3)
    return ", ".join(a[:-1]) + ", and " + a[-1] + ". Jewelry is metal and pearl only, worn on the body, nothing added to her face or ears."
PLAN = [(1, ["wood"]), (2, ["stone", "wood"]), (2, ["wood", "stone"])]
BL_A = BODYLIFT
BL_B = "her feet arched fully vertical on the very tips of her toes like a dancer on pointe, her whole body lifted far above the ground on them, while her body keeps its full original proportions — thick heavy thighs, wide full hips and a huge bust exactly as massive as before, and only the heels add height"
BL_C = "her feet arched fully vertical on the very tips of her toes like a dancer on pointe, her whole body lifted far above the ground on them as if standing on stilts, while her body keeps its full original proportions — thick heavy thighs, wide full hips and a huge bust exactly as massive as before"
sel = []
for n, kinds in PLAN:
    for attempt in range(60):
        picks = [rr.choice(WOODS if k == "wood" else STONES) for k in kinds]
        if len({p[0] for p in picks}) < n: continue
        physs = ([PH_BBW] if n == 1 else [PH_BBW, PH_AMA]); ages = [rr.choice(AGES) for _ in range(n)]; poses = [rr.choice(POSES) for _ in range(n)]; eths = rr.sample(ETH, n)
        si = rr.randrange(8); st = rr.getstate()
        outs = []; ok = True
        for mode, jw in (("C", True),):
            MODE, JEWEL = "num", jw; JR.seed(500 + n); BODYLIFT = BL_C
            rr.setstate(st)
            t, infos = build(kinds, picks, physs, ages, poses, eths, SETS[si])
            try: check(f"t{n}{mode}{jw}", t)
            except AssertionError: ok = False; break
            if re.search(r"\b(\w+) \1\b", t) or re.search(r"[가-힣]", t): ok = False; break
            outs.append((t, infos))
        if ok: break
    else: raise SystemExit("fail")
    sel.append((n, kinds, picks, physs, eths, si, outs))
o = ["# 목재·석재 듀오 힐 40인치 — 절충 문구 C (2개)\n",
     "듀오 2개이며 모두 힐 40인치 표기 + 부피 큰 체형(BBW + amazon bombshell)입니다. C = 'her legs stretched impossibly long'만 빼고 'as if standing on stilts'는 유지한 채 '체형은 그대로(굵은 허벅지·넓은 힙·큰 가슴)'를 덧붙인 절충 문구입니다. 1번은 직전 시험 3·4번과 같은 듀오(석재 로도크로사이트 + 목재 레이스우드)라서 이전 A·B 결과와 직접 비교할 수 있고, 2번은 다른 듀오입니다. 번호별로 정상/이상, 그리고 1번은 A·B와 비교해 높이와 체형이 어느 쪽에 가까운지만 알려주세요.\n"]
labels = {0: "C 절충 문구(stilts 유지 + 체형 유지)"}
order = [(1, 0), (2, 0)]
num = 0
for si_, vi in order:
    n, kinds, picks, physs, eths, si, outs = sel[si_]; t, infos = outs[vi]; num += 1
    ti = f"{['','솔로','듀오'][n]} · " + " / ".join(f"{'목재' if k=='wood' else '석재'} {p[0]}" for k, p in zip(kinds, picks)) + " · 체형 " + ", ".join(x[0] for x in physs) + " · 인종 " + ", ".join(e[0] for e in eths) + " · " + " ‖ ".join(infos) + f" · 배경 {SETKO[si]} · {labels[vi]}"
    o.append(f"## {num}. {ti}\n\n```\n{t}\n```\n"); print(num, ti[:260], len(t.split()))
open(O + "LumineX_WoodStone_LegLength_C2.md", "w", encoding="utf-8").write("\n".join(o))
