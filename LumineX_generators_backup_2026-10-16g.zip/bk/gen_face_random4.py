# -*- coding: utf-8 -*-
import random, re
import gen_cjk_v2 as G
O = "/mnt/user-data/outputs/"
EX = {"아이돌": ["귀여운", "발랄한", "당황한", "눈물 글썽한", "몽환적인", "도도한", "놀란", "호기심 어린"],
      "20대": ["도도한", "섹시한", "귀여운", "발랄한", "몽환적인", "당황한", "눈물 글썽한", "카리스마 있는", "놀란", "호기심 어린", "광기 어린"],
      "30대": ["고혹적인", "군림하는", "냉혹한", "카리스마 있는", "도도한", "섹시한", "몽환적인", "놀란", "광기 어린"]}
FACEPAINT = {"경극", "마이코", "혼례(연지곤지)", "둔황 비천풍"}
HDR = "facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face,"
LIT = "A soft frontal light on her face and ears;"
KEY = "A soft key light from the front and slightly to the side on her face;"
ANG = {"3/4 회전(왼쪽)": ("her head turned about forty-five degrees to her left in a three-quarter view, her eyes still looking straight into the camera, one ear and the turned cheek clearly visible,", KEY),
       "3/4 회전(오른쪽)": ("her head turned about forty-five degrees to her right in a three-quarter view, her eyes still looking straight into the camera, one ear and the turned cheek clearly visible,", KEY),
       "숙이고 올려보기": ("her head tilted slightly down with the chin tucked and her eyes looking up at the camera from beneath her brows, the camera at eye level, both ears still visible,", LIT),
       "고개 살짝 기울임": ("her head tilted a little to one side, her eyes looking straight into the camera, both ears clearly visible,", LIT)}
TEAR = "a small dark beauty mark just below the outer corner of her left eye like a tear mole, a second tiny beauty mark above the right corner of her upper lip"
TEAR3 = TEAR + ", and a third on her left cheekbone, each one a clearly visible dot of real skin pigment"
TEAR2 = TEAR + ", each one a clearly visible dot of real skin pigment"
FRK = "a dense scatter of natural freckles across the bridge of her nose and both cheeks, individual tan-brown freckles clearly visible through the skin and not covered by any makeup"
def sub(t, a, b):
    assert t.count(a) == 1, a; return t.replace(a, b)
def one(seed, nat, grp):
    rr = random.Random(seed)
    for _ in range(50):
        try:
            expr = rr.choice(EX[grp]); st = None
            t, title, m = G.make(rr, nat, grp, expr, style=st, nacc=rr.choices([0, 1, 2, 3], [.08, .27, .40, .25])[0])
            pier = m["piercing"] != "P0"; fp = m["makeup"] in FACEPAINT
            ang = None; mole = None
            r = rr.random()
            if r < 0.75:
                opts = [a for a in ANG if not (pier and a.startswith("3/4"))]
                if expr == "도도한": opts = [a for a in opts if a != "숙이고 올려보기"]
                if opts: ang = rr.choice(opts)
            if not fp and rr.random() < 0.6:
                cheek = bool(m["micro"] or m["sticker"])
                kinds = ["눈물점+점"] + ([] if cheek else ["눈물점+점2", "주근깨"] if not (m["makeup"] and m["dark"]) else ["눈물점+점2"])
                if cheek: kinds = ["눈물점+점"]
                mole = rr.choice(kinds)
            if not ang and not mole: continue
            if ang: t = sub(t, HDR, ANG[ang][0]); t = sub(t, LIT, ANG[ang][1])
            if mole:
                txt = {"눈물점+점": TEAR2, "눈물점+점2": TEAR3, "주근깨": FRK}[mole]
                t = sub(t, "catchlights, full lips, ", "catchlights, full lips, " + txt + ", ")
            assert not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t)
            tag = " · ".join(x for x in [("각도 " + ang) if ang else None, ("점 " + mole) if mole else None] if x)
            return t, f"{title} · 아워글래스 · {tag}"
        except AssertionError:
            continue
    raise SystemExit("fail")
S = [one(111, "한국", "20대"), one(212, "일본", "아이돌"), one(313, "중국", "20대"), one(414, "한국", "30대")]
o = ["# 얼굴 컷 랜덤 4개 (각도 · 점/주근깨 포함)\n", "번호별로 정상/이상만 알려주세요.\n"]
for i, (t, ti) in enumerate(S, 1):
    o.append(f"## {i}. {ti}\n\n```\n{t}\n```\n"); print(i, ti)
open(O + "LumineX_Face_Random4_AngleMole.md", "w", encoding="utf-8").write("\n".join(o))
