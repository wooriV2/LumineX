# -*- coding: utf-8 -*-
"""임산부 허리 컷 / 힙 컷 + 얼굴 소재(피어싱·쥬얼리·마이크로더멀·스티커·헤나·렌즈) 랜덤 샘플.
기반: 등록된 Piercing Frame 임산부 허리 컷 50개(la_pframe_geo_300_bundle.json). 소재 선택 규칙은 gen_cjk_v2.py의 포인트 슬롯(최대 3종, 가중치) 그대로."""
import json, re, random, sys, collections
O = "/mnt/user-data/outputs/"
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 1
FACEPAINT = {"경극", "마이코", "혼례(연지곤지)", "둔황 비천풍"}
STK = [("야광 별", {"ck"}, "three small glow-in-the-dark star stickers on the cheekbone, softly glowing neon green-blue against the dark"),
       ("야광 하트·별", {"ck", "tp"}, "five tiny glow-in-the-dark heart and star stickers scattered on the cheekbones and temple, softly glowing neon pink and blue"),
       ("나비", {"tp", "ck"}, "two small iridescent butterfly stickers, one at the outer corner of the eye on the temple and one on the cheekbone"),
       ("금박 나뭇잎", {"tp", "ck"}, "three small gold foil stickers shaped like tiny leaves, one at the temple and two on the cheekbone"),
       ("동물 실루엣", {"ck", "tp"}, "three small cat and rabbit silhouette stickers on the cheekbones and temple"),
       ("네잎클로버", {"tp", "ck"}, "three small green four-leaf clover stickers, one at the temple and two on the cheekbone"),
       ("금박 별(관자놀이)", {"tp"}, "four small gold foil star stickers, two at each temple"),
       ("야광 초승달(관자놀이)", {"tp"}, "a small glow-in-the-dark crescent moon sticker at each temple, softly glowing neon blue-green against the dark"),
       ("이마 눈", {"fh"}, "a single small evil-eye sticker at the center of the forehead, well above the brows")]
LENS_COL = [("아이스블루", "ice-blue"), ("코발트 블루", "deep cobalt-blue"), ("에메랄드", "vivid emerald-green"), ("형광 라임", "neon lime-green"), ("앰버", "glowing amber-gold"),
            ("바이올렛", "vivid violet-purple"), ("크림슨 레드", "intense crimson-red"), ("핫핑크", "hot-pink"), ("순백", "pure opaque white"), ("오렌지 파이어", "fiery orange"), ("터쿼이즈", "bright turquoise")]
LENS_PUP = [("둥근 동공", "round natural pupils"), ("고양이눈", "a vertical slit cat-eye pupil"), ("큰 동공", "a greatly enlarged dilated pupil"),
            ("방사형 무늬", "a radiating sunburst iris pattern"), ("두꺼운 외곽 링", "a thick dark outer ring and round natural pupils"), ("하트 동공", "a heart-shaped pupil")]
LQ = "fully opaque and solidly saturated across the whole iris with no natural brown showing through, the colour bright and unmistakable, with a darker limbal ring"
LTAIL = "sitting naturally on the irises and clear of the eyelids"
HENNA = [("붉은 갈색", "deep reddish-brown"), ("금색", "metallic gold"), ("흰색", "pure white")]
GEM_SHAPES = ["heart", "star", "four-leaf clover", "crescent moon", "butterfly", "round"]
GEM_COLORS = ["clear", "pink", "ruby-red", "emerald-green", "sapphire-blue", "gold", "amethyst-purple"]
KO_S = {"heart": "하트", "star": "별", "four-leaf clover": "네잎클로버", "crescent moon": "초승달", "butterfly": "나비", "round": "라운드"}
KO_C = {"clear": "투명", "pink": "핑크", "ruby-red": "루비", "emerald-green": "에메랄드", "sapphire-blue": "사파이어", "gold": "골드", "amethyst-purple": "자수정"}
JQ = {1: "a single piece", 2: "two to three pieces", 3: "four to six pieces, layered", 4: "seven to ten pieces, heavily stacked", 5: "well over ten pieces, an extreme maximalist stack"}
JMET = {"JMG": "gold", "JMS": "silver", "JMR": "rose-gold", "JMP": "platinum", "JMX": "mixed-metal"}
W = {"pierce": 3, "lens": 0.6, "micro": 1.4, "sticker": 1.4, "henna": 1}
def art(c): return ("an " if c[0] in "aeiou" else "a ") + c
def wsample(rr, opts, k):
    pool = list(opts); res = []
    for _ in range(min(k, len(pool))):
        c = rr.choices(pool, [W[o] for o in pool])[0]; res.append(c); pool.remove(c)
    return res
WAIST_HDR = "framed from the very top of her head down to just below her pregnant belly, the frame cutting off beneath the belly."
HIP_HDR = "framed from the very top of her head down through the hips, the frame cutting off across the upper thighs so no knees, lower legs or feet are visible."
BASES = [x for x in json.load(open(O + "la_pframe_geo_300_bundle.json", encoding="utf-8")) if x["meta"]["track"] == "임산부" and x["meta"]["group_size"] == 1]

def make(rr, frame, base):
    paras = base["prompt"].split("\n\n"); head, subj = paras[0], paras[1]
    assert paras[2].startswith("Piercings:") and paras[3].startswith("Piercing depth:") and paras[-1].startswith("Lighting:")
    mk = re.search(r"메이크업 ([^·)]+)", base["title"]).group(1).strip()
    fp = any(f in mk for f in FACEPAINT)
    free_fh = not re.search(r"forehead|huadian|gonji", subj); hasstk = "sticker" in subj.lower(); can_lens = "lens" not in subj.lower()
    opts = ["pierce"] + (["lens"] if can_lens else []) + ([] if fp else ([] if hasstk else ["micro", "sticker"]) + (["henna"] if free_fh else []))
    chosen = wsample(rr, opts, rr.choice([2, 3]))
    pier = "pierce" in chosen; clr = " and clear of the piercings" if pier else ""
    parts = []; info = []; zone_ck = zone_fh = zone_tp = False
    if "micro" in chosen:
        sh, co = rr.choice(GEM_SHAPES), rr.choice(GEM_COLORS); pl = rr.choice(["A", "A+B", "C"] if free_fh else ["A", "C"])
        where = {"A": "a row of five small gems along each cheekbone", "A+B": "a row of five small gems along each cheekbone and one larger gem at the center of the forehead", "C": "a cluster of three small gems at each temple"}[pl]
        zone_ck |= "A" in pl; zone_fh |= "B" in pl; zone_tp |= pl == "C"
        shp = "round faceted" if sh == "round" else f"{sh}-shaped"
        parts.append(f"microdermal {co} {shp} gems pressed deep into the skin: {where}, each gem sitting on a tiny hidden metal base implanted beneath the skin and pressing firmly down so the skin around every gem is visibly pushed in, forming a clear small dimple with a soft raised ring of flesh bulging around its edge, a small natural warm shadow in each dimple, calm healthy skin with no redness or swelling, all gems well clear of the eyes" + clr)
        info.append(f"마이크로더멀 {KO_C[co]} {KO_S[sh]}")
    if "sticker" in chosen:
        ok = [s for s in STK if not (("ck" in s[1]) and zone_ck) and not (("tp" in s[1]) and zone_tp) and not ("fh" in s[1] and (zone_fh or not free_fh))]
        s = rr.choice(ok); parts.append(s[2] + ", all stickers flat on the skin, clear of the eyes and lids" + clr); info.append(f"스티커 {s[0]}"); zone_fh |= "fh" in s[1]
    if "henna" in chosen and not zone_fh:
        hn = rr.choice(HENNA); parts.append(f"fine {hn[1]} henna mehndi line patterns of vines and dots painted across the forehead only, well clear of the eyes and brows"); info.append(f"헤나 {hn[0]}")
    if "lens" in chosen:
        if rr.random() < 0.2:
            (n1, c1), (n2, c2) = rr.sample(LENS_COL, 2); p1, p2 = rr.choice(LENS_PUP), rr.choice(LENS_PUP)
            parts.insert(0, f"odd-eyed with two clearly different lenses: her left eye has {art(c1)} coloured contact lens with {p1[1]}, {LQ}, and her right eye has {art(c2)} coloured contact lens with {p2[1]}, {LQ}, {LTAIL}, the two eye colours both bright and clearly different from each other")
            info.append(f"렌즈 오드아이 {n1}({p1[0]})|{n2}({p2[0]})")
        else:
            (n1, c1), p1 = rr.choice(LENS_COL), rr.choice(LENS_PUP)
            parts.insert(0, f"vivid {c1} coloured contact lenses with {p1[1]}, both eyes the same, {LQ}, {LTAIL}"); info.append(f"렌즈 {n1}({p1[0]})")
    jew = None
    if rr.random() < 0.5:
        q, jm = rr.randint(1, 5), rr.choice(list(JMET)); m = JMET[jm]
        jew = (f"Jewelry: {'besides the piercings ' if pier else ''}she wears {JQ[q]} of {m} necklaces and chains resting on her neck and collarbones, and {JQ[q]} of {m} hair ornaments set in her hair, all of it real, without covering her eyes, her face{' or her piercings' if pier else ''}.")
        info.append(f"쥬얼리 JQ{q} {m}")
    # 조립
    if parts:
        a = "Her whole face, ears and neck are real living flesh"; assert subj.count(a) == 1
        subj = subj.replace(a, "Face details: " + ", ".join(parts) + ". " + a, 1)
    if frame == "hip": head = head.replace(WAIST_HDR, HIP_HDR, 1).replace("waist shot", "hip shot", 1); assert HIP_HDR in head
    lit = paras[-1]
    if not pier:
        head = head.replace(", large enough to read every piercing, and her ear pieces are oversized so they read clearly at this distance.", ", large and sharp.", 1)
        lit = lit.replace("so the makeup and the glints on every piece of metal read clearly", "so the makeup and every detail of her face read clearly", 1)
    if "micro" in chosen:
        lit = lit.replace("every piece of metal read clearly", "every piece of metal and every gem read clearly", 1) if pier else lit.replace("every detail of her face read clearly", "every gem and every detail of her face read clearly", 1)
    out = [head, subj] + ([paras[2], paras[3]] if pier else []) + ([jew] if jew else []) + paras[4:-1] + [lit]
    t = "\n\n".join(out)
    assert not re.search(r"[가-힣]", t) and not re.findall(r"\b(\w+) \1\b", t), re.findall(r"\b(\w+) \1\b", t)
    plev = base["meta"]["piercing"] if pier else "피어싱 없음"
    return t, frame, plev, info, base["title"], chosen, jew is not None

if __name__ == "__main__":
    rr = random.Random(SEED); res = []
    plan = ["waist", "hip", "waist", "hip"]
    used = set()
    for f in plan:
        cand = [b for b in BASES if b["meta"]["piercing"] in (("P25", "P50", "P100") if f == "waist" else ("P25", "P50")) and b["key"] not in used]
        b = rr.choice(cand); used.add(b["key"]); res.append(make(rr, f, b))
    json.dump([dict(t=r[0], frame=r[1], p=r[2], info=r[3], base=r[4], chosen=r[5], jew=r[6]) for r in res], open("preg_cut.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for r in res: print(r[1], r[2], r[3], r[5], r[6], len(r[0].split()))
