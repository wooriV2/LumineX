import re,random,sys
sys.path.insert(0,'.')
exec(open('mk_group_v2.py',encoding='utf-8').read().split('if __name__=="__main__":')[0])
R=random.Random(20261024)
o=["# LumineX — Face Sculpt 2·3·4·5인 샘플 4개 (인원별 1개, 귀 장식은 인물마다 다르게)\n",
"- 바뀐 점: ① **귀 장식을 인물마다 다르게** — 철 추 / 혼합 금속 추 / 단일 금속 추(금속이 서로 다름) / 대형 귀걸이 중 인물마다 서로 다른 종류를 뽑고(5인만 하나 겹침 가능), 구멍 수(1·2·3개)도 인물마다 따로 정합니다. ② **4·5인에도 실사 문구**(잔털·주근깨·비대칭·\"플라스틱처럼 매끈하지 않게\") 적용. ③ 2·3인은 지난번처럼 인물별 추 목록을 삭제하고 공통 문단을 압축.",
"- 확인할 것: (1) 인물마다 귀 장식이 서로 다르게 나오는지 (2) 4·5인에서 얼굴 구분과 눈·입술 주인공 특징이 살아 있는지 (3) 피부가 사진처럼 보이는지. 정상/이상은 번호로, 이상이면 위 번호와 인물 #번호만 알려주세요. (4·5인은 프롬프트가 길어 약해질 수 있습니다.)\n"]
for idx,n in enumerate([2,3,4,5],1):
    spec,bg,mode,t,labs=sample(R,n)
    w0=len(t.split()); t,nB=real2(t); t,k,k2=shorten(t); t=re.sub(r"  +"," ",t)
    assert not re.search(r"[가-힣]",t) and "{" not in t and nB>=n-sum(1 for kk,nm in spec if kk=="arch")
    o.append(f"## {idx}. {n}인 · "+" + ".join(nm for kk,nm in spec)+(" (45도)" if mode!="front" else " (정면)")+f" · 배경 {bg}")
    for j,l in enumerate(labs,1): o.append(f"- #{j}: {l}")
    o.append(f"- 길이: {len(t.split())}단어\n\n```\n{t}\n```\n"); print(idx,n,len(t.split()))
open(OUT+'LumineX_FaceSculpt_Group_EarMix_4.md','w',encoding='utf-8').write("\n".join(o))
