# -*- coding: utf-8 -*-
# 신규 영역 4종 샘플(각 2개): 우주·성운 / 용암·마그마 / 털실·펠트 / 수묵·서예 — mk_new_bundles 틀, 전 축 기본 랜덤
_src = open("mk_new_bundles.py", encoding="utf-8").read()
exec(_src[:_src.index('if __name__')])
LEAD = "body curving to follow her body's true three-dimensional shape, "
T_WET = LEAD + "a continuous glossy wet-look coating over her entire body, thick sheets and streams of liquid running down every curve in glistening rivulets, countless beads and droplets clinging to the surface and dripping from her chin, fingertips, hips and knees, razor-sharp bright specular highlights along every curve, nothing lying flat. Dense wet surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
def V(tag, desc, solid, nmw, T, base, acc, fin): return dict(tag=tag, desc=desc, solid=solid, nmw=nmw, T=T, base=base, acc=acc, fin=fin)
VS = [
 V("젖은 광택 · 브론즈 오일", "oil-drenched glistening bronze", "wet-look", "glistening wet bronze", T_WET,
   "BLAZING deep metallic bronze-gold pigment across the full torso both legs neck to ankle, drenched in thick clear body oil",
   "VIVID golden oil streaming in long slow rivulets and heavy oil droplets hanging from every curve", "mirror-wet glossy"),
 V("젖은 광택 · 샤워 크림슨", "shower-drenched glistening crimson", "wet-look", "glistening wet crimson", T_WET,
   "BLAZING saturated crimson-red pigment across the full torso both legs neck to ankle, soaked under a running shower",
   "VIVID streams of clear water cascading from above in sheets and bright round water beads clinging everywhere, with a fine mist of spray in the air", "mirror-wet glossy"),
 V("젖은 광택 · 빗속 블랙", "rain-drenched glistening jet-black", "wet-look", "glistening wet black", T_WET,
   "BLAZING deep jet-black pigment across the full torso both legs neck to ankle, soaked by pouring rain",
   "VIVID silver rain streaking down in bright lines, white highlights glittering on every water bead and rivulet, and splashes bursting around her feet", "mirror-wet glossy"),
]
def chk(t): return not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t) and "navel" not in t.lower()

import sys
sys.path.insert(0, "../master")
import mdefs as D
import mk_newmakeup as NM
G0 = face.__globals__["G"]; _orig_pm = G0.pick_makeup
NM.extend(G0)
NEWV["wetpaint"] = []
NEWV["crystalp"] = []
MODEMAP = {}
MODEKO = {"both": "머리+얼굴 젖음", "hair": "머리만 젖음", "none": "안 젖음"}
_prev_nv = person_nv
def person_nv(label, key, phys, age, pose, eth):
    if key not in ("wetpaint", "crystalp"): return _prev_nv(label, key, phys, age, pose, eth)
    v = CUR_VAR[(label, key)]; nmw = v["nmw"]; nm = "the wet paint"
    pn, pd = phys; p = f"{label}: " if label else ""
    md = MODEMAP.get(label, "none")
    hairtxt = hair() + (", soaking wet, slicked and clinging in wet strands" if md in ("hair", "both") else "")
    sheen = "water droplets beading across her skin and a wet glistening sheen" if md == "both" else "a soft sheen of natural oils"
    mat = v["mat"] if "mat" in v else HEAD.format(desc=v["desc"], solid=v["solid"]) + v["T"].format(base=v["base"], acc=v["acc"], fin=v["fin"])
    feat, seg, info = face(eth); skin = eth[1]
    hl = HEEL_ if HEELMODE[0] == "forty" else HEEL_REL
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of the same {nmw}, each with {hl}, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, made of the same {nmw} with a high polish."
    fc = f"{p}Face: her face and ears are NOT {nm} — they are real living flesh with real pores, {sheen} and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hairtxt} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    return "\n".join([body, shoe, nails, jw, fc]), info

LIQE = {"샤워": "shower", "오일": "oil", "빗속": "rain"}
LIQ = {"샤워": ("soaked under a running shower", VS[1]["acc"], "mirror-wet glossy", None),
       "오일": ("drenched in thick clear body oil", VS[0]["acc"], "mirror-wet glossy", None),
       "빗속": ("soaked by pouring rain", VS[2]["acc"], "mirror-wet glossy", "outdoor")}
COLS = {  # key: (영어 형용사, base 색 문장, 한글)
 "jet-black": ("jet-black", "BLAZING deep jet-black pigment across the full torso both legs neck to ankle", "블랙", "black"),
 "midnight-blue": ("midnight-blue", "BLAZING deep midnight-blue pigment across the full torso both legs neck to ankle", "미드나이트 블루", "navy"),
 "deep emerald": ("deep emerald", "BLAZING deep emerald-green pigment across the full torso both legs neck to ankle", "딥 에메랄드", "emerald"),
 "burgundy": ("burgundy", "BLAZING deep burgundy-wine pigment across the full torso both legs neck to ankle", "버건디", "burgundy"),
 "cobalt": ("cobalt", "BLAZING cobalt-blue pigment across the full torso both legs neck to ankle", "코발트", "cobalt"),
 "crimson": ("crimson", "BLAZING saturated crimson-red pigment across the full torso both legs neck to ankle", "크림슨", "crimson"),
 "bronze": ("bronze", "BLAZING deep metallic bronze-gold pigment across the full torso both legs neck to ankle", "브론즈", "bronze"),
}
def solid_v(key, liq):
    adj, base, ko, nmc = COLS[key]; how, acc, fin, _ = LIQ[liq]
    return V(f"젖은 {ko}", f"{LIQE[liq]}-drenched glistening {adj}", "wet-look", f"glistening wet {nmc}", T_WET, f"{base}, {how}", acc, fin)
CRY = {"rose": ("ROSE QUARTZ PINK", "SOFT GOLD", "rose quartz crystal", "로즈쿼츠"), "smoky": ("SMOKY GREY", "CHARCOAL", "smoky quartz crystal", "스모키쿼츠")}
def crystal_v(key):
    c1, c2, sh, ko = CRY[key]
    mat = (f"full body {sh} clusters growing directly out of her own skin covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, every crystal point erupting outward from beneath the surface of her living skin in true three-dimensional relief, each facet catching its own individual glint and casting its own small hard shadow onto the skin and onto neighbouring crystals, nothing lying flat. Dense overlapping clusters — BLAZING {c1} crystal points erupting across the full torso both legs neck to ankle, VIVID {c2} mineral veins and undertone glinting through the thinnest points filling every remaining gap with real depth and texture, each facet sharply faceted and distinct, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    return dict(tag=f"석영 {ko}", nmw=sh, mat=mat, desc=sh, solid="crystal")
# (이름, 인원, 액체, [(종류, 키)])  종류: solid=젖은 단색, bodypaint/irezumi/uvneon=일반(젖지 않은) 바디페인팅

import json, collections
_g = open("../master/gen_extreme.py", encoding="utf-8").read()
exec(_g[_g.index("B_INS = ("):_g.index("PAINT_S")])
STY = ['코갸루', '마이코', '경극', '혼례(연지곤지)', '둔황 비천풍', '글래스 스킨', '강남언니', '인스타글램', '구풍', '홍콩풍', '아마갸루', '걸크러시', '지뢰계', '야마바', '만바', '반바', '아게하',
       '히메갸루', '오네에갸루', '로리타 갸루', '야미카와', '데코라', '웨이쉰', '브리티시 모드']
G0.pick_makeup = (lambda _r, style=None: _orig_pm(_r, style=_r.choice(STY)))
FULL = "across the full torso both legs neck to ankle"

# ── 새 재질 7종 템플릿 ──
FULL = "across the full torso both legs neck to ankle"
T_ICE = LEAD + "a body-wide shell of clear and frosted ice, thick translucent ice plates and crusted hoarfrost with sharp feathery frost crystals growing outward along every curve, clear icicles hanging from her fingertips, hips and knees, cold light refracting through the ice, nothing lying flat. Dense icy surface — {base}, {acc}, {fin}, completely covering her whole body, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_FEATHER = LEAD + "layers of real feathers overlapping like plumage, small downy feathers over the torso and long sweeping quill feathers along her arms, hips and legs, every feather with its own shaft and fine barbs ruffling at the edges and casting small shadows on the feathers below, nothing lying flat. Dense plumage surface — {base}, {acc}, {fin}, completely covering her whole body, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_HENNA = "intricate hand-drawn henna mehndi patterns in dark reddish-brown paste applied directly to her skin and wrapping around every curve, dense lace-like paisleys, floral vines, mandalas and fine dot-work with delicate line work, the paste slightly raised in fine dark lines, no area of skin left plain. Dense henna surface — {base}, {acc}, {fin}, covering her whole body, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_CIRC = LEAD + "a dense printed-circuit surface grown over her entire body, raised copper traces and solder pads running in tidy right-angled lines over every curve, tiny glowing LED points and small rectangles of black silicon chips set into the surface, hair-thin lines of light pulsing along the traces, nothing lying flat. Dense circuit surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_NACRE = LEAD + "overlapping mother-of-pearl nacre tiles set edge to edge over her whole body, each tile with a fine edge and a soft milky lustre that shifts through rainbow colours across every curve, hard bright highlights, nothing lying flat. Dense nacre surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_WING = LEAD + "thin translucent insect-wing membranes layered over her whole body like overlapping dragonfly and butterfly wings, a network of fine dark veins and cells running through each wing, iridescent colour shifting across every curve, wing edges fringed with tiny scales, nothing lying flat. Dense wing surface — {base}, {acc}, {fin}, completely covering her whole body, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_MIRROR = LEAD + "hundreds of broken mirror shards of all sizes mosaicked over her entire body, each shard with sharp straight edges set at a different angle and reflecting a different piece of the surroundings, thin dark grout lines between the shards, sharp white glints flashing off every edge, nothing lying flat. Dense mirror-mosaic surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
HEAD_H = HEAD.replace("fused directly to", "drawn directly onto").replace("not a printed pattern, this is a solid {solid} ", "not a sticker, this is {solid} ")
def AV(tag, desc, solid, nmw, T, base, acc, fin, part, head=None):
    return dict(tag=tag, desc=desc, solid=solid, nmw=nmw, T=T, base=base, acc=acc, fin=fin, part=part, head=head or HEAD)
N_ICE = AV("얼음·서리", "ice-and-frost-encrusted", "shell of glacial ice", "clear frosted ice", T_ICE, f"BLAZING pale glacier-blue ice plates and white hoarfrost {FULL}", "VIVID crisp white frost crystals fanning out from the edges and clear icicles hanging from her fingertips, hips and knees, with a faint breath-mist drifting", "glassy frozen", "the ice")
N_FEA = AV("깃털 · 레이븐 블랙", "feather-covered", "coat of plumage", "glossy black feathers", T_FEATHER, f"BLAZING glossy raven-black plumage with an oil-slick purple and green sheen {FULL}", "VIVID long sweeping quill feathers trailing from her arms and hips and loose down floating in the air around her", "glossy feathered", "the plumage")
N_HEN = AV("헤나·메헨디", "henna-patterned", "a layer of henna mehndi lace-work", "henna-brown lacquer", T_HENNA, f"BLAZING deep reddish-brown henna lace-work {FULL}", "VIVID large mandala medallions on her torso and thighs, with fine dot-work and tiny floral sprigs filling every gap", "dark glossy paste", "the henna", HEAD_H)
N_CIR = AV("회로·사이버", "circuit-board", "circuit-board surface", "black circuit-board lacquer", T_CIRC, f"BLAZING matte black circuit-board surface with gold copper traces {FULL}", "VIVID electric cyan light pulses racing along the traces and small glowing LED points scattered across her torso", "etched circuitry", "the circuit board")
N_NAC = AV("진주층", "mother-of-pearl", "mother-of-pearl nacre shell", "mother-of-pearl", T_NACRE, f"BLAZING milky pearl-white nacre with pink and aqua lustre {FULL}", "VIVID soft rainbow sheen sliding across each tile and a few larger shell-pearl bumps", "polished nacre", "the nacre")
N_WIN = AV("곤충 날개", "insect-wing-covered", "layer of insect-wing membrane", "iridescent wing membrane", T_WING, f"BLAZING iridescent green-gold and violet dragonfly-wing membranes {FULL}", "VIVID dark vein networks and tiny scale-dust shimmer along the wing edges", "iridescent wing", "the wings")
N_MIR = AV("거울 파편 모자이크", "mirror-shard-mosaic", "mosaic of broken mirror shards", "mirror shards", T_MIRROR, f"BLAZING silver mirror shards {FULL}", "VIVID bright white glints off the shard edges and a few shards tinted gold and rose", "razor-edged mirror", "the mirror")

POSES = [p for p in POSES if "arms crossed under her bust" not in p and "framing the face" not in p]
def mat_of(v): return v["head"].format(desc=v["desc"], solid=v["solid"]) + v["T"].format(base=v["base"], acc=v["acc"], fin=v["fin"])
NEWV["areap"] = []
_prev_a = person_nv
def person_nv(label, key, phys, age, pose, eth):
    if key != "areap": return _prev_a(label, key, phys, age, pose, eth)
    v = CUR_VAR[(label, key)]; nmw = v["nmw"]; nm = v["part"]
    pn, pd = phys; p = f"{label}: " if label else ""
    mat = mat_of(v)
    feat, seg, info = face(eth); skin = eth[1]
    hl = HEEL_ if HEELMODE[0] == "forty" else HEEL_REL
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of the same {nmw}, each with {hl}, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, made of the same {nmw} with a high polish."
    fc = f"{p}Face: her face and ears are NOT {nm} — they are real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair()} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    return "\n".join([body, shoe, nails, jw, fc]), info
PLAN = [("얼음·서리 솔로", [N_ICE]), ("깃털 솔로", [N_FEA]), ("헤나·메헨디 솔로", [N_HEN]), ("회로·사이버 솔로", [N_CIR]), ("진주층 솔로", [N_NAC]), ("곤충 날개 솔로", [N_WIN]), ("거울 파편 모자이크 솔로", [N_MIR])]
rg = random.Random(20261401); rr.seed(20261401); ns2["JR"].seed(20261401)
o1 = ["# 새 재질 7종 샘플 — 얼음·서리 / 깃털 / 헤나 / 회로·사이버 / 진주층 / 곤충 날개 / 거울 파편 (각 솔로 1)\n", "Material Mix와 같은 기본 랜덤입니다(체형·나이·포즈·인종·배경·힐·네일·주얼리·메이크업). 번호별로 정상/이상만 알려주세요. 이상이면 한 줄만요.\n"]
for gi, (name, vs) in enumerate(PLAN, 1):
    n = len(vs)
    for attempt in range(800):
        CUR_VAR.clear()
        if n == 1:
            v = vs[0]; phys = rg.choices(BIG5, W5)[0]; age = rg.choice(AGES); pose = rg.choice(POSES); eth = rg.sample(ETH, 1)[0]
            bid, wx = BGL.pick(rg, 1); scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
            HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
            ns2["JR"].seed(rg.randrange(10**9))
            body, info = assemble(mat_of(v), v["nmw"], "part of the figure", phys, age, pose, eth)
            env = f"{scene}, bright and evenly lit, shadows soft, the whole floor and surroundings clearly visible and in focus, NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as her."
            tail = f"Background: {env} ONE woman only. Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
            t = f"Professional fashion photograph, full body shot. ONE woman standing.\n\n{body}\n\n{tail}{CAM} 8K portrait {ASP[1]} aspect ratio."
            bodies = [phys[0]]; eths = [eth[0]]; infos = [info]
        else:
            kinds = []; picks = []
            for idx, v in enumerate(vs): CUR_VAR[(f"#{idx+1}", "areap")] = v; kinds.append("areap"); picks.append(v)
            physs = []
            while len(physs) < n:
                c = rg.choices(BIG5, W5)[0]
                if c not in physs: physs.append(c)
            ages = [rg.choice(AGES) for _ in range(n)]; poses = [rg.choice(POSES) for _ in range(n)]; eths_ = rg.sample(ETH, n)
            bid, wx = BGL.pick(rg, n); scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
            HEELMODE[0] = "forty"
            ns2["JR"].seed(rg.randrange(10**9))
            t, infos = build3(list(kinds), picks, physs, ages, poses, eths_, scene)
            t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as any of them.", 1)
            bodies = [x[0] for x in physs]; eths = [e[0] for e in eths_]
        if not chk(t): continue
        break
    else: raise SystemExit("fail " + name)
    hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
    mats = " / ".join(v["tag"] for v in vs)
    o1.append(f"## {gi}. {name} · {mats} · 체형 {', '.join(bodies)} · 인종 {', '.join(eths)} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko}\n\n```\n{t}\n```\n")
    print(gi, name, len(t.split()), t.count("forty inches"))
open(O + "LumineX_NewMat7_Solo.md", "w", encoding="utf-8").write("\n".join(o1))
