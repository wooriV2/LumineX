import re
OLD = "with three breasts — a matching pair in the usual place and a third full breast centred directly below the pair, all three the same size and shape and all fully covered by the UV bodypaint,"
BASE = """Professional fashion photograph, full body shot. ONE woman standing.

THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, mid 30s goddess, super hourglass physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum beyond any proportion, %s most dramatic hourglass ratio ever recorded on any human body, thighs so thick pressing together, UV-reactive BLAZING ELECTRIC MAGENTA locs mid-length tousled — full body UV neon dragon formations bodypaint covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Bold formations — BLAZING ELECTRIC MAGENTA dragon coiling the full torso both legs neck to ankle, VIVID NEON GREEN dragon flame formations filling every gap, STARK WHITE eye highlights, NO airbrush NO gradient wash. Pose: strong hip pop right, both hands pressing outer hips outward simultaneously arching back to extreme — most extreme super hourglass silhouette ever displayed.
Footwear: magenta green platform thigh-high boots 8 inch.
Nails: extra long stiletto nails BLAZING NEON MAGENTA GREEN UV reactive tips.
Hair: UV-reactive magenta locs mid-length tousled.

MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. UV blacklight illumination only — zero white light. ONE woman only. Multiple UV blacklights from all angles making every formation glow at maximum intensity%s. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle. BLAZING UV NEON MAGENTA GREEN on blue-black void skin dragon contrast. Extreme high-gloss oil. 2:3 vertical 8K portrait. portrait 2:3 vertical."""
V = [
 ("A. 가로 한 줄 (좌·중·우)",
  "with three breasts in a single horizontal row across the chest — left, centre and right, the centre breast sitting directly between the other two on exactly the same level, all three exactly equal in size, shape and fullness and evenly spaced, none lower or smaller than the others, all three fully covered by the UV bodypaint,", ""),
 ("B. 기존 쌍 사이에 셋째 삽입",
  "with three identical full breasts side by side — a matching pair in the usual place and a third breast of exactly the same size placed in the middle between them on the same horizontal line, so the three sit in one row with the middle breast centred on the breastbone, no breast lower than the others, all three fully covered by the UV bodypaint,", ""),
 ("C. 가로 한 줄 + 세 가슴 모두 조명",
  "with a wide chest carrying three breasts of exactly equal size and volume in one horizontal row — left, middle and right, the middle one centred between the other two at the same height, the three clearly reading as three equal rounded forms side by side, all three fully covered by the UV bodypaint,",
  ", with the blacklights angled so that all three breasts are lit equally and their rounded outlines are clearly visible, the middle breast glowing as brightly as the left and right ones"),
]
o = ["# LumineX 가슴 3개 — 네온 가로 한 줄 배치 3종\n", "블루블랙 피부 · 30대 중반 · 슈퍼 아워글래스 · 마젠타 드래곤 UV 네온 · 가슴 3개 (가로 한 줄 배치)\n"]
for i,(lab,a,b) in enumerate(V,1):
    p = BASE % (a,b)
    assert not re.search(r"[가-힣]", p) and OLD not in p
    o += [f"\n## {i}. {lab}\n", "```", p, "```"]
open("/mnt/user-data/outputs/LumineX_ThreeBreasts_Neon_Row3.md","w",encoding="utf-8").write("\n".join(o)+"\n")
print("ok")
