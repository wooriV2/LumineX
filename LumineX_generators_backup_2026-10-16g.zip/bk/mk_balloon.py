# -*- coding: utf-8 -*-
# 블록 조립(장난감 조립 블록) 샘플 — mk_new_bundles 틀, 전 축 기본 랜덤
_src = open("mk_new_bundles.py", encoding="utf-8").read()
exec(_src[:_src.index('if __name__')])
BT_TWIST = ("body made of many long glossy latex balloons twisted into segments, each segment a taut inflated tube bulging in the middle and pinched into small twist-knots where it meets the next, the segments swelling and tapering along her curves so the whole figure still follows her body's true three-dimensional shape, tight stretched latex with sharp bright specular highlights and faint wrinkles around every twist-knot, nothing lying flat. Dense balloon surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
BT_VINYL = ("body made of puffy air-filled glossy vinyl inflatable chambers, plump rounded chambers separated by sealed seam lines, swelling and tapering along her curves so the whole figure still follows her body's true three-dimensional shape, taut stretched vinyl with sharp bright specular reflections and a small round air valve at her hip, nothing lying flat. Dense inflated surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
def blk(nm, desc, base, acc, tag, kind, T, solid, nmw, fin):
    return dict(kind=kind, tag=tag, desc=desc, solid=solid, nm=nm, nmw=nmw, base=base, acc=acc, fin=fin, T=T)
BLOCKS = [
 blk("balloon", "twisted glossy latex balloon sculpture",
     "BLAZING glossy hot-pink latex balloons across the full torso both legs neck to ankle",
     "VIVID a few shiny gold metallic balloons twisted in as bold stripes along her sides, and bright white highlights gleaming on every taut balloon", "풍선 꼬임 (라텍스)", "balloon_twist",
     BT_TWIST, "balloon-twist", "latex balloons", "high-gloss taut latex"),
 blk("vinyl", "glossy inflatable vinyl sculpture",
     "BLAZING glossy aqua-blue vinyl across the full torso both legs neck to ankle",
     "VIVID bright white sealed seam lines between every chamber, a yellow air valve at her hip, and bright white highlights gleaming on every plump chamber", "비닐 에어 인플레이터블", "balloon_vinyl",
     BT_VINYL, "inflatable vinyl", "inflatable vinyl", "high-gloss taut vinyl"),
]
def mat_blk(v): return HEAD.format(desc=v["desc"], solid=v["solid"]) + v["T"].format(base=v["base"], acc=v["acc"], fin=v["fin"]), v["nmw"], "part of the inflated figure"
def chk(t): return not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t) and "navel" not in t.lower()
rg = random.Random(20261115); rr.seed(20261115); ns2["JR"].seed(20261115)
o1 = ["# 풍선 샘플 2개 — 라텍스 꼬임 풍선 · 비닐 에어 인플레이터블\n", "Material Mix와 같은 기본 랜덤입니다(체형·나이·포즈·인종·배경·힐·네일·주얼리). 번호별로 정상/이상만 알려주세요. 이상이면 한 줄만요.\n"]
for i, v in enumerate(BLOCKS, 1):
    for _ in range(500):
        phys = rg.choices(BIG5, W5)[0]; age = rg.choice(AGES); pose = rg.choice(POSES); eth = rg.sample(ETH, 1)[0]
        bid, wx = BGL.pick(rg, 1); scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
        ns2["JR"].seed(rg.randrange(10**9))
        mat, nmw, part = mat_blk(v)
        body, info = assemble(mat, nmw, part, phys, age, pose, eth)
        env = f"{scene}, bright and evenly lit, shadows soft, the whole floor and surroundings clearly visible and in focus, NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as her."
        tail = f"Background: {env} ONE woman only. Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
        t = f"Professional fashion photograph, full body shot. ONE woman standing.\n\n{body}\n\n{tail}{CAM} 8K portrait {ASP[1]} aspect ratio."
        if chk(t): break
    hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
    o1.append(f"## {i}. {v['tag']} 솔로 · 체형 {phys[0]} · 인종 {eth[0]} · {info} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko}\n\n```\n{t}\n```\n")
    print(i, len(t.split()), "forty" in t)
open(O + "LumineX_Balloon_Sample_2.md", "w", encoding="utf-8").write("\n".join(o1))
