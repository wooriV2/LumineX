# -*- coding: utf-8 -*-
# 4~5인 이레즈미·UV네온(신발 색 일치) + 바디페인팅 쿼텟(힐 40인치) + 옵시디언 트리오(힐 40인치) — 4개
import re
src = open("gen_heel_ab_tracks8.py", encoding="utf-8").read()
exec(src[:src.index("o = [")])
exec(open("gen_heel_color3.py", encoding="utf-8").read().split("NOTDARK =")[0].split("exec(src")[1].split("\n",1)[1])
NOTDARK = "NOT black, NOT dark, NOT plain — the footwear must be a bright, saturated, glossy colour taken straight from her own body art"
def per_person_n(t, shoe_re, make, n_exp):
    cols = {}
    for l in t.split("\n"):
        m = re.match(r"#(\d): THE ABSOLUTE", l)
        if m:
            cols[m.group(1)] = colors(l); assert len(cols[m.group(1)]) >= 2, (m.group(1), cols[m.group(1)])
    def f(m):
        k = m.group(1); c = cols[k]
        return make(k, f"{c[0]} and {c[1]}" if len(c) < 3 else f"{c[0]}, {c[1]} and {c[2]}", m)
    t, n = re.subn(shoe_re, f, t); assert n == n_exp, n
    return t
def mx_color_n(t, n):
    return per_person_n(t, r"#(\d): platform boots 8 inch, extra long stiletto nails",
        lambda k, c, m: f"#{k}: thigh-high platform stiletto boots entirely in the exact same colours as her own body art — {c} — {NOTDARK}, each with {HEEL('num')}, {BODYLIFT}, extra long stiletto nails", n)
def obs_fix(t):
    t, k = re.subn(r"extreme platform boots carved from the same glossy obsidian with gold seams", f"extreme platform boots carved from the same glossy obsidian with gold seams, each with {HEEL('num')}, {BODYLIFT}", t)
    assert k == 3, k
    return t
def core4_fix(t):
    def f(m):
        lead, desc = m.group(1), re.sub(r"^[Ee]xtreme ", "", m.group(2))
        return f"{lead}ootwear: the most absurdly extreme heels imaginable — {desc}, each with {HEEL('num')}, {BODYLIFT}."
    t, k = re.subn(r"((?:[Ff]ar-left woman's f|[Ll]eft woman's f|[Rr]ight woman's f|[Ff]ar-right woman's f|[Cc]enter woman's f|F))ootwear: (.*?), the platform soles rising far higher than her ankle bone, at least three times the thickness of an ordinary heel\.", f, t)
    assert k == 4, k
    return t
SETS = [("이레즈미 쿼텟 · 신발 색 일치", mx["la_irezumi_quartet_01"], lambda t: put_low(mx_color_n(t["prompt"], 4)) if False else None),]
items = [
 ("이레즈미 쿼텟(4인) · 힐 40인치 + 신발 색 일치", mx["la_irezumi_quartet_01"], lambda p: put_low(mx_color_n(p["prompt"], 4))),
 ("UV네온 퀸텟(5인) · 힐 40인치 + 신발 색 일치", mx["la_uvneon_quintet_01"], lambda p: put_low(mx_color_n(p["prompt"], 5))),
 ("바디페인팅 쿼텟(4인) · 힐 40인치", core["la_core_quartet_01"], lambda p: p and (lambda t: t.rstrip("\n") + LOW)(core4_fix(p["prompt"]))),
 ("옵시디언 트리오(3인) · 힐 40인치", d120["la_obsidian_trio_01"], lambda p: put_low(obs_fix(p["prompt"]))),
]
o = ["# 4~5인 극단 힐 확장 시험 (4개) — 이레즈미 4인 · UV네온 5인 · 바디페인팅 4인 · 옵시디언 3인\n",
     "등록 프롬프트의 신발 문장만 40인치 힐 + 발끝 서기 표현으로 바꿨습니다. 이레즈미·UV네온은 인물별 몸 패턴 색을 신발 색으로 지정했고(검정·어두운 색 금지), 바디페인팅은 원래 인물별 신발 색이 적혀 있어 그대로 두었고, 옵시디언은 검정 유리 신발이 원래 의도라 색 지정 없이 힐만 바꿨습니다. 번호별로 정상/이상, 그리고 신발이 인물별 몸 색과 맞는지(1·2번), 힐이 확실히 높은지만 알려주세요.\n"]
for i, (ti, p, fx) in enumerate(items, 1):
    t = fx(p); assert not re.search(r"[가-힣]", t) and "forty inches" in t
    o.append(f"## {i}. {ti} · {phys(p)}\n\n```\n{t}\n```\n"); print(i, ti, len(t.split()))
    for l in t.split("\n"):
        if re.search(r"(thigh-high platform|ootwear: the most|obsidian with gold seams, each)", l): print("   ", l[:230])
open(O + "LumineX_Heel_Big4.md", "w", encoding="utf-8").write("\n".join(o))
