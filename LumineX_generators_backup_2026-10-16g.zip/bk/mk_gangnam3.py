import re,random
exec(open('mk_trio_arch.py',encoding='utf-8').read().split("SPECS=")[0])
G.NATS.clear(); G.NATS["한국"]="Korean"
G.C.INT=""
def pick_style(rr,N,tusk): return "강남언니"
def make_base(rr,nat,grp,expr,style,N):
    for tr in range(80):
        try: return G.make(random.Random(rr.randrange(10**9)),nat,grp,expr,style=style,slots=["pierce"],pier_level="P150" if N>=100 else ("P50" if N>=50 else "P25"))
        except AssertionError: continue
    raise SystemExit("gen fail")
print([n for n,c in EYEP][:6])
spec=[("eye",EYEP[0][0]),("lip","큐피드 보우"),("eye",EYEP[1][0])]
rr=random.Random(4242)
for tr in range(300):
    try: t,labs,dup=group3(rr.randrange(10**7),spec,"front","mix",2,BGN[0])
    except AssertionError: continue
    break
t=real(t,spec)
for a,b in [("the eyes are in coloured doll-eye contact lenses with a big iris","the eyes have a big dark iris"),("in luminous coloured contact lenses with a big visible iris","with a big visible dark iris")]:
    t=t.replace(a,b)
assert 'contact lens' not in t
assert not re.search(r"[가-힣]",t)
labs=[re.sub(r"강남언니\([^)]*\)","강남언니(포인트)",l) for l in labs]
print(labs); print(len(t.split()))
print(t.count("precise winged liner"), t.count("Korean woman"), t.count("peach-fuzz"))
o="# LumineX — 한국인 강남언니 3인 (일반 인물, 같은 메이크업)\n\n- 인물을 브랫츠에서 한국인 일반 인물 3명으로 바꿨습니다. 세 명 모두 메이크업 리스트의 **강남언니(포인트)** 이고, 얼굴 강조(눈·입술)는 번들 그대로입니다. 귀 추는 혼합 금속, 구멍 2개. 사람 같은 느낌을 보려고 컬러 렌즈는 이번에만 모두 뺐습니다(눈 강조 항목 속 렌즈 문장은 '큰 짙은 홍채'로 교체).\n- 정상/이상 + 피부가 고무 같은지, 직전 브랫츠 강남언니 3인과 비교해 어느 쪽이 더 사실적인지만 알려주세요.\n\n"+"\n".join(f"- #{j}: {l}" for j,l in enumerate(labs,1))+"\n\n```\n"+t+"\n```\n"
open(OUT+'LumineX_Korean3_GangnamUnni_1.md','w',encoding='utf-8').write(o)
