# -*- coding: utf-8 -*-
# 새 재질 6종 번들 300 (솔로60 + 같은 재질 2~5인 120 + 섞은 재질 2~5인 120) + 새 색 확인 샘플 6
_A4 = open("mk_area4_bundle.py", encoding="utf-8").read()
exec(_A4[:_A4.index("# ── 변형표 ──")], globals())
exec(open("../newmat_defs.py", encoding="utf-8").read(), globals())
POSES = [p for p in POSES if "arms crossed under her bust" not in p and "framing the face" not in p]
THIN = {"curvy petite", "wide hip narrow"}
BODIES22 = [b for b in BODIES22 if b[0] not in THIN]
exec(_A4[_A4.index("def one("):_A4.index("def make_title(")], globals())
import json, collections
import os
EXCL = set(json.load(open("mat6_excl.json", encoding="utf-8"))) if os.path.exists("mat6_excl.json") else set()
def VR(fam, ko, src, base=None, acc=None, nmw=None):
    d = dict(src); d["fam"] = fam; d["ko"] = ko
    if base: d["base"] = f"BLAZING {base} {FULL}"
    if acc: d["acc"] = f"VIVID {acc}"
    if nmw: d["nmw"] = nmw
    return d
MATS = {
 "ice": ("얼음·서리", "Ice", [VR("ice", "글레이셔 블루", N_ICE), VR("ice", "딥 사파이어", N_ICE, "deep sapphire-blue clear ice plates and white hoarfrost")]),
 "feather": ("깃털", "Feather", [VR("feather", "레이븐 블랙", N_FEA), VR("feather", "스노우 화이트", N_FEA, "snow-white plumage with blush-pink tips", "long sweeping white quill feathers trailing from her arms and hips and loose white down floating in the air around her", "soft white feathers")]),
 "circuit": ("회로·사이버", "Circuit", [VR("circuit", "블랙 골드", N_CIR), VR("circuit", "화이트 세라믹", N_CIR, "glossy white ceramic circuit-board surface with silver traces", "magenta light pulses racing along the traces and small glowing LED points scattered across her torso", "white ceramic circuit-board lacquer")]),
 "nacre": ("진주층", "Nacre", [VR("nacre", "펄 화이트", N_NAC), VR("nacre", "블랙 타히티", N_NAC, "black Tahitian-pearl nacre with green and violet lustre", "soft peacock-green and violet sheen sliding across each tile and a few larger shell-pearl bumps", "black pearl nacre")]),
 "wing": ("곤충 날개", "Wing", [VR("wing", "잠자리 그린골드", N_WIN), VR("wing", "모르포 블루", N_WIN, "iridescent electric-blue morpho butterfly-wing membranes", "dark vein networks and tiny scale-dust shimmer along the wing edges")]),
 "mirror": ("거울 파편", "Mirror", [VR("mirror", "실버", N_MIR), VR("mirror", "골드 틴트", N_MIR, "gold-tinted mirror shards", "bright white glints off the shard edges and a few shards tinted rose and silver", "gold-tinted mirror shards")]),
}
CATS = {k: f"🏺 Living Artifact · {v[1]} Formula" for k, v in MATS.items()}; CATS["mix"] = "🏺 Living Artifact · Six-Material Mix Formula"
PREF = {k: f"la_{k}_" for k in MATS}; PREF["mix"] = "la_m6mix_"
NAMES = {1: "solo", 2: "duo", 3: "trio", 4: "quartet", 5: "quintet"}; KOCNT = {1: "솔로", 2: "듀오", 3: "트리오", 4: "쿼르텟", 5: "퀸텟"}
def vlist(m): return [v for v in MATS[m][2] if (m, v["ko"]) not in {tuple(x.split("|")) for x in EXCL}]
# ── 새 색 확인 샘플 6 ──
rg = random.Random(20261501); rr.seed(20261501); ns2["JR"].seed(20261501)
SEEN = set()
chk_o = ["# LumineX — 새 재질 6종 · 추가 색 확인 샘플 6개 (재질당 새 색 1개, 솔로)\n", "전 축 기본 랜덤입니다. 번호별 성공/실패만 알려주세요.\n"]
for i, m in enumerate(MATS, 1):
    v = MATS[m][2][1]
    r = one(m, 1, [v])
    chk_o.append(f"## {i}. {MATS[m][0]} · {v['ko']} · 체형 {r['bodies'][0]} · 인종 {r['eths'][0]} · 배경 {BGL.BG[r['bid']][2]} · {'힐 40인치' if r['heel']=='forty' else '힐 숫자 없음'}\n\n```\n{r['t']}\n```\n")
open(O + "LumineX_NewMat6_ColorCheck6.md", "w", encoding="utf-8").write("\n".join(chk_o))
# ── 번들 ──
rg = random.Random(20261502); rr.seed(20261502); ns2["JR"].seed(20261502)
SEEN = set()
def title_of(r, k, ser, mats):
    n = r["n"]; vs = r["vars"]
    body = r["bodies"][0] if n == 1 else agg(r["bodies"])
    if ser == "mix": mat = "+".join(MATS[m][0] for m in mats)
    else:
        c = collections.Counter(v["ko"] for v in vs); mat = MATS[ser][0] + " " + "+".join(f"{a}×{c[a]}" if c[a] > 1 else a for a in dict.fromkeys(v["ko"] for v in vs))
    poses = pose_ko(r["poses"][0]) if n == 1 else ""
    name = "Mix6" if ser == "mix" else MATS[ser][1]
    return " · ".join(x for x in [f"{name} {KOCNT[n]} #{k:03d}", body, mat, poses, BGL.BG[r["bid"]][2], agg(r["mk"])] if x)
out = []
def add(r, ser, k, mats):
    n = r["n"]
    meta = {"group_size": n, "aspect_ratio": r["asp"], "format": "newmat6", "kind": ("mixed" if ser == "mix" else "solid"), "areas": [v["fam"] for v in r["vars"]], "variants": [v["ko"] for v in r["vars"]],
            "physiques": r["bodies"], "ethnicity": r["eths"], "poses": r["poses"], "background": r["bid"], "weather": r["wx"][0] if r["wx"] else None, "heel_mode": r["heel"], "jewelry": True}
    out.append({"key": f"{PREF[ser]}{NAMES[n]}_{k:03d}", "category": CATS[ser], "title": title_of(r, k, ser, mats), "prompt": r["t"], "meta": meta})
for m in MATS:
    L = vlist(m)
    for k in range(1, 11): add(one(m, 1, [rg.choice(L)]), m, k, [m])
    for n in (2, 3, 4, 5):
        for k in range(1, 6): add(one(m, n, [rg.choice(L) for _ in range(n)]), m, k, [m])
for n in (2, 3, 4, 5):
    for k in range(1, 31):
        ms = rg.sample(list(MATS), n)
        add(one("mix", n, [rg.choice(vlist(m)) for m in ms]), "mix", k, ms)
assert len(out) == 300 and len({p["key"] for p in out}) == 300 and len({p["prompt"] for p in out}) == 300
json.dump(out, open(O + "la_newmat6_300_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(out), collections.Counter(p["category"] for p in out)); print("max title", max(len(p["title"]) for p in out))
