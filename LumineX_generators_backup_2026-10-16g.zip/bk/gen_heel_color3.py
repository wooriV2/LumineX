# -*- coding: utf-8 -*-
# 이레즈미·UV네온·왁스 트리오 — 힐 40인치 + 신발을 각자 몸 패턴 색으로 지정 (3개)
import re
src = open("gen_heel_ab_tracks8.py", encoding="utf-8").read()
exec(src[:src.index("o = [")])
def colors(body):
    seg = body.split("ANYWHERE", 1)[1].split("Pose:", 1)[0]
    runs = re.findall(r"\b[A-Z]{3,}(?:[ -][A-Z]{3,})*\b", seg)
    out = []
    for r in runs:
        r = r.lower()
        if r not in out: out.append(r)
    return out[:3]
def per_person(t, shoe_re, make):
    lines = t.split("\n"); cols = {}
    for l in lines:
        m = re.match(r"#(\d): THE ABSOLUTE", l)
        if m: cols[m.group(1)] = colors(l); assert len(cols[m.group(1)]) >= 2, (m.group(1), cols[m.group(1)])
    def f(m):
        k = m.group(1); c = cols[k]
        return make(k, " and ".join(c[:2]) if len(c) < 3 else f"{c[0]}, {c[1]} and {c[2]}", m)
    t, n = re.subn(shoe_re, f, t); assert n == 3, n
    return t
NOTDARK = "NOT black, NOT dark, NOT plain — the footwear must be a bright, saturated, glossy colour taken straight from her own body art"
def mx_color(t):
    return per_person(t, r"#(\d): platform boots 8 inch, extra long stiletto nails",
        lambda k, c, m: f"#{k}: thigh-high platform stiletto boots entirely in the exact same colours as her own body art — {c} — {NOTDARK}, each with {HEEL('num')}, {BODYLIFT}, extra long stiletto nails")
def wax_color(t):
    return per_person(t, r"#(\d): extreme platform heels entirely coated in the same hardened wax drips",
        lambda k, c, m: f"#{k}: extreme platform heels entirely coated in the same hardened wax drips in {c}, {NOTDARK}, each with {HEEL('num')}, {BODYLIFT}")
o = ["# 트리오 힐 40인치 + 신발 색을 몸 패턴과 일치 (이레즈미 · UV네온 · 왁스, 3개)\n",
     "직전 40인치 프롬프트에서 신발이 어둡게 나와서, 각 인물의 몸 패턴 색을 그대로 신발 색으로 지정하고 '검정·어두운 색 금지'를 넣었습니다. 나머지는 직전과 같습니다. 번호별로 정상/이상, 신발 색이 패턴과 맞는지만 알려주세요.\n"]
n = 0
for tr, p, fix in [("이레즈미", mx["la_irezumi_trio_01"], mx_color), ("UV네온", mx["la_uvneon_trio_01"], mx_color), ("왁스", d120["la_wax_trio_01"], wax_color)]:
    t = fix(p["prompt"]); t = put_low(t); n += 1
    assert not re.search(r"[가-힣]", t) and "forty inches" in t
    o.append(f"## {n}. {tr} 트리오 · {phys(p)} · 힐 40인치 + 신발 색 일치\n\n```\n{t}\n```\n"); print(n, tr, len(t.split()))
    for l in t.split("\n"):
        if re.match(r"#\d: (thigh-high|extreme platform)", l): print("   ", l[:260])
open(O + "LumineX_Trio_HeelColor3.md", "w", encoding="utf-8").write("\n".join(o))
