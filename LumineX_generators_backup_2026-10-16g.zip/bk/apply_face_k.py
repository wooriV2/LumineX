# -*- coding: utf-8 -*-
# 한국형 솔로·듀오(group_size<=2) 프롬프트의 각 인물 단락에 얼굴 사실감 문장(Face: ...)을 " Pose: " 앞에 삽입.
# 실버폭스는 나이 주름 문장, 20대는 주름 없는 문장. 국제형·트리오 이상은 건드리지 않는다.
import json, re, sys
core = ("a real photograph of a real woman's face, not an illustration and not a CG render — visible pores and fine skin grain, {skin}, "
        "faint peach-fuzz hairs catching the light, natural tonal variation with a soft flush on the cheeks, a few small natural beauty marks, slight natural asymmetry, "
        "eyes with real wet catchlights and individual lashes, lips with real vertical texture — never airbrushed, never smooth like plastic. ")
F_S = "Face: " + core.format(skin="the fine natural expression lines of her age around the eyes and mouth")
F_Y = "Face: " + core.format(skin="youthful, smooth, fresh skin with no visible wrinkles")
def apply(t):
    out = []; n = 0
    for line in t.split("\n"):
        if " Pose: " in line:
            F = F_Y if re.search(r"(early|mid|late) 20s", line[:500]) else F_S
            line = line.replace(" Pose: ", " " + F + "Pose: ", 1); n += 1
        out.append(line)
    return "\n".join(out), n
def apply_bundle(N):
    cnt = 0
    for p in N:
        if p["meta"]["kind"] == "K" and p["meta"]["group_size"] <= 2:
            t, n = apply(p["prompt"]); assert n == p["meta"]["group_size"], p["key"]
            p["prompt"] = t; cnt += 1
    return cnt
if __name__ == "__main__":
    src, dst = sys.argv[1], sys.argv[2]
    N = json.load(open(src, encoding="utf-8")); c = apply_bundle(N)
    json.dump(N, open(dst, "w", encoding="utf-8"), ensure_ascii=False, indent=1); print("applied", c)
