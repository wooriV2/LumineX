# -*- coding: utf-8 -*-
import random, re
import cjk_face_lib as C
F, MK = C.load(); MK.update(C.BLACK_MK)
NAT = {"한국": "Korean", "중국": "Chinese", "일본": "Japanese"}
LEN = "stuck out to a natural, realistic length with the tip reaching just below the lower lip"
QUAD = "the tongue split into four narrow pointed strands from the tip back about two-thirds of its length, the strands fanned slightly apart"
RING = ", a small matching ring through the tip of each strand"
EY = {"발랄": "wide bright eyes, cheeks lifted by a cheeky grin, mouth wide open with her tongue ",
      "도발": "heavy-lidded eyes with a provocative stare straight into the camera, mouth wide open with her tongue ",
      "광기": "eyes opened extremely wide with the whites showing all around the irises, a fixed unblinking stare, a wide stretched grin with her mouth open and her tongue "}
EN = {"발랄": "a playful, mischievous expression", "도발": "a defiant, provocative expression", "광기": "a manic, unhinged expression"}
DARK = ["비주얼계", "잉크 블랙립", "펑크 블랙립", "고스 블랙립", "걸크러시"]
rr = random.Random(77)
def src(lv, jew): return [x for x in F if x["meta"]["piercing"] == lv and (("Jewelry:" in x["prompt"]) == jew)][0]
o = ["# 혀 4갈래 + 강한 피어싱 시험 3개 (한중일 아이돌)\n", "혀를 4갈래로 나눴고, 피어싱 단계·쥬얼리·메이크업·표정은 무작위로 뽑았습니다. 번호별로 정상/이상만 알려주세요. 이상이면 갈래 수가 몇 갈래로 나왔는지 한 줄만 적어주세요.\n"]
rings = [True, True, False]; rr.shuffle(rings); exs = rr.sample(list(EY), 3)
for i, nat in enumerate(["한국", "중국", "일본"], 1):
    lv = rr.choice(["P100", "P150"]); jew = rr.choice([True, False]); mkn = rr.choice(DARK); ex = exs[i - 1]; ring = rings[i - 1]
    key = f"tq{i}"; C.EXPR[key] = EY[ex] + LEN + ", " + QUAD + (RING if ring else "") + ", " + EN[ex]
    t = C.build(src(lv, jew), NAT[nat], "아이돌", key, mkn, MK, random.Random(70 + i))
    assert not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t), re.findall(r".{20}\b(\w+) \1\b", t)
    o.append(f"## {i}. {nat} · 아이돌 · 혀 4갈래{' + 갈래마다 링' if ring else ' (링 없음)'} · 표정 {ex} · 메이크업 {mkn} · 피어싱 {lv}{'+쥬얼리' if jew else ''}\n\n```\n{t}\n```\n"); print(o[-1].split("\n")[0])
open("/mnt/user-data/outputs/LumineX_Tongue_4way3.md", "w", encoding="utf-8").write("\n".join(o))
