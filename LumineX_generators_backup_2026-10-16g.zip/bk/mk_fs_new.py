import re,random,json,sys
g=open('gen_fs2.py',encoding='utf-8').read()
exec(g[:g.index('if __name__=="__main__":')])
m=open('mk_group4.py',encoding='utf-8').read()
exec(m[m.index('END="'):m.index('TEXT.update')])
rr=random.Random(20261013)
names=rr.sample(list(NEWLIP),4)
tusk_flag=False
o=["# LumineX — Face Sculpt 단일 컷 샘플 4개 (신규 입술 6종 중 4종, 번들과 같은 랜덤 추첨)\n","- 입술 강조 단일 컷이라 45도 구도입니다. 피어싱 레벨·물건 추가 축·귀 스타일·메이크업·국적은 번들과 같은 확률로 랜덤입니다.","- 정상/이상 번호만 알려주세요.\n"]
for i,n in enumerate(names,1):
    it=build2(i,'lip',n,NEWLIP[n],rr)
    o.append(f"## {i}. {it['title']}\n\n```\n{it['prompt']}\n```\n"); print(i,n,len(it['prompt'].split()))
open(OUT+'LumineX_FaceSculpt_NewLips_Single_4.md','w',encoding='utf-8').write("\n".join(o))
