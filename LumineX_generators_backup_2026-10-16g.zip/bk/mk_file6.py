import re,random
exec(open('new_lib.py',encoding='utf-8').read())
FORE_PEND="A forehead pendant: a fine gold chain runs along the centre parting of her hair and ends in a teardrop gem pendant resting at the middle of her forehead."
NOSE_EAR="A nose-to-ear chain: a fine chain swags from the ring on her left nostril wing across the cheek, well below the eye and clear of the lips, up to a hook at the top of her left ear."
BEADS="A forehead bead band: a row of large turquoise and coral beads is strung across the top of her forehead along the hairline like a headband, with a round ornament set with a large gem at its centre."
def subj(t): return [x for x in t.split("\n\n") if x.startswith("Subject:")][0]
def subj_add(t,txt):
    s=subj(t); k=" Her whole face, ears and neck are real living flesh"; assert k in s
    return t.replace(s,s.replace(k," "+txt+k,1))
def slots(t,txts):
    k="The left and right sides are balanced."; assert k in t
    return t.replace(k," ".join(txts)+" "+k,1)
def skin(t,txt):
    s=subj(t); s2,n=re.subn(r"adult (Korean|Chinese|Japanese) woman — .*?, (early|mid|late) (\d0s)",lambda m:f"adult woman — {txt}, {m.group(2)} {m.group(3)}",s,count=1); assert n==1
    return t.replace(s,s2)
def light(t,bg,key,rim):
    a="MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient."
    assert a in t; t=t.replace(a,bg)
    b="A soft frontal light on her face and ears, so the glints on every piece of metal read clearly against her skin; a thin cool rim light along the hair and shoulders."
    assert b in t; return t.replace(b,key+" "+rim)
def finish(t,mode,nw,rr,lab,force=None):
    global FORCE
    FORCE=force
    return apply_ear(t,mode,nw,random.Random(rr.randrange(10**9)),w,HW2,COL2,None,lab)

THEMES["bright"]=("Every piece on her face is bright and light-coloured, so that it gleams clearly against her deep skin: small polished gold and mirror-silver studs, rings and bars, and tiny clear diamonds and pearls.","The face and ear jewelry is real polished bright yellow gold and mirror silver set with clear diamonds, white pearls and icy pale gems, every piece light and gleaming","밝은 금속·보석")

A_OLD="two separate large healed openings in the earlobe, one below the other with a clear gap of bare skin between them, each opening holding its own very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel,"
def holes(t,h,lab):
    if h==2: return t,lab+" · 귀 구멍 2개"
    assert A_OLD in t
    if h==1:
        t=t.replace(A_OLD,"one large healed opening in the earlobe holding a very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel,")
        t=t.replace("these two iron rings","this iron ring")
        t,n=re.subn(r"On each ear the two iron rings each carry their own column of weights, the two columns holding [^,]*? weights, hanging side by side","On each ear the single iron ring carries all the weights, hanging in a staggered cluster",t); assert n==1
        t=t.replace("Because the load is shared between two openings,","Because all the load is carried by one opening,")
    else:
        t=t.replace(A_OLD,"three separate large healed openings in the earlobe, one below another with a clear gap of bare skin between each, each opening holding its own very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel,")
        t=t.replace("these two iron rings","these three iron rings")
        t,n=re.subn(r"On each ear the two iron rings each carry their own column of weights, the two columns holding [^,]*? weights, hanging side by side","On each ear the three iron rings share the weights between them in uneven numbers, each ring carrying its own column of weights, hanging side by side",t); assert n==1
        t=t.replace("Because the load is shared between two openings, the weight gently pulls each earlobe down a little into a slightly elongated, soft, healthy loop of skin, only a small natural droop that is just enough to show how heavy the weights are;","Because the load is shared between three openings, the weight pulls each earlobe down only very slightly into a soft, healthy loop of skin, a barely noticeable natural droop that is just enough to show the weights are heavy;")
        assert "shared between three openings" in t
    assert not re.search(r"two iron rings|two openings|two columns",t)
    return t,lab+f" · 귀 구멍 {h}개"
METALS0=dict(METALS)
BRIGHT={"gold":("polished bright yellow gold with a hammered, gleaming surface","gold"),"silver":("bright polished mirror silver with a gleaming hammered surface","silver"),"tin":("bright polished chrome-silver with a gleaming hammered surface","tin"),"brass":("bright polished golden brass with a gleaming surface","brass")}
def brighten(t):
    t=t.replace("rough and matte and unpolished with no shine","bright, polished and gleaming")
    t=t.replace("rough, matte, unpolished heavy metal in mixed materials (lead, tin, gold, silver, bronze, copper, brass and iron)","bright polished heavy metal in mixed materials (gold, silver, chrome-silver and brass)")
    t=t.replace("rough, matte, unpolished ","bright, polished ")
    t=t.replace("black cast-iron","bright polished gold").replace("black cast iron","bright polished gold").replace("blackened steel","polished bright silver").replace("heavy black iron links","heavy bright metal links")
    t=re.sub(r"\biron (rings?)\b",r"gold \1",t)
    return t
rr=random.Random(5151)
OUTS=[]
def make(title,N,zero,minimal,mode,build_fn=None,force=None,expr0=None,theme=None,style0=None,bright=False,h=2):
    global METALS
    for tr in range(100):
        r2=random.Random(rr.randrange(10**9))
        try:
            nw=r2.choice([8,9,10]); deco=r2.choice(["",HENNA,STICK,BOTH])
            t,lab,lt,nw=base(r2,N,zero,minimal,deco,nw,theme=theme,expr0=expr0,style0=style0)
            if build_fn: t=build_fn(t)
            if bright: METALS=BRIGHT
            try: t,lab2=finish(t,mode,nw,r2,lab+f" · 귀 추 {nw}개/귀 2구멍",force)
            finally: METALS=METALS0
            if bright: t=brighten(t)
            t,lab2=holes(t,h,lab2)
        except AssertionError as e: continue
        if re.search(r"[가-힣]",t) or (re.search(r"\b(\w+) \1\b",t) and re.search(r"\b(\w+) \1\b",t).group(1).lower() not in("had","that")): continue
        if bright and re.search(r"blackened|black cast|bronze|copper|\blead\b|\biron\b|pitted|tarnished|dark (silver|brass)",t): continue
        OUTS.append((title+" · "+lab2+(" · "+lt if lt else ""),t)); print(len(OUTS),len(t.split())); return
    raise SystemExit(("fail",title))
Z=("tmp","brow","bri")
BW="She has no eyebrows at all: "


NB=BW
make("눈썹 대용 · 진주 스터드 줄",25,Z,False,"iron",lambda t:subj_add(t,NB+"her brow bones are bare skin, with a row of seven small round white pearl studs set into the skin along each brow bone, getting slightly smaller toward the outer end, kept well away from her eyes."),h=2)
make("눈썹 대용 · 가리비·불가사리 참",25,Z,False,"mix",lambda t:subj_add(t,NB+"her brow bones are bare skin, with three tiny silver rings through the skin along each brow bone, each ring carrying a small charm, a scallop shell, a starfish and a tiny pearl, the charms hanging only a few millimetres below the ring and staying high on the brow bone, well away from her eyelids."),h=3)
make("눈썹 대용 · 산호 구슬 링",25,Z,False,"iron",lambda t:subj_add(t,NB+"her brow bones are bare skin, with a row of small rings through the skin along each brow bone, each ring strung with a pink coral bead, the rings standing out from the skin so the loops and beads are clearly visible, kept well away from her eyes."),h=1)
make("눈썹 대용 · 눈썹뼈 작은 링 줄",25,Z,False,"mix",lambda t:subj_add(t,NB+"her brow bones are bare skin, with a row of five small polished silver rings through the skin along each brow bone, each loop standing out from the skin so the circles are clearly visible against her face, kept well away from her eyes."),h=2)
make("눈썹 대용 · 바깥쪽 끝 스파이크 스터드",25,Z,False,"iron",lambda t:subj_add(t,NB+"her brow bones are bare skin, with two or three small sharp polished silver cone-spike studs at the outer end of each brow bone, standing out from the skin, kept well away from her eyes."),h=3)
H=[2,3,1,2,3]
o=["# LumineX — 눈썹 대용 시험 (5개)\n","- 1 진주 스터드 줄, 2 가리비·불가사리 참(작은 링에 매달림), 3 산호 구슬 링, 4 눈썹뼈 작은 링 줄(고리가 서 있음), 5 바깥쪽 끝 스파이크 스터드. 배경은 기본 순흑, 귀 구멍 수는 1~3 랜덤입니다. 정상/이상 번호만 알려주세요.\n"]
for i,(title,p) in enumerate(OUTS,1):
    title=re.sub(r" · 귀 구멍 \d개","",title); title=title.replace(" 2구멍",f" {H[i-1]}구멍")
    o.append(f"## {i}. {title}\n\n```\n{p}\n```\n")
open(OUT+'LumineX_NewAxes_Test_File6.md','w',encoding='utf-8').write("\n".join(o))
