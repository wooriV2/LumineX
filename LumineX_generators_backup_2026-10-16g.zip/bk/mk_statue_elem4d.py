# -*- coding: utf-8 -*-
# 소재 축 신규 샘플 6개: 선 몸(철사·철근·네온 튜브) 3 + 모래시계 용기 몸 3 — 조각상 프레임 컷 틀, 피어싱 없음, Core 체형
import re, sys, random, json
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity"); sys.path.insert(0, "../../master")
_g = open("gen_pierce_statue.py", encoding="utf-8").read()
exec(_g[:_g.index("def build(")])
import mdefs as D
exec(open("../../bk/newbody_defs.py", encoding="utf-8").read(), globals())
rnd.seed(20262101)
# ── Core 체형 (키 큰 쪽 제외: 다리 길이 문장이 무릎·허벅지 끝 컷과 충돌) ──
_NBd = [b[1] for b in D.BODIES if b[0] == "Nubian booty builder"][0]
_NBB = _NBd.replace("wide flaring lats", "a full, heavy, firm bust standing out on her chest").replace("a deeply carved abdomen with sharp obliques", "a deeply carved six-pack abdomen with sharp obliques")
CORE = ["legendary bust", "curved bust", "siren bust hourglass", "glamour hourglass", "hourglass bombshell", "black glamour", "apex siren", "violin hip hourglass", "latina curves", "Brazilian booty glam",
        "muscular hourglass BBW", "hourglass SSBBW", "USSBBW", "Nubian booty builder", "powerlifter bombshell", "Nubian bust builder"]
POOL = {b[0]: b[1] for b in D.BODIES}; POOL.update({nm: desc for nm, ko, kod, desc in NB}); POOL["Nubian bust builder"] = _NBB
TAILRE = re.compile(r";?\s*her arms, hands, legs and feet stay in correct proportion to each other\s*$")
FLAG = re.compile(r"\b(feet|ankle|ankles|calves|calf|knee|knees|stilt|tall|towering|height|pressing together|pressed together|long legs|legs)\b", re.I)
SWAPS = [(", thighs pressing together", ""), ("thighs pressing together, ", ""), ("thighs pressed together", "thighs"), (", thick heavy calves", ""), ("sagging down toward her knees", "sagging down over her thighs"),
         ("past the line of her own knees", "past the line of her own thighs"), (", and diamond-shaped calves", ""), (" and diamond-shaped calves", ""), ("thick hamstrings,", "thick hamstrings"), ("a visible teardrop shape above each knee", "a visible teardrop shape above each thigh end")]
CLEAN = {}; DROP = {}
for nm in CORE:
    d = TAILRE.sub("", POOL[nm]).strip().rstrip(";,. ")
    for a, b in SWAPS: d = d.replace(a, b)
    f = FLAG.findall(d)
    if f: DROP[nm] = sorted(set(x.lower() for x in f))
    else: CLEAN[nm] = d
print("제외(프레임 컷과 충돌):", DROP)
KO = {"legendary bust": "레전더리 바스트", "curved bust": "커브드 바스트", "siren bust hourglass": "사이렌 바스트 아워글래스", "glamour hourglass": "글래머 아워글래스", "hourglass bombshell": "아워글래스 밤쉘", "black glamour": "블랙 글래머", "apex siren": "에이펙스 사이렌",
      "violin hip hourglass": "바이올린 힙 아워글래스", "latina curves": "라티나 커브스", "Brazilian booty glam": "브라질리언 부티 글램", "muscular hourglass BBW": "머스큘러 아워글래스 BBW", "hourglass SSBBW": "아워글래스 SSBBW", "USSBBW": "USSBBW", "Nubian booty builder": "누비안 부티 빌더", "powerlifter bombshell": "파워리프터 밤쉘", "Nubian bust builder": "누비안 바스트 빌더"}
# ── 새 소재 ──
FIT = "carved as one solid sculpted mass like a statue, never hollow, with no gaps and no skin anywhere, every wrist, palm, finger and knuckle the same material"
FIT = "built as one open lattice sculpture like a statue, with no real body, no skin and no flesh anywhere inside or beneath the wire — the wire figure is the entire torso, and only the backdrop shows through the gaps, every wrist, palm, finger and knuckle made of the same lines"
LINES = {
 "wire": ("철사", "ONE scribbled wire sculpture, like a three-dimensional drawing made of pencil-thick bright steel wire: dense scribbled and tangled loops of wire form every part of her figure — her chest, torso, both arms, both hands with every finger, and both thighs are nothing but tangled wire, with no solid surface and no real limb, chest or skin anywhere; the tangles are heavy and overlapping in the middle of each part and the backdrop shows through between the loops, with a ring of wire around her chest, her waist and her hips, each wire catching its own thin glint"),
 "rebar": ("철근", "ONE sculpture of thick ribbed steel rebar bars bent into the exact shape of her body, closely spaced ring-shaped hoops around her chest, waist and hips joined by many long vertical bars, with a few diagonal bars and bundled tie-wire lashed at every crossing, so the cage reads as a full, filled form you can still see into, with no concrete, rust-orange stains on the bars"),
 "tube": ("네온 튜브", "ONE sculpture of bent glass neon tubes glowing in vivid electric pink and cyan, drawn as closely spaced flowing contour lines and rings that trace every curve of her form, with a second, shorter set of tubes curving inside the first so the body reads as a full, filled form of light you can still see into, small black electrode caps and thin cables at the tube ends"),
}
SANDS = [("금빛 모래", "fine warm golden desert sand"), ("미드나이트 블루 모래", "fine midnight-blue sand scattered with tiny silver sparkles"), ("로즈 모래", "fine soft rose-pink sand with pale pearl glints")]
GLASS = "The glass is unmistakably glass: thick, crystal-clear and polished, with bright specular reflections sliding along every curved surface, sharp white highlights and dark refraction edges where the walls are thickest, tiny bubbles trapped in the glass itself. Her shoulders, chest, belly, hips and both thighs keep their exact sculpted shapes as clear glass outlines, and a clean glass rim runs along the boundary where the vessel meets the neck."
def body_line(key):
    nm, desc = LINES[key]
    return (f"{LIST} — is not painted, covered or clothed but physically made of {desc}, {FIT}.", nm, False)
GLASS2 = "The glass is unmistakably glass: thick, crystal-clear and polished, with bright specular reflections sliding along its curved walls, sharp white highlights and dark refraction edges where the walls are thickest, tiny bubbles trapped in the glass itself."
SIL = {"siren bust hourglass": "an enormous upper bulb as her bust, an impossibly narrow glass neck, a full lower bulb",
       "legendary bust": "a gigantic upper bulb projecting far forward as her bust, a very narrow glass neck, a full lower bulb",
       "glamour hourglass": "a full round upper bulb as her bust, a sharply narrow glass neck, a wide curvaceous lower bulb",
       "violin hip hourglass": "a modest round upper bulb as her bust, a narrow glass neck, a very wide lower bulb",
       "latina curves": "a full round upper bulb as her bust, a narrow glass neck, an equally full lower bulb",
       "Brazilian booty glam": "a full round upper bulb as her bust, a narrow glass neck, a huge rounded lower bulb that dominates the silhouette"}
def body_hour(i):
    nm, sand = SANDS[i]
    return (f"Below the collarbones there is no human torso at all: in its place her entire torso is a giant real hourglass of thick, crystal-clear glass, and the hourglass itself is the torso. Its shape is the whole silhouette from the collarbones to the thigh ends — {{SIL}}. The upper glass bulb is shaped as her bust, the narrow glass neck is the only thing left of her waist, and the lower glass bulb is her belly and hips and runs on into both thighs. Her arms are plain clear glass limbs with solid glass hands. {GLASS2} {sand.capitalize()} pours in a thin steady stream from the upper bulb through the glass neck and heaps in a smooth cone in the lower bulb. There is nothing inside the glass but sand, nothing behind it but the backdrop — no body, no skin, no second figure, no torso outline anywhere.", f"모래시계·{nm}", True)
def body_vessel(kind):
    if kind == "bulb":
        return (f"{LIST} — is not a body at all: her whole torso IS a giant vintage light bulb of thick, crystal-clear glass and nothing else. The round glass dome is her bust and ribcage, the glass narrows through her waist, and the lower glass swells into her belly and hips and continues into both thighs. A fine tungsten filament coils inside the glass from her chest down to her hips, glowing a warm orange-white with a soft halo around each coil. Her arms are plain clear glass limbs with solid glass hands. {GLASS2} There is no body, no torso outline and no skin anywhere — the bulb itself is the whole torso, and beyond its glass walls there is only the backdrop.", "전구", True)
    return (f"{LIST} — is not a body at all: her whole torso IS a giant lava lamp, a tall glass lamp body in the silhouette of her torso, filled completely with vivid translucent magenta liquid lit from within by a hot orange glow, in which big glowing orange and gold wax blobs slowly rise and sink, some stretching into soft teardrops, spread from her chest down through her hips; a polished brass cap closes the lamp at her collarbones and a polished brass base cup caps the end of each thigh, with a warm glow spilling onto the floor beneath. Her arms are plain clear glass limbs with solid glass hands. {GLASS2} There is no body, no torso and no skin inside or behind the glass.", "라바 램프", True)
LABEL = ['Physique']
CUR_EN = ''
def build_new(frame, phys, body, mname, transparent, vessel, lattice=False):
    pname, pos, part = FR[frame]
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC) + 1)
    (ba, bb) = rnd.choice(BACKS)
    hair = f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}"
    tip = (f"{pos[0].upper()}{pos[1:]}, each thigh individually curves inward and " + ("seals shut into its own smooth, rounded, closed tip" if vessel else "rounds off into its own smooth, deeply polished tip") +
           " — the two thighs stay clearly separate all the way down, never merging" + (" or fusing" if vessel else ", fusing or tapering") + " into a single base — no calves, no feet, nothing continues below either tip — the " + ("vessel" if vessel else "material") + " simply reaching its natural end on each leg, both " + ("sealed " if vessel else "") + "rounded tips resting side by side on the surface beneath her.")
    if lattice:
        tip = (f"{pos[0].upper()}{pos[1:]}, each thigh individually curves inward and its lines gather into its own rounded closed end — the two thighs stay clearly separate all the way down, never merging into a single base — no calves, no feet, nothing continues below either end, both rounded ends resting side by side on the surface beneath her.")
        mid = "Transmission: everything below the collarbones is an open lattice with wide gaps, nothing inside it, so the backdrop and its light sources are visible straight through her body between the lines, while her real face, ears and neck are opaque living flesh. Her face stays completely opaque."
        light = f"Lighting: the glowing backdrop shines through the gaps of her open body, {ba} through one side and {bb} through the other. A soft frontal light falls on her face and ears only; a thin cool rim light traces her whole figure so every line of the lattice reads clearly. Only her face, ears and neck read as real skin."
    elif transparent == "elem":
        mid = f"Material: everything below the collarbones is nothing but {CUR_EN} in constant motion, lit by its own glow, while her real face, ears and neck are opaque living flesh. Her face stays completely opaque."
        light = f"Lighting: the glowing backdrop frames her whole silhouette from behind, {ba} on one side and {bb} on the other, while the {CUR_EN} body lights itself and throws its own glow onto the floor. A soft frontal light falls on her face and ears only. Only her face, ears and neck read as real skin."
        tip = tip.replace("smooth, deeply polished tip", "smooth, rounded tip")
    elif transparent:
        mid = "Transmission: everything below the collarbones is a transparent material that light passes through, while her real face, ears and neck are opaque living flesh that no light passes through. The background and its light sources are visible straight through her body, bent and tinted by the material, with bright refraction edges and soft coloured shadows. Her face stays completely opaque."
        light = f"Lighting: the glowing backdrop floods her body from behind, so {ba} passes through one side and {bb} passes through the other. A soft frontal light falls on her face and ears only; a thin cool rim light traces her whole figure. Only her face, ears and neck read as real skin."
    else:
        mid = "Material: everything below the collarbones is a completely dense solid with no gaps that no light passes through, while her real face, ears and neck are living flesh. The body blocks the backdrop's glow entirely, its surface catching the light with a hard, honest sheen and soft contact shadows, so it is unmistakable that the body itself is built from the material."
        light = f"Lighting: the glowing backdrop frames her whole silhouette from behind, {ba} on one side and {bb} on the other, while her dense body blocks it completely. A soft frontal light falls on her face and ears, and a thin cool rim light traces her whole figure so the surface of the material reads clearly. Only her face, ears and neck read as real skin."
    p = (f"Professional fashion photograph, {pname}. ONE woman, angled 45 degrees toward the camera, framed so her whole sculpted form is visible from the top of her head down to two individually rounded, deliberately finished tips {pos}, her face in natural scale with her body — never an oversized close-up crop of just the face. Where her sculpted form comes to an end at her {part}, it is because the sculpture itself ends there, not because a camera frame happens to cut her off.\n\n"
         f"Subject: A real photograph of a strikingly beautiful adult {nat} woman — {fa}, {hair}. {REAL_FACE}\n\n"
         f"{LABEL[0]}: {phys}.\n\nBody: {body} {tip}\n\n{mid}\n\n"
         f"Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. There is no line down the centre of her body. At that line, the material's edge rises in a small raised step above her flesh, casting a crisp shadow — her skin beside it stays smooth and even. The rounded tip is the material's own finish, always the clean, deliberate result of a sculpture — never the edge of a photograph.\n\n"
         f"Setting: a huge backdrop behind her washed with two coloured lights from behind — {ba} on one side and {bb} on the other, blending into a smooth gradient in the middle, and a glossy dark floor beneath her.\n\n"
         f"Pose: standing tall, her left hand (solid material) resting on her flared hip, her right arm held clear of her body with the hand (solid material) relaxed at hip height, both hands well away from her face, head tilted slightly toward the camera.\n\n{light} Shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait.")
    if transparent == "elem":
        p = p.replace("hand (solid material)", f"hand (made of {CUR_EN})").replace("hand (solid material)", f"hand (made of {CUR_EN})")
        p = re.sub(r"At that line, the material's edge rises in a small raised step above her flesh, casting a crisp shadow", f"At that line the {CUR_EN} begins directly against her skin", p)
    p = dd(p).replace(",,", ",").replace(".,", ",")  #.replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), p[:100]
    return p, f"메이크업 {mk}"

def OBJ(shape_txt, extra, arms, name):
    return (f"Below the collarbones there is no human torso at all: in its place her entire torso is {shape_txt}, and that object itself is the torso. {extra} {arms} There is nothing inside it that is a body, no skin and no second figure, and nothing behind it but the backdrop — no torso outline, no waist outline anywhere.", name)
GL = GLASS2
OBJS = {
 "clock": OBJ("a pair of big round clocks — a smaller round clock as her bust and a larger round clock as her hips, joined by a short, very narrow brass gear shaft that is the only thing left of her waist, the lower clock continuing into both thighs",
              f"Each clock has a polished brass rim and a clear glass crystal through which every gear, spring and escapement is visible, with the dial and its numerals on the front and slender hands showing a time. {GL}", "Her arms are plain brass-and-glass limbs with solid hands.", "시계"),
 "snowglobe": OBJ("two real glass snow globes joined into one — a smaller globe as her bust and a larger globe as her hips, connected by a very narrow glass neck that is the only thing left of her waist, the larger globe continuing into both thighs",
              f"{GL} Fine white snow and a few glitter flecks swirl slowly in clear liquid through both globes and the narrow neck, settling in soft drifts at the bottom of the lower globe.", "Her arms are plain clear glass limbs with solid glass hands.", "스노우 글로브"),
 "flask": OBJ("a real chemist's glass distillation apparatus — a round-bottomed glass flask as her bust and a larger round-bottomed glass flask as her hips, joined by a narrow glass tube that is the only thing left of her waist, the lower flask continuing into both thighs",
              f"{GL} A vivid emerald-green liquid boils gently in the lower flask, and pale vapour rises through the narrow tube into the upper flask, where it condenses into slow droplets.", "Her arms are plain clear glass limbs with solid glass hands.", "증류 플라스크"),
 "lantern": OBJ("a real hurricane lantern of thick clear glass — a round glass globe as her bust, the glass narrowing to a slim waist, and a wide flared glass base as her hips, continuing into both thighs",
              f"{GL} A single steady flame burns inside the glass, its warm glow lighting the whole figure from within.", "Her arms are plain clear glass limbs with solid glass hands.", "허리케인 랜턴"),
 "perfume": OBJ("a real Art Deco perfume bottle of thick faceted crystal — broad rounded shoulders as her bust, tapering to a slim waist, and flaring into a wide faceted base as her hips, continuing into both thighs",
              f"{GL} The bottle is filled to the brim with golden-amber perfume that glows where the light passes through it.", "Her arms are plain clear faceted-crystal limbs with solid hands.", "향수병"),
 "gourd": OBJ("a real glass gourd-shaped bottle — a rounded upper glass bulb as her bust, a very narrow glass neck that is the only thing left of her waist, and a larger rounded lower glass bulb as her hips, continuing into both thighs",
              f"{GL} The bottle is filled with deep ruby-red wine that glows where the light passes through it.", "Her arms are plain clear glass limbs with solid glass hands.", "유리 호리병"),
 "bubble": OBJ("a cluster of real giant soap bubbles — two large round bubbles side by side as her bust, a narrow pinched film waist, and one larger bubble as her hips, continuing into both thighs",
              "Each bubble is a paper-thin film that shimmers with shifting rainbow colours, with bright window-like reflections sliding across its surface, and nothing inside but clear air.", "Her arms are thin soap-film limbs with delicate film hands.", "비눗방울"),
 "jelly": OBJ("a real translucent jellyfish — a soft round bell as her bust and ribcage with fine glowing radial canals, a narrow pinched waist, and a ruffled, frilled skirt of flowing translucent tissue as her hips, continuing into both thighs",
              "The whole body is clear, jelly-like and softly bioluminescent, glowing pale blue and violet from within, with fine droplets clinging to its surface.", "Her arms are slender translucent jellyfish limbs with soft frilled hands.", "해파리"),
 "vase": OBJ("a real Art Nouveau glass vase — a gently swelling upper body as her bust, a slim waist, and a wide flowing lower body as her hips, continuing into both thighs",
              f"{GL} Swirling ribbons of iridescent teal and amber are blown into the glass itself, shifting colour as the light moves.", "Her arms are plain clear glass limbs with solid glass hands.", "아르누보 유리 꽃병"),
}
ELEM = [
 ("물|water", "a pair of giant water droplets — a smaller round water droplet as her bust and a larger round water droplet as her hips, joined by a short, very narrow stream of water that is the only thing left of her waist, the lower water droplet continuing into both thighs of water; each is water all the way through, with swirling currents, rising bubbles and white foam inside and splashes flying off its surface", "Her arms are streams of flowing water, ending in hands of water."),
 ("연기|smoke", "a pair of giant balls of smoke — a smaller round ball of smoke as her bust and a larger round ball of smoke as her hips, joined by a short, very narrow neck of smoke that is the only thing left of her waist, the lower ball of smoke continuing into both thighs of smoke; each is smoke all the way through, thick and billowing, with feathered edges dissolving into curling wisps and a faint ember glow inside", "Her arms are curling ribbons of smoke, ending in hands of smoke."),
 ("불꽃|flame", "a pair of giant fireballs — a smaller round fireball as her bust and a larger round fireball as her hips, joined by a short, very narrow neck of flame that is the only thing left of her waist, the lower fireball continuing into both thighs of flame; each is flame all the way through, roiling orange, gold and white-hot yellow, with flames licking off its edges and sparks and embers drifting away", "Her arms are streams of flame, ending in hands of flame."),
 ("번개|lightning", "a pair of giant plasma balls — a smaller round plasma ball as her bust and a larger round plasma ball as her hips, joined by a short, very narrow bolt of lightning that is the only thing left of her waist, the lower plasma ball continuing into both thighs of lightning; each is lightning all the way through, a blue-white tangle of crackling branching bolts, with thin arcs forking off its surface and a violet glow around it", "Her arms are forking bolts of lightning, ending in hands of light."),
]
CRAFT = [
 ("종이접기|origami paper", "a standing origami sculpture in the shape of her figure — her bust, waist, hips and thighs folded from crisp white paper into sharp geometric facets with fine crease lines", "Her arms are folded paper too, ending in hands of folded paper.", False),
 ("설탕 유리|sugar glass", "a standing hard-candy sculpture in the shape of her figure — her bust, waist, hips and thighs made of translucent amber spun-sugar glass, glossy and faceted, with bright light glowing through it", "Her arms are sugar glass too, ending in hands of sugar glass.", True),
 ("구체관절 인형|doll", "a standing ball-jointed doll sculpture in the shape of her figure — her bust, waist, hips and thighs made of smooth porcelain-white resin with visible round ball joints at the waist and hips and fine seams between the parts", "Her arms are resin doll arms with visible ball joints at the shoulders and wrists, ending in jointed doll hands.", False),
]
FIGS = ["siren bust hourglass", "legendary bust", "glamour hourglass", "violin hip hourglass", "latina curves", "Brazilian booty glam"]
frames = ["hip", "demi", "tq"]
items = []
order = ["e0","e1","e2","e3"]
pool_o = [n for n in FIGS if n in CLEAN]; rnd.shuffle(pool_o)
for k, key in enumerate(order):
    f = rnd.choice(frames)
    if key.startswith("e"):
        nm, shape, arms = ELEM[[2,0,1,3][int(key[1])]]; nm, en = nm.split("|"); CUR_EN = en; name = pool_o[int(key[1])*2 % len(pool_o)]
        body = (f"Below the collarbones there is no human torso at all: in its place her entire torso is {shape}, and the {en} itself is the whole torso. {arms} There is no real body, no skin and no second figure inside or beneath it.")
        p, mk = (LABEL.__setitem__(0, "Silhouette"), build_new(f, (SIL[name].replace("glass neck","waist").replace("bulb","mass"))[0].upper() + (SIL[name].replace("glass neck","waist").replace("bulb","mass"))[1:], body, nm, "elem", False))[1]; LABEL[0] = "Physique"; lab = f"원소 몸 · {nm}"
    elif key == "craft":
        nm, shape, arms, tr = rnd.choice(CRAFT); nm, en = nm.split("|"); name = rnd.choice(list(CLEAN))
        body = (f"Below the collarbones there is no human torso at all: in its place her entire torso is {shape}, and the {en} sculpture itself is the whole torso. {arms} There is no real body, no skin and no second figure inside or beneath it.")
        p, mk = build_new(f, CLEAN[name], body, nm, tr, False); lab = f"공예 조각상 · {nm}"
    else:
        name = pool_o[k % len(pool_o)]
        body, nm = OBJS[key]
        sl = SIL[name]; p, mk = (LABEL.__setitem__(0, 'Silhouette'), build_new(f, sl[0].upper() + sl[1:], body, nm, True, True))[1]; LABEL[0] = 'Physique'
        lab = f"물체 몸 · {nm}"
    items.append((FRKO[f], KO[name], lab, mk, p))
L = ["# LumineX — 소재 축 원소 몸 4종 v4 (원소 덩어리 두 개)\n", "조각상 프레임 컷 틀에서 피어싱은 없고, 물체 모양 자체가 몸통입니다. 번호별로 성공/실패만 알려주세요.\n"]
for i, (fr, bd, mt, mk, p) in enumerate(items, 1):
    L.append(f"## {i}. {fr} · {bd} · {mt} · {mk}\n\n```\n{p}\n```\n")
open("/mnt/user-data/outputs/LumineX_Material_Elements4d.md", "w", encoding="utf-8").write("\n".join(L))
for fr, bd, mt, mk, p in items: print(fr, bd, mt, len(p.split()))
