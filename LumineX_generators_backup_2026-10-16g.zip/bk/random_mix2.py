import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
NS=None
src=open('random_mix.py').read(); src=src[:src.index('def build(')]
NS={}; exec(compile(src,'random_mix.py','exec'),NS)
OUT=NS['OUT']; sub=NS['sub']; ETH=NS['ETH']; LENS=NS['LENS']; JAWS=NS['JAWS']; MATS=NS['MATS']; HEAD=NS['HEAD']; H45=NS['H45']; FRM=NS['FRM']; NS45=NS['NS45']
EYE={e[0]:e[1] for e in NS['EYES']}
EYES=[("사이렌 눈",EYE["사이렌 눈"]),("옆트임 초최극한(5배)","pure fantasy eyes, impossibly long but elegantly beautiful: the outer corners of both eyes sweep across her temples and all the way round the side of her head until they reach the front edge of her ears, and the inner corners are fully opened with the small pink inner corner visible, so each eye opening is about five times its natural length, an unbelievably long, thin, razor-sharp almond shape like a long blade running from beside her nose all the way to her ears, showing a huge amount of iris and white; a razor-sharp black liner follows the entire shape and ends in a very long, fine point right at the front of each ear; the eyes are in very large {lens} doll-eye contact lenses with a glossy shine and a big iris, both eyes the same, with a round natural pupil and bright catchlights"),
("후디드 아이","heavy-lidded, half-lowered, smouldering eyes with a deep-set heavy upper lid covering part of the iris, dramatic smoky brown-black eyeshadow blended up to the brow bone, thick long curled lashes and a soft winged liner, in rich {lens} contact lenses, both eyes the same, with a round natural pupil and bright catchlights"),
("애교살 초극대",EYE["애교살 초극대"])]
LIPS=[("러시안 립 초과장","the most extreme 'Russian lips' imaginable: gigantic, very tall, very plump doll-like lips, the upper lip lifted and flared high with a razor-sharp, towering cupid's bow, the lower lip enormous and pillowy, both lips with perfectly crisp, razor-sharp edges, the whole pout projecting far forward from her face so the lips are the dominant feature of her face in this three-quarter view; ultra-glossy pink-nude with a bright white highlight along the top of each lip, still perfectly balanced and beautiful, never duck-like, never smudged past the lip line"),
("체리 립","'cherry lips': the fullness concentrated in the centre of the upper and lower lips, forming a rounded, plump, pouty cherry-shaped mouth with the corners left slim and untouched, glossy cherry-red, youthful, sweet and symmetrical"),
("키홀 퓨트","a 'keyhole pout': two plump, high-volume pads of filler on either side of the centre of her lips, leaving a small round keyhole-shaped gap in the middle of her slightly parted lips, glossy deep rose, eye-catching and subtly seductive"),
("러시안 립 과장","extremely exaggerated 'Russian lips': huge, tall, doll-like lips with a dramatic amount of vertical height in both the upper and lower lip, a high, flared, strongly lifted upper lip with a very sharp, high and pronounced cupid's bow, very crisp, razor-clean, sharply drawn edges all around the mouth, a full, tall, plump lower lip, and a clearly visible forward projection of the whole pout in this three-quarter view; glossy nude-rose, perfectly balanced and elegant, never duck-like, never smudged past the lip line")]
NOSES=[("자연 코","a refined nose"),("성형 코 1단","a high, straight, refined, surgically sculpted nose: a tall, slim, straight bridge, a narrow, pointed, projecting tip and clearly narrow nostril wings with slim, neat nostrils"),("성형 코 2단","a very steep, sharply sculpted surgical nose: a knife-like bridge that rises steeply and sharply from the brow, a needle-pointed tip projecting well forward, and very narrow, tightly pinched nostril wings with thin, slit-like nostrils")]
def rest(fn,i):
    s=open(OUT+fn,encoding='utf-8').read(); b=re.findall(r"```\n(.*?)\n```",s,re.S)[i]
    return [x for x in b.split("\n\n") if x.startswith("Piercings:")][0]
REST={"A":rest('LumineX_GoldTusk_Restored_3.md',0),"B":rest('LumineX_GoldTusk_Restored_3.md',1),"C":rest('LumineX_GoldTusk_Restored_3.md',2)}
GOLD_FULL="polished solid yellow gold with a warm mirror finish and a slender sharp taper"
def tusk(pat,mat):
    p=REST[pat]
    if mat[0]=="금": return p
    # mat tuple: name, full, short
    p=p.replace(GOLD_FULL,mat[1]).replace("real polished solid yellow gold","real "+mat[2]).replace("polished solid yellow gold",mat[2])
    return p
def subj(rr,star,item,jaw,nose,eth,lens):
    base=f"A real photograph of a strikingly beautiful adult {eth[0]} woman, mid 20s, with {eth[1]} and {eth[2]}. "
    if star=="eye": mid=f"Her eyes are the star of her face: {item[1].format(lens=lens)}. Soft full lips in a natural rose. "
    else: mid=f"Her lips are the star of her face: {item[1]}. Her eyes are large and bright with bright real catchlights and a round natural pupil. "
    return sub(base+mid+f"Her nose: {nose[1]}. Her jawline and chin: {jaw[1]}. Flawless glowing skin, a confident gaze straight into the camera.")
def build(rr,star,item,mod):
    eth=rr.choice(ETH); lens=rr.choice(LENS); jaw=rr.choice(JAWS); nose=rr.choice(NOSES)
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(rr.randrange(10**6)),"한국","20대","도도한",style="NONE",slots=["pierce"],pier_level="P5"); break
        except AssertionError: continue
    ps=t.split("\n\n"); depth=[x for x in ps if x.startswith("Piercing depth:")][0]; light=[x for x in ps if x.startswith("Lighting:")][0]
    sj=subj(rr,star,item,jaw,nose,eth,lens); kind,arg=mod
    hair="Hair: her hair is swept back behind both ears, leaving both ears, her jawline and her neck fully visible so every hanging piece is in clear view."
    if star=="eye":
        ang="정면"; head=HEAD
        if kind=="tusk":
            mat=rr.choice(MATS); mat=(mat[0],mat[1],mat[2]); p=tusk(arg,mat); lab=f"엄니({mat[0]}) 패턴{arg}"; head=HEAD.replace("down to the base of her neck and the tops of her collarbones, the frame cutting off there",FRM["chest"]); fr=True
        else:
            lab,p,frk=arg(rr); head=HEAD.replace("down to the base of her neck and the tops of her collarbones, the frame cutting off there",FRM[frk]); fr=True
    else:
        ang="45도"; head=H45.replace("down to the base of her neck and the tops of her collarbones, the frame cutting off there",FRM["chest"]) if kind=="tusk" else H45; fr=False
        if kind=="tusk":
            mat=rr.choice(MATS); mat=(mat[0],mat[1],mat[2]); p=tusk(arg,mat); lab=f"엄니({mat[0]}) 패턴{arg}"
        else:
            fn=rr.choice(["gold","pearl","steel"]); lab={"gold":"골드+다이아 4","pearl":"진주+핑크 에나멜 4","steel":"블랙 스틸 4"}[fn]; p=NS45[fn]()
        light,n=re.subn(r"A soft frontal light on her face and ears","A soft key light from the front and slightly to the side on her face, shaping the cheek and jawline with a soft shadow below the jaw",light,count=1); assert n==1
    parts=[head,sj,p,depth]
    if fr: parts.append(hair)
    parts.append(light); new="\n\n".join(parts); assert not re.search(r"[가-힣]",new)
    return f"{eth[0]} · {item[0]} · {nose[0]} · {jaw[0]} · {ang} · {lab}",new
rr=random.Random(20261012+7)
PLAN=[("eye",EYES[1],("tusk","A")),("eye",EYES[0],("m",NS['mod_chin'])),("eye",EYES[2],("tusk","C")),("eye",EYES[3],("m",NS['mod_ladder'])),
      ("lip",LIPS[0],("tusk","B")),("lip",LIPS[1],("l",None)),("lip",LIPS[2],("tusk","A")),("lip",LIPS[3],("l",None))]
o=["# LumineX — 채택 항목 섞은 확인 세트 8개 (눈 4 정면 · 입술 4 45도)\n","- 1~4: 눈 별(옆트임 5배·사이렌·후디드·애교살 초극대) 정면, 5~8: 입술 별(러시안 초과장·체리·키홀·러시안 과장) 45도. 인종·턱선·코(자연/성형1/성형2)·피어싱 모듈(새 엄니 3패턴·턱 링+귀 추·전면 채우기·가벼운 4개)은 랜덤.","- 정상/이상(+ 별 특징이 보이는지, 섞어서 무너진 번호)만 알려주세요.\n"]
for i,(st,it,md) in enumerate(PLAN,1):
    lab,txt=build(rr,st,it,md); o.append(f"## {i}. {lab}\n\n```\n{txt}\n```\n"); print(i,lab)
open(OUT+'LumineX_MixedCheck_8.md','w',encoding='utf-8').write("\n".join(o))
