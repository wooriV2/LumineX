import re,random
exec(open('new_lib.py',encoding='utf-8').read())
FORE_PEND="A forehead pendant: a fine gold chain runs along the centre parting of her hair and ends in a teardrop gem pendant resting at the middle of her forehead."
NOSE_EAR="A nose-to-ear chain: a fine chain swags from the ring on her left nostril wing across the cheek, well below the eye and clear of the lips, up to a hook at the top of her left ear."
BEADS="A forehead bead band: a row of large turquoise and coral beads is strung across the top of her forehead along the hairline like a headband, with a round ornament set with a large gem at its centre."
def subj(t): return [x for x in t.split("\n\n") if x.startswith("Subject:")][0]
def subj_add(t,txt):
    s=subj(t); k=" Her whole face, ears and neck are real living flesh"; assert k in s
    return t.replace(s,s.replace(k," "+txt+k,1))
def slots(t,txts):
    k="The left and right sides are balanced."; assert k in t
    return t.replace(k," ".join(txts)+" "+k,1)
def skin(t,txt):
    s=subj(t); s2,n=re.subn(r"adult (Korean|Chinese|Japanese) woman — .*?, (early|mid|late) (\d0s)",lambda m:f"adult woman — {txt}, {m.group(2)} {m.group(3)}",s,count=1); assert n==1
    return t.replace(s,s2)
def light(t,bg,key,rim):
    a="MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient."
    assert a in t; t=t.replace(a,bg)
    b="A soft frontal light on her face and ears, so the glints on every piece of metal read clearly against her skin; a thin cool rim light along the hair and shoulders."
    assert b in t; return t.replace(b,key+" "+rim)
def finish(t,mode,nw,rr,lab,force=None):
    global FORCE
    FORCE=force
    return apply_ear(t,mode,nw,random.Random(rr.randrange(10**9)),w,HW2,COL2,None,lab)
rr=random.Random(4242)
OUTS=[]
def make(title,N,zero,minimal,mode,build_fn=None,force=None,expr0=None,theme=None,style0=None):
    for tr in range(100):
        r2=random.Random(rr.randrange(10**9))
        try:
            nw=r2.choice([8,9,10]); deco=r2.choice(["",HENNA,STICK,BOTH])
            t,lab,lt,nw=base(r2,N,zero,minimal,deco,nw,theme=theme,expr0=expr0,style0=style0)
            if build_fn: t=build_fn(t)
            t,lab2=finish(t,mode,nw,r2,lab+f" · 귀 추 {nw}개/귀 2구멍",force)
        except AssertionError as e: continue
        if re.search(r"[가-힣]",t) or (re.search(r"\b(\w+) \1\b",t) and re.search(r"\b(\w+) \1\b",t).group(1).lower() not in("had","that")): continue
        OUTS.append((title+" · "+lab2,t)); print(len(OUTS),len(t.split())); return
    raise SystemExit(("fail",title))
Z=("tmp","brow","bri")
# slots
make("슬롯 A · 이마 펜던트 + 코-귀 체인",25,("fh",)+Z,False,"mix",lambda t:slots(t,[FORE_PEND,NOSE_EAR]))
make("슬롯 B · 종 모양 귀걸이 + 이마 비즈 띠(추 없음)",25,("fh",)+Z,False,"earring",lambda t:slots(t,[BEADS]),force=4)
make("슬롯 C · 이마 펜던트 + 코-귀 체인 + 종 모양 귀걸이",25,("fh",)+Z,False,"earring",lambda t:slots(t,[FORE_PEND,NOSE_EAR]),force=4)
# skin tone
make("피부톤 · 블루블랙",50,Z,False,"mix",lambda t:skin(t,"THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky with a soft healthy sheen"),style0="NONE")
make("피부톤 · 에보니 브라운",50,Z,False,"iron",lambda t:skin(t,"deep ebony-brown skin with a rich warm undertone and a healthy glossy sheen"),style0="NONE")
# brows
make("눈썹 · 탈색 눈썹",25,Z,False,"mix",lambda t:subj_add(t,"Her eyebrows are bleached completely white-blonde, almost invisible against her skin, so her eyes and metal stand out."))
make("눈썹 · 눈썹 없음 + 보석 라인",25,Z,False,"iron",lambda t:subj_add(t,"She has no eyebrows at all: her brow bones are smooth, bare skin, with a thin line of tiny crystal gems glued along each brow bone where the brows would be."))
# teeth
make("치아 · 금니 그릴즈",25,("ul","ll","chin")+Z,False,"mix",lambda t:subj_add(t,"Her mouth is slightly open, her lips parted just enough in a confident half-smile to clearly show her upper front teeth, which are covered in polished gold grillz, each tooth capped in shining gold (this overrides the lips pressed or closed in her expression)."),expr0="섹시한")
make("치아 · 송곳니 + 치아 보석",25,("ul","ll","chin")+Z,False,"iron",lambda t:subj_add(t,"Her mouth is slightly open, her lips parted just enough to clearly show her teeth, with pointed, elongated, sharp canine fangs and a few tiny diamonds set on her front teeth (this overrides the lips pressed or closed in her expression)."),expr0="카리스마 있는")
# bg
make("배경·조명 · 짙은 버건디 + 마젠타 림라이트",25,Z,False,"mix",lambda t:light(t,"A plain seamless deep burgundy backdrop, nothing else in frame, no texture, no gradient.","A soft warm frontal light on her face and ears, so the glints on every piece of metal read clearly against her skin;","a thin magenta rim light along the hair and shoulders."))
make("배경·조명 · 짙은 남색 + 호박색 림라이트",25,Z,False,"iron",lambda t:light(t,"A plain seamless deep midnight-navy backdrop, nothing else in frame, no texture, no gradient.","A soft cool frontal light on her face and ears, so the glints on every piece of metal read clearly against her skin;","a thin amber rim light along the hair and shoulders."))
o=["# LumineX — 새 축·슬롯 시험 샘플 파일 1 (11개)\n","- 1~3 얼굴 액세서리 슬롯, 4~5 피부톤(블루블랙·에보니), 6~7 눈썹, 8~9 치아 장식, 10~11 배경·조명. 모두 기존 얼굴 컷 틀(귀 스타일 축 포함) 위에 한 가지씩 얹었습니다.","- 정상/이상 번호만 알려주세요.\n"]
for i,(title,p) in enumerate(OUTS,1): o.append(f"## {i}. {title}\n\n```\n{p}\n```\n")
open(OUT+'LumineX_NewAxes_Test_File1.md','w',encoding='utf-8').write("\n".join(o))
