# -*- coding: utf-8 -*-
import re
s = open("gen_woodstone_groups6.py", encoding="utf-8").read()
ns = {}
exec(s[:s.index("S = [(")], ns)
W, T, build, check, BIG = ns["W"], ns["T"], ns["build"], ns["check"], ns["BIG"]
HEELS = ["thirty inches", "thirty-six inches", "forty inches", "thirty-two inches"]
cnt = [0]
def heel(m):
    h = HEELS[cnt[0] % 4]; cnt[0] += 1; nm = m.group(1)
    return (f"heels of the most absurdly extreme height imaginable, thigh-high platform stiletto boots carved from the same {nm}, each with a razor-thin tapered heel a full {h} tall and a twelve-inch hidden front platform, her feet arched fully vertical on the very tips of her toes like a dancer on pointe, her legs stretched impossibly long and her whole body lifted far above the ground on them as if standing on stilts, extra long nails")
def mk(kind, picks, slot):
    t = build(kind, picks, slot)
    t, k = re.subn(r"extreme platform boots carved from the same ([^,]+), extra long nails", heel, t); assert k == len(picks)
    a = " 8K portrait"; assert t.count(a) == 1
    return t.replace(a, " Very low camera angle with the full length of every boot visible down to the floor, the towering heel height dominating the silhouette and lifting her far above the floor." + a)
S = [("목재", [W[9]], 7), ("석재", [T[8]], 9), ("목재", [W[11], W[6]], 10), ("석재", [T[10], T[5]], 12)]
o = ["# 더 극단적인 힐 높이 — 솔로 2·듀오 2 (목재/석재)\n", "얼굴 문장 없음, 부피 큰 체형. 번호별로 정상/이상만 알려주세요.\n"]
for i, (kind, picks, slot) in enumerate(S, 1):
    t = mk(kind, picks, slot); check(f"h{i}", t)
    assert not re.search(r"\b(\w+) \1\b", t), re.findall(r".{20}\b(\w+) \1\b", t)
    n = len(picks); ti = f"{kind} {['','솔로','듀오','트리오'][n]} · {' / '.join(p[0] for p in picks)} · 체형 {', '.join(BIG[j % 4][0] for j in range(n))} · 초극단 힐"
    o.append(f"## {i}. {ti}\n\n```\n{t}\n```\n"); print(i, ti, len(t.split()))
open("/mnt/user-data/outputs/LumineX_ExtremeHeels_Higher4.md", "w", encoding="utf-8").write("\n".join(o))
