# -*- coding: utf-8 -*-
# 신규 영역 4종 샘플(각 2개): 우주·성운 / 용암·마그마 / 털실·펠트 / 수묵·서예 — mk_new_bundles 틀, 전 축 기본 랜덤
_src = open("mk_new_bundles.py", encoding="utf-8").read()
exec(_src[:_src.index('if __name__')])
LEAD = "body curving to follow her body's true three-dimensional shape, "
T_WET = LEAD + "a continuous glossy wet-look coating over her entire body, thick sheets and streams of liquid running down every curve in glistening rivulets, countless beads and droplets clinging to the surface and dripping from her chin, fingertips, hips and knees, razor-sharp bright specular highlights along every curve, nothing lying flat. Dense wet surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
def V(tag, desc, solid, nmw, T, base, acc, fin): return dict(tag=tag, desc=desc, solid=solid, nmw=nmw, T=T, base=base, acc=acc, fin=fin)
VS = [
 V("젖은 광택 · 브론즈 오일", "oil-drenched glistening bronze", "wet-look", "glistening wet bronze", T_WET,
   "BLAZING deep metallic bronze-gold pigment across the full torso both legs neck to ankle, drenched in thick clear body oil",
   "VIVID golden oil streaming in long slow rivulets and heavy oil droplets hanging from every curve", "mirror-wet glossy"),
 V("젖은 광택 · 샤워 크림슨", "shower-drenched glistening crimson", "wet-look", "glistening wet crimson", T_WET,
   "BLAZING saturated crimson-red pigment across the full torso both legs neck to ankle, soaked under a running shower",
   "VIVID streams of clear water cascading from above in sheets and bright round water beads clinging everywhere, with a fine mist of spray in the air", "mirror-wet glossy"),
 V("젖은 광택 · 빗속 블랙", "rain-drenched glistening jet-black", "wet-look", "glistening wet black", T_WET,
   "BLAZING deep jet-black pigment across the full torso both legs neck to ankle, soaked by pouring rain",
   "VIVID silver rain streaking down in bright lines, white highlights glittering on every water bead and rivulet, and splashes bursting around her feet", "mirror-wet glossy"),
]
def chk(t): return not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t) and "navel" not in t.lower()

import sys
sys.path.insert(0, "../master")
import mdefs as D
import mk_newmakeup as NM
G0 = face.__globals__["G"]; _orig_pm = G0.pick_makeup
NM.extend(G0)
NEWV["wetpaint"] = []
NEWV["crystalp"] = []
MODEMAP = {}
MODEKO = {"both": "머리+얼굴 젖음", "hair": "머리만 젖음", "none": "안 젖음"}
_prev_nv = person_nv
def person_nv(label, key, phys, age, pose, eth):
    if key not in ("wetpaint", "crystalp"): return _prev_nv(label, key, phys, age, pose, eth)
    v = CUR_VAR[(label, key)]; nmw = v["nmw"]; nm = "the wet paint"
    pn, pd = phys; p = f"{label}: " if label else ""
    md = MODEMAP.get(label, "none")
    hairtxt = hair() + (", soaking wet, slicked and clinging in wet strands" if md in ("hair", "both") else "")
    sheen = "water droplets beading across her skin and a wet glistening sheen" if md == "both" else "a soft sheen of natural oils"
    mat = v["mat"] if "mat" in v else HEAD.format(desc=v["desc"], solid=v["solid"]) + v["T"].format(base=v["base"], acc=v["acc"], fin=v["fin"])
    feat, seg, info = face(eth); skin = eth[1]
    hl = HEEL_ if HEELMODE[0] == "forty" else HEEL_REL
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of the same {nmw}, each with {hl}, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, made of the same {nmw} with a high polish."
    fc = f"{p}Face: her face and ears are NOT {nm} — they are real living flesh with real pores, {sheen} and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hairtxt} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    return "\n".join([body, shoe, nails, jw, fc]), info

LIQE = {"샤워": "shower", "오일": "oil", "빗속": "rain"}
LIQ = {"샤워": ("soaked under a running shower", VS[1]["acc"], "mirror-wet glossy", None),
       "오일": ("drenched in thick clear body oil", VS[0]["acc"], "mirror-wet glossy", None),
       "빗속": ("soaked by pouring rain", VS[2]["acc"], "mirror-wet glossy", "outdoor")}
COLS = {  # key: (영어 형용사, base 색 문장, 한글)
 "jet-black": ("jet-black", "BLAZING deep jet-black pigment across the full torso both legs neck to ankle", "블랙", "black"),
 "midnight-blue": ("midnight-blue", "BLAZING deep midnight-blue pigment across the full torso both legs neck to ankle", "미드나이트 블루", "navy"),
 "deep emerald": ("deep emerald", "BLAZING deep emerald-green pigment across the full torso both legs neck to ankle", "딥 에메랄드", "emerald"),
 "burgundy": ("burgundy", "BLAZING deep burgundy-wine pigment across the full torso both legs neck to ankle", "버건디", "burgundy"),
 "cobalt": ("cobalt", "BLAZING cobalt-blue pigment across the full torso both legs neck to ankle", "코발트", "cobalt"),
 "crimson": ("crimson", "BLAZING saturated crimson-red pigment across the full torso both legs neck to ankle", "크림슨", "crimson"),
 "bronze": ("bronze", "BLAZING deep metallic bronze-gold pigment across the full torso both legs neck to ankle", "브론즈", "bronze"),
}
def solid_v(key, liq):
    adj, base, ko, nmc = COLS[key]; how, acc, fin, _ = LIQ[liq]
    return V(f"젖은 {ko}", f"{LIQE[liq]}-drenched glistening {adj}", "wet-look", f"glistening wet {nmc}", T_WET, f"{base}, {how}", acc, fin)
CRY = {"rose": ("ROSE QUARTZ PINK", "SOFT GOLD", "rose quartz crystal", "로즈쿼츠"), "smoky": ("SMOKY GREY", "CHARCOAL", "smoky quartz crystal", "스모키쿼츠")}
def crystal_v(key):
    c1, c2, sh, ko = CRY[key]
    mat = (f"full body {sh} clusters growing directly out of her own skin covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, every crystal point erupting outward from beneath the surface of her living skin in true three-dimensional relief, each facet catching its own individual glint and casting its own small hard shadow onto the skin and onto neighbouring crystals, nothing lying flat. Dense overlapping clusters — BLAZING {c1} crystal points erupting across the full torso both legs neck to ankle, VIVID {c2} mineral veins and undertone glinting through the thinnest points filling every remaining gap with real depth and texture, each facet sharply faceted and distinct, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    return dict(tag=f"석영 {ko}", nmw=sh, mat=mat, desc=sh, solid="crystal")
# (이름, 인원, 액체, [(종류, 키)])  종류: solid=젖은 단색, bodypaint/irezumi/uvneon=일반(젖지 않은) 바디페인팅

import json, collections
_g = open("../master/gen_extreme.py", encoding="utf-8").read()
exec(_g[_g.index("B_INS = ("):_g.index("PAINT_S")])
STY = ['코갸루', '마이코', '경극', '혼례(연지곤지)', '둔황 비천풍', '글래스 스킨', '강남언니', '인스타글램', '구풍', '홍콩풍', '아마갸루', '걸크러시', '지뢰계', '야마바', '만바', '반바', '아게하',
       '히메갸루', '오네에갸루', '로리타 갸루', '야미카와', '데코라', '웨이쉰', '브리티시 모드']
G0.pick_makeup = (lambda _r, style=None: _orig_pm(_r, style=_r.choice(STY)))
FULL = "across the full torso both legs neck to ankle"
# ── 템플릿 ──
T_CHROME = LEAD + "a seamless liquid-metal chrome shell with a perfect mirror finish, reflecting the surroundings in sharp warped images that bend over every curve, hard bright white highlights and deep dark reflections side by side, smooth and seamless with no joints, nothing lying flat. Dense mirror surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_HOLO = LEAD + "a holographic iridescent foil that shifts colour across every curve, bands of colour sliding across the surface as the angle changes, fine prismatic sparkle and sharp bright highlights, nothing lying flat. Dense holographic surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_RHINE = LEAD + "thousands of tiny faceted rhinestone crystals set edge to edge in dense rows that follow her curves, each stone with its own sharp star-shaped glint and rainbow flash, larger stones scattered among the tiny ones, the stones standing in relief over every curve so the surface is never flat, nothing lying flat. Dense crystal surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_POWDER = LEAD + "a thick coat of vivid coloured powder dusted and smeared over her entire body in dense overlapping layers of different colours, big clouds of coloured powder bursting into the air around her and drifting down, powder caked into every crease, nothing lying flat. Dense powder surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_SPLASH = LEAD + "thick wet splashes and splatters of vivid paint thrown over her entire body in overlapping layers, heavy drips running down every curve, big arcs of paint flying through the air around her, glossy wet paint catching the light, nothing lying flat. Dense paint-splashed surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_PROJ = "mapped onto her body and curving to follow its true three-dimensional shape, animated light patterns projected from several unseen projectors onto her skin, the patterns sharp and luminous with crisp edges and slightly warped over every bulge, pools of coloured light spilling onto the floor and faint beams of light visible in the air. Dense projected surface — {base}, {acc}, {fin}, completely covering her whole body, NO airbrush NO gradient wash, NO flat printed surface anywhere"
HEAD_P = HEAD.replace("fused directly to", "projected onto").replace("a solid {solid} ", "{solid} ")
def AV(tag, desc, solid, nmw, T, base, acc, fin, part, head=None):
    return dict(tag=tag, desc=desc, solid=solid, nmw=nmw, T=T, base=base, acc=acc, fin=fin, part=part, head=head or HEAD)
CH_SILVER = AV("크롬 · 실버", "mirror-polished liquid chrome", "liquid chrome", "mirror chrome", T_CHROME, f"BLAZING flawless mirror-silver chrome {FULL}", "VIVID pale blue and warm white reflections warping over every curve, with sharp white highlights streaking along her sides", "mirror-polished", "the chrome")
CH_ROSE = AV("크롬 · 로즈골드", "mirror-polished rose-gold liquid chrome", "liquid chrome", "rose-gold chrome", T_CHROME, f"BLAZING flawless mirror rose-gold chrome {FULL}", "VIVID warm pink and amber reflections warping over every curve, with sharp white highlights streaking along her sides", "mirror-polished", "the chrome")
HO_PINK = AV("홀로그램 · 핑크시안", "iridescent holographic foil", "holographic foil", "holographic foil", T_HOLO, f"BLAZING pink, cyan and violet holographic foil {FULL}", "VIVID bands of gold and lime flashing through the foil, and fine prismatic sparkle across every curve", "mirror-bright foil", "the foil")
RH_AB = AV("라인스톤 · 오로라", "aurora-borealis rhinestone-encrusted", "rhinestone crystal", "rhinestone crystals", T_RHINE, f"BLAZING clear aurora-borealis rhinestones flashing blue, pink and green {FULL}", "VIVID a few larger silver-white stones and tiny gold stones scattered among them", "faceted crystal", "the crystal")
RH_PINK = AV("라인스톤 · 핫핑크", "hot-pink rhinestone-encrusted", "rhinestone crystal", "rhinestone crystals", T_RHINE, f"BLAZING hot-pink rhinestones {FULL}", "VIVID a few larger clear stones and tiny silver stones scattered among them", "faceted crystal", "the crystal")
RH_JET = AV("라인스톤 · 제트블랙", "jet-black rhinestone-encrusted", "rhinestone crystal", "rhinestone crystals", T_RHINE, f"BLAZING jet-black rhinestones {FULL}", "VIVID a few larger silver stones and tiny clear stones flashing among them", "faceted crystal", "the crystal")
PW_HOLI = AV("파우더 · 홀리", "colour-powder-covered", "coloured powder", "vivid pigment", T_POWDER, f"BLAZING magenta, sunny yellow, bright cyan and orange powder in overlapping bands {FULL}", "VIVID big bursting clouds of the same colours hanging in the air around her and powder handprints smeared across her skin", "matte powdery", "the powder")
SP_MC = AV("스플래시 · 마젠타시안", "paint-splashed", "wet paint", "glossy paint", T_SPLASH, f"BLAZING hot magenta and electric cyan paint splashed in overlapping layers {FULL}", "VIVID a few splashes of bright yellow and white paint and long drips running down her legs", "wet glossy paint", "the paint")
SP_YB = AV("스플래시 · 노랑파랑", "paint-splashed", "wet paint", "glossy paint", T_SPLASH, f"BLAZING sunny yellow and deep ultramarine-blue paint splashed in overlapping layers {FULL}", "VIVID a few splashes of bright orange and white paint and long drips running down her legs", "wet glossy paint", "the paint")
PJ_GRID = AV("프로젝션 · 사이버 격자", "animated light-pattern", "pure projected light", "projection-lit pearl-white gloss", T_PROJ, f"BLAZING electric cyan and magenta neon grid lines and geometric shapes {FULL}", "VIVID bright white pulses of light racing along the grid lines", "luminous projected light", "the projected light", HEAD_P)
PJ_KAL = AV("프로젝션 · 만화경", "animated light-pattern", "pure projected light", "projection-lit pearl-white gloss", T_PROJ, f"BLAZING violet, gold and teal kaleidoscope mandala patterns {FULL}", "VIVID mirrored petals of white light opening and closing across her torso", "luminous projected light", "the projected light", HEAD_P)
PJ_OCEAN = AV("프로젝션 · 물결빛", "animated light-pattern", "pure projected light", "projection-lit pearl-white gloss", T_PROJ, f"BLAZING deep blue and turquoise rippling water-caustic light {FULL}", "VIVID bright white caustic lines shimmering across every curve", "luminous projected light", "the projected light", HEAD_P)
def mat_of(v): return v["head"].format(desc=v["desc"], solid=v["solid"]) + v["T"].format(base=v["base"], acc=v["acc"], fin=v["fin"])
NEWV["areap"] = []
_prev_a = person_nv
def person_nv(label, key, phys, age, pose, eth):
    if key != "areap": return _prev_a(label, key, phys, age, pose, eth)
    v = CUR_VAR[(label, key)]; nmw = v["nmw"]; nm = v["part"]
    pn, pd = phys; p = f"{label}: " if label else ""
    mat = mat_of(v)
    feat, seg, info = face(eth); skin = eth[1]
    hl = HEEL_ if HEELMODE[0] == "forty" else HEEL_REL
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of the same {nmw}, each with {hl}, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, made of the same {nmw} with a high polish."
    fc = f"{p}Face: her face and ears are NOT {nm} — they are real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair()} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    return "\n".join([body, shoe, nails, jw, fc]), info
T_HOLO2 = LEAD + "a seamless iridescent liquid-metal shell with an oil-slick holographic sheen, colours sliding across every curve as the angle changes, fine prismatic sparkle and sharp bright mirror highlights, smooth and seamless with no seams or edges, nothing lying flat. Dense holographic surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
HO_FIX = AV("홀로그램 · 핑크시안(액체 크롬형)", "iridescent holographic liquid chrome", "holographic liquid chrome", "holographic chrome", T_HOLO2, f"BLAZING pink, cyan and violet oil-slick holographic chrome {FULL}", "VIVID bands of gold and lime flashing through the sheen, and fine prismatic sparkle across every curve", "mirror-polished", "the chrome")
HO_MINT = AV("홀로그램 · 민트라일락(액체 크롬형)", "iridescent holographic liquid chrome", "holographic liquid chrome", "holographic chrome", T_HOLO2, f"BLAZING mint-green, lilac and peach oil-slick holographic chrome {FULL}", "VIVID bands of electric blue and silver flashing through the sheen, and fine prismatic sparkle across every curve", "mirror-polished", "the chrome")
T_POWDER2 = LEAD + "a thick packed coat of vivid coloured pigment powder pressed onto her entire skin in one continuous matte layer, deep overlapping smears and handprints of colour blending into one another, powder caked into every crease and pooling in every hollow, a haze of coloured powder hanging in the air around her, nothing lying flat. Dense powder surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_SPLASH2 = LEAD + "thick wet paint splashed and splattered over her entire body in overlapping layers until no skin shows, a continuous glossy coat of vivid paint over every curve, heavy drips running down every curve, big arcs of paint flying through the air around her, nothing lying flat. Dense paint-splashed surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
PW_A = AV("파우더 · 홀리(수정)", "pigment-caked", "packed pigment powder", "vivid pigment", T_POWDER2, f"BLAZING magenta, sunny yellow, bright cyan and orange powder in overlapping smeared layers {FULL}", "VIVID powder handprints smeared across her skin and thick colour pooled in every hollow", "matte powdery", "the powder")
PW_B = AV("파우더 · 핑크블루(수정)", "pigment-caked", "packed pigment powder", "vivid pigment", T_POWDER2, f"BLAZING hot pink and royal blue powder in overlapping smeared layers {FULL}", "VIVID powder handprints smeared across her skin and thick colour pooled in every hollow", "matte powdery", "the powder")
SP_MC2 = AV("스플래시 · 마젠타시안(수정)", "paint-splashed", "wet paint", "glossy paint", T_SPLASH2, f"BLAZING hot magenta and electric cyan paint splashed in overlapping layers {FULL}", "VIVID a few splashes of bright yellow and white paint and long drips running down her legs", "wet glossy paint", "the paint")
SP_YB2 = AV("스플래시 · 노랑파랑(수정)", "paint-splashed", "wet paint", "glossy paint", T_SPLASH2, f"BLAZING sunny yellow and deep ultramarine-blue paint splashed in overlapping layers {FULL}", "VIVID a few splashes of bright orange and white paint and long drips running down her legs", "wet glossy paint", "the paint")
T_RHINE2 = LEAD + "thousands of tiny faceted rhinestone crystals packed tightly together directly onto her skin with no skin showing between them, stones overlapping at random angles in thick layers, each stone with its own sharp star-shaped glint and rainbow flash, larger stones scattered among the tiny ones, the stones standing in relief over every curve so the surface is never flat, nothing lying flat. Dense crystal surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
def RH2(v): d = dict(v); d["T"] = T_RHINE2; d["tag"] = v["tag"] + "(수정)"; return d

# ═══════════ 새 영역 4종 번들 (크롬·라인스톤·프로젝션·스플래시) ═══════════
import json, collections
from retitle import agg, mk_clean, pose_ko
_g = open("../master/gen_extreme.py", encoding="utf-8").read()
exec(_g[_g.index("B_INS = ("):_g.index("PAINT_S")])
exec(_g[_g.index("SEAT = ["):_g.index("for _p in SEAT")])
EXTREME = ("USSBBW", "hourglass SSBBW")
BODIES22 = [b for b in D.BODIES if not b[0].startswith("pregnant")]
assert len(BODIES22) == 22
def phys_of(b, solo):
    if b[0] in EXTREME:
        return (b[0], b[1] + "; " + B_INS.format(edge=", her body so wide that her hips nearly touch the left and right edges of the frame" if solo else ""))
    return (b[0], b[1])

# ── 주얼리: 라인스톤은 팔다리만, 나머지는 배꼽 항목만 제외 ──
JW_ALL = ns2["JW"]
JW_LIMB = ["thick polished gold bangles stacked on both wrists", "sculpted gold armbands high on both upper arms", "a fine gold chain looped around her thigh above the knee", "heavy gold rings on every finger"]
JW_NONAVEL = [j for j in JW_ALL if "navel" not in j]
assert len(JW_NONAVEL) == 8
CURFAM = ["x"]
def jewel_fam(p):
    lab = p.split(":")[0] if p else None
    fam = CUR_VAR[(lab, "areap")]["fam"] if (lab and (lab, "areap") in CUR_VAR) else CURFAM[0]
    pool = JW_LIMB if fam == "rhine" else JW_NONAVEL
    a = ns2["JR"].sample(pool, 3)
    return ", ".join(a[:-1]) + ", and " + a[-1] + ". Jewelry is metal and pearl only, worn on the body, nothing added to her face or ears."
ns2["jewel"] = jewel_fam

# ── 변형표 ──
def XV(fam, ko, T, desc, solid, nmw, base, acc, fin, part, head=None):
    d = AV(ko, desc, solid, nmw, T, base, acc, fin, part, head); d["fam"] = fam; d["ko"] = ko; return d
def CH(ko, adj, nmc, base, acc):
    return XV("chrome", ko, T_CHROME, f"mirror-polished {adj}liquid chrome", "liquid chrome", f"{nmc}chrome".strip() if nmc else "mirror chrome",
              f"BLAZING flawless mirror {base} chrome {FULL}", f"VIVID {acc} reflections warping over every curve, with sharp white highlights streaking along her sides", "mirror-polished", "the chrome")
CHROME = [  # (변형, 가중치) — 실버는 Kintsugi 액체 실버와 겹쳐 비중을 낮춘다
 (CH("실버", "", "", "silver", "pale blue and warm white"), 0.5), (CH("로즈골드", "rose-gold ", "rose-gold ", "rose-gold", "warm pink and amber"), 1.0),
 (CH("골드", "gold ", "gold ", "gold", "warm orange and pale yellow"), 1.0), (CH("코퍼", "copper ", "copper ", "copper", "deep red-brown and amber"), 1.0),
 (CH("건메탈", "gunmetal ", "gunmetal ", "dark gunmetal", "cool steel-blue and white"), 1.0), (CH("블랙", "black ", "black ", "jet-black", "deep blue and violet"), 1.0),
 (CH("코발트", "cobalt-blue ", "cobalt-blue ", "cobalt-blue", "pale cyan and white"), 1.0)]
def RH(ko, adj, base, acc):
    return XV("rhine", ko, T_RHINE2, f"{adj}rhinestone-encrusted", "rhinestone crystal", "rhinestone crystals", f"BLAZING {base} {FULL}", f"VIVID {acc}", "faceted crystal", "the crystal")
RHINE = [(RH("오로라", "aurora-borealis ", "clear aurora-borealis rhinestones flashing blue, pink and green", "a few larger silver-white stones and tiny gold stones scattered among them"), 1.0),
 (RH("핫핑크", "hot-pink ", "hot-pink rhinestones", "a few larger clear stones and tiny silver stones scattered among them"), 1.0),
 (RH("제트블랙", "jet-black ", "jet-black rhinestones", "a few larger silver stones and tiny clear stones flashing among them"), 1.0),
 (RH("다이아몬드", "diamond-clear ", "diamond-clear rhinestones", "a few larger pale-blue stones and tiny silver stones flashing among them"), 1.0),
 (RH("골드", "gold ", "gold rhinestones", "a few larger clear stones and tiny amber stones scattered among them"), 1.0),
 (RH("루비레드", "ruby-red ", "ruby-red rhinestones", "a few larger clear stones and tiny gold stones scattered among them"), 1.0),
 (RH("에메랄드", "emerald-green ", "emerald-green rhinestones", "a few larger clear stones and tiny gold stones scattered among them"), 1.0),
 (RH("로열블루", "royal-blue ", "royal-blue rhinestones", "a few larger clear stones and tiny silver stones scattered among them"), 1.0)]
def PJ(ko, base, acc):
    return XV("proj", ko, T_PROJ, "animated light-pattern", "pure projected light", "projection-lit pearl-white gloss", f"BLAZING {base} {FULL}", f"VIVID {acc}", "luminous projected light", "the projected light", HEAD_P)
PROJ = [(PJ("사이버 격자", "electric cyan and magenta neon grid lines and geometric shapes", "bright white pulses of light racing along the grid lines"), 1.0),
 (PJ("만화경", "violet, gold and teal kaleidoscope mandala patterns", "mirrored petals of white light opening and closing across her torso"), 1.0),
 (PJ("물결빛", "deep blue and turquoise rippling water-caustic light", "bright white caustic lines shimmering across every curve"), 1.0),
 (PJ("은하수", "deep indigo and violet starfield with drifting nebula clouds of light", "tiny white stars twinkling and bright streaks of light racing across every curve"), 1.0),
 (PJ("불꽃", "flowing orange and crimson flames licking up across every curve", "bright yellow embers and sparks floating across her skin"), 1.0),
 (PJ("오로라 리본", "flowing green and pink aurora ribbons sweeping across every curve", "bright white sparkling edges glowing along the ribbons"), 1.0),
 (PJ("모자이크", "mosaic tiles of red, blue, gold and green light covering every curve", "bright white glowing lines between the tiles"), 1.0)]
def SP(ko, c1, c2, c3):
    return XV("splash", ko, T_SPLASH2, "paint-splashed", "wet paint", "glossy paint", f"BLAZING {c1} and {c2} paint splashed in overlapping layers {FULL}",
              f"VIVID a few splashes of bright {c3} and white paint and long drips running down her legs", "wet glossy paint", "the paint")
SPLASH = [(SP("마젠타시안", "hot magenta", "electric cyan", "yellow"), 1.0), (SP("노랑파랑", "sunny yellow", "deep ultramarine-blue", "orange"), 1.0),
 (SP("오렌지틸", "bright orange", "deep teal", "yellow"), 1.0), (SP("핑크바이올렛", "hot pink", "deep violet", "cyan"), 1.0),
 (SP("레드블랙", "crimson-red", "jet-black", "gold"), 1.0), (SP("라임퍼플", "lime-green", "electric purple", "yellow"), 1.0),
 (SP("터콰이즈코랄", "bright turquoise", "coral-pink", "white"), 1.0)]
AREAS = {"chrome": ("크롬", CHROME), "rhine": ("라인스톤", RHINE), "proj": ("프로젝션", PROJ), "splash": ("스플래시", SPLASH)}
SERIES = {"chrome": "Chrome", "rhine": "Rhinestone", "proj": "Projection", "splash": "Splash", "mix": "Mix4"}
CATS = {"chrome": "🏺 Living Artifact · Chrome Formula", "rhine": "🏺 Living Artifact · Rhinestone Formula", "proj": "🏺 Living Artifact · Projection Formula",
        "splash": "🏺 Living Artifact · Splash Formula", "mix": "🏺 Living Artifact · Four-Element Mix Formula"}
PREF = {"chrome": "la_chrome_", "rhine": "la_rhine_", "proj": "la_proj_", "splash": "la_splash_", "mix": "la_a4mix_"}
NAMES = {1: "solo", 2: "duo", 3: "trio", 4: "quartet", 5: "quintet"}; KOCNT = {1: "솔로", 2: "듀오", 3: "트리오", 4: "쿼르텟", 5: "퀸텟"}
rg = random.Random(20261401); rr.seed(20261401); ns2["JR"].seed(20261401)
SEEN = set()
def pick_var(area, exclude=()):
    ko, L = AREAS[area]
    for _ in range(100):
        v = rg.choices([x[0] for x in L], [x[1] for x in L])[0]
        if v["ko"] not in exclude: return v
    raise SystemExit("pick_var")

NEWV["clothp"] = []
_prev_c = person_nv
def person_nv(label, key, phys, age, pose, eth):
    if key != "clothp": return _prev_c(label, key, phys, age, pose, eth)
    c = CUR_VAR[(label, key)]; nmw = c["nmw"]
    pn, pd = phys; p = f"{label}: " if label else ""
    feat, seg, info = face(eth); skin = eth[1]
    hl = HEEL_ if HEELMODE[0] == "forty" else HEEL_REL
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of {nmw}, each with {hl}, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, in {nmw} with a high polish."
    fc = f"{p}Face: her face is bare of any garment — real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair()} — {c['text']}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    return "\n".join([body, shoe, nails, jw, fc]), info
BODY = {b[0]: b for b in BODIES22}
CUSTOM = {
 1: ("muscular big bust", "an enormous, overwhelmingly muscular woman; massive thick arms with heavy defined muscle, broad powerful shoulders and a broad powerful back, a heavy dense muscular torso with a deeply carved abdomen, and a colossal full bust resting heavy and wide on her powerful chest, far wider than her shoulders and projecting well forward; her waist still draws in with a visible inward pull; enormous round hips and gigantic thighs with huge defined quadriceps and hamstrings, deep muscle separation and heavy swelling muscle bulging in every direction, thick heavy calves; her head looks small on top of her massive body; her arms, hands, legs and feet stay in correct proportion to each other"),
 2: ("amazon big bust", "an extraordinarily tall and enormous woman, far beyond any real person, towering and broad; a commanding statuesque frame with huge broad shoulders, powerful thick arms with hard defined muscle, a long dense muscular torso, and a colossal full bust projecting well forward above it, far wider than her shoulders; her waist draws in with a visible inward pull; enormous powerful hips and colossal long thighs with huge hard-defined quadriceps and hamstrings, deep muscle separation sweeping from hip to knee, thick strong calves; her arms, hands, legs and feet stay in correct proportion to each other")}

# ═══════════ 의상 번들 400 ═══════════
import collections
O_ = "/mnt/user-data/outputs/"
PB = ("옥상 테라스", "야외 테라스", "여름 해변", "하얀 안뜰", "바닷가 산책로")
TAIL_BAND = ", leaving the curve of her bust visible above and below it, no other garment on her chest, her stomach fully visible below it"
def micro_bot(c): return f"a minimal {c} micro bikini bottom of one tiny low-rise opaque triangle on thin side strings tied at the hips, the small opaque piece fully covering her"
def T_band2(c): return f"a micro strapless {c} bandeau reduced to the narrowest possible strip only two fingers tall, stretched tightly across the middle of her bust and covering only what it must, leaving the curve of her bust visible above and below it, her stomach fully visible below it"
T_HARN = "a minimal black leather harness bra of small molded triangle cups on thin crossing straps with silver ring hardware, the small opaque cups fully covering her bust, her stomach fully visible below it"
T_BALC = "a black leather balconette bra with molded lifting cups, a lace-up front and thin straps, a narrow band under the cups and nothing below it, her whole stomach bare and fully visible, the cups fully covering her bust"
T_MTOP = "a tiny gold sequin micro-bikini top of two small opaque triangle cups on thin strings tied at the neck and back, fully covering her bust"
T_PLUNGE = "a minimal red satin corset-style top reduced to two small opaque molded cups noticeably smaller than normal cups on thin straps, leaving more of the curve of her bust visible around them, short and ending just below her bust, with an extremely wide plunging V neckline that spreads as far apart as possible across her chest and runs down to the bottom of the corset, where its bottom tip stays closed and joined in a neat point right under her bust with no split or gap at the bottom, no boning or band below that point, the small opaque cups still fully covering what they cover, her whole stomach bare below it"
def T_crop(c): return f"a fitted {c} crop top ending at her ribcage and fully covering her bust"
T_BUSTIER = "a structured black leather corset-style bustier top with molded cups lifting and pushing her bust together, boned and laced at the sides and fully covering her bust"
T_HALTER = "a tiny gold sequin halter top of small opaque triangle cups tied at the neck and back and fully covering her bust"
def pool_tops(c, ckor, extra=()):
    """상의 풀: (ko, text). c = 스커트 소재 영어, ckor = 한글 소재"""
    L = [("밴도", T_band2(c)), ("크롭탑", T_crop(c)), ("하네스 브라", T_HARN), ("발코네트 브라", T_BALC), ("마이크로 탑", T_MTOP), ("플런지 코르셋", T_PLUNGE)]
    return L + list(extra)

FAM = []   # (pref, series, cat_key, entries)  entries: (ko, nmw, text, bgs, bodies)
CATK = {"bust": "🏺 Living Artifact · Bust Outfit Formula", "swim": "🏺 Living Artifact · Swimwear Formula", "latex": "🏺 Living Artifact · Latex & Mesh Formula",
        "gown": "🏺 Living Artifact · Gown Formula", "skirt": "🏺 Living Artifact · Skirt Outfit Formula", "band": "🏺 Living Artifact · Band & Belt Formula"}
R = random.Random(20267001)
BUST2 = ("legendary bust", "curved bust")
# A. 가슴 특화 × 상의 5종 (50)
F_A = []
TOPS_A = [("플런지 코르셋 탑 레드 새틴", "glossy red satin", f"wearing {micro_bot('red satin')}, paired with {T_PLUNGE}"),
          ("하네스 브라 블랙 레더", "glossy black leather", f"wearing {micro_bot('black leather')}, paired with {T_HARN}"),
          ("마이크로 비키니 탑 골드 시퀸", "sparkling gold sequin", f"wearing {micro_bot('gold sequin')}, paired with {T_MTOP}"),
          ("발코네트 코르셋 브라 블랙 레더", "glossy black leather", f"wearing {micro_bot('black leather')}, paired with {T_BALC}"),
          ("초소형 밴도 블랙 레더", "glossy black leather", f"wearing {micro_bot('black leather')}, paired with {T_band2('black leather')}")]
for ko, nmw, tx in TOPS_A:
    for j in range(10): F_A.append((ko, nmw, tx, None, BUST2))
R.shuffle(F_A); FAM.append(("la_clothes_bust_", "Bust", "bust", F_A))
# B. 초소형 밴도 × 체형 (30)
F_B = []
for ko, c, nmw in (("초소형 밴도 블랙 레더", "black leather", "glossy black leather"), ("초소형 밴도 레드 새틴", "red satin", "glossy red satin"), ("초소형 밴도 화이트 레더", "white leather", "glossy white leather")):
    for j in range(10): F_B.append((ko, nmw, f"wearing {micro_bot(c)}, paired with {T_band2(c)}", None, None))
R.shuffle(F_B); FAM.append(("la_clothes_bandeau_", "Bandeau", "bust", F_B))
# C. 마이크로 비키니 (30)
MB = [("마이크로 비키니 블랙", "glossy black", "wearing a tiny black micro bikini of small opaque triangle cups on thin strings and a minimal low-rise string bottom, the small opaque pieces fully covering her, tied at the neck, back and hips"),
      ("마이크로 비키니 골드 메탈", "polished gold metal", "wearing a tiny gold micro bikini of small polished gold-metal triangle cups joined by thin gold chains and a minimal gold-chain-and-plate bottom, the small opaque pieces fully covering her"),
      ("마이크로 비키니 레드 젖음", "glossy wet red", "wearing a tiny glossy red micro bikini of small opaque triangle cups and a minimal low-rise string bottom, soaked and clinging, water streaming down her whole body in glistening rivulets with countless beads and droplets clinging to her skin, her hair soaking wet and slicked")]
def nip_top(c): return f"wearing a minimal {c} micro bikini bottom of one tiny low-rise opaque triangle on thin side strings tied at the hips, the small opaque piece fully covering her, paired with a {c} micro-bikini top reduced to two tiny opaque triangles on thin strings tied at the neck and back, each just big enough to cover only her nipple and nothing more, leaving the rest of her bust visible around them, her stomach fully visible below"
F_C = []
for (ko, nmw, tx), n in zip(MB, (7, 7, 6)):
    for j in range(n): F_C.append((ko, nmw, tx, PB, BUST2))
for ko, c, n in (("유두만 마이크로 비키니 블랙 레더", "black leather", 4), ("유두만 마이크로 비키니 화이트 레더", "white leather", 3), ("유두만 마이크로 비키니 딥 퍼플 레더", "deep purple leather", 3)):
    for j in range(n): F_C.append((ko, f"glossy {c}", nip_top(c), None, BUST2))
R.shuffle(F_C); FAM.append(("la_clothes_microbik_", "MicroBikini", "swim", F_C))
# D. 일반 비키니 (30)
BK = [("하이웨이스트 비키니 코랄 레드", "glossy coral-red", "wearing a high-waisted coral-red bikini with a structured bandeau top and high-cut bottoms in glossy fabric, fitted to every curve", 8),
      ("스트링 비키니 골드", "polished gold", "wearing a gold string bikini with a triangle top and low-rise side-tie bottoms, thin straps tied at the neck and hips, fitted to every curve", 8),
      ("크롬 비키니", "mirror-polished liquid chrome", "wearing a mirror-polished liquid-chrome bikini, a sculpted bandeau top and high-cut bottoms of seamless silver metal reflecting the surroundings in sharp warped images", 7),
      ("젖은 비키니 블랙", "glossy wet black", "wearing a jet-black glossy halter bikini with high-cut bottoms, soaked and clinging, water streaming down her whole body in glistening rivulets with countless beads and droplets clinging to her skin, her hair soaking wet and slicked", 7)]
DB = [(ko, nmw, tx, PB, None) for ko, nmw, tx, n in BK for j in range(n)]; R.shuffle(DB); FAM.append(("la_clothes_bikini_", "Bikini", "swim", DB))
# E. 라텍스 캣슈트 (30)
LAT = [("크림슨 레드", "crimson-red"), ("젯 블랙", "jet-black"), ("화이트", "white"), ("코발트 블루", "cobalt-blue"), ("딥 퍼플", "deep purple")]
F_E = [(f"라텍스 캣슈트 {k}", f"glossy {c} latex", f"wearing a skin-tight glossy {c} latex catsuit with a high collar zipped up the front to the sternum and long sleeves, stretched over every curve from neck to ankle with mirror shine and fine pull-creases at the elbows and knees, completely opaque, the only exposed skin her face and hands", None, None) for k, c in LAT for j in range(6)]
R.shuffle(F_E); FAM.append(("la_clothes_latex_", "Latex", "latex", F_E))
# F. 시어 메시 보디수트 (30)
MSH = [("블랙", "jet-black", 8), ("화이트", "white", 8), ("딥 레드", "deep red", 7), ("네이비", "navy", 7)]
F_F = [(f"시어 메시 보디수트 {k}", f"glossy {c}", f"wearing a long-sleeved {c} sheer mesh bodysuit with opaque embroidered lace appliqué panels covering the bust, hips and seams, a high lace collar and high-cut legs, fitted to every curve", None, None) for k, c, n in MSH for j in range(n)]
R.shuffle(F_F); FAM.append(("la_clothes_mesh_", "Mesh", "latex", F_F))
# G. 컷아웃 (40)
F_G = []
for c, ck in (("white", "화이트"), ("black", "블랙"), ("ivory", "아이보리")):
    for j in range(4): F_G.append((f"컷아웃 롱 {ck}", f"glossy {c}", f"wearing a sleek floor-length {c} jersey gown with large cutouts at both sides of the waist, narrow straps crossing the torso and a high leg slit up to the hip, hugging every curve", None, None))
for c, ck in (("red", "레드"), ("white", "화이트"), ("cobalt-blue", "코발트")):
    for j in range(3 if c != "red" else 4): F_G.append((f"컷아웃 미니 {ck}", f"glossy {c}", f"wearing a sleek {c} jersey mini dress ending at mid-thigh with large cutouts at both sides of the waist and narrow straps crossing the torso, hugging every curve", None, None))
for c, ck in (("black", "블랙"), ("red", "레드"), ("white", "화이트")):
    for j in range(3 if c != "black" else 4): F_G.append((f"컷아웃 초미니 {ck}", f"glossy {c}", f"wearing a sleek {c} jersey ultra-mini dress ending at the very top of her thighs with large cutouts at both sides of the waist and narrow straps crossing the torso, hugging every curve", None, None))
for c, ck in (("emerald", "에메랄드"), ("crimson", "크림슨"), ("midnight-blue", "미드나이트 블루"), ("emerald", "에메랄드")):
    for j in range(2): F_G.append((f"새틴 슬릿 드레스 {ck}", f"liquid {c} satin", f"wearing a floor-length {c} liquid-satin slip gown with a plunging neckline and a thigh-high slit, clinging to every curve with silky highlights flowing along the folds", None, None))
R.shuffle(F_G); FAM.append(("la_clothes_cutout_", "Cutout", "gown", F_G))
# H. 플런지 배꼽까지 (30)
F_H = []
for c, ck in (("white", "화이트"), ("black", "블랙"), ("ivory", "아이보리")):
    for j in range(5): F_H.append((f"딥 플런지 롱 {ck}", f"glossy {c}", f"wearing a sleek floor-length {c} jersey gown with a deep plunging V neckline cut down to her belly button, the fabric edges hugging the sides of her bust, narrow straps over the shoulders, a high leg slit up to the hip, hugging every curve", None, None))
for c, ck in (("red", "레드"), ("white", "화이트"), ("black", "블랙")):
    for j in range(5): F_H.append((f"딥 플런지 미니 {ck}", f"glossy {c}", f"wearing a sleek {c} jersey mini dress ending at mid-thigh with a deep plunging V neckline cut down to her belly button, the fabric edges hugging the sides of her bust, narrow straps over the shoulders, hugging every curve", None, None))
R.shuffle(F_H); FAM.append(("la_clothes_plunge_", "Plunge", "gown", F_H))
# I. 슬릿 미니 5단계 (30) — 상의 랜덤
SK_MAT = [("black leather", "glossy black leather", "블랙 레더"), ("glossy red latex", "glossy red latex", "레드 라텍스"), ("white liquid-satin", "glossy white satin", "화이트 새틴")]
STEPS = [("1단계", "a skin-tight {c} micro-mini skirt with its hem at the very top of her thighs and a deep slit cut up the front center to the hip line"),
         ("2단계", "a skin-tight {c} micro-mini skirt with its hem a hand-width below her hips and a high slit cut up the left side to the hip bone"),
         ("3단계", "a skin-tight {c} mini skirt with its hem at the upper thigh and a high slit cut up the left side to the top of her thigh"),
         ("4단계", "a skin-tight {c} mini skirt with its hem at mid-thigh and a slit cut up the left side to the upper thigh"),
         ("5단계", "a skin-tight {c} skirt with its hem just above the knee and a slit cut up the left side to mid-thigh")]
F_I = []
for sk, st in STEPS:
    for j in range(6):
        c, nmw, ck = SK_MAT[0] if j < 3 else (SK_MAT[1] if j < 5 else SK_MAT[2])
        tko, ttx = R.choice(pool_tops(c, ck))
        F_I.append((f"슬릿 미니 {sk} {ck} + {tko}", nmw, f"wearing {st.format(c=c)}, paired with {ttx}", None, None))
R.shuffle(F_I); FAM.append(("la_clothes_slit_", "Slit", "skirt", F_I))
# J. 초미니 초하이 슬릿 + 상의 (30)
UM = [("black leather", "glossy black leather", "블랙 레더", "left"), ("white liquid-satin", "glossy white satin", "화이트 새틴", "right"), ("glossy red latex", "glossy red latex", "레드 라텍스", "left"), ("sparkling gold sequin", "sparkling gold sequin", "골드 시퀸", "right")]
F_J = []
for i in range(30):
    c, nmw, ck, side = UM[i % 4]
    tko, ttx = R.choice(pool_tops(c, ck))
    F_J.append((f"초미니 슬릿 {ck} + {tko}", nmw, f"wearing a skin-tight {c} ultra-mini skirt ending at the very top of her thighs with a slit cut up the {side} side all the way to the hip bone, paired with {ttx}", None, None))
R.shuffle(F_J); FAM.append(("la_clothes_umini_", "UltraMini", "skirt", F_J))
# K. 근육질 큰가슴 (20) — 허벅지 강조 체형 (CUSTOM 1,2)
F_K = []
for i in range(20):
    c, nmw, ck, side = UM[0] if i % 2 == 0 else UM[3]
    tko, ttx = R.choice(pool_tops(c, ck, extra=[("버스티에", T_BUSTIER), ("홀터 탑", T_HALTER)]))
    F_K.append((f"초미니 슬릿 {ck} + {tko}", nmw, f"wearing a skin-tight {c} ultra-mini skirt ending at the very top of her thighs with a slit cut up the {side} side all the way to the hip bone, paired with {ttx}", None, (1, 2)[i % 2 == 0 and 0 or 1] if False else None))
for i, e in enumerate(F_K): F_K[i] = e[:4] + ((1, 2)[i // 10],)
R.shuffle(F_K); FAM.append(("la_clothes_musc_", "MuscleBust", "bust", F_K))
# L. 벨트 (30)
def beltbra(c, bk): return f"a single wide {c} belt buckled around her chest as her only top, two fingers tall, pulled tightly across the middle of her bust with a {bk} buckle at the center front and the strap end tucked short, covering only what it must, leaving the curve of her bust visible above and below it, no other garment on her chest"
def beltskirt(c, bk): return f"a wide {c} belt buckled low around her hips as her skirt, one hand tall, fully opaque and fully covering her, with a {bk} buckle at her left hip and the strap end hanging short, no other garment on her hips"
BL = [("black leather", "블랙 레더", "silver")]
F_L = []
for i in range(15):
    c, ck, bk = BL[0]
    F_L.append((f"벨트 세트 {ck}", f"glossy {c}", f"wearing {beltskirt(c, bk)}, paired with {beltbra(c, bk)}, her stomach fully visible below it", None, None))
for i in range(15):
    c, ck, bk = BL[0]
    F_L.append((f"가슴 벨트 + 마이크로 미니 {ck}", f"glossy {c}", f"wearing a skin-tight {c} micro-mini skirt with its hem at the very top of her thighs, fully covering her, paired with {beltbra(c, bk)}, her stomach fully visible below it", None, None))
# M. 띠 (20): 스카프 8 · 퍼 6 · 포장지 6
F_M = []
SC = [("에메랄드", "emerald-green"), ("크림슨", "crimson"), ("아이보리", "ivory"), ("미드나이트 블루", "midnight-blue")]
for i in range(8):
    ck, c = SC[i % 4]; knot = "at the side of her bust right beside one breast" if i % 2 == 0 else "at her side just below her ribs"
    F_M.append((f"실크 스카프 랩 {ck}", f"{c} silk", f"wearing a skin-tight {c} silk micro-mini skirt with its hem at the very top of her thighs, fully covering her, paired with a {c} silk scarf folded into the narrowest possible strip only two fingers tall, stretched tightly across the middle of her bust and knotted in a small knot {knot}, one end of the silk trailing long down her side and the other end cut short, fully opaque and covering only what it must{TAIL_BAND}", None, None))
for i, (ck, c) in enumerate((("화이트", "white"), ("화이트", "white"), ("블랙", "black"), ("블랙", "black"), ("핑크", "pale pink"), ("핑크", "pale pink"))):
    F_M.append((f"퍼 밴도 {ck}", f"{c} faux fur", f"wearing a {c} faux-fur micro-mini skirt with its hem at the very top of her thighs, fully covering her, paired with a strapless thick {c} faux-fur bandeau reduced to the narrowest possible strip only two fingers tall, stretched tightly across the middle of her bust and covering only what it must{TAIL_BAND}", None, None))
for i, (ck, c, rb) in enumerate((("골드 무늬", "gold", "red"), ("골드 무늬", "gold", "red"), ("골드 무늬", "gold", "red"), ("실버 무늬", "silver", "blue"), ("실버 무늬", "silver", "blue"), ("실버 무늬", "silver", "blue"))):
    F_M.append((f"포장지 밴도 {ck}", f"{c} wrapping paper", f"wearing a skin-tight {c} wrapping-paper micro-mini skirt with its hem at the very top of her thighs, fully covering her, neatly folded with clean edges and no tears, paired with a strapless {c} wrapping-paper bandeau with a fine metallic pattern, neatly cut with clean edges and no tears, reduced to the narrowest possible strip only two fingers tall, stretched tightly across the middle of her bust and tied with a small {rb} ribbon bow at the center front, fully opaque and covering only what it must{TAIL_BAND}", None, None))
L_all = F_L; R.shuffle(L_all); FAM.append(("la_clothes_belt_", "Belt", "band", L_all))
R.shuffle(F_M); FAM.append(("la_clothes_band_", "Band", "band", F_M))


POOL = {}
for pref, series, ck, ents in FAM:
    for (ko, nmw, text, bgs, bodies) in ents:
        if bodies is not None: continue
        base = ko.split(" + ")[0] if series in ("Slit", "UltraMini") else ko
        key = f"{series}:{ko}"
        if key not in POOL: POOL[key] = (nmw, text, bgs)
print(len(POOL), list(POOL)[:40])
POSES = [p for p in POSES if "arms crossed under her bust" not in p and "framing the face" not in p]
rg = random.Random(20267302); rr.seed(20267302); ns2["JR"].seed(20267302)
o = ["# 의상 그룹 시험 4개 (2~5인, 사람마다 다른 의상)\n", "전 축 기본 랜덤(체형 22종·나이·포즈·인종·배경·힐 40인치 고정·네일·주얼리·메이크업). 번호별로 정상/이상만 알려주세요.\n"]
for gi, n in enumerate((2, 3, 4, 5), 1):
    for attempt in range(1500):
        CUR_VAR.clear()
        _ser = rg.sample(sorted({k.split(':')[0] for k in POOL}), n); names = [rg.choice([k for k in POOL if k.startswith(sr + ':')]) for sr in _ser]
        kinds = []; picks = []
        for idx, nm in enumerate(names):
            CUR_VAR[(f"#{idx+1}", "clothp")] = dict(text=POOL[nm][1], nmw=POOL[nm][0]); kinds.append("clothp"); picks.append(None)
        bs = []
        while len(bs) < n:
            c = rg.choice(BODIES22)
            if c[0] not in [x[0] for x in bs]: bs.append(c)
        physs = [phys_of(b, False) for b in bs]
        ages = [rg.choice(AGES) for _ in range(n)]; poses = [rg.choice(POSES) for _ in range(n)]; eths_ = rg.sample(ETH, n)
        bid, wx = BGL.pick(rg, n)
        allowed = [POOL[nm][2] for nm in names if POOL[nm][2]]
        if any(BGL.BG[bid][2] not in a for a in allowed): continue
        scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty"
        ns2["JR"].seed(rg.randrange(10**9))
        t, infos = build3(kinds, picks, physs, ages, poses, eths_, scene)
        t = t.replace("Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle.", "Extreme macro detail on the fabric texture, the skin and the shadows.")
        t = t.replace("no props or statues made of the same material as any of them.", "no props or statues.").replace("no props or statues made of the same material as her.", "no props or statues.")
        if not chk(t) or re.search(r"\b(foil|lens|sticker|doll)\b", t, re.I): continue
        if t.count("forty inches") != n or t.count("Jewelry:") != n or "Pattern density" in t: continue
        break
    else: raise SystemExit("fail")
    o.append(f"## {gi}. {n}인 · 의상 {' / '.join(x.split(':',1)[1] for x in names)} · 체형 {' / '.join(b[0] for b in bs)} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''}\n\n```\n{t}\n```\n")
    print(gi, n, names, len(t.split()))
open(O_ + "LumineX_ClothGroup4.md", "w", encoding="utf-8").write("\n".join(o))
