# -*- coding: utf-8 -*-
# 실버폭스 Structure Pack 120: 맥시멀리스트 전용 Structure Pack 원본(gen_s2pack_max.py 출력) → 실버폭스 K 60 + 국제 60, 맞물림 경계.
import json, random, re, sys, collections
HERE = "/tmp/claude-0/-home-claude/62db5eea-2487-540b-9935-a7df06448e2a/scratchpad/"
sys.path.insert(0, HERE + "sfv2"); sys.path.insert(0, HERE + "bi")
import sf_blend_lib as L, bi_lib as BI, apply_face_k as F
O = "/mnt/user-data/outputs/"
raw = json.load(open(HERE + "sfv2/la_s2pack_maxonly_120_raw.json", encoding="utf-8"))
rr = random.Random(20261008)
CAT = {"K": "🏺 Living Artifact · K-Silverfox Structure Pack Formula", "I": "🏺 Living Artifact · Silverfox Structure Pack Formula"}
PFX = {"K": "la_ksilverfox_s2pack", "I": "la_silverfox_s2pack"}
NM = {1: "solo", 2: "duo", 3: "trio"}; TY = {1: "Solo", 2: "Duo", 3: "Trio"}
PH = re.compile(r"(?:silver fox goddess|(?:early|mid|late) [45]0s), (.+?) physique THE MOST EXTREME")
out = []
for gs in (1, 2, 3):
    pool = [x for x in raw if x["meta"]["group_size"] == gs]; assert len(pool) == 40
    kinds = {}
    byst = collections.defaultdict(list)
    for x in pool: byst[x["meta"]["structures"][0].replace("맥시 ", "").split("·")[0]].append(x)
    flip = 0
    for st, g in byst.items():
        rr.shuffle(g)
        for i, x in enumerate(g): kinds[x["key"]] = "K" if (i + flip) % 2 == 0 else "I"
        flip += len(g) % 2
    ks = [k for k, v in kinds.items() if v == "K"]; is_ = [k for k, v in kinds.items() if v == "I"]
    while len(ks) > 20: k = ks.pop(); kinds[k] = "I"; is_.append(k)
    while len(is_) > 20: k = is_.pop(); kinds[k] = "K"; ks.append(k)
    cnt = {"K": 0, "I": 0}
    for x in pool:
        kd = kinds[x["key"]]; cnt[kd] += 1
        t, n = L.convert_prompt(x["prompt"], kd, rr.randrange(10 ** 9)); assert n == gs
        t = BI.interlock(t); assert t
        if kd == "K" and gs <= 2:
            t, c = F.apply(t); assert c == gs
        bodies = PH.findall(t); assert len(bodies) == gs, (x["key"], bodies)
        sts = " / ".join(s.replace("맥시 ", "") for s in x["meta"]["structures"])
        title = f"{'K-Silverfox' if kd == 'K' else 'Silverfox'} Structure Pack {TY[gs]} #{cnt[kd]:02d} ({'한국' if kd == 'K' else '국제'} · {sts} · 체형 {' / '.join(bodies)})"
        out.append({"key": f"{PFX[kd]}_{NM[gs]}_{cnt[kd]:02d}", "category": CAT[kd], "title": title, "prompt": t,
                    "meta": {"group_size": gs, "aspect_ratio": x["meta"]["aspect_ratio"], "format": "silverfox-structure-pack", "kind": kd,
                             "layout": x["meta"]["layout"], "structures": x["meta"]["structures"], "source": x["key"], "boundary": "interlock-v1"}})
json.dump(out, open(O + "la_silverfox_s2pack_120_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(out), collections.Counter((p["meta"]["kind"], p["meta"]["group_size"]) for p in out), len(set(p["key"] for p in out)))
