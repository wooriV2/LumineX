import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
OUT='/mnt/user-data/outputs/'
def run_until(fn,marker):
    src=open(fn).read(); src=src[:src.index(marker)]
    ns={}; exec(compile(src,fn,'exec'),ns); return ns
# namespaces
NSA=run_until('combo_A.py','CFG=['); NSB=run_until('combo_B.py','CFG=['); NSC=run_until('combo_C.py','CFG=[')
NS45=run_until('lips3.py','V=[(')
HL=run_until('heavy_ladder.py','PL=[')
AE=run_until('area_extreme.py','NA=[')
IRON=NSA['IRON']; SAFE=NSA['SAFE']; HEAD=NS45['HEAD']; HEAD_W=NS45['HEAD_W']; H45=NS45['H45']; sub=NS45['sub']; TAIL=NS45['TAIL']
def subjects(fn):
    t=open(OUT+fn,encoding='utf-8').read()
    return [[p for p in b.split("\n\n") if p.startswith("Subject:")][0] for b in re.findall(r"```\n(.*?)\n```",t,re.S)]
BARBIE=subjects('LumineX_BarbieWestern_3.md'); BR=subjects('LumineX_FaceTypes_Bratz_IG_Elf_3.md'); SF=subjects('LumineX_FaceTypes_Succubus_Femme_Siren_3.md')
ARCH=[("바비 인형(금발·파란 눈)",BARBIE[0]),("바비 인형(갈색 머리·보라빛 눈)",BARBIE[1]),("바비 인형(핑크 머리·민트 눈)",BARBIE[2]),("브랫츠 돌",BR[0]),("서큐버스",SF[0]),("인어 세이렌",SF[2])]
ETH=[("Korean","luminous fair skin","long glossy dark-brown hair"),("Japanese","fair skin with a pink blush","a soft dark-brown bob with blunt bangs"),("Chinese","porcelain skin","long straight glossy black hair"),("Western","very fair skin","long platinum-blonde waves"),("Mediterranean","warm golden-bronze skin","long dark chestnut waves"),("Middle Eastern","warm olive skin","long glossy black hair"),("Latin","warm honey-tan skin","long glossy dark waves")]
LENS=["glowing amber","ice-blue","vivid emerald-green","deep violet","dark brown with a warm glow"]
EYES=[("사이렌 눈","long, narrow, strongly upturned siren eyes with the outer corners lifted high toward the temples, a catlike inner point and a long sharp wing of liner, in luminous {lens} contact lenses with a big visible iris, both eyes the same, with a round natural pupil and bright catchlights"),
      ("도 아이","huge, perfectly round, wide, innocent doe eyes with a very large visible iris, a soft white inner liner and very long curled lashes, in {lens} contact lenses, both eyes the same, with a round natural pupil and bright catchlights"),
      ("애교살 초극대","large, soft, smiling eyes curving into gentle crescents with a defined double eyelid, and a hugely plump, pillowy fat roll under each eye, twice as thick as her upper eyelid, running along the whole lower lash line and bulging out like a small soft pillow, with a bright pearly champagne highlighter on top of it and a soft shadow line right beneath it, in soft brown doll-eye contact lenses with a big iris, both eyes the same, with a round natural pupil and bright catchlights"),
      ("옆트임 극대","extremely widened eyes: lateral canthoplasty has extended the outer corners of both eyes far outward almost to her temples and medial canthoplasty has opened the inner corners so the small pink inner corner of each eye is visible, so each eye opening is about one and a half times its natural length, very long, wide and almond-shaped, showing a very large amount of the iris, a razor-sharp black eyeliner following the extended shape and ending in a long point at the temple, in large dark-brown doll-eye contact lenses with a glossy shine, both eyes the same, with a round natural pupil and bright catchlights")]
LIPS=[("큐피드 보우","an extremely sharply defined cupid's bow, with two high, crisp peaks on the upper lip and a deep, clean central dip forming a perfect M-shaped upper lip line, moderately full lips with razor-clean edges, in satin deep berry-red"),
      ("립 플립","a 'lip flip': the upper lip gently rolled outward and upward, so a wide band of the soft pink inner part of the upper lip shows above the lip line and the upper lip looks fuller and flared without extra volume, in glossy nude-pink, balanced with a full lower lip"),
      ("립 리프트","a 'lip lift': a short, lifted space between the base of the nose and the upper lip, the upper lip curled up and outward in a high, gently smiling line with a sliver of her upper front teeth showing between softly parted lips, in glossy soft coral")]
JAWS=[("V라인","an extreme, razor-sharp V-line: the cheeks taper in a long, smooth, straight diagonal from the ears down to a small, narrow, pointed chin, a very slim lower face with a sharply defined sculpted jaw edge"),
      ("각진 턱","a strong, angular, square jawline: a wide, clearly defined, sharp-cornered jaw angle just below each ear, a broad flat chin with a slight cleft, hollow sculpted cheeks and very high, razor-sharp cheekbones"),
      ("하트형 턱","a heart-shaped face: a wide forehead and high, full cheekbones narrowing in a smooth curve into a delicate, pointed, softly rounded chin like the tip of a heart"),
      ("둥근 베이비 페이스","a soft, round 'baby face' jaw: full, plump, rounded cheeks, a short, soft, rounded jawline with no sharp angles and a small, round, slightly full chin")]
MATS=[("무쇠",IRON,"blackened cast iron"),("상아·뼈","creamy ivory-white carved bone with fine natural grain and a smooth polished surface","creamy ivory-white carved bone"),("금","polished solid yellow gold with a warm mirror finish and a slender sharp taper","polished solid yellow gold"),("흑요석","glossy black volcanic obsidian glass with razor-sharp tapering edges and bright specular reflections","glossy black obsidian glass"),("은","bright polished sterling silver with a mirror finish and a slender sharp taper","bright polished sterling silver")]
def composed(rr,angle):
    eth=rr.choice(ETH); eye=rr.choice(EYES); lip=rr.choice(LIPS); jaw=rr.choice(JAWS); lens=rr.choice(LENS)
    s=sub(f"A real photograph of a strikingly beautiful adult {eth[0]} woman, mid 20s, with {eth[1]} and {eth[2]}. Her eyes are the star of her face: {eye[1].format(lens=lens)}. Her lips: {lip[1]}. Her jawline and chin: {jaw[1]}. A refined nose, flawless glowing skin, a confident gaze straight into the camera.")
    return f"{eth[0]}·{eye[0]}·{lip[0]}·{jaw[0]}", s
def mod_tusk(rr,heavy_ears=True):
    pat=rr.choice("ABC"); NS={"A":NSA,"B":NSB,"C":NSC}[pat]
    third={"A":None,"B":NS['LIP'],"C":NS['CHIN']}[pat]
    mat=rr.choice(MATS)
    p=NS['mk'](8,third,"x",random.Random(rr.randrange(10**6)))
    if mat[0]!="무쇠":
        n=p.count(IRON); p=p.replace("a single thick, solid, sharp tusk of "+IRON,"a single thick, solid, sharp tusk of "+mat[1],1)
        p=p.replace("All jewelry is real blackened cast iron,","The tusk is real "+mat[2]+", while all the rings, chains and weights are blackened cast iron,")
    return f"엄니({mat[0]}) 패턴{pat}+귀 추 8개/귀",p,"chest"
def mod_nath(rr):
    return "콧볼 노즈링(금)+귀 사슬",AE['P'][2][2],"shoulder"
def mod_chin(rr):
    ear=NSC['eartxt'](8,random.Random(rr.randrange(10**6)))
    p=("Piercings: Exactly three piercings in total, and nowhere else: first, "+ear+" (two earlobe rings in total); second, "+NSC['CHIN']+". "+NSC['SK']+" Her eyebrows, lips, nose and the upper parts of her ears carry no piercing at all. All jewelry is real blackened cast iron,"+SAFE)
    return "턱 링 추 3개+귀 추 8개/귀",p,"chest"
def mod_ladder(rr):
    N=rr.choice([50,100,150,200]); nw=rr.choice([8,9,10]); v=rr.choice(["수수","화려","귀여움"])
    metal,gems=HL['TH'][v]; deco=rr.choice([HL['HENNA'],HL['STICK'],""])
    p,tot=HL['para'](N,nw,metal,gems,deco,random.Random(rr.randrange(10**6)))
    return f"전면 채우기 P{N}({v})+귀 추 {nw}개/귀",p,"shoulder"
MODS=[mod_tusk,mod_nath,mod_chin,mod_ladder]
FRM={"chest":"down to the middle of her chest, the frame cutting off there, so the weights and chains fully hang in view","shoulder":"down to her collarbones and the tops of her shoulders, the frame cutting off there, so everything fully hangs in view"}
def build(rr,kind):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(rr.randrange(10**6)),"한국","20대","도도한",style="NONE",slots=["pierce"],pier_level="P5"); break
        except AssertionError: continue
    ps=t.split("\n\n"); depth=[x for x in ps if x.startswith("Piercing depth:")][0]; light=[x for x in ps if x.startswith("Lighting:")][0]
    if kind=="arch":
        fname,sj=rr.choice(ARCH); name=fname; mod=rr.choice(MODS); lab,p,fr=mod(rr); head=HEAD; ang="정면"
        head=HEAD.replace("down to the base of her neck and the tops of her collarbones, the frame cutting off there",FRM[fr])
    elif kind=="front":
        name,sj=composed(rr,"front"); mod=rr.choice(MODS); lab,p,fr=mod(rr); ang="정면"
        head=HEAD.replace("down to the base of her neck and the tops of her collarbones, the frame cutting off there",FRM[fr])
    else:
        name,sj=composed(rr,"45"); fn=rr.choice(["gold","pearl","steel"]); lab={"gold":"골드+다이아 4","pearl":"진주+핑크 에나멜 4","steel":"블랙 스틸 4"}[fn]; p=NS45[fn](); head=H45; ang="45도"; fr=None
        light,n=re.subn(r"A soft frontal light on her face and ears","A soft key light from the front and slightly to the side on her face, shaping the cheek and jawline with a soft shadow below the jaw",light,count=1); assert n==1
    parts=[head,sj,p,depth]
    if fr: parts.append("Hair: her hair is swept back behind both ears, leaving both ears, her jawline and her neck fully visible so every hanging piece is in clear view.")
    parts.append(light)
    new="\n\n".join(parts); assert not re.search(r"[가-힣]",new)
    return f"{name} · {ang} · {lab}",new
rr=random.Random(20261012)
KINDS=["arch","arch","front","front","front45","front45"]
o=["# LumineX — 채택 항목 랜덤 조합 프롬프트 6개\n","- 1~2번: 채택 얼굴 유형(바비·브랫츠·서큐버스·세이렌) 중 랜덤 + 피어싱 모듈(엄니 3패턴/콧볼 노즈링/턱 링/전면 채우기) 랜덤, 정면.","- 3~4번: 인종·눈(사이렌·도·애교살·옆트임)·입술(큐피드·플립·리프트)·턱선(4종)을 랜덤 조합 + 피어싱 모듈 랜덤, 정면.","- 5~6번: 같은 랜덤 조합을 45도 구도로, 피어싱은 가벼운 4개(3/4 구도에서 피어싱이 사라지는 경향 대비).","- 정상/이상(+ 조합 특징이 보이는지)만 번호로 알려주세요.\n"]
for i,k in enumerate(KINDS,1):
    kk="45" if k=="front45" else k
    lab,txt=build(rr,"arch" if k=="arch" else ("front" if k=="front" else "45"))
    o.append(f"## {i}. {lab}\n\n```\n{txt}\n```\n"); print(i,lab)
open(OUT+'LumineX_RandomMix_6.md','w',encoding='utf-8').write("\n".join(o))
