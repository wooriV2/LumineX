import re,random,sys
sys.path.insert(0,'.')
src=open('mk_group5.py',encoding='utf-8').read()
exec(src[:src.index("R=_r.Random(20261013)")])
R=random.Random(7)
for n in (2,3):
    for ear in ("iron","mix","earring"):
        spec=draw_spec(R,n)
        for tr in range(50):
            try: t,labs,dup=group3(R.randrange(10**7),spec,"front",ear,2,"순흑 기본"); break
            except AssertionError: continue
        paras=t.split("\n\n")
        print(n,ear,len(t.split()),[ (p[:18],len(p.split())) for p in paras])
        if ear=="iron" and n==3: open('/tmp/_trio_iron.txt','w').write(t)
