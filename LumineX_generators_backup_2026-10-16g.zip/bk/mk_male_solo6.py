# -*- coding: utf-8 -*-
# 남성 바디페인팅 솔로 샘플 6개 (Core 바디페인팅 틀의 문단 구조, 남성 체형·문장)
import re, sys, random
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity"); sys.path.insert(0, "../../master")
_g = open("gen_pierce_statue.py", encoding="utf-8").read()
exec(_g[:_g.index("def build(")])
rnd.seed(20261016)
BODIES = {
 "V자 보디빌더": "An extraordinarily large and powerful man, far beyond any real person. A massive V-shaped torso: enormously broad shoulders with capped, rounded deltoids, a thick heavy chest, a deeply carved six-pack abdomen narrowing to a comparatively small waist, huge thick arms with split biceps and horseshoe triceps, wide flaring lats, and powerful thick quads and diamond calves. His head stays in correct proportion to his broad frame.",
 "린 애슬레틱": "A tall, lean, athletic man built like a swimmer. Broad shoulders tapering cleanly to a narrow waist, a defined chest, a visible eight-pack abdomen with sharp obliques, long strong arms with clear vein definition, and long lean muscular legs with defined calves. Nothing bulky, everything taut and sculpted.",
 "키 큰 슬렌더": "A very tall, slim, long-limbed man with a runway build. Straight shoulders, a flat lean chest, a flat defined stomach, slender strong arms and very long legs, lightly muscled and elegant, with visible collarbones and a narrow waist. His head stays in correct proportion to his long frame.",
 "파워리프터": "A thick, heavy, extremely strong man built like a powerlifter. A huge barrel chest, enormously wide shoulders and back, a thick solid waist with a firm rounded belly over strong abs, massive arms, and enormous thick thighs and calves. Every part is large, dense and continuous rather than sharply cut.",
 "대형 헤비": "A giant, big-bellied man with great natural size throughout. Broad powerful shoulders, a wide heavy chest, a large round soft belly hanging over a thick waist, thick strong arms, and wide heavy thighs beneath. Every curve is large, solid and continuous, with a warm, imposing bearing.",
 "클래식 머슬": "A classically muscular athletic man in the shape of a Greek statue. Wide shoulders, a full defined chest, a clean six-pack abdomen, strong rounded arms, and muscular thighs and calves, balanced and proportionate from head to toe, powerful but not exaggerated.",
 "스트롱맨": "A massive, stocky strongman. A thick short neck, huge round shoulders, an enormously deep chest, a thick powerful midsection with a solid belly, tree-trunk arms, and huge thick legs planted wide. Heavy, dense and immovable, every part solid.",
 "중년 실버 아스레틱": "A fit mature man in his late 40s with an athletic, well-kept build. Broad shoulders, a firm defined chest, a flat strong abdomen with visible lines, strong forearms, and lean strong legs, with the quiet, assured bearing of a man who has trained for decades.",
}
NATS = [("Indian", "warm golden-brown skin"), ("Korean", "smooth fair skin with a warm undertone"), ("Japanese", "smooth fair skin with a neutral undertone"), ("Nigerian", "deep blue-black skin"),
        ("Brazilian", "warm bronze skin"), ("Turkish", "olive skin"), ("Egyptian", "warm tan skin"), ("Russian", "pale fair skin"), ("Mexican", "warm medium-brown skin"),
        ("Iranian", "light olive skin"), ("Samoan", "deep golden-brown skin"), ("Italian", "olive-tan skin"), ("Ethiopian", "deep ebony-brown skin"), ("Filipino", "warm tan-brown skin")]
FACE = ["a strong jawline", "a sharp defined jawline and high cheekbones", "a square jaw", "a softly carved jaw and calm eyes"]
BEARD = ["clean-shaven", "light stubble", "a short neatly trimmed beard", "a short trimmed beard and moustache"]
MKU = [("", "메이크업 없음"), ("", "메이크업 없음"), ("dark smoky eyeliner", "스모키 아이라이너"), ("a metallic gold shimmer on the eyelids", "골드 쉬머 아이"), ("clear glossy brows and a faint bronzer glow", "글로우 브론저")]
MOOD = ["calm and confident", "intense and focused", "composed and regal", "relaxed with a faint half-smile", "fierce and commanding"]
HK = ["HSS스트레이트", "HSW웨이브", "HSC컬", "HSBN번", "HSAF아프로", "HSLC락스", "HSCR콘로우", "HSSK슬릭백", "HSSH샤기컷", "HSWF울프컷", "HSMH모호크", "HSPX픽시컷", "HSTN탑노트"]
AGES = ["in his late 20s", "in his early 30s", "in his late 30s", "in his mid 40s"]
NAILS = ["Short, clean nails with a matte black polish.", "Short natural nails.", "Short nails with a glossy dark-grey polish.", "Short nails with a metallic gold polish."]
POSES = ["standing in a wide confident stance, body angled three-quarters to the camera, one hand resting on his hip", "standing tall in profile, head turned toward the camera, arms relaxed at his sides",
         "walking toward the camera with a long stride, arms swinging naturally", "one arm raised and bent behind his head, body angled three-quarters to the camera",
         "standing with his weight on one leg, one hand running through his hair, body angled three-quarters to the camera", "in a deep lunge with his torso turned three-quarters to the camera, both hands on his front thigh",
         "standing three-quarter back to the camera, looking back over his shoulder", "both arms raised overhead, body angled three-quarters to the camera"]
SHOES = ["chunky black platform combat boots", "tall lace-up platform boots", "glossy patent platform loafers", "high-top platform sneakers", "knee-high platform boots", "thick-soled platform sandals"]
BG = ["plain seamless deep-charcoal", "plain seamless mid-grey", "plain seamless deep-navy", "plain seamless warm-sand", "plain seamless dark-olive"]
def craft(c):
    cn, cd, cb, cf = CRAFT_DB_FULL[c]; return f"{cn} ({cd}), rendered in {cb} with {cf} filling the space between, flowing over every muscle", cn
def build(i, bkey):
    nat, skin = rnd.choice(NATS); age = rnd.choice(AGES); mkt, mko = rnd.choice(MKU)
    hk = rnd.choice(HK); ci = rnd.randrange(1, len(HC) + 1)
    hair = ("silver hair styled in " if age.endswith("45s") or "mid 40s" in age else f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in ") + HAIR_EN_FULL[hk]
    c = rnd.choice(T.CRAFTS_39); ct, cn = craft(c); bg = rnd.choice(BG)
    face = f"{rnd.choice(FACE)}, {rnd.choice(BEARD)}" + (f", {mkt}" if mkt else "")
    p = (f"Image format: a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide.\n\n"
         f"A full-body photograph with a {bg} backdrop, shot on a medium format camera with an 85mm lens at f/8, a single hard key light raking in from one side, sharp focus from head to toe, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n"
         f"Subject: ONE real adult {nat} man {age}, his face exactly the same tone as his body, real skin texture with visible pores and fine grain, {face}, {skin}, {rnd.choice(MOOD)}, {hair}, real living eyes. {rnd.choice(NAILS)}\n\n"
         f"Physique: {BODIES[bkey]} His arms, hands, legs and feet stay in correct proportion to each other.\n\n"
         f"Skin: Real photographic skin — visible pores and fine grain, a taut surface with natural creases and shadow only where the muscle and flesh fold, fine hair on the forearms and legs. No smooth illustration finish, no plastic CG sheen.\n\n"
         f"Body Art: His bare skin is painted in {ct}. The paint is pigment sitting on living skin, so it distorts slightly over every muscle and bulge. The paint covers his whole body with no bare skin left anywhere below the jaw: shoulders, chest, upper arms, forearms, backs of his hands, sides, back, abdomen, lower abdomen, rear, thighs, knees, calves and the tops of his feet. His face is left unpainted and the pattern fades out at the neck with no hard line.\n\n"
         f"Pose: {rnd.choice(POSES)}.\n\n"
         f"Footwear: {rnd.choice(SHOES).capitalize()}, the platform soles rising far higher than his ankle bone, at least three times the thickness of an ordinary sole.\n\n"
         f"Background & Lighting: the painted pattern catching the light in sharp glints, the hard raking light carving every muscle and fold.\n\n"
         f"Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide. portrait 2:3 vertical.")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), re.findall(r"\b(\w+) \1\b", p)
    return p, f"{bkey} · {cn} · {mko}"
L = ["# LumineX — 남성 바디페인팅 솔로 샘플 6종\n", "의상 없이 몸 전체가 공예 패턴으로 덮인 성인 남성 솔로입니다. 번호별로 성공/실패만 알려주세요(실패는 한 줄 이유만).\n"]
for n, b in enumerate(rnd.sample(list(BODIES), 6), 1):
    p, d = build(n, b); L.append(f"## {n}. 남성 바디페인팅 · {d}\n\n```\n{p}\n```\n"); print(n, d, len(p.split()))
open("/mnt/user-data/outputs/LumineX_Male_BodyPaint_Solo6.md", "w", encoding="utf-8").write("\n".join(L))
