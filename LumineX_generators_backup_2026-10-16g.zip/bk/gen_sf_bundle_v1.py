# -*- coding: utf-8 -*-
# 맥시멀리스트 틀 + 패턴 풀 확장(이레즈미26·UV27·바디페인팅 공예41·스테인드글라스·금박·식물·해태) + 신발24·헤어16·손톱 확장.
import json, re, random, difflib, sys
sys.path.insert(0, "/home/claude/glassface"); sys.path.insert(0, "/home/claude/diversity")
from sfv2_lib import HAIRS6, SF_AGES, HAEJAE, two_colors, SHOES, NAILS, IREZUMI_FULL, UV_FULL
from full_dicts import CRAFT_DB_FULL, SHOE_EN_FULL, NAIL_SHAPE_EN_FULL, NAIL_FIN_EN_FULL
D = json.load(open("/mnt/user-data/outputs/la_maximalist_bundle.json", encoding="utf-8"))
BLACK = "THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky"
KFACE = "Korean silver fox goddess luminous warm golden-olive complexion elegant silver-era maturity"
NUM = {2: "TWO", 3: "THREE", 4: "FOUR", 5: "FIVE", 6: "SIX", 7: "SEVEN", 8: "EIGHT", 9: "NINE", 10: "TEN"}
CAT = {"ire": "Irezumi", "uv": "UV Neon", "glass": "Stained Glass", "gold": "Gold Leaf", "bot": "Botanical"}
HAIR16 = ["silver-white sleek straight hair falling past her shoulders", "silver-white loose waves cascading to her waist", "silver-white voluminous curls framing her face",
          "silver-white hair in a sleek high ponytail", "silver-white hair in an elegant updo", "silver-white half-up hair, top section lifted with the length flowing loose below",
          "silver-white hair in a low bun", "silver-white chin-length bob", "silver-white layered tousled shag cut", "silver-white layered wolf cut with curtain bangs",
          "silver-white flat glossy finger waves styled close to the scalp", "silver-white intricate fishtail braid", "silver-white crown braid wrapping around the head",
          "silver-white low chignon knot at the nape", "silver-white vintage victory rolls framing the face", "silver-white sleek wet-look hair slicked straight back"]
HDR = re.compile(r"^#(\d+): " + re.escape(BLACK) + r", ((?:early|mid|late) \d0s) goddess, (.+? physique) THE MOST EXTREME")
PLAIN = "platform boots 8 inch, extra long stiletto nails to match."
UVSH = "platform boots 8 inch, extra long stiletto nails BLAZING NEON UV reactive tips."
def pool(sec, n): return [p for p in D if CAT[sec] in p["category"] and f"{NUM[n]} women standing" in p["prompt"]]
def persons_of(p): return [b for b in p.split("\n\n")[1:] if re.match(r"#\d+: ", b)]
def phys_of(b): return HDR.match(b.split("\n", 1)[0]).group(3)
def pat_of(b): return re.search(r"full body (.+?) covering", b).group(1)
def ink_of(b):
    m = re.search(r"(?:Bold black ink outlines|Bold formations|Thin irregular metallic sheets) — (.*?), NO airbrush", b, re.S)
    return m.group(1) if m else b
def craft_person(base, rnd, seen):
    while True:
        k = rnd.choice(list(CRAFT_DB_FULL) + ["__H__"])
        if k == "__H__":
            if HAEJAE[0] in seen: continue
            return haetae_person(base), HAEJAE[0], None
        nm, desc, pal, scroll = CRAFT_DB_FULL[k]
        if nm not in seen: break
    a, b = (pal.split("-and-") + ["gold"])[:2] if "-and-" in pal else (pal.split("-")[0], "gold")
    a, b = a.split("-")[-1], b.split("-")[-1]
    if a == b: b = "crimson" if a != "crimson" else "gold"
    A, B = a.upper(), b.upper()
    ink = f"{desc}, BLAZING {A} and VIVID {B} bands following every deep curve of her body, dense {scroll} filling every gap"
    base = re.sub(r"full body .+? irezumi covering", f"full body {nm} bodypaint covering", base, count=1)
    base = re.sub(r"(Bold black ink outlines — ).*?(, NO airbrush)", lambda m: "Bold formations — " + ink + m.group(2), base, count=1, flags=re.S)
    return base, nm, (a, b)
def haetae_person(base):
    base = re.sub(r"full body .+? irezumi covering", f"full body {HAEJAE[0]} covering", base, count=1)
    return re.sub(r"(Bold black ink outlines — ).*?(, NO airbrush)", lambda m: m.group(1) + HAEJAE[1] + m.group(2), base, count=1, flags=re.S)
def pick_persons(secs, kind, rnd, n_src):
    seen = set(); out = []; pc = {}; maxrep = 2 if len(secs) >= 9 else 1
    for s in secs:
        for _ in range(500):
            if s in ("bp", "haetae"):
                src = rnd.choice(pool("ire", n_src)); b = rnd.choice(persons_of(src["prompt"]))
                if pc.get(phys_of(b), 0) >= maxrep: continue
                if s == "bp": b, nm, cols = craft_person(b, rnd, seen); seen.add(nm)
                else: b = haetae_person(b); nm, cols = HAEJAE[0], None
            elif s in ("ire", "uv"):
                src = rnd.choice(pool(s, n_src)); b = rnd.choice(persons_of(src["prompt"]))
                if pc.get(phys_of(b), 0) >= maxrep: continue
                nm, ink = rnd.choice(IREZUMI_FULL if s == "ire" else UV_FULL)
                if s == "ire":
                    b = re.sub(r"full body .+? irezumi covering", f"full body {nm} irezumi covering", b, count=1)
                    b = re.sub(r"(Bold black ink outlines — ).*?(, NO airbrush)", lambda m: m.group(1) + ink + m.group(2), b, count=1, flags=re.S)
                else:
                    u = ink if re.match(r"(BLAZING|VIVID|STARK)", ink) else "BLAZING " + ink
                    b = re.sub(r"full body UV neon .+? bodypaint covering", f"full body UV neon {nm} bodypaint covering", b, count=1)
                    b = re.sub(r"(Bold formations — ).*?(, NO airbrush)", lambda m: m.group(1) + u + m.group(2), b, count=1, flags=re.S)
                if pat_of(b) in seen: continue
                cols = None
            else:
                src = rnd.choice(pool(s, n_src)); b = rnd.choice(persons_of(src["prompt"]))
                if pc.get(phys_of(b), 0) >= maxrep or pat_of(b) in seen: continue
                cols = None
            pc[phys_of(b)] = pc.get(phys_of(b), 0) + 1; seen.add(pat_of(b)); out.append((s, b, cols)); break
        else: raise RuntimeError(s)
    return out
KYOUNG = "Korean idol goddess luminous warm golden-olive complexion youthful fresh glow"
def conv(block, num, age, hair, kind, young=False):
    first, rest = (block.split("\n", 1) + [""])[:2]
    m = HDR.match(first); assert m, first[:120]
    if young: head = (f"#{num}: {BLACK}, {age} goddess, {m.group(3)} THE MOST EXTREME" if kind == "I" else f"#{num}: {KYOUNG}, {age}, {m.group(3)} THE MOST EXTREME")
    else: head = (f"#{num}: {BLACK}, {age} silver fox goddess, {m.group(3)} THE MOST EXTREME" if kind == "I" else f"#{num}: {KFACE}, {age}, {m.group(3)} THE MOST EXTREME")
    first = head + first[m.end():]
    i = first.index(" — full body"); j = first.rfind(", ", 0, i); oh = first[j + 2:i]
    assert re.search(r"hair|braid|loc|afro|bob|crop|ponytail|bun|wave|curl|crown|updo|cut|tresses", oh, re.I), oh
    first = first[:j + 2] + hair + first[i:]
    rest = re.sub(r"^#\d+: ", f"#{num}: ", rest, flags=re.M)
    return first, rest
from full_dicts import HAIR_COLOR_EN_FULL
HC = [v for v in HAIR_COLOR_EN_FULL.values() if not re.search(r"silver|ash-grey|icy|platinum|balayage|ombre", v)]
def render(n, plist, ages, kind, ext, seed, who=None):
    r2 = random.Random(seed); hairs = r2.sample(HAIR16 if ext else HAIRS6, n)
    who = who or ["S"] * n
    hairs = [h if w == "S" else h.replace("silver-white", r2.choice(HC)) for h, w in zip(hairs, who)]; shoes = r2.sample(list(SHOE_EN_FULL.values()), n)
    out = []; lab = []
    for k, ((s, b, cols), age, hair, shoe) in enumerate(zip(plist, ages, hairs, shoes), 1):
        first, rest = conv(b, k, age, hair, kind, young=(who[k - 1] == "Y"))
        if ext:
            shape = r2.choice(list(NAIL_SHAPE_EN_FULL.values() if False else ["stiletto", "coffin", "almond"])); fin = r2.choice(list(NAIL_FIN_EN_FULL.values()))
            if rest == f"#{k}: {PLAIN}":
                c = list(cols) if cols else two_colors(ink_of(b))
                rest = f"#{k}: {c[0]} {c[1]} {shoe}, extra long {shape} {fin} nails {c[0]} {c[1]} tips."
            elif rest == f"#{k}: {UVSH}": rest = f"#{k}: {shoe}, extra long {shape} {fin} nails BLAZING NEON UV reactive tips."
        out.append(first + ("\n" + rest if rest else ""))
        lab.append(f"{phys_of(b).replace(' physique','')}·{age}·{pat_of(first.replace(chr(10),' ') if False else first)}·{hair.replace('silver-white ','').replace('silver-streaked ','')}")
    return out, lab
IRE = {p["meta"]["group_size"]: p for p in D if "Irezumi" in p["category"] and p["meta"]["group_size"] in range(1, 11) and p["key"].endswith("_01")}
FR = {}
for p in D:
    if p["key"].endswith("_01"): FR.setdefault(next(k for k, v in CAT.items() if v in p["category"]), {})[p["meta"]["group_size"]] = p
def frame(n, out, fc="ire"):
    src = FR[fc][n]["prompt"]; blocks = src.split("\n\n")
    if n == 1:
        body = re.sub(r"^#\d+: ", "", out[0], flags=re.M)
        return "Professional fashion photograph, full body shot. ONE woman standing.\n\n" + body + "\n\n" + blocks[-1]
    tail = "\n\n".join(b for b in blocks[1:] if not re.match(r"#\d+: ", b))
    return blocks[0] + "\n\n" + "\n\n".join(out) + "\n\n" + tail
def check(name, t):
    assert not re.search(r"[가-힣]", t); d = [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", t)]; assert not d, (name, d)
def make(name, kind, secs, seed, ext=True, ages=None, plist=None, who=None, fc="ire"):
    n = len(secs); rnd = random.Random(seed)
    if plist is None: plist = pick_persons(secs, kind, rnd, n if n >= 6 else (4 if n <= 4 else 5))
    if ages is None:
        ages = rnd.sample(SF_AGES * 3, n); ys = rnd.sample(["early 20s", "mid 20s", "late 20s"], 3)
        ages = [ys.pop() if w == "Y" else a for a, w in zip(ages, who or ["S"] * n)]
    out, lab = render(n, plist, ages, kind, ext, seed, who); t = frame(n, out, fc).replace("VIVID VIVID", "VIVID"); check(name, t)
    if kind == "K": assert "DARKEST BLACK" not in t
    return t, lab, plist, ages
# ================= 번들 생성 =================
import json, collections
KO = {"ire": "이레즈미", "bp": "바디페인팅", "uv": "UV네온", "glass": "스테인드글라스", "bot": "식물", "haetae": "해태", "gold": "금박"}
SIZES = [("solo", 1, 60), ("duo", 2, 50), ("trio", 3, 50), ("quartet", 4, 40), ("quintet", 5, 30), ("sextet", 6, 20), ("septet", 7, 15), ("octet", 8, 15), ("nonet", 9, 10), ("decet", 10, 10)]
CATNAME = {"K": "🏺 Living Artifact · K-Silverfox Formula", "I": "🏺 Living Artifact · Silverfox Formula"}
PREFIX = {"K": "la_ksilverfox_", "I": "la_silverfox_"}
def mixed_secs(n, kind, rr):
    rare = ["uv", "glass", "bot"] + (["gold"] if kind == "I" else [])
    rr.shuffle(rare); p = 0.55 if n >= 3 else 0.4
    secs = [r for r in rare if rr.random() < p][:n]
    base = ["ire", "bp"]
    while len(secs) < n: secs.append(rr.choice(base))
    if len(set(secs)) < 2: secs[0] = rr.choice(rare)
    if len(set(secs)) < 2: secs[0] = "ire"; secs[1] = "bp"
    rr.shuffle(secs); return secs
def build_one(kind, n, mode, nY, seed):
    rr = random.Random(seed * 7 + 1)
    if n == 1: secs = [rr.choice(["ire", "bp", "uv", "glass", "bot"] + (["gold"] if kind == "I" else []))]; fc = "uv" if secs[0] == "uv" else "ire"
    elif mode in ("ire", "bp", "uv"): secs = [mode] * n; fc = "uv" if mode == "uv" else "ire"
    else: secs = mixed_secs(n, kind, rr); fc = "ire"
    ys = set(rr.sample(range(n), nY)) if nY else set(); who = ["Y" if i in ys else "S" for i in range(n)]
    t, lab, pl, ag = make("x", kind, secs, seed, True, None, None, who, fc)
    return t, lab, secs, who, fc
def title(kind, key_size, idx, n, secs, who, lab, mode):
    sizeko = {1: "Solo", 2: "Duo", 3: "Trio", 4: "Quartet", 5: "Quintet", 6: "Sextet", 7: "Septet", 8: "Octet", 9: "Nonet", 10: "Decet"}[n]
    nY = who.count("Y"); comp = "실버폭스만" if nY == 0 else f"실버폭스 {n - nY} + 20대 {nY}"
    if n == 1: sec = KO[secs[0]]
    elif mode in ("ire", "bp", "uv"): sec = KO[mode] + " 전원"
    else: sec = "혼합(" + "·".join(KO[x] for x in dict.fromkeys(secs)) + ")"
    phys = [re.match(r"(.+?)·", re.sub(r"^\[20대\] ", "", l)).group(1) for l in lab]
    ph = "/".join(phys[:3]) + (f" 외 {n - 3}명" if n > 3 else "")
    return f"{'K-Silverfox' if kind == 'K' else 'Silverfox'} {sizeko} #{idx:02d} ({'한국' if kind == 'K' else '국제'} · {comp} · {sec} · 체형 {ph})"
OUT = []; seen_prompts = set(); stats = collections.Counter()
seedbase = 700000
for kind in ("K", "I"):
    for tname, n, N in SIZES:
        rr = random.Random(hash((kind, n)) & 0xffff or 1)
        rr = random.Random(f"{kind}{n}")
        idxs = list(range(N)); rr.shuffle(idxs)
        nsingle = 0 if n == 1 else round(N * 0.3); ncon = 0 if n == 1 else round(N * 0.3)
        single = set(idxs[:nsingle]); rr.shuffle(idxs); contrast = set(idxs[:ncon])
        singles_modes = ["ire", "bp", "uv"]; sm = 0
        for i in range(N):
            mode = "mixed"
            if i in single: mode = singles_modes[sm % 3]; sm += 1
            nY = 0
            if i in contrast: nY = 1 if n <= 5 else rr.choice([1, 2, 2])
            for attempt in range(30):
                seed = seedbase + attempt * 100000 + (1 if kind == "K" else 2) * 10000 + n * 100 + i
                try:
                    t, lab, secs, who, fc = build_one(kind, n, mode, nY, seed)
                except Exception as e:
                    import traceback; lasterr = traceback.format_exc(); continue
                if t in seen_prompts: continue
                break
            else: raise RuntimeError((kind, n, i, mode, nY, lasterr[-600:]))
            seen_prompts.add(t)
            key = f"{PREFIX[kind]}{tname}_{i + 1:02d}"
            meta = {"group_size": n, "aspect_ratio": FR[fc][n]["meta"]["aspect_ratio"], "format": "silverfox", "kind": kind, "sections": list(dict.fromkeys(secs)), "contrast_20s": nY, "single_section": mode in ("ire", "bp", "uv") or n == 1}
            OUT.append({"key": key, "category": CATNAME[kind], "title": title(kind, tname, i + 1, n, secs, who, lab, mode), "prompt": t, "meta": meta})
            stats[(kind, tname, "single" if meta["single_section"] else "mixed", nY > 0)] += 1
json.dump(OUT, open("/mnt/user-data/outputs/la_silverfox_600_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(OUT)); print(collections.Counter(p["category"] for p in OUT))
