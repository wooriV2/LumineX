# -*- coding: utf-8 -*-
# 신규 번들 3종(솔로 60씩): Nebula / Lava / Brick — Material Mix 틀(전 축 기본 랜덤), 재질 문장만 교체
_a = open("mk_new4.py", encoding="utf-8").read()
exec(_a[:_a.index("def chk(t)")])          # mk_new_bundles 헤더 + T_NEB/T_LAVA/V()
_b = open("mk_block.py", encoding="utf-8").read()
exec(_b[_b.index("BT = ("):_b.index("BLOCKS = [")])   # BT (블록 템플릿)
def chk(t): return not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t) and "navel" not in t.lower()
def NB(tag, kind, desc, solid, nmw, base, acc):  # 성운·은하
    d = V(tag, desc, solid, nmw, T_NEB, base, acc, "softly glowing"); d["kind"] = kind; return d
def LV(tag, kind, desc, solid, nmw, base, acc, fin):
    d = V(tag, desc, solid, nmw, T_LAVA, base, acc, fin); d["kind"] = kind; return d
def BK(tag, kind, desc, base, acc):
    d = V(tag, desc, "toy-brick", "plastic toy bricks", BT, base, acc, "glossy hard plastic"); d["kind"] = kind; return d
FULL = "across the full torso both legs neck to ankle"
NEBULA = {
 "nebula": [
  NB("보라 성운", "nebula", "glowing violet nebula starfield", "starfield", "glowing nebula starfield", f"BLAZING deep indigo-violet and magenta nebula clouds {FULL}", "VIVID tiny white and gold stars and thin gold constellation lines linking the brightest stars"),
  NB("진홍 성운", "nebula", "glowing crimson nebula starfield", "starfield", "glowing nebula starfield", f"BLAZING deep crimson-red and fiery orange nebula clouds {FULL}", "VIVID tiny white and gold stars and thin white constellation lines linking the brightest stars"),
  NB("에메랄드 성운", "nebula", "glowing emerald nebula starfield", "starfield", "glowing nebula starfield", f"BLAZING deep emerald-green and sapphire-blue nebula clouds {FULL}", "VIVID tiny white and pale-gold stars and thin pale-gold constellation lines linking the brightest stars"),
 ],
 "galaxy": [
  NB("청록 은하", "galaxy", "glowing cyan galaxy starfield", "starfield", "glowing galaxy starfield", f"BLAZING electric cyan-blue and deep teal galaxy clouds with a bright rose-pink spiral core {FULL}", "VIVID tiny white stars and thin silver-white constellation lines linking the brightest stars"),
  NB("황금 은하", "galaxy", "glowing golden galaxy starfield", "starfield", "glowing galaxy starfield", f"BLAZING warm amber-gold and deep bronze galaxy clouds with a bright white-gold spiral core {FULL}", "VIVID tiny white stars and thin white constellation lines linking the brightest stars"),
  NB("남보라 은하", "galaxy", "glowing royal-blue galaxy starfield", "starfield", "glowing galaxy starfield", f"BLAZING deep royal-blue and violet galaxy clouds with a bright pale-blue spiral core {FULL}", "VIVID tiny white stars and thin silver-white constellation lines linking the brightest stars"),
 ],
}
LAVA = {
 "basalt": [
  LV("현무암 주황 용암", "basalt", "cracked black basalt and molten lava", "volcanic rock", "black basalt and molten lava", f"BLAZING matte black basalt crust plates {FULL}", "VIVID bright orange-red molten lava glowing in every crack, with a few white-hot yellow veins", "rough volcanic"),
  LV("현무암 진홍 용암", "basalt", "cracked black basalt and crimson molten lava", "volcanic rock", "black basalt and molten lava", f"BLAZING matte black basalt crust plates {FULL}", "VIVID deep crimson-red molten lava glowing in every crack, with white-hot orange veins", "rough volcanic"),
  LV("현무암 노랑 용암", "basalt", "cracked black basalt and bright molten lava", "volcanic rock", "black basalt and molten lava", f"BLAZING matte black basalt crust plates {FULL}", "VIVID bright yellow-orange molten lava glowing in every crack, with white-hot veins", "rough volcanic"),
 ],
 "obsidian": [
  LV("흑요석 황금 용암", "obsidian", "cracked glossy obsidian and golden molten lava", "volcanic glass", "obsidian and molten lava", f"BLAZING glossy black obsidian crust plates {FULL}", "VIVID golden-yellow molten lava glowing in every crack, with white-hot veins and drifting orange embers", "glassy volcanic"),
  LV("흑요석 주황백 용암", "obsidian", "cracked glossy obsidian and white-hot molten lava", "volcanic glass", "obsidian and molten lava", f"BLAZING glossy black obsidian crust plates {FULL}", "VIVID orange and white-hot molten lava glowing in every crack, with drifting orange embers", "glassy volcanic"),
  LV("흑요석 루비 용암", "obsidian", "cracked glossy obsidian and ruby-red molten lava", "volcanic glass", "obsidian and molten lava", f"BLAZING glossy black obsidian crust plates {FULL}", "VIVID deep ruby-red molten lava glowing in every crack, with orange glints and drifting embers", "glassy volcanic"),
 ],
}
BRICK = {
 "multi": [
  BK("원색 블록", "multi", "classic multicolour interlocking plastic toy-brick sculpture", f"BLAZING bold blocks of vivid red, sunny yellow, bright blue and white bricks {FULL}", "VIVID a few bright green and orange bricks mixed among them, and glossy highlights catching on every round stud"),
  BK("파스텔 블록", "multi", "pastel multicolour interlocking plastic toy-brick sculpture", f"BLAZING soft blocks of pastel pink, mint-green, lemon-yellow, lavender and sky-blue bricks {FULL}", "VIVID a few pure white bricks mixed among them, and glossy highlights catching on every round stud"),
  BK("네온 블록", "multi", "neon multicolour interlocking plastic toy-brick sculpture", f"BLAZING bold blocks of neon pink, lime-green, bright orange and electric cyan bricks {FULL}", "VIVID a few pure white bricks mixed among them, and glossy highlights catching on every round stud"),
 ],
 "mono": [
  BK("터키석 단색 블록", "mono", "single-colour interlocking plastic toy-brick sculpture", f"BLAZING glossy turquoise-blue bricks {FULL}", "VIVID a scattering of pure white bricks forming bold stripes along her sides, and glossy highlights catching on every round stud"),
  BK("빨강 단색 블록", "mono", "single-colour interlocking plastic toy-brick sculpture", f"BLAZING glossy cherry-red bricks {FULL}", "VIVID a scattering of pure white bricks forming bold stripes along her sides, and glossy highlights catching on every round stud"),
  BK("검정 단색 블록", "mono", "single-colour interlocking plastic toy-brick sculpture", f"BLAZING glossy jet-black bricks {FULL}", "VIVID a scattering of bright gold bricks forming bold stripes along her sides, and glossy highlights catching on every round stud"),
  BK("핫핑크 단색 블록", "mono", "single-colour interlocking plastic toy-brick sculpture", f"BLAZING glossy hot-pink bricks {FULL}", "VIVID a scattering of pure white bricks forming bold stripes along her sides, and glossy highlights catching on every round stud"),
 ],
}
FAM = {"nebula": (NEBULA, "la_nebula_", "🏺 Living Artifact · Nebula Formula", "Nebula", 20261121, "nebula", "part of the starfield figure"),
       "lava": (LAVA, "la_lava_", "🏺 Living Artifact · Lava Formula", "Lava", 20261122, "lava", "part of the volcanic figure"),
       "brick": (BRICK, "la_brick_", "🏺 Living Artifact · Brick Formula", "Brick", 20261123, "brick", "part of the brick figure")}
def build_family(name):
    TAB, pref, CAT, TITLE, seed, fmt, part = FAM[name]
    rg = random.Random(seed); rr.seed(seed); ns2["JR"].seed(seed)
    kinds = list(TAB); out = []; seen = set(); rounds = 60 // len(kinds)
    for j in range(rounds):
        for k in kinds:
            vs = TAB[k]; v = vs[j % len(vs)]
            for attempt in range(500):
                phys = rg.choices(BIG5, W5)[0]; age = rg.choice(AGES); pose = rg.choice(POSES); eth = rg.sample(ETH, 1)[0]
                bid, wx = BGL.pick(rg, 1); scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
                HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
                ns2["JR"].seed(rg.randrange(10**9))
                mat = HEAD.format(desc=v["desc"], solid=v["solid"]) + v["T"].format(base=v["base"], acc=v["acc"], fin=v["fin"])
                body, info = assemble(mat, v["nmw"], part, phys, age, pose, eth)
                env = f"{scene}, bright and evenly lit, shadows soft, the whole floor and surroundings clearly visible and in focus, NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as her."
                tail = f"Background: {env} ONE woman only. Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
                t = f"Professional fashion photograph, full body shot. ONE woman standing.\n\n{body}\n\n{tail}{CAM} 8K portrait {ASP[1]} aspect ratio."
                if not chk(t) or t in seen: continue
                break
            else: raise SystemExit("fail")
            seen.add(t); n = len(out) + 1
            hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
            assert t.count("forty inches") == (1 if HEELMODE[0] == "forty" else 0)
            out.append({"key": f"{pref}{n:03d}", "category": CAT,
                        "title": f"{TITLE} Solo #{n:03d} ({v['tag']} · 체형 {phys[0]} · 인종 {eth[0]} · {info} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko} · 몸 주얼리)",
                        "prompt": t, "meta": {"group_size": 1, "aspect_ratio": ASP[1], "format": fmt, "kind": v["kind"], "variant": v["tag"], "physiques": [phys[0]], "ethnicity": [eth[0]],
                                              "background": bid, "weather": wx[0] if wx else None, "heel_mode": HEELMODE[0], "jewelry": True}})
    assert len(out) == 60 and len({p["key"] for p in out}) == 60
    return out
if __name__ == "__main__":
    for name in FAM:
        out = build_family(name)
        json.dump(out, open(O + f"la_{name}_60_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        wc = [len(p["prompt"].split()) for p in out]
        print(name, len(out), min(wc), max(wc), sum(wc)//len(wc), collections.Counter(p["meta"]["kind"] for p in out).most_common(), collections.Counter(p["meta"]["variant"] for p in out).most_common(), len({p["meta"]["background"] for p in out}), "배경", collections.Counter(p["meta"]["heel_mode"] for p in out), len({p["meta"]["ethnicity"][0] for p in out}), "인종", len({p["meta"]["physiques"][0] for p in out}), "체형")
