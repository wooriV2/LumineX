# -*- coding: utf-8 -*-
"""사용 이력 추적 + 최소사용 우선 랜덤 선택 유틸리티.
앞으로 메이크업/손톱/신발/헤어를 고를 때 이 함수를 거쳐서,
내가 "무난한 것"으로 계속 손이 가는 습관을 구조적으로 막는다."""
import random, json, os

TRACK_FILE = "/home/claude/diversity/usage.json"

MAKEUP_48 = [
 "코갸루","히메갸루","아게하","오네에갸루","아마갸루","야마바","만바","반바","비주얼계","지뢰계","야미카와","데코라",
 "강남언니","글래머러스파티","걸크러시","뱀파이어다크","한복화보",
 "구풍","웨이쉰","홍콩풍",
 "락혼글램","파케앙트글램","텔레노벨라글램","프렌치레드립","슬라브글램","인스타글램","서아프리카글램","하베샤화장","요루바신부화장","소피아로렌풍","화환화장","스칸디프로스트","발칸글램","노르딕발키리",
 "페르시안글램","레바논웨딩글램","걸프아바야글램","파키스탄브라이덜글램","우즈벡실크로드글램","자메이카댄스홀글램","하와이안훌라","스페인플라멩코글램",
 "BollywoodGlam","CarnivalGlam","AoDaiGlam","TurkishGlam","GermanGlam","EgyptianGlam",
]
NAIL_SHAPES = ["NA아몬드","NS스퀘어","NC코핀","NT스틸레토","NO오벌","NR라운드"]
NAIL_FINISH = ["FG글로시","FM매트","FC크롬","FT글리터","FH홀로그래픽"]
SHOES_24 = [
 "플랫폼스틸레토힐","익스트림플랫폼하이힐","플랫폼스틸레토펌프스","플랫폼스틸레토앵클부츠","플랫폼하이힐뮬","익스트림플랫폼웨지",
 "플랫폼스틸레토메리제인","익스트림플랫폼싸이하이부츠","플랫폼스틸레토슬링백","익스트림플랫폼레이스업샌들",
 "플랫폼스틸레토니하이부츠","플랫폼스틸레토크로스스트랩샌들","익스트림플랫폼스퀘어토힐","플랫폼스틸레토페탈토힐",
 "익스트림플랫폼버클부츠","플랫폼스틸레토코르셋레이스부츠","익스트림플랫폼클리어힐","플랫폼스틸레토스터드부츠",
 "순수스틸레토펌프스","발레힐","니들힐","싸이하이스틸레토부츠","스컬프처럴힐","앵클스트랩스틸레토",
]
HAIR_STYLE = ["HSS스트레이트","HSW웨이브","HSC컬","HSPT포니테일","HSU업두","HSB브레이드","HSBN번","HSTT트윈테일",
 "HSAF아프로","HSLC락스","HSCR콘로우","HSHU하프업","HSPX픽시컷","HSBC보브컷","HSCH쉬농","HSFB피쉬테일브레이드","HSTN탑노트","HSSK슬릭백",
 "HSSB스페이스번","HSBK반투노트","HSFW핑거웨이브","HSCP크림프","HSBX박스브레이드","HSFR프렌치브레이드","HSMB마이크로브레이드","HSSH샤기컷","HSWF울프컷","HSMH모호크","HSVR빅토리롤","HSCB크라운브레이드","HSHP하이퍼프"]

HAIR_COLOR = ["HCJB제트블랙","HCNB내추럴블랙","HCDB다크브라운","HCCB체스트넛브라운","HCAB애쉬브라운","HCCH초콜릿브라운","HCMH마호가니","HCCP코퍼",
 "HCAU오번","HCSB스트로베리블론드","HCHB허니블론드","HCGB골든블론드","HCPB플래티넘블론드","HCCM샴페인블론드","HCSG실버그레이","HCAG애쉬그레이",
 "HCBG버건디","HCRG로즈골드","HCBL발레아쥬","HCOM옴브레","HCPP파스텔핑크","HCPL파스텔라벤더","HCPM파스텔민트","HCPC파스텔피치",
 "HCVB비비드블루","HCVV비비드바이올렛","HCVM비비드마젠타","HCVG비비드그린","HCVO비비드오렌지","HCIW아이시화이트"]

def _load():
    if os.path.exists(TRACK_FILE):
        with open(TRACK_FILE) as f:
            return json.load(f)
    return {}

def _save(d):
    with open(TRACK_FILE,"w") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)

def pick_least_used(pool, category, n=1, seed=None):
    """category별 사용횟수가 가장 적은 것들 중에서 랜덤으로 n개 뽑고, 사용횟수를 갱신한다."""
    if seed is not None:
        random.seed(seed)
    usage = _load()
    cat_usage = usage.setdefault(category, {item: 0 for item in pool})
    for item in pool:
        cat_usage.setdefault(item, 0)
    min_count = min(cat_usage[item] for item in pool)
    least_used = [item for item in pool if cat_usage[item] == min_count]
    random.shuffle(least_used)
    picked = (least_used + [i for i in pool if i not in least_used])[:n]
    for item in picked:
        cat_usage[item] += 1
    _save(usage)
    return picked

if __name__ == "__main__":
    print("메이크업 5개(최소사용우선):", pick_least_used(MAKEUP_48, "makeup", 5))
    print("손톱모양 2개:", pick_least_used(NAIL_SHAPES, "nail_shape", 2))
    print("손톱마감 2개:", pick_least_used(NAIL_FINISH, "nail_finish", 2))
    print("신발 3개:", pick_least_used(SHOES_24, "shoes", 3))
    print("헤어스타일 2개:", pick_least_used(HAIR_STYLE, "hair_style", 2))

BODY_14 = ["글래머아워글래스","머슬아워글래스BBW","헤비머슬","USSBBW","아워글래스SSBBW","파워리프터","아마조네스",
 "슈퍼글래머","블랙글래머","레전드바스트","커브드바스트","브라질부티글램","폴리네시안여신","누비안부티빌더"]

# ===== 전체 축 확장 =====
POSE_19 = ["정면와이드스탠스","한쪽무릎꿇기","3/4각도","옆모습","뒷모습3/4","걷는동작","벽에기대기","의자앉기",
 "바닥옆으로기대기","양팔위로","허리손","머리넘기기","런지자세","완전뒷모습","창가기대기","계단에앉기","얼굴감싸기","점프동작","양무릎꿇고정면"]

PIERCE_P = ["P8","P15","P25","P50","P100","P150","P200"]
PIERCE_C = ["C0","C1","C2"]
PIERCE_G = ["GD","GP","GO","GA","GR","GS","GX"]
PIERCE_F = ["FH","FS","FB","FC","FD","FG","FX"]
PIERCE_S = ["S0","S1"]
PIERCE_M = ["MG","MR","MS","MC","MBR","MBZ","MX"]

CRAFTS_39 = [
 "VietnameseSonMai","TurkishIznik","IndianMughal","KoreanNajeon","ChineseCizhou","MexicanTalavera","KoreanEunipsa",
 "RussianPalekh","JapaneseKutani","ThaiBenjarong","FilipinoYakan","PeruvianNazca","FrenchLimoges","UkrainianPetrykivka",
 "AmericanArtDeco","NigerianAdire","EthiopianCrossLattice","YorubaAdireEleko","ItalianDeruta","UkrainianPysanka",
 "SwedishKurbits","RomanianHorezu","NorwegianRosemaling","EgyptianMamluk","MoroccanZellige","SpanishTalaveraReina",
 "GeorgianMinonkari","HungarianKalocsa","PolishBoleslawiec","CzechBohemian","FinnishIittala","CroatianHvar",
 "PortugueseAzulejo","SpanishAndalusian","KlimtMosaic","EscherTessellation","CubistFragment","IslamicGeometric","VasarelyOpArt",
 "JapaneseMakie",
]

BACKGROUND_POOL = ["스튜디오중회색","스튜디오차콜","스튜디오다크네이비","스튜디오웜브라운","옥상야경","네온거리","해변석양",
 "루프탑풀","대리석로비","야시장","고대유적","옥상일출","스파온천","열대정원","소금사막","설산","포도밭","인피니티풀"]

AGE_12 = ["A20E","A20M","A20L","A30E","A30M","A30L","A40E","A40M","A40L","A50E","A50M","A50L"]
VIBE_5 = ["VC귀여운","VS섹시한","VCH시크한","VP청순한","VPR도발적인"]

if __name__ == "__main__":
    print("포즈3:", pick_least_used(POSE_19, "pose", 3))
    print("피어싱P3:", pick_least_used(PIERCE_P, "pierce_p", 3))
    print("공예5:", pick_least_used(CRAFTS_39, "craft", 5))
    print("배경3:", pick_least_used(BACKGROUND_POOL, "background", 3))
    print("나이2:", pick_least_used(AGE_12, "age", 2))
    print("분위기2:", pick_least_used(VIBE_5, "vibe", 2))

def pick_random(pool, n=1, seed=None):
    """순수 랜덤 선택 — 사용 이력 추적 없이, 전체 풀에서 균등하게 랜덤으로 n개 뽑는다.
    '최소사용우선'은 라운드로빈처럼 너무 규칙적이 될 수 있어서, 진짜 다양성 테스트엔 이 함수를 쓴다."""
    if seed is not None:
        random.seed(seed)
    pool2 = list(pool)
    random.shuffle(pool2)
    if n <= len(pool2):
        return pool2[:n]
    # n이 풀보다 크면 중복 허용
    return [random.choice(pool) for _ in range(n)]

ENVIRONMENT_POOL = [
 "비내리는야외","눈내리는야외","꽃잎휘날림","눈쌓인산공원","은하수밤하늘","안개낀숲",
 "단풍잎흩날림","모래바람사막","오로라밤하늘","폭포물안개","번개치는밤하늘","서리낀새벽",
]

# ===== 환경(Environment) 48종 — 장소+날씨+시간대+자연현상 결합, 블러 처리 전제 =====
ENVIRONMENT_48 = {
 "비내리는야외": "a rain-soaked outdoor street at night, falling rain streaked by light, softly blurred",
 "눈내리는야외": "falling snow drifting through a cold outdoor night, softly blurred",
 "꽃잎휘날림": "cherry-blossom petals drifting through the air around her, softly blurred",
 "눈쌓인산공원": "a snow-covered mountain park at dusk, softly blurred",
 "은하수밤하늘": "a clear night sky thick with stars and the Milky Way overhead, softly blurred",
 "안개낀숲": "a misty pine forest with soft fog drifting between the trees, softly blurred",
 "단풍잎흩날림": "red and gold autumn leaves drifting through the air around her, softly blurred",
 "모래바람사막": "a desert at dusk with fine windblown sand drifting across the dunes, softly blurred",
 "오로라밤하늘": "a night sky with the aurora rippling in green and violet overhead, softly blurred",
 "폭포물안개": "a waterfall's fine rising mist catching the light behind her, softly blurred",
 "번개치는밤하늘": "a dark stormy sky lit by a distant flash of lightning, softly blurred",
 "서리낀새벽": "a frost-covered field at first light, pale cold mist low to the ground, softly blurred",
 "노을지는열대해변": "a tropical beach at sunset, deep orange and pink sky over the water, softly blurred",
 "일출해변": "a beach at sunrise, soft golden light low over a calm ocean, softly blurred",
 "황금시간대초원": "an open grassland at golden hour, warm low sunlight raking across the grass, softly blurred",
 "블루아워도심": "a city skyline just after sunset in the deep blue hour, softly blurred",
 "한낮사막열기": "a desert at midday with visible heat-shimmer rising off the sand, softly blurred",
 "보름달밤하늘": "a clear night sky with a huge low full moon rising, softly blurred",
 "무지개소나기후": "a landscape just after a rain shower with a faint rainbow arching in the sky, softly blurred",
 "반딧불이숲": "a dark forest clearing with fireflies glowing and drifting in the air, softly blurred",
 "유성우밤하늘": "a dark night sky with streaks of a meteor shower overhead, softly blurred",
 "벚꽃터널": "a long tunnel of blooming cherry trees arching overhead, softly blurred",
 "라벤더밭": "a wide lavender field at golden hour, soft purple rows stretching to the horizon, softly blurred",
 "대나무숲바람": "a tall bamboo grove with the stalks bending gently in a breeze, softly blurred",
 "화산증기": "a volcanic landscape with steam vents rising in the distance, softly blurred",
 "빙하동굴": "the inside of a blue-lit ice cave, light glowing through the ice walls, softly blurred",
 "협곡황금빛": "a deep red-rock canyon lit by low golden sunlight, softly blurred",
 "가을포도밭": "an autumn vineyard with golden-red leaves on the vines, softly blurred",
 "초원뇌우": "an open plain with a distant thunderstorm rolling across the horizon, softly blurred",
 "빙하오로라": "a glacier landscape at night with the aurora glowing above it, softly blurred",
 "온천수증기": "a hot spring with warm steam rising off the water into cold air, softly blurred",
 "안개차밭": "a misty hillside tea plantation at dawn, soft fog hanging over the rows, softly blurred",
 "소금사막거울": "a vast salt flat at dusk, the wet surface mirroring the sky perfectly, softly blurred",
 "야시장빗물반사": "a night market street with rain-slicked ground reflecting the warm lights, softly blurred",
 "옥상안개": "a city rooftop wrapped in low drifting fog at night, softly blurred",
 "보름달뜨는황야": "an open wilderness at dusk with a huge harvest moon rising on the horizon, softly blurred",
 "반사비치야간": "a bioluminescent beach at night, the waves glowing faintly blue where they break, softly blurred",
 "안개소나무숲": "a dense pine forest with thick fog settled low among the trunks, softly blurred",
 "모래먼지돌풍": "a desert landscape with a distant dust devil spinning across the sand, softly blurred",
 "장맛비커튼": "a heavy monsoon rain falling like a curtain across an open landscape, softly blurred",
 "얼어붙은폭포": "a frozen waterfall, pale blue ice catching the winter light, softly blurred",
 "설원빛내림": "a vast snowfield with low golden sunlight raking across the surface, softly blurred",
 "안개항구": "a harbour at dawn wrapped in soft drifting mist, boats faintly visible, softly blurred",
 "들꽃초원바람": "a wildflower meadow swaying gently in a breeze, softly blurred",
 "붉은노을사막": "a desert landscape under a deep crimson sunset sky, softly blurred",
 "청록빙하호수": "a glacial lake with brilliant turquoise water under a clear sky, softly blurred",
 "눈보라설산": "a snowy mountain ridge with blowing snow streaming off the peak, softly blurred",
 "황혼대나무정원": "a traditional garden with tall bamboo at dusk, soft fading light, softly blurred",
 "은하수사막": "a desert at night with a brilliant Milky Way arching over the dunes, softly blurred",
}

# ===== 환경 2.0: 흐림여부 분리 + 실내 환경 추가 =====
FOCUS_STYLE = {
 "흐림": "softly out of focus behind her, a shallow depth of field keeping her sharp",
 "선명": "in sharp focus throughout, both she and the environment clearly resolved, a deep depth of field",
}

ENVIRONMENT_OUTDOOR = {
 "비내리는야외": "a rain-soaked outdoor street at night, falling rain streaked by light",
 "눈내리는야외": "falling snow drifting through a cold outdoor night",
 "꽃잎휘날림": "cherry-blossom petals drifting through the air around her",
 "눈쌓인산공원": "a snow-covered mountain park at dusk",
 "은하수밤하늘": "a clear night sky thick with stars and the Milky Way overhead",
 "안개낀숲": "a misty pine forest with soft fog drifting between the trees",
 "단풍잎흩날림": "red and gold autumn leaves drifting through the air around her",
 "모래바람사막": "a desert at dusk with fine windblown sand drifting across the dunes",
 "오로라밤하늘": "a night sky with the aurora rippling in green and violet overhead",
 "폭포물안개": "a waterfall's fine rising mist catching the light behind her",
 "번개치는밤하늘": "a dark stormy sky lit by a distant flash of lightning",
 "서리낀새벽": "a frost-covered field at first light, pale cold mist low to the ground",
 "노을지는열대해변": "a tropical beach at sunset, deep orange and pink sky over the water",
 "일출해변": "a beach at sunrise, soft golden light low over a calm ocean",
 "황금시간대초원": "an open grassland at golden hour, warm low sunlight raking across the grass",
 "블루아워도심": "a city skyline just after sunset in the deep blue hour",
 "한낮사막열기": "a desert at midday with visible heat-shimmer rising off the sand",
 "보름달밤하늘": "a clear night sky with a huge low full moon rising",
 "무지개소나기후": "a landscape just after a rain shower with a faint rainbow arching in the sky",
 "반딧불이숲": "a dark forest clearing with fireflies glowing and drifting in the air",
 "유성우밤하늘": "a dark night sky with streaks of a meteor shower overhead",
 "벚꽃터널": "a long tunnel of blooming cherry trees arching overhead",
 "라벤더밭": "a wide lavender field at golden hour, soft purple rows stretching to the horizon",
 "대나무숲바람": "a tall bamboo grove with the stalks bending gently in a breeze",
 "화산증기": "a volcanic landscape with steam vents rising in the distance",
 "빙하동굴": "the inside of a blue-lit ice cave, light glowing through the ice walls",
 "협곡황금빛": "a deep red-rock canyon lit by low golden sunlight",
 "가을포도밭": "an autumn vineyard with golden-red leaves on the vines",
 "초원뇌우": "an open plain with a distant thunderstorm rolling across the horizon",
 "빙하오로라": "a glacier landscape at night with the aurora glowing above it",
 "온천수증기": "a hot spring with warm steam rising off the water into cold air",
 "안개차밭": "a misty hillside tea plantation at dawn, soft fog hanging over the rows",
 "소금사막거울": "a vast salt flat at dusk, the wet surface mirroring the sky perfectly",
 "야시장빗물반사": "a night market street with rain-slicked ground reflecting the warm lights",
 "옥상안개": "a city rooftop wrapped in low drifting fog at night",
 "보름달뜨는황야": "an open wilderness at dusk with a huge harvest moon rising on the horizon",
 "반사비치야간": "a bioluminescent beach at night, the waves glowing faintly blue where they break",
 "안개소나무숲": "a dense pine forest with thick fog settled low among the trunks",
 "모래먼지돌풍": "a desert landscape with a distant dust devil spinning across the sand",
 "장맛비커튼": "a heavy monsoon rain falling like a curtain across an open landscape",
 "얼어붙은폭포": "a frozen waterfall, pale blue ice catching the winter light",
 "설원빛내림": "a vast snowfield with low golden sunlight raking across the surface",
 "안개항구": "a harbour at dawn wrapped in soft drifting mist, boats faintly visible",
 "들꽃초원바람": "a wildflower meadow swaying gently in a breeze",
 "붉은노을사막": "a desert landscape under a deep crimson sunset sky",
 "청록빙하호수": "a glacial lake with brilliant turquoise water under a clear sky",
 "눈보라설산": "a snowy mountain ridge with blowing snow streaming off the peak",
 "황혼대나무정원": "a traditional garden with tall bamboo at dusk, soft fading light",
 "은하수사막": "a desert at night with a brilliant Milky Way arching over the dunes",
}

ENVIRONMENT_INDOOR = {
 "창밖비": "a large window behind her with rain streaking down the glass, a dim room beyond",
 "창밖눈": "a large window behind her with snow falling steadily outside, a warm room beyond",
 "벽난로": "a dim room lit by the warm orange glow of a crackling fireplace",
 "온실습기": "a glass greenhouse filled with lush plants and soft humid haze",
 "스파증기": "a warm spa interior with soft steam drifting through the air",
 "다락빛줄기": "a dusty attic with thin shafts of sunlight cutting through the gloom",
 "도서관빛줄기": "a grand library with tall windows, soft light beams falling across rows of books",
 "와인셀러": "a stone wine cellar lit by warm candlelight, bottles lining the walls",
 "실내아이스링크": "an indoor ice rink with cool blue overhead lighting",
 "플라네타리움": "a planetarium dome glowing with a projected starfield overhead",
 "수족관조명": "a large aquarium with blue light filtering through the water behind her",
 "산업로프트먼지빛": "an industrial loft with big windows, dust visible drifting in a shaft of light",
 "스테인드글라스": "a grand hall lit by coloured light falling through a stained-glass window",
 "볼룸샹들리에": "an ornate ballroom lit by a huge crystal chandelier overhead",
 "실내정원아트리움": "a glass-roofed atrium filled with tall indoor trees and soft natural light",
 "사우나증기": "a warm wooden sauna interior with thick steam curling through the air",
 "실내폭포": "a hotel lobby with an indoor waterfall feature softly lit",
 "호텔스위트야경": "a luxury hotel suite at night, a city skyline glowing through floor-to-ceiling windows",
 "녹음스튜디오무드등": "a recording studio lit by moody coloured ambient lighting",
 "아트스튜디오": "a sunlit art studio with paint-splattered surfaces and tall north-facing windows",
 "실내수영장": "an indoor swimming pool at night, water reflections rippling on the ceiling",
 "온실난초": "a warm conservatory filled with blooming orchids and soft misted air",
 "극장무대조명": "an empty theatre stage lit by a single warm spotlight from above",
 "박물관전시홀": "a grand museum hall with tall arched windows and soft diffused daylight",
}

def environment_text(env_key, focus_key="흐림", is_indoor=False):
    pool = ENVIRONMENT_INDOOR if is_indoor else ENVIRONMENT_OUTDOOR
    return f"{pool[env_key]}, {FOCUS_STYLE[focus_key]}"

# ===== 환경 3.0: 시설(Facility) 카테고리 대거 추가 =====
ENVIRONMENT_FACILITY = {
 # 교통시설
 "공항터미널": "a modern airport terminal with tall glass walls and distant departure boards",
 "기차역플랫폼": "a grand train station platform with arriving trains softly blurred in the distance",
 "지하철역": "a subway station platform with tiled walls and the glow of an arriving train",
 "페리선착장": "a ferry dock at dusk with boats moored along the water",
 "전용기내부": "the interior of a private jet cabin, soft warm cabin lighting",
 # 상업시설
 "쇼핑몰아트리움": "a vast shopping mall atrium with a glass-domed ceiling and multiple levels",
 "백화점화장품층": "an upscale department store floor with glowing display counters",
 "부티크매장": "an elegant boutique interior with soft spotlighting on racks of clothing",
 "전통시장홀": "a covered market hall with vendor stalls and warm hanging lights",
 "푸드코트": "a modern food court with colourful signage softly blurred",
 # 유흥시설
 "나이트클럽": "a nightclub interior with coloured strobe lighting and a crowded dance floor softly blurred",
 "칵테일바": "an elegant cocktail bar with warm amber lighting and rows of bottles behind the counter",
 "스피크이지바": "a dim speakeasy-style bar with low vintage lighting and leather booths",
 "노래방룸": "a private karaoke room with coloured mood lighting and a glowing screen",
 "카지노플로어": "a casino floor with glowing slot machines and card tables softly blurred",
 # 놀이시설
 "놀이공원야간": "an amusement park at night, a lit ferris wheel and rides glowing in the background",
 "카니발축제": "a carnival midway at night with colourful lights and game booths",
 "오락실": "a retro arcade with glowing game cabinets and neon signage",
 "볼링장": "a bowling alley with lane lights and a glowing scoreboard behind her",
 "회전목마": "an ornate carousel turning softly in the background, warm lights glowing",
 "롤러코스터구역": "an amusement park with a tall roller coaster track rising behind her",
 "워터파크": "an outdoor water park with slides and pools softly blurred",
 "서커스텐트": "the inside of a grand circus tent, rigging and lights overhead",
 # 공연장
 "콘서트홀": "a grand concert hall with tiered seating and a lit stage beyond",
 "오페라하우스": "an ornate opera house interior with velvet seats and gilded balconies",
 "영화관": "a movie theatre interior with rows of seats and a glowing screen behind her",
 "경기장스타디움": "a huge stadium with tiered seating and floodlights overhead",
 "야외원형극장": "an open-air amphitheatre at dusk with stone tiered seating",
 "재즈클럽": "an intimate jazz club with a small stage and warm low lighting",
 # 스포츠시설
 "체육관": "a modern gym interior with equipment softly blurred in the background",
 "요가스튜디오": "a bright minimalist yoga studio with soft natural light",
 "복싱링": "a boxing gym with a ring lit by overhead lights",
 "테니스코트": "an outdoor tennis court with stadium lighting at dusk",
 "라커룸": "a sleek locker room with rows of lockers and soft overhead lighting",
 # 문화시설
 "아트갤러리": "a minimalist art gallery with white walls and softly spotlit paintings",
 "천문대": "an observatory interior with a huge telescope and a domed ceiling",
 "과학관전시실": "a science museum exhibit hall with glowing interactive displays",
 # 호스피탈리티
 "루프탑바": "a rooftop bar at night with a city skyline glowing behind her",
 "레스토랑인테리어": "an upscale restaurant interior with warm candlelit tables",
 "카페창가": "a cosy café interior with warm light falling through a large window",
 "와인바": "an intimate wine bar with shelves of bottles and soft amber lighting",
 # 산업/업무
 "공장플로어": "an industrial factory floor with machinery softly blurred",
 "오피스타워로비": "a sleek corporate office tower lobby with glass and marble",
 "사진스튜디오백스테이지": "a photography studio backstage area with lighting rigs and reflectors",
 "패션쇼백스테이지": "a fashion show backstage area with mirrors, racks of clothes and bright bulbs",
 # 종교/예식
 "대성당내부": "the soaring interior of a grand cathedral, light falling through high windows",
 "사원내부": "the ornate interior of a traditional temple, warm lantern light",
 "모스크내부": "the interior of a grand mosque with intricate tilework and soft light",
 "웨딩홀": "an elegant wedding hall decorated with flowers and soft fairy lights",
 # 야외 공공시설
 "동물원": "a zoo pathway at dusk with enclosures softly blurred in the background",
 "식물원온실": "a large botanical garden conservatory filled with exotic plants",
 "드라이브인극장": "a drive-in theatre at night with a glowing screen in the distance",
 "축제장야간": "an outdoor festival ground at night with string lights strung overhead",
}

if __name__ == "__main__":
    pass

# ===== 환경 4.0: 탈것(Vehicle) + 농기구(Farm) 카테고리 =====
ENVIRONMENT_VEHICLE = {
 # 버스
 "시내버스내부": "the interior of a city bus, seats and handrails softly blurred",
 "이층버스상단": "the open top deck of a double-decker bus, a city skyline passing behind",
 "투어버스": "the interior of a tour bus with large windows and a passing landscape outside",
 # 비행기
 "비행기객실": "an airplane cabin interior, rows of seats and overhead bins softly blurred",
 "비행기창가구름": "a window seat on an airplane, a sea of clouds visible outside the window",
 "공항활주로탑승": "a jet airliner on an airport tarmac at dusk, boarding stairs beside it",
 "조종석": "an airplane cockpit, instrument panels glowing softly",
 # 오토바이
 "오토바이도로": "a motorcycle parked on an open coastal road at golden hour",
 "빈티지오토바이차고": "a garage with a vintage motorcycle, warm workshop lighting",
 # 자전거
 "자전거도로": "a tree-lined cycling path dappled with afternoon light",
 "자전거대여소": "a row of bicycles at an outdoor rental stand, a city street behind",
 # 트럭
 "픽업트럭짐칸": "the open bed of a pickup truck parked in an open field at dusk",
 "대형트럭운전석": "the cab of a large semi-truck, a highway stretching ahead through the windshield",
 "푸드트럭": "a colourful food truck with its serving window lit, a street scene behind",
 # 배
 "요트갑판": "the deck of a sailing yacht on open water, sails softly blurred behind",
 "크루즈갑판야간": "the deck of a cruise ship at night, the dark ocean and ship lights behind",
 "어선갑판": "the deck of a small fishing boat, nets and equipment softly blurred",
 "대형화물선갑판": "the deck of a large cargo ship, shipping containers stacked behind",
 "럭셔리요트내부": "the interior lounge of a luxury yacht, warm wood panelling and soft light",
 # 농기구/농장
 "트랙터밭": "a wide farm field with a tractor parked in the distance, golden-hour light",
 "콤바인수확철": "a wheat field at harvest time, a combine harvester softly blurred in the background",
 "헛간내부": "the inside of a rustic wooden barn, light falling through gaps in the boards",
 "포도밭트랙터": "a vineyard with a small tractor parked between the rows at golden hour",
 "건초더미들판": "an open field dotted with round hay bales at sunset",
 "농산물직판장": "an outdoor farmers market stall piled with fresh produce",
 "풍차농장": "a row of windmills turning slowly across an open farm landscape",
 "논밭농기구": "a rice paddy field with traditional farming tools softly blurred nearby",
 "과수원사다리": "an orchard with ladders resting against the trees, warm afternoon light",
}

if __name__ == "__main__":
    pass

# ===== 환경 5.0: 도시디테일 + 특수자연/수중 + 야외스포츠 + 주거공간 + 추가시설 =====
ENVIRONMENT_URBAN = {
 "골목길": "a narrow cobblestone alleyway with warm lights glowing from windows above",
 "옥상정원": "a rooftop garden with potted plants and a city skyline behind",
 "주차장": "a multi-level parking garage with concrete pillars and overhead lighting",
 "다리위": "a pedestrian bridge at night, city lights reflecting on the water below",
 "도심광장": "an open city plaza with a fountain and surrounding buildings softly blurred",
 "공사현장": "an urban construction site with scaffolding and warm evening light",
 "성내부": "the grand stone interior of a medieval castle, tall arched windows",
 "궁전정원": "the manicured gardens of a grand palace, fountains and hedges",
 "고대유적석주": "ancient stone ruins with tall weathered columns against the sky",
 "유럽광장": "a European cobblestone piazza lined with cafés, warm evening light",
}

ENVIRONMENT_NATURE_EXTREME = {
 "수중산호초": "underwater, surrounded by a vivid coral reef and shafts of light from above",
 "동굴시스템": "deep inside a limestone cave system, stalactites catching soft light",
 "절벽끝": "standing at the edge of a dramatic cliff overlooking the ocean",
 "정글캐노피": "a dense jungle canopy with shafts of light breaking through the leaves",
 "사바나초원": "an African savanna at golden hour, acacia trees on the horizon",
 "맹그로브습지": "a mangrove swamp with roots rising from still water, soft mist",
 "화산분화구": "the rim of a volcanic crater, faint smoke rising from below",
 "빙산바다": "open polar water dotted with drifting icebergs",
 "레드록사막": "a red-rock desert landscape with dramatic eroded formations",
 "툰드라설원": "a vast open tundra under a pale arctic sky",
}

ENVIRONMENT_SPORT_OUTDOOR = {
 "스키슬로프": "a snowy ski slope with mountain peaks rising behind",
 "골프장": "a manicured golf course at golden hour, rolling green fairways",
 "서핑해변": "a beach with rolling surf and surfboards planted in the sand",
 "스케이트파크": "an outdoor skate park with concrete ramps and graffiti",
 "암벽등반절벽": "a rocky cliff face set up for climbing, ropes and chalk marks visible",
 "승마장": "an open equestrian field with a horse and riding fence softly blurred",
 "요트경기장": "a coastal sailing marina with yachts moored at golden hour",
 "하이킹산길": "a mountain hiking trail with a sweeping valley view behind",
 "야외수영장": "an outdoor swimming pool deck surrounded by loungers",
 "러닝트랙": "an outdoor athletics track with stadium seating softly blurred",
}

ENVIRONMENT_DOMESTIC = {
 "침실": "a softly lit bedroom interior with warm ambient lighting",
 "욕실욕조": "an elegant bathroom with a freestanding tub and soft candlelight",
 "야간발코니": "a private balcony at night overlooking a glittering city skyline",
 "펜트하우스거실": "a luxury penthouse living room with floor-to-ceiling windows at dusk",
 "홈짐": "a sleek home gym with equipment and large mirrors",
 "워크인클로젯": "an elegant walk-in closet with soft spotlighting on racks of clothes",
 "서재": "a private study lined with bookshelves, warm lamp light",
 "주방아일랜드": "a modern kitchen with a marble island, soft pendant lighting",
 "옥상자쿠지": "a rooftop terrace with a glowing hot tub and city lights beyond",
 "온실홈가든": "a home conservatory filled with plants and soft natural light",
}

ENVIRONMENT_FACILITY2 = {
 "귀신의집": "the entrance to a dimly lit amusement-park haunted house attraction",
 "고카트트랙": "an outdoor go-kart track with coloured barriers and overhead lighting",
 "레이저태그": "a dark laser-tag arena lit by glowing neon obstacles",
 "음악페스티벌무대": "an outdoor music festival at night, a lit stage and crowd softly blurred",
 "VIP라운지": "an exclusive VIP lounge with plush seating and low ambient lighting",
 "루프탑풀파티": "a rooftop pool party at dusk, string lights and a glowing pool",
 "방탈출룸": "a themed escape-room interior with puzzle props and moody lighting",
 "트램폴린파크": "an indoor trampoline park with coloured padded surfaces",
 "아이스링크실내": "an indoor ice skating rink with cool overhead lighting",
 "경마장": "a horse racing track grandstand with the track stretching behind",
}

# ===== 줌/카메라 거리(Zoom) 축 =====
ZOOM_LEVELS = {
 "클로즈업": "a close-up shot, the camera framing just her face and shoulders, the environment heavily blurred behind her",
 "타이트풀샷": "a tight full-body shot, the camera close enough that her body fills most of the frame from head to toe, the environment visible but secondary",
 "미디엄와이드": "a medium-wide shot, the camera pulled back so her full body is smaller in frame with noticeably more of the environment visible around her",
 "와이드샷": "a wide establishing shot, the camera pulled well back so she stands within a generous foreground and background — for example sand stretching toward her in the foreground with palm trees behind — her figure clearly smaller than the surrounding scene",
 "익스트림와이드": "an extreme wide shot, the camera far back so she appears as a small figure within a dominant, richly detailed landscape or interior",
}

if __name__ == "__main__":
    pass

# ===== 쥬얼리 개수(JQ) 축 =====
JEWELRY_QTY = {
 "JQ1": "a single piece of jewellery",
 "JQ2": "two to three pieces of jewellery, a simple matched set",
 "JQ3": "four to six pieces of jewellery, layered",
 "JQ4": "seven to ten pieces of jewellery, heavily layered and stacked",
 "JQ5": "well over ten pieces of jewellery, an extreme maximalist stack covering her neck, wrists and fingers",
}

# ===== 재질 트랙 전용 축 =====
MATERIAL_PALETTE = ["citrine","sapphire","amethyst","ruby","jade","rosequartz","aquamarine","smoky","opal",
 "alabaster","amber","moonstone","seaglass","frosted","glacial","resin","rosepink","cobalt"]
# ice 제외(internal fracture planes 표현으로 안전검사 걸림), emerald 제외(internal fractures 표현으로 걸림)

STRUCTURE_T = ["T1","T2","T3","T4","T5","T6"]
# T1=단일통재질, T2=유리그릇+내용물, T3=통재질+봉입물, T4=부위혼합, T5=그라데이션전환, T6=재질→실사전환(듀얼바디)

FRAME_TYPES = ["FRF","FRB","FRW","FRH","FRD","FRQ","FRA","FRFL"]
# 얼굴·가슴·허리·힙·데미스탯·쓰리쿼터·앵클·전신

MATERIAL_BODY_KEYS = ["colo","bust","hgu","tent","top","ath"]  # FULL_BODY/HIP_BODY 공용
# 콜로설·바스트퀸·아워글래스USSBBW·텐트폴USSBBW·톱헤비아워글래스·애슬리트USSBBW

if __name__ == "__main__":
    pass

# ===== 목재/석재 팔레트(재질 트랙 확장) =====
MATERIAL_WOOD = {
 "walnut": ("dark walnut wood", "rich chocolate-brown grain swirling in tight wavy lines, a deep satin polish"),
 "mahogany": ("polished mahogany wood", "deep reddish-brown grain with a warm glowing sheen"),
 "oak": ("golden oak wood", "pale honey-gold grain with bold straight striping, a matte-satin finish"),
 "ebony": ("deep ebony wood", "near-black grain with a glossy, almost liquid polish"),
 "birch": ("pale birch wood", "light cream-white grain with fine subtle striping, a soft satin finish"),
 "rosewood": ("rich rosewood", "deep reddish-purple grain with dark contrasting streaks, a warm glossy polish"),
 "maple": ("blonde maple wood", "pale golden-cream grain with a gentle rippling figure, a bright satin finish"),
 "teak": ("warm teak wood", "golden-brown grain with a naturally oily, soft sheen"),
 "cherrywood": ("polished cherrywood", "warm reddish-amber grain deepening with a rich glossy polish"),
 "zebrawood": ("striped zebrawood", "bold alternating cream and dark-brown stripes, a glossy polish"),
}
MATERIAL_STONE = {
 "whitemarble": ("polished white marble", "soft grey veining threading through a brilliant white ground, a cool glossy polish"),
 "blackmarble": ("polished black marble", "fine silver-white veining threading through a deep black ground, a glossy polish"),
 "greenmarble": ("polished green marble", "swirling emerald and jade veining through a deep green ground, a glossy polish"),
 "granite": ("speckled granite", "a dense field of tiny black, grey and white flecks, a hard glossy polish"),
 "onyx": ("banded onyx", "translucent amber and cream banding layered like tree rings, a deep glossy polish"),
 "travertine": ("warm travertine", "soft porous cream-tan texture with fine natural pitting, a matte-satin finish"),
 "basalt": ("dark basalt", "a dense, even charcoal-grey surface with a cool matte polish"),
 "limestone": ("pale limestone", "a soft warm beige surface with faint fossil-like texture, a matte finish"),
 "quartzite": ("pale quartzite", "a bright white ground with fine grey mineral veining, a hard glossy polish"),
 "terrazzo": ("colourful terrazzo", "small flecks of white, pink and grey stone set in a smooth polished ground"),
}

if __name__ == "__main__":
    pass

# ===== 신규 축: 컷 라인(CutLine) × 방향(Direction) =====
CUT_LINES = {
 "겨드랑이": "a line running straight across her body at armpit height, just below the shoulders",
 "가슴밑": "a line running straight across her body just beneath the bust",
 "허리": "a line running straight across her body at the narrowest point of her natural waist",
 "힙": "a line running straight across her body at the widest point of her hips",
 "허벅지V라인": "a shallow V-shaped line across her upper thighs, angling up from the outer thigh on each side to meet at a point low in the centre, like a bikini-cut line",
}
CUT_DIRECTION = {
 "상체실사": "upper real / lower material — everything above the cut line is ordinary real flesh, everything below it (down to her feet) is one continuous solid material",
 "하체실사": "upper material / lower real — everything from her collarbones down to the cut line is one continuous solid material, everything below the cut line (down to her feet) is ordinary real flesh",
}

if __name__ == "__main__":
    pass
