# -*- coding: utf-8 -*-
import re
s = open("gen_woodstone_groups6.py", encoding="utf-8").read()
ns = {}
exec(s[:s.index("S = [(")], ns)
W, T, build, check, BIG = ns["W"], ns["T"], ns["build"], ns["check"], ns["BIG"]
HEELS = ["eighteen inches", "sixteen inches", "twenty inches"]
cnt = [0]
def heel(m):
    h = HEELS[cnt[0] % 3]; cnt[0] += 1; nm = m.group(1)
    return (f"the most extreme towering heels ever worn, thigh-high platform stiletto boots carved from the same {nm}, each with a thin tapered heel a full {h} tall and a six-inch hidden front platform, her feet arched almost vertically on tiptoe like a dancer on pointe, her whole body lifted impossibly high on them, extra long nails")
def mk(kind, picks, slot):
    t = build(kind, picks, slot)
    t, k = re.subn(r"extreme platform boots carved from the same ([^,]+), extra long nails", heel, t); assert k == len(picks)
    a = " 8K portrait"; assert t.count(a) == 1
    return t.replace(a, " Low camera angle with every boot visible in full down to the floor, the extreme heel height dominating the silhouette." + a)
S = [("석재", [T[6]], 4), ("목재", [W[7], W[10]], 6), ("석재", [T[7], T[2], T[10]], 3)]
o = ["# 가장 극단적인 높이의 힐 — 솔로·듀오·트리오 (목재/석재)\n", "얼굴 문장 없음, 부피 큰 체형. 번호별로 정상/이상만 알려주세요.\n"]
for i, (kind, picks, slot) in enumerate(S, 1):
    t = mk(kind, picks, slot); check(f"h{i}", t)
    assert not re.search(r"\b(\w+) \1\b", t), re.findall(r".{20}\b(\w+) \1\b", t)
    n = len(picks); ti = f"{kind} {['','솔로','듀오','트리오'][n]} · {' / '.join(p[0] for p in picks)} · 체형 {', '.join(BIG[j % 4][0] for j in range(n))} · 극단 힐"
    o.append(f"## {i}. {ti}\n\n```\n{t}\n```\n"); print(i, ti, len(t.split()))
open("/mnt/user-data/outputs/LumineX_ExtremeHeels_3.md", "w", encoding="utf-8").write("\n".join(o))
