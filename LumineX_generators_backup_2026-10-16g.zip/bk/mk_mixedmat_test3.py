# -*- coding: utf-8 -*-
# 여성 바디페인팅 정면 비교 샘플 4개 (부피 큰 체형 2 + 근육질 2) — 남성 정면 실패 대조용
import re, sys
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity"); sys.path.insert(0, "../../master")
_g = open("gen_pierce_statue.py", encoding="utf-8").read()
exec(_g[:_g.index("def build(")])
import mdefs as D
exec(open("../../bk/newbody_defs.py", encoding="utf-8").read(), globals())
_src = open("../../bk/mk_statue_obj11.py", encoding="utf-8").read()
exec(_src[_src.index("rnd.seed("):_src.index("LABEL = ['Physique']")])      # KO 등
rnd.seed(20261703)
sys.path.insert(0, '../../bk')
import bg_library as _BG
OUTD = [b[0] for b in _BG.B if b[4]]
POOL = {b[0]: b[1] for b in D.BODIES}; POOL.update({nm: desc for nm, ko, kod, desc in NB})
_NBd = POOL["Nubian booty builder"]
POOL["Nubian bust builder"] = _NBd.replace("wide flaring lats", "a full, heavy, firm bust standing out on her chest").replace("a deeply carved abdomen with sharp obliques", "a deeply carved six-pack abdomen with sharp obliques")
POSES = {"s_curve": "standing facing the camera in a graceful S-curve, her left hand resting on her flared hip and her right hand lifting her hair away from her neck",
         "walk": "walking toward the camera with a slow swaying runway stride, one hand brushing her hair back",
         "over_shoulder": "standing in three-quarter view with her weight on one leg, one hand on her flared hip, looking back over her shoulder at the camera",
         "crossed": "standing facing the camera with one leg crossed in front of the other, both hands resting on her hips, her head tilted slightly",
         "wide": "standing in a wide confident stance facing the camera, both hands resting on her flared hips, her chin lifted"}
SHOES = ["Extreme gold ballet heels", "Extreme black patent stiletto pumps", "Extreme silver platform sandals", "Extreme red lacquer platform pumps"]
NAILS = ["Long square nails, glossy finish.", "Long almond nails, chrome finish.", "Long coffin nails, deep burgundy.", "Long stiletto nails, glossy black."]
BG = ["plain seamless deep-charcoal", "plain seamless mid-grey", "plain seamless deep-navy"]
NATSM = [("Korean", "smooth fair skin with a warm undertone"), ("Korean", "luminous porcelain skin"), ("Chinese", "smooth fair skin with a neutral undertone"), ("Chinese", "light skin with a warm golden undertone"), ("Japanese", "smooth pale skin with a cool undertone"), ("Japanese", "smooth fair skin with a neutral undertone")]
FACEM = ["a rugged masculine face with a strong square jaw, heavy straight brows and prominent cheekbones", "a chiseled masculine face with a broad jaw, deep-set eyes and a strong brow ridge", "a mature masculine face with a squared chin, a strong nose and a thick neck", "a hard-edged masculine face with a wide jaw, thick brows and a defined Adam's apple"]
MKUM = [""]
BEARDM = ["light stubble", "a short neatly trimmed beard", "a short trimmed beard and moustache", "a dark five-o'clock shadow"]
NATHC = [i for i, h in enumerate(HC) if h[:4] in ("HCJB", "HCNB", "HCDB", "HCCB", "HCAB")]
HKM = ["HSS스트레이트", "HSW웨이브", "HSSK슬릭백", "HSSH샤기컷"]
AGESM = ["in his late 20s", "in his early 30s", "in his mid 30s", "in his late 30s"]
import full_dicts as _F
SHOECOL = ["gold", "black", "red", "silver", "white", "cobalt-blue", "hot-pink"]
GB = {"__name__": "gb"}
exec(open("gen_blend_540.py", encoding="utf-8").read().split("\nPHYS = [")[0], GB)
GB["rnd"] = rnd
_nb = open("mk_blendnew6.py", encoding="utf-8").read()
exec(_nb[_nb.index("NEWM = ["):_nb.index("FORCE = [None]")], GB)
GB["WOODS"] = {k: v for k, v in GB["WOODS"].items() if k in ("walnut", "ebony")}
MATP = ["irezumi", "glass", "stone", "nacre", "scale_snake", "scale_dragon", "scale_butterfly", "scale_koi", "obsidian", "scale_mermaid", "feather", "circuit", "wing"]
MW = [1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3, 3, 3]
SCM = []
def pick_scene_mats(n):
    while True:
        m = [rnd.choices(MATP, weights=MW)[0] for _ in range(n)]
        if len(set(m)) < n or m.count("uvneon") > 1 or ("stone" in m and "wood" in m): continue
        return m
MAT_ART = "{lab} Body Art: {Pr} body carries {mt}. It is fused to {pr} own living skin and flexes slightly over every bulge, with no fabric, seam or garment anywhere. It covers {pr} whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of {pr} hands, sides, back, rear, lower belly, knees, calves and the tops of {pr} feet. {Pr} face is left bare and the material fades out at the neck with no hard line."
def matart(lab, male):
    k = SCM.pop(0); mt, _ = GB["mat_text"](k)
    if male: mt = re.sub(r"\bher\b", "his", mt)
    pr = "his" if male else "her"
    return MAT_ART.format(lab=lab, mt=mt, pr=pr, Pr=pr.capitalize()), GB["MAT_KO"][k]
def craft(c):
    cn, cd, cb, cf = CRAFT_DB_FULL[c]
    return f"{cn} ({cd}), wide {cb} bands following every deep crease and curving around the hips and thighs like contour lines, dense {cf} filling the space between every band", cn

import json, collections
import full_dicts as F
CORE = ["legendary bust", "curved bust", "siren bust hourglass", "glamour hourglass", "hourglass bombshell", "black glamour", "apex siren", "violin hip hourglass", "latina curves", "Brazilian booty glam"]
for _k in CORE: assert _k in POOL, _k
JTYPE_EN = {"JE":"earrings","JN":"necklaces","JB":"bracelets","JR":"rings","JA":"anklets","JH":"hair ornaments"}
JSING = {"JE":"earring","JN":"necklace","JB":"bracelet","JR":"ring","JA":"anklet","JH":"hair ornament"}
JMETAL_EN = {"JMG":"gold","JMS":"silver","JMR":"rose-gold","JMP":"platinum","JMX":"mixed-metal"}
JQ_SHORT = {"JQ1":"a single {m} {s}","JQ2":"two to three {m} {p}","JQ3":"four to six layered {m} {p}","JQ4":"seven to ten heavily stacked {m} {p}","JQ5":"an extreme maximalist stack of well over ten {m} {p}"}
MALEIDOL = ["a handsome young man's idol face with a clean sharp jawline, straight thick brows and defined expressive eyes", "a handsome male model face with high cheekbones, a straight nose, a firm jaw and straight dark brows", "a striking young male model face with sharp straight brows, a strong chin and a visible Adam's apple",
            "a sleek male idol face with a straight nose, a sharp jawline, thick brows and cool intense eyes", "a clean-cut young male model face with defined cheekbones, a firm jaw and strong straight brows", "an elegant handsome young male face with a high nose bridge, a defined jaw, straight brows and a strong neck"]
BOYISH = ["a pretty-boy idol face with flawless smooth skin, large clear eyes, a slim jaw and soft full lips", "a youthful idol face with a small V-line jaw, bright expressive eyes and a straight nose", "a delicate beautiful-boy face with long lashes, a slim straight nose and a clean jawline", "a fresh-faced boy-group idol face with clear glowing skin, bright eyes and a gentle smile line", "a youthful boy-group center idol face with neat sharp brows, a slim nose and glossy full lips", "a pretty androgynous idol face with large doe eyes, a small chin and a soft jaw"]
PRETTY = ["a pretty-boy idol face with flawless smooth skin, large clear eyes, a slim jaw and soft full lips", "a youthful idol face with a small V-line jaw, bright expressive eyes and a straight nose", "a delicate beautiful-boy face with long lashes, a slim straight nose and a clean jawline"]
IDOLF = ["a pretty-boy idol face with flawless smooth skin, large clear eyes, a slim jaw and soft full lips", "a youthful idol face with a small V-line jaw, bright expressive eyes and a straight nose", "a delicate beautiful-boy face with long lashes, a slim straight nose and a clean jawline", "a fresh-faced boy-group idol face with clear glowing skin, bright eyes and a gentle smile line", "a youthful boy-group center idol face with neat sharp brows, a slim nose and glossy full lips", "a pretty androgynous idol face with large doe eyes, a small chin and a soft jaw"]
IDOLB = ["clean-shaven", "a very faint trace of stubble", "a very faint trace of stubble"]
def face_pick():
    if rnd.random() < 0.65: return rnd.choice(MALEIDOL), rnd.choice(IDOLB), True
    return rnd.choice(BOYISH), "clean-shaven", True
AGESB = ["in his early 20s", "in his mid 20s", "in his late 20s", "in his early 30s", "in his mid 30s", "in his late 30s", "in his early 40s", "in his mid 40s"]
MKB = [("", ""), ("dramatic black smoky eyeshadow with sharp winged eyeliner", "블랙 스모키 윙"), ("metallic gold glitter eyeshadow with defined lashes", "골드 글리터 아이"), ("graphic electric-blue eyeliner extended into bold wings", "그래픽 블루 라인"), ("deep plum smoky eyes with dark lashes", "플럼 스모키"), ("silver foil-lined eyes with a cool shimmer", "실버 포일 아이")]
BADCRAFT = {"CroatianHvar", "FinnishIittala", "UkrainianPysanka"}
CRAFTS = [c for c in T.CRAFTS_39 if c not in BADCRAFT]
PLAT = lambda k: k.startswith("플랫폼") or k.startswith("익스트림플랫폼")
SHOEK = list(T.SHOES_24)
POSE_ALL = [k for k in T.POSE_19 if k != "얼굴감싸기"]
POSE_GRP = ["정면와이드스탠스", "3/4각도", "뒷모습3/4", "걷는동작", "허리손", "머리넘기기"]
LAB3 = ["LEFT", "CENTER", "RIGHT"]; LAB2 = ["LEFT", "RIGHT"]
ART = ("{lab}Body Art: Her bare skin is painted in {ct}. The paint is pigment sitting on living skin, so it distorts slightly over every bulge. The paint covers her whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of her hands, sides, back, rear, lower belly, knees, calves and the tops of her feet. Her face is left unpainted and the pattern fades out at the neck with no hard line.")
def shoe_line(lab):
    k = rnd.choice(SHOEK); en = re.sub(r"^extreme ", "", F.SHOE_EN_FULL[k]); col = rnd.choice(SHOECOL)
    if PLAT(k): return f"{lab}Footwear: Extreme {col} {en}, the platform soles rising far higher than her ankle bone, at least three times the thickness of an ordinary heel.", k
    return f"{lab}Footwear: Extreme {col} {en} with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform.", k

MBODIES = {
 "V자 보디빌더": "An extraordinarily large and powerful man, far beyond any real person. A massive V-shaped torso: enormously broad shoulders with capped, rounded deltoids, a thick heavy chest, a deeply carved six-pack abdomen narrowing to a comparatively small waist, huge thick arms with split biceps and horseshoe triceps, wide flaring lats, and powerful thick quads and diamond calves. His head stays in correct proportion to his broad frame.",
 "린 애슬레틱": "A tall, lean, athletic man built like a swimmer. Broad shoulders tapering cleanly to a narrow waist, a defined chest, a visible eight-pack abdomen with sharp obliques, long strong arms with clear vein definition, and long lean muscular legs with defined calves. Nothing bulky, everything taut and sculpted.",
 "키 큰 슬렌더": "A very tall, slim, long-limbed man with a runway build. Straight shoulders, a flat lean chest, a flat defined stomach, slender strong arms and very long legs, lightly muscled and elegant, with visible collarbones and a narrow waist. His head stays in correct proportion to his long frame.",
 "파워리프터": "A thick, heavy, extremely strong man built like a powerlifter. A huge barrel chest, enormously wide shoulders and back, a thick solid waist with a firm rounded belly over strong abs, massive arms, and enormous thick thighs and calves. Every part is large, dense and continuous rather than sharply cut.",
 "대형 헤비": "A giant, big-bellied man with great natural size throughout. Broad powerful shoulders, a wide heavy chest, a large round soft belly hanging over a thick waist, thick strong arms, and wide heavy thighs beneath. Every curve is large, solid and continuous, with a warm, imposing bearing.",
 "클래식 머슬": "A classically muscular athletic man in the shape of a Greek statue. Wide shoulders, a full defined chest, a clean six-pack abdomen, strong rounded arms, and muscular thighs and calves, balanced and proportionate from head to toe, powerful but not exaggerated.",
 "스트롱맨": "A massive, stocky strongman. A thick short neck, huge round shoulders, an enormously deep chest, a thick powerful midsection with a solid belly, tree-trunk arms, and huge thick legs planted wide. Heavy, dense and immovable, every part solid.",
 "중년 실버 아스레틱": "A fit mature man in his late 40s with an athletic, well-kept build. Broad shoulders, a firm defined chest, a flat strong abdomen with visible lines, strong forearms, and lean strong legs, with the quiet, assured bearing of a man who has trained for decades.",
}
NATS = [("Korean", "smooth fair skin with a warm undertone"), ("Korean", "luminous porcelain skin"), ("Chinese", "smooth fair skin with a neutral undertone"), ("Chinese", "light skin with a warm golden undertone"), ("Japanese", "smooth pale skin with a cool undertone"), ("Japanese", "smooth fair skin with a neutral undertone")]
FACE = ["a refined idol face with a clean sharp jawline and defined expressive eyes", "a handsome model face with high cheekbones and a straight nose", "a soft-featured idol face with large clear eyes and a defined jaw", "a striking model face with sharp brows and a narrow chin"]
BEARD = ["clean-shaven", "clean-shaven", "clean-shaven", "a very faint trace of stubble"]
MKU = [("natural idol makeup with soft brown eyeshadow and a tinted lip", "아이돌 내추럴 메이크업"), ("light smoky eyeliner and glossy skin", "라이트 스모키"), ("glass-skin makeup with a faint shimmer on the cheekbones", "글래스 스킨"), ("", "메이크업 없음")]
MOOD = ["calm and cool", "intense and focused", "composed and elegant", "relaxed with a faint half-smile", "fierce and charismatic"]
HK = ["HSS스트레이트", "HSW웨이브", "HSSK슬릭백", "HSSH샤기컷", "HSWF울프컷", "HSPX픽시컷", "HSTN탑노트"]
AGES = ["in his early 20s", "in his mid 20s", "in his late 20s", "in his early 30s", "in his mid 30s"]
NAILS = ["Short, clean nails with a matte black polish.", "Short natural nails.", "Short nails with a glossy dark-grey polish.", "Short nails with a metallic gold polish."]
MBODY = ["V자 보디빌더", "린 애슬레틱", "키 큰 슬렌더", "파워리프터", "클래식 머슬", "스트롱맨"]
MNATS = [("Korean", "smooth fair skin with a warm undertone"), ("Korean", "luminous porcelain skin"), ("Chinese", "smooth fair skin with a neutral undertone"), ("Chinese", "light skin with a warm golden undertone"), ("Japanese", "smooth pale skin with a cool undertone"), ("Japanese", "smooth fair skin with a neutral undertone")]
BOYF = ["a pretty-boy idol face with flawless smooth skin, large clear eyes, a slim jaw and soft full lips", "a youthful idol face with a small V-line jaw, bright expressive eyes and a straight nose", "a delicate beautiful-boy face with long lashes, a slim straight nose and a clean jawline", "a fresh-faced boy-group idol face with clear glowing skin, bright eyes and a gentle smile line", "a youthful boy-group center idol face with neat sharp brows, a slim nose and glossy full lips", "a pretty androgynous idol face with large doe eyes, a small chin and a soft jaw"]
EYEMK = [x[0] for x in MKB if x[0]]
MMOOD = ["calm and cool", "intense and focused", "composed and elegant", "relaxed with a faint half-smile", "fierce and charismatic"]
FHS = [h for h in T.HAIR_STYLE if h[:4] not in ("HSTT", "HSSB")]
FEMBODY = ["legendary bust", "curved bust", "siren bust hourglass", "glamour hourglass", "hourglass bombshell", "black glamour", "apex siren", "violin hip hourglass", "latina curves", "Brazilian booty glam"]
MART = ("{lab} Body Art: His bare skin is painted in {ct}. The paint is pigment sitting on living skin, so it distorts slightly over every muscle and bulge. The paint covers his whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of his hands, sides, back, rear, lower belly, knees, calves and the tops of his feet. His face is left unpainted and the pattern fades out at the neck with no hard line.")
FART = ("{lab} Body Art: Her bare skin is painted in {ct}. The paint is pigment sitting on living skin, so it distorts slightly over every bulge. The paint covers her whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of her hands, sides, back, rear, lower belly, knees, calves and the tops of her feet. Her face is left unpainted and the pattern fades out at the neck with no hard line.")
def pose_t(k, male):
    t = F.POSE_EN_FULL[k]
    return re.sub(r"\bherself\b", "himself", re.sub(r"\bher\b", "his", t)) if male else t
MSHOES = ["combat boots", "chunky platform boots", "high-top platform sneakers", "cowboy boots", "work boots", "thick-soled derby shoes", "chelsea boots", "platform loafers"]
MSHOECOL = ["black", "white", "tan-brown", "silver", "red", "cobalt-blue", "gold", "olive-green"]
def shoe2(lab, male, kind="F"):
    if kind in ("M", "MF") and rnd.random() < 0.225:
        pr = "his" if male else "her"
        return f"{lab} Footwear: Extreme {rnd.choice(MSHOECOL)} {rnd.choice(MSHOES)} with thick platform soles rising far higher than {pr} ankle bone, at least three times the thickness of an ordinary sole."
    k = rnd.choice(list(T.SHOES_24)); en = re.sub(r"^extreme ", "", F.SHOE_EN_FULL[k]); col = rnd.choice(SHOECOL); pr = "his" if male else "her"
    if PLAT(k): return f"{lab} Footwear: Extreme {col} {en}, the platform soles rising far higher than {pr} ankle bone, at least three times the thickness of an ordinary heel."
    return f"{lab} Footwear: Extreme {col} {en} with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform."
def jw():
    q = rnd.choice(list(JQ_SHORT)); jm = JMETAL_EN[rnd.choice(list(JMETAL_EN))]; jt = rnd.choice([k for k in JTYPE_EN if k != "JE"]); return JQ_SHORT[q].format(m=jm, s=JSING[jt], p=JTYPE_EN[jt])
SHAPES = ["a round bell", "a chunky hexagonal nut-shaped weight with a round hole through the centre", "a cube-shaped block", "a square-sided cowbell", "a barrel-shaped weight", "a hammer head", "a teardrop-shaped sinker", "a small flared temple bell", "a ship's anchor", "a miniature anvil", "a pyramid-shaped lump"]
GEMS = ["ruby", "emerald", "sapphire", "diamond", "amethyst", "topaz", "pearl-cluster", "aquamarine"]
CHAINM = ["gold", "silver", "rose-gold", "platinum", "copper", "brass", "bronze"]
WMET = ["iron", "gold", "tin", "silver", "lead", "bronze", "copper"]
WMW = [1, 2, 1, 2, 1, 1, 1]
BRI = {"gold", "silver"}
def wear(n):
    cm = rnd.choice(CHAINM)
    while True:
        ms = [rnd.choices(WMET, weights=WMW)[0] for _ in range(n)]
        if (n == 1 or len(set(ms)) >= 2) and (BRI & set(ms)): break
    sh = rnd.sample(SHAPES, n)
    items = ", ".join(f"a {m} {re.sub(r'^an? ', '', x)}" for m, x in zip(ms, sh)); nw = ["zero", "one", "two", "three", "four", "five", "six"][n]
    return f"a large {cm} hoop carrying {nw} heavy rough hammered matte metal weight{'s' if n > 1 else ''} on {cm} chain{'s of different lengths' if n > 1 else ''} ({items}), all hanging clear of the body and none below the collarbone"
def one_line():
    return f"a single long {rnd.choice(CHAINM)} chain ending in one large faceted {rnd.choice(GEMS)} drop"
def earr():
    t = rnd.randrange(4)
    if t == 0: return f"a different earring on each ear: on one ear {one_line()}, and on the other ear {wear(rnd.choice([2, 3, 4, 5]))}"
    if t == 1:
        n1 = rnd.choice([1, 2, 3, 4, 5]); n2 = rnd.choice([x for x in (2, 3, 4, 5, 6) if x != n1]); return f"a different earring on each ear: on one ear {wear(n1)}, and on the other ear {wear(n2)}"
    if t == 2: return f"a different earring on each ear: on one ear {wear(rnd.choice([3, 4, 5]))}, and on the other ear {one_line()} with a heavy rough {rnd.choice(WMET[1:])} {rnd.choice(SHAPES)} hanging at its end"
    n = rnd.choice([2, 3, 4]); return f"matching-style earrings on both ears, each ear {wear(n)}"

REG_F = {"EA": ["Japanese", "Korean", "Chinese"], "SEA": ["Thai", "Filipina", "Vietnamese"], "SA": ["Indian", "Pakistani", "Uzbek"], "BLACK": ["Nigerian", "Ethiopian", "Yoruba Nigerian", "Jamaican"],
         "ME": ["Iranian", "Lebanese", "Emirati", "Egyptian", "Turkish"], "EU": ["French", "Russian", "Italian", "Ukrainian", "Swedish", "Romanian", "Norwegian", "Spanish", "German"], "LAT": ["Latina", "Brazilian"], "PAC": ["American", "Hawaiian"]}
REG_W = {"EA": 1, "SEA": 1, "SA": 1, "BLACK": 1.6, "ME": 1.4, "EU": 1.8, "LAT": 1, "PAC": 0.8}
_NATMK = collections.defaultdict(list)
for _k in T.MAKEUP_48: _NATMK[face_nohair(_k)[0]].append(_k)
def pick_mk():
    reg = rnd.choices(list(REG_W), weights=list(REG_W.values()))[0]
    nat = rnd.choice([n for n in REG_F[reg] if _NATMK.get(n)])
    return rnd.choice(_NATMK[nat])
MN_REG = {"EA": [("Korean", "luminous porcelain skin"), ("Japanese", "smooth pale skin with a cool undertone"), ("Chinese", "smooth light skin with a warm golden undertone")],
 "SEA": [("Thai", "smooth golden-tan skin"), ("Vietnamese", "smooth warm light-tan skin"), ("Filipino", "smooth warm tan skin")],
 "SA": [("Indian", "smooth warm brown skin with a soft glow"), ("Pakistani", "smooth light-brown skin with a warm undertone"), ("Uzbek", "fair olive skin with a warm undertone")],
 "BLACK": [("Nigerian", "deep rich dark-brown skin with a smooth satin glow"), ("Ethiopian", "smooth medium-brown skin with a warm red undertone"), ("Senegalese", "deep blue-black skin with a smooth sheen"), ("Jamaican", "smooth deep caramel-brown skin"), ("Kenyan", "deep ebony skin with a soft glow")],
 "ME": [("Iranian", "olive skin with a warm undertone"), ("Lebanese", "smooth olive-tan skin"), ("Emirati", "smooth warm golden-tan skin"), ("Egyptian", "smooth warm light-brown skin"), ("Turkish", "fair olive skin with a warm undertone")],
 "EU": [("French", "fair skin with a faint rosy undertone"), ("Swedish", "very pale smooth skin with a cool undertone"), ("Italian", "smooth light-olive skin"), ("Spanish", "smooth warm olive skin"), ("Russian", "pale smooth skin with a cool undertone"), ("German", "fair skin with a neutral undertone"), ("Ukrainian", "fair smooth skin"), ("Norwegian", "pale smooth skin with a soft pink undertone")],
 "LAT": [("Brazilian", "smooth warm bronze skin"), ("Mexican", "smooth warm light-brown skin"), ("Colombian", "smooth golden-tan skin"), ("Argentinian", "smooth light-olive skin")],
 "PAC": [("Hawaiian", "smooth warm bronze skin"), ("Samoan", "smooth warm brown skin"), ("Maori", "smooth warm olive-brown skin")]}
MAGES = ["in his early 20s", "in his mid 20s", "in his mid 20s", "in his late 20s", "in his late 20s", "in his early 30s"]
EXPM = ["a warm natural smile", "a bright open smile showing his teeth", "a gentle soft smile", "a playful half-grin", "a relaxed easygoing look with a faint smile", "a calm gentle gaze", "a cool composed look", "a shy sweet smile", "a confident smirk", "a soft amused smile"]
EXPMF = ["a gentle soft smile", "a relaxed half-smile", "a calm easy look", "a confident smirk", "a soft amused smile"]
MKM = [("natural idol makeup with soft brown eyeshadow and a tinted lip", "아이돌 내추럴"), ("glass-skin makeup with a faint shimmer on the cheekbones", "글래스 스킨"), ("light smoky eyeliner and glossy skin", "라이트 스모키"),
       ("dramatic black smoky eyeshadow with sharp winged eyeliner", "블랙 스모키 윙"), ("metallic gold glitter eyeshadow with defined lashes", "골드 글리터"), ("graphic electric-blue eyeliner extended into bold wings", "블루 라인"),
       ("deep plum smoky eyes with dark lashes", "플럼 스모키"), ("silver foil-lined eyes with a cool shimmer", "실버 포일"), ("soft peach-pink eyeshadow, subtly glossy lips and a dewy highlight on the cheekbones", "피치 듀이"),
       ("bold emerald-green eyeliner with a sheer burgundy-stained lip", "에메랄드 라인"), ("sparkling glitter dusted under the eyes with rose-gold eyeshadow", "로즈골드 글리터"), ("sharp black graphic eyeliner with matte nude lips and defined contour", "그래픽 블랙"),
       ("copper-bronze smoky eyes with a golden highlight", "코퍼 브론즈"), ("pearly white eyeshadow with a clear gloss lip and soft blush", "펄 화이트 글로시")]
def pick_nm():
    reg = rnd.choices(list(REG_W), weights=list(REG_W.values()))[0]
    return rnd.choice(MN_REG[reg])
def nailz():
    fin = {"FC": "chrome", "FT": "glitter", "FH": "holographic"}[rnd.choice(["FC", "FT", "FH"])]
    return f"Extremely long {NAIL_SHAPE_EN_FULL[rnd.choice(T.NAIL_SHAPES)]} nails, {fin} finish studded with crystals."
def person(lab, kind, bkey, pk):
    hs = rnd.choice(FHS); hc = rnd.choice(T.HAIR_COLOR); hair = f"{HAIR_COLOR_EN_FULL[hc]} hair styled in {HAIR_EN_FULL[hs]}"
    if kind == "F":
        mk = pick_mk(); nat, fa = face_nohair(mk)
        t1 = f"{lab}: ONE real adult {nat} woman, her face exactly the same tone as her body, real skin texture with visible pores and fine grain, {fa}, {hair}, real living eyes, wearing {earr()} and {jw()}. {nailz()}"
        ph = f"{lab} Physique: {POOL[bkey]} Her arms, hands, legs and feet stay in correct proportion to each other."
        art, cn = matart(lab, False); pose = f"{lab} Pose: {pose_t(pk, False)}."; tag = f"여성 {KO.get(bkey, bkey)}·메이크업 {mk}"
    elif kind == "MF":
        natm, skinm = pick_nm(); agem = rnd.choice(MAGES); mkt, mko = rnd.choice(MKM)
        fc, bd = rnd.choice(MALEIDOL), rnd.choice(IDOLB)
        mk = (", " + mkt) if mkt and False else ""
        t1 = f"{lab}: ONE real adult {natm} person with a handsome man's face on a full, curvaceous female body — a man {agem}, his face exactly the same tone as his body, real skin texture with visible pores and fine grain, {fc}, {bd}, {mkt}, {skinm}, {rnd.choice(EXPMF)}, {hair}, real living eyes, wearing {earr()} and {jw()}. {nailz()}"
        ph = f"{lab} Physique: {POOL[bkey]} Her arms, hands, legs and feet stay in correct proportion to each other."
        art, cn = matart(lab, False); pose = f"{lab} Pose: {pose_t(pk, False)}."; tag = f"남성얼굴·여성체형 {KO.get(bkey, bkey)}·메이크업 {mko}"
    else:
        nat, skin = pick_nm(); age = rnd.choice(MAGES); mkt, mko = rnd.choice(MKM)
        t1 = f"{lab}: ONE real adult {nat} man {age}, his face exactly the same tone as his body, real skin texture with visible pores and fine grain, {rnd.choice(BOYF)}, clean-shaven, {mkt}, {skin}, {rnd.choice(EXPM)}, {hair}, real living eyes, wearing {earr()} and {jw()}. {nailz()}"
        ph = f"{lab} Physique: {MBODIES[bkey]} His arms, hands, legs and feet stay in correct proportion to each other."
        art, cn = matart(lab, True); pose = f"{lab} Pose: {pose_t(pk, True)}."; tag = f"남성 {bkey}·메이크업 {mko}"
    return "\n".join([t1, ph, art, pose, shoe2(lab, kind == "M", kind)]), f"{tag}({cn})"
SKINP = "Real photographic skin — visible pores and fine grain, a taut surface with natural creases and shadow only where the flesh and muscle fold. No smooth illustration finish, no plastic CG sheen."
def build(kinds):
    n = len(kinds); labs = ["LEFT", "RIGHT"] if n == 2 else ["LEFT", "CENTER", "RIGHT"]
    _bid = rnd.choice(OUTD); BGD = _BG.desc(_bid); BGK = [b[2] for b in _BG.B if b[0] == _bid][0]
    BGD = BGD.replace("completely empty of other people", "empty of any people other than the subjects").replace("made of the same material as her", "made of the same material as them")
    blocks, tags = [], []
    for lab, kd in zip(labs, kinds):
        bk = rnd.choice(MBODY) if kd == "M" else rnd.choice(FEMBODY)
        t, tg = person(lab, kd, bk, rnd.choice(POSE_GRP)); blocks.append(t); tags.append(tg)
    if n == 2:
        fmt = "a vertical portrait-orientation photograph, 4:5 aspect ratio, taller than it is wide"; word = "TWO people standing side by side with generous spacing so every figure reads clearly and nobody's arms cross a neighbour"; cam = "the camera set back so both are visible from head to toe"; endl = "Vertical 4:5 portrait-orientation full-body photograph, taller than it is wide, all faces toward the camera."
    else:
        fmt = "a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide"; word = "THREE people standing close side by side, shoulder to shoulder in a single row, with just enough spacing that every figure reads clearly and nobody's arms cross a neighbour"; cam = "the camera set back far enough that all three are visible from head to toe, the whole row filling the width of the tall frame"; endl = "Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide, all faces toward the camera."
    p = (f"Image format: {fmt}.\n\n"
         f"A full-body photograph in {BGD}, {word}, {cam}, shot on a medium format camera with an 85mm lens at f/8, in natural sunlight, sharp focus on every figure, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n"
         + "\n\n".join(blocks) + "\n\n" + f"Skin (everyone): {SKINP}\n\n"
         f"Background & Lighting: each material catching the sunlight in sharp glints, the sunlight carving every fold, curve and muscle. {endl}")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), re.findall(r"\b(\w+) \1\b", p)
    return p, " / ".join(tags), BGK

import json, collections, itertools
DECKF = []; DECKM = []
def pickbody(kd):
    deck, pool = (DECKM, MBODY) if kd == "M" else (DECKF, FEMBODY)
    if not deck: deck.extend(rnd.sample(pool, len(pool)))
    return deck.pop()
_orig_rc = rnd.choice
def build2(kinds):
    SCM[:] = pick_scene_mats(len(kinds))
    n = len(kinds); labs = ["LEFT", "RIGHT"] if n == 2 else ["LEFT", "CENTER", "RIGHT"]
    _bid = rnd.choice(OUTD); BGD = _BG.desc(_bid); BGK = [b[2] for b in _BG.B if b[0] == _bid][0]
    BGD = BGD.replace("completely empty of other people", "empty of any people other than the subjects").replace("made of the same material as her", "made of the same material as them")
    blocks, tags, metas = [], [], []
    for lab, kd in zip(labs, kinds):
        bk = pickbody(kd); pk = rnd.choice(POSE_GRP)
        t, tg = person(lab, kd, bk, pk); blocks.append(t); tags.append((kd, bk, tg)); metas.append(dict(kind=kd, body=bk, pose=pk))
    if n == 2:
        fmt = "a vertical portrait-orientation photograph, 4:5 aspect ratio, taller than it is wide"; asp = "4:5"; word = "TWO people standing side by side with generous spacing so every figure reads clearly and nobody's arms cross a neighbour"; cam = "the camera set back so both are visible from head to toe"; endl = "Vertical 4:5 portrait-orientation full-body photograph, taller than it is wide, all faces toward the camera."
    else:
        fmt = "a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide"; asp = "2:3"; word = "THREE people standing close side by side, shoulder to shoulder in a single row, with just enough spacing that every figure reads clearly and nobody's arms cross a neighbour"; cam = "the camera set back far enough that all three are visible from head to toe, the whole row filling the width of the tall frame"; endl = "Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide, all faces toward the camera."
    p = (f"Image format: {fmt}.\n\n"
         f"A full-body photograph in {BGD}, {word}, {cam}, shot on a medium format camera with an 85mm lens at f/8, in natural sunlight, sharp focus on every figure, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n"
         + "\n\n".join(blocks) + "\n\n" + f"Skin (everyone): {SKINP}\n\n"
         f"Background & Lighting: each material catching the sunlight in sharp glints, the sunlight carving every fold, curve and muscle. {endl}")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), re.findall(r"\b(\w+) \1\b", p)
    return p, tags, metas, BGK, asp
def short(kd, bk, tg, lv=0):
    mk = re.search(r"메이크업 (.*?)\(", tg); mt = re.search(r"\(([^()]*)\)$", tg); mk = mk.group(1) if mk else ""; mt = mt.group(1) if mt else ""
    nm = {"F": "여 ", "MF": "남얼굴 ", "M": "남 "}[kd] + KO.get(bk, bk)
    return nm + ("·" + mk if lv == 0 and mk else "") + ("·" + mt if lv <= 1 and mt else "")
DUO = [["F", "M"], ["MF", "M"], ["F", "MF"]]
TRIO = list(itertools.permutations(["F", "MF", "M"]))
CAT = "🏺 Living Artifact · Mixed Gender Material Formula"
rows = []; SEEN = set()
NATC = collections.Counter()
for gs, N, combos in ((2, 12, DUO), (3, 6, [list(c) for c in TRIO])):
    i = 0
    while i < N:
        kinds = combos[i % len(combos)]
        try: p, tags, metas, BGK, asp = build2(kinds)
        except AssertionError: continue
        if p in SEEN: continue
        SEEN.add(p); i += 1
        gname = "Duo" if gs == 2 else "Trio"
        for lv in (0, 1, 2):
            title = f"MixedMat {gname} #{i:03d} · " + " / ".join(short(*t, lv) for t in tags)
            if len(title) <= 103: break
        assert len(title) <= 103, title
        rows.append({"key": f"la_mixedmat_{gname.lower()}_{i:03d}", "category": CAT, "title": title, "prompt": p,
                     "meta": {"group_size": gs, "aspect_ratio": asp, "format": "mixed-gender-group", "background": BGK, "kinds": kinds, "persons": metas}})
json.dump(rows, open("/mnt/user-data/outputs/la_mixedmat_test3.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(rows), max(len(r["title"]) for r in rows), len({r["key"] for r in rows}), len({r["title"] for r in rows}))
print(collections.Counter(tuple(r["meta"]["kinds"]) for r in rows))
print(sorted(collections.Counter(m["body"] for r in rows for m in r["meta"]["persons"]).items(), key=lambda x: x[1]))
import statistics
for gs in (2, 3):
    w = [len(r["prompt"].split()) for r in rows if r["meta"]["group_size"] == gs]; print(gs, int(statistics.mean(w)), max(w))
