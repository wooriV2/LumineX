# -*- coding: utf-8 -*-
import re
O = "/mnt/user-data/outputs/"
base = re.findall(r"```\n(.*?)\n```", open(O + "LumineX_UVNeon_SoloDuoTrio_Test.md", encoding="utf-8").read(), re.S)[0]
THREE = "hips AND bust simultaneously flaring to absolute maximum beyond any proportion, with three breasts — a matching pair in the usual place and a third full breast centred directly below the pair, all three the same size and shape and all fully covered by the UV bodypaint,"
def sub(t, a, b):
    assert t.count(a) == 1, a; return t.replace(a, b)
base = sub(base, "hips AND bust simultaneously flaring to absolute maximum beyond any proportion,", THREE)
fm = re.search(r"Bold formations — .*?NO airbrush NO gradient wash\.", base, re.S).group(0)
V = [dict(name="번개 웹 (에메랄드+옐로우)", age="late 20s goddess", hair="BLAZING ELECTRIC EMERALD locs cascading to her waist", art="lightning web",
          fm="Bold formations — BLAZING ELECTRIC EMERALD lightning bolt formations branching across the full torso both legs neck to ankle, VIVID NEON YELLOW spark burst formations filling every gap, STARK WHITE electric arc highlights, NO airbrush NO gradient wash.",
          shoe="emerald yellow platform thigh-high boots 8 inch", nail="BLAZING NEON EMERALD YELLOW", tail="BLAZING UV NEON EMERALD YELLOW on blue-black void skin electric contrast.", hairline="UV-reactive emerald locs cascading to her waist."),
     dict(name="크리스탈 격자 (바이올렛+시안)", age="early 30s goddess", hair="BLAZING ELECTRIC VIOLET locs cascading to her waist", art="crystal lattice",
          fm="Bold formations — BLAZING ELECTRIC VIOLET geometric lattice facets full torso both legs to ankle, prismatic crystal faces refracting CYAN light, STARK WHITE crystal node bursts filling every gap, NO airbrush NO gradient wash.",
          shoe="violet cyan platform heels 8 inch", nail="BLAZING NEON VIOLET CYAN", tail="BLAZING UV NEON VIOLET CYAN on blue-black void skin prismatic contrast.", hairline="UV-reactive violet locs cascading to her waist."),
     dict(name="용 (마젠타+그린)", age="mid 30s goddess", hair="BLAZING ELECTRIC MAGENTA locs mid-length tousled", art="dragon formations",
          fm="Bold formations — BLAZING ELECTRIC MAGENTA dragon coiling the full torso both legs neck to ankle, VIVID NEON GREEN dragon flame formations filling every gap, STARK WHITE eye highlights, NO airbrush NO gradient wash.",
          shoe="magenta green platform thigh-high boots 8 inch", nail="BLAZING NEON MAGENTA GREEN", tail="BLAZING UV NEON MAGENTA GREEN on blue-black void skin dragon contrast.", hairline="UV-reactive magenta locs mid-length tousled.")]
o = ["# 가슴 3개 UV네온 시험 3개 (솔로, 문양 3종)\n", "기존 UV네온 솔로 구조에 가슴 3개 문장을 넣고 문양·색만 바꿨습니다. 번호별로 정상/이상만 알려주세요. 이상이면 가슴이 몇 개로 나왔는지 한 줄만 적어주세요.\n"]
for i, v in enumerate(V, 1):
    t = sub(base, "early 30s goddess", v["age"])
    t = sub(t, "UV-reactive BLAZING ELECTRIC CRYSTAL WHITE locs cascading to her waist", "UV-reactive " + v["hair"])
    t = sub(t, "full body UV neon cosmic nebula bodypaint", f"full body UV neon {v['art']} bodypaint")
    t = sub(t, fm, v["fm"])
    t = sub(t, "Footwear: magenta cyan platform thigh-high boots 8 inch.", f"Footwear: {v['shoe']}.")
    t = sub(t, "BLAZING NEON MAGENTA CYAN UV reactive tips", f"{v['nail']} UV reactive tips")
    t = sub(t, "Hair: UV-reactive crystal-white locs cascading to her waist.", "Hair: " + v["hairline"])
    t = sub(t, "BLAZING UV NEON MAGENTA CYAN GOLD on blue-black void skin cosmic contrast.", v["tail"])
    assert not re.search(r"[가-힣]", t) and "nebula" not in t and "CRYSTAL WHITE" not in t
    o.append(f"## {i}. UV네온 {v['name']} · 블루블랙 피부 · {v['age'].split()[0]} {v['age'].split()[1]} · 슈퍼 아워글래스 · 가슴 3개\n\n```\n{t}\n```\n")
open(O + "LumineX_ThreeBreasts_Neon3.md", "w", encoding="utf-8").write("\n".join(o)); print("ok")
