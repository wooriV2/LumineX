# -*- coding: utf-8 -*-
import json, re
O = "/mnt/user-data/outputs/"
A = "hips AND bust simultaneously flaring to absolute maximum beyond any proportion,"
B = "hips AND bust simultaneously flaring to absolute maximum beyond any proportion, with three breasts of exactly equal size — a matching pair in the usual place and a third breast centred directly below the pair that is NOT smaller, NOT flatter and NOT less full than the other two: all three are identical in diameter, fullness and projection, all three fully covered by the body art,"
def sub(t, a, b, cnt=1):
    assert t.count(a) == cnt, (a, t.count(a)); return t.replace(a, b)
mx = json.load(open(O + "la_maximalist_bundle.json", encoding="utf-8")); cr = json.load(open(O + "la_180_bundle.json", encoding="utf-8"))
def mxsolo(pre, idx=0): return [p for p in mx if p["key"].startswith(pre) and p["meta"].get("group_size") == 1][idx]
cq = [p for p in cr if p["key"] == "la_crystal_solo_04"][0]; ci = [p for p in cr if p["key"] == "la_crystal_solo_16"][0]
bot, sg, gl = mxsolo("la_botanical"), mxsolo("la_stainedglass"), mxsolo("la_goldleaf")
def three(t): return sub(t, A, B)
TB = "with three breasts of exactly equal size — a matching pair in the usual place and a third breast centred directly below the pair that is NOT smaller, NOT flatter and NOT less full than the other two: all three are identical in diameter, fullness and projection, all three fully covered by the body art,"
qz = sub(cq["prompt"], "simultaneously the most massive full-figure curves,", "simultaneously the most massive full-figure curves, " + TB)
ice = three(ci["prompt"]); ice = sub(ice, "Pose: three-quarter angle, one hand on the outer hip, the other raised overhead", "Pose: full frontal, both hands pressing the outer hips outward so the chest is fully visible")
items = [("석영(클리어 쿼츠)", qz, cq["key"]), ("얼음(아이스 크리스탈)", ice, ci["key"]), ("플로럴(작약)", three(bot["prompt"]), bot["key"]), ("스테인드글라스", three(sg["prompt"]), sg["key"]), ("금박", three(gl["prompt"]), gl["key"])]
o = ["# 가슴 3개 — 다른 섹션 5개 (석영 · 얼음 · 플로럴 · 스테인드글라스 · 금박)\n", "기존 솔로 프롬프트(블루블랙 피부, 슈퍼 아워글래스)에 가슴 3개 문장만 넣었습니다. 석영은 아마존 체형, 나머지는 슈퍼 아워글래스입니다. 번호별로 정상/이상만 알려주세요. 이상이면 가슴이 몇 개로 나왔는지 한 줄만 적어주세요.\n"]
for i, (nm, t, src) in enumerate(items, 1):
    assert not re.search(r"[가-힣]", t); print("dup:", re.findall(r"\b(\w+) \1\b", t))
    age = re.search(r"(\w+ \d0s) goddess", t).group(1)
    o.append(f"## {i}. {nm} · 블루블랙 피부 · {age} · {'아마존 보머셸' if i == 1 else '슈퍼 아워글래스'} · 가슴 3개\n\n```\n{t}\n```\n"); print(i, nm, age, src)
open(O + "LumineX_ThreeBreasts_Sections5.md", "w", encoding="utf-8").write("\n".join(o))
