# -*- coding: utf-8 -*-
# 신규 영역 4종 샘플(각 2개): 우주·성운 / 용암·마그마 / 털실·펠트 / 수묵·서예 — mk_new_bundles 틀, 전 축 기본 랜덤
_src = open("mk_new_bundles.py", encoding="utf-8").read()
exec(_src[:_src.index('if __name__')])
LEAD = "body curving to follow her body's true three-dimensional shape, "
T_WET = LEAD + "a continuous glossy wet-look coating over her entire body, thick sheets and streams of liquid running down every curve in glistening rivulets, countless beads and droplets clinging to the surface and dripping from her chin, fingertips, hips and knees, razor-sharp bright specular highlights along every curve, nothing lying flat. Dense wet surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
def V(tag, desc, solid, nmw, T, base, acc, fin): return dict(tag=tag, desc=desc, solid=solid, nmw=nmw, T=T, base=base, acc=acc, fin=fin)
VS = [
 V("젖은 광택 · 브론즈 오일", "oil-drenched glistening bronze", "wet-look", "glistening wet bronze", T_WET,
   "BLAZING deep metallic bronze-gold pigment across the full torso both legs neck to ankle, drenched in thick clear body oil",
   "VIVID golden oil streaming in long slow rivulets and heavy oil droplets hanging from every curve", "mirror-wet glossy"),
 V("젖은 광택 · 샤워 크림슨", "shower-drenched glistening crimson", "wet-look", "glistening wet crimson", T_WET,
   "BLAZING saturated crimson-red pigment across the full torso both legs neck to ankle, soaked under a running shower",
   "VIVID streams of clear water cascading from above in sheets and bright round water beads clinging everywhere, with a fine mist of spray in the air", "mirror-wet glossy"),
 V("젖은 광택 · 빗속 블랙", "rain-drenched glistening jet-black", "wet-look", "glistening wet black", T_WET,
   "BLAZING deep jet-black pigment across the full torso both legs neck to ankle, soaked by pouring rain",
   "VIVID silver rain streaking down in bright lines, white highlights glittering on every water bead and rivulet, and splashes bursting around her feet", "mirror-wet glossy"),
]
def chk(t): return not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t) and "navel" not in t.lower()

import sys
sys.path.insert(0, "../master")
import mdefs as D
import mk_newmakeup as NM
G0 = face.__globals__["G"]; _orig_pm = G0.pick_makeup
NM.extend(G0)
NEWV["wetpaint"] = []
NEWV["crystalp"] = []
MODEMAP = {}
MODEKO = {"both": "머리+얼굴 젖음", "hair": "머리만 젖음", "none": "안 젖음"}
_prev_nv = person_nv
def person_nv(label, key, phys, age, pose, eth):
    if key not in ("wetpaint", "crystalp"): return _prev_nv(label, key, phys, age, pose, eth)
    v = CUR_VAR[(label, key)]; nmw = v["nmw"]; nm = "the wet paint"
    pn, pd = phys; p = f"{label}: " if label else ""
    md = MODEMAP.get(label, "none")
    hairtxt = hair() + (", soaking wet, slicked and clinging in wet strands" if md in ("hair", "both") else "")
    sheen = "water droplets beading across her skin and a wet glistening sheen" if md == "both" else "a soft sheen of natural oils"
    mat = v["mat"] if "mat" in v else HEAD.format(desc=v["desc"], solid=v["solid"]) + v["T"].format(base=v["base"], acc=v["acc"], fin=v["fin"])
    feat, seg, info = face(eth); skin = eth[1]
    hl = HEEL_ if HEELMODE[0] == "forty" else HEEL_REL
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of the same {nmw}, each with {hl}, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, made of the same {nmw} with a high polish."
    fc = f"{p}Face: her face and ears are NOT {nm} — they are real living flesh with real pores, {sheen} and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hairtxt} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    return "\n".join([body, shoe, nails, jw, fc]), info

LIQE = {"샤워": "shower", "오일": "oil", "빗속": "rain"}
LIQ = {"샤워": ("soaked under a running shower", VS[1]["acc"], "mirror-wet glossy", None),
       "오일": ("drenched in thick clear body oil", VS[0]["acc"], "mirror-wet glossy", None),
       "빗속": ("soaked by pouring rain", VS[2]["acc"], "mirror-wet glossy", "outdoor")}
COLS = {  # key: (영어 형용사, base 색 문장, 한글)
 "jet-black": ("jet-black", "BLAZING deep jet-black pigment across the full torso both legs neck to ankle", "블랙", "black"),
 "midnight-blue": ("midnight-blue", "BLAZING deep midnight-blue pigment across the full torso both legs neck to ankle", "미드나이트 블루", "navy"),
 "deep emerald": ("deep emerald", "BLAZING deep emerald-green pigment across the full torso both legs neck to ankle", "딥 에메랄드", "emerald"),
 "burgundy": ("burgundy", "BLAZING deep burgundy-wine pigment across the full torso both legs neck to ankle", "버건디", "burgundy"),
 "cobalt": ("cobalt", "BLAZING cobalt-blue pigment across the full torso both legs neck to ankle", "코발트", "cobalt"),
 "crimson": ("crimson", "BLAZING saturated crimson-red pigment across the full torso both legs neck to ankle", "크림슨", "crimson"),
 "bronze": ("bronze", "BLAZING deep metallic bronze-gold pigment across the full torso both legs neck to ankle", "브론즈", "bronze"),
}
def solid_v(key, liq):
    adj, base, ko, nmc = COLS[key]; how, acc, fin, _ = LIQ[liq]
    return V(f"젖은 {ko}", f"{LIQE[liq]}-drenched glistening {adj}", "wet-look", f"glistening wet {nmc}", T_WET, f"{base}, {how}", acc, fin)
CRY = {"rose": ("ROSE QUARTZ PINK", "SOFT GOLD", "rose quartz crystal", "로즈쿼츠"), "smoky": ("SMOKY GREY", "CHARCOAL", "smoky quartz crystal", "스모키쿼츠")}
def crystal_v(key):
    c1, c2, sh, ko = CRY[key]
    mat = (f"full body {sh} clusters growing directly out of her own skin covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, every crystal point erupting outward from beneath the surface of her living skin in true three-dimensional relief, each facet catching its own individual glint and casting its own small hard shadow onto the skin and onto neighbouring crystals, nothing lying flat. Dense overlapping clusters — BLAZING {c1} crystal points erupting across the full torso both legs neck to ankle, VIVID {c2} mineral veins and undertone glinting through the thinnest points filling every remaining gap with real depth and texture, each facet sharply faceted and distinct, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    return dict(tag=f"석영 {ko}", nmw=sh, mat=mat, desc=sh, solid="crystal")
# (이름, 인원, 액체, [(종류, 키)])  종류: solid=젖은 단색, bodypaint/irezumi/uvneon=일반(젖지 않은) 바디페인팅

import json, collections
_g = open("../master/gen_extreme.py", encoding="utf-8").read()
exec(_g[_g.index("B_INS = ("):_g.index("PAINT_S")])
STY = ['코갸루', '마이코', '경극', '혼례(연지곤지)', '둔황 비천풍', '글래스 스킨', '강남언니', '인스타글램', '구풍', '홍콩풍', '아마갸루', '걸크러시', '지뢰계', '야마바', '만바', '반바', '아게하',
       '히메갸루', '오네에갸루', '로리타 갸루', '야미카와', '데코라', '웨이쉰', '브리티시 모드']
G0.pick_makeup = (lambda _r, style=None: _orig_pm(_r, style=_r.choice(STY)))
FULL = "across the full torso both legs neck to ankle"
# ── 템플릿 ──
T_CHROME = LEAD + "a seamless liquid-metal chrome shell with a perfect mirror finish, reflecting the surroundings in sharp warped images that bend over every curve, hard bright white highlights and deep dark reflections side by side, smooth and seamless with no joints, nothing lying flat. Dense mirror surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_HOLO = LEAD + "a holographic iridescent foil that shifts colour across every curve, bands of colour sliding across the surface as the angle changes, fine prismatic sparkle and sharp bright highlights, nothing lying flat. Dense holographic surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_RHINE = LEAD + "thousands of tiny faceted rhinestone crystals set edge to edge in dense rows that follow her curves, each stone with its own sharp star-shaped glint and rainbow flash, larger stones scattered among the tiny ones, the stones standing in relief over every curve so the surface is never flat, nothing lying flat. Dense crystal surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_POWDER = LEAD + "a thick coat of vivid coloured powder dusted and smeared over her entire body in dense overlapping layers of different colours, big clouds of coloured powder bursting into the air around her and drifting down, powder caked into every crease, nothing lying flat. Dense powder surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_SPLASH = LEAD + "thick wet splashes and splatters of vivid paint thrown over her entire body in overlapping layers, heavy drips running down every curve, big arcs of paint flying through the air around her, glossy wet paint catching the light, nothing lying flat. Dense paint-splashed surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_PROJ = "mapped onto her body and curving to follow its true three-dimensional shape, animated light patterns projected from several unseen projectors onto her skin, the patterns sharp and luminous with crisp edges and slightly warped over every bulge, pools of coloured light spilling onto the floor and faint beams of light visible in the air. Dense projected surface — {base}, {acc}, {fin}, completely covering her whole body, NO airbrush NO gradient wash, NO flat printed surface anywhere"
HEAD_P = HEAD.replace("fused directly to", "projected onto").replace("a solid {solid} ", "{solid} ")
def AV(tag, desc, solid, nmw, T, base, acc, fin, part, head=None):
    return dict(tag=tag, desc=desc, solid=solid, nmw=nmw, T=T, base=base, acc=acc, fin=fin, part=part, head=head or HEAD)
CH_SILVER = AV("크롬 · 실버", "mirror-polished liquid chrome", "liquid chrome", "mirror chrome", T_CHROME, f"BLAZING flawless mirror-silver chrome {FULL}", "VIVID pale blue and warm white reflections warping over every curve, with sharp white highlights streaking along her sides", "mirror-polished", "the chrome")
CH_ROSE = AV("크롬 · 로즈골드", "mirror-polished rose-gold liquid chrome", "liquid chrome", "rose-gold chrome", T_CHROME, f"BLAZING flawless mirror rose-gold chrome {FULL}", "VIVID warm pink and amber reflections warping over every curve, with sharp white highlights streaking along her sides", "mirror-polished", "the chrome")
HO_PINK = AV("홀로그램 · 핑크시안", "iridescent holographic foil", "holographic foil", "holographic foil", T_HOLO, f"BLAZING pink, cyan and violet holographic foil {FULL}", "VIVID bands of gold and lime flashing through the foil, and fine prismatic sparkle across every curve", "mirror-bright foil", "the foil")
RH_AB = AV("라인스톤 · 오로라", "aurora-borealis rhinestone-encrusted", "rhinestone crystal", "rhinestone crystals", T_RHINE, f"BLAZING clear aurora-borealis rhinestones flashing blue, pink and green {FULL}", "VIVID a few larger silver-white stones and tiny gold stones scattered among them", "faceted crystal", "the crystal")
RH_PINK = AV("라인스톤 · 핫핑크", "hot-pink rhinestone-encrusted", "rhinestone crystal", "rhinestone crystals", T_RHINE, f"BLAZING hot-pink rhinestones {FULL}", "VIVID a few larger clear stones and tiny silver stones scattered among them", "faceted crystal", "the crystal")
RH_JET = AV("라인스톤 · 제트블랙", "jet-black rhinestone-encrusted", "rhinestone crystal", "rhinestone crystals", T_RHINE, f"BLAZING jet-black rhinestones {FULL}", "VIVID a few larger silver stones and tiny clear stones flashing among them", "faceted crystal", "the crystal")
PW_HOLI = AV("파우더 · 홀리", "colour-powder-covered", "coloured powder", "vivid pigment", T_POWDER, f"BLAZING magenta, sunny yellow, bright cyan and orange powder in overlapping bands {FULL}", "VIVID big bursting clouds of the same colours hanging in the air around her and powder handprints smeared across her skin", "matte powdery", "the powder")
SP_MC = AV("스플래시 · 마젠타시안", "paint-splashed", "wet paint", "glossy paint", T_SPLASH, f"BLAZING hot magenta and electric cyan paint splashed in overlapping layers {FULL}", "VIVID a few splashes of bright yellow and white paint and long drips running down her legs", "wet glossy paint", "the paint")
SP_YB = AV("스플래시 · 노랑파랑", "paint-splashed", "wet paint", "glossy paint", T_SPLASH, f"BLAZING sunny yellow and deep ultramarine-blue paint splashed in overlapping layers {FULL}", "VIVID a few splashes of bright orange and white paint and long drips running down her legs", "wet glossy paint", "the paint")
PJ_GRID = AV("프로젝션 · 사이버 격자", "animated light-pattern", "pure projected light", "projection-lit pearl-white gloss", T_PROJ, f"BLAZING electric cyan and magenta neon grid lines and geometric shapes {FULL}", "VIVID bright white pulses of light racing along the grid lines", "luminous projected light", "the projected light", HEAD_P)
PJ_KAL = AV("프로젝션 · 만화경", "animated light-pattern", "pure projected light", "projection-lit pearl-white gloss", T_PROJ, f"BLAZING violet, gold and teal kaleidoscope mandala patterns {FULL}", "VIVID mirrored petals of white light opening and closing across her torso", "luminous projected light", "the projected light", HEAD_P)
PJ_OCEAN = AV("프로젝션 · 물결빛", "animated light-pattern", "pure projected light", "projection-lit pearl-white gloss", T_PROJ, f"BLAZING deep blue and turquoise rippling water-caustic light {FULL}", "VIVID bright white caustic lines shimmering across every curve", "luminous projected light", "the projected light", HEAD_P)
def mat_of(v): return v["head"].format(desc=v["desc"], solid=v["solid"]) + v["T"].format(base=v["base"], acc=v["acc"], fin=v["fin"])
NEWV["areap"] = []
_prev_a = person_nv
def person_nv(label, key, phys, age, pose, eth):
    if key != "areap": return _prev_a(label, key, phys, age, pose, eth)
    v = CUR_VAR[(label, key)]; nmw = v["nmw"]; nm = v["part"]
    pn, pd = phys; p = f"{label}: " if label else ""
    mat = mat_of(v)
    feat, seg, info = face(eth); skin = eth[1]
    hl = HEEL_ if HEELMODE[0] == "forty" else HEEL_REL
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of the same {nmw}, each with {hl}, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, made of the same {nmw} with a high polish."
    fc = f"{p}Face: her face and ears are NOT {nm} — they are real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair()} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    return "\n".join([body, shoe, nails, jw, fc]), info
T_HOLO2 = LEAD + "a seamless iridescent liquid-metal shell with an oil-slick holographic sheen, colours sliding across every curve as the angle changes, fine prismatic sparkle and sharp bright mirror highlights, smooth and seamless with no seams or edges, nothing lying flat. Dense holographic surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
HO_FIX = AV("홀로그램 · 핑크시안(액체 크롬형)", "iridescent holographic liquid chrome", "holographic liquid chrome", "holographic chrome", T_HOLO2, f"BLAZING pink, cyan and violet oil-slick holographic chrome {FULL}", "VIVID bands of gold and lime flashing through the sheen, and fine prismatic sparkle across every curve", "mirror-polished", "the chrome")
HO_MINT = AV("홀로그램 · 민트라일락(액체 크롬형)", "iridescent holographic liquid chrome", "holographic liquid chrome", "holographic chrome", T_HOLO2, f"BLAZING mint-green, lilac and peach oil-slick holographic chrome {FULL}", "VIVID bands of electric blue and silver flashing through the sheen, and fine prismatic sparkle across every curve", "mirror-polished", "the chrome")
T_POWDER2 = LEAD + "a thick packed coat of vivid coloured pigment powder pressed onto her entire skin in one continuous matte layer, deep overlapping smears and handprints of colour blending into one another, powder caked into every crease and pooling in every hollow, a haze of coloured powder hanging in the air around her, nothing lying flat. Dense powder surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
T_SPLASH2 = LEAD + "thick wet paint splashed and splattered over her entire body in overlapping layers until no skin shows, a continuous glossy coat of vivid paint over every curve, heavy drips running down every curve, big arcs of paint flying through the air around her, nothing lying flat. Dense paint-splashed surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
PW_A = AV("파우더 · 홀리(수정)", "pigment-caked", "packed pigment powder", "vivid pigment", T_POWDER2, f"BLAZING magenta, sunny yellow, bright cyan and orange powder in overlapping smeared layers {FULL}", "VIVID powder handprints smeared across her skin and thick colour pooled in every hollow", "matte powdery", "the powder")
PW_B = AV("파우더 · 핑크블루(수정)", "pigment-caked", "packed pigment powder", "vivid pigment", T_POWDER2, f"BLAZING hot pink and royal blue powder in overlapping smeared layers {FULL}", "VIVID powder handprints smeared across her skin and thick colour pooled in every hollow", "matte powdery", "the powder")
SP_MC2 = AV("스플래시 · 마젠타시안(수정)", "paint-splashed", "wet paint", "glossy paint", T_SPLASH2, f"BLAZING hot magenta and electric cyan paint splashed in overlapping layers {FULL}", "VIVID a few splashes of bright yellow and white paint and long drips running down her legs", "wet glossy paint", "the paint")
SP_YB2 = AV("스플래시 · 노랑파랑(수정)", "paint-splashed", "wet paint", "glossy paint", T_SPLASH2, f"BLAZING sunny yellow and deep ultramarine-blue paint splashed in overlapping layers {FULL}", "VIVID a few splashes of bright orange and white paint and long drips running down her legs", "wet glossy paint", "the paint")
T_RHINE2 = LEAD + "thousands of tiny faceted rhinestone crystals packed tightly together directly onto her skin with no skin showing between them, stones overlapping at random angles in thick layers, each stone with its own sharp star-shaped glint and rainbow flash, larger stones scattered among the tiny ones, the stones standing in relief over every curve so the surface is never flat, nothing lying flat. Dense crystal surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
def RH2(v): d = dict(v); d["T"] = T_RHINE2; d["tag"] = v["tag"] + "(수정)"; return d

# ═══════════ 새 영역 4종 번들 (크롬·라인스톤·프로젝션·스플래시) ═══════════
import json, collections
from retitle import agg, mk_clean, pose_ko
_g = open("../master/gen_extreme.py", encoding="utf-8").read()
exec(_g[_g.index("B_INS = ("):_g.index("PAINT_S")])
exec(_g[_g.index("SEAT = ["):_g.index("for _p in SEAT")])
EXTREME = ("USSBBW", "hourglass SSBBW")
BODIES22 = [b for b in D.BODIES if not b[0].startswith("pregnant")]
assert len(BODIES22) == 22
def phys_of(b, solo):
    if b[0] in EXTREME:
        return (b[0], b[1] + "; " + B_INS.format(edge=", her body so wide that her hips nearly touch the left and right edges of the frame" if solo else ""))
    return (b[0], b[1])

# ── 주얼리: 라인스톤은 팔다리만, 나머지는 배꼽 항목만 제외 ──
JW_ALL = ns2["JW"]
JW_LIMB = ["thick polished gold bangles stacked on both wrists", "sculpted gold armbands high on both upper arms", "a fine gold chain looped around her thigh above the knee", "heavy gold rings on every finger"]
JW_NONAVEL = [j for j in JW_ALL if "navel" not in j]
assert len(JW_NONAVEL) == 8
CURFAM = ["x"]
def jewel_fam(p):
    lab = p.split(":")[0] if p else None
    fam = CUR_VAR[(lab, "areap")]["fam"] if (lab and (lab, "areap") in CUR_VAR) else CURFAM[0]
    pool = JW_LIMB if fam == "rhine" else JW_NONAVEL
    a = ns2["JR"].sample(pool, 3)
    return ", ".join(a[:-1]) + ", and " + a[-1] + ". Jewelry is metal and pearl only, worn on the body, nothing added to her face or ears."
ns2["jewel"] = jewel_fam

# ── 변형표 ──
def XV(fam, ko, T, desc, solid, nmw, base, acc, fin, part, head=None):
    d = AV(ko, desc, solid, nmw, T, base, acc, fin, part, head); d["fam"] = fam; d["ko"] = ko; return d
def CH(ko, adj, nmc, base, acc):
    return XV("chrome", ko, T_CHROME, f"mirror-polished {adj}liquid chrome", "liquid chrome", f"{nmc}chrome".strip() if nmc else "mirror chrome",
              f"BLAZING flawless mirror {base} chrome {FULL}", f"VIVID {acc} reflections warping over every curve, with sharp white highlights streaking along her sides", "mirror-polished", "the chrome")
CHROME = [  # (변형, 가중치) — 실버는 Kintsugi 액체 실버와 겹쳐 비중을 낮춘다
 (CH("실버", "", "", "silver", "pale blue and warm white"), 0.5), (CH("로즈골드", "rose-gold ", "rose-gold ", "rose-gold", "warm pink and amber"), 1.0),
 (CH("골드", "gold ", "gold ", "gold", "warm orange and pale yellow"), 1.0), (CH("코퍼", "copper ", "copper ", "copper", "deep red-brown and amber"), 1.0),
 (CH("건메탈", "gunmetal ", "gunmetal ", "dark gunmetal", "cool steel-blue and white"), 1.0), (CH("블랙", "black ", "black ", "jet-black", "deep blue and violet"), 1.0),
 (CH("코발트", "cobalt-blue ", "cobalt-blue ", "cobalt-blue", "pale cyan and white"), 1.0)]
def RH(ko, adj, base, acc):
    return XV("rhine", ko, T_RHINE2, f"{adj}rhinestone-encrusted", "rhinestone crystal", "rhinestone crystals", f"BLAZING {base} {FULL}", f"VIVID {acc}", "faceted crystal", "the crystal")
RHINE = [(RH("오로라", "aurora-borealis ", "clear aurora-borealis rhinestones flashing blue, pink and green", "a few larger silver-white stones and tiny gold stones scattered among them"), 1.0),
 (RH("핫핑크", "hot-pink ", "hot-pink rhinestones", "a few larger clear stones and tiny silver stones scattered among them"), 1.0),
 (RH("제트블랙", "jet-black ", "jet-black rhinestones", "a few larger silver stones and tiny clear stones flashing among them"), 1.0),
 (RH("다이아몬드", "diamond-clear ", "diamond-clear rhinestones", "a few larger pale-blue stones and tiny silver stones flashing among them"), 1.0),
 (RH("골드", "gold ", "gold rhinestones", "a few larger clear stones and tiny amber stones scattered among them"), 1.0),
 (RH("루비레드", "ruby-red ", "ruby-red rhinestones", "a few larger clear stones and tiny gold stones scattered among them"), 1.0),
 (RH("에메랄드", "emerald-green ", "emerald-green rhinestones", "a few larger clear stones and tiny gold stones scattered among them"), 1.0),
 (RH("로열블루", "royal-blue ", "royal-blue rhinestones", "a few larger clear stones and tiny silver stones scattered among them"), 1.0)]
def PJ(ko, base, acc):
    return XV("proj", ko, T_PROJ, "animated light-pattern", "pure projected light", "projection-lit pearl-white gloss", f"BLAZING {base} {FULL}", f"VIVID {acc}", "luminous projected light", "the projected light", HEAD_P)
PROJ = [(PJ("사이버 격자", "electric cyan and magenta neon grid lines and geometric shapes", "bright white pulses of light racing along the grid lines"), 1.0),
 (PJ("만화경", "violet, gold and teal kaleidoscope mandala patterns", "mirrored petals of white light opening and closing across her torso"), 1.0),
 (PJ("물결빛", "deep blue and turquoise rippling water-caustic light", "bright white caustic lines shimmering across every curve"), 1.0),
 (PJ("은하수", "deep indigo and violet starfield with drifting nebula clouds of light", "tiny white stars twinkling and bright streaks of light racing across every curve"), 1.0),
 (PJ("불꽃", "flowing orange and crimson flames licking up across every curve", "bright yellow embers and sparks floating across her skin"), 1.0),
 (PJ("오로라 리본", "flowing green and pink aurora ribbons sweeping across every curve", "bright white sparkling edges glowing along the ribbons"), 1.0),
 (PJ("모자이크", "mosaic tiles of red, blue, gold and green light covering every curve", "bright white glowing lines between the tiles"), 1.0)]
def SP(ko, c1, c2, c3):
    return XV("splash", ko, T_SPLASH2, "paint-splashed", "wet paint", "glossy paint", f"BLAZING {c1} and {c2} paint splashed in overlapping layers {FULL}",
              f"VIVID a few splashes of bright {c3} and white paint and long drips running down her legs", "wet glossy paint", "the paint")
SPLASH = [(SP("마젠타시안", "hot magenta", "electric cyan", "yellow"), 1.0), (SP("노랑파랑", "sunny yellow", "deep ultramarine-blue", "orange"), 1.0),
 (SP("오렌지틸", "bright orange", "deep teal", "yellow"), 1.0), (SP("핑크바이올렛", "hot pink", "deep violet", "cyan"), 1.0),
 (SP("레드블랙", "crimson-red", "jet-black", "gold"), 1.0), (SP("라임퍼플", "lime-green", "electric purple", "yellow"), 1.0),
 (SP("터콰이즈코랄", "bright turquoise", "coral-pink", "white"), 1.0)]
AREAS = {"chrome": ("크롬", CHROME), "rhine": ("라인스톤", RHINE), "proj": ("프로젝션", PROJ), "splash": ("스플래시", SPLASH)}
SERIES = {"chrome": "Chrome", "rhine": "Rhinestone", "proj": "Projection", "splash": "Splash", "mix": "Mix4"}
CATS = {"chrome": "🏺 Living Artifact · Chrome Formula", "rhine": "🏺 Living Artifact · Rhinestone Formula", "proj": "🏺 Living Artifact · Projection Formula",
        "splash": "🏺 Living Artifact · Splash Formula", "mix": "🏺 Living Artifact · Four-Element Mix Formula"}
PREF = {"chrome": "la_chrome_", "rhine": "la_rhine_", "proj": "la_proj_", "splash": "la_splash_", "mix": "la_a4mix_"}
NAMES = {1: "solo", 2: "duo", 3: "trio", 4: "quartet", 5: "quintet"}; KOCNT = {1: "솔로", 2: "듀오", 3: "트리오", 4: "쿼르텟", 5: "퀸텟"}
rg = random.Random(20261401); rr.seed(20261401); ns2["JR"].seed(20261401)
SEEN = set()
def pick_var(area, exclude=()):
    ko, L = AREAS[area]
    for _ in range(100):
        v = rg.choices([x[0] for x in L], [x[1] for x in L])[0]
        if v["ko"] not in exclude: return v
    raise SystemExit("pick_var")

NEWV["clothp"] = []
_prev_c = person_nv
def person_nv(label, key, phys, age, pose, eth):
    if key != "clothp": return _prev_c(label, key, phys, age, pose, eth)
    c = CUR_VAR[(label, key)]; nmw = c["nmw"]
    pn, pd = phys; p = f"{label}: " if label else ""
    feat, seg, info = face(eth); skin = eth[1]
    hl = HEEL_ if HEELMODE[0] == "forty" else HEEL_REL
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of {nmw}, each with {hl}, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, in {nmw} with a high polish."
    fc = f"{p}Face: her face is bare of any garment — real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair()} — {c['text']}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    return "\n".join([body, shoe, nails, jw, fc]), info
BODY = {b[0]: b for b in BODIES22}
CL = [
 ("마이크로 하의 · 유두만 가리는 마이크로 비키니 탑 (레드 레더) · 바스트 특화", "glossy red leather", "wearing a minimal red leather micro bikini bottom of one tiny low-rise opaque triangle on thin side strings tied at the hips, the small opaque piece fully covering her, paired with a red leather micro-bikini top reduced to two tiny opaque triangles on thin strings tied at the neck and back, each just big enough to cover only her nipple and nothing more, leaving the rest of her bust visible around them, her stomach fully visible below", None),
 ("마이크로 하의 · 유두만 가리는 마이크로 비키니 탑 (화이트 레더) · 바스트 특화", "glossy white leather", "wearing a minimal white leather micro bikini bottom of one tiny low-rise opaque triangle on thin side strings tied at the hips, the small opaque piece fully covering her, paired with a white leather micro-bikini top reduced to two tiny opaque triangles on thin strings tied at the neck and back, each just big enough to cover only her nipple and nothing more, leaving the rest of her bust visible around them, her stomach fully visible below", None),
 ("마이크로 하의 · 유두만 가리는 마이크로 비키니 탑 (딥 퍼플 레더) · 바스트 특화", "glossy deep purple leather", "wearing a minimal deep purple leather micro bikini bottom of one tiny low-rise opaque triangle on thin side strings tied at the hips, the small opaque piece fully covering her, paired with a deep purple leather micro-bikini top reduced to two tiny opaque triangles on thin strings tied at the neck and back, each just big enough to cover only her nipple and nothing more, leaving the rest of her bust visible around them, her stomach fully visible below", None)]
BODYFOR = {1: 'legendary bust', 2: 'curved bust', 3: 'legendary bust'}
rg = random.Random(20267101); rr.seed(20267101); ns2["JR"].seed(20267101)
o = ["# 마이크로 하의 + 유두만 가리는 마이크로 탑 3색 (가슴 강조 체형)\n", "전 축 기본 랜덤입니다(체형·나이·포즈·인종·배경·힐·네일·주얼리·메이크업). 번호별로 정상/이상만 알려주세요. 이상이면 한 줄만요.\n"]
for gi, (ko, nmw, text, bgs) in enumerate(CL, 1):
    for attempt in range(800):
        CUR_VAR.clear(); CUR_VAR[(None, "clothp")] = dict(text=text, nmw=nmw)
        CURFAM[0] = "x"
        phys = phys_of(BODY[BODYFOR[gi]], True); age = rg.choice(AGES); pose = (rg.choice(SEAT) if (BODYFOR[gi] in EXTREME and rg.random() < 0.7) else rg.choice(POSES)); eth = rg.sample(ETH, 1)
        bid, wx = BGL.pick(rg, 1)
        if bgs and BGL.BG[bid][2] not in bgs: continue
        scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
        ns2["JR"].seed(rg.randrange(10**9))
        t, infos = build3(["clothp"], [None], [phys], [age], [pose], eth, scene)
        t = t.replace("Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle.", "Extreme macro detail on the fabric texture, the skin and the shadows.")
        t = t.replace("no props or statues made of the same material as her.", "no props or statues.")
        if not chk(t) or re.search(r"\b(foil|lens|sticker|doll)\b", t, re.I): continue
        if t.count("forty inches") != (1 if HEELMODE[0] == "forty" else 0) or t.count("Jewelry:") != 1: continue
        break
    else: raise SystemExit("fail")
    hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
    o.append(f"## {gi}. {ko} · 체형 {phys[0]} · 인종 {eth[0][0]} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko}\n\n```\n{t}\n```\n")
    print(gi, ko, len(t.split()), "Pattern" in t, "same material" in t)
open(O + "LumineX_NippleTop3Colors_Solo.md", "w", encoding="utf-8").write("\n".join(o))
