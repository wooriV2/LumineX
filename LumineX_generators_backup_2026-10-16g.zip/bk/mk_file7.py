import re,random
s=open('mk_file4.py',encoding='utf-8').read()
exec(s[:s.index('COOL=')])   # helpers, holes, brighten, THEMES['bright'] ...
NOSES=ns['NOSES'];JAWS=ns['JAWS'];ANG45=ns['ANG45'];HDR=ns['HDR'];ARCHL=ns['ARCH']
EYE=ns['EYEITEMS']+ns['CAN']; LIP=ns['LIPITEMS']
FORE_PEND="A forehead pendant: a fine gold chain runs along the centre parting of her hair and ends in a teardrop gem pendant resting at the middle of her forehead."
NOSE_EAR="A nose-to-ear chain: a fine chain swags from the ring on her left nostril wing across the cheek, well below the eye and clear of the lips, up to a hook at the top of her left ear."
BEADS="A forehead bead band: a row of large turquoise and coral beads is strung across the top of her forehead along the hairline like a headband, with a round ornament set with a large gem at its centre."
COOL=" The background colours are cool, mid-to-dark tones clearly different from her skin tone, never beige, peach, orange or brown, and never bright."
SOFT=", out of focus with a shallow depth of field, with no objects and no people in the background, and the background is darker and softer than her face so that her face and the metal are the brightest, sharpest part of the image."
BGS=[("스튜디오 짙은 남색","A plain seamless deep midnight-navy backdrop, nothing else in frame, no texture, no gradient."+COOL),
("스튜디오 짙은 청록","A plain seamless deep teal backdrop, nothing else in frame, no texture, no gradient."+COOL),
("스튜디오 짙은 자주","A plain seamless deep plum backdrop, nothing else in frame, no texture, no gradient."+COOL),
("스튜디오 슬레이트 회청","A plain seamless dark slate blue-grey backdrop, nothing else in frame, no texture, no gradient."+COOL),
("실내 청록 벨벳 라운지","The background is a dim lounge with deep teal velvet walls and a few soft blurred lamps in muted blue-green"+SOFT+COOL),
("실내 창가 푸른 새벽빛 방","The background is a quiet room beside a tall window, with soft pale blue pre-dawn light and a cool blurred grey-blue wall behind her"+SOFT+COOL),
("실외 푸른 시간대 호숫가","The background is a lakeside at blue hour, a blurred dark navy lake and distant hills under a deep indigo sky"+SOFT+COOL),
("실외 비 오는 밤 청록·남색 네온","The background is a city street at night in the rain, blurred neon signs and car lights in teal and deep blue"+SOFT+COOL),
("실외 안개 낀 숲","The background is a misty forest at dusk, soft blurred dark-green trees fading into pale fog"+SOFT+COOL),
("순흑 기본",None)]
BROWS=[("헤나 문양",5,"her brow bones are bare skin, painted in place of brows with a delicate reddish-brown henna pattern of tiny curling vines and dots following the line of each brow."),
("맨살",1.5,"her brow bones are completely smooth, bare, clean skin with no hair, no drawing and no ornament, like the face of the Mona Lisa, so the whole attention rests on her eyes."),
("보석 라인",1.5,"her brow bones are bare skin, with a thin line of tiny crystal gems glued along each brow bone where the brows would be."),
("스터드 줄",1.5,"her brow bones are bare skin, with a neat row of eight tiny polished silver studs set into the skin along each brow bone, kept well away from her eyes."),
("작은 링 줄",1.5,"her brow bones are bare skin, with a row of five small polished silver rings through the skin along each brow bone, each loop standing out from the skin so the circles are clearly visible, kept well away from her eyes."),
("스파이크 스터드",1.5,"her brow bones are bare skin, with two or three small sharp polished silver cone-spike studs at the outer end of each brow bone, standing out from the skin, kept well away from her eyes."),
("진주 스터드",1,"her brow bones are bare skin, with a row of seven small round white pearl studs set into the skin along each brow bone, getting slightly smaller toward the outer end, kept well away from her eyes."),
("가리비·불가사리 참",1,"her brow bones are bare skin, with three tiny silver rings through the skin along each brow bone, each ring carrying a small charm, a scallop shell, a starfish and a tiny pearl, the charms hanging only a few millimetres below the ring and staying high on the brow bone, well away from her eyelids."),
("산호 구슬 링",1,"her brow bones are bare skin, with a row of small rings through the skin along each brow bone, each ring strung with a pink coral bead, the rings standing out from the skin so the loops and beads are clearly visible, kept well away from her eyes.")]
TEETH=[("금니 그릴즈","Her mouth is slightly open, her lips parted just enough in a confident half-smile to clearly show her upper front teeth, which are covered in polished gold grillz, each tooth capped in shining gold (this overrides the lips pressed or closed in her expression).","섹시한"),
("송곳니+치아 보석","Her mouth is slightly open, her lips parted just enough to clearly show her teeth, with pointed, elongated, sharp canine fangs and a few tiny diamonds set on her front teeth (this overrides the lips pressed or closed in her expression).","카리스마 있는")]
SKINS=[("블루블랙","THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky with a soft healthy sheen",True),
("에보니 브라운","deep ebony-brown skin with a rich warm undertone and a healthy glossy sheen",True),
("올리브","warm olive skin with a natural healthy glow",False),
("포셀린","pale porcelain skin with a cool pink undertone and a soft natural glow",False)]
SLOTS=[("이마 펜던트+코-귀 체인",[FORE_PEND,NOSE_EAR],True,False),("이마 비즈 띠",[BEADS],True,False),("종 모양 귀걸이",[],False,True),("이마 펜던트+코-귀 체인+종 모양 귀걸이",[FORE_PEND,NOSE_EAR],True,True)]
def wchoice(r,items,wi):
    tot=sum(x[wi] for x in items); v=r.random()*tot
    for x in items:
        v-=x[wi]
        if v<=0: return x
    return items[-1]
def subj_add2(t,txt):
    sj=subj(t); k=" Her whole face, ears and neck are real living flesh"
    if k in sj: return t.replace(sj,sj.replace(k," "+txt+k,1))
    return t.replace(sj,sj.rstrip()+" "+txt)
def slots2(t,txts):
    k="The left and right sides are balanced."; assert k in t
    return t.replace(k," ".join(txts)+" "+k,1)
def draw(N,kind,r2,k):
    obj=['theme','chains','slot','brow','teeth']; env=['skin','bg']
    if N>=150: obj=['theme']
    if kind=='lip': obj.remove('teeth') if 'teeth' in obj else None
    cap_obj=2 if N<=25 else 1
    if kind=='lip': cap_obj=1
    if kind=='arch': env=['bg']
    pool=obj+env; r2.shuffle(pool); pick=[]; no=0
    for p in pool:
        if len(pick)>=k: break
        if p in obj:
            if no>=cap_obj: continue
            no+=1
        pick.append(p)
    return pick
def sample(N,kind,k,seed):
    rr=random.Random(seed)
    for tr in range(200):
        r2=random.Random(rr.randrange(10**9))
        try:
            if kind=='eye': name,text,c=r2.choice(EYE)
            elif kind=='lip': name,text,c=r2.choice(LIP)
            else: name,fn,c=r2.choice(ARCHL); text=fn
            picks=draw(N,kind,r2,k); adds=[]; zero=[]; theme=None; chains=False; expr0=None; style0=None; bright=False
            if kind=='eye': zero+=["tmp","brow","bri"]
            if kind=='lip': zero+=["ul","ll","chin"]
            if kind=='arch': zero+=["ul","ll","tmp","brow","bri"]
            texts=[]; slot=None; skinp=None; browp=None; teeth=None; bgp=None; mode_force=None
            for p in picks:
                if p=='theme':
                    skin_dark=False
                    theme=r2.choice(["punk","marine"]); adds.append("테마 "+THEMES[theme][2])
                elif p=='chains': chains=True; adds.append("체인 연결")
                elif p=='slot':
                    slot=r2.choice(SLOTS); adds.append("슬롯 "+slot[0])
                    if slot[2]: zero.append("fh")
                elif p=='brow':
                    browp=wchoice(r2,BROWS,1); adds.append("눈썹 대용 "+browp[0]); zero.append("brow")
                elif p=='teeth':
                    teeth=r2.choice(TEETH); adds.append("치아 "+teeth[0]); expr0=teeth[2]; zero+=["ul","ll","chin"]
                elif p=='skin':
                    skinp=r2.choice(SKINS if N<=50 or True else SKINS);
                    if skinp[0]=="알라바스터": pass
                    adds.append("피부톤 "+skinp[0]); style0="NONE"
                elif p=='bg':
                    bgp=r2.choice(BGS); adds.append("배경 "+bgp[0])
            if skinp and skinp[2]:
                bright=True
                if theme: continue            # dark skin + punk/marine pack: skip combo
                theme="bright"
            if skinp and style0=="NONE" and kind=='lip': pass
            nw=r2.choice([8,9,10]); deco=r2.choice(["",HENNA,STICK,BOTH])
            t,lab,lt,nw=base(r2,N,tuple(dict.fromkeys(zero)),False,deco,nw,theme=theme,chains=chains,expr0=expr0,style0=style0)
            # star feature
            sj=subj(t)
            if kind=='arch':
                tx=text(r2); tx=tx if tx.startswith("Subject:") else "Subject: "+tx
                t=t.replace(sj,tx)
            else:
                jaw=r2.choice(JAWS); nose=r2.choice(NOSES); nz=nose if name!="애니 돌 아이 실사형" else NOSES[0]
                if kind=='eye':
                    star=f"her eyes are the star of her face (the shape, size and lenses described here override the eyes of her makeup, while the colours of her eyeshadow and liner follow her makeup): {text.format(lens='coloured') if '{lens}' in text else text}"
                else:
                    star=f"her lips are the star of her face (the shape, size and projection described here override the lips of her makeup, while the lip colour and finish follow her makeup and ignore any lip colour named here): {text}"
                add=f" Her face has been surgically sculpted far beyond her natural look, and these changes override her natural features: {star}; her nose: {nz[1]}; her jawline and chin: {jaw[1]}. Every feature is exaggerated but beautiful, balanced and refined, in harmony with the rest of her face, never distorted, never grotesque."
                t=t.replace(sj,sj+add)
            if kind=='lip':
                a=ANG45 if r2.random()<0.5 else ANG45.replace("to her left","to her right")
                assert HDR in t; t=t.replace(HDR,a,1)
                b="A soft frontal light on her face and ears"; assert b in t
                t=t.replace(b,"A soft key light from the front and slightly to the side on her face and ears",1)
            # add-ons
            if skinp: t=skin(t,skinp[1])
            if browp: t=subj_add2(t,"She has no eyebrows at all: "+browp[2])
            if teeth: t=subj_add2(t,teeth[1])
            if slot and slot[1]: t=slots2(t,slot[1])
            if bgp and bgp[1]:
                a0="MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient."
                assert a0 in t; t=t.replace(a0,bgp[1])
            # ear style
            if slot and slot[3]: mode="earring"; FORCE_V=4
            else:
                mode=wchoice(r2,[("iron",25),("mix",35),("one",15),("earring",15),("combo",10)],1)[0]; FORCE_V=None
                if bright and mode in("iron","combo"): mode="mix"
            h=2
            if mode in("iron","mix","one"): h=r2.choice([1,2,3])
            if bright: METALS=BRIGHT
            try: t,lab2=finish(t,mode,nw,r2,lab+f" · 귀 추 {nw}개/귀 2구멍",FORCE_V)
            finally: METALS=METALS0
            if bright: t=brighten(t)
            if mode in("iron","mix","one") and h==1: t=t.replace("and above them sit","and above it sit")
            if mode in("iron","mix","one"): t,lab2=holes(t,h,lab2); lab2=re.sub(r" · 귀 구멍 \d개","",lab2).replace(" 2구멍",f" {h}구멍")
        except AssertionError as e:
            continue
        except KeyError as e: continue
        if re.search(r"[가-힣]",t) or "{" in t: continue
        d=re.search(r"\b(\w+) \1\b",t)
        if d and d.group(1).lower() not in("had","that"): continue
        if "zero separate" in t: continue
        if bright and re.search(r"blackened|black cast|bronze|copper|\blead\b|\biron\b|pitted|tarnished|dark (silver|brass)",t): continue
        t=re.sub(r"  +"," ",t)
        title=f"P{N} · {kind=='eye' and '눈' or kind=='lip' and '입술' or '유형'} 주인공 {name} · 추가 축 {len(adds)}개: "+(", ".join(adds) if adds else "없음")+" · "+lab2
        return title,t
    raise SystemExit(("fail",N,kind))
CFG=[(5,'lip',3),(15,'eye',2),(25,'arch',3),(50,'eye',2),(100,'lip',1),(200,'eye',2)]
OUTS=[]
for i,(N,kind,k) in enumerate(CFG):
    ti,t=sample(N,kind,k,9000+i*7); OUTS.append((ti,t)); print(i+1,N,kind,len(t.split()),ti[:140])
o=["# LumineX — 랜덤 풀 확인 샘플 (6개, 피어싱 P5 → P200)\n","- 모든 축을 풀에 넣고 단계별 한도(P25 이하 총 3개·물건 축 2개, P50~P100 총 2개·물건 축 1개, P150 이상 물건 축은 테마 팩만)로 랜덤 추첨했습니다. 각 제목에 이번에 뽑힌 추가 축을 적었습니다. 정상/이상 번호만 알려주세요.\n"]
for i,(title,p) in enumerate(OUTS,1): o.append(f"## {i}. {title}\n\n```\n{p}\n```\n")
open(OUT+'LumineX_RandomPool_Test_1.md','w',encoding='utf-8').write("\n".join(o))
