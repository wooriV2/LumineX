import re,random,sys
sys.path.insert(0,'.')
exec(open('mk_group_v2.py',encoding='utf-8').read().split('if __name__=="__main__":')[0])
BAR=["바비 인형(금발)","바비 인형(갈색 머리)","바비 인형(핑크 머리)"]
SETS=[("바비만 2인 (금발 + 핑크 머리)",[("arch",BAR[0]),("arch",BAR[2])]),
      ("바비만 3인 (금발 + 갈색 + 핑크 머리)",[("arch",n) for n in BAR]),
      ("브랫츠만 4인",[("arch","브랫츠 돌")]*4),
      ("브랫츠만 5인",[("arch","브랫츠 돌")]*5)]
def sig(p):
    a=re.search(r"with ([\w -]+) streaks",p); b=re.search(r"in (?:vivid )?([\w -]+?) (?:doll-eye|big-iris) contact lenses",p)
    return (a.group(1) if a else None, b.group(1) if b else None)
R=random.Random(20261026)
o=["# LumineX — 같은 유형끼리 2~5인 샘플 4개 (바비만 2·3인, 브랫츠만 4·5인)\n",
"- 바비는 머리 색이 3종(금발·갈색·핑크)뿐이라 3인까지만 서로 다르게 가능하고, 4·5인은 줄무늬 색과 렌즈 색을 겹치지 않게 뽑을 수 있는 브랫츠로 골랐습니다.",
"- 같은 유형 안에서 머리 색(브랫츠는 줄무늬·렌즈 색), 피어싱 테마, 귀 장식이 서로 다르게 나오도록 뽑았고, 귀 장식은 인물마다 다른 종류입니다. 유형 사실감 구조는 적용돼 있고(잔털·주근깨 문장은 유형에는 없음), 한 장면·같은 배경입니다.",
"- 정상/이상은 번호로, 이상이면 한 줄만(예: 얼굴이 쌍둥이처럼 같음 · 귀 장식이 같음 · 피부가 고무 같음 · 인물 #번호).\n"]
for idx,(lab,spec) in enumerate(SETS,1):
    n=len(spec); bg=R.choice(BGN)
    for tr in range(900):
        try: t,labs,dup=group5(R.randrange(10**7),spec,"front",bg)
        except AssertionError: continue
        if dup and dup.split()[0].lower() not in("had","that"): continue
        ps=re.findall(r"(?<=\n\n#\d: ).*?(?=\n\n#\d )",t,re.S)
        brz=[sig(p) for p,(k,nm) in zip(ps,spec) if nm=="브랫츠 돌"]
        if brz and (len(set(x[0] for x in brz))<len(brz) or len(set(x[1] for x in brz))<len(brz)): continue
        pl=[l.split(" · ")[5] for l in labs]
        if len(set(pl))<min(len(pl),3): continue
        break
    else: raise SystemExit(("fail",idx))
    t,nB=real2(t); t,k,k2=shorten(t); t=re.sub(r"  +"," ",t); assert not re.search(r"[가-힣]",t)
    o.append(f"## {idx}. {lab} · 배경 {bg}")
    for j,l in enumerate(labs,1): o.append(f"- #{j}: {l}")
    o.append(f"- 길이: {len(t.split())}단어\n\n```\n{t}\n```\n"); print(idx,n,len(t.split()),brz,pl)
open(OUT+'LumineX_SameType_Group_2to5_4.md','w',encoding='utf-8').write("\n".join(o))
