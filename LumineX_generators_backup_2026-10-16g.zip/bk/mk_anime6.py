import re,glob
OUT='/mnt/user-data/outputs/'
att=[f for f in glob.glob('/root/.claude/uploads/*/5a615939-attachment.txt')][0]
A=open(att,encoding='utf-8').read().split("\n\n")
ctl=open(OUT+'LumineX_EarShapes_Face5.md',encoding='utf-8').read()
C=re.search(r"## 1번.*?```\n(.*?)\n```",ctl,re.S).group(1).split("\n\n")
P_A=[p for p in A if p.startswith("Piercings:")][0]; DEPTH=[p for p in C if p.startswith("Piercing depth:")][0]
P_C=[p for p in C if p.startswith("Piercings:")][0]
exec(open('cover_lib.py',encoding='utf-8').read().split("\n",5)[0]) if False else None
SAFE=" sitting in real, calm, healthy skin — no redness, no swelling, no irritation — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes."
P_B=("Piercings: Exactly twelve piercings in total, Y2K maximalist and asymmetrical: on each ear a large glossy hot-pink enamel hoop in the lobe, a row of three rhinestone studs up the rim and one heart-shaped ring above them; one rhinestone stud in the left nostril wing; and one thick bar with star-shaped gem ends through the outer end of the right eyebrow. Each piece is large and clearly visible, and nothing else on the face is pierced. The skin around every piece is smooth, intact and fully healed, with no tearing, no wound, no blood and no redness. All jewelry is polished gold with glossy hot-pink, turquoise and yellow enamel and sparkling rhinestones,"+SAFE)
HEAD={"A":"Anime key visual illustration, close-up beauty portrait. ONE woman, facing the viewer straight on, her head level, both ears clearly visible on either side of her face, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp."}
STYLE={1:"Style: A high-quality Japanese anime key visual illustration, clean cel shading, crisp confident line art, vibrant saturated colors, polished professional anime art — not a photograph. Everything in the image, the face, the hair and every piece of jewelry, is drawn in this same anime style.",
2:"Style: A polished semi-realistic 2.5D anime illustration, soft painterly shading, delicate line art, a gentle hint of skin texture, rich colors — still clearly an illustration, not a photograph. Everything in the image, the face, the hair and every piece of jewelry, is drawn in this same style.",
3:"Style: The woman is a high-quality Japanese anime character, drawn with clean cel shading, crisp confident line art and vibrant saturated colors, but every piece of jewelry on her is a photorealistic real metal object with real reflections, real weight and real material texture, sitting against her drawn skin."}
SUBJ={"star":"Subject: An adult anime heroine, mid 20s, with {skin} and {hair}. Her eyes are huge, glittering anime eyes with big star-shaped pupils, layered highlights and long lashes, under thin expressive brows. Her mouth is a small, cute, cat-like ω-shaped mouth with one tiny fang showing, with a faint blush on her cheeks. A bright, mischievous look straight at the viewer. Every feature is exaggerated but beautiful, balanced and refined, never distorted.",
"heart":"Subject: An adult anime heroine, mid 20s, with {skin} and {hair}. Her eyes are huge, sparkling anime eyes with glossy heart-shaped pupils, soft pink blush lines under the eyes and long curled lashes, under thin expressive brows. Her mouth is a tiny, sweet, ω-shaped smile with a faint blush on her cheeks. A dreamy, adoring look straight at the viewer. Every feature is exaggerated but beautiful, balanced and refined, never distorted.",
"cool":"Subject: An adult anime heroine, mid 20s, with {skin} and {hair}. Her eyes are sharp, narrow, upturned tsurime anime eyes with a cold, piercing iris, crisp highlights and long dark lashes, under low, straight brows. Her mouth is a thin, calm line with two small sharp fangs just visible at the corner. A cool, merciless look straight at the viewer. Every feature is exaggerated but beautiful, balanced and refined, never distorted."}
LIGHT="Lighting: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. A soft frontal light on her face and ears, so the glints on every piece of metal read clearly; a thin cool rim light along the hair and shoulders. 2:3 vertical 8K illustration."
def anime(tier,subj,skin,hair,pier,label):
    P=pier
    if tier<3:
        P=P.replace("sitting in real, calm, healthy skin","sitting in smooth, calm, healthy skin")
        P=re.sub(r"\breal (?=[a-z])","",P)
        D=re.sub(r"\breal (?=[a-z])","",DEPTH).replace("the real tissue","the tissue")
    else: D=DEPTH
    parts=[HEAD["A"],STYLE[tier],SUBJ[subj].format(skin=skin,hair=hair),P,D,"Hair: her hair is swept back behind both ears, leaving both ears, her jawline and her neck fully visible so every piece is in clear view.",LIGHT]
    t="\n\n".join(parts)
    if tier<3: assert not re.search(r"\breal\b|photograph(?!\.)|photorealistic",t.replace("not a photograph","")),re.findall(r".{30}\breal\b.{20}",t)
    return t
SK="smooth fair skin with a soft pink blush"
S=[(1,"star",SK,"long straight pastel-pink hair with a blunt fringe",P_B,"풀 애니 · 별 동공 + ω입 + 송곳니 · Y2K 에나멜 12개"),
   (1,"cool","smooth pale skin","long straight silver-white hair swept back",P_A,"풀 애니 · 날카로운 눈 + 송곳니 · 무쇠 추 귀걸이"),
   (2,"heart","soft warm-beige skin with a gentle blush","a chic black lob with soft layers",P_C,"2.5D · 하트 동공 + ω입 · 금 피어싱 갑옷"),
   (2,"star","soft fair skin with rosy cheeks","long wavy lavender hair with a side fringe",P_B,"2.5D · 별 동공 + ω입 + 송곳니 · Y2K 에나멜 12개"),
   (3,"heart","smooth fair skin with a soft pink blush","long straight honey-blonde hair with a centre part",P_A,"애니 얼굴 + 실사 금속 · 하트 동공 + ω입 · 무쇠 추 귀걸이"),
   (3,"cool","smooth pale skin","long straight jet-black hair swept back",P_C,"애니 얼굴 + 실사 금속 · 날카로운 눈 + 송곳니 · 금 피어싱 갑옷")]
o=["# LumineX — 애니 피어싱 시험 6개 (애니 얼굴 + 피어싱)\n","- 세 가지 스타일 단계: ①풀 애니(얼굴·피어싱 모두 애니) ②2.5D 반실사 애니 ③애니 얼굴 + 실사 금속(제미나이가 스타일을 맞추려는 경향이 있어 위험). 애니 전용 눈·입(별·하트 동공, ω 입, 송곳니)을 넣었고, 피어싱은 기존 틀 3종(Y2K 에나멜 12개 · 무쇠 추 귀걸이 · 금 피어싱 갑옷)입니다.","- 정상/이상(+ 애니 얼굴이 유지되는지, 3·5·6번은 금속만 실사로 나오는지)만 번호로 알려주세요.\n"]
for i,(tr,sj,sk,hr,pr,lab) in enumerate(S,1):
    t=anime(tr,sj,sk,hr,pr,lab); assert not re.search(r"[가-힣]",t)
    o.append(f"## {i}. {lab}\n\n```\n{t}\n```\n"); print(i,len(t.split()))
open(OUT+'LumineX_AnimePiercing_6.md','w',encoding='utf-8').write("\n".join(o))
