# -*- coding: utf-8 -*-
import random, re
import cjk_face_lib as C
F, MK = C.load(); MK.update(C.BLACK_MK)
NAT = {"한국": "Korean", "중국": "Chinese", "일본": "Japanese"}
LEN = "stuck out to a natural, realistic length with the tip reaching just below the lower lip"
NUM = {3: "three", 4: "four", 5: "five", 6: "six"}
EY = {"발랄": "wide bright eyes, cheeks lifted by a cheeky grin, mouth wide open with her tongue ", "도발": "heavy-lidded eyes with a provocative stare straight into the camera, mouth wide open with her tongue ", "광기": "eyes opened extremely wide with the whites showing all around the irises, a fixed unblinking stare, a wide stretched grin with her mouth open and her tongue "}
EN = {"발랄": "a playful, mischievous expression", "도발": "a defiant, provocative expression", "광기": "a manic, unhinged expression"}
DARK = ["비주얼계", "잉크 블랙립", "펑크 블랙립", "고스 블랙립", "걸크러시"]
def src(lv, jew): return [x for x in F if x["meta"]["piercing"] == lv and (("Jewelry:" in x["prompt"]) == jew)][0]
rr = random.Random(88)
o = ["# 갈라진 혀 갈래 수 시험 (3·4·5·6갈래) — 한글 병기 효과 확인용\n", "각 프롬프트의 혀 문장 끝에 한글 괄호 (혀 N갈래)가 들어 있습니다. 제미나이에서 갈래 수가 맞게 나오는지 번호별로 정상/이상만 알려주세요. 이상이면 몇 갈래로 나왔는지 한 줄만 적어주세요.\n"]
for i, (n, nat, ex) in enumerate([(3, "한국", "발랄"), (4, "중국", "광기"), (5, "일본", "도발"), (6, "한국", "광기")], 1):
    lv = rr.choice(["P100", "P150"]); jew = rr.choice([True, False]); mkn = rr.choice(DARK)
    tg = f"the tongue split into {NUM[n]} narrow pointed strands from the tip back about two-thirds of its length, the strands fanned slightly apart [[TG]], a small matching ring through the tip of each strand"
    key = f"tn{i}"; C.EXPR[key] = EY[ex] + LEN + ", " + tg + ", " + EN[ex]
    t = C.build(src(lv, jew), NAT[nat], "아이돌", key, mkn, MK, random.Random(80 + i)).replace("[[TG]]", f"(혀 {n}갈래)")
    assert f"(혀 {n}갈래)" in t and not re.search(r"[가-힣]", re.sub(r"\(혀 \d갈래\)", "", t))
    o.append(f"## {i}. {nat} · 아이돌 · 혀 {n}갈래 + 갈래마다 링 · 표정 {ex} · 메이크업 {mkn} · 피어싱 {lv}{'+쥬얼리' if jew else ''}\n\n```\n{t}\n```\n")
open("/mnt/user-data/outputs/LumineX_Tongue_N_Strands4.md", "w", encoding="utf-8").write("\n".join(o))
print("ok")
