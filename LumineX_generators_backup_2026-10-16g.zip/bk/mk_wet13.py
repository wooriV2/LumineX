# -*- coding: utf-8 -*-
# 신규 영역 4종 샘플(각 2개): 우주·성운 / 용암·마그마 / 털실·펠트 / 수묵·서예 — mk_new_bundles 틀, 전 축 기본 랜덤
_src = open("mk_new_bundles.py", encoding="utf-8").read()
exec(_src[:_src.index('if __name__')])
LEAD = "body curving to follow her body's true three-dimensional shape, "
T_WET = LEAD + "a continuous glossy wet-look coating over her entire body, thick sheets and streams of liquid running down every curve in glistening rivulets, countless beads and droplets clinging to the surface and dripping from her chin, fingertips, hips and knees, razor-sharp bright specular highlights along every curve, nothing lying flat. Dense wet surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
def V(tag, desc, solid, nmw, T, base, acc, fin): return dict(tag=tag, desc=desc, solid=solid, nmw=nmw, T=T, base=base, acc=acc, fin=fin)
VS = [
 V("젖은 광택 · 브론즈 오일", "oil-drenched glistening bronze", "wet-look", "glistening wet bronze", T_WET,
   "BLAZING deep metallic bronze-gold pigment across the full torso both legs neck to ankle, drenched in thick clear body oil",
   "VIVID golden oil streaming in long slow rivulets and heavy oil droplets hanging from every curve", "mirror-wet glossy"),
 V("젖은 광택 · 샤워 크림슨", "shower-drenched glistening crimson", "wet-look", "glistening wet crimson", T_WET,
   "BLAZING saturated crimson-red pigment across the full torso both legs neck to ankle, soaked under a running shower",
   "VIVID streams of clear water cascading from above in sheets and bright round water beads clinging everywhere, with a fine mist of spray in the air", "mirror-wet glossy"),
 V("젖은 광택 · 빗속 블랙", "rain-drenched glistening jet-black", "wet-look", "glistening wet black", T_WET,
   "BLAZING deep jet-black pigment across the full torso both legs neck to ankle, soaked by pouring rain",
   "VIVID silver rain streaking down in bright lines, white highlights glittering on every water bead and rivulet, and splashes bursting around her feet", "mirror-wet glossy"),
]
def chk(t): return not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t) and "navel" not in t.lower()

import sys
sys.path.insert(0, "../master")
import mdefs as D
import mk_newmakeup as NM
G0 = face.__globals__["G"]; _orig_pm = G0.pick_makeup
NM.extend(G0)
NEWV["wetpaint"] = []
_prev_nv = person_nv
def person_nv(label, key, phys, age, pose, eth):
    if key != "wetpaint": return _prev_nv(label, key, phys, age, pose, eth)
    v = CUR_VAR[(label, key)]; nmw = v["nmw"]; nm = "the wet paint"
    pn, pd = phys; p = f"{label}: " if label else ""
    mat = HEAD.format(desc=v["desc"], solid=v["solid"]) + v["T"].format(base=v["base"], acc=v["acc"], fin=v["fin"])
    feat, seg, info = face(eth); skin = eth[1]
    hl = HEEL_ if HEELMODE[0] == "forty" else HEEL_REL
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of the same {nmw}, each with {hl}, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, made of the same {nmw} with a high polish."
    fc = f"{p}Face: her face and ears are NOT {nm} — they are real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair()} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    return "\n".join([body, shoe, nails, jw, fc]), info

LIQE = {"샤워": "shower", "오일": "oil", "빗속": "rain"}
LIQ = {"샤워": ("soaked under a running shower", VS[1]["acc"], "mirror-wet glossy", None),
       "오일": ("drenched in thick clear body oil", VS[0]["acc"], "mirror-wet glossy", None),
       "빗속": ("soaked by pouring rain", VS[2]["acc"], "mirror-wet glossy", "outdoor")}
IREZ = {n: t for n, t in D.IREZUMI}; UVN = {n: t for n, t in D.UVNEON}
def paint_v(kind, key, liq):
    how, acc, fin, _ = LIQ[liq]
    if kind == "irezumi":
        return V(f"이레즈미 {key}", f"{LIQE[liq]}-drenched glistening {key} irezumi", "wet-look", "glistening wet inked", T_WET, f"bold black ink outlines — BLAZING {IREZ[key].replace('BLAZING ', '', 1)}, {how}", acc, fin)
    if kind == "uvneon":
        return V(f"UV네온 {key}", f"{LIQE[liq]}-drenched glistening {key} UV neon bodypaint", "wet-look", "glistening wet neon", T_WET, f"BLAZING {UVN[key].replace('BLAZING ', '', 1)}, {how}", acc, fin)
    cn, cd, cb, cf = D.CRAFTS[key]
    return V(f"공예 {cn}", f"{LIQE[liq]}-drenched glistening {cn} bodypaint", "wet-look", "glistening wet glazed", T_WET,
             f"{cn} — {cd}, wide {cb} bands following every deep crease, {'' if cf.startswith('dense ') else 'dense '}{cf} filling the space between bands, covering her whole body below the jaw, {how}", acc, fin)
# 인원별 구성: (인원, 액체, [(종류, 키), ...])
PLAN = [
 (2, "샤워", [("irezumi", "koi waterfall climb"), ("uvneon", "jellyfish bioluminescence")]),
 (3, "오일", [("craft", "MoroccanZellige"), ("irezumi", "dragon phoenix"), ("uvneon", "aurora curtain")]),
 (4, "빗속", [("irezumi", "great wave"), ("craft", "PortugueseAzulejo"), ("uvneon", "cosmic nebula"), ("irezumi", "peony")]),
 (5, "샤워", [("craft", "Kintsugi"), ("uvneon", "lightning web"), ("irezumi", "tiger"), ("craft", "KoreanNajeon"), ("uvneon", "ocean wave")]),
]
STY = ['코갸루', '걸크러시', '글래스 스킨', '홍콩풍', '강남언니', '인스타글램', '구풍', '오네에갸루', '웨이쉰', '히메갸루', '만바']
G0.pick_makeup = (lambda _r, style=None: _orig_pm(_r, style=_r.choice(STY)))
rg = random.Random(20261128); rr.seed(20261128); ns2["JR"].seed(20261128)
WINTER = ('겨울 눈 광장', '겨울 설원', '얼음 동굴')
NUMKO = {2: "듀오", 3: "트리오", 4: "쿼텟(4인)", 5: "퀸텟(5인)"}
o1 = ["# 젖은 광택(wet-look) × 바디페인팅 그룹 2~5인 — 사람마다 다른 패턴, 한 장면은 같은 액체\n", "Material Mix와 같은 기본 랜덤입니다(체형·나이·포즈·인종·배경·힐·네일·주얼리). 번호별로 정상/이상만 알려주세요. 이상이면 한 줄만요.\n"]
for gi, (n, liq, items) in enumerate(PLAN, 1):
    for attempt in range(500):
        CUR_VAR.clear(); picks = []; kinds = []
        for idx, (k, key) in enumerate(items):
            v = paint_v(k, key, liq); CUR_VAR[(f"#{idx+1}", "wetpaint")] = v; picks.append(v); kinds.append("wetpaint")
        physs = []
        while len(physs) < n:
            c = rg.choices(BIG5, W5)[0]
            if c not in physs: physs.append(c)
        ages = [rg.choice(AGES) for _ in range(n)]; poses = [rg.choice(POSES) for _ in range(n)]; eths = rg.sample(ETH, n)
        bid, wx = BGL.pick(rg, n)
        if LIQ[liq][3] == "outdoor":
            while (not BGL.BG[bid][4]) or BGL.BG[bid][2] in WINTER: bid, wx = BGL.pick(rg, n)
        scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
        ns2["JR"].seed(rg.randrange(10**9))
        t, infos = build3(list(kinds), picks, physs, ages, poses, eths, scene)
        t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as any of them.", 1)
        if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t) or "navel" in t.lower(): continue
        break
    else: raise SystemExit("fail group")
    mats = " / ".join(p["tag"] for p in picks)
    hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
    o1.append(f"## {gi}. {NUMKO[n]} · 젖은 광택 · {liq} · {mats} · 체형 {', '.join(x[0] for x in physs)} · 인종 {', '.join(e[0] for e in eths)} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko}\n\n```\n{t}\n```\n")
    print(gi, n, len(t.split()), t.count("forty inches"))
open(O + "LumineX_WetLook_PaintGroup4.md", "w", encoding="utf-8").write("\n".join(o1))
