import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
from cover_lib import SAFE
SK="The skin around the piece is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
def mk(mat,fin):
    return ("Piercings: Exactly one piercing in total, through the septum, the thin soft wall between the nostrils, and nowhere else: a single thick, solid, sharp tusk of "+mat+f" as thick as her thumb in the middle passes straight through the septum and sweeps out sideways across her face, past the outer edges of her nostril wings to about the middle of her cheeks, in a smooth boar-tusk curve, its two ends rising gently upward and tapering to needle-sharp points, with the tips ending well below her eyes at the height of her nostrils. The tusk sits clearly above her upper lip and does not touch or cover her lips. Nothing hangs from it. {fin} "+SK+" Everything else on her face and ears is completely free of piercings. All jewelry is real "+mat.split(' with')[0].split(' like')[0]+","+SAFE)
V=[("상아·뼈","creamy ivory-white carved bone with fine natural grain and a smooth polished surface","The tusk is pale ivory against her skin."),
   ("흑요석","glossy black volcanic obsidian glass with razor-sharp tapering edges and bright specular reflections","The tusk is deep glassy black with crisp highlights."),
   ("은","bright polished sterling silver with a mirror finish and a slender sharp taper","The tusk is bright, reflective silver."),
   ("금","polished solid yellow gold with a warm mirror finish and a slender sharp taper","The tusk is warm, glowing gold.")]
NA=[("한국","20대","도도한"),("일본","아이돌","군림하는"),("중국","20대","섹시한"),("한국","30대","냉혹한")]
o=["# LumineX — 코 사이 엄니 소재 변주 4개 (상아·흑요석·은·금)\n","- 엄니는 콧볼 바깥에서 뺨 중간까지, 끝은 뾰족하게 좁아지는 멧돼지 엄니 곡선, 추 없음, 입술·턱·귀는 비움. 눈보다 한참 아래에서 끝남.","- 정상/이상(+ 크기·샤프함)만 번호로 알려주세요.\n"]
for i,((lab,mat,fin),(nat,grp,ex)) in enumerate(zip(V,NA),1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(67000+i*100+tr),nat,grp,ex,style="NONE",slots=["pierce"],pier_level="P3"); break
        except AssertionError: continue
    else: raise SystemExit(i)
    old=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    t=re.sub(r'\n\nJewelry:[^\n]*','',t.replace(old,mk(mat,fin)))
    t=t.replace("\n\nLighting:","\n\nHair: her hair is swept back behind both ears, leaving both ears, her jawline and her neck fully visible.\n\nLighting:",1)
    assert not re.search(r"[가-힣]",t)
    o.append(f"## {i}. {lab} — {title}\n\n```\n{t}\n```\n")
open('/mnt/user-data/outputs/LumineX_SeptumTusk_Materials_4.md','w',encoding='utf-8').write("\n".join(o)); print("ok")
