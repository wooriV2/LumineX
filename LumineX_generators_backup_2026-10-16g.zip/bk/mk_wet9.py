# -*- coding: utf-8 -*-
# 신규 영역 4종 샘플(각 2개): 우주·성운 / 용암·마그마 / 털실·펠트 / 수묵·서예 — mk_new_bundles 틀, 전 축 기본 랜덤
_src = open("mk_new_bundles.py", encoding="utf-8").read()
exec(_src[:_src.index('if __name__')])
LEAD = "body curving to follow her body's true three-dimensional shape, "
T_WET = LEAD + "a continuous glossy wet-look coating over her entire body, thick sheets and streams of liquid running down every curve in glistening rivulets, countless beads and droplets clinging to the surface and dripping from her chin, fingertips, hips and knees, razor-sharp bright specular highlights along every curve, nothing lying flat. Dense wet surface — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere"
def V(tag, desc, solid, nmw, T, base, acc, fin): return dict(tag=tag, desc=desc, solid=solid, nmw=nmw, T=T, base=base, acc=acc, fin=fin)
VS = [
 V("젖은 광택 · 브론즈 오일", "oil-drenched glistening bronze", "wet-look", "glistening wet bronze", T_WET,
   "BLAZING deep metallic bronze-gold pigment across the full torso both legs neck to ankle, drenched in thick clear body oil",
   "VIVID golden oil streaming in long slow rivulets and heavy oil droplets hanging from every curve", "mirror-wet glossy"),
 V("젖은 광택 · 샤워 크림슨", "shower-drenched glistening crimson", "wet-look", "glistening wet crimson", T_WET,
   "BLAZING saturated crimson-red pigment across the full torso both legs neck to ankle, soaked under a running shower",
   "VIVID streams of clear water cascading from above in sheets and bright round water beads clinging everywhere, with a fine mist of spray in the air", "mirror-wet glossy"),
 V("젖은 광택 · 빗속 블랙", "rain-drenched glistening jet-black", "wet-look", "glistening wet black", T_WET,
   "BLAZING deep jet-black pigment across the full torso both legs neck to ankle, soaked by pouring rain",
   "VIVID silver rain streaking down in bright lines, white highlights glittering on every water bead and rivulet, and splashes bursting around her feet", "mirror-wet glossy"),
]
def chk(t): return not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t) and "navel" not in t.lower()
import sys
sys.path.insert(0, "../master")
import mdefs as D
_g = open("../master/gen_extreme.py", encoding="utf-8").read()
exec(_g[_g.index("B_INS = ("):_g.index("PAINT_S")])
_SEATS = _g[_g.index("SEAT = ["):_g.index("for _p in SEAT")]
exec(_SEATS)
def _bod(i, ext):
    n, d = D.BODIES[i][0], D.BODIES[i][1]
    return (n, d + "; " + B_INS.format(edge=", her body so wide that her hips nearly touch the left and right edges of the frame")) if ext else (n, d)
PHYS3 = [_bod(12, True), _bod(10, False), _bod(9, False), _bod(11, True), _bod(15, False), _bod(13, False), _bod(10, False), _bod(9, False), _bod(12, True)]
VD = [
 V("A1 밝은색 · 골드 옐로 오일", "oil-drenched glistening bright gold", "wet-look", "glistening wet gold", T_WET,
   "BLAZING bright golden-yellow pigment across the full torso both legs neck to ankle, drenched in thick clear body oil",
   "VIVID clear oil streaming in long slow rivulets and heavy oil droplets hanging from every curve", "mirror-wet glossy"),
 V("A2 밝은색 · 핫핑크 샤워", "shower-drenched glistening hot pink", "wet-look", "glistening wet pink", T_WET,
   "BLAZING hot-pink pigment across the full torso both legs neck to ankle, soaked under a running shower",
   "VIVID streams of clear water cascading from above in sheets and bright round water beads clinging everywhere, with a fine mist of spray in the air", "mirror-wet glossy"),
 V("A3 밝은색 · 스칼렛 빗속", "rain-drenched glistening scarlet", "wet-look", "glistening wet scarlet", T_WET,
   "BLAZING bright scarlet-red pigment across the full torso both legs neck to ankle, soaked by pouring rain",
   "VIVID silver rain streaking down in bright lines, white highlights glittering on every water bead and rivulet, and splashes bursting around her feet", "mirror-wet glossy"),
 V("B1 중간색 · 코발트 빗속", "rain-drenched glistening cobalt", "wet-look", "glistening wet cobalt", T_WET,
   "BLAZING cobalt-blue pigment across the full torso both legs neck to ankle, soaked by pouring rain",
   "VIVID silver rain streaking down in bright lines, white highlights glittering on every water bead and rivulet, and splashes bursting around her feet", "mirror-wet glossy"),
 V("B2 중간색 · 바이올렛 샤워", "shower-drenched glistening violet", "wet-look", "glistening wet violet", T_WET,
   "BLAZING rich violet-purple pigment across the full torso both legs neck to ankle, soaked under a running shower",
   "VIVID streams of clear water cascading from above in sheets and bright round water beads clinging everywhere, with a fine mist of spray in the air", "mirror-wet glossy"),
 V("B3 중간색 · 틸 오일", "oil-drenched glistening teal", "wet-look", "glistening wet teal", T_WET,
   "BLAZING deep teal pigment across the full torso both legs neck to ankle, drenched in thick clear body oil",
   "VIVID clear oil streaming in long slow rivulets and heavy oil droplets hanging from every curve", "mirror-wet glossy"),
 V("C1 새 액체 · 블랙 풀사이드", "pool-drenched glistening jet-black", "wet-look", "glistening wet black", T_WET,
   "BLAZING deep jet-black pigment across the full torso both legs neck to ankle, freshly risen from a swimming pool",
   "VIVID clear pool water streaming off her in sheets as if she has just risen from a pool, bright round water beads clinging everywhere and water dripping from her fingertips and hips", "mirror-wet glossy"),
 V("C2 새 액체 · 블랙 물 튀김", "splash-drenched glistening jet-black", "wet-look", "glistening wet black", T_WET,
   "BLAZING deep jet-black pigment across the full torso both legs neck to ankle, caught in a burst of splashing water",
   "VIVID water bursting around her in frozen mid-air splashes and arcs of droplets, bright round water beads clinging everywhere", "mirror-wet glossy"),
 V("C3 새 액체 · 블랙 파도 물보라", "sea-spray-drenched glistening jet-black", "wet-look", "glistening wet black", T_WET,
   "BLAZING deep jet-black pigment across the full torso both legs neck to ankle, standing in the surf",
   "VIVID sea spray and white foam running down her body in glittering rivulets, with waves of foam splashing around her legs", "mirror-wet glossy"),
]
G0 = face.__globals__["G"]; _orig_pm = G0.pick_makeup
ALLOWED = [
 ['강남언니', '인스타글램', '아게하', '둔황 비천풍', '경극', '홍콩풍'],
 ['아마갸루', '지뢰계', '코갸루', '인스타글램', '홍콩풍', '구풍'],
 ['경극', '혼례(연지곤지)', '구풍', '마이코', '홍콩풍', '강남언니'],
 ['코갸루', '걸크러시', '글래스 스킨', '만바', '야마바', '홍콩풍'],
 ['아마갸루', '지뢰계', '홍콩풍', '글래스 스킨', '만바'],
 ['코갸루', '걸크러시', '글래스 스킨', '둔황 비천풍', '야마바'],
] + [['걸크러시', '만바', '지뢰계', '글래스 스킨', '강남언니', '인스타글램', '코갸루']] * 3
rg = random.Random(20261124); rr.seed(20261124); ns2["JR"].seed(20261124)
o1 = ["# 젖은 광택(wet-look) 시험 9개 (스타일 메이크업을 몸 색에 맞춤: 코갸루·강남언니 등) — 밝은 색 A1~3 · 중간 색 B1~3 · 새 액체 C1~3 (어두운 색 3종은 통과)\n", "Material Mix와 같은 기본 랜덤입니다(체형·나이·포즈·인종·배경·힐·네일·주얼리). 번호별로 정상/이상만 알려주세요. 이상이면 한 줄만요.\n"]
for i, v in enumerate(VD, 1):
    for _ in range(500):
        phys = PHYS3[i - 1]; age = rg.choice(AGES); pose = rg.choice(SEAT) if (phys[0] in ('USSBBW', 'hourglass SSBBW') and rg.random() < 0.7) else rg.choice(POSES); eth = rg.sample(ETH, 1)[0]
        bid, wx = BGL.pick(rg, 1)
        if i >= 7:
            OK = {7: ('옥상 테라스', '야외 테라스', '여름 해변', '하얀 안뜰'), 8: None, 9: ('바닷가 산책로', '여름 해변', '해안 절벽', '항구 등대')}[i]
            while not BGL.BG[bid][4] or (OK and BGL.BG[bid][2] not in OK): bid, wx = BGL.pick(rg, 1)
        scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
        ns2["JR"].seed(rg.randrange(10**9))
        mat = HEAD.format(desc=v["desc"], solid=v["solid"]) + v["T"].format(base=v["base"], acc=v["acc"], fin=v["fin"])
        G0.pick_makeup = (lambda _r, style=None, _a=ALLOWED[i - 1]: _orig_pm(_r, style=_r.choice(_a)))
        body, info = assemble(mat, v["nmw"], "part of the figure", phys, age, pose, eth)
        env = f"{scene}, bright and evenly lit, shadows soft, the whole floor and surroundings clearly visible and in focus, NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as her."
        tail = f"Background: {env} ONE woman only. Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
        t = f"Professional fashion photograph, full body shot. ONE woman standing.\n\n{body}\n\n{tail}{CAM} 8K portrait {ASP[1]} aspect ratio."
        if chk(t): break
    hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
    o1.append(f"## {i}. {v['tag']} 솔로 · 체형 {phys[0]} · 인종 {eth[0]} · {info} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko}\n\n```\n{t}\n```\n")
    print(i, len(t.split()), t.count("forty inches"))
open(O + "LumineX_WetLook_Test9_mk2.md", "w", encoding="utf-8").write("\n".join(o1))
