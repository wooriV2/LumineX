import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
from cover_lib import SAFE
IRON="rough black cast iron with a hammered, pitted, matte surface"
SK="The skin is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
END=" Everything else on her face and ears is completely free of piercings. All jewelry is real blackened cast iron,"
E_=("Piercings: Exactly one piercing in total, a huge stretched hole in the lower lip, and nowhere else. Her lower lip is not a normal lip any more: it has been stretched around a large round hole in its centre until the lip itself is only a thin, smooth, taut loop of soft pink-red lip flesh, like a rubber band, that circles the hole all the way around, and the hole is completely filled by a thick round plate of "+IRON+" as wide as two of her fingers laid side by side, so the viewer sees, from the outside to the inside, her chin, then the full ring of stretched lip flesh, then the dark metal plate in the middle. The ring of lip flesh is clearly visible on every side of the plate, with the plate's edge sunk into it, and the plate's flat face is turned toward the viewer. The loop of lip hangs down from her mouth, so her upper lip, her teeth line and the corners of her mouth stay fully bare and visible above it. Nothing hangs from the plate. "+SK+END+SAFE)
F_=("Piercings: Exactly one piercing in total, and nowhere else: a traditional stretched lip plate in the lower lip, in the style of the lip plates worn in Ethiopia. A thick round plate of "+IRON+" as wide as two of her fingers laid side by side sits inside a large hole in the middle of her lower lip, with the lower lip stretched into a thin, taut ring of real lip flesh that wraps the whole plate and holds it from all sides, in her natural lip colour, clearly different from the dark metal. The lip with the plate hangs down in front of her chin, tilted slightly outward, while her upper lip, her teeth line and the corners of her mouth stay fully bare and visible above it. The face is seen at a slight three-quarter angle so the ring of lip flesh around the plate is clearly visible. Nothing hangs from the plate. "+SK+END+SAFE)
V=[("E — 구조를 구체적으로(고무줄 같은 입술 고리)",E_),("F — 전통 립 플레이트 이름으로 지칭 + 3/4 각도",F_)]
NA=[("한국","20대","도도한"),("일본","20대","군림하는")]
o=["# LumineX — 립 플레이트 v3 (추 없음) 2개: 구멍과 입술 고리를 구체적으로\n","- E는 '입술이 고무줄처럼 얇은 고리가 되어 구멍을 감쌈, 바깥에서 안으로 턱→입술 고리→금속판' 순서로 구조를 설명. F는 전통 립 플레이트로 지칭하고 3/4 각도.","- 정상/이상(+ 입술이 구멍을 감싼 표현인지)만 번호로 알려주세요.\n"]
for i,((lab,pp),(nat,grp,ex)) in enumerate(zip(V,NA),1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(65000+i*100+tr),nat,grp,ex,style="NONE",slots=["pierce"],pier_level="P3"); break
        except AssertionError: continue
    else: raise SystemExit(i)
    old=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    t=re.sub(r'\n\nJewelry:[^\n]*','',t.replace(old,pp))
    assert not re.search(r"[가-힣]",t)
    o.append(f"## {lab} — {title}\n\n```\n{t}\n```\n")
open('/mnt/user-data/outputs/LumineX_LipPlate_v3_2.md','w',encoding='utf-8').write("\n".join(o)); print("ok")
