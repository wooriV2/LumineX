import re,random
src=open('mk_group5.py',encoding='utf-8').read()
exec(src[:src.index("R=_r.Random(20261013)")])
GROUP=dict(globals())
ns2={}
g=open('gen_fs2.py',encoding='utf-8').read()
exec(compile(g[:g.index('if __name__=="__main__":')],'gfs2','exec'),ns2)
m=open('mk_group4.py',encoding='utf-8').read()
exec(m[m.index('END="'):m.index('TEXT.update')],ns2)
ns2['tusk_flag']=False
cjk=open('cjk_face_lib.py',encoding='utf-8').read()
HAIRS=sorted(set(re.findall(r'"((?:[^"]*?(?:hair|bob|bun|waves|lob|ponytail|braid|bangs|updo|twin|pigtail)[^"]*?))"',cjk)),key=len,reverse=True)
SILV=["long silver-white hair in soft waves swept to one side","a sleek silver-grey bob with soft layers","a polished silver low bun with a few loose strands","long straight silver hair with a side part"]
AGE_RE=re.compile(r"\b(?:early|mid|late) (?:20s|30s)\b")
LEVELS=[("아이돌",["early 20s"],False),("20대 후반",["late 20s"],False),("30대 후반",["late 30s"],False),("실버폭스",["early 40s","mid 40s","late 40s","early 50s"],True)]
def pick_age(R):
    lab,ages,silver=R.choice(LEVELS); return lab,R.choice(ages),silver
def set_age(p,age,silver,R,arch=False):
    p=AGE_RE.sub(age,p); p=re.sub(r"\b(?:Early|Mid|Late) (?:20s|30s)\.",age.capitalize()+".",p)
    if silver and not arch:
        for h in HAIRS:
            if h in p: p=p.replace(h,R.choice(SILV),1); break
    return p
R=random.Random(20261016)
TEXT_E={n:t for n,t,c in ns2['EYE2']}; TEXT_L={n:t for n,t,c in ns2['LIP']}; TEXT_L.update(ns2['NEWLIP']); ARCHF={n:f for n,f,c in ns2['ARCH']}
o=["# LumineX — 전 연령대 혼합 시험 3개 (솔로 1 · 트리오 1 · 4인 1)\n","- 연령 축 4단계(아이돌 · 20대 후반 · 30대 후반 · 실버폭스)를 같은 비율로 랜덤. 실버폭스는 40대 초반~50대 초반 중 하나에 은발(눈·입술 인물), 유형(바비·서큐버스 등)은 정체성인 머리·외형을 유지. 프롬프트에 문장 추가 없음(나이 숫자·머리색만 교체).","- 그룹은 인물마다 나이를 따로 뽑아 한 장면에 여러 연령이 섞입니다.","- 정상/이상 번호만, 가능하면 연령이 섞여 보이는지 한 줄만 알려주세요.\n"]
# solo
kind=R.choices(["eye","lip","arch"],[40,40,20])[0]
pool={"eye":[(n,c) for n,t,c in ns2['EYE2']],"lip":[(n,c) for n,t,c in ns2['LIP']]+list({"덕 립 극한":9,"드롭 립 극한":9,"바르도 립 극한":9,"와이드 립 극한":9,"오 립 극한":8,"고양이 입 극한":8}.items()),"arch":[(n,c) for n,f,c in ns2['ARCH']]}[kind]
name=R.choices([p[0] for p in pool],[p[1] for p in pool])[0]
it=ns2['build2'](1,kind,name,(ARCHF[name] if kind=="arch" else (TEXT_E if kind=="eye" else TEXT_L)[name]),R)
lab,age,silver=pick_age(R)
t=set_age(it["prompt"],age,silver,R,arch=(kind=="arch")); assert not re.search(r"[가-힣]",t)
o.append(f"## 1. 솔로 · {name} · {lab}({age}{', 은발' if silver and kind!='arch' else ''}) · {it['title']}\n\n```\n{t}\n```\n"); print(1,len(t.split()),lab,age)
for idx,n in ((2,3),(3,4)):
    G3=GROUP['group3']
    while True:
        spec=GROUP['draw_spec'](R,n)
        ear=R.choices(["iron","mix","one","earring"],[25,35,15,15])[0]; h=R.choices([1,2,3],[75,161,64])[0]; bg=R.choice(GROUP['BGN'])
        haslip=any(k=="lip" for k,_ in spec)
        mode="q45" if (n==4 and haslip and R.random()<0.5) else "front"
        for tr in range(300):
            try: tx,labs,dup=G3(R.randrange(10**7),spec,mode,ear,h,bg)
            except AssertionError: continue
            mk=[l.split(" · ")[4] for l in labs if "유형 고유 메이크업" not in l]
            if len(set(mk))<len(mk) or sum(x=="메이크업 없음" for x in mk)>1: continue
            if dup and dup.split()[0].lower() not in("had","that"): continue
            break
        else: continue
        break
    ages=[pick_age(R) for _ in range(n)]
    paras=tx.split("\n\n"); outp=[]
    for p in paras:
        mm=re.match(r"#(\d+): ",p)
        if mm:
            j=int(mm.group(1))-1; lab_,age_,silver_=ages[j]
            p=set_age(p,age_,silver_,R,arch=("A striking adult" not in p))
        outp.append(p)
    tx="\n\n".join(outp); assert not re.search(r"[가-힣]",tx)
    earlab={"iron":"철 추","mix":"혼합 금속 추","one":"단일 금속 추","earring":"대형 귀걸이"}[ear]
    o.append(f"## {idx}. {n}인 · "+" + ".join(nm for k,nm in spec)+(" (45도)" if mode!="front" else " (정면)")+f" · {earlab}"+("" if ear=="earring" else f" · 귀 구멍 {h}개")+f" · 배경 {bg}")
    for j,l in enumerate(labs,1):
        la,ag,sv=ages[j-1]; o.append(f"- #{j}: {la}({ag}{', 은발' if sv and 'A striking adult' in paras[1+2*j-2] else ''}) · {l}")
    o.append("\n```\n"+tx+"\n```\n"); print(idx,len(tx.split()),[(a[0],a[1]) for a in ages])
open(OUT+'LumineX_MixedAge_3.md','w',encoding='utf-8').write("\n".join(o))
