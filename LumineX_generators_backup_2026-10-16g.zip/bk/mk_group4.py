import re,random
s=open('mk_group2.py',encoding='utf-8').read()
exec(s[:s.index('CFG=[')])           # person(), TEXT, HW2, COL2 ... (original group() is replaced below)
exec(open('ear_styles.py',encoding='utf-8').read())   # METALS, SHAPES, FORMS, FORMLAB, SEG_OLD
# ---- canthus fixes (same as the single-cut bundle)
LINER_RE=re.compile(r"a razor-sharp black (?:eyeliner|liner) follows the (?:whole extended|entire) shape and ends in ([^;]*);")
COLOUR_RE=re.compile(r"a razor-sharp eyeliner in the colour of her makeup follows the entire shape and ends in [^;]*;")
PLAIN="the outline of each eye is crisp and clean, defined only by her natural dark lashes and the edge of her lids, with no eyeshadow and no eyeliner;"
INNER6="the inner corners are cut open far toward the bridge of her nose, the small pink inner corners reaching almost to the sides of her nose bridge,"
INNER8="the inner corners are cut open so far that they almost meet at the root of her nose, the small pink inner corners clearly visible on either side of the nose bridge,"
INNEW="the inner corners are fully opened with the small pink inner corners clearly visible,"
for n in list(TEXT):
    if "트임" in n:
        t=TEXT[n]; assert LINER_RE.search(t),n
        t=LINER_RE.sub(lambda m:"a razor-sharp eyeliner in the colour of her makeup follows the entire shape and ends in "+m.group(1)+";",t)
        if n.startswith("양쪽 트임 6배"): assert INNER6 in t; t=t.replace(INNER6,INNEW)
        if n.startswith("양쪽 트임 8배"): assert INNER8 in t; t=t.replace(INNER8,INNEW)
        TEXT[n]=t
A_OLD="two separate large healed openings in the earlobe, one below the other with a clear gap of bare skin between them, each opening holding its own very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel,"
A_NEW={1:"one large healed opening in the earlobe holding a very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel,",
       3:"three separate large healed openings in the earlobe, one below another with a clear gap of bare skin between each, each opening holding its own very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel,"}
LOBE_RE=re.compile(r"Because the load is shared between two openings, each earlobe is stretched[^;]*; no lobe sags, droops, collapses or hangs down to the shoulder, every head stays upright, and")
LOBE={1:"Because all the load is carried by one opening, the weight gently pulls each earlobe down a little into a slightly elongated, soft, healthy loop of skin, only a small natural droop that is just enough to show how heavy the weights are; no lobe stretches long, tears or collapses or hangs down to the neck or shoulder, every head stays upright, and",
      2:"Because the load is shared between two openings, the weight gently pulls each earlobe down a little into a slightly elongated, soft, healthy loop of skin, only a small natural droop that is just enough to show how heavy the weights are; no lobe stretches long, tears or collapses or hangs down to the neck or shoulder, every head stays upright, and",
      3:"Because the load is shared between three openings, the weight pulls each earlobe down only very slightly into a soft, healthy loop of skin, a barely noticeable natural droop that is just enough to show the weights are heavy; no lobe stretches long, tears or collapses or hangs down to the neck or shoulder, every head stays upright, and"}
COLS_RE=re.compile(r"On each ear of every woman the two iron rings each carry their own column of weights, the two columns holding [^,]*? weights, hanging side by side")
def ear_person(p,mode,h,fa,rr):
    """personal piercing paragraph"""
    if mode in("iron","mix","one"):
        assert A_OLD in p
        if h!=2: p=p.replace(A_OLD,A_NEW[h])
        if h==1: p=p.replace("and above them sit","and above it sit")
        if h==1: p=p.replace("these two iron rings","this iron ring")
        if h==3: p=p.replace("these two iron rings","these three iron rings")
        if mode=="mix": p=p.replace("separate massive solid weights, each of a different shape:","separate massive solid weights, each of a different shape and a different metal:")
        p=p.replace("as big as a fist or larger","at least as big as her whole fist and clearly larger than her earlobe")
    else:
        assert SEG_OLD in p
        p=p.replace(SEG_OLD,f"the lower opening holding {FORMS[fa]}, and the upper opening holding a large classic round hoop earring")
        p=p.replace("(not counting the hanging weights)","(not counting the hanging drops)")
        k="All the ear weights hang from the bottoms of these two iron rings"
        if k in p: p=p[:p.index(k)].rstrip()
    return p
def share_ear(share_w,nw,mode,h,rr):
    assert LOBE_RE.search(share_w), share_w[-700:]
    w=LOBE_RE.sub(LOBE[h],share_w)
    if h==1:
        w,n=COLS_RE.subn("On each ear of every woman the single iron ring carries all the weights, hanging in a staggered cluster",w); assert n==1
    elif h==3:
        w,n=COLS_RE.subn("On each ear of every woman the three iron rings share the weights between them in uneven numbers, each ring carrying its own column of weights, hanging side by side",w); assert n==1
    w=w.replace("as big as a fist or larger","at least as big as her whole fist and clearly larger than her earlobe")
    k="reaching down along the neck to the collarbones"; assert k in w
    w=w.replace(k,"hanging freely in the air, clear of the neck and shoulders, with even the longest chain and its weight ending no lower than the level of the collarbones")
    if mode in("mix","one"):
        if mode=="mix":
            met="rough, matte, unpolished heavy metal in mixed materials, each weight a different shape and each in a different metal among gold, bronze, iron, tin, brass, silver, copper and lead"
        else:
            m=rr.choice(list(METALS)); met="rough, matte, unpolished "+METALS[m][1]+", each weight a different shape"
        k2="an enormous, dense, completely solid, squat, blunt lump of rough black cast iron"; assert k2 in w
        w=w.replace(k2,"a massive, dense, solid lump of "+met)
        k3="each weight on its own thick chain of heavy black iron links"; assert k3 in w
        w=w.replace(k3,"each weight on its own thick heavy chain of the same metal as the weight")
    return w
BGSG=[b for b in [("순흑 기본",None),
("스튜디오 짙은 남색","A plain seamless deep midnight-navy backdrop, nothing else in frame, no texture, no gradient. The background colours are cool, mid-to-dark tones clearly different from their skin tones, never beige, peach, orange or brown, and never bright."),
("스튜디오 짙은 청록","A plain seamless deep teal backdrop, nothing else in frame, no texture, no gradient. The background colours are cool, mid-to-dark tones clearly different from their skin tones, never beige, peach, orange or brown, and never bright."),
("실내 청록 벨벳 라운지","The background is a dim lounge with deep teal velvet walls and a few soft blurred lamps in muted blue-green, out of focus with a shallow depth of field, with no objects and no other people in the background, and the background is darker and softer than their faces so that their faces and the metal are the brightest, sharpest part of the image. The background colours are cool, mid-to-dark tones clearly different from their skin tones, never beige, peach, orange or brown, and never bright."),
("실외 푸른 시간대 호숫가","The background is a lakeside at blue hour, a blurred dark navy lake and distant hills under a deep indigo sky, out of focus with a shallow depth of field, with no objects and no other people in the background, and the background is darker and softer than their faces so that their faces and the metal are the brightest, sharpest part of the image. The background colours are cool, mid-to-dark tones clearly different from their skin tones, never beige, peach, orange or brown, and never bright."),
("실외 비 오는 밤 청록·남색 네온","The background is a city street at night in the rain, blurred neon signs and car lights in teal and deep blue, out of focus with a shallow depth of field, with no objects and no other people in the background, and the background is darker and softer than their faces so that their faces and the metal are the brightest, sharpest part of the image. The background colours are cool, mid-to-dark tones clearly different from their skin tones, never beige, peach, orange or brown, and never bright."),
("실외 안개 낀 숲","The background is a misty forest at dusk, soft blurred dark-green trees fading into pale fog, out of focus with a shallow depth of field, with no objects and no other people in the background, and the background is darker and softer than their faces so that their faces and the metal are the brightest, sharpest part of the image. The background colours are cool, mid-to-dark tones clearly different from their skin tones, never beige, peach, orange or brown, and never bright.")] ]
BGD=dict(BGSG)
def group3(seed,spec,mode,ear,h,bgname):
    rr=random.Random(seed); n=len(spec); nw=6 if n==2 else 4; NP=12 if n==2 else 10
    nats=rr.sample(list(G.NATS),n); subs=[];prs=[];labs=[]
    fas=rr.sample(range(len(FORMS)),n)
    for (kind,name),nat,fa in zip(spec,nats,fas):
        for tr in range(60):
            try:
                s_,p,l=person(random.Random(rr.randrange(10**9)),nat,kind,name,nw,NP)
                if "트임" in name and "메이크업 없음" in l:
                    s_,c=COLOUR_RE.subn(PLAIN,s_); s_=s_.replace("while the colours of her eyeshadow and liner follow her makeup","and she wears no eyeshadow and no eyeliner at all")
                p=ear_person(p,ear,h,fa,rr)
                if ear!="earring": l=l.replace("2구멍",f"{h}구멍")
                else: l=re.sub(r"귀 추 \d+개/귀 2구멍","대형 귀걸이 "+FORMLAB[fa],l)
            except AssertionError: continue
            if re.search(r"[가-힣]",s_+p) or "{" in s_+p: continue
            break
        else: raise SystemExit(("fail",name))
        if mode=="front": s_=s_.replace("in this three-quarter view","in this frontal view")
        subs.append(s_);prs.append(p);labs.append(l)
    cnt={2:"TWO",3:"THREE"}[n]; tw={2:"both",3:"all three"}[n]
    hang="the long earrings" if ear=="earring" else "the weights"
    if mode=="front":
        hd=f"Professional fashion photograph, close-up beauty portrait. {cnt} women standing close together, shoulders touching, each facing the camera straight on in a perfectly frontal portrait, heads level, both ears of every woman clearly visible on either side of her face, framed tightly from the very top of their heads down to the line of their shoulders, the frame cutting off just below them, so {hang} fully hang in view. Every face is large and sharp. All of them stand together in one single shared scene, in one row in front of the same continuous background, and this is one single photograph taken with one camera at one moment, not a collage: the women overlap slightly in depth and the background runs unbroken behind all of them."
        lit="A soft frontal light on all the faces and ears, so the makeup and the glints on every piece of metal read clearly"
    else:
        hd=f"Professional fashion photograph, close-up beauty portrait. {cnt} women standing close together, shoulders touching, {tw} with their heads turned about forty-five degrees to their left in a three-quarter view, their eyes still looking straight into the camera, one ear and the turned cheek of every woman clearly visible, and from this angle the full projection of every woman's lips from her face is clearly visible, framed tightly from the very top of their heads down to the line of their shoulders, the frame cutting off just below them, so {hang} fully hang in view. Every face is large and sharp. All of them stand together in one single shared scene, in one row in front of the same continuous background, and this is one single photograph taken with one camera at one moment, not a collage: the women overlap slightly in depth and the background runs unbroken behind all of them."
        lit="A soft key light from the front and slightly to the side on all the faces, so the makeup and the glints on every piece of metal read clearly"
    body=[]
    for i,(s_,p) in enumerate(zip(subs,prs),1):
        body.append(f"#{i}: {s_}"); body.append(f"#{i} {p}")
    if ear=="earring":
        earp="Earrings: each woman's large earrings hang freely in the air down to the level of her collarbone and no lower, and no earring of one woman hangs in front of another woman's face."
    else:
        share_w=HW2.format(col=COL2[nw]).replace("On each ear the two iron rings each carry","On each ear of every woman the two iron rings each carry")
        for a,b in [("hanging side by side on chains of different lengths","hanging side by side, each weight on its own thick chain of heavy black iron links, the chains of different lengths"),("reaching down along her neck to her collarbones","reaching down along the neck to the collarbones"),("hangs just past her jaw; the lobe does not sag, droop, collapse or hang down to her shoulder, her head stays upright, and","hangs just past the jaw; no lobe sags, droops, collapses or hangs down to the shoulder, every head stays upright, and")]:
            assert a in share_w,a; share_w=share_w.replace(a,b)
        earp="Ear weights: "+share_ear(share_w,nw,ear,h,rr)
    ratio={2:"4:3 horizontal",3:"3:2 horizontal"}[n]
    depth="Piercing depth: every bar is embedded in the skin so only its two end studs show on the surface; every ring passes through a small healed opening in the skin, the skin visible through the loop, and every stud sits through the skin with its back hidden, all of them passing through the real tissue with the skin wrapping snugly around them."
    bgt=BGD[bgname]
    if bgt is None:
        pose_bg="They all share one single continuous pitch-black background behind them, with no separate panels, no split screen, no borders and no different backgrounds behind different women."
        light_bg="MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient."
    else:
        pose_bg="They all share one single continuous background behind them, the same one for all of them, with no separate panels, no split screen, no borders and no different backgrounds behind different women."
        light_bg=bgt
    pend="the hanging pieces of one never hang" if ear=="earring" else "the weights of one never hang"
    parts=[hd]+body+[earp,
      "All piercings: Each woman wears only the piercings named in her own paragraph, in those places and nowhere else; on every woman the eyes, eyelids and eyebrows stay completely clear. All jewelry is real metal, sitting in real, calm, healthy skin — no redness, no swelling, no irritation — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes.",
      depth,
      "Hair: every woman's hair is swept back behind both ears, leaving both ears, jawlines and necks fully visible so every hanging piece is in clear view.",
      f"Pose: each woman stands upright, arms relaxed at her sides, heads level, shoulder to shoulder and close enough that their shoulders and upper arms touch or slightly overlap in depth, leaning very slightly toward each other, so that {pend} in front of another and each woman's hanging pieces stay in front of her own shoulder. {pose_bg} There is no dividing line between the women, and no different light, colour or background on different women.",
      f"Lighting: {light_bg} One single light setup lights everyone from the same direction with the same colour, so the shadows and highlights match on every woman. {lit}; a thin cool rim light along the hair and shoulders. {ratio} 8K."]
    t="\n\n".join(parts); t=re.sub(r"catching the light\s+Her face","catching the light. Her face",t); t=re.sub(r"  +"," ",t)
    assert not re.search(r"[가-힣]",t) and "{" not in t
    assert not re.search(r"two iron rings|two openings|two columns",t) or h==2
    d=re.search(r"\b(\w+) \1\b",t)
    return t,labs,(d.group(0) if d else None)

END=", every edge razor-crisp, perfectly symmetrical, so that the lips are by far the dominant feature of her face in this three-quarter view, still reading as a beautiful, believable human face, never smudged past the lip line"
NEWLIP={
"덕 립 극한":"the absolute extreme of a 'duck lip' pout: the upper lip lifted high and thrust far forward and upward like the bill of a duck, a plump, broad, glossy ledge that juts dramatically out from her face, the lower lip a full rounded cushion tucked beneath it and pushed forward to meet it, the whole mouth pursed into a bold beak-like pout whose projection from the face is enormous, mirror-glossy deep rose with bright white highlights on both lips"+END,
"드롭 립 극한":"the absolute extreme of a 'drop lip': a lower lip that is enormous, heavy and pendulous, hanging like a giant glossy tear drop, three times as full as her slim, sharply drawn upper lip, so that the lower lip fills most of the height of the mouth and projects far forward, its dome catching a huge bright white highlight, the upper lip a slim precise bow resting on top of it, mirror-glossy deep rose"+END,
"바르도 립 극한":"the absolute extreme of a 'Bardot pout': an upper lip that is huge, puffy and pillow-like, twice as thick as the lower lip, swelling far forward and upward and overhanging the slimmer, flatter lower lip tucked beneath it, its two soft rounded peaks plump as small cushions, the whole pout projecting far forward from her face, mirror-glossy deep rose with bright white highlights on the upper lip"+END,
"와이드 립 극한":"the absolute extreme of a 'wide mouth': a mouth so wide that its corners stretch out to the line below the outer corners of her eyes, spanning almost the full width of her lower face, the lips long, full and generously plump, a smooth, long, perfectly drawn horizontal mouth with a gently curved upper lip line, mirror-glossy deep rose with bright white highlights along both lips"+END.replace("in this three-quarter view","in this view"),
"오 립 극한":"the absolute extreme of an 'O lip': a tiny, perfectly round, doll-like mouth, the lips gathered and pursed forward into a small plump circle as if about to say 'oo', a thick glossy rim of lip around a small round centre, pushed out from her face, the corners of the mouth drawn right in so the mouth is small and neat, mirror-glossy deep rose with bright white highlights on the rim"+END.replace("in this three-quarter view","in this view"),
"고양이 입 극한":"the absolute extreme of 'cat lips': the upper lip forms a bold, deeply curved omega, two high, plump, rounded humps curling up on either side and meeting in a sharp, deep notch down the centre, the corners of the mouth tucked in and turned slightly up like a cat's, below it a small, neat, plump lower lip, mirror-glossy deep rose with bright white highlights on the two humps"+END.replace("in this three-quarter view","in this view"),
}
TEXT.update(NEWLIP)
BGN=[n for n,_ in BGSG] if isinstance(BGSG,list) else list(BGSG)
import random as _r
R=_r.Random(20261013)
SPECS=[("A",[("lip","덕 립 극한"),("lip","드롭 립 극한"),("lip","바르도 립 극한")],"q45"),
       ("B",[("lip","와이드 립 극한"),("lip","오 립 극한"),("lip","고양이 입 극한")],"front")]
o=["# LumineX — 입술 모양 신규 6종 극단 표현 · 3인 풀 프롬프트 2장\n",
"- A장(45도): 덕 립 · 드롭 립 · 바르도 립 (돌출·부피가 윤곽을 만드는 3종). B장(정면): 와이드 립 · 오 립 · 고양이 입 (폭·작기·윗입술 곡선이 윤곽을 만드는 3종).",
"- 귀 스타일·구멍 수(1~3)·배경은 번들과 같은 확률로 랜덤 추첨, 메이크업은 3명이 서로 다르게(메이크업 없음은 최대 1명). 한 공간·한 장 사진 문구는 그대로.",
"- 정상/이상은 인물 번호(A-1 ~ B-3)로 알려주세요.\n"]
for tag,spec,mode in SPECS:
    ear=R.choices(["iron","mix","one","earring"],[25,35,15,15])[0]; h=R.choice([1,2,2,3]); bg=R.choice(BGN)
    for tr in range(200):
        try: t,labs,dup=group3(R.randrange(10**6),spec,mode,ear,h,bg)
        except AssertionError: continue
        mk=[l.split(" · ")[4] for l in labs]
        if len(set(mk))<3 or sum(m=="메이크업 없음" for m in mk)>1: continue
        if dup and dup.split()[0].lower() not in("had","that"): continue
        break
    else: raise SystemExit("fail "+tag)
    earlab={"iron":"철 추","mix":"혼합 금속 추","one":"단일 금속 추","earring":"대형 귀걸이"}[ear]
    o.append(f"## {tag}장 · 트리오 · "+" + ".join(n for k,n in spec)+(" (45도)" if mode!="front" else " (정면)")+f" · {earlab}"+("" if ear=="earring" else f" · 귀 구멍 {h}개")+f" · 배경 {bg}")
    for j,l in enumerate(labs,1): o.append(f"- {tag}-{j}: {l}")
    o.append("\n```\n"+t+"\n```\n"); print(tag,len(t.split()),ear,h,bg)
open(OUT+'LumineX_LipShapes_New6_Trio_2.md','w',encoding='utf-8').write("\n".join(o))
