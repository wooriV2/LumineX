import re,random
exec(open('new_lib.py',encoding='utf-8').read())
FORE_PEND="A forehead pendant: a fine gold chain runs along the centre parting of her hair and ends in a teardrop gem pendant resting at the middle of her forehead."
NOSE_EAR="A nose-to-ear chain: a fine chain swags from the ring on her left nostril wing across the cheek, well below the eye and clear of the lips, up to a hook at the top of her left ear."
BEADS="A forehead bead band: a row of large turquoise and coral beads is strung across the top of her forehead along the hairline like a headband, with a round ornament set with a large gem at its centre."
def subj(t): return [x for x in t.split("\n\n") if x.startswith("Subject:")][0]
def subj_add(t,txt):
    s=subj(t); k=" Her whole face, ears and neck are real living flesh"; assert k in s
    return t.replace(s,s.replace(k," "+txt+k,1))
def slots(t,txts):
    k="The left and right sides are balanced."; assert k in t
    return t.replace(k," ".join(txts)+" "+k,1)
def skin(t,txt):
    s=subj(t); s2,n=re.subn(r"adult (Korean|Chinese|Japanese) woman — .*?, (early|mid|late) (\d0s)",lambda m:f"adult woman — {txt}, {m.group(2)} {m.group(3)}",s,count=1); assert n==1
    return t.replace(s,s2)
def light(t,bg,key,rim):
    a="MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient."
    assert a in t; t=t.replace(a,bg)
    b="A soft frontal light on her face and ears, so the glints on every piece of metal read clearly against her skin; a thin cool rim light along the hair and shoulders."
    assert b in t; return t.replace(b,key+" "+rim)
def finish(t,mode,nw,rr,lab,force=None):
    global FORCE
    FORCE=force
    return apply_ear(t,mode,nw,random.Random(rr.randrange(10**9)),w,HW2,COL2,None,lab)

THEMES["bright"]=("Every piece on her face is bright and light-coloured, so that it gleams clearly against her deep skin: small polished gold and mirror-silver studs, rings and bars, and tiny clear diamonds and pearls.","The face and ear jewelry is real polished bright yellow gold and mirror silver set with clear diamonds, white pearls and icy pale gems, every piece light and gleaming","밝은 금속·보석")
METALS0=dict(METALS)
BRIGHT={"gold":("polished bright yellow gold with a hammered, gleaming surface","gold"),"silver":("bright polished mirror silver with a gleaming hammered surface","silver"),"tin":("bright polished chrome-silver with a gleaming hammered surface","tin"),"brass":("bright polished golden brass with a gleaming surface","brass")}
def brighten(t):
    t=t.replace("rough and matte and unpolished with no shine","bright, polished and gleaming")
    t=t.replace("rough, matte, unpolished heavy metal in mixed materials (lead, tin, gold, silver, bronze, copper, brass and iron)","bright polished heavy metal in mixed materials (gold, silver, chrome-silver and brass)")
    t=t.replace("rough, matte, unpolished ","bright, polished ")
    t=t.replace("black cast-iron","bright polished gold").replace("black cast iron","bright polished gold").replace("blackened steel","polished bright silver").replace("heavy black iron links","heavy bright metal links")
    t=re.sub(r"\biron (rings?)\b",r"gold \1",t)
    return t
rr=random.Random(9191)
OUTS=[]
def make(title,N,zero,minimal,mode,build_fn=None,force=None,expr0=None,theme=None,style0=None,bright=False):
    global METALS
    for tr in range(100):
        r2=random.Random(rr.randrange(10**9))
        try:
            nw=r2.choice([8,9,10]); deco=r2.choice(["",HENNA,STICK,BOTH])
            t,lab,lt,nw=base(r2,N,zero,minimal,deco,nw,theme=theme,expr0=expr0,style0=style0)
            if build_fn: t=build_fn(t)
            if bright: METALS=BRIGHT
            try: t,lab2=finish(t,mode,nw,r2,lab+f" · 귀 추 {nw}개/귀 2구멍",force)
            finally: METALS=METALS0
            if bright: t=brighten(t)
        except AssertionError as e: continue
        if re.search(r"[가-힣]",t) or (re.search(r"\b(\w+) \1\b",t) and re.search(r"\b(\w+) \1\b",t).group(1).lower() not in("had","that")): continue
        if bright and re.search(r"blackened|black cast|bronze|copper|\blead\b|\biron\b|pitted|tarnished|dark (silver|brass)",t): continue
        OUTS.append((title+" · "+lab2+(" · "+lt if lt else ""),t)); print(len(OUTS),len(t.split())); return
    raise SystemExit(("fail",title))
Z=("tmp","brow","bri")
BW="She has no eyebrows at all: "
make("피부톤 · 블루블랙 + 밝은 금속·보석",50,Z,False,"mix",lambda t:skin(t,"THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky with a soft healthy sheen"),style0="NONE",theme="bright",bright=True)
make("피부톤 · 에보니 브라운 + 밝은 금속·보석 + 대형 귀걸이",50,Z,False,"earring",lambda t:skin(t,"deep ebony-brown skin with a rich warm undertone and a healthy glossy sheen"),style0="NONE",theme="bright",bright=True)
make("눈썹 · 없음 + 헤나 문양",25,Z,False,"mix",lambda t:subj_add(t,BW+"her brow bones are bare skin, painted in place of brows with a delicate reddish-brown henna pattern of tiny curling vines and dots following the line of each brow."))
make("눈썹 · 없음 + 스터드 줄",25,Z,False,"iron",lambda t:subj_add(t,BW+"her brow bones are bare skin, with a neat row of eight tiny polished silver studs set into the skin along each brow bone where the brows would be."))
make("눈썹 · 없음 + 눈썹뼈 바 피어싱",25,Z,False,"mix",lambda t:subj_add(t,BW+"her brow bones are smooth bare skin, with two small curved silver barbells passing through the outer part of each brow bone, only their two end balls showing on the surface, kept well away from her eyes."))
make("눈썹 · 없음 + 맨살(모나리자)",25,Z,False,"iron",lambda t:subj_add(t,BW+"her brow bones are completely smooth, bare, clean skin with no hair, no drawing and no ornament, like the face of the Mona Lisa, so the whole attention rests on her eyes."))
def bg(t,desc,key,rim):
    return light(t,"The background is "+desc+", out of focus with a shallow depth of field, with no objects and no people in the background, and the background is darker and softer than her face so that her face and the metal are the brightest, sharpest part of the image.",key,rim)
make("배경 · 실내 창가 자연광 방",25,Z,False,"mix",lambda t:bg(t,"a quiet room beside a tall window, with soft pale daylight falling through the window and a warm blurred wall behind her","A soft window daylight on her face and ears, so the glints on every piece of metal read clearly against her skin;","a gentle warm glow along the hair and shoulders."))
make("배경 · 실내 따뜻한 카페 보케",25,Z,False,"earring",lambda t:bg(t,"the warm interior of a dim cafe, a wash of golden bokeh lights","A soft warm frontal light on her face and ears, so the glints on every piece of metal read clearly against her skin;","a thin amber rim light along the hair and shoulders."),force=4)
make("배경 · 실외 해 질 녘 해변",25,Z,False,"iron",lambda t:bg(t,"a beach at sunset, a blurred band of sea and a low orange-pink sky","A soft warm frontal light on her face and ears, so the glints on every piece of metal read clearly against her skin;","a thin golden sunset rim light along the hair and shoulders."))
make("배경 · 실외 비 오는 밤 도시 네온",25,Z,False,"mix",lambda t:bg(t,"a city street at night in the rain, blurred neon signs and car lights in pink and blue","A soft frontal light on her face and ears, so the glints on every piece of metal read clearly against her skin;","a thin pink and blue neon rim light along the hair and shoulders."))
make("배경 · 실외 안개 낀 숲",25,Z,False,"one",lambda t:bg(t,"a misty forest at dusk, soft blurred dark-green trees fading into pale fog","A soft cool frontal light on her face and ears, so the glints on every piece of metal read clearly against her skin;","a thin pale cool rim light along the hair and shoulders."))
o=["# LumineX — 새 축 시험 샘플 파일 3 (10개)\n","- 1~2 어두운 피부톤 + 밝은 금속·보석 연동, 3~6 눈썹 없음 + 대체재(헤나·스터드 줄·눈썹뼈 바·맨살), 7~10 실내·실외 아웃포커스 배경(창가 방·카페·해변·비 오는 밤 도시·안개 숲)입니다.","- 정상/이상 번호만 알려주세요.\n"]
for i,(title,p) in enumerate(OUTS,1): o.append(f"## {i}. {title}\n\n```\n{p}\n```\n")
open(OUT+'LumineX_NewAxes_Test_File3.md','w',encoding='utf-8').write("\n".join(o))
