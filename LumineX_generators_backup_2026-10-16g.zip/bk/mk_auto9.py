# -*- coding: utf-8 -*-
import re, random, sys
_s = open("mk_doll3.py", encoding="utf-8").read()
exec(_s[:_s.index("rg = random.Random(")])
rg = random.Random(int(sys.argv[1]) if len(sys.argv) > 1 else 20261024)
AUTO = [
 V("brass", "polished brass clockwork automaton", "polished brass", "brass",
   "BLAZING warm polished brass plates across the full torso both legs neck to ankle",
   "VIVID silver gears with large ruby bearings at their centres turning inside the cut-out window, deep blue-green verdigris joints standing out sharply against the brass, a small brass wind-up key turning slowly at her side", "bright polished", "황동 오토마톤"),
 V("porcelain", "white porcelain automaton with gold gears", "glazed porcelain", "glazed porcelain",
   "BLAZING glossy white porcelain plates painted with fine blue flowers across the full torso both legs neck to ankle",
   "VIVID gold gears with large gold bearings at their centres turning inside the cut-out window, copper-red joints standing out sharply against the white, a small gold wind-up key turning slowly at her side", "high-gloss glazed", "도자기 오토마톤"),
 V("enamel", "black enamel automaton with silver gears", "black enamel", "black enamel",
   "BLAZING mirror-black enamel plates inlaid with silver filigree across the full torso both legs neck to ankle",
   "VIVID silver gears with large white pearl bearings at their centres turning inside the cut-out window, bright gold joints standing out sharply against the black, a small silver wind-up key turning slowly at her side", "mirror-gloss enamelled", "흑칠 오토마톤"),
]

_jw0 = ns2["jewel"]
ns2["jewel"] = lambda p: _jw0(p).replace("a small pendant at her navel", "a small pendant resting on her belly plate")
NEWV["auto"] = AUTO
_prev2 = person_nv
def person_nv(label, key, phys, age, pose, eth):
    if key != "auto": return _prev2(label, key, phys, age, pose, eth)
    nm, desc, solid, nmw, base, acc, fin, tag = CUR_VAR[(label, key)]
    pn, pd = phys; p = f"{label}: " if label else ""
    mat = (f"full body {desc} body fused directly to her own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, this is a solid {solid} automaton body curving to follow her body's true three-dimensional shape, divided into fitted {nm} plates, with one huge round cut-out window across her chest and belly as wide as her whole torso, showing a dense tangle of meshing gears of many sizes packed edge to edge inside a deep hollow cavity lit from within by a soft warm glow, stacked in layers at different depths with light pale-gold gaps between the layers so every gear on every layer is clearly visible, one giant gear as wide as her ribcage surrounded by medium and small gears, coiled springs and steel shafts, all turning together, and at her neck, shoulders, elbows, wrists, hips, knees and ankles every plate ends in a round exposed hinge joint with a thin dark gap and its own small shadow, nothing lying flat. Dense fitted plates — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    feat, seg, info = face(eth); skin = eth[1]
    hl = HEEL_ if HEELMODE[0] == "forty" else HEEL_REL
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of the same {nmw}, each with {hl}, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, made of the same {nmw} with a high polish."
    fc = f"{p}Face: her face and ears are NOT part of the automaton body — they are real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair()} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    return "\n".join([body, shoe, nails, jw, fc]), info
def chk(t): return not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t)
# ---- 오토마톤 3
o1 = ["# 오토마톤 밝은 속 3개 — 황동 · 도자기 · 흑칠 (창 안이 깊고 밝아서 모든 기어가 보임)\n", "Material Mix와 같은 기본 랜덤입니다(관절은 몸과 대비색). 번호별로 정상/이상만 알려주세요. 이상이면 한 줄만요.\n"]
for i, v in enumerate(AUTO, 1):
    for _ in range(300):
        physs = [rg.choices(BIG5, W5)[0]]; CUR_VAR.clear(); CUR_VAR[(None, "auto")] = v
        ages = [rg.choice(AGES)]; poses = [rg.choice(POSES)]; eths = rg.sample(ETH, 1)
        bid, wx = BGL.pick(rg, 1); scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
        ns2["JR"].seed(rg.randrange(10**9))
        t, infos = build3(["auto"], [v], physs, ages, poses, eths, scene)
        t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as her.", 1)
        if chk(t): break
    o1.append(f"## {i}. {v[7]} 솔로 · 체형 {physs[0][0]} · 인종 {eths[0][0]} · {infos[0]} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''}\n\n```\n{t}\n```\n")
    print("auto", i, len(t.split()))
open(O + "LumineX_Automaton_Bright_v2_3.md", "w", encoding="utf-8").write("\n".join(o1))
