# -*- coding: utf-8 -*-
# 물체 몸 믹스(사람마다 물체 하나, 2~3명) 샘플 3개 — 석고상 프레임 컷 틀
import re, sys, random
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity"); sys.path.insert(0, "../../master")
_g = open("gen_pierce_statue.py", encoding="utf-8").read()
exec(_g[:_g.index("def build(")])
import mdefs as D
exec(open("../../bk/newbody_defs.py", encoding="utf-8").read(), globals())
_src = open("../../bk/mk_statue_obj11.py", encoding="utf-8").read()
_i0 = _src.index("rnd.seed("); _i1 = _src.index("LABEL = ['Physique']")
_hdr = _src[_i0:_i1]
exec(_hdr)                      # CORE, CLEAN, KO, SIL, GLASS2 ...
rnd.seed(20262201)
NWD = {2: "TWO", 3: "THREE"}; ASPG = {2: "3:4", 3: "4:5"}
FIGS = ["siren bust hourglass", "legendary bust", "glamour hourglass", "violin hip hourglass", "latina curves", "Brazilian booty glam"]
REAL_SHORT = REAL_FACE.split("— ")[0].strip()

def hair_of():
    si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC) + 1)
    return f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}"

def OBJ(shape_txt, extra, arms):
    return (f"Below the collarbones there is no human torso at all: in its place her entire torso is {shape_txt}, and that object itself is the torso. {extra} {arms} "
            "There is nothing inside it that is a body, no skin and no second figure, and nothing behind it but the backdrop — no torso outline, no waist outline anywhere.")

GL = GLASS2
# (본문, 한글 이름, 투명 여부, 실루엣 치환)
OBJS = {
 "clock": (OBJ("one single round antique clock stretched vertically into a long, body-shaped form — its brass rim swelling wide right at her collarbones as her bust, pinching in to a slim waist, and swelling wide again below as her hips, continuing into both thighs of polished bronze",
               "It is still one clock: a single dial stretched along the whole length of the form under a clear glass crystal, with the numerals running around the rim from top to bottom and two slender hands pointing from a centre at her waist, and gears, springs and an escapement visible through the stretched dial.",
               "Her shoulders and arms are polished bronze like her thighs, solid bronze limbs with bronze hands, joined to the clock at the shoulders."),
           "시계", False, (("glass neck", "waist"), ("bulb", "mass"))),
 "violin": (OBJ("one single large violin standing upright, its body in the silhouette of her torso — the wide upper bout as her bust, the narrow curved waist of the instrument, and the wider lower bout as her hips, continuing into both thighs of the same varnished wood",
                "It is still one violin: the top plate faces forward with two carved f-holes, a bridge and four taut strings running down the centre of the figure, and a golden-brown varnish with a deep flame-maple grain that catches the light.",
                "Her shoulders and arms are the same varnished maple wood as her thighs, solid carved wooden limbs with wooden hands, joined to the violin at the shoulders."),
            "바이올린", False, (("upper bulb", "upper bout"), ("glass neck", "waist"), ("lower bulb", "lower bout"))),
 "maebyeong": (OBJ("one single large Korean celadon maebyeong vase standing upright, its body in the silhouette of her torso — the broad rounded shoulder of the vase as her bust, the narrow waist of the vase, and the wide flared lower body as her hips, continuing into both thighs of the same celadon porcelain",
                   "It is still one vase: pale jade-green celadon glaze with a fine crackle, with white and black inlaid cranes flying among clouds across the whole figure, and the glaze pooling darker in the grooves.",
                   "Her shoulders and arms are the same jade-green celadon porcelain as her thighs, solid glazed limbs with porcelain hands, joined to the vase at the shoulders."),
               "청자 매병", False, (("upper bulb", "broad shoulder"), ("glass neck", "waist"), ("lower bulb", "flared lower body"))),
 "lantern": (OBJ("a real hurricane lantern of thick clear glass — a round glass globe as her bust, the glass narrowing to a slim waist, and a wide flared glass base as her hips, continuing into both thighs",
                 f"{GL} One long, thick, real white candle floats in mid-air in the hollow centre of the glass, touching nothing, melted wax running down its sides in thick drips, its flame burning steadily and its warm glow lighting the whole figure from within.",
                 "Her arms are plain clear glass limbs with solid glass hands."),
             "허리케인 랜턴", True, ()),
 "perfume": (OBJ("a real Art Deco perfume bottle of thick faceted crystal — broad rounded shoulders as her bust, tapering to a slim waist, and flaring into a wide faceted base as her hips, continuing into both thighs",
                 f"{GL} The bottle is filled to the brim with golden-amber perfume that glows where the light passes through it.",
                 "Her arms are plain clear faceted-crystal limbs with solid hands."),
             "향수병", True, ()),
}

def person(lab, key, figname, frame):
    pname, pos, part = FR[frame]
    body, ko, transp, subs = OBJS[key]
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); hair = hair_of()
    sl = SIL[figname]
    for a, b in subs: sl = sl.replace(a, b)
    sl = sl[0].upper() + sl[1:]
    vessel = key in ("lantern", "perfume")
    tip = "sealed shut into its own smooth, rounded, closed tip" if vessel else "rounded off into its own smooth, deeply polished tip"
    tipsent = (f"{pos[0].upper()}{pos[1:]}, each thigh individually curves inward and {tip} — the two thighs stay clearly separate, never merging into a single base — nothing continues below either tip, and each tip rests directly on the polished floor with a soft contact shadow.")
    mat = ("Her body below the collarbones is a transparent material that light passes through; her face, ears and neck stay opaque living flesh."
           if transp else
           "Her body below the collarbones is a completely opaque solid that no light passes through; her face, ears and neck are living flesh.")
    block = (f"{lab}: A strikingly beautiful adult {nat} woman — {fa}, {hair}. {REAL_SHORT}.\n{lab} Silhouette: {sl}.\n{lab} Body: {body} {tipsent} {mat}")
    return block, f"{ko}·{KO[figname]}·메이크업 {mk}"

def group(frame, keys):
    g = len(keys); pname, pos, part = FR[frame]
    figs = rnd.sample([n for n in FIGS if n in CLEAN], g)
    blocks, descs = [], []
    for i, (k, f) in enumerate(zip(keys, figs)):
        b, d = person(f"#{i+1}", k, f, frame); blocks.append(b); descs.append(d)
    (ba, bb) = rnd.choice(BACKS)
    intro = (f"Professional fashion photograph, {pname}. {NWD[g]} women standing side by side, each angled 45 degrees toward the camera, framed so every woman's whole sculpted form is visible from the top of her head down to two individually rounded, deliberately finished tips {pos}, each face in natural scale with her body — never an oversized close-up crop. Where a sculpted form comes to an end at the {part}, it is because the sculpture itself ends there, not because a camera frame happens to cut her off. Generous spacing so every figure reads clearly, nobody's arms crossing a neighbour. Every sculpture stands directly on the floor on its own two rounded tips, with the polished floor visible beneath and around them and no pedestal, so no figure floats in the air.")
    common = ("Boundary for each woman: a sharp jagged line runs around the base of her neck and across both collarbones — real skin above, material immediately below. At that line, the material's edge rises in a small raised step above her flesh, casting a crisp shadow — her skin beside it stays smooth and even. Each rounded tip is that object's own finish — never the edge of a photograph.")
    setting = f"Setting: a huge backdrop behind them washed with two coloured lights from behind — {ba} on one side and {bb} on the other, blending into a smooth gradient in the middle, and a glossy dark floor beneath them."
    pose = "Pose: each stands tall, her left hand resting on her flared hip, her right arm held clear of her body with the hand relaxed at hip height, every hand well away from every face, heads tilted slightly toward the camera."
    anyt = any(OBJS[k][2] for k in keys)
    light = ("Lighting: the glowing backdrop shines through every transparent body from behind, tinting it, while the opaque bodies block it completely and are lit by two large softboxes raking from either side. " if anyt else
             "Lighting: the glowing backdrop frames every silhouette from behind while the opaque bodies block it completely, lit by two large softboxes raking from either side. ")
    light += ("A soft frontal light falls on all the faces and ears; a thin cool rim light traces every figure. Only each woman's face, ears and neck read as real skin. "
              f"Shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. {ASPG[g]} aspect ratio, 8K.")
    p = f"{intro}\n\n" + "\n\n".join(blocks) + f"\n\n{common}\n\n{setting}\n\n{pose}\n\n{light}"
    p = dd(p).replace(",,", ",").replace(".,", ",")
    bad = [x.group(0) for x in re.finditer(r"\b(\w+) \1\b", p)]
    assert not re.search(r"[가-힣]", p) and not bad, bad
    return p, " ; ".join(descs)

specs = [("듀오 · 서로 다른 물체 (불투명 시계 + 투명 향수병)", "demi", ["clock", "perfume"]),
         ("듀오 · 같은 물체 (랜턴 2명)", "hip", ["lantern", "lantern"]),
         ("트리오 · 서로 다른 물체 (바이올린 + 청자 매병 + 랜턴)", "hip", ["violin", "maebyeong", "lantern"])]
L = ["# LumineX — 물체 몸 믹스 샘플 3종 (사람마다 물체 하나, 2~3명)\n",
     "한 화면에 2~3명이 있고 **사람마다 자기 물체가 몸**입니다. 번호별로 성공/실패만 알려주세요.\n"]
for n, (name, frame, keys) in enumerate(specs, 1):
    p, d = group(frame, keys)
    L.append(f"## {n}. {FRKO[frame]} · {name}\n\n{d}\n\n```\n{p}\n```\n")
    print(n, FRKO[frame], name, len(p.split()), "단어 |", d)
open("/mnt/user-data/outputs/LumineX_Material_ObjectMix3b.md", "w", encoding="utf-8").write("\n".join(L))
