# -*- coding: utf-8 -*-
# 맥시멀리스트 틀 + 패턴 풀 확장(이레즈미26·UV27·바디페인팅 공예41·스테인드글라스·금박·식물·해태) + 신발24·헤어16·손톱 확장.
import json, re, random, difflib, sys
sys.path.insert(0, "/home/claude/glassface"); sys.path.insert(0, "/home/claude/diversity")
from sfv2_lib import HAIRS6, SF_AGES, HAEJAE, two_colors, SHOES, NAILS
from full_dicts import CRAFT_DB_FULL, SHOE_EN_FULL, NAIL_SHAPE_EN_FULL, NAIL_FIN_EN_FULL
D = json.load(open("/mnt/user-data/outputs/la_maximalist_bundle.json", encoding="utf-8"))
BLACK = "THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky"
KFACE = "Korean silver fox goddess luminous warm golden-olive complexion elegant silver-era maturity"
NUM = {2: "TWO", 3: "THREE", 4: "FOUR", 5: "FIVE", 6: "SIX", 7: "SEVEN", 8: "EIGHT", 9: "NINE", 10: "TEN"}
CAT = {"ire": "Irezumi", "uv": "UV Neon", "glass": "Stained Glass", "gold": "Gold Leaf", "bot": "Botanical"}
HAIR16 = ["silver-white sleek straight hair falling past her shoulders", "silver-white loose waves cascading to her waist", "silver-white voluminous curls framing her face",
          "silver-white hair in a sleek high ponytail", "silver-white hair in an elegant updo", "silver-white half-up hair, top section lifted with the length flowing loose below",
          "silver-white hair in a low bun", "silver-white chin-length bob", "silver-white layered tousled shag cut", "silver-white layered wolf cut with curtain bangs",
          "silver-white flat glossy finger waves styled close to the scalp", "silver-white intricate fishtail braid", "silver-white crown braid wrapping around the head",
          "silver-white low chignon knot at the nape", "silver-white vintage victory rolls framing the face", "silver-white sleek wet-look hair slicked straight back"]
HDR = re.compile(r"^#(\d+): " + re.escape(BLACK) + r", ((?:early|mid|late) \d0s) goddess, (.+? physique) THE MOST EXTREME")
PLAIN = "platform boots 8 inch, extra long stiletto nails to match."
UVSH = "platform boots 8 inch, extra long stiletto nails BLAZING NEON UV reactive tips."
def pool(sec, n): return [p for p in D if CAT[sec] in p["category"] and f"{NUM[n]} women standing" in p["prompt"]]
def persons_of(p): return [b for b in p.split("\n\n")[1:] if re.match(r"#\d+: ", b)]
def phys_of(b): return HDR.match(b.split("\n", 1)[0]).group(3)
def pat_of(b): return re.search(r"full body (.+?) covering", b).group(1)
def ink_of(b):
    m = re.search(r"(?:Bold black ink outlines|Bold formations|Thin irregular metallic sheets) — (.*?), NO airbrush", b, re.S)
    return m.group(1) if m else b
def craft_person(base, rnd, seen):
    while True:
        k = rnd.choice(list(CRAFT_DB_FULL)); nm, desc, pal, scroll = CRAFT_DB_FULL[k]
        if nm not in seen: break
    a, b = (pal.split("-and-") + ["gold"])[:2] if "-and-" in pal else (pal.split("-")[0], "gold")
    a, b = a.split("-")[-1], b.split("-")[-1]
    if a == b: b = "crimson" if a != "crimson" else "gold"
    A, B = a.upper(), b.upper()
    ink = f"{desc}, BLAZING {A} and VIVID {B} bands following every deep curve of her body, dense {scroll} filling every gap"
    base = re.sub(r"full body .+? irezumi covering", f"full body {nm} bodypaint covering", base, count=1)
    base = re.sub(r"(Bold black ink outlines — ).*?(, NO airbrush)", lambda m: "Bold formations — " + ink + m.group(2), base, count=1, flags=re.S)
    return base, nm, (a, b)
def haetae_person(base):
    base = re.sub(r"full body .+? irezumi covering", f"full body {HAEJAE[0]} covering", base, count=1)
    return re.sub(r"(Bold black ink outlines — ).*?(, NO airbrush)", lambda m: m.group(1) + HAEJAE[1] + m.group(2), base, count=1, flags=re.S)
def pick_persons(secs, kind, rnd, n_src):
    seen = set(); out = []; pc = {}; maxrep = 2 if len(secs) >= 9 else 1
    for s in secs:
        for _ in range(500):
            if s in ("bp", "haetae"):
                src = rnd.choice(pool("ire", n_src)); b = rnd.choice(persons_of(src["prompt"]))
                if pc.get(phys_of(b), 0) >= maxrep: continue
                if s == "bp": b, nm, cols = craft_person(b, rnd, seen); seen.add(nm)
                else: b = haetae_person(b); nm, cols = HAEJAE[0], None
            else:
                src = rnd.choice(pool(s, n_src)); b = rnd.choice(persons_of(src["prompt"]))
                if pc.get(phys_of(b), 0) >= maxrep or pat_of(b) in seen: continue
                cols = None
            pc[phys_of(b)] = pc.get(phys_of(b), 0) + 1; seen.add(pat_of(b)); out.append((s, b, cols)); break
        else: raise RuntimeError(s)
    return out
KYOUNG = "Korean idol goddess luminous warm golden-olive complexion youthful fresh glow"
def conv(block, num, age, hair, kind, young=False):
    first, rest = (block.split("\n", 1) + [""])[:2]
    m = HDR.match(first); assert m, first[:120]
    if young: head = (f"#{num}: {BLACK}, {age} goddess, {m.group(3)} THE MOST EXTREME" if kind == "I" else f"#{num}: {KYOUNG}, {age}, {m.group(3)} THE MOST EXTREME")
    else: head = (f"#{num}: {BLACK}, {age} silver fox goddess, {m.group(3)} THE MOST EXTREME" if kind == "I" else f"#{num}: {KFACE}, {age}, {m.group(3)} THE MOST EXTREME")
    first = head + first[m.end():]
    i = first.index(" — full body"); j = first.rfind(", ", 0, i); oh = first[j + 2:i]
    assert re.search(r"hair|braid|loc|afro|bob|crop|ponytail|bun|wave|curl|crown|updo|cut|tresses", oh, re.I), oh
    first = first[:j + 2] + hair + first[i:]
    rest = re.sub(r"^#\d+: ", f"#{num}: ", rest, flags=re.M)
    return first, rest
from full_dicts import HAIR_COLOR_EN_FULL
HC = [v for v in HAIR_COLOR_EN_FULL.values() if not re.search(r"silver|ash-grey|icy|platinum|balayage|ombre", v)]
def render(n, plist, ages, kind, ext, seed, who=None):
    r2 = random.Random(seed); hairs = r2.sample(HAIR16 if ext else HAIRS6, n)
    who = who or ["S"] * n
    hairs = [h if w == "S" else h.replace("silver-white", r2.choice(HC)) for h, w in zip(hairs, who)]; shoes = r2.sample(list(SHOE_EN_FULL.values()), n)
    out = []; lab = []
    for k, ((s, b, cols), age, hair, shoe) in enumerate(zip(plist, ages, hairs, shoes), 1):
        first, rest = conv(b, k, age, hair, kind, young=(who[k - 1] == "Y"))
        if ext:
            shape = r2.choice(list(NAIL_SHAPE_EN_FULL.values() if False else ["stiletto", "coffin", "almond"])); fin = r2.choice(list(NAIL_FIN_EN_FULL.values()))
            if rest == f"#{k}: {PLAIN}":
                c = list(cols) if cols else two_colors(ink_of(b))
                rest = f"#{k}: {c[0]} {c[1]} {shoe}, extra long {shape} {fin} nails {c[0]} {c[1]} tips."
            elif rest == f"#{k}: {UVSH}": rest = f"#{k}: {shoe}, extra long {shape} {fin} nails BLAZING NEON UV reactive tips."
        out.append(first + ("\n" + rest if rest else ""))
        lab.append(f"{phys_of(b).replace(' physique','')}·{age}·{pat_of(first.replace(chr(10),' ') if False else first)}·{hair.replace('silver-white ','').replace('silver-streaked ','')}")
    return out, lab
IRE = {p["meta"]["group_size"]: p for p in D if "Irezumi" in p["category"] and p["meta"]["group_size"] in range(1, 11) and p["key"].endswith("_01")}
FR = {}
for p in D:
    if p["key"].endswith("_01"): FR.setdefault(next(k for k, v in CAT.items() if v in p["category"]), {})[p["meta"]["group_size"]] = p
def frame(n, out, fc="ire"):
    src = FR[fc][n]["prompt"]; blocks = src.split("\n\n")
    if n == 1:
        body = re.sub(r"^#\d+: ", "", out[0], flags=re.M)
        return "Professional fashion photograph, full body shot. ONE woman standing.\n\n" + body + "\n\n" + blocks[-1]
    tail = "\n\n".join(b for b in blocks[1:] if not re.match(r"#\d+: ", b))
    return blocks[0] + "\n\n" + "\n\n".join(out) + "\n\n" + tail
def check(name, t):
    assert not re.search(r"[가-힣]", t); d = [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", t)]; assert not d, (name, d)
def make(name, kind, secs, seed, ext=True, ages=None, plist=None, who=None, fc="ire"):
    n = len(secs); rnd = random.Random(seed)
    if plist is None: plist = pick_persons(secs, kind, rnd, n if n >= 6 else (4 if n <= 4 else 5))
    if ages is None:
        ages = rnd.sample(SF_AGES * 3, n); ys = rnd.sample(["early 20s", "mid 20s", "late 20s"], 3)
        ages = [ys.pop() if w == "Y" else a for a, w in zip(ages, who or ["S"] * n)]
    out, lab = render(n, plist, ages, kind, ext, seed, who); t = frame(n, out, fc).replace("VIVID VIVID", "VIVID"); check(name, t)
    if kind == "K": assert "DARKEST BLACK" not in t
    return t, lab, plist, ages
# ---- 한 섹션만 쓰는 그룹 시험 ----
S = []
def add(name, kind, secs, seed, fc):
    t, lab, pl, ag = make(name, kind, secs, seed, True, fc=fc); S.append([name, lab, t])
add("국제 UV네온 솔로 · 전원 UV(블랙라이트 틀)", "I", ["uv"], 401, "uv")
add("K UV네온 트리오 · 전원 UV(블랙라이트 틀)", "K", ["uv"] * 3, 402, "uv")
add("국제 UV네온 퀸텟 · 전원 UV(블랙라이트 틀)", "I", ["uv"] * 5, 403, "uv")
add("K 바디페인팅 쿼르텟 · 전원 공예 바디페인팅", "K", ["bp"] * 4, 404, "ire")
add("국제 이레즈미 트리오 · 전원 이레즈미", "I", ["ire"] * 3, 405, "ire")
rr = random.Random(406); sc = ["haetae", "bp"]; rr.shuffle(sc)
t, lab, pl, ag = make("K 듀오 · 해태 + 바디페인팅", "K", sc, 406, True); S.append(["K 듀오 · 해태 + 바디페인팅 (혼합)", lab, t])
for i, s in enumerate(S, 1): print(i, len(s[2].split()), s[0]); print("   ", s[1])
import pickle; pickle.dump(S, open("v7_items.pkl", "wb"))
