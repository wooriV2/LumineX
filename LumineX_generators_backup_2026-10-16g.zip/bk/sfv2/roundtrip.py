import re
from sfv2_lib import *
# --- 트리오 왕복 ---
t = open("pasted_trio.txt", encoding="utf-8").read().rstrip("\n")
pat = re.compile(r"(?P<pos>LEFT|CENTER|RIGHT): EXTREME (?P<pname>.+?) with Korean silver fox features — (?P<skin>.+?) elegant silver-era maturity, (?P<age>[^—]+?) — (?P<detail>.+?), (?P<hair>silver[^,—]+?) — full body (?P<sec>.+?) irezumi covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE\. Bold black ink outlines — (?P<ink>.+?) — filling EVERY gap neck to ankle including both legs hip to ankle to toe, NO bare leg skin visible, NO airbrush NO gradient wash\. Pose: (?P<pose>.+?)\.\n(?P=pos): (?P<shoe>.+)")
blocks = t.split("\n\n")
persons = []
for b in blocks[0:3]:
    m = pat.match(b.replace("Professional fashion photograph, full body shot. THREE women standing side by side.\n", ""))
    assert m, b[:80]; d = m.groupdict(); persons.append(trio_person(**d))
names = re.search(r"physiques — (.+?) — must", t).group(1)
rebuilt = trio_wrap(persons, names)
print("트리오 왕복:", "완전 일치" if rebuilt == t else "불일치")
if rebuilt != t:
    import difflib
    for i,(a,b) in enumerate(zip(rebuilt,t)):
        if a!=b: print(i, repr(rebuilt[i-60:i+60]), repr(t[i-60:i+60])); break
# --- 듀오 왕복 (사람 문단 단위) ---
d = open("pasted_duo.txt", encoding="utf-8").read().rstrip("\n")
blocks = d.split("\n\n")
L, R = blocks[1], blocks[2]
pl = re.compile(r"(?P<pos>LEFT): (?P<skin>THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky), (?P<age>[^,]+?) silver fox goddess, extreme (?P<pname>.+?) physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — (?P<detail>.+?), (?P<hair>silver[^,—]+?) — full body (?P<sec>.+?) irezumi covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE\. Bold black ink outlines — (?P<ink>.+?)\. Pose: (?P<pose>.+?)\.\nLEFT: (?P<shoe>.+)")
m = pl.match(L); assert m
g = m.groupdict(); body, shoe = ds_person(g["pos"], "black", g["skin"], g["age"], g["pname"], g["detail"], g["hair"], g["sec"], g["ink"], g["pose"], g["pos"], g["shoe"])
print("듀오 LEFT(블랙형):", "일치" if body + "\nLEFT: " + shoe == L else "불일치")
pr = re.compile(r"(?P<pos>RIGHT): (?P<form>Serbian) silver fox goddess (?P<skin>warm olive Balkan complexion strong bone structure) elegant silver-era maturity, (?P<age>[^,]+?), extreme (?P<pname>.+?) physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — (?P<detail>.+?), (?P<hair>silver[^—]+?) — full body (?P<sec>.+?) irezumi covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE\. Bold black ink outlines — (?P<ink>.+?)\. Pose: (?P<pose>.+?)\.\nRIGHT: (?P<shoe>.+)")
m = pr.match(R); assert m
g = m.groupdict(); body, shoe = ds_person(g["pos"], g["form"], g["skin"], g["age"], g["pname"], g["detail"], g["hair"], g["sec"], g["ink"], g["pose"], g["pos"], g["shoe"])
print("듀오 RIGHT(국적형):", "일치" if body + "\nRIGHT: " + shoe == R else "불일치")
