# -*- coding: utf-8 -*-
import re, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
_src = open("/home/claude/glassface/gen_sf_hof.py", encoding="utf-8").read().split("def person(")[0]
ns = {"__name__": "ns"}; exec(_src, ns); os.chdir(HERE)
IREZUMI_FULL, UV_FULL, POSES, PHYS, T = ns["IREZUMI_FULL"], ns["UV_FULL"], ns["POSES"], ns["PHYS"], ns["T"]
HAEJAE, two_colors, SHOES, NAILS, SF_AGES = ns["HAEJAE"], ns["two_colors"], ns["SHOES"], ns["NAILS"], ns["SF_AGES"]

TAIL = ("full body {sec} irezumi covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. "
        "Bold black ink outlines — {ink}")
TRIO_TAIL = " — filling EVERY gap neck to ankle including both legs hip to ankle to toe, NO bare leg skin visible, NO airbrush NO gradient wash. Pose: {pose}."
BLACK = "THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky"
KSKIN = "luminous warm golden-olive complexion"
# 트리오 6체형: 붙여주신 트리오 프롬프트의 문장 그대로
TRIO_BODIES = [
 ("PEAR GODDESS", "pear goddess maximum lower body", "upper body dramatically slim making contrast with lower body utterly extreme, hips flaring to absolute maximum from impossibly slim waist, thighs massively thick dominating lower frame, bubble butt projecting dramatically backward"),
 ("SUPER HOURGLASS", "super hourglass maximum ratio", "waist cinched to absolute impossible minimum defying human biology, hips AND bust simultaneously at absolute maximum explosive extreme, most dramatic hourglass ratio ever rendered, thighs so thick pressing together"),
 ("PLUS SIZE BOMBSHELL", "plus size maximum volume", "most massive full-figure curves at absolute maximum, hips so wide dominating entire frame, bust overwhelming gravity, thighs crushing together, waist snatched against impossible volume"),
 ("HOURGLASS GODDESS", "hourglass maximum drama", "waist cinched to absolute impossible minimum defying human biology, hips AND bust simultaneously flaring to absolute maximum, most dramatic hourglass ratio ever rendered, thighs powerful and thick pressing together"),
 ("BUBBLE BUTT GODDESS", "bubble butt maximum projection", "bubble butt so impossibly enormous projecting backward at maximum impossible distance defying all physics, hips so wide extending beyond frame, thighs crushing together at maximum, waist snatched to impossible minimum, full bust"),
 ("THICK THIGH TEMPTRESS", "thick thigh maximum girth", "thighs so impossibly massively thick beyond all human anatomy crushing together at maximum girth, hips wide and commanding, full heavy bust, waist dramatically snatched"),
]
# 듀오·솔로 체형: 붙여주신 3개(문장 그대로) + 등록 맥시멀리스트 체형(PHYS, latina curves 제외)
DS_BODIES = [
 ("wide hip narrow waist", "hips so dramatically wide extending beyond frame, waist cinched to absolute impossible minimum, bust so overwhelmingly massive defying gravity completely projecting forward, legs powerful and thick from massive hips"),
 ("bubble butt corset", "bubble butt so impossibly enormous projecting backward at maximum impossible distance, waist cinched to absolute impossible corset minimum, hips AND bust simultaneously flaring to absolute maximum, bust so overwhelmingly massive defying gravity completely with bust profile clearly visible from side angle, thighs powerfully thick pressing together"),
 ("BBW goddess", "entire body so impossibly voluminous and enormous beyond all anatomy limits, bust so overwhelmingly massive defying gravity completely projecting forward, hips so dramatically wide extending far beyond frame both sides, thighs so massively thick crushing together, bubble butt projecting backward at maximum impossible distance, waist relatively snatched creating dramatic silhouette against enormous volume, total body volume filling and overflowing entire frame"),
] + [(n, d) for n, d in PHYS if n != "latina curves"]
HAIRS6 = ["silver-streaked short crop cut razor sharp", "silver-streaked vintage finger waves deep side part glamorous", "silver-white long curly waves cascading to waist",
          "silver-streaked high ponytail sleek taut", "silver-white blunt bob jaw length sleek", "silver-streaked long straight hair loose flowing"]

def trio_person(pos, pname, skin, age, detail, hair, sec, ink, pose, shoe, feat="Korean silver fox features"):
    return (f"{pos}: EXTREME {pname} with {feat} — {skin} elegant silver-era maturity, {age} — {detail}, {hair} — " + TAIL.format(sec=sec, ink=ink) + TRIO_TAIL.format(pose=pose) + f"\n{pos}: {shoe}")
def ds_person(pos, form, skin, age, pname, detail, hair, sec, ink, pose, shoe_pos, shoe):
    lab = f"{pos}: " if pos else ""
    if form == "black": head = f"{skin}, {age} silver fox goddess, extreme {pname} physique"
    else: head = f"{form} silver fox goddess {skin} elegant silver-era maturity, {age}, extreme {pname} physique"
    body = (f"{lab}{head} THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {detail}, {hair} — " + TAIL.format(sec=sec, ink=ink) + f". Pose: {pose}.")
    return body, shoe
def trio_wrap(persons, names):
    return ("Professional fashion photograph, full body shot. THREE women standing side by side.\n" + "\n\n".join(persons) +
            f"\n\nAll: extreme high-gloss oil. MANDATORY pure pitch black void background only. CRITICAL: all three women legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible on any leg anywhere. THREE completely different extreme physiques — {names} — must CLASH and DOMINATE every inch of frame. 8K portrait 3:4 vertical. portrait 2:3 vertical.")
