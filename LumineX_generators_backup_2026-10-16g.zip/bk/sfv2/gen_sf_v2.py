# -*- coding: utf-8 -*-
import random, re
from sfv2_lib import *
rnd = random.Random(20261007)
def pick_section(kind, uv_ok, used=()):
  while True:
    r = _pick(kind, uv_ok)
    if r[1] not in used: return r
def _pick(kind, uv_ok):
    pool = ["ire", "ire"] + (["uv"] if uv_ok else []) + (["haetae"] if kind == "K" else [])
    s = rnd.choice(pool)
    if s == "ire": nm, ink = rnd.choice(IREZUMI_FULL); return s, nm, ink
    if s == "uv": nm, ink = rnd.choice(UV_FULL); return s, f"UV neon {nm}", ink
    return s, HAEJAE[0], HAEJAE[1]
def shoe_of(ink):
    c1, c2 = two_colors(ink); return f"{c1} {c2} {rnd.choice(SHOES)} 8 inch", f"extra long {rnd.choice(NAILS)} nails {c1} {c2} tips."
def fix(p): return p.replace("bodypaint irezumi", "bodypaint")
def check(name, p):
    assert not re.search(r"[가-힣]", p), (name, "KOREAN")
    d = [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", p)]; assert not d, (name, d)
    assert "bodypaint irezumi" not in p
items = []
def trio(kind):
    bodies = rnd.sample(TRIO_BODIES, 3); hairs = rnd.sample(HAIRS6, 3); ages = rnd.sample(SF_AGES, 3); ps = []; lab = []; uv = False; used = []
    for pos, (pn, short, det), hair, age in zip(["LEFT", "CENTER", "RIGHT"], bodies, hairs, ages):
        s, sec, ink = pick_section(kind, not uv, used); used.append(sec); uv |= (s == "uv"); pose = rnd.choice(POSES)
        shoe, nails = shoe_of(ink); shoe_line = f"{shoe}, {nails}"
        if kind == "K": ps.append(trio_person(pos, pn, KSKIN, age, det, hair, sec, ink, pose, shoe_line))
        else: ps.append(trio_person(pos, pn, BLACK, age, det, hair, sec, ink, pose, shoe_line, feat="silver fox features"))
        lab.append(f"{pn.title()}·{age}·{sec}")
    return fix(trio_wrap(ps, ", ".join(b[1] for b in bodies))), " / ".join(lab)
def ds(kind, n):
    bodies = rnd.sample(DS_BODIES, n); ps = []; shoes = []; lab = []; uv = False; hairs = []; used = []; ages = rnd.sample(SF_AGES, n)
    pos_names = ["LEFT", "RIGHT"] if n == 2 else [""]
    for (pos, (pn, det)), age in zip(zip(pos_names, bodies), ages):
        s, sec, ink = pick_section(kind, not uv, used); used.append(sec); uv |= (s == "uv"); pose = rnd.choice(POSES); hair = rnd.choice(HAIRS6)
        shoe, nails = shoe_of(ink)
        if kind == "K": body, _ = ds_person(pos, "Korean", KSKIN, age, pn, det, hair, sec, ink, pose, pos, shoe)
        else: body, _ = ds_person(pos, "black", BLACK, age, pn, det, hair, sec, ink, pose, pos, shoe)
        ps.append((pos, body, shoe, nails, hair)); lab.append(f"{pn}·{age}·{sec}")
    if n == 2:
        txt = "\n\n".join(f"{b}\n{pos}: {shoe}, {nails}" for pos, b, shoe, nails, h in ps)
        p = ("Professional fashion photograph, full body shot. TWO women standing side by side.\n\n" + txt +
             "\n\nAll: extreme high-gloss oil. MANDATORY pure pitch black void background only. NO arm crossing over chest, NO pose blocking adjacent figure, each figure fully visible at all times. TWO women only — each physique must fill and DOMINATE the entire half of frame. CRITICAL: all women legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible on any leg anywhere. 8K portrait 2:3 vertical.")
    else:
        pos, b, shoe, nails, hair = ps[0]; big = "ENORMOUS BBW volume fully on display. " if bodies[0][0] == "BBW goddess" else ""
        p = (f"Professional fashion photograph, full body shot. ONE woman standing.\n\n{b}\nFootwear: {shoe}.\nNails: {nails}\nHair: {hair}.\n\n"
             f"MANDATORY pure pitch black void background only. ONE woman only. {big}Pattern density MAXIMUM — zero bare skin anywhere. Extreme high-gloss oil. 2:3 vertical 8K portrait. portrait 2:3 vertical.")
    return fix(p), " / ".join(lab)
specs = [("K-실버폭스 솔로 (한국 인물)", lambda: ds("K", 1)), ("K-실버폭스 듀오 (한국 인물)", lambda: ds("K", 2)), ("K-실버폭스 트리오 (한국 인물)", lambda: trio("K")),
         ("국제 실버폭스 솔로 (블루블랙 피부)", lambda: ds("I", 1)), ("국제 실버폭스 트리오 (블루블랙 피부)", lambda: trio("I"))]
for name, fn in specs:
    p, lb = fn(); check(name, p); items.append((name, lb, p))
L = ["# LumineX · Silver Fox 뼈대 재현 시험 — 성공한 HOF 프롬프트 문장 그대로 (5개)\n",
     "**원칙**: 붙여주신 성공 프롬프트(솔로·듀오·트리오)의 문장을 한 글자도 바꾸지 않고, 자유축 값만 바꿨습니다. 원문에서 값을 뽑아 같은 문장으로 다시 조립해 보는 검증을 했고, 트리오는 원문과 **완전 일치**, 듀오는 두 인물 형태 모두 **일치**했습니다.\n",
     "- **고정**: 은발 헤어(성공 프롬프트의 은발 문구 6종), 나이 40대 초반~50대 초반, 메이크업 문장 없음.\n- **K(1~3번)**: 트리오는 `with Korean silver fox features — luminous warm golden-olive complexion`, 듀오·솔로는 `Korean silver fox goddess luminous warm golden-olive complexion` 형태입니다.\n- **국제(4·5번)**: 블루블랙 피부 문구(`THE ABSOLUTE DARKEST BLACK SKIN ON EARTH ...`)를 씁니다. 트리오 형식에서는 `with silver fox features — {블루블랙 피부} elegant silver-era maturity`로 이어 붙인 것이 유일하게 새로 만든 연결입니다(성공 원문에 블루블랙 트리오가 없었습니다).\n",
     "- **체형**: 트리오 6종은 트리오 원문 문장 그대로, 듀오·솔로는 원문 3종 + 등록 맥시멀리스트 체형입니다. 문양·색·포즈·신발은 등록된 생성기 값입니다.\n- **새로 쓴 문장(원문이 문양 전용이라)**: 듀오 마무리의 `CRITICAL: all women legs ...` 한 줄, 솔로 마무리에서 문양 전용 문장 제외. 솔로 성공작에 있던 `pattern so densely packed it reads as second skin...` 문장은 넣지 않았습니다.\n",
     "**알려주실 것**: 번호별 **성공/실패**만 (생성이 안 되면 실패). 예: `1 성공 / 2 실패 / 3 성공 / 4 성공 / 5 실패`\n",
     "## 색인 (체형·나이·섹션)\n", "| 번호 | 구성 | 인물별 |", "|---|---|---|"]
for k, (d, lb, p) in enumerate(items, 1): L.append(f"| {k} | {d} | {lb} |")
L.append("")
for k, (d, lb, p) in enumerate(items, 1): L += [f"## {k}. {d}\n", "```", p, "```\n"]
open("/mnt/user-data/outputs/LumineX_SF_Skeleton_1.md", "w", encoding="utf-8").write("\n".join(L))
for k, (d, lb, p) in enumerate(items, 1): print(k, len(p.split()), d, "|", lb)
