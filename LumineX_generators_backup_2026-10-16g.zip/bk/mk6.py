import re,random,sys,os
src=open('random_mix5_lib.py').read(); ns={}; exec(compile(src,'lib','exec'),ns)
G=ns['G']; build=ns['build']; HENNA=ns['HENNA']; STICK=ns['STICK']; BOTH=ns['BOTH']; OUT=ns['OUT']
FACEPAINT={"마이코","경극","혼례(연지곤지)","둔황 비천풍"}
ALLOW=[x for x in G.STYLES if x not in FACEPAINT]
def lipdesc(fn,i):
    b=re.findall(r"```\n(.*?)\n```",open(OUT+fn,encoding='utf-8').read(),re.S)[i]
    sj=[p for p in b.split("\n\n") if p.startswith("Subject:")][0]
    return re.search(r"Her lips are the star of her face: she has (.*?)\. Her eyes are large",sj,re.S).group(1)
b=re.findall(r"```\n(.*?)\n```",open(OUT+'LumineX_BothCanthus8_Mixed_4.md',encoding='utf-8').read(),re.S)[0]
E8=("양쪽 트임 8배+거대한 눈",re.search(r"pure fantasy eyes.*?bright catchlights(?=; her nose)",b,re.S).group(0).replace("coloured","{lens}"))
T=open(OUT+'LumineX_ExtremeNext_10.md',encoding='utf-8').read()
SI=re.search(r"extreme siren eyes:.*?bright catchlights",T,re.S).group(0)
HO=re.search(r"extremely heavy-lidded, almost closed.*?bright catchlights",T,re.S).group(0)
R6=("러시안 립 극한",lipdesc('LumineX_ExtremeNext_10.md',1)); CH=("체리 립 +1",lipdesc('LumineX_ExtremeNext_10.md',4)); KH=("키홀 퓨트 +1",lipdesc('LumineX_ExtremeNext_10.md',5))
Z=("tmp","brow","bri")
PLAN=[("eye",E8,"한국","20대","도도한",25,8,"수수",HENNA,None,Z),
("eye",("사이렌 눈 +1",SI),"중국","30대","섹시한",50,9,"화려",STICK,"A",Z),
("eye",("후디드 아이 +1",HO),"일본","아이돌","몽환적인",25,10,"귀여움",BOTH,None,Z),
("lip",R6,"한국","20대","카리스마 있는",25,8,"화려",HENNA,None,()),
("lip",CH,"일본","아이돌","귀여운",25,9,"귀여움","",None,()),
("lip",KH,"중국","30대","군림하는",25,10,"수수",HENNA,None,())]
rr=random.Random(20261013)
o=["# LumineX — 기본 랜덤(일반 메이크업 포함) 시험 샘플 6개 · 귀 추 2구멍\n","- 메이크업은 기본 축 전체에서 랜덤(얼굴 전체를 칠하는 마이코·경극·혼례·둔황은 제외): 진한 눈 메이크업, 블랙립, 레드립, 자연스러운 계열 등. 주인공(눈/입술)의 모양·크기는 주인공 문장이 우선, 색은 메이크업을 따르게 함.","- 귀 추: 귓볼 구멍 2개, 구멍마다 무쇠 링 1개와 추 기둥 1개(8개=4·4, 9개=5·4, 10개=5·5). 1~3 눈 주인공(정면), 4~6 입술 주인공(45도, 입 주변 피어싱 없음).","- 정상/이상(+ 메이크업과 주인공이 충돌해 무너진 번호, 귀가 덜 처지는지)만 번호로 알려주세요.\n"]
for k,(st,it,nat,grp,ex,N,nw,v,deco,pat,zero) in enumerate(PLAN,1):
    sty=rr.choice(ALLOW)
    lab,t=build(k,8000+k*23,nat,grp,ex,st,it,N,nw,v,deco,pat,zero,sty,st=="lip")
    assert "{lens}" not in t and "{" not in t.split("Subject:")[1][:3000]
    o.append(f"## {k}. {lab}\n\n```\n{t}\n```\n"); print(k,sty,'|',lab[:150])
open(OUT+'LumineX_MakeupMix_Test_6.md','w',encoding='utf-8').write("\n".join(o))
