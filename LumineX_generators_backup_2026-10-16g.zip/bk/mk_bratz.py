import re,random
ns2={}
g=open('gen_fs2.py',encoding='utf-8').read()
exec(compile(g[:g.index('if __name__=="__main__":')],'gfs2','exec'),ns2)
ns2['tusk_flag']=False; OUT=ns2['OUT']
ARCHF={n:f for n,f,c in ns2['ARCH']}
R=random.Random(20261017)
it=ns2['build2'](1,'arch','브랫츠 돌',ARCHF['브랫츠 돌'],R)
base=it["prompt"]
assert "A strikingly beautiful adult woman" in base and "high-gloss, airbrushed, glossy finish" in base and "'Bratz doll' face brought to life" in base
def v1(t):
    t=t.replace("A strikingly beautiful adult woman","A real photograph of a strikingly beautiful adult woman",1)
    t=t.replace("high-gloss, airbrushed, glossy finish","glossy finish with real visible pores")
    return t
def v2(t):
    t=v1(t)
    t=t.replace("with the glamorous Y2K 'Bratz doll' face brought to life","with a glamorous Y2K 'Bratz'-inspired glam face on a real woman")
    t=t.replace("doll-eye contact lenses","big-iris contact lenses")
    return t
def v3(t):
    t=v2(t)
    t=t.replace("adult woman, mid 20s","adult Korean woman, mid 20s",1)
    t=t.replace("a photograph of a real woman, not an illustration, not a render","a photograph of a real Korean woman's face with East Asian Korean features, not an illustration, not a render",1)
    return t
o=["# LumineX — 브랫츠 돌 실사 앵커 시험 3개 (같은 인물·같은 틀, 브랫츠 문단만 다름)\n","- 원인 추정: 브랫츠 문단은 일반 인물과 달리 ① \"A real photograph of\" 시작이 없고 ② 국적별 실제 얼굴 특징 묘사가 없고 ③ \"Bratz doll\"·\"doll-eye\"·\"airbrushed\"·\"high-gloss\" 같은 장난감/그림 쪽 단어가 많고 ④ 실사 문구가 끝에 한 줄뿐입니다.","- V1: ①(시작에 \"A real photograph of\") + 그림 쪽 단어(airbrushed·high-gloss) 교체 / V2: V1 + \"Bratz doll\"→\"Bratz-inspired glam face on a real woman\", doll-eye 렌즈→큰 홍채 렌즈 / V3: V2 + 한국 여성의 실제 얼굴 특징 지정. 문장 추가 없이 교체 위주(V3만 짧은 구절 추가).","- 번호별 정상/이상과 \"실사 느낌\" 순위만 알려주세요.\n"]
for i,(nm,f) in enumerate((("V1",v1),("V2",v2),("V3",v3)),1):
    t=f(base); assert not re.search(r"[가-힣]",t)
    o.append(f"## {i}. 브랫츠 돌 {nm} · {it['title']}\n\n```\n{t}\n```\n"); print(i,len(t.split()))
open(OUT+'LumineX_Bratz_Realism_3.md','w',encoding='utf-8').write("\n".join(o))
