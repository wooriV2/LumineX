# -*- coding: utf-8 -*-
import re
s = open("gen_woodstone_sample4.py", encoding="utf-8").read()
ns = {}
exec(s[:s.index("# (소재 종류")], ns)
PH0 = ns["PH"]; HAIRS, POSES, AGES, check = ns["HAIRS"], ns["POSES"], ns["AGES"], ns["check"]
BIG = [PH0[2], PH0[4], PH0[5], PH0[0]]  # BBW bombshell, amazon bombshell, latina curves, super hourglass
WOODS = ns["WOODS"] + [
 ("rosewood", "deep purple-brown rosewood", "BLAZING deep purple-brown rosewood grain across the full torso both legs neck to ankle", "VIVID near-black streaks running between the carved sections"),
 ("bubinga", "pinkish-red bubinga", "BLAZING pinkish-red bubinga grain across the full torso both legs neck to ankle", "VIVID purple vein lines running between the carved sections"),
 ("wenge", "near-black wenge", "BLAZING near-black wenge grain across the full torso both legs neck to ankle", "VIVID gold-tan pinstripes running between the carved sections"),
 ("tulipwood", "cream and rose tulipwood", "BLAZING cream and rose-pink tulipwood grain across the full torso both legs neck to ankle", "VIVID violet ribbons running between the carved sections"),
 ("olive wood", "golden olive wood", "BLAZING golden olive wood grain across the full torso both legs neck to ankle", "VIVID dark-brown swirling figure running between the carved sections"),
 ("cherry", "warm reddish cherry", "BLAZING warm reddish-gold cherry grain across the full torso both legs neck to ankle", "VIVID deep-red highlight streaks running between the carved sections")]
STONES = ns["STONES"] + [
 ("onyx", "polished banded onyx", "BLAZING glossy black onyx surface across the full torso both legs neck to ankle", "VIVID creamy-white concentric banding flowing through every section"),
 ("tiger's eye", "polished tiger's eye", "BLAZING golden-brown tiger's eye surface across the full torso both legs neck to ankle", "VIVID bright gold silky banding shimmering through every section"),
 ("labradorite", "polished labradorite", "BLAZING dark grey labradorite surface across the full torso both legs neck to ankle", "VIVID electric blue and gold flashes shimmering through every section"),
 ("turquoise", "polished turquoise", "BLAZING sky-blue turquoise surface across the full torso both legs neck to ankle", "VIVID dark brown matrix webbing running through every section"),
 ("carnelian", "polished carnelian", "BLAZING fiery orange-red carnelian surface across the full torso both legs neck to ankle", "VIVID pale golden-orange banding flowing through every section"),
 ("sodalite", "polished sodalite", "BLAZING deep royal-blue sodalite surface across the full torso both legs neck to ankle", "VIVID white calcite veins flowing through every section")]
NUM = {1: "ONE", 2: "TWO", 3: "THREE", 4: "FOUR", 5: "FIVE"}; ASP = {1: "2:3", 2: "3:4", 3: "4:5", 4: "4:5", 5: "5:4"}
def person(kind, pick, label, idx, j):
    nm, desc, base, acc = pick
    phy_name, phy_detail = BIG[j % 4]; age = AGES[(idx * 3) % 8]; hair = HAIRS[(idx * 5 + 1) % 8]; pose = POSES[idx % 7]
    if kind == "목재":
        mat = (f"full body {desc if desc.endswith("wood") else desc + " wood"} carved directly over her own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not a printed pattern, this is solid carved wood curving to follow her body's true three-dimensional shape, divided into dozens of fitted carved sections whose grain changes direction from one section to the next, each joint standing in a thin raised ridge catching its own soft glint and casting its own small shadow, nothing lying flat. Dense fitted sections — {base}, {acc}, polished to a warm satin sheen, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
        shoe = f"extreme platform boots carved from the same {nm if nm.endswith("wood") else nm + " wood"}, extra long nails in matching polished {nm if nm.endswith("wood") else nm + " wood"}."
    else:
        mat = (f"full body {desc} fused directly to her own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, this is solid stone curving to follow her body's true three-dimensional shape, divided into dozens of fitted stone sections, each joint standing in a thin raised ridge catching its own bright glint and casting its own small shadow, nothing lying flat. Dense fitted sections — {base}, {acc}, high-gloss polished, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
        shoe = f"extreme platform boots carved from the same {nm}, extra long nails in matching polished {nm}."
    p = f"{label}: " if label else ""
    return (f"{p}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {hair} — {mat}. Pose: {pose} — most extreme {phy_name} silhouette ever displayed.\n{p}{shoe}")
def build(kind, picks, slot):
    n = len(picks); labels = [f"#{i+1}" for i in range(n)] if n > 1 else [None]
    body = "\n\n".join(person(kind, picks[i], labels[i], slot * 5 + i, i) for i in range(n))
    if n == 1:
        tail = "MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. ONE woman only. Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
    else:
        tail = f"Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.\nAll: Extreme macro detail on every surface texture and shadow. CRITICAL: all {n} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere, every element standing in true relief, nothing flat. {NUM[n]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame."
    return f"""Professional fashion photograph, full body shot. {NUM[n]} wom{"a" if n == 1 else "e"}n standing{" side by side" if n > 1 else ""}.

{body}

{tail} 8K portrait {ASP[n]} aspect ratio."""
W, T = WOODS, STONES
S = [("석재", [T[8]], 4), ("목재", [W[8], W[10], W[6]], 5), ("목재", [W[6], W[9], W[11], W[1]], 6), ("석재", [T[7], T[11], T[10], T[9]], 7), ("목재", [W[7], W[0], W[3], W[10], W[4]], 8), ("석재", [T[6], T[2], T[9], T[8], T[3]], 9)]
o = ["# 목재·석재 — 부피 큰 체형 중심, 4~5인 포함 샘플 6개\n", "얼굴 문장 없음. 인물마다 다른 목재/석재(같은 그룹은 같은 종류). 번호별로 정상/이상만 알려주세요.\n"]
for i, (kind, picks, slot) in enumerate(S, 1):
    t = build(kind, picks, slot); check(f"s{i}", t)
    assert not re.search(r"\b(\w+) \1\b", t), re.findall(r".{20}\b(\w+) \1\b", t)
    n = len(picks); ph = ", ".join(BIG[j % 4][0] for j in range(n))
    ti = f"{kind} {NUM[n].title() if False else ['','솔로','듀오','트리오','4인','5인'][n]} · {' / '.join(p[0] for p in picks)} · 체형 {ph}"
    o.append(f"## {i}. {ti}\n\n```\n{t}\n```\n"); print(i, ti, len(t.split()))
open("/mnt/user-data/outputs/LumineX_WoodStone_Groups6.md", "w", encoding="utf-8").write("\n".join(o))
