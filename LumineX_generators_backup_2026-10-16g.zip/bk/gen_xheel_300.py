# -*- coding: utf-8 -*-
# 극단 힐 추가 번들 300: 바디페인팅·이레즈미·UV네온(솔로~퀸텟 각 12) + 왁스·옵시디언(솔로~트리오 각 20)
import json, re, random, copy
O = "/mnt/user-data/outputs/"
L = lambda f: {p["key"]: p for p in json.load(open(O + f, encoding="utf-8"))}
core, mx, d120 = L("la_core_bundle.json"), L("la_maximalist_bundle.json"), L("la_120_bundle.json")
wrep = L("la_wax_duo01_replace_bundle.json"); d120["la_wax_duo_01"] = wrep["la_wax_duo_01"]
BODYLIFT = "her feet arched fully vertical on the very tips of her toes like a dancer on pointe, her legs stretched impossibly long and her whole body lifted far above the ground on them as if standing on stilts"
LOW = " Very low camera angle with the full length of every boot visible down to the floor, the towering heel height dominating the silhouette and lifting her far above the floor."
NOTDARK = "NOT black, NOT dark, NOT plain — the footwear must be a bright, saturated, glossy colour taken straight from her own body art"
def HEEL(mode):
    if mode == "forty": return "a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform"
    return "a razor-thin tapered heel taller than her entire shin from ankle to knee and a towering hidden front platform"
def put_low(t):
    i = t.rindex(" 8K"); return t[:i] + LOW + t[i:]
def colors(line):
    seg = line.split("ANYWHERE", 1)[1].split("Pose:", 1)[0]
    out = []
    for r in re.findall(r"\b[A-Z]{3,}(?:[ -][A-Z]{3,})*\b", seg):
        r = r.lower()
        if r not in out: out.append(r)
    return out[:3]
def person_colors(t, n):
    cols = {}
    for l in t.split("\n"):
        m = re.match(r"(?:#(\d): )?THE ABSOLUTE DARKEST", l)
        if m:
            c = colors(l); k = m.group(1) or "1"
            assert len(c) >= 2, (k, c); cols[k] = c
    assert len(cols) == n, (len(cols), n)
    return cols
def cj(c): return f"{c[0]} and {c[1]}" if len(c) < 3 else f"{c[0]}, {c[1]} and {c[2]}"
def fix_mx(t, n, mode):
    cols = person_colors(t, n)
    def f(m):
        k = m.group(1)[1:-2] if m.group(1) else "1"
        pre = m.group(1) or ""
        return f"{pre}thigh-high platform stiletto boots entirely in the exact same colours as her own body art — {cj(cols[k])} — {NOTDARK}, each with {HEEL(mode)}, {BODYLIFT}, extra long stiletto nails"
    t, k = re.subn(r"(#\d: )?platform boots 8 inch, extra long stiletto nails", f, t); assert k == n, k
    return put_low(t)
def fix_wax(t, n, mode):
    cols = person_colors(t, n); cnt = [0]
    def f(m):
        pre = m.group(1) or ""; k = pre[1:-2] if pre else "1"
        return f"{pre}extreme platform heels entirely coated in the same hardened wax drips in {cj(cols[k])}, {NOTDARK}, each with {HEEL(mode)}, {BODYLIFT}"
    t, k = re.subn(r"(#\d: )?extreme platform heels entirely coated in the same hardened wax drips", f, t); assert k == n, k
    return put_low(t)
def fix_obs(t, n, mode):
    t, k = re.subn(r"extreme platform boots carved from the same glossy obsidian with gold seams", f"extreme platform boots carved from the same glossy obsidian with gold seams, each with {HEEL(mode)}, {BODYLIFT}", t); assert k == n, k
    return put_low(t)
def fix_core(t, n, mode):
    def f(m):
        lead, desc = m.group(1), re.sub(r"^[Ee]xtreme ", "", m.group(2))
        return f"{lead}ootwear: the most absurdly extreme heels imaginable — {desc}, each with {HEEL(mode)}, {BODYLIFT}."
    t, k = re.subn(r"((?:[A-Z][A-Za-z-]* woman's f|F))ootwear: (.*?), the platform soles rising far higher than her ankle bone, at least three times the thickness of an ordinary heel\.", f, t)
    assert k == n, (k, n)
    return t.rstrip("\n") + LOW
def phys(p):
    if p["meta"].get("composition"): return " / ".join(p["meta"]["composition"])
    return ", ".join(dict.fromkeys(x for x in re.findall(r"([A-Za-z][\w\- ]{3,40}?) physique", p["prompt"]) if "completely" not in x))
GR = [("solo", 1, "솔로"), ("duo", 2, "듀오"), ("trio", 3, "트리오"), ("quartet", 4, "4인"), ("quintet", 5, "5인")]
TR = [("bodypaint", "Body Paint", "바디페인팅", core, "la_core_", fix_core, 12, 5, "original"),
      ("irezumi", "Irezumi", "이레즈미", mx, "la_irezumi_", fix_mx, 12, 5, "matched"),
      ("uvneon", "UV Neon", "UV네온", mx, "la_uvneon_", fix_mx, 12, 5, "matched"),
      ("wax", "Wax", "왁스", d120, "la_wax_", fix_wax, 20, 3, "matched"),
      ("obsidian", "Obsidian", "옵시디언", d120, "la_obsidian_", fix_obs, 20, 3, "black")]
CAT = "🏺 Living Artifact · Extreme Heels Body-Art"
random.seed(20261009)
out = []
for tr, en, ko, src, pre, fx, NN, ng, shoe in TR:
    for gname, n, gko in GR[:ng]:
        _seen = set(); pool = []
        for k in sorted(k for k in src if k.startswith(f"{pre}{gname}_")):
            if src[k]["prompt"] not in _seen: _seen.add(src[k]["prompt"]); pool.append(k)
        N = min(NN, len(pool))
        pick = [pool[int(j * len(pool) / N)] for j in range(N)]
        if N < NN: print("  부족:", tr, gname, N, "/", NN)
        if n == 1:
            modes = ["forty"] * (N * 65 // 120 + 1) ; modes = (["forty"] * round(N * 0.55) + ["relative"] * (N - round(N * 0.55)))
            random.shuffle(modes)
        else: modes = ["forty"] * N
        for i, (sk, mode) in enumerate(zip(pick, modes), 1):
            p = src[sk]; t = fx(p["prompt"], n, mode)
            assert not re.search(r"[가-힣]", t)
            assert t.count("forty inches") == (n if mode == "forty" else 0), (sk, t.count("forty inches"))
            assert "platform boots 8 inch" not in t and "the platform soles rising" not in t
            meta = copy.deepcopy(p["meta"]); meta.update(format="extremeheel", track=tr, heel_mode=mode, shoe=shoe, source=sk)
            hm = "힐 40인치" if mode == "forty" else "힐 숫자 없음"
            sc = {"matched": " · 신발 색 몸 패턴과 일치", "original": " · 신발 색 원문 유지", "black": " · 검정 유리 신발"}[shoe]
            out.append({"key": f"la_xheel_{tr}_{gname}_{i:02d}", "category": CAT,
                        "title": f"{en} Heel {gname.capitalize()} #{i:02d} ({ko} {gko} · {'구성' if p['meta'].get('composition') else '체형'} {phys(p)} · {hm}{sc})",
                        "prompt": t, "meta": meta})
keys = [p["key"] for p in out]; assert len(set(keys)) == len(keys), len(keys)
import collections as _c
_d = _c.defaultdict(list)
for p in out: _d[p["prompt"]].append(p["key"] + "<-" + p["meta"]["source"])
print("중복:", [v for v in _d.values() if len(v) > 1])
assert len(_d) == len(out)
json.dump(out, open(O + "la_xheel_300_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
import collections
print(len(out), collections.Counter((p["meta"]["track"], p["meta"]["group_size"]) for p in out))
print(collections.Counter(p["meta"]["heel_mode"] for p in out if p["meta"]["group_size"] == 1))
print(max(len(p["prompt"].split()) for p in out), out[0]["title"])
