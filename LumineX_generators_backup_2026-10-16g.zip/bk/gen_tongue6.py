# -*- coding: utf-8 -*-
import random, re
import cjk_face_lib as C
F, MK = C.load(); MK.update(C.BLACK_MK)
NAT = {"한국": "Korean", "중국": "Chinese", "일본": "Japanese"}
FORK = "the tongue deeply forked like a snake's, split down the middle for most of its length, the two pointed tips clearly separated and curling slightly apart"
RINGS = "with a small matching metal ring through each fork tip"
STUD = "with a matching metal barbell stud through its centre, one ball on top and one underneath, sitting in real wet healthy tissue"
ROW = "with a row of three small matching barbell studs down its centre line, each with a ball on top and underneath"
BLACK = "the tongue dyed jet-black and deeply forked like a snake's, split down the middle for most of its length, the two pointed tips clearly separated"
E1 = "wide bright eyes, cheeks lifted by a cheeky grin, mouth open with her tongue stuck out straight over the lower lip, {t}, a playful, mischievous expression"
E2 = "heavy-lidded eyes with a provocative stare straight into the camera, mouth open with her tongue stuck out and curled up toward one corner of the lips, {t}, a defiant, provocative expression"
E3 = "heavy-lidded eyes, lips parted, her tongue stretched out long and low with its tip reaching down past the lower lip toward the chin, {t}, a sultry, teasing expression"
E4 = "eyes opened extremely wide with the whites showing all around the irises, a fixed unblinking stare, a wide stretched grin with her tongue flicked out, {t}, {x}, a manic, unhinged expression"
def src(lv, jew):
    c = [x for x in F if x["meta"]["piercing"] == lv and (("Jewelry:" in x["prompt"]) == jew)]
    return c[0]
CASES = [("한국", "20대", E1, FORK, "", None, ("P50", True), "분리된 혀"),
         ("일본", "20대", E2, FORK + ", " + RINGS, "", "비주얼계", ("P100", True), "분리된 혀+끝 링"),
         ("중국", "30대", E3, STUD, "", None, ("P150", False), "혀 중앙 스터드"),
         ("한국", "아이돌", E1, ROW, "", None, ("P25", True), "혀 스터드 3개"),
         ("일본", "30대", E2, BLACK, "", "고스 블랙립", ("P100", False), "검은 분리된 혀"),
         ("중국", "20대", E4, FORK + ", " + RINGS, "a gold grill covering the upper front teeth, set with small clear gems", None, ("P150", True), "분리된 혀+끝 링+금니 그릴")]
o = ["# 혀 표현 + 피어싱 시험 6개 (얼굴 클로즈업)\n", "피어싱은 기존 단계 그대로 두고, 입을 벌려 혀가 보이게 했습니다. 혀 표현 종류를 섞었습니다. 번호별로 정상/이상만 알려주세요. 이상이면 혀(분리·스터드·링)가 안 나왔는지 한 줄만 적어주세요.\n"]
for i, (nat, grp, E, tg, x, mkn, (lv, jew), lab) in enumerate(CASES, 1):
    key = f"tg{i}"; C.EXPR[key] = E.format(t=tg, x=x)
    rr = random.Random(40 + i)
    t = C.build(src(lv, jew), NAT[nat], grp, key, mkn, MK, rr)
    assert not re.search(r"[가-힣]", t)
    o.append(f"## {i}. {nat} · {grp} · {lab} · {'메이크업 ' + mkn if mkn else '메이크업 없음'} · 피어싱 {lv}{'+쥬얼리' if jew else ''}\n\n```\n{t}\n```\n")
    print(i, C.EXPR[key][:230])
open("/mnt/user-data/outputs/LumineX_Tongue_Pierce6.md", "w", encoding="utf-8").write("\n".join(o))
