import re,random,json,collections,sys
sys.path.insert(0,'.')
OUT='/mnt/user-data/outputs/'
# --- gen_fs6 environment, with a hook to force the age group ---
g=open('gen_fs2.py',encoding='utf-8').read()
g=g[:g.index('if __name__=="__main__":')]
g=g.replace('grp=rr.choice(["아이돌","20대","30대"])','grp=(GRPFORCE[0] or rr.choice(["아이돌","20대","30대"]))',1)
assert 'GRPFORCE' in g
GRPFORCE=[None]
exec(g)
m=open('mk_group4.py',encoding='utf-8').read()
exec(m[m.index('END="'):m.index('TEXT.update')])
f6=open('gen_fs6.py',encoding='utf-8').read()
exec(f6[f6.index('cnt_old='):f6.index('jobs=[]')].replace("assert sum(c for n,t,c in LIP3)==120",""))
tusk_flag=False
# --- age logic from mk_mixed_age2 ---
cjk=open('cjk_face_lib.py',encoding='utf-8').read()
HAIRS=sorted(set(re.findall(r'"((?:[^"]*?(?:hair|bob|bun|waves|lob|ponytail|braid|bangs|updo|twin|pigtail)[^"]*?))"',cjk)),key=len,reverse=True)
SILV=["long silver-white hair in soft waves swept to one side","a sleek silver-grey bob with soft layers","a polished silver low bun with a few loose strands","long straight silver hair with a side part"]
AGE_RE=re.compile(r"\b(?:early|mid|late) (?:20s|30s)\b")
LEVELS=[("아이돌",["early 20s"],False,"아이돌"),("20대 후반",["late 20s"],False,"20대"),("30대 후반",["late 30s"],False,"30대"),("실버폭스",["early 40s","mid 40s","late 40s","early 50s"],True,"30대")]
SWAP=[("high-gloss, airbrushed, glossy finish","natural satin finish"),("airbrushed","natural"),("doll-eye contact lenses","big-iris contact lenses"),("luminous fair porcelain complexion","fair complexion"),("clear glass-skin glow","natural skin tone"),("a glass-skin highlight","a soft highlight"),("smooth dewy skin","natural skin with visible pores"),("luminous ","")]
def set_age(p,age,silver,R):
    p=AGE_RE.sub(age,p); p=re.sub(r"\b(?:Early|Mid|Late) (?:20s|30s)\.",age.capitalize()+".",p)
    if silver:
        for h in HAIRS:
            if h in p: p=p.replace(h,R.choice(SILV),1); return p,True
        return p,False
    return p,True
def scale(items,total):
    s=sum(c for *_,c in items); raw=[c*total/s for *_,c in items]; fl=[int(x) for x in raw]
    for i in sorted(range(len(items)),key=lambda i:-(raw[i]-fl[i]))[:total-sum(fl)]: fl[i]+=1
    return [(*it[:-1],f) for it,f in zip(items,fl)]
def run(tag,cat,catname,seed,eye_n,lip_n,arch_n,levels,fn):
    rr=random.Random(seed); R=random.Random(seed+1)
    eye=scale(list(EYE2),eye_n) if eye_n!=120 else list(EYE2)
    lip=scale(list(LIP3),lip_n) if lip_n!=120 else list(LIP3)
    jobs=[]
    for name,text,c in eye: jobs+=[("eye",name,text)]*c
    for name,text,c in lip: jobs+=[("lip",name,text)]*c
    for name,f,c in ARCH[:] if arch_n else []: jobs+=[("arch",name,f)]*c
    # even level spread for the 240 eye/lip jobs (shuffled)
    nonarch=[j for j in jobs if j[0]!="arch"]
    lv=[levels[i%len(levels)] for i in range(len(nonarch))]; R.shuffle(lv)
    out=[]; li=0
    for i,(kind,name,text) in enumerate(jobs,1):
        if kind=="arch": GRPFORCE[0]=None; L=None
        else: L=lv[li]; li+=1; GRPFORCE[0]=L[3]
        it=build2(i,kind,name,text,rr)
        if kind=='arch':
            for a,b in SW: it['prompt']=it['prompt'].replace(a,b)
            it['prompt']=it['prompt'].replace('..','.')
            lab="유형(원래 나이)"; age="original"
        else:
            for x_,y_ in SWAP: it['prompt']=it['prompt'].replace(x_,y_)
            it['prompt'],nB=re.subn(re.escape(S1)+r'\.?',B1.replace('\\','\\\\'),it['prompt']); assert nB==1
            for a,b in CX: it['prompt']=it['prompt'].replace(a,b)
            lab,ages,silver,_=L; age=R.choice(ages)
            it['prompt'],ok=set_age(it['prompt'],age,silver,R); assert ok,(i,'no hair')
        old=it['meta']['age_group']
        it['title']=it['title'].replace(f"Face Sculpt #{i:03d}",f"Face Sculpt {fn} #{i:03d}",1).replace(f" · {old} · ",f" · {lab}"+("" if kind=="arch" else f"({age})")+" · ",1)
        it['key']=f"la_facesculpt_{tag}_{i:03d}"; it['category']=catname
        it['meta']['age_group']=lab; it['meta']['age']=age
        out.append(it)
    return out
if __name__=="__main__":
    cat1="🏺 Living Artifact · Face Sculpt Mixed-Age Formula"; cat2="🏺 Living Artifact · Face Sculpt Silverfox Formula"
    A=run("mix",None,cat1,20261020,120,120,60,LEVELS,"Mixed-Age")
    B=run("sf",None,cat2,20261021,150,150,0,[LEVELS[3]],"Silverfox")
    for nm,o in (("mix",A),("sf",B)):
        json.dump(o,open(OUT+f'la_facesculpt_{nm}_{len(o)}_bundle.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
        w=[len(x["prompt"].split()) for x in o]
        print(nm,len(o),min(w),max(w),round(sum(w)/len(w)),collections.Counter(x["meta"]["age_group"] for x in o))
        print(" kinds",collections.Counter(x["meta"]["kind"] for x in o),"keys",len(set(x["key"] for x in o)),"korean",sum(1 for x in o if re.search(r"[가-힣]",x["prompt"])))
        print(" piercing",collections.Counter(x["meta"]["piercing"] for x in o),"ear",collections.Counter(x["meta"]["ear_mode"] for x in o))
        print(" dup",sum(1 for x in o if re.search(r"\b(\w+) \1\b",x["prompt"]) and re.search(r"\b(\w+) \1\b",x["prompt"]).group(1).lower() not in("had","that")))
