import re
exec(open('mk_anime_split.py',encoding='utf-8').read().split("S=[(")[0])
HEAD="Close-up beauty portrait of a photograph with one cracked face. ONE woman, facing the camera straight on, her head level, both ears clearly visible on either side of her face, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp."
def STYLE(a):
    r="left" if a=="right" else "right"
    return (f"Style: The whole image is a real photograph of a real woman, except for one part of her face. Her neck, collarbones, shoulders, the background and most of her face are real photographic skin, hair and light. On the {a} side of the picture, a jagged, irregular crack runs down her face like a crack in glass, from the hairline above the centre of her forehead, down between her eyes along the side of her nose, past the corner of her mouth to the tip of her chin, never cutting through either eye. Everything {a} of the crack, her {a} eye, brow, cheek, half of her lips, her {a} ear and the hair above them, is a high-quality Japanese anime illustration with clean cel shading, crisp line art and vibrant colours. The crack ends at her chin and does not continue onto her neck, which is entirely real. It is one woman, one face, one pose: the anime part has the same shape, size and position as the real face it replaces, as if part of a photographed face has broken away to show a drawing beneath.")
def SUBJ(a,hair,eye):
    r="left" if a=="right" else "right"
    return (f"Subject: An adult woman, mid 20s, with {hair} that is the same colour on both sides and flows across the crack. On the real {r} side she is a real woman: real skin with visible pores and fine peach-fuzz hairs, a real eye with bright wet catchlights and individual lashes, real lips with fine vertical lines. On the anime {a} side the same face is drawn: smooth cel-shaded skin with a soft pink blush, {eye}, and an anime-drawn lip half with a tiny fang at the corner of the mouth. A cool, calm look straight into the camera.")
def FRAG(a):
    return (f"The crack: along the whole crack there are small broken fragments, tiny and dense near the forehead, larger and sparser around the cheek, and fading to nothing at the chin. The breaking itself is photographic: real broken edges with real depth and real shadow, not drawn. The drawn pieces show a raw torn edge where the flat colour simply ends, with no ink line around the break itself, and each lifted fragment casts a real photographic shadow with soft falloff. Nothing drawn appears anywhere on the real side, and nothing real appears inside the anime part except the metal described below.")
def PIERCE(a,body):
    r="left" if a=="right" else "right"
    return body+f" Every piece on the real {r} side is real metal with real reflections, real weight and real contact shadows on real skin. Every piece on the anime {a} side is the same piece drawn in anime style with cel-shaded highlights and crisp outlines. The pieces on both sides are identical in shape and size, and the eyes and eyelids stay clear."
S=[("right",IRON,"long straight silver-white hair","a huge glittering anime eye with a star-shaped pupil","오른쪽 얼굴이 애니로 쪼개짐 · 무쇠 추 귀걸이 · 목 아래 전부 실사"),
   ("left",Y2K,"long straight pastel-pink hair with a blunt fringe","a huge sparkling anime eye with a heart-shaped pupil","왼쪽 얼굴이 애니로 쪼개짐 · Y2K 에나멜 12개 · 목 아래 전부 실사"),
   ("right",GOLD,"a chic black lob with soft layers","a sharp upturned anime eye with a cold iris and crisp highlights","오른쪽 얼굴이 애니로 쪼개짐 · 금 피어싱 17개 · 목 아래 전부 실사")]
o=["# LumineX — 쪼개진 얼굴 혼합 3개 (얼굴 일부만 애니로 깨짐, 목 아래는 전부 실사)\n","- 직선 2분할 대신: 얼굴 한쪽이 유리처럼 불규칙하게 갈라지며 그 안이 애니로 보이는 구도. 균열은 이마 머리선 → 코 옆(두 눈 사이) → 입꼬리 → 턱 끝에서 끝나고 목으로 이어지지 않으며, 목·쇄골·어깨·배경은 전부 실사. 균열 가장자리는 실사 파편(깊이·그림자)으로 표현했습니다.","- 정상/이상(+ 균열이 얼굴을 쪼개는 느낌인지, 한쪽 금속이 실제 금속으로 나왔는지)만 번호로 알려주세요.\n"]
for i,(side,pier,hair,eye,lab) in enumerate(S,1):
    t="\n\n".join([HEAD,STYLE(side),SUBJ(side,hair,eye),PIERCE(side,pier)+SAFE,FRAG(side),LIGHT])
    assert not re.search(r"[가-힣]",t)
    o.append(f"## {i}. {lab}\n\n```\n{t}\n```\n"); print(i,len(t.split()))
open(OUT+'LumineX_FaceCrack_RealAnime_3.md','w',encoding='utf-8').write("\n".join(o))
