# -*- coding: utf-8 -*-
# 등록된 맥시멀리스트 4·5인 프롬프트를 그대로 가져와 (나이·머리색·[한국형은 피부 문구])만 바꾼다.
import json, re, random, difflib
from sfv2_lib import HAIRS6, SF_AGES, HAEJAE
rnd = random.Random(20261007)
D = json.load(open("/mnt/user-data/outputs/la_maximalist_bundle.json", encoding="utf-8"))
BLACK = "THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky"
KFACE = "Korean silver fox goddess luminous warm golden-olive complexion elegant silver-era maturity"
NUM = {4: "FOUR", 5: "FIVE"}
def presets(cat, n): return [p for p in D if cat in p["category"] and f"{NUM[n]} women standing" in p["prompt"]]
def split(p):
    blocks = p.split("\n\n"); head = blocks[0]; persons = []; tail = []
    for b in blocks[1:]:
        (persons if re.match(r"#\d+: ", b) else tail).append(b)
    return head, persons, "\n\n".join(tail)
HDR = re.compile(r"^#(\d+): " + re.escape(BLACK) + r", ((?:early|mid|late) \d0s) goddess, (.+? physique) THE MOST EXTREME")
def conv(block, num, age, hair, kind):
    first, rest = (block.split("\n", 1) + [""])[:2]
    m = HDR.match(first); assert m, first[:140]
    phys = m.group(3)
    new_head = (f"#{num}: {BLACK}, {age} silver fox goddess, {phys} THE MOST EXTREME" if kind == "I"
                else f"#{num}: {KFACE}, {age}, {phys} THE MOST EXTREME")
    first = new_head + first[m.end():]
    i = first.index(" — full body"); j = first.rfind(", ", 0, i); old_hair = first[j + 2:i]
    assert re.search(r"hair|braid|loc|afro|bob|crop|ponytail|bun|wave|curl|crown|updo|cut|tresses", old_hair, re.I), old_hair
    first = first[:j + 2] + hair + first[i:]
    rest = re.sub(r"^#\d+: ", f"#{num}: ", rest, flags=re.M)
    return first + ("\n" + rest if rest else ""), phys
def phys_of(block): return HDR.match(block.split("\n", 1)[0]).group(3)
def pat_of(block): return re.search(r"full body (.+?) (?:irezumi|bodypaint|covering|leaf|stained|living)", block).group(1)
def build(name, kind, cat, n, mix=None):
    ages = rnd.sample(SF_AGES, 4) if n == 4 else rnd.sample(SF_AGES, 4) + [rnd.choice(SF_AGES)]
    hairs = rnd.sample(HAIRS6, n)
    if mix is None:
        src = rnd.choice(presets(cat, n)); head, ps, tail = split(src["prompt"]); assert len(ps) == n; used = src["key"]
    else:
        base = rnd.choice(presets("Irezumi", n)); head, _, tail = split(base["prompt"]); ps = []; used = []
        seen = set()
        def take(c, kindpat=None):
            while True:
                s = rnd.choice(presets(c, n)); _, pp, _ = split(s["prompt"]); b = rnd.choice(pp)
                if phys_of(b) in seen or (kindpat and pat_of(b) in seen): continue
                seen.add(phys_of(b)); seen.add(pat_of(b)); used.append(s["key"]); return b
        for c in mix:
            if c == "HAETAE":
                b = take("Irezumi")
                b = re.sub(r"full body .+? irezumi covering", f"full body {HAEJAE[0]} covering", b, count=1)
                b = re.sub(r"(Bold black ink outlines — ).*?(, NO airbrush)", lambda m: m.group(1) + HAEJAE[1] + m.group(2), b, count=1, flags=re.S)
            else: b = take(c)
            ps.append(b)
        assert len(ps) == n
    out = []; physes = []
    for k, (b, age, hair) in enumerate(zip(ps, ages, hairs), 1):
        nb, ph = conv(b, k, age, hair, kind); out.append(nb); physes.append(ph)
    text = head + "\n\n" + "\n\n".join(out) + "\n\n" + tail
    text = text.replace("VIVID VIVID", "VIVID")
    assert not re.search(r"[가-힣]", text); d = [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", text)]
    assert not d or all(x in ("had had",) for x in d), d
    if kind == "K": assert "DARKEST BLACK" not in text
    pats = [re.search(r"full body (.+?) covering", b).group(1) for b in out]
    return text, " / ".join(f"{ph.replace(' physique','')}·{a}·{pt.replace(' irezumi','')}" for ph, a, pt in zip(physes, ages, pats)), used
specs = [("국제 4인 · 스테인드글라스 (블루블랙)", "I", "Stained Glass", 4, None), ("국제 5인 · 금박 (블루블랙)", "I", "Gold Leaf", 5, None),
         ("국제 4인 · 식물 (블루블랙)", "I", "Botanical", 4, None), ("국제 5인 · 이레즈미·UV 혼합 (블루블랙)", "I", None, 5, ["Irezumi", "Irezumi", "Irezumi", "Irezumi", "UV Neon"]),
         ("K 4인 · 스테인드글라스 (한국 인물)", "K", "Stained Glass", 4, None), ("K 5인 · 식물 (한국 인물)", "K", "Botanical", 5, None),
         ("K 4인 · 이레즈미·UV·해태 혼합 (한국 인물)", "K", None, 4, ["Irezumi", "Irezumi", "UV Neon", "HAETAE"])]
items = []
for name, kind, cat, n, mix in specs:
    if mix: rnd.shuffle(mix)
    t, lb, used = build(name, kind, cat, n, mix); items.append((name, lb, t, used)); print(len(items), len(t.split()), name, "|", used)
# 원본 대비 변경 범위 점검: 단일 섹션 샘플은 인물당 변경 토큰 수 출력
for name, lb, t, used in items:
    if isinstance(used, str):
        src = next(p for p in D if p["key"] == used)["prompt"]
        dd = [x for x in difflib.ndiff(src.split(), t.split()) if x[0] in "+-"]
        print(" 변경 토큰", len(dd), name)
L = ["# LumineX · Silver Fox 4~5인 + 섹션 확장 시험 (7개)\n",
 "**기준**: 등록된 맥시멀리스트 4·5인 프롬프트(`la_maximalist` 번들)를 **문장 그대로** 가져와서, 인물마다 **나이(40대 초반~50대 초반)**와 **머리색(은발)**만 바꿨습니다. K 쪽은 피부 문구를 `Korean silver fox goddess luminous warm golden-olive complexion elegant silver-era maturity`(앞서 성공한 한국형 문구)로 바꿨고, 국제 쪽은 블루블랙 피부 문구 그대로에 `silver fox goddess`를 붙였습니다. 그 외 체형·문양·포즈·신발·Environment·마무리·화면비(4:5 / 5:4)는 등록 문장 그대로입니다.\n",
 "- **4·5번 인원 표기**는 트리오의 `LEFT/CENTER/RIGHT`가 아니라 등록된 `#1~#5` 형식입니다. 5인은 나이 4종 중 하나가 한 번 겹칩니다.\n- **혼합(4번, 7번)**: 이레즈미·UV네온·해태 바디페인팅 인물 문단을 서로 다른 등록 프리셋에서 가져와 합쳤습니다(체형·문양 중복 없음, UV네온 1명). 마무리는 이레즈미 쪽 문장을 썼습니다(UV 프리셋의 블랙라이트 조명 문장은 이레즈미와 충돌해서 제외).\n- 금박은 블루블랙 피부 전용이라 국제형에만 넣었습니다.\n- 등록 스테인드글라스 원문에 있던 `VIVID VIVID` 중복 단어는 `VIVID` 하나로 고쳤습니다(이것만 원문과 다릅니다).\n",
 "**알려주실 것**: 번호별 **성공/실패**만. 영어 단어가 보였으면 `(단어)`만 덧붙여 주세요. 예: `1 성공 / 2 실패 / 3 성공(단어)`\n",
 "## 색인 (체형·나이·문양)\n", "| 번호 | 구성 | 인물별 |", "|---|---|---|"]
for k, (name, lb, t, u) in enumerate(items, 1): L.append(f"| {k} | {name} | {lb} |")
L.append("")
for k, (name, lb, t, u) in enumerate(items, 1): L += [f"## {k}. {name}\n", "```", t, "```\n"]
open("/mnt/user-data/outputs/LumineX_SF_Quartet_Quintet_1.md", "w", encoding="utf-8").write("\n".join(L))
