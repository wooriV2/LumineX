import re,random,json,collections,sys
s=open('mk_file7.py',encoding='utf-8').read()
exec(s[:s.index('CFG=[')])        # helpers, holes, brighten, BGS/BROWS/TEETH/SKINS/SLOTS, finish, apply_ear ...
MATS=[ (m[0], (m[1]+" and a slender sharp taper") if m[0] in("무쇠","상아·뼈","흑요석") else m[1]) + tuple(m[2:]) for m in ns['MATS'] ]
ARCH=ns['ARCH']
EXCL_N=[5,15,25,50,100,150,200]; W_N=[15,15,15,20,20,7.5,7.5]
# ---- canthus items: drop 2x / 2.5x, rebalance counts
CAN2=[]
cnt={"옆트임 극한(3배)":6,"옆트임 최극한(4배)":6,"양쪽 트임 6배+큰 눈":9,"양쪽 트임 8배+거대한 눈":9}
for n,t,c in ns['CAN']:
    if n in cnt: CAN2.append((n,t,cnt[n]))
assert sum(c for n,t,c in CAN2)==30
EYE2=ns['EYEITEMS']+CAN2
# liner / inner-corner fixes
LINER_RE=re.compile(r"a razor-sharp black (?:eyeliner|liner) follows the (?:whole extended|entire) shape and ends in ([^;]*);")
PLAIN="the outline of each eye is crisp and clean, defined only by her natural dark lashes and the edge of her lids, with no eyeshadow and no eyeliner;"
INNER6="the inner corners are cut open far toward the bridge of her nose, the small pink inner corners reaching almost to the sides of her nose bridge,"
INNER8="the inner corners are cut open so far that they almost meet at the root of her nose, the small pink inner corners clearly visible on either side of the nose bridge,"
INNEW="the inner corners are fully opened with the small pink inner corners clearly visible,"
def fix_canthus(name,text,plain):
    if "트임" not in name: return text
    assert LINER_RE.search(text),name
    if plain: text=LINER_RE.sub(PLAIN,text)
    else: text=LINER_RE.sub(lambda m:"a razor-sharp eyeliner in the colour of her makeup follows the entire shape and ends in "+m.group(1)+";",text)
    if name.startswith("양쪽 트임 6배"): assert INNER6 in text; text=text.replace(INNER6,INNEW)
    if name.startswith("양쪽 트임 8배"): assert INNER8 in text; text=text.replace(INNER8,INNEW)
    return text
# pre-flight: transformations must work on all canthus items
for n,t,c in CAN2: fix_canthus(n,t,True); fix_canthus(n,t,False)
# ---- base with tusk support
def base2(rr,N,zero,minimal,deco,nw,theme=None,chains=False,expr0=None,style0=None,pat=None,mat=None):
    nat=rr.choice(list(G.NATS)); grp=rr.choice(["아이돌","20대","30대"]); expr=rr.choice(EX[grp]); v=rr.choice(["수수","화려","귀여움"])
    if expr0: grp="20대"; expr=expr0
    style=style0 or pick_style(rr,N,pat)
    t,title,meta=make_base(rr,nat,grp,expr,style,N)
    metal,gems=TH[v]
    pp=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    new,tot=para2(N,nw,metal,gems,deco,random.Random(rr.randrange(10**9)),pat,mat,zero,minimal)
    if theme:
        s_,tail,lt=THEMES[theme]
        new=new.replace("The left and right sides are balanced.",s_+" The left and right sides are balanced.",1)
        old=f"The face and ear jewelry is real {metal} set with {gems}"; assert old in new
        new=new.replace(old,tail)
    else: lt=""
    if chains:
        assert "The left and right sides are balanced." in new
        new=new.replace("The left and right sides are balanced.",CHAINS+" The left and right sides are balanced.",1)
    t=re.sub(r'\n\nJewelry:[^\n]*','',t.replace(pp,new))
    sj=[x for x in t.split("\n\n") if x.startswith("Subject:")][0]
    sj2=sj.replace(BODYS,"").replace(". Real pores and fine skin grain on her skin, a soft sheen of natural oils, large eyes with bright real catchlights, full lips, ",", ")
    sj2=re.sub(r" — a photograph of a real (\w+) woman's face \(.*?\), not an illustration"," — a photograph of a real \\1 woman's face, not an illustration",sj2)
    t=t.replace(sj,sj2)
    fr=FR["ch"] if pat else FR["sh"]
    t,n=re.subn(re.escape(FR_OLD),fr,t,count=1); assert n==1
    t=t.replace("\n\nLighting:","\n\n"+HAIR+"\n\nLighting:",1)
    mk=("메이크업 "+(meta.get("makeup_label") or "없음")) if style!="NONE" else "메이크업 없음"
    lab=f"{nat} · {grp} · {expr} · {mk} · P{N}({v})"
    return t,lab,lt,nw,style,meta,nat,grp,expr,mk
def draw2(N,kind,r2,k,tusk):
    obj=['theme','chains','slot','brow','teeth']; env=['skin','bg']
    if N>=150: obj=['theme']
    if kind=='lip' and 'teeth' in obj: obj.remove('teeth')
    if tusk:
        if 'teeth' in obj: obj.remove('teeth')
        if 'slot' in obj: obj.remove('slot')       # tusk frame already extends to the chest
    cap_obj=2 if N<=25 else 1
    if kind=='lip': cap_obj=1
    if kind=='arch': env=['bg']
    cap_tot=3 if N<=25 else 2
    k=min(k,cap_tot)
    pick=[]; no=0
    if tusk: no=1
    pool=obj+env; r2.shuffle(pool)
    need=k-(1 if tusk else 0)
    for p in pool:
        if len(pick)>=need: break
        if p in obj:
            if no>=cap_obj: continue
            no+=1
        pick.append(p)
    return pick
def build2(idx,kind,name,text,rr):
    for tr in range(300):
        r2=random.Random(rr.randrange(10**9))
        try:
            tusk = (kind=='eye' and tusk_flag)
            Ns=[5,15,25,50,100,150,200]; Ws=[15,15,15,20,20,7.5,7.5]
            if kind=='lip': Ns,Ws=Ns[:5],Ws[:5]
            N=50 if tusk else r2.choices(Ns,Ws)[0]
            k=r2.choices([0,1,2,3],[10,30,35,25])[0]
            if tusk: k=max(k,1)
            picks=draw2(N,kind,r2,k,tusk); adds=[]; zero=[]; theme=None; chains=False; expr0=None; style0=None; bright=False
            if kind=='eye': zero+=["tmp","brow","bri"]
            if kind=='lip': zero+=["ul","ll","chin"]
            if kind=='arch': zero+=["ul","ll","tmp","brow","bri"]
            slot=skinp=browp=teeth=bgp=None; pat=mat=None
            if tusk: pat=r2.choice("ABC"); mat=r2.choice(MATS); adds.append(f"엄니({mat[0]}) 패턴{pat}")
            for p in picks:
                if p=='theme': theme=r2.choice(["punk","marine"]); adds.append("테마 "+THEMES[theme][2])
                elif p=='chains': chains=True; adds.append("체인 연결")
                elif p=='slot':
                    slot=r2.choice(SLOTS); adds.append("슬롯 "+slot[0])
                    if slot[2]: zero.append("fh")
                elif p=='brow': browp=wchoice(r2,BROWS,1); adds.append("눈썹 대용 "+browp[0]); zero.append("brow")
                elif p=='teeth': teeth=r2.choice(TEETH); adds.append("치아 "+teeth[0]); expr0=teeth[2]; zero+=["ul","ll","chin"]
                elif p=='skin': skinp=r2.choice(SKINS); adds.append("피부톤 "+skinp[0]); style0="NONE"
                elif p=='bg': bgp=r2.choice(BGS); adds.append("배경 "+bgp[0])
            if skinp and skinp[2]:
                bright=True
                if theme: continue
                theme="bright"
            nw=r2.choice([8,9,10])
            deco=r2.choice(["",HENNA,STICK,BOTH]) if kind!='lip' else r2.choice(["",HENNA,HENNA])
            t,lab,lt,nw,style,meta,nat,grp,expr,mk=base2(r2,N,tuple(dict.fromkeys(zero)),False,deco,nw,theme=theme,chains=chains,expr0=expr0,style0=style0,pat=pat,mat=mat)
            sj=subj(t)
            nn=(style=="NONE")
            if kind=='arch':
                tx=text(r2); tx=tx if tx.startswith("Subject:") else "Subject: "+tx
                t=t.replace(sj,tx); nose=jaw=None
            else:
                jaw=r2.choice(JAWS); nose=r2.choice(NOSES); nz=nose if name!="애니 돌 아이 실사형" else NOSES[0]
                tx=fix_canthus(name,text,nn) if kind=='eye' else text
                if kind=='eye':
                    tail="and she wears no eyeshadow and no eyeliner at all" if (nn and "트임" in name) else "while the colours of her eyeshadow and liner follow her makeup"
                    star=f"her eyes are the star of her face (the shape, size and lenses described here override the eyes of her makeup, {tail}): {tx.format(lens='coloured') if '{lens}' in tx else tx}"
                else:
                    star=f"her lips are the star of her face (the shape, size and projection described here override the lips of her makeup, while the lip colour and finish follow her makeup and ignore any lip colour named here): {tx}"
                add=f" Her face has been surgically sculpted far beyond her natural look, and these changes override her natural features: {star}; her nose: {nz[1]}; her jawline and chin: {jaw[1]}. Every feature is exaggerated but beautiful, balanced and refined, in harmony with the rest of her face, never distorted, never grotesque."
                t=t.replace(sj,sj+add)
            if kind=='lip':
                a=ANG45 if r2.random()<0.5 else ANG45.replace("to her left","to her right")
                assert HDR in t; t=t.replace(HDR,a,1)
                b="A soft frontal light on her face and ears"; assert b in t
                t=t.replace(b,"A soft key light from the front and slightly to the side on her face and ears",1)
            if skinp: t=skin(t,skinp[1])
            if browp: t=subj_add2(t,"She has no eyebrows at all: "+browp[2])
            if teeth: t=subj_add2(t,teeth[1])
            if slot and slot[1]: t=slots2(t,slot[1])
            if bgp and bgp[1]:
                a0="MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient."
                assert a0 in t; t=t.replace(a0,bgp[1])
            if slot and slot[3]: mode="earring"; FORCE_V=4
            else:
                mode=wchoice(r2,[("iron",25),("mix",35),("one",15),("earring",15),("combo",10)],1)[0]; FORCE_V=None
                if bright and mode in("iron","combo"): mode="mix"
            h=2
            if mode in("iron","mix","one"): h=r2.choice([1,2,3])
            if bright: METALS=BRIGHT
            try: t,lab2=finish(t,mode,nw,r2,lab+f" · 귀 추 {nw}개/귀 2구멍",FORCE_V)
            finally: METALS=METALS0
            if bright: t=brighten(t)
            if mode in("iron","mix","one") and h==1: t=t.replace("and above them sit","and above it sit")
            if mode in("iron","mix","one"):
                t,lab2=holes(t,h,lab2); lab2=re.sub(r" · 귀 구멍 \d개","",lab2).replace(" 2구멍",f" {h}구멍")
        except (AssertionError,KeyError,ValueError) as e:
            continue
        if re.search(r"[가-힣]",t) or "{" in t or "zero separate" in t: continue
        d=re.search(r"\b(\w+) \1\b",t)
        if d and d.group(1).lower() not in("had","that"): continue
        if bright and re.search(r"blackened|black cast|bronze|copper|\blead\b|\biron\b|pitted|tarnished|dark (silver|brass)",t): continue
        t=re.sub(r"  +"," ",t)
        if pat:
            assert "as thick as her thumb in the middle" in t and "not one bit further" in t
            t=t.replace("as thick as her thumb in the middle","as thick as a pencil in the middle")
            t=t.replace("only as far as their outer edges and not one bit further,","only as far as the outer edges of the nostril wings and not one bit further, so the whole tusk is no wider than her nose itself and stays small and delicate in proportion to her face,")
        t=t.replace("as big as a fist or larger","at least as big as her whole fist and clearly larger than her earlobe")
        if len(t.split())>2150: continue
        ang="45도" if kind=='lip' else "정면"
        parts=[f"{nat} · {grp} · {expr}",name]
        if kind!="arch": parts+=[nose[0],jaw[0]]
        parts+=[ang,("유형 고유 메이크업" if kind=="arch" else mk),f"P{N}",lab2.split(" · ")[-1]]
        parts+=adds
        if "Henna" in deco: parts.append("헤나")
        if "Stickers" in deco: parts.append("스티커")
        lens=meta.get("lens")
        if kind!="arch" and lens: parts.append("렌즈 "+lens)
        title=f"Face Sculpt #{idx:03d} ("+" · ".join(parts)+")"
        return dict(key=f"la_facesculpt_{idx:03d}",category="🏺 Living Artifact · Face Sculpt Formula",title=title,prompt=t,
          meta=dict(group_size=1,aspect_ratio="2:3",format="face-sculpt",kind=kind,star=name,nat=nat,age_group=grp,expression=expr,piercing=f"P{N}",makeup=("type-inherent" if kind=="arch" else style),tusk=pat,ear_mode=mode,ear_holes=h,ear_weights=nw,addons=adds))
    raise SystemExit(("fail",idx,name))
if __name__=="__main__":
    rr=random.Random(20261014)
    jobs=[]
    for name,text,c in EYE2: jobs+=[("eye",name,text)]*c
    for name,text,c in LIP: jobs+=[("lip",name,text)]*c
    for name,fn,c in ARCH: jobs+=[("arch",name,fn)]*c
    print(len(jobs))
    out=[]
    eye_idx=[i for i,j in enumerate(jobs) if j[0]=='eye']
    tusk_set=set()   # tusk removed from Face Sculpt (2026-10-13)
    for i,(kind,name,text) in enumerate(jobs,1):
        tusk_flag=(i-1) in tusk_set
        out.append(build2(i,kind,name,text,rr))
        if i%25==0: print(i,file=sys.stderr)
    json.dump(out,open(OUT+'la_facesculpt_300_bundle_v2.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
    print(collections.Counter(x["meta"]["star"] for x in out).most_common(30))
    print(collections.Counter(x["meta"]["piercing"] for x in out))
    print(collections.Counter(len(x["meta"]["addons"]) for x in out))
    print(collections.Counter(x["meta"]["ear_mode"] for x in out), collections.Counter(x["meta"]["ear_holes"] for x in out))
    print("tusk",sum(1 for x in out if x["meta"]["tusk"]))
    w=[len(x["prompt"].split()) for x in out]; print(min(w),max(w),sum(w)/len(w))
