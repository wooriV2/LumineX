import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
from cover_lib import SAFE
IRON="rough black cast iron with a hammered, pitted, matte surface"
SK="The skin is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
END=" Everything else on her face and ears is completely free of piercings. All jewelry is real blackened cast iron,"
def mk(ring,hole):
    return ("Piercings: Exactly one piercing in total, a huge stretched hole in the lower lip, and nowhere else: a traditional stretched lip ring in the lower lip, in the style of the lip plates worn in Ethiopia, but in the form of an open ring. Her lower lip has been stretched around a large round hole in its centre until the lip itself is only a thin, smooth, taut loop of soft pink-red lip flesh, like a rubber band, that circles the hole all the way around, and the hole holds a thick round ring of "+IRON+f" {ring}, with an open see-through hole in its middle {hole}, so through the hole the viewer sees her lower teeth and the skin of her chin. From the outside to the inside the viewer sees her chin, then the full ring of stretched lip flesh in her natural lip colour, clearly different from the dark metal, then the thick metal ring, then the open hole; the ring's outer edge is sunk into the loop of lip flesh, which is visible on every side. The loop of lip hangs down from her mouth, tilted slightly outward, while her upper lip, her teeth line and the corners of her mouth stay fully bare and visible above it. The face is seen at a slight three-quarter angle so the ring of lip flesh around the metal ring is clearly visible. Nothing hangs from the ring. "+SK+END+SAFE)
V=[("G — 링 굵기 손가락, 구멍 큰 동전","as thick as a finger, about as wide overall as two of her fingers laid side by side","as wide as a large coin"),
   ("H — 링 굵기 손가락 두 배, 구멍 작게","as thick as two fingers, about as wide overall as three of her fingers laid side by side","as wide as a small coin")]
NA=[("한국","20대","도도한"),("일본","20대","군림하는")]
o=["# LumineX — 립 링 v4 (가운데 뚫림) 2개: E 구조 + F 전통 지칭·3/4 각도 + 뚫린 링\n","- G: 링 굵기 손가락 1개, 구멍 큰 동전 크기. H: 링 더 두껍고 구멍 작게. 구멍으로 아랫니·턱 피부가 비치게. 추 없음.","- 정상/이상(+ 입술이 링을 감쌌는지, 구멍이 보이는지)만 번호로 알려주세요.\n"]
for i,((lab,ring,hole),(nat,grp,ex)) in enumerate(zip(V,NA),1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(66000+i*100+tr),nat,grp,ex,style="NONE",slots=["pierce"],pier_level="P3"); break
        except AssertionError: continue
    else: raise SystemExit(i)
    old=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    t=re.sub(r'\n\nJewelry:[^\n]*','',t.replace(old,mk(ring,hole)))
    assert not re.search(r"[가-힣]",t)
    o.append(f"## {lab} — {title}\n\n```\n{t}\n```\n")
open('/mnt/user-data/outputs/LumineX_LipRing_v4_2.md','w',encoding='utf-8').write("\n".join(o)); print("ok")
