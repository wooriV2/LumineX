# -*- coding: utf-8 -*-
# 한국 실버폭스 번들의 얼굴 문장에 국적 단어를 한 번 더 넣어 서양인 얼굴로 흐르는 것을 막는다(R1).
import json, sys
OUT = "/mnt/user-data/outputs/"
A = ("a real photograph of a real woman's face,", "a real photograph of a real Korean woman's face,")
B = ("a photograph of a real face,", "a photograph of a real Korean woman's face,")
C = ("a striking adult woman —", "a striking adult Korean woman —")
for f in sys.argv[1:]:
    N = json.load(open(OUT + f, encoding="utf-8")); c = 0
    for p in N:
        if p["meta"]["kind"] != "K" or p["meta"].get("nat") == "R1": continue
        t = p["prompt"]; t0 = t
        for a, b in (A, B, C): t = t.replace(a, b)
        if t != t0: p["prompt"] = t; p["meta"]["nat"] = "R1"; c += 1
    json.dump(N, open(OUT + f, "w", encoding="utf-8"), ensure_ascii=False, indent=1); print(f, "changed", c)
