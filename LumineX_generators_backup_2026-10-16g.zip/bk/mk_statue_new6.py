# -*- coding: utf-8 -*-
# 소재 축 신규 샘플 6개: 선 몸(철사·철근·네온 튜브) 3 + 모래시계 용기 몸 3 — 조각상 프레임 컷 틀, 피어싱 없음, Core 체형
import re, sys, random, json
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity"); sys.path.insert(0, "../../master")
_g = open("gen_pierce_statue.py", encoding="utf-8").read()
exec(_g[:_g.index("def build(")])
import mdefs as D
exec(open("../../bk/newbody_defs.py", encoding="utf-8").read(), globals())
rnd.seed(20262001)
# ── Core 체형 (키 큰 쪽 제외: 다리 길이 문장이 무릎·허벅지 끝 컷과 충돌) ──
_NBd = [b[1] for b in D.BODIES if b[0] == "Nubian booty builder"][0]
_NBB = _NBd.replace("wide flaring lats", "a full, heavy, firm bust standing out on her chest").replace("a deeply carved abdomen with sharp obliques", "a deeply carved six-pack abdomen with sharp obliques")
CORE = ["legendary bust", "curved bust", "siren bust hourglass", "glamour hourglass", "hourglass bombshell", "black glamour", "apex siren", "violin hip hourglass", "latina curves", "Brazilian booty glam",
        "muscular hourglass BBW", "hourglass SSBBW", "USSBBW", "Nubian booty builder", "powerlifter bombshell", "Nubian bust builder"]
POOL = {b[0]: b[1] for b in D.BODIES}; POOL.update({nm: desc for nm, ko, kod, desc in NB}); POOL["Nubian bust builder"] = _NBB
TAILRE = re.compile(r";?\s*her arms, hands, legs and feet stay in correct proportion to each other\s*$")
FLAG = re.compile(r"\b(feet|ankle|ankles|calves|calf|knee|knees|stilt|tall|towering|height|pressing together|pressed together|long legs|legs)\b", re.I)
CLEAN = {}; DROP = {}
for nm in CORE:
    d = TAILRE.sub("", POOL[nm]).strip().rstrip(";,. ")
    f = FLAG.findall(d)
    if f: DROP[nm] = sorted(set(x.lower() for x in f))
    else: CLEAN[nm] = d
print("제외(프레임 컷과 충돌):", DROP)
KO = {"legendary bust": "레전더리 바스트", "curved bust": "커브드 바스트", "siren bust hourglass": "사이렌 바스트 아워글래스", "glamour hourglass": "글래머 아워글래스", "hourglass bombshell": "아워글래스 밤쉘", "black glamour": "블랙 글래머", "apex siren": "에이펙스 사이렌",
      "violin hip hourglass": "바이올린 힙 아워글래스", "latina curves": "라티나 커브스", "Brazilian booty glam": "브라질리언 부티 글램", "muscular hourglass BBW": "머스큘러 아워글래스 BBW", "hourglass SSBBW": "아워글래스 SSBBW", "USSBBW": "USSBBW", "Nubian booty builder": "누비안 부티 빌더", "powerlifter bombshell": "파워리프터 밤쉘", "Nubian bust builder": "누비안 바스트 빌더"}
# ── 새 소재 ──
FIT = "carved as one solid sculpted mass like a statue, never hollow, with no gaps and no skin anywhere, every wrist, palm, finger and knuckle the same material"
LINES = {
 "wire": ("철사", "ONE continuous sculpture of thousands of fine bright steel wires wound, coiled and layered in dense overlapping loops that follow every curve of her form, so tightly packed that the surface reads as a solid woven mass, each wire catching its own thin glint and casting hairline shadows on the wires beneath, completely opaque"),
 "rebar": ("철근", "ONE heavy sculpture of thick ribbed steel rebar bars bent into the exact shape of her body, lashed with twisted tie-wire at every crossing and packed solid between the bars with rough grey concrete so that no gap remains, rust-orange stains bleeding from the bars into the concrete, completely opaque"),
 "tube": ("네온 튜브", "ONE dense sculpture of bent glass neon tubes glowing in vivid electric pink and cyan, coiled and layered side by side in tight rows that follow every curve of her form over a fine black metal frame, so tightly packed that the whole body reads as a solid glowing mass of tubing with no gaps, small black electrode caps and thin cables at the tube ends"),
}
SANDS = [("금빛 모래", "fine warm golden desert sand"), ("미드나이트 블루 모래", "fine midnight-blue sand scattered with tiny silver sparkles"), ("로즈 모래", "fine soft rose-pink sand with pale pearl glints")]
GLASS = "The glass is unmistakably glass: thick, crystal-clear and polished, with bright specular reflections sliding along every curved surface, sharp white highlights and dark refraction edges where the walls are thickest, tiny bubbles trapped in the glass itself. Her shoulders, chest, belly, hips and both thighs keep their exact sculpted shapes as clear glass outlines, and a clean glass rim runs along the boundary where the vessel meets the neck."
def body_line(key):
    nm, desc = LINES[key]
    return (f"{LIST} — is not painted, covered or clothed but physically made of {desc}, {FIT}.", nm, False)
def body_hour(i):
    nm, sand = SANDS[i]
    return (f"{LIST} — is a sculpted vessel of thick, crystal-clear glass in the exact shape of her body, shaped as a real hourglass: her chest and ribcage form the upper glass chamber, her waist is the narrowest glass neck, and her belly, hips and both thighs form the lower glass chamber. {GLASS} {sand.capitalize()} pours in a thin steady stream from the upper chamber through the narrow glass waist and heaps in a smooth cone in the lower chamber, so the upper chamber is partly empty and the lower chamber is mostly full.", f"모래시계·{nm}", True)
def build_new(frame, phys, body, mname, transparent, vessel):
    pname, pos, part = FR[frame]
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC) + 1)
    (ba, bb) = rnd.choice(BACKS)
    hair = f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}"
    tip = (f"{pos[0].upper()}{pos[1:]}, each thigh individually curves inward and " + ("seals shut into its own smooth, rounded, closed tip" if vessel else "rounds off into its own smooth, deeply polished tip") +
           " — the two thighs stay clearly separate all the way down, never merging" + (" or fusing" if vessel else ", fusing or tapering") + " into a single base — no calves, no feet, nothing continues below either tip — the " + ("vessel" if vessel else "material") + " simply reaching its natural end on each leg, both " + ("sealed " if vessel else "") + "rounded tips resting side by side on the surface beneath her.")
    if transparent:
        mid = "Transmission: everything below the collarbones is a transparent material that light passes through, while her real face, ears and neck are opaque living flesh that no light passes through. The background and its light sources are visible straight through her body, bent and tinted by the material, with bright refraction edges and soft coloured shadows. Her face stays completely opaque."
        light = f"Lighting: the glowing backdrop floods her body from behind, so {ba} passes through one side and {bb} passes through the other. A soft frontal light falls on her face and ears only; a thin cool rim light traces her whole figure. Only her face, ears and neck read as real skin."
    else:
        mid = "Material: everything below the collarbones is a completely dense solid with no gaps that no light passes through, while her real face, ears and neck are living flesh. The body blocks the backdrop's glow entirely, its surface catching the light with a hard, honest sheen and soft contact shadows, so it is unmistakable that the body itself is built from the material."
        light = f"Lighting: the glowing backdrop frames her whole silhouette from behind, {ba} on one side and {bb} on the other, while her dense body blocks it completely. A soft frontal light falls on her face and ears, and a thin cool rim light traces her whole figure so the surface of the material reads clearly. Only her face, ears and neck read as real skin."
    p = (f"Professional fashion photograph, {pname}. ONE woman, angled 45 degrees toward the camera, framed so her whole sculpted form is visible from the top of her head down to two individually rounded, deliberately finished tips {pos}, her face in natural scale with her body — never an oversized close-up crop of just the face. Where her sculpted form comes to an end at her {part}, it is because the sculpture itself ends there, not because a camera frame happens to cut her off.\n\n"
         f"Subject: A real photograph of a strikingly beautiful adult {nat} woman — {fa}, {hair}. {REAL_FACE}\n\n"
         f"Physique: {phys}.\n\nBody: {body} {tip}\n\n{mid}\n\n"
         f"Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. There is no line down the centre of her body. At that line, the material's edge rises in a small raised step above her flesh, casting a crisp shadow — her skin beside it stays smooth and even. The rounded tip is the material's own finish, always the clean, deliberate result of a sculpture — never the edge of a photograph.\n\n"
         f"Setting: a huge backdrop behind her washed with two coloured lights from behind — {ba} on one side and {bb} on the other, blending into a smooth gradient in the middle, and a glossy dark floor beneath her.\n\n"
         f"Pose: standing tall, her left hand (solid material) resting on her flared hip, her right arm held clear of her body with the hand (solid material) relaxed at hip height, both hands well away from her face, head tilted slightly toward the camera.\n\n{light} Shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait.")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), p[:100]
    return p, f"메이크업 {mk}"
frames = ["hip", "demi", "tq"]
fr1 = frames[:]; rnd.shuffle(fr1); fr2 = frames[:]; rnd.shuffle(fr2)
names = rnd.sample(list(CLEAN), 6)
items = []
for i, key in enumerate(["wire", "rebar", "tube"]):
    b, mn, tr = body_line(key); p, mk = build_new(fr1[i], CLEAN[names[i]], b, mn, tr, False)
    items.append((FRKO[fr1[i]], KO[names[i]], f"선 몸 · {mn}", mk, p))
for i in range(3):
    b, mn, tr = body_hour(i); p, mk = build_new(fr2[i], CLEAN[names[3 + i]], b, mn, tr, True)
    items.append((FRKO[fr2[i]], KO[names[3 + i]], f"용기 몸 · {mn}", mk, p))
L = ["# LumineX — 소재 축 신규 샘플 6개 (선 몸 3 · 모래시계 용기 몸 3)\n", "조각상 프레임 컷 틀에서 피어싱은 없이, 체형은 Core 체형(키 큰 쪽 제외)에서 랜덤입니다. 번호별로 성공/실패만 알려주세요.\n"]
for i, (fr, bd, mt, mk, p) in enumerate(items, 1):
    L.append(f"## {i}. {fr} · {bd} · {mt} · {mk}\n\n```\n{p}\n```\n")
open("/mnt/user-data/outputs/LumineX_Material_NewAreas_Wire_Hourglass6.md", "w", encoding="utf-8").write("\n".join(L))
for fr, bd, mt, mk, p in items: print(fr, bd, mt, len(p.split()))
