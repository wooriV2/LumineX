# -*- coding: utf-8 -*-
import re
s = open("gen_woodstone_groups6.py", encoding="utf-8").read()
ns = {}
exec(s[:s.index("S = [(")], ns)
W, T, build, check, BIG = ns["W"], ns["T"], ns["build"], ns["check"], ns["BIG"]
HEELS = ["seventy-two inches", "sixty inches", "eighty-four inches"]
cnt = [0]
def heel(m):
    h = HEELS[cnt[0] % 3]; cnt[0] += 1; nm = m.group(1)
    return (f"heels of the single most extreme height physically imaginable, thigh-high platform stiletto boots carved from the same {nm}, each with a razor-thin tapered heel a full {h} tall — taller than her own legs — and an eighteen-inch hidden front platform, her feet arched fully vertical on the very tips of her toes like a dancer on pointe, the boots rising like towering stilts that lift her whole body to a gigantic height far above the ground, extra long nails")
SET = {1: "a bright white-walled modern gallery hall with a polished pale floor and a full-height doorway standing open beside her, flooded with soft natural daylight from tall windows",
       2: "a sunlit open-air stone terrace at midday with a pale paved floor, a waist-high balustrade, potted palms and a full-height wooden door behind her, bright blue sky overhead",
       3: "a bright airy glass-roofed atrium with a pale polished floor, a wide staircase with standard-height steps and tall potted trees, filled with soft white daylight"}
BG = "MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient."
def mk(kind, picks, slot):
    t = build(kind, picks, slot)
    t, k = re.subn(r"extreme platform boots carved from the same ([^,]+), extra long nails", heel, t); assert k == len(picks)
    n = len(picks); assert t.count(BG) == 1
    t = t.replace(BG, f"Environment: {SET[n]}, bright and evenly lit, shadows soft, the whole floor and surroundings clearly visible and in focus, NO dark background NO black void.")
    cam = " Full-length wide shot from a moderate distance with the camera at waist height, the whole figure from the soles of the boots to the top of her head completely visible, with the door, steps or balustrade beside her at normal human scale so the impossible heel height reads at a glance, the towering heels clearly separating the boot soles from the floor."
    a = " 8K portrait"; assert t.count(a) == 1
    return t.replace(a, cam + a)
S = [("목재", [W[8]], 13), ("석재", [T[9], T[11]], 14), ("목재", [W[4], W[5], W[1]], 15)]
o = ["# 최대 극단 힐·밝은 배경 높이 + 밝은 배경(실내·야외) — 솔로·듀오·트리오\n", "얼굴 문장 없음, 부피 큰 체형. 번호별로 정상/이상만 알려주세요.\n"]
for i, (kind, picks, slot) in enumerate(S, 1):
    t = mk(kind, picks, slot); check(f"h{i}", t)
    assert not re.search(r"\b(\w+) \1\b", t), re.findall(r".{20}\b(\w+) \1\b", t)
    n = len(picks); ti = f"{kind} {['','솔로','듀오','트리오'][n]} · {' / '.join(p[0] for p in picks)} · 체형 {', '.join(BIG[j % 4][0] for j in range(n))} · 최대 극단 힐·밝은 배경"
    o.append(f"## {i}. {ti}\n\n```\n{t}\n```\n"); print(i, ti, len(t.split()))
open("/mnt/user-data/outputs/LumineX_ExtremeHeels_Bright3.md", "w", encoding="utf-8").write("\n".join(o))
