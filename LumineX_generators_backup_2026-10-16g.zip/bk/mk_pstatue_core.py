# -*- coding: utf-8 -*-
# 피어싱 석상 × Core 체형 샘플 (솔로 6)
import re, sys, os, random
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity"); sys.path.insert(0, "../../master")
_g = open("gen_pierce_statue.py", encoding="utf-8").read()
exec(_g[:_g.index("def build(")])
import mdefs as D
exec(open("../../bk/newbody_defs.py", encoding="utf-8").read(), globals())
_src = open("../../bk/mk_statue_obj11.py", encoding="utf-8").read()
_i0 = _src.index("rnd.seed("); _i1 = _src.index("LABEL = ['Physique']")
exec(_src[_i0:_i1])            # CORE, CLEAN, KO ...
CORE = {k: v for k, v in CLEAN.items() if k != "apex siren"}
bs = open("gen_bundle_statue.py", encoding="utf-8").read()
bs = bs.replace("os.chdir('/home/claude/glassface'); ", "")
bs = bs[:bs.index("# ----- 배정 -----")]
exec(bs)                        # S, X, Y, GR, solo(), R ...
for ns in (S, X, Y, GR):
    ns["PHYS"][:] = [v.rstrip(".") + "." for v in CORE.values()]
rev = {v.rstrip(".") + ".": k for k, v in CORE.items()}
PLV = {"hip": ["P25", "P50", "P100", "P150", "P200"], "demi": ["P8", "P25", "P50", "P100", "P150"], "tq": ["P8", "P25", "P50", "P100"]}
R.seed(20261015)
plan = [("single", "hip"), ("single", "tq"), ("mix5", "demi"), ("mix5", "tq"), ("split3", "hip"), ("split3", "demi")]
A_OLD = "no calves, no feet, nothing continues below either tip"
A_NEW = "no calves, no feet, no shins, no ankles and no real skin legs of any kind — below each rounded tip there is only the glossy floor, nothing continues below either tip"
SW_OLD = "resting side by side on the surface beneath her"
SW_NEW = "resting directly on the polished floor with a soft contact shadow"
L = ["# LumineX — 피어싱 석상 × Core 체형 샘플 6종\n", "기존 Piercing Statue 틀에서 체형만 Core 체형으로 바꿨고, 바닥에 닿는 문구와 쓰리쿼터 보강 문장을 넣었습니다. 번호별로 성공/실패만 알려주세요.\n"]
for n, (st, fr) in enumerate(plan, 1):
    P = R.choice(PLV[fr]); title, p, meta = solo(fr, st, P, n)
    if SW_OLD in p: p = p.replace(SW_OLD, SW_NEW, 1)
    if fr == "tq":
        if A_OLD in p: p = p.replace(A_OLD, A_NEW, 1)
        else:
            _e = SW_NEW + "."
            assert _e in p; p = p.replace(_e, SW_NEW + ", with no shins, no ankles and no real skin legs of any kind — below each rounded tip there is only the glossy floor.", 1)
    nm = next((rev[k] for k in rev if k.rstrip(".") in p), None)
    assert nm, "체형 매칭 실패"
    title = re.sub(r"체형 [^·]*·", f"체형 {KO[nm]} ·", title, count=1)
    print(n, FRKO[fr], P, st, nm, len(p.split()), SW_NEW in p, ("no shins" in p) if fr == "tq" else "-")
    L.append(f"## {n}. {title}\n\n```\n{p}\n```\n")
open("/mnt/user-data/outputs/LumineX_PiercingStatue_Core6.md", "w", encoding="utf-8").write("\n".join(L))
