# -*- coding: utf-8 -*-
# 소재 축 신규 샘플 6개: 선 몸(철사·철근·네온 튜브) 3 + 모래시계 용기 몸 3 — 조각상 프레임 컷 틀, 피어싱 없음, Core 체형
import re, sys, random, json
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity"); sys.path.insert(0, "../../master")
_g = open("gen_pierce_statue.py", encoding="utf-8").read()
exec(_g[:_g.index("def build(")])
import mdefs as D
exec(open("../../bk/newbody_defs.py", encoding="utf-8").read(), globals())
rnd.seed(20262003)
# ── Core 체형 (키 큰 쪽 제외: 다리 길이 문장이 무릎·허벅지 끝 컷과 충돌) ──
_NBd = [b[1] for b in D.BODIES if b[0] == "Nubian booty builder"][0]
_NBB = _NBd.replace("wide flaring lats", "a full, heavy, firm bust standing out on her chest").replace("a deeply carved abdomen with sharp obliques", "a deeply carved six-pack abdomen with sharp obliques")
CORE = ["legendary bust", "curved bust", "siren bust hourglass", "glamour hourglass", "hourglass bombshell", "black glamour", "apex siren", "violin hip hourglass", "latina curves", "Brazilian booty glam",
        "muscular hourglass BBW", "hourglass SSBBW", "USSBBW", "Nubian booty builder", "powerlifter bombshell", "Nubian bust builder"]
POOL = {b[0]: b[1] for b in D.BODIES}; POOL.update({nm: desc for nm, ko, kod, desc in NB}); POOL["Nubian bust builder"] = _NBB
TAILRE = re.compile(r";?\s*her arms, hands, legs and feet stay in correct proportion to each other\s*$")
FLAG = re.compile(r"\b(feet|ankle|ankles|calves|calf|knee|knees|stilt|tall|towering|height|pressing together|pressed together|long legs|legs)\b", re.I)
SWAPS = [(", thighs pressing together", ""), ("thighs pressing together, ", ""), ("thighs pressed together", "thighs"), (", thick heavy calves", ""), ("sagging down toward her knees", "sagging down over her thighs"),
         ("past the line of her own knees", "past the line of her own thighs"), (", and diamond-shaped calves", ""), (" and diamond-shaped calves", ""), ("thick hamstrings,", "thick hamstrings"), ("a visible teardrop shape above each knee", "a visible teardrop shape above each thigh end")]
CLEAN = {}; DROP = {}
for nm in CORE:
    d = TAILRE.sub("", POOL[nm]).strip().rstrip(";,. ")
    for a, b in SWAPS: d = d.replace(a, b)
    f = FLAG.findall(d)
    if f: DROP[nm] = sorted(set(x.lower() for x in f))
    else: CLEAN[nm] = d
print("제외(프레임 컷과 충돌):", DROP)
KO = {"legendary bust": "레전더리 바스트", "curved bust": "커브드 바스트", "siren bust hourglass": "사이렌 바스트 아워글래스", "glamour hourglass": "글래머 아워글래스", "hourglass bombshell": "아워글래스 밤쉘", "black glamour": "블랙 글래머", "apex siren": "에이펙스 사이렌",
      "violin hip hourglass": "바이올린 힙 아워글래스", "latina curves": "라티나 커브스", "Brazilian booty glam": "브라질리언 부티 글램", "muscular hourglass BBW": "머스큘러 아워글래스 BBW", "hourglass SSBBW": "아워글래스 SSBBW", "USSBBW": "USSBBW", "Nubian booty builder": "누비안 부티 빌더", "powerlifter bombshell": "파워리프터 밤쉘", "Nubian bust builder": "누비안 바스트 빌더"}
# ── 새 소재 ──
FIT = "carved as one solid sculpted mass like a statue, never hollow, with no gaps and no skin anywhere, every wrist, palm, finger and knuckle the same material"
FIT = "built as one open lattice sculpture like a statue, with no real body, no skin and no flesh anywhere inside or beneath the wire — the wire figure is the entire torso, and only the backdrop shows through the gaps, every wrist, palm, finger and knuckle made of the same lines"
LINES = {
 "wire": ("철사", "ONE scribbled wire sculpture, like a three-dimensional drawing made of pencil-thick bright steel wire: dense scribbled and tangled loops of wire form every part of her figure — her chest, torso, both arms, both hands with every finger, and both thighs are nothing but tangled wire, with no solid surface and no real limb, chest or skin anywhere; the tangles are heavy and overlapping in the middle of each part and the backdrop shows through between the loops, with a ring of wire around her chest, her waist and her hips, each wire catching its own thin glint"),
 "rebar": ("철근", "ONE rebar sculpture, like a three-dimensional drawing made of thick ribbed steel rebar bars bent into the shape of her body: bundled and crossing rebar bars form every part of her figure — her chest, torso, both arms, both hands with every finger, and both thighs are nothing but rebar, with no solid surface, no concrete and no real limb, chest or skin anywhere; the bars are heavy and overlapping in the middle of each part and the backdrop shows through between them, with a ring of rebar hoops around her chest, her waist and her hips, bundled tie-wire lashed at every crossing and rust-orange stains on the bars"),
 "tube": ("네온 튜브", "ONE sculpture of bent glass neon tubes glowing in vivid electric pink and cyan, drawn as closely spaced flowing contour lines and rings that trace every curve of her form, with a second, shorter set of tubes curving inside the first so the body reads as a full, filled form of light you can still see into, small black electrode caps and thin cables at the tube ends"),
}
SANDS = [("금빛 모래", "fine warm golden desert sand"), ("미드나이트 블루 모래", "fine midnight-blue sand scattered with tiny silver sparkles"), ("로즈 모래", "fine soft rose-pink sand with pale pearl glints")]
GLASS = "The glass is unmistakably glass: thick, crystal-clear and polished, with bright specular reflections sliding along every curved surface, sharp white highlights and dark refraction edges where the walls are thickest, tiny bubbles trapped in the glass itself. Her shoulders, chest, belly, hips and both thighs keep their exact sculpted shapes as clear glass outlines, and a clean glass rim runs along the boundary where the vessel meets the neck."
def body_line(key):
    nm, desc = LINES[key]
    return (f"{LIST} — is not painted, covered or clothed but physically made of {desc}, {FIT}.", nm, False)
GLASS2 = "The glass is unmistakably glass: thick, crystal-clear and polished, with bright specular reflections sliding along its curved walls, sharp white highlights and dark refraction edges where the walls are thickest, tiny bubbles trapped in the glass itself."
SIL = {"siren bust hourglass": "an enormous upper bulb as her bust, an impossibly narrow glass neck, a full lower bulb",
       "legendary bust": "a gigantic upper bulb projecting far forward as her bust, a very narrow glass neck, a full lower bulb",
       "glamour hourglass": "a full round upper bulb as her bust, a sharply narrow glass neck, a wide curvaceous lower bulb",
       "violin hip hourglass": "a modest round upper bulb as her bust, a narrow glass neck, a very wide lower bulb",
       "latina curves": "a full round upper bulb as her bust, a narrow glass neck, an equally full lower bulb",
       "Brazilian booty glam": "a full round upper bulb as her bust, a narrow glass neck, a huge rounded lower bulb that dominates the silhouette"}
def body_hour(i):
    nm, sand = SANDS[i]
    return (f"Below the collarbones there is no human torso at all: in its place her entire torso is a giant real hourglass of thick, crystal-clear glass, and the hourglass itself is the torso. Its shape is the whole silhouette from the collarbones to the thigh ends — {{SIL}}. The upper glass bulb is shaped as her bust, the narrow glass neck is the only thing left of her waist, and the lower glass bulb is her belly and hips and runs on into both thighs. Her arms are plain clear glass limbs with solid glass hands. {GLASS2} {sand.capitalize()} pours in a thin steady stream from the upper bulb through the glass neck and heaps in a smooth cone in the lower bulb. There is nothing inside the glass but sand, nothing behind it but the backdrop — no body, no skin, no second figure, no torso outline anywhere.", f"모래시계·{nm}", True)
def body_vessel(kind):
    if kind == "bulb":
        return (f"{LIST} — is not a body at all: her whole torso IS a giant vintage light bulb of thick, crystal-clear glass and nothing else. The round glass dome is her bust and ribcage, the glass narrows through her waist, and the lower glass swells into her belly and hips and continues into both thighs. A fine tungsten filament coils inside the glass from her chest down to her hips, glowing a warm orange-white with a soft halo around each coil. Her arms are plain clear glass limbs with solid glass hands. {GLASS2} There is no body, no torso outline and no skin anywhere — the bulb itself is the whole torso, and beyond its glass walls there is only the backdrop.", "전구", True)
    return (f"{LIST} — is not a body at all: her whole torso IS a giant lava lamp, a tall glass lamp body in the silhouette of her torso, filled completely with vivid translucent magenta liquid lit from within by a hot orange glow, in which big glowing orange and gold wax blobs slowly rise and sink, some stretching into soft teardrops, spread from her chest down through her hips; a polished brass cap closes the lamp at her collarbones and a polished brass base cup caps the end of each thigh, with a warm glow spilling onto the floor beneath. Her arms are plain clear glass limbs with solid glass hands. {GLASS2} There is no body, no torso and no skin inside or behind the glass.", "라바 램프", True)
LABEL = ['Physique']
def build_new(frame, phys, body, mname, transparent, vessel, lattice=False):
    pname, pos, part = FR[frame]
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC) + 1)
    (ba, bb) = rnd.choice(BACKS)
    hair = f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}"
    tip = (f"{pos[0].upper()}{pos[1:]}, each thigh individually curves inward and " + ("seals shut into its own smooth, rounded, closed tip" if vessel else "rounds off into its own smooth, deeply polished tip") +
           " — the two thighs stay clearly separate all the way down, never merging" + (" or fusing" if vessel else ", fusing or tapering") + " into a single base — no calves, no feet, nothing continues below either tip — the " + ("vessel" if vessel else "material") + " simply reaching its natural end on each leg, both " + ("sealed " if vessel else "") + "rounded tips resting side by side on the surface beneath her.")
    if lattice:
        tip = (f"{pos[0].upper()}{pos[1:]}, each thigh individually curves inward and its lines gather into its own rounded closed end — the two thighs stay clearly separate all the way down, never merging into a single base — no calves, no feet, nothing continues below either end, both rounded ends resting directly on the polished floor with a soft contact shadow.")
        mid = "Transmission: everything below the collarbones is an open lattice with wide gaps, nothing inside it, so the backdrop and its light sources are visible straight through her body between the lines, while her real face, ears and neck are opaque living flesh. Her face stays completely opaque."
        light = f"Lighting: the glowing backdrop shines through the gaps of her open body, {ba} through one side and {bb} through the other. A soft frontal light falls on her face and ears only; a thin cool rim light traces her whole figure so every line of the lattice reads clearly. Only her face, ears and neck read as real skin."
    elif transparent:
        mid = "Transmission: everything below the collarbones is a transparent material that light passes through, while her real face, ears and neck are opaque living flesh that no light passes through. The background and its light sources are visible straight through her body, bent and tinted by the material, with bright refraction edges and soft coloured shadows. Her face stays completely opaque."
        light = f"Lighting: the glowing backdrop floods her body from behind, so {ba} passes through one side and {bb} passes through the other. A soft frontal light falls on her face and ears only; a thin cool rim light traces her whole figure. Only her face, ears and neck read as real skin."
    else:
        mid = "Material: everything below the collarbones is a completely dense solid with no gaps that no light passes through, while her real face, ears and neck are living flesh. The body blocks the backdrop's glow entirely, its surface catching the light with a hard, honest sheen and soft contact shadows, so it is unmistakable that the body itself is built from the material."
        light = f"Lighting: the glowing backdrop frames her whole silhouette from behind, {ba} on one side and {bb} on the other, while her dense body blocks it completely. A soft frontal light falls on her face and ears, and a thin cool rim light traces her whole figure so the surface of the material reads clearly. Only her face, ears and neck read as real skin."
    p = (f"Professional fashion photograph, {pname}. ONE woman, angled 45 degrees toward the camera, framed so her whole sculpted form is visible from the top of her head down to two individually rounded, deliberately finished tips {pos}, her face in natural scale with her body — never an oversized close-up crop of just the face. Where her sculpted form comes to an end at her {part}, it is because the sculpture itself ends there, not because a camera frame happens to cut her off.\n\n"
         f"Subject: A real photograph of a strikingly beautiful adult {nat} woman — {fa}, {hair}. {REAL_FACE}\n\n"
         f"{LABEL[0]}: {phys}.\n\nBody: {body} {tip}\n\n{mid}\n\n"
         f"Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. There is no line down the centre of her body. At that line, the material's edge rises in a small raised step above her flesh, casting a crisp shadow — her skin beside it stays smooth and even. The rounded tip is the material's own finish, always the clean, deliberate result of a sculpture — never the edge of a photograph.\n\n"
         f"Setting: a huge backdrop behind her washed with two coloured lights from behind — {ba} on one side and {bb} on the other, blending into a smooth gradient in the middle, and a glossy dark floor beneath her.\n\n"
         f"Pose: standing tall, her left hand (solid material) resting on her flared hip, her right arm held clear of her body with the hand (solid material) relaxed at hip height, both hands well away from her face, head tilted slightly toward the camera.\n\n{light} Shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait.")
    if frame == "tq":
        _t = "no calves, no feet, nothing continues below either end"
        assert _t in p
        p = p.replace(_t, "no calves, no feet, no shins, no ankles and no real skin legs of any kind — below each rounded end there is only the glossy floor, nothing continues below either end", 1)
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), p[:100]
    return p, f"메이크업 {mk}"
frames = ["hip", "demi", "tq"]
def frs(): f = frames[:]; rnd.shuffle(f); return f
fr1, fr2 = frs(), frs()
HOURB = [n for n in ["siren bust hourglass", "legendary bust", "glamour hourglass", "violin hip hourglass", "latina curves", "Brazilian booty glam"] if n in CLEAN]
hn = rnd.sample(HOURB, 3)
rest = rnd.sample([n for n in CLEAN if n not in hn], 5)
names = rest[:3] + hn + rest[3:]
if names[0] != 'powerlifter bombshell': names[0] = 'powerlifter bombshell'
L = ['Physique']
def build_new(frame, phys, body, mname, transparent, vessel, lattice=False):
    pname, pos, part = FR[frame]
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC) + 1)
    (ba, bb) = rnd.choice(BACKS)
    hair = f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}"
    tip = (f"{pos[0].upper()}{pos[1:]}, each thigh individually curves inward and " + ("seals shut into its own smooth, rounded, closed tip" if vessel else "rounds off into its own smooth, deeply polished tip") +
           " — the two thighs stay clearly separate all the way down, never merging" + (" or fusing" if vessel else ", fusing or tapering") + " into a single base — no calves, no feet, nothing continues below either tip — the " + ("vessel" if vessel else "material") + " simply reaching its natural end on each leg, both " + ("sealed " if vessel else "") + "rounded tips resting side by side on the surface beneath her.")
    if lattice:
        tip = (f"{pos[0].upper()}{pos[1:]}, each thigh individually curves inward and its lines gather into its own rounded closed end — the two thighs stay clearly separate all the way down, never merging into a single base — no calves, no feet, nothing continues below either end, both rounded ends resting side by side on the surface beneath her.")
        mid = "Transmission: everything below the collarbones is an open lattice with wide gaps, nothing inside it, so the backdrop and its light sources are visible straight through her body between the lines, while her real face, ears and neck are opaque living flesh. Her face stays completely opaque."
        light = f"Lighting: the glowing backdrop shines through the gaps of her open body, {ba} through one side and {bb} through the other. A soft frontal light falls on her face and ears only; a thin cool rim light traces her whole figure so every line of the lattice reads clearly. Only her face, ears and neck read as real skin."
    elif transparent:
        mid = "Transmission: everything below the collarbones is a transparent material that light passes through, while her real face, ears and neck are opaque living flesh that no light passes through. The background and its light sources are visible straight through her body, bent and tinted by the material, with bright refraction edges and soft coloured shadows. Her face stays completely opaque."
        light = f"Lighting: the glowing backdrop floods her body from behind, so {ba} passes through one side and {bb} passes through the other. A soft frontal light falls on her face and ears only; a thin cool rim light traces her whole figure. Only her face, ears and neck read as real skin."
    else:
        mid = "Material: everything below the collarbones is a completely dense solid with no gaps that no light passes through, while her real face, ears and neck are living flesh. The body blocks the backdrop's glow entirely, its surface catching the light with a hard, honest sheen and soft contact shadows, so it is unmistakable that the body itself is built from the material."
        light = f"Lighting: the glowing backdrop frames her whole silhouette from behind, {ba} on one side and {bb} on the other, while her dense body blocks it completely. A soft frontal light falls on her face and ears, and a thin cool rim light traces her whole figure so the surface of the material reads clearly. Only her face, ears and neck read as real skin."
    p = (f"Professional fashion photograph, {pname}. ONE woman, angled 45 degrees toward the camera, framed so her whole sculpted form is visible from the top of her head down to two individually rounded, deliberately finished tips {pos}, her face in natural scale with her body — never an oversized close-up crop of just the face. Where her sculpted form comes to an end at her {part}, it is because the sculpture itself ends there, not because a camera frame happens to cut her off.\n\n"
         f"Subject: A real photograph of a strikingly beautiful adult {nat} woman — {fa}, {hair}. {REAL_FACE}\n\n"
         f"{LABEL[0]}: {phys}.\n\nBody: {body} {tip}\n\n{mid}\n\n"
         f"Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. There is no line down the centre of her body. At that line, the material's edge rises in a small raised step above her flesh, casting a crisp shadow — her skin beside it stays smooth and even. The rounded tip is the material's own finish, always the clean, deliberate result of a sculpture — never the edge of a photograph.\n\n"
         f"Setting: a huge backdrop behind her washed with two coloured lights from behind — {ba} on one side and {bb} on the other, blending into a smooth gradient in the middle, and a glossy dark floor beneath her.\n\n"
         f"Pose: standing tall, her left hand (solid material) resting on her flared hip, her right arm held clear of her body with the hand (solid material) relaxed at hip height, both hands well away from her face, head tilted slightly toward the camera.\n\n{light} Shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait.")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), p[:100]
    return p, f"메이크업 {mk}"
frames = ["hip", "demi", "tq"]
def frs(): f = frames[:]; rnd.shuffle(f); return f
fr1, fr2 = frs(), frs()
HOURB = [n for n in ["siren bust hourglass", "legendary bust", "glamour hourglass", "violin hip hourglass", "latina curves", "Brazilian booty glam"] if n in CLEAN]
hn = rnd.sample(HOURB, 3)
rest = rnd.sample([n for n in CLEAN if n not in hn], 5)
names = rest[:3] + hn + rest[3:]
if names[0] != 'powerlifter bombshell': names[0] = 'powerlifter bombshell'
items = []
rr = rnd.sample(list(CLEAN), 4); fr4 = [rnd.choice(frames) for _ in range(4)]
for i, key in enumerate(["wire", "wire", "rebar", "rebar"]):
    b, mn, tr = body_line(key); p, mk = build_new(fr4[i], CLEAN[rr[i]], b, mn, True, False, lattice=True)
    items.append((FRKO[fr4[i]], KO[rr[i]], f"선 몸(열린 격자) · {mn}", mk, p))
L = ['Physique']
def build_new(frame, phys, body, mname, transparent, vessel, lattice=False):
    pname, pos, part = FR[frame]
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC) + 1)
    (ba, bb) = rnd.choice(BACKS)
    hair = f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}"
    tip = (f"{pos[0].upper()}{pos[1:]}, each thigh individually curves inward and " + ("seals shut into its own smooth, rounded, closed tip" if vessel else "rounds off into its own smooth, deeply polished tip") +
           " — the two thighs stay clearly separate all the way down, never merging" + (" or fusing" if vessel else ", fusing or tapering") + " into a single base — no calves, no feet, nothing continues below either tip — the " + ("vessel" if vessel else "material") + " simply reaching its natural end on each leg, both " + ("sealed " if vessel else "") + "rounded tips resting side by side on the surface beneath her.")
    if lattice:
        tip = (f"{pos[0].upper()}{pos[1:]}, each thigh individually curves inward and its lines gather into its own rounded closed end — the two thighs stay clearly separate all the way down, never merging into a single base — no calves, no feet, nothing continues below either end, both rounded ends resting side by side on the surface beneath her.")
        mid = "Transmission: everything below the collarbones is an open lattice with wide gaps, nothing inside it, so the backdrop and its light sources are visible straight through her body between the lines, while her real face, ears and neck are opaque living flesh. Her face stays completely opaque."
        light = f"Lighting: the glowing backdrop shines through the gaps of her open body, {ba} through one side and {bb} through the other. A soft frontal light falls on her face and ears only; a thin cool rim light traces her whole figure so every line of the lattice reads clearly. Only her face, ears and neck read as real skin."
    elif transparent:
        mid = "Transmission: everything below the collarbones is a transparent material that light passes through, while her real face, ears and neck are opaque living flesh that no light passes through. The background and its light sources are visible straight through her body, bent and tinted by the material, with bright refraction edges and soft coloured shadows. Her face stays completely opaque."
        light = f"Lighting: the glowing backdrop floods her body from behind, so {ba} passes through one side and {bb} passes through the other. A soft frontal light falls on her face and ears only; a thin cool rim light traces her whole figure. Only her face, ears and neck read as real skin."
    else:
        mid = "Material: everything below the collarbones is a completely dense solid with no gaps that no light passes through, while her real face, ears and neck are living flesh. The body blocks the backdrop's glow entirely, its surface catching the light with a hard, honest sheen and soft contact shadows, so it is unmistakable that the body itself is built from the material."
        light = f"Lighting: the glowing backdrop frames her whole silhouette from behind, {ba} on one side and {bb} on the other, while her dense body blocks it completely. A soft frontal light falls on her face and ears, and a thin cool rim light traces her whole figure so the surface of the material reads clearly. Only her face, ears and neck read as real skin."
    p = (f"Professional fashion photograph, {pname}. ONE woman, angled 45 degrees toward the camera, framed so her whole sculpted form is visible from the top of her head down to two individually rounded, deliberately finished tips {pos}, her face in natural scale with her body — never an oversized close-up crop of just the face. Where her sculpted form comes to an end at her {part}, it is because the sculpture itself ends there, not because a camera frame happens to cut her off.\n\n"
         f"Subject: A real photograph of a strikingly beautiful adult {nat} woman — {fa}, {hair}. {REAL_FACE}\n\n"
         f"{LABEL[0]}: {phys}.\n\nBody: {body} {tip}\n\n{mid}\n\n"
         f"Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. There is no line down the centre of her body. At that line, the material's edge rises in a small raised step above her flesh, casting a crisp shadow — her skin beside it stays smooth and even. The rounded tip is the material's own finish, always the clean, deliberate result of a sculpture — never the edge of a photograph.\n\n"
         f"Setting: a huge backdrop behind her washed with two coloured lights from behind — {ba} on one side and {bb} on the other, blending into a smooth gradient in the middle, and a glossy dark floor beneath her.\n\n"
         f"Pose: standing tall, her left hand (solid material) resting on her flared hip, her right arm held clear of her body with the hand (solid material) relaxed at hip height, both hands well away from her face, head tilted slightly toward the camera.\n\n{light} Shot on a Hasselblad X2D with an 85mm lens, shallow depth of field. 2:3 vertical 8K portrait.")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), p[:100]
    return p, f"메이크업 {mk}"
frames = ["hip", "demi", "tq"]
def frs(): f = frames[:]; rnd.shuffle(f); return f
fr1, fr2 = frs(), frs()
HOURB = [n for n in ["siren bust hourglass", "legendary bust", "glamour hourglass", "violin hip hourglass", "latina curves", "Brazilian booty glam"] if n in CLEAN]
hn = rnd.sample(HOURB, 3)
rest = rnd.sample([n for n in CLEAN if n not in hn], 5)
names = rest[:3] + hn + rest[3:]
if names[0] != 'powerlifter bombshell': names[0] = 'powerlifter bombshell'
items = []
pool = [n for n in CLEAN]
rr = rnd.sample(pool, 4); fr4 = [frames[0], frames[1], frames[2], rnd.choice(frames)]
for i, key in enumerate(["wire", "wire", "rebar", "rebar"]):
    b, mn, tr = body_line(key); p, mk = build_new(fr4[i], CLEAN[rr[i]], b, mn, True, False, lattice=True)
    t1 = "both rounded ends resting side by side on the surface beneath her."
    assert t1 in p
    p = p.replace(t1, "both rounded ends resting directly on the polished floor with a soft contact shadow.", 1)
    if fr4[i] == "tq":
        t2 = "no calves, no feet, nothing continues below either end"
        assert t2 in p
        p = p.replace(t2, "no calves, no feet, no shins, no ankles and no real skin legs of any kind — below each rounded end there is only the glossy floor, nothing continues below either end", 1)
    items.append((FRKO[fr4[i]], KO[rr[i]], f"선 몸(열린 격자) · {mn}", mk, p))
L = ["# LumineX — 선 몸 수정본 4종 (철사 2 · 철근 2)\n", "조각상 프레임 컷 틀에서 피어싱은 없이, 체형은 Core 체형(키 큰 쪽 제외)에서 랜덤입니다. 번호별로 성공/실패만 알려주세요.\n"]
for i, (fr, bd, mt, mk, p) in enumerate(items, 1):
    L.append(f"## {i}. {fr} · {bd} · {mt} · {mk}\n\n```\n{p}\n```\n")
open("/mnt/user-data/outputs/LumineX_Material_WireRebar4.md", "w", encoding="utf-8").write("\n".join(L))
for fr, bd, mt, mk, p in items: print(fr, bd, mt, len(p.split()))
