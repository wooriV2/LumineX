import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
from cover_lib import SAFE
HEAD="Professional fashion photograph, close-up beauty portrait. ONE woman, facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp. Mid 20s."
HEAD_W=HEAD.replace("down to the base of her neck and the tops of her collarbones, the frame cutting off there","down to her collarbones and the tops of her shoulders, the frame cutting off there, so the earrings fully hang in view")
TAIL=" Every feature is exaggerated but beautiful, balanced and refined, in harmony with the rest of her face, never distorted, never grotesque. Real skin fine grain and a soft sheen of natural oils on her face, ears and neck, individual hair strands catching the light — a photograph of a real woman, not an illustration, not a render."
SK="The skin around every piece is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
IRON="rough black cast iron with a hammered, pitted, matte surface"
def sub(txt): return "Subject: "+txt+TAIL



def eyesub(face,eyes,brows,rest):
    return sub("A real photograph of a strikingly beautiful adult woman, mid 20s, "+face+" Her eyes are the star of her face: "+eyes+" "+brows+" "+rest+" Looking straight into the camera.")
def pier(mat,desc,col):
    return ("Piercings: Exactly six piercings in total, symmetrical: on each ear a large "+desc+" hoop in the lobe and two matching studs up the rim. Each piece is large and clearly visible, and nothing else on the face is pierced. "+SK+" All jewelry is real "+mat+","+SAFE)
V=[("사이렌 눈 — 중동계(페르시아·아랍풍) · 길고 올라간 눈·콜 아이라인·진한 눈썹 · 골드+에메랄드 피어싱 6",
    eyesub("a Middle Eastern woman with warm olive skin and long glossy black hair.","long, narrow, strongly upturned siren eyes with the outer corners lifted high toward the temples, a catlike inner point, thick smoky black kohl liner on the waterline and a long straight wing, in luminous deep amber contact lenses with a big visible iris, both eyes the same, with a round natural pupil and bright catchlights.","Strong, thick, sharply arched dark brows.","Full lips in deep rosewood, a straight slender nose and high cheekbones. A sultry, powerful gaze."),
    pier("polished yellow gold set with green emeralds","gold with a green emerald",1)),
   ("도 아이 — 서양인(북유럽풍) · 둥글고 넓은 눈·긴 속눈썹·연한 금발 · 은+진주 피어싱 6",
    eyesub("a Western woman with very fair skin, a light pink blush and long soft platinum-blonde hair.","huge, perfectly round, wide, innocent doe eyes with a very large visible iris, with a soft white inner liner along the lower lash line and a small softly shaded flick under the lower lashes, in sky-blue contact lenses, both eyes the same, with a round natural pupil and bright catchlights.","Very long, thick, curled lashes and soft, gently rounded, pale brows.","Soft pink lips, a tiny straight nose and rosy rounded cheeks. A sweet, wide-eyed gaze."),
    pier("polished sterling silver set with white pearls","silver with a white pearl",1)),
   ("반쯤 감긴 묵직한 눈 — 남유럽·라틴풍 · 무거운 눈꺼풀·스모키·긴 속눈썹 · 블랙 스틸 피어싱 6",
    eyesub("a Mediterranean woman with warm golden-bronze skin and long, thick, dark chestnut waves.","heavy-lidded, half-lowered, smouldering eyes with a deep-set heavy upper lid covering part of the iris, dramatic smoky brown-black eyeshadow blended up to the brow bone, thick long curled lashes and a soft winged liner, in rich dark-brown contact lenses with a little warm hazel glow, both eyes the same, with a round natural pupil and bright catchlights.","Full, strong, softly arched dark brows.","Full lips in warm brick-rose, a straight nose and a strong defined jaw. A lazy, sensual gaze."),
    pier("blackened steel","black steel",1)),
   ("애교살·도톰 쌍꺼풀 눈 — 한국 · 부드러운 눈 아래 애교살·반짝이는 눈웃음 · 로즈골드+핑크 피어싱 6",
    eyesub("a Korean woman with luminous fair skin, soft see-through bangs and long dark-brown hair.","large, soft, gently smiling eyes with a clearly defined double eyelid, a plump, rounded 'aegyo-sal' fat roll under each eye that makes the lower lids puff up and sparkle, a lightly shimmering pink-champagne shadow, in soft brown doll-eye contact lenses, both eyes the same, with a round natural pupil and bright catchlights.","Soft, gently straight, slightly low brows.","Soft pink lips in a gentle smile, a small straight nose and a slim V-line chin. A warm, smiling gaze."),
    pier("polished rose gold with pastel-pink enamel","rose-gold with pastel-pink enamel",1)),
   ("옆트임 눈 — 중국 · 바깥으로 길게 트인 눈·큰 홍채·또렷한 아이라인 · 골드+제이드 피어싱 6",
    eyesub("a Chinese woman with luminous porcelain skin and long straight glossy black hair.","surgically widened eyes: lateral canthoplasty has extended the outer corners of both eyes outward toward the temples, so each eye opening is very long and wide, showing a large amount of the iris, with a crisp, sharp black eyeliner following the extended shape and a clean double eyelid, in large dark-brown doll-eye contact lenses with a slight glossy shine, both eyes the same, with a round natural pupil and bright catchlights.","Slim, clean, softly arched dark brows.","Soft rose lips, a straight refined nose and a slim V-line jaw. A cool, intense gaze."),
    pier("polished yellow gold set with green jade","gold with green jade",1))]
o=["# LumineX — 눈 5종 × 인종 매칭 (정면)\n","- 사이렌·중동계 / 도 아이·서양인 / 반쯤 감긴 눈·남유럽 / 애교살·한국 / 옆트임·중국. 눈이 주인공이라 피어싱은 양쪽 귀 6개로 절제. 모두 성인.","- 정상/이상(+ 눈 모양 특징이 보이는지)만 번호로 알려주세요.\n"]
for i,(lab,sj,p) in enumerate(V,1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(82000+i*100+tr),"한국","20대","도도한",style="NONE",slots=["pierce"],pier_level="P5"); break
        except AssertionError: continue
    else: raise SystemExit(i)
    ps=t.split("\n\n")
    depth=[x for x in ps if x.startswith("Piercing depth:")][0]; light=[x for x in ps if x.startswith("Lighting:")][0]
    new="\n\n".join([HEAD,sj,p,depth,light]); assert not re.search(r"[가-힣]",new)
    o.append(f"## {i}. {lab}\n\n```\n{new}\n```\n")
open('/mnt/user-data/outputs/LumineX_Eyes5_Ethnic_5.md','w',encoding='utf-8').write("\n".join(o)); print("ok")
