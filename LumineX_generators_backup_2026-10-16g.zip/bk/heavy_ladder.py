import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
from cover_lib import SAFE,w,counts,pl
G.STEP_IDX.update({"고스 블랙립":[4],"뱀파이어 다크":[4]})
IRON="rough black cast iron with a hammered, pitted, matte surface"
W=["a solid rough cube-shaped block","a solid rough cannonball","a chunky solid hexagonal block","a solid thick rectangular ingot block","a short thick solid cylinder stump","a solid pyramid-shaped lump with a wide base","a small solid kettlebell with a thick short handle","a solid squat hammer head block","a thick solid disc like a weight plate","a solid rough boulder-like lump"]
COL={8:"3, 3 and 2",9:"3, 3 and 3",10:"4, 3 and 3"}
def ears(nw,rr):
    out=[]
    for side in ("left","right"):
        sh=rr.sample(W,nw)
        out.append(f"on the {side} ear "+", ".join(f"{s} on its own thick chain of heavy black iron links" for s in sh))
    return "; ".join(out)
HW=("On each ear the chains hang from this one ring in three side-by-side columns of {col} weights, staggered at different heights so every weight is fully visible and none hides another. Every single weight is an enormous, dense, completely solid, squat, blunt lump of rough black cast iron, as big as a fist or larger, with no thin parts, no arms and no hollow parts; its size does NOT shrink just because there are many of them: the last weight is exactly as big, as thick and as heavy-looking as the first. Each weight alone looks like it weighs several kilograms, each chain is pulled bar-straight and taut, and at a glance every single one looks crushingly, unmistakably heavy. Together they drag each earlobe down hard into a very long, thin, taut, stretched loop of skin that hangs past the jaw, along the whole neck and past the collarbone down to the line of her shoulders, her head tilting slightly under the load; the stretch is long but natural and the loop stays smooth and intact, fully healed, with no tearing, no wound, no blood and no redness.")
def rim(n):
    if n<=3: return f"{w(n)} thick classic round O-rings and studs along the helix rim above the lobe"
    a=max(1,round(n*.5)); b=max(1,round(n*.3)); c=max(0,n-a-b)
    return f"{w(n)} pieces above the lobe: {w(a)} classic round O-rings and studs along the helix rim, {w(b)} studs and small bars across the upper cartilage"+(f" and {w(c)} in the conch and tragus" if c else "")
def para(N,nw,metal,gems,deco,rr):
    c=counts(N); seg=[]
    seg.append(("a single large " if c["sep"]==1 else f"{w(c['sep'])} separate ")+"septum ring"+("" if c["sep"]==1 else "s")+" of different sizes and shapes through the thin soft wall between the nostrils, in a short stack that ends above the upper lip")
    h=c["nos"]//2; seg.append(f"{pl(h,'small ring')} wrapping snugly around each nostril wing")
    seg.append(f"{pl(c['bri'],'straight bar')} across the bridge of the nose, from just below the inner ends of the brows (well clear of the eyes) down to the middle of the nose, each with a gem cap at both ends")
    h=c["brow"]//2; seg.append(f"{pl(h,'small bar or ring')} through each eyebrow, all on the brow bone above the eyes and never on the eyelids")
    seg.append(f"{pl(c['ul'],'small hoop or stud')} along the edge of the upper lip")
    seg.append(f"{pl(c['ll'],'small hoop or stud')} across the lower lip's edge")
    seg.append(f"{pl(c['chin'],'small ring or stud')} on the chin")
    h=c["ear"]//2
    seg.append(f"on each ear, one very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel, passes through one large healed opening in the stretched lobe, and above it sit {rim(h-1)}")
    seg.append(f"{pl(c['fh'],'small stud')} across the lower half of the forehead just above the brows in even rows, leaving the upper forehead free")
    h=c["tmp"]//2; seg.append(f"{pl(h,'small stud')} on each temple bone, well clear of the eyes")
    h=c["chk"]//2; seg.append(f"{pl(h,'small stud')} along each cheekbone, well clear of the eyes")
    tot=sum(c.values())
    dens=("The piercings are packed so densely that the rows touch and overlap, leaving only hairline gaps of bare skin between them, until the face reads as a single armour of metal; the eyes and eyelids stay clear. " if N>=100 else "The pieces are spread over the whole face in clear rows so every one reads individually, with bare skin between them; the eyes and eyelids stay clear. ")
    heavy=f"All the weights hang from the bottom of each lobe's one iron ring, and they are not counted in the piercing total: on each ear there are exactly {w(nw)} separate massive solid weights, each of a different shape: "+ears(nw,rr)+". "+HW.format(col=COL[nw])
    return (f"Piercings: A face fully covered with real piercings, about {w(tot)} in total (not counting the hanging weights), spread over every area so that no area is empty: "+"; ".join(seg)+". The left and right sides are balanced. "+dens+deco+" "+heavy+f" The face and ear jewelry is real {metal} set with {gems}, while the hanging weights are always black cast iron,"+SAFE),tot
HENNA="Henna: fine metallic gold henna mehndi line patterns of vines and dots are painted across the upper forehead near the hairline only, above the forehead studs, well clear of the eyes and brows."
STICK="Stickers: five tiny glow-in-the-dark heart and star stickers are scattered flat on the skin of the lower cheeks and the jawline below the cheekbone studs, clear of the piercings, the eyes and the lips."
TH={"수수":("blackened steel","small clear diamonds, one-colour, restrained"),"화려":("mixed yellow gold, silver and rose gold","glossy multicoloured enamel and rainbow gemstones"),"귀여움":("pastel-enamelled gold","white pearls, pastel gemstones, hearts and stars")}
PL=[(25,8,"귀여움","한국","아이돌","발랄한","아마갸루",STICK,"스티커+렌즈+아마갸루 메이크업"),
    (50,8,"수수","일본","20대","냉혹한","고스 블랙립","","렌즈+어두운 립(고스 블랙립)"),
    (100,9,"화려","중국","20대","섹시한","NONE",HENNA,"헤나+렌즈, 메이크업 없음"),
    (150,10,"수수","한국","30대","군림하는","뱀파이어 다크",STICK,"스티커+렌즈+어두운 메이크업(뱀파이어 다크)"),
    (200,10,"화려","일본","아이돌","카리스마 있는","NONE",HENNA+" "+STICK,"헤나+스티커+렌즈, 메이크업 없음")]
o=["# LumineX — 무거운 귀걸이(추 8~10개) × 피어싱 P25·P50·P100·P150·P200 (5개)\n",
"- 기준: 귓볼마다 굵은 무쇠 링 1개(터널 없음) + 뭉툭한 무쇠 추 8~10개(어깨선까지 늘어짐). 추는 피어싱 합계에 포함하지 않음. 얼굴 전체 채우기(빈 부위 없음), 코 사이 최대 3개(윗입술 위에서 끝남), 귀 한쪽 최대 30개 이내.",
"- 테마: 25=귀여움, 50=수수, 100=화려, 150=수수, 200=화려. 수수·귀여움은 메이크업 포함(P50 이상은 어두운 립 계열만), 화려는 메이크업 없음. 프레임은 어깨 윗부분까지 넓히고 머리는 귀 뒤로.",
"- 정상/이상(+ 추가 8~10개 나오는지, 렌즈·헤나·스티커 보이는지)만 번호로 알려주세요.\n"]
for i,(N,nw,v,nat,grp,ex,sty,deco,lab) in enumerate(PL,1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(52000+i*100+tr),nat,grp,ex,style=sty,slots=["pierce","lens"],pier_level="P150" if N>=100 else ("P50" if N>=50 else "P25")); break
        except AssertionError: continue
    else: raise SystemExit(N)
    metal,gems=TH[v]
    pp=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    new,tot=para(N,nw,metal,gems,deco,random.Random(53000+i))
    t=re.sub(r'\n\nJewelry:[^\n]*','',t.replace(pp,new))
    t=t.replace("\n\nLighting:","\n\nHair: her hair is swept back behind both ears, leaving both ears, her jawline and her neck fully visible so every iron weight hangs in clear view.\n\nLighting:",1)
    t,nn=re.subn(r'down to the base of her neck and the tops of her collarbones, the frame cutting off there','down to the line of her shoulders, the frame cutting off just below them, so the weights fully hang in view',t,count=1); assert nn==1
    assert not re.search(r"[가-힣]",t)
    o.append(f"## P{N}-{v} (추 {nw}개/귀 · {lab}) — {title} · 피어싱 합계 약 {tot}개\n\n```\n{t}\n```\n"); print(N,tot,len(t.split()))
open('/mnt/user-data/outputs/LumineX_HeavyEarrings_P25to200_5.md','w',encoding='utf-8').write("\n".join(o))
