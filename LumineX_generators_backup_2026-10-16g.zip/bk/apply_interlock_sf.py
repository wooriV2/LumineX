# -*- coding: utf-8 -*-
# 실버폭스 Material Blend 180: 흐릿한 전환 구역 문장 → 맞물림 경계 문장(변형 C)으로 교체, 보호 문장 삭제.
import json, re
O = "/mnt/user-data/outputs/"
PROT = re.compile(r" Even inside a transition zone the skin is never left bare: at every point one material, or a mixture of the two, fully covers it\.?")
S12 = re.compile(r"The boundaries between regions are hazy and feathered — there is no visible line at all\. Each transition zone is about a hand's width wide, and across it .*?never a hard edge\.", re.S)
NEW = ("Where two regions meet, the materials interlock naturally: elements of one reach into the other and the two materials simply touch, "
       "so the boundary is made only of the two neighbouring materials, each in its own colours, with no gap between them.")
def C(t):
    n = t.count("The boundaries between"); t, a = PROT.subn("", t); t, b = S12.subn(NEW, t); assert a == b == n >= 1, (a, b, n)
    t = t.replace("course.,", "course,"); assert ".," not in t and not re.search(r"\b(\w+) \1\b", t) and "hand's width" not in t and "dissolve" not in t
    return t
B = json.load(open(O + "la_silverfox_blend_180_bundle.json", encoding="utf-8"))
for p in B:
    p["prompt"] = C(p["prompt"]); p["meta"]["boundary"] = "interlock-v1"
json.dump(B, open(O + "la_silverfox_blend_180_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1); print(len(B))
