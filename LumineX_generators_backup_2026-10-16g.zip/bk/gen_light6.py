# -*- coding: utf-8 -*-
# 조명 · 시간대 · 분위기 섞기 시험 6개
import re, random, sys, json
sys.path.insert(0, "../bg")
src6 = open("gen_persona6.py", encoding="utf-8").read()
exec(src6[:src6.index("PERS = {}")])
rp = random.Random(20261030)
PERS = {}
orig_disp3 = disp3
SNAKE = "a mass of dozens of thick coiling snakes carved from the same {m}, each snake with a detailed head, open eyes and a flicking tongue, writhing around her head and falling down her back, the snakes are her hair"
def disp4(label, kind, pick, phys, age, pose, eth, heel_in):
    pe = PERS.get(label)
    HAIRO[0] = pe[1] if pe else None
    t, info, nm = orig_disp3(label, kind, pick, phys, age, pose, eth, heel_in)
    if pe and pe[1] and kind not in NEWV and kind not in PAINT:
        t, n = re.subn(r', ([^,—]+?) hair — ', f', {pe[1]} — ', t, count=1); assert n == 1
    if pe and pe[0]:
        t, n = re.subn(r" goddess, ", f", {pe[0]}, ", t, count=1); assert n == 1
    return t, info, nm
ns2["person"] = disp4
ETHD = {e[0]: e for e in ETH}
CONC = {c[0]: (c[1], c[2]) for v in P.values() for c in v}
# (재질들, 컨셉들, 배경 id, 조명, 시간대, 분위기, 설명)
L = {"rim": "strong rim backlight, silhouette definition, halo effect", "chiaro": "dramatic chiaroscuro, deep shadows and sharp highlights",
     "hardsun": "harsh direct sunlight, strong sharp shadows, high contrast", "gold": "golden hour warm backlight, skin luminosity, glowing",
     "pool": "underwater pool light reflection, rippling aqua light patterns", "moon": "moonlight, silvery blue natural light, mysterious outdoor glow"}
T = {"dusk": "dusk twilight, dramatic sunset colors, sky ablaze with color", "noon": "midday harsh sunlight, strong direct light, sharp shadows, high contrast",
     "morning": "morning golden hour, soft warm early sunlight, fresh dewy atmosphere", "night": "deep night, a dark sky overhead"}
M = {"romantic": "romantic mood, soft warm atmosphere, tender feminine editorial", "powerful": "powerful commanding mood, intense dominant atmosphere, fierce editorial",
     "dreamy": "dreamy ethereal mood, soft romantic atmosphere, fantasy editorial", "serene": "serene tranquil mood, peaceful calm atmosphere, meditative editorial",
     "luxury": "luxury opulent mood, sophisticated elegant atmosphere, high-end editorial", "mystery": "mysterious alluring mood, enigmatic atmosphere, captivating editorial"}
KEEP = ", her whole figure from the boots to the top of her head clearly lit and fully visible with every material detail sharp"
PLAN = [(["jade"], ["선녀"], "chinese_garden", "rim", "dusk", "romantic", "황혼 + 림라이트 + 로맨틱"),
        (["bronze"], ["발키리"], "canyon", "hardsun", "noon", "powerful", "정오 + 하드 직사광 + 파워풀"),
        (["amber"], ["오슌"], "waterfall", "gold", "morning", "dreamy", "아침 골든아워 + 골든 백라이트 + 몽환"),
        (["coral"], ["예마야"], "pool", "pool", None, "serene", "실내 + 수중 물빛 반사 + 세레니티"),
        (["porcelain", "lacquer"], ["낙신", "경국지색"], "opera_stairs", "chiaro", None, "luxury", "실내 + 키아로스쿠로 + 럭셔리"),
        (["stone"], ["메두사"], "parthenon", "moon", "night", "mystery", "심야 + 달빛 + 미스터리")]
o = ["# 조명 · 시간대 · 분위기 섞기 시험 (6개)\n", "배경 라이브러리의 장소 하나씩을 고르고, 조명·시간대·분위기를 한 줄씩 얹었다. 기존의 '밝고 고르게 비춤' 문구는 조명 문구로 바꿨고, 밤·황혼은 인물 전체가 또렷이 보이도록 한 줄을 더했다. 컨셉·포즈·헤어는 앞 번들과 같다.\n"]
for i, (kinds, cons, bid, lt, tm, md, desc) in enumerate(PLAN, 1):
    n = len(kinds)
    PERS.clear(); CUR_VAR.clear(); picks = []; eths = []; infos_p = []
    for idx, k in enumerate(kinds):
        lab = f"#{idx+1}" if n > 1 else None
        en, ethn = CONC[cons[idx]]; eths.append(ETHD[ethn])
        if k in NEWV: v = rp.choice(NEWV[k]); CUR_VAR[(lab, k)] = v; picks.append(v)
        else: picks.append(rp.choice(STONES) if k == "stone" else rp.choice(WOODS))
        hb = rp.choice(HAIRB) if ethn in ("ebony", "blue-black") else None
        if cons[idx] == "메두사": hb = SNAKE.format(m=picks[-1][1])
        PERS[lab] = (en, hb); infos_p.append(f"{KO[k]}={cons[idx]}")
    for attempt in range(100):
        physs = []
        while len(physs) < n:
            c = rp.choices(BIG5, W5)[0]
            if c not in physs: physs.append(c)
        ages = [rp.choice(AGES) for _ in range(n)]; poses = rp.sample([p for p in NEWPOSES if "camera" not in p and "back" not in p], n)
        scene = BGL.BG[bid][3]
        if tm in ("dusk", "night"): scene = re.sub(r"\b(sunlit|sunny|bright|midday) ", "", scene)
        HEELMODE[0] = "forty"; ns2["JR"].seed(rp.randrange(10**9))
        t, infos = build3(kinds, picks, physs, ages, poses, eths, scene)
        t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as " + ("her" if n == 1 else "any of them") + ".", 1)
        add = L[lt] + (", " + T[tm] if tm else "") + ", " + M[md] + (KEEP if tm in ("dusk", "night") or lt == "chiaro" else "")
        t, nn = re.subn(r", bright and evenly lit, shadows soft,", ", " + add + ",", t, count=1); assert nn == 1, "env"
        if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t): continue
        break
    else: raise SystemExit("fail")
    assert t.count("forty inches") == n
    o.append(f"## {i}. {({1:'솔로',2:'듀오'})[n]} · {' / '.join(infos_p)} · {desc} · 배경 {BGL.BG[bid][2]} · 포즈 {' / '.join(p.split(',')[0] for p in poses)}\n\n```\n{t}\n```\n"); print(i, desc, len(t.split()))
open(O + "LumineX_Light6.md", "w", encoding="utf-8").write("\n".join(o))
