import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
from cover_lib import SAFE
IRON="rough black cast iron with a hammered, pitted, matte surface"
HEAVY="Every weight is an enormous, dense, completely solid, squat, blunt lump of rough black cast iron, as big as a fist or larger, with no thin parts, no arms and no hollow parts, crushingly and unmistakably heavy; every chain is thick and pulled bar-straight and taut by the load."
NOTHING_ELSE="Everything else on her face and ears is completely free of piercings."
SK="The skin around every piece is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
ACCESS_END=" All jewelry is real blackened cast iron,"
P=[]
# 1 아랫입술
P.append(("아랫입술 — 거대 립 플레이트 + 쇠뭉치","chest",
"Piercings: Exactly one piercing in total, in the lower lip, and nowhere else: her lower lip is stretched into a thin, smooth, taut loop of skin wrapped around the rim of an enormous, very thick, heavy disc of "+IRON+" as wide as her whole palm, which stands out in front of her chin like a plate, its upper edge resting just below her closed upper lip so her upper lip, her teeth line and the corners of her mouth stay fully bare and visible. Three separate massive solid weights hang from the bottom edge of the disc on thick chains of heavy black iron links, one cube-shaped block, one cannonball and one ingot block, hanging at different lengths down past her chin onto her chest. "+HEAVY+" "+SK+" "+NOTHING_ELSE+ACCESS_END+SAFE))
# 2 코 사이
P.append(("코 사이 — 거대 엄니 바","shoulder",
"Piercings: Exactly one piercing in total, through the septum, the thin soft wall between the nostrils, and nowhere else: a gigantic, very thick, solid horn-shaped tusk of "+IRON+" as thick as her thumb passes straight through the septum and stretches out sideways across her face as wide as her cheekbones, its two ends curving gently upward in a smooth bull-horn arc and ending in blunt rounded tips well below her eyes, at the height of her nostrils; it sits clearly above her upper lip and does not cover her lips. A heavy solid iron ring hangs from the middle of the tusk beneath the nose, with one fist-sized solid cannonball weight hanging from it, ending clearly above her upper lip. "+HEAVY+" "+SK+" "+NOTHING_ELSE+ACCESS_END+SAFE))
# 3 콧볼
P.append(("콧볼 — 거대 노즈링(나트) + 귀까지 이어지는 사슬","shoulder",
"Piercings: Exactly two piercings in total, in the left nostril wing and the left ear, and nowhere else: an enormous, thick, ornate gold nose ring as wide as her whole palm, a huge round hoop wrapping around the left nostril wing and hanging out far from the face, set with a row of large pearls, red rubies and gold filigree; two thick, heavy gold chain swags with large links, one above the other, run from the bottom of this nose ring across the left cheek, a palm's width below the eye, to a thick gold hoop through the upper part of the left ear, and a row of small gold bells and pearls hangs from the swags. The right side of her face, her right nostril and her lips are completely bare. "+SK+" "+NOTHING_ELSE+" All jewelry is real polished yellow gold with large pearls and rubies,"+SAFE))
# 4 눈썹
P.append(("눈썹 — 얼굴 폭 긴 곡선 바","shoulder",
"Piercings: Exactly two piercings in total, one through each eyebrow, and nowhere else: through each eyebrow runs one gigantic, very thick, solid curved bar of "+IRON+" as thick as her finger and as long as her hand, following the brow bone from the inner end of the brow all the way out past the temple toward the hairline, with a big solid spiked ball end cap as large as a ping-pong ball at each end; both bars sit entirely on the brow bone, never touching the eyelids, with clear skin between the bar and the eyelid, and the eyes stay fully open and visible. "+SK+" "+NOTHING_ELSE+ACCESS_END+SAFE))
# 5 귀 연골
P.append(("귀 연골 — 거대 후프 + 긴 바에 쇠뭉치 줄줄이","shoulder",
"Piercings: Exactly six piercings in total, three through the upper cartilage of each ear, and nowhere else: through the helix rim of each ear passes one gigantic very thick solid hoop of "+IRON+" as wide as her whole palm, hanging far out from the head and down past her jaw; above it a thick straight industrial bar as long as her hand runs across the upper ear, and below it a second thick bar across the middle of the ear; from the bars and the hoop hang, on each ear, five separate massive solid iron weights of different blunt shapes (cube block, cannonball, hexagonal block, ingot block, short cylinder stump), each on its own thick chain of heavy black iron links, at different lengths down to the line of her shoulders. The earlobes themselves are completely normal and unpierced. "+HEAVY+" "+SK+" "+NOTHING_ELSE+ACCESS_END+SAFE))
# 6 턱
P.append(("턱 — 굵은 링 + 가슴까지 쇠뭉치 사슬","chest",
"Piercings: Exactly one piercing in total, through the chin, and nowhere else: one gigantic, very thick, heavy ring of "+IRON+" as thick as her finger and as wide as a saucer passes through the skin of the chin beneath the lower lip, hanging down onto her neck; from the bottom of this ring hang four separate massive solid weights (cube block, cannonball, ingot block, short cylinder stump) on thick chains of heavy black iron links of four different lengths, down past her neck onto her chest, so the load pulls her chin slightly down; her lips and her mouth stay fully bare and visible. "+HEAVY+" "+SK+" "+NOTHING_ELSE+ACCESS_END+SAFE))
# 7 사슬 연결
P.append(("부위 사이 — 코·입술에서 귀로 가로지르는 굵은 사슬","shoulder",
"Piercings: Exactly six piercings in total, and nowhere else: one thick heavy ring of "+IRON+" around each nostril wing, one thick heavy ring through the left and one through the right side of the lower lip's edge, and one very thick heavy hoop through each ear's helix rim; from each nostril ring a thick, heavy chain with large links is pulled taut straight across the cheek to the ear hoop on the same side, running low across the cheek, a palm's width below the eye, and from each lower-lip ring a second thick chain is pulled taut along the jawline to the same ear hoop, so the chains form a heavy metal web between nose, mouth and ears; a fist-sized solid iron weight hangs from each ear hoop on a short thick chain. Both lips stay fully bare and visible and no chain crosses the eyes. "+HEAVY+" "+SK+" "+NOTHING_ELSE+ACCESS_END+SAFE))
NA=[("한국","20대","도도한"),("일본","아이돌","군림하는"),("중국","20대","섹시한"),("한국","30대","냉혹한"),("일본","20대","카리스마 있는"),("중국","아이돌","고혹적인"),("한국","20대","몽환적인")]
FR={"chest":"down to the middle of her chest, the frame cutting off there, so the chains and weights fully hang in view","shoulder":"down to her collarbones and the tops of her shoulders, the frame cutting off there, so everything fully hangs in view"}
o=["# LumineX — 부위별 극단 피어싱 7개 (이상·상상 기준, 부위당 1개)\n","- 부위 하나만 피어싱, 나머지는 비움. 소재는 무쇠 중심(콧볼 노즈링만 금). 눈 거리·입술 노출·멀쩡한 피부는 유지.","- 정상/이상(+ 의도한 모양이 나왔는지)만 번호로 알려주세요.\n"]
for i,((lab,fr,pp),(nat,grp,ex)) in enumerate(zip(P,NA),1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(61000+i*100+tr),nat,grp,ex,style="NONE",slots=["pierce"],pier_level="P3"); break
        except AssertionError: continue
    else: raise SystemExit(i)
    old=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    t=re.sub(r'\n\nJewelry:[^\n]*','',t.replace(old,pp))
    t,nn=re.subn(r'down to the base of her neck and the tops of her collarbones, the frame cutting off there',FR[fr],t,count=1); assert nn==1
    t=t.replace("\n\nLighting:","\n\nHair: her hair is swept back behind both ears, leaving both ears, her jawline and her neck fully visible.\n\nLighting:",1)
    assert not re.search(r"[가-힣]",t)
    o.append(f"## {i}. {lab} — {title}\n\n```\n{t}\n```\n"); print(i,len(t.split()))
open('/mnt/user-data/outputs/LumineX_AreaExtreme_7.md','w',encoding='utf-8').write("\n".join(o))
