# -*- coding: utf-8 -*-
# 신규 번들 3종(솔로 60씩): Automaton / Edible / Doll Joint — Material Mix 틀(전 축 기본 랜덤), 재질 문장만 교체
import re, random, sys, json, collections
_s = open("mk_doll3.py", encoding="utf-8").read()
exec(_s[:_s.index("rg = random.Random(")])
_jw0 = ns2["jewel"]
ns2["jewel"] = lambda p: _jw0(p).replace("a small pendant at her navel", "a small pendant resting on her belly plate")

OPQ = "completely opaque"; SAT = "richly saturated in colour"
def assemble(mat, nmw, part, phys, age, pose, eth):
    pn, pd = phys
    feat, seg, info = face(eth); skin = eth[1]
    hl = HEEL_ if HEELMODE[0] == "forty" else HEEL_REL
    shoe = f"Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of the same {nmw}, each with {hl}, {BODYLIFT}."
    nails = f"Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, made of the same {nmw} with a high polish."
    fc = f"Face: her face and ears are NOT {part} — they are real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    jw = f"Jewelry: {ns2['jewel']('')}"
    body = f"{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair()} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    return "\n".join([body, shoe, nails, jw, fc]), info

HEAD = "full body {desc} fused directly to her own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, this is a solid {solid} "
# ---------- 인형 관절
DJ = ("body curving to follow her body's true three-dimensional shape, divided into smooth fitted {nm} segments, and at her neck, shoulders, elbows, wrists, hips, knees and ankles every segment ends in a round exposed ball joint seated in its socket with a thin dark gap and its own small shadow, nothing lying flat. Dense fitted segments — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
def doll(nm, desc, solid, base, acc, fin, tag, kind, nmw=None):
    return dict(kind=kind, tag=tag, desc=desc, solid=solid, nm=nm, nmw=nmw or solid, base=base, acc=acc, fin=fin)
def BJDacc(joint, against, extra): return f"VIVID {joint} ball joints standing out sharply against the {against}, {extra}"
DOLLS = {
 "bjd_porcelain": [
  doll("porcelain", "smooth matte white bisque porcelain ball-jointed doll", "bisque porcelain", "BLAZING flawless matte pale-white bisque porcelain across the full torso both legs neck to ankle", BJDacc("bright cobalt-blue", "white", "faint painted blush on every knuckle, elbow and knee"), "soft matte bisque", "흰 도자기 · 코발트 관절", "bjd_porcelain"),
  doll("porcelain", "smooth matte powder-blue bisque porcelain ball-jointed doll", "bisque porcelain", "BLAZING flawless matte powder-blue bisque porcelain across the full torso both legs neck to ankle", BJDacc("deep coral-red", "powder-blue", "faint painted white blush on every knuckle, elbow and knee"), "soft matte bisque", "파우더블루 도자기 · 코랄 관절", "bjd_porcelain"),
  doll("porcelain", "smooth matte pale lavender bisque porcelain ball-jointed doll", "bisque porcelain", "BLAZING flawless matte pale lavender bisque porcelain across the full torso both legs neck to ankle", BJDacc("bright polished gold", "lavender", "faint painted white blush on every knuckle, elbow and knee"), "soft matte bisque", "라벤더 도자기 · 금 관절", "bjd_porcelain"),
 ],
 "bjd_resin": [
  doll("resin", "satin pale mint-green resin ball-jointed doll", "cast resin", "BLAZING smooth satin pale mint-green resin across the full torso both legs neck to ankle", BJDacc("deep wine-red", "mint-green", "dark elastic cord glimpsed inside every joint gap"), "soft satin-gloss", "민트 레진 · 와인레드 관절", "bjd_resin"),
  doll("resin", "satin soft lilac resin ball-jointed doll", "cast resin", "BLAZING smooth satin soft lilac resin across the full torso both legs neck to ankle", BJDacc("bright polished gold", "lilac", "dark elastic cord glimpsed inside every joint gap"), "soft satin-gloss", "라일락 레진 · 금 관절", "bjd_resin"),
  doll("resin", "satin pale butter-yellow resin ball-jointed doll", "cast resin", "BLAZING smooth satin pale butter-yellow resin across the full torso both legs neck to ankle", BJDacc("deep teal", "butter-yellow", "dark elastic cord glimpsed inside every joint gap"), "soft satin-gloss", "버터옐로 레진 · 틸 관절", "bjd_resin"),
 ],
 "marionette": [
  doll("wooden", "carved honey-beech wooden marionette", "carved beechwood", "BLAZING warm honey-gold beechwood grain across the full torso both legs neck to ankle", BJDacc("bright teal-blue painted", "honey-gold wood", "thin taut strings running from her head, shoulders, elbows, wrists, hips and knees straight up out of the top of the frame"), "hand-waxed satin", "벚나무 마리오네트 · 청록 관절", "marionette"),
  doll("wooden", "carved deep walnut wooden marionette", "carved walnut", "BLAZING deep chocolate-brown walnut grain across the full torso both legs neck to ankle", BJDacc("bright aqua-blue painted", "dark walnut", "thin taut strings running from her head, shoulders, elbows, wrists, hips and knees straight up out of the top of the frame"), "hand-waxed satin", "월넛 마리오네트 · 아쿠아 관절", "marionette"),
  doll("wooden", "carved whitewashed birch wooden marionette", "carved birchwood", "BLAZING pale whitewashed birch grain across the full torso both legs neck to ankle", BJDacc("bright vermilion-red painted", "whitewashed wood", "thin taut strings running from her head, shoulders, elbows, wrists, hips and knees straight up out of the top of the frame"), "hand-waxed satin", "흰 자작나무 마리오네트 · 주홍 관절", "marionette"),
  doll("wooden", "carved ebonised black wooden marionette", "carved ebony", "BLAZING glossy ebonised black wood grain across the full torso both legs neck to ankle", BJDacc("bright polished gold", "black wood", "thin taut strings running from her head, shoulders, elbows, wrists, hips and knees straight up out of the top of the frame"), "hand-waxed satin", "흑단 마리오네트 · 금 관절", "marionette"),
 ],
 "mannequin": [
  doll("wooden", "pale lacquered wooden artist's mannequin", "lacquered wood", "BLAZING smooth pale birch-blonde lacquered wood across the full torso both legs neck to ankle", "VIVID dark walnut-brown ball joints standing out sharply against the pale wood, each with a steel pivot screw, and a thin black seam down the spine", "smooth lacquered satin", "연한 자작 마네킹 · 월넛 관절", "mannequin"),
  doll("wooden", "pale lacquered maple wooden artist's mannequin", "lacquered wood", "BLAZING smooth pale maple lacquered wood across the full torso both legs neck to ankle", "VIVID deep crimson-red ball joints standing out sharply against the pale wood, each with a steel pivot screw, and a thin black seam down the spine", "smooth lacquered satin", "메이플 마네킹 · 크림슨 관절", "mannequin"),
  doll("wooden", "grey-washed lacquered wooden artist's mannequin", "lacquered wood", "BLAZING smooth grey-washed lacquered wood across the full torso both legs neck to ankle", "VIVID bright orange ball joints standing out sharply against the grey wood, each with a steel pivot screw, and a thin black seam down the spine", "smooth lacquered satin", "회색 마네킹 · 오렌지 관절", "mannequin"),
 ],
 "kintsugi": [
  doll("ceramic", "glazed ivory ceramic ball-jointed doll mended with gold", "glazed ceramic", "BLAZING glossy ivory-white glaze across the full torso both legs neck to ankle", "VIVID glossy emerald-green lacquer ball joints standing out sharply against the ivory, bright gold kintsugi seams zigzagging across every segment", "high-gloss glazed", "상아 킨츠기 · 에메랄드 관절", "kintsugi"),
  doll("ceramic", "glazed celadon-green ceramic ball-jointed doll mended with gold", "glazed ceramic", "BLAZING glossy soft celadon-green glaze across the full torso both legs neck to ankle", "VIVID glossy vermilion-red lacquer ball joints standing out sharply against the celadon, bright gold kintsugi seams zigzagging across every segment", "high-gloss glazed", "청자 킨츠기 · 주홍 관절", "kintsugi"),
  doll("ceramic", "glazed pale-blue ceramic ball-jointed doll mended with gold", "glazed ceramic", "BLAZING glossy pale sky-blue glaze across the full torso both legs neck to ankle", "VIVID glossy deep violet lacquer ball joints standing out sharply against the pale blue, bright gold kintsugi seams zigzagging across every segment", "high-gloss glazed", "하늘색 킨츠기 · 보라 관절", "kintsugi"),
 ],
 "bunraku": [
  doll("gofun", "white gofun-painted wooden Japanese bunraku puppet", "gofun-painted wood", "BLAZING chalk-white gofun shell paint across the full torso both legs neck to ankle", "VIVID vermilion-red painted joints and thin black silk cords tied around every wrist, elbow and knee", "soft matte shell-white", "분라쿠 · 주홍 관절", "bunraku"),
  doll("gofun", "white gofun-painted wooden Japanese bunraku puppet", "gofun-painted wood", "BLAZING chalk-white gofun shell paint across the full torso both legs neck to ankle", "VIVID deep indigo-blue painted joints and thin gold silk cords tied around every wrist, elbow and knee", "soft matte shell-white", "분라쿠 · 인디고 관절", "bunraku"),
  doll("gofun", "white gofun-painted wooden Japanese bunraku puppet", "gofun-painted wood", "BLAZING chalk-white gofun shell paint across the full torso both legs neck to ankle", "VIVID deep forest-green painted joints and thin red silk cords tied around every wrist, elbow and knee", "soft matte shell-white", "분라쿠 · 초록 관절", "bunraku"),
 ],
}
# ---------- 오토마톤
AT = ("automaton body curving to follow her body's true three-dimensional shape, divided into fitted {nm} plates, with one huge round cut-out window across her chest and belly as wide as her whole torso, showing a dense tangle of meshing gears of many sizes packed edge to edge inside a deep hollow cavity lit from within by a soft warm glow, stacked in layers at different depths with light pale-gold gaps between the layers so every gear on every layer is clearly visible, one giant gear as wide as her ribcage surrounded by medium and small gears, coiled springs and steel shafts, all turning together, and at her neck, shoulders, elbows, wrists, hips, knees and ankles every plate ends in a round exposed hinge joint with a thin dark gap and its own small shadow, nothing lying flat. Dense fitted plates — {base}, {acc}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
def auto(nm, desc, solid, plate, gear, bearing, joint, key, fin, tag, kind):
    base = f"BLAZING {plate} across the full torso both legs neck to ankle"
    acc = f"VIVID {gear} gears with large {bearing} bearings at their centres turning inside the cut-out window, {joint} joints standing out sharply against the {plate.split(' plates')[0].split()[-1] if False else nm}, a large {key} wind-up key as long as her forearm turning slowly at her side"
    return dict(kind=kind, tag=tag, desc=desc, solid=solid, nm=nm, nmw=solid, base=base, acc=acc, fin=fin)
AUTOS = {
 "brass": [
  auto("brass", "polished brass clockwork automaton", "polished brass", "warm polished brass plates", "silver", "red ruby", "deep blue-green verdigris", "brass", "bright polished", "황동 · 녹청 관절", "brass"),
  auto("brass", "polished brass clockwork automaton", "polished brass", "warm polished brass plates", "silver", "red ruby", "royal-blue", "brass", "bright polished", "황동 · 로열블루 관절", "brass"),
  auto("brass", "polished brass clockwork automaton", "polished brass", "warm polished brass plates", "silver", "emerald-green", "deep crimson-red", "brass", "bright polished", "황동 · 크림슨 관절", "brass"),
 ],
 "porcelain": [
  auto("porcelain", "white porcelain automaton with gold gears", "glazed porcelain", "glossy white porcelain plates painted with fine blue flowers", "gold", "gold", "copper-red", "gold", "high-gloss glazed", "도자기 · 구리빛 붉은 관절", "porcelain"),
  auto("porcelain", "white porcelain automaton with gold gears", "glazed porcelain", "glossy white porcelain plates painted with fine blue flowers", "gold", "gold", "cobalt-blue", "gold", "high-gloss glazed", "도자기 · 코발트 관절", "porcelain"),
  auto("porcelain", "white porcelain automaton with gold gears", "glazed porcelain", "glossy white porcelain plates painted with pink peonies and green leaves", "gold", "gold", "emerald-green", "gold", "high-gloss glazed", "도자기 모란 · 에메랄드 관절", "porcelain"),
 ],
 "enamel": [
  auto("enamel", "black enamel automaton with silver gears", "black enamel", "mirror-black enamel plates inlaid with silver filigree", "silver", "white pearl", "bright gold", "silver", "mirror-gloss enamelled", "흑칠 · 금 관절", "enamel"),
  auto("enamel", "midnight-blue enamel automaton with silver gears", "midnight-blue enamel", "mirror-gloss midnight-blue enamel plates inlaid with silver filigree", "silver", "white pearl", "bright gold", "silver", "mirror-gloss enamelled", "미드나이트블루 · 금 관절", "enamel"),
  auto("enamel", "deep burgundy enamel automaton with gold gears", "deep burgundy enamel", "mirror-gloss deep burgundy enamel plates inlaid with gold filigree", "gold", "white pearl", "bright silver", "gold", "mirror-gloss enamelled", "버건디 · 은 관절", "enamel"),
 ],
 "rosegold": [
  auto("rose-gold", "polished rose-gold clockwork automaton", "polished rose gold", "warm pink-gold polished plates", "pale-gold", "pink sapphire", "deep emerald-green", "rose-gold", "bright polished", "로즈골드 · 에메랄드 관절", "rosegold"),
  auto("rose-gold", "polished rose-gold clockwork automaton", "polished rose gold", "warm pink-gold polished plates", "pale-gold", "pink sapphire", "deep sapphire-blue", "rose-gold", "bright polished", "로즈골드 · 사파이어 관절", "rosegold"),
  auto("rose-gold", "polished rose-gold clockwork automaton", "polished rose gold", "warm pink-gold polished plates", "pale-gold", "pink sapphire", "bright violet-purple", "rose-gold", "bright polished", "로즈골드 · 보라 관절", "rosegold"),
 ],
 "steel": [
  auto("steel", "blackened gunmetal steel automaton with copper gears", "blackened steel", "dark gunmetal-grey steel plates with fine riveted seams", "bright copper", "amber", "bright polished gold", "copper", "satin-polished", "건메탈 · 금 관절", "steel"),
  auto("steel", "blackened gunmetal steel automaton with copper gears", "blackened steel", "dark gunmetal-grey steel plates with fine riveted seams", "bright copper", "amber", "bright turquoise", "copper", "satin-polished", "건메탈 · 터키석 관절", "steel"),
  auto("steel", "blackened gunmetal steel automaton with copper gears", "blackened steel", "dark gunmetal-grey steel plates with fine riveted seams", "bright copper", "amber", "vivid scarlet-red", "copper", "satin-polished", "건메탈 · 스칼렛 관절", "steel"),
 ],
 "turquoise": [
  auto("enamel", "turquoise-blue enamel automaton with gold gears", "turquoise enamel", "glossy turquoise-blue enamel plates inlaid with gold filigree", "gold", "white pearl", "bright coral-red", "gold", "mirror-gloss enamelled", "터키석 · 코랄 관절", "turquoise"),
  auto("enamel", "scarlet-red enamel automaton with gold gears", "scarlet enamel", "glossy scarlet-red enamel plates inlaid with gold filigree", "gold", "white pearl", "pale ivory-white", "gold", "mirror-gloss enamelled", "스칼렛 · 아이보리 관절", "turquoise"),
  auto("enamel", "emerald-green enamel automaton with gold gears", "emerald enamel", "glossy emerald-green enamel plates inlaid with gold filigree", "gold", "white pearl", "pale ivory-white", "gold", "mirror-gloss enamelled", "에메랄드 · 아이보리 관절", "turquoise"),
 ],
}
# ---------- 먹는 재질
ET = ("real {solid} curving to follow her body's true three-dimensional shape, {clause}, nothing lying flat. Dense surface — {base}, {acc}, with {pat}, {fin}, {opq}, NO airbrush NO gradient wash, NO flat printed surface anywhere")
EPAT = ["fine edible gold-leaf flecks scattered across the surface", "thin glossy drizzle lines tracing every curve of her body", "tiny sugar pearls pressed along the surface"]
def edi(nm, desc, solid, nmw, base, acc, fin, clause, tag, kind, transl=False):
    return dict(kind=kind, tag=tag, desc=desc, solid=solid, nm=nm, nmw=nmw, base=base, acc=acc, fin=fin, clause=clause, transl=transl)
CH_CL = "thick molten rivulets of it streaming down her body in glossy ribbons and pooling in shining puddles around her feet"
HO_CL = "thick golden honey streaming from the cells down her body in long glossy strands and pooling in shining puddles around her feet"
IC_CL = "soft scoops and swirls slowly melting, thick creamy drips running down her body and pooling in puddles around her feet"
JE_CL = "soft and wobbling, light glowing through the translucent body so that suspended fruit slices and bubbles show inside"
CK_CL = "thick piped frosting standing out in deep sculpted relief, with golden sponge cake layers showing at the cut edges"
def CA_CL(c1, c2): return f"thick glossy sugar syrup in {c1} and {c2} swirls slowly stretching and dripping down her body in long sticky strands and pooling in shining puddles around her feet"
EDIBLES = {
 "choc": [
  edi("chocolate", "glossy tempered dark chocolate", "chocolate", "chocolate", "BLAZING deep glossy dark-chocolate brown across the full torso both legs neck to ankle", "VIVID creamy white-chocolate drizzle lines and tiny gold-leaf flecks across the surface", "mirror-glossy tempered", CH_CL, "다크 초콜릿", "choc"),
  edi("chocolate", "glossy tempered milk chocolate", "chocolate", "chocolate", "BLAZING warm caramel-brown milk chocolate across the full torso both legs neck to ankle", "VIVID thin dark-chocolate drizzle lines and crushed hazelnut pieces across the surface", "mirror-glossy tempered", CH_CL, "밀크 초콜릿", "choc"),
  edi("chocolate", "glossy tempered white chocolate", "chocolate", "chocolate", "BLAZING smooth ivory-white chocolate across the full torso both legs neck to ankle", "VIVID raspberry-red drizzle lines and tiny freeze-dried berries across the surface", "mirror-glossy tempered", CH_CL, "화이트 초콜릿", "choc"),
 ],
 "honey": [
  edi("honeycomb", "golden honey-filled honeycomb", "honeycomb wax and honey", "honeycomb wax", "BLAZING hexagonal wax cells brimming with glowing golden honey across the full torso both legs neck to ankle", "VIVID deeper amber pools of honey shimmering inside every cell", "wet glossy", HO_CL, "황금 벌집 꿀", "honey", True),
  edi("honeycomb", "dark amber honey-filled honeycomb", "honeycomb wax and honey", "honeycomb wax", "BLAZING hexagonal wax cells brimming with dark reddish-amber buckwheat honey across the full torso both legs neck to ankle", "VIVID bright golden highlights shimmering inside every cell", "wet glossy", HO_CL, "짙은 호박색 꿀", "honey", True),
  edi("honeycomb", "pale lemon-gold honey-filled honeycomb", "honeycomb wax and honey", "honeycomb wax", "BLAZING hexagonal wax cells brimming with pale lemon-gold honey across the full torso both legs neck to ankle", "VIVID warm orange pools of honey shimmering inside every cell", "wet glossy", HO_CL, "연한 레몬골드 꿀", "honey", True),
 ],
 "candy": [
  edi("candy", "melting swirled hard candy", "hard candy", "hard candy", "BLAZING candy-red and cream-white swirled stripes of glossy molten sugar across the full torso both legs neck to ankle", "VIVID clear sugar-glass edges glinting along the swirls and tiny rainbow sprinkles caught in the sticky surface", "high-gloss sticky", CA_CL("red", "white"), "빨강 녹은 사탕", "candy", True),
  edi("candy", "melting swirled hard candy", "hard candy", "hard candy", "BLAZING bubblegum-pink and cream-white swirled stripes of glossy molten sugar across the full torso both legs neck to ankle", "VIVID clear sugar-glass edges glinting along the swirls and tiny rainbow sprinkles caught in the sticky surface", "high-gloss sticky", CA_CL("pink", "white"), "분홍 녹은 사탕", "candy", True),
  edi("candy", "melting swirled hard candy", "hard candy", "hard candy", "BLAZING turquoise-blue and cream-white swirled stripes of glossy molten sugar across the full torso both legs neck to ankle", "VIVID clear sugar-glass edges glinting along the swirls and tiny rainbow sprinkles caught in the sticky surface", "high-gloss sticky", CA_CL("turquoise", "white"), "청록 녹은 사탕", "candy", True),
  edi("candy", "melting swirled hard candy", "hard candy", "hard candy", "BLAZING orange and lemon-yellow swirled stripes of glossy molten sugar across the full torso both legs neck to ankle", "VIVID clear sugar-glass edges glinting along the swirls and tiny rainbow sprinkles caught in the sticky surface", "high-gloss sticky", CA_CL("orange", "yellow"), "오렌지 녹은 사탕", "candy", True),
 ],
 "jelly": [
  edi("jelly", "wobbling raspberry gelatin jelly", "jelly", "jelly", "BLAZING glossy translucent raspberry-red jelly across the full torso both legs neck to ankle", "VIVID tiny suspended fruit slices and air bubbles glowing inside the body", "wet glossy", JE_CL, "라즈베리 젤리", "jelly", True),
  edi("jelly", "wobbling lime gelatin jelly", "jelly", "jelly", "BLAZING glossy translucent lime-green jelly across the full torso both legs neck to ankle", "VIVID tiny suspended lime slices and air bubbles glowing inside the body", "wet glossy", JE_CL, "라임 젤리", "jelly", True),
  edi("jelly", "wobbling orange gelatin jelly", "jelly", "jelly", "BLAZING glossy translucent orange jelly across the full torso both legs neck to ankle", "VIVID tiny suspended orange segments and air bubbles glowing inside the body", "wet glossy", JE_CL, "오렌지 젤리", "jelly", True),
  edi("jelly", "wobbling grape gelatin jelly", "jelly", "jelly", "BLAZING glossy translucent deep grape-purple jelly across the full torso both legs neck to ankle", "VIVID tiny suspended grapes and air bubbles glowing inside the body", "wet glossy", JE_CL, "포도 젤리", "jelly", True),
 ],
 "icecream": [
  edi("ice cream", "soft-serve strawberry and vanilla ice cream", "ice cream", "ice cream", "BLAZING pale pink strawberry and cream-white vanilla swirls across the full torso both legs neck to ankle", "VIVID colorful sprinkles and thick chocolate sauce swirls across the surface", "glossy melting", IC_CL, "딸기 바닐라 아이스크림", "icecream"),
  edi("ice cream", "soft-serve mint and chocolate-chip ice cream", "ice cream", "ice cream", "BLAZING pale mint-green ice cream studded with dark chocolate chips across the full torso both legs neck to ankle", "VIVID thick fudge sauce swirls and crushed cookie crumbs across the surface", "glossy melting", IC_CL, "민트 초코칩 아이스크림", "icecream"),
  edi("ice cream", "soft-serve blueberry and vanilla ice cream", "ice cream", "ice cream", "BLAZING pale periwinkle-blue blueberry and cream-white vanilla swirls across the full torso both legs neck to ankle", "VIVID whole blueberries and thick berry sauce swirls across the surface", "glossy melting", IC_CL, "블루베리 바닐라 아이스크림", "icecream"),
 ],
 "cake": [
  edi("buttercream", "pastel buttercream-frosted cake", "frosted cake", "pastel sugar paste", "BLAZING smooth pastel pink buttercream frosting across the full torso both legs neck to ankle", "VIVID piped white rosettes, pearl-white sugar beads and tiny macarons set along the body", "soft matte frosted", CK_CL, "분홍 버터크림 케이크", "cake"),
  edi("buttercream", "pastel mint buttercream-frosted cake", "frosted cake", "pastel sugar paste", "BLAZING smooth pastel mint-green buttercream frosting across the full torso both legs neck to ankle", "VIVID piped white rosettes, silver sugar beads and tiny lemon macarons set along the body", "soft matte frosted", CK_CL, "민트 버터크림 케이크", "cake"),
  edi("buttercream", "white wedding-style buttercream cake", "frosted cake", "pastel sugar paste", "BLAZING smooth snow-white buttercream frosting across the full torso both legs neck to ankle", "VIVID piped white rosettes, edible gold leaf and pearl-white sugar beads set along the body", "soft matte frosted", CK_CL, "화이트 웨딩 케이크", "cake"),
  edi("ganache", "dark chocolate ganache cake with fresh berries", "frosted cake", "chocolate", "BLAZING glossy dark-chocolate ganache frosting across the full torso both legs neck to ankle", "VIVID fresh raspberries, glossy strawberries and gold-dusted chocolate curls set along the body", "glossy ganache", CK_CL, "초콜릿 가나슈 케이크", "cake"),
 ],
}
def mat_for(fam, v):
    if fam == "doll": return HEAD.format(desc=v["desc"], solid=v["solid"]) + DJ.format(nm=v["nm"], base=v["base"], acc=v["acc"], fin=v["fin"]), v["nmw"], "part of the doll body"
    if fam == "auto": return HEAD.format(desc=v["desc"], solid=v["solid"]) + AT.format(nm=v["nm"], base=v["base"], acc=v["acc"], fin=v["fin"]), v["nmw"], "part of the automaton body"
    pat = rr.choice(EPAT)
    h = HEAD.format(desc=v["desc"], solid="").replace("this is a solid  ", "this is ")
    return h + ET.format(solid=v["solid"], clause=v["clause"], base=v["base"], acc=v["acc"], pat=pat, fin=v["fin"], opq=SAT if v["transl"] else OPQ), v["nmw"], v["nm"]
FAM = {"automaton": ("auto", AUTOS, "la_automaton_", "🏺 Living Artifact · Automaton Formula", "Automaton", 20261101),
       "edible": ("edi", EDIBLES, "la_edible_", "🏺 Living Artifact · Edible Formula", "Edible", 20261102),
       "dolljoint": ("doll", DOLLS, "la_dolljoint_", "🏺 Living Artifact · Doll Joint Formula", "DollJoint", 20261103)}
def build_family(name):
    fam, TAB, pref, CAT, TITLE, seed = FAM[name]
    rg = random.Random(seed); rr.seed(seed); ns2["JR"].seed(seed)
    kinds = list(TAB); out = []; seen = set()
    for j in range(10):
        for k in kinds:
            vs = TAB[k]; v = vs[j % len(vs)]
            for attempt in range(500):
                phys = rg.choices(BIG5, W5)[0]; age = rg.choice(AGES); pose = rg.choice(POSES); eth = rg.sample(ETH, 1)[0]
                bid, wx = BGL.pick(rg, 1); scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
                HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
                ns2["JR"].seed(rg.randrange(10**9))
                mat, nmw, part = mat_for("doll" if fam == "doll" else "auto" if fam == "auto" else "edi", v)
                body, info = assemble(mat, nmw, part, phys, age, pose, eth)
                env = f"{scene}, bright and evenly lit, shadows soft, the whole floor and surroundings clearly visible and in focus, NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as her."
                tail = f"Background: {env} ONE woman only. Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
                t = f"Professional fashion photograph, full body shot. ONE woman standing.\n\n{body}\n\n{tail}{CAM} 8K portrait {ASP[1]} aspect ratio."
                if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t) or t in seen or "navel" in t.lower(): continue
                break
            else: raise SystemExit("fail")
            seen.add(t); n = len(out) + 1
            hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
            assert t.count("forty inches") == (1 if HEELMODE[0] == "forty" else 0)
            out.append({"key": f"{pref}{n:03d}", "category": CAT,
                        "title": f"{TITLE} Solo #{n:03d} ({v['tag']} · 체형 {phys[0]} · 인종 {eth[0]} · {info} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko} · 몸 주얼리)",
                        "prompt": t, "meta": {"group_size": 1, "aspect_ratio": ASP[1], "format": name, "kind": v["kind"], "variant": v["tag"], "physiques": [phys[0]], "ethnicity": [eth[0]],
                                              "background": bid, "weather": wx[0] if wx else None, "heel_mode": HEELMODE[0], "jewelry": True}})
    assert len(out) == 60 and len({p["key"] for p in out}) == 60
    return out
if __name__ == "__main__":
    for name in FAM:
        out = build_family(name)
        fn = {"automaton": "la_automaton_60_bundle.json", "edible": "la_edible_60_bundle.json", "dolljoint": "la_dolljoint_60_bundle.json"}[name]
        json.dump(out, open(O + fn, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        wc = [len(p["prompt"].split()) for p in out]
        print(name, len(out), min(wc), max(wc), sum(wc)//len(wc), collections.Counter(p["meta"]["kind"] for p in out).most_common(), len({p["meta"]["background"] for p in out}), "배경", collections.Counter(p["meta"]["heel_mode"] for p in out))
