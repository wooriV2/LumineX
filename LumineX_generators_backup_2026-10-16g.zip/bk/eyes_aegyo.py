import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
from cover_lib import SAFE
HEAD="Professional fashion photograph, close-up beauty portrait. ONE woman, facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp. Mid 20s."
HEAD_W=HEAD.replace("down to the base of her neck and the tops of her collarbones, the frame cutting off there","down to her collarbones and the tops of her shoulders, the frame cutting off there, so the earrings fully hang in view")
TAIL=" Every feature is exaggerated but beautiful, balanced and refined, in harmony with the rest of her face, never distorted, never grotesque. Real skin fine grain and a soft sheen of natural oils on her face, ears and neck, individual hair strands catching the light — a photograph of a real woman, not an illustration, not a render."
SK="The skin around every piece is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
IRON="rough black cast iron with a hammered, pitted, matte surface"
def sub(txt): return "Subject: "+txt+TAIL



def eyesub(face,eyes,brows,rest):
    return sub("A real photograph of a strikingly beautiful adult woman, mid 20s, "+face+" Her eyes are the star of her face: "+eyes+" "+brows+" "+rest+" Looking straight into the camera.")
def pier(mat,desc,col):
    return ("Piercings: Exactly six piercings in total, symmetrical: on each ear a large "+desc+" hoop in the lobe and two matching studs up the rim. Each piece is large and clearly visible, and nothing else on the face is pierced. "+SK+" All jewelry is real "+mat+","+SAFE)
V=[("애교살 초극대 — 한국 · 눈 아래 통통한 애교살 융기·반달 눈웃음·하이라이터 · 로즈골드+핑크 피어싱 6",
    eyesub("a Korean woman with luminous fair skin, soft see-through bangs and long dark-brown hair.","large, soft, smiling eyes that curve into gentle crescents with a clearly defined double eyelid, and the signature feature of her face is her exaggerated 'aegyo-sal': a hugely plump, pillowy, rounded fat roll under each eye, twice as thick as her upper eyelid, running along the whole length of the lower lash line and bulging out like a small soft pillow, so the lower lids look round, inflated and glossy, clearly visible as a big puffy ridge with a bright pearly champagne highlighter on top of it and a soft shadow line right beneath it, which makes her eyes look like two bright smiling crescents sitting on top of two soft cushions, sweet and sparkling; the eyes are in soft brown doll-eye contact lenses with a big iris, both eyes the same, with a round natural pupil and bright catchlights.","Soft, gently straight, slightly low brows.","Soft pink lips in a gentle smile, a small straight nose and a slim V-line chin. A warm, smiling gaze."),
    pier("polished rose gold with pastel-pink enamel","rose-gold with pastel-pink enamel",1)),
   ("옆트임 극대 — 중국 · 앞뒤로 트인 아주 긴 눈·눈꼬리가 관자까지·분홍 앞트임 · 골드+제이드 피어싱 6",
    eyesub("a Chinese woman with luminous porcelain skin and long straight glossy black hair.","the signature feature of her face is her extreme surgically widened eyes: lateral canthoplasty has extended the outer corners of both eyes far outward almost to her temples, and medial canthoplasty has opened the inner corners so the small pink inner corner of each eye is visible, so each eye opening is about one and a half times its natural length, very long, wide and almond-shaped, showing a very large amount of the iris and a bit of the white on both sides; a razor-sharp black eyeliner follows the whole extended shape and ends in a long point at the temple, with a clean double eyelid; the eyes are in large dark-brown doll-eye contact lenses with a big iris and a glossy shine, both eyes the same, with a round natural pupil and bright catchlights.","Slim, clean, softly arched dark brows.","Soft rose lips, a straight refined nose and a slim V-line jaw. A cool, intense gaze."),
    pier("polished yellow gold set with green jade","gold with green jade",1))]
o=["# LumineX — 애교살 초극대 1종 (정면)\n","- 애교살: 눈 아래 윗눈꺼풀 두께의 통통한 융기 + 하이라이터. 옆트임: 눈 길이 1.5배, 눈꼬리가 관자 근처까지 + 앞트임 분홍 안쪽 코너. 피어싱은 양쪽 귀 6개로 절제.","- 정상/이상(+ 눈 모양 특징이 보이는지)만 번호로 알려주세요.\n"]
for i,(lab,sj,p) in enumerate(V[:1],1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(84000+i*100+tr),"한국","20대","도도한",style="NONE",slots=["pierce"],pier_level="P5"); break
        except AssertionError: continue
    else: raise SystemExit(i)
    ps=t.split("\n\n")
    depth=[x for x in ps if x.startswith("Piercing depth:")][0]; light=[x for x in ps if x.startswith("Lighting:")][0]
    new="\n\n".join([HEAD,sj,p,depth,light]); assert not re.search(r"[가-힣]",new)
    o.append(f"## {i}. {lab}\n\n```\n{new}\n```\n")
open('/mnt/user-data/outputs/LumineX_Eyes_AegyoMax_1.md','w',encoding='utf-8').write("\n".join(o)); print("ok")
