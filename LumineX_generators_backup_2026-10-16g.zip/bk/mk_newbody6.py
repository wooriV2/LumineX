# -*- coding: utf-8 -*-
# 새 체형 6종 초안 + 코스튬 솔로 샘플 6개 (체형 1개씩)
_s = open('mk_costume_bundle.py', encoding='utf-8').read()
exec(_s[:_s.index("out = []")], globals())
TAIL = "her arms, hands, legs and feet stay in correct proportion to each other"
NB = [
 ("siren bust hourglass", "사이렌 바스트 아워글래스", "가슴이 압도적으로 크고 허리가 가장 가늘며, 엉덩이는 그 아래로 받쳐 주는 가슴 우세 아워글래스",
  f"an extraordinarily curvaceous woman, far beyond any real person; a colossal heavy bust projecting far forward and wider than her shoulders is the first thing the eye lands on, and directly below it her waist pulls in to an impossibly narrow, sharply defined line with a deep shadowed groove, then full round hips and soft thick thighs flare out beneath as a strong second curve; the drop from bust to waist is the most dramatic part of her silhouette; not thin, not boyish, not a straight figure; her head looks small above her bust; {TAIL}"),
 ("violin hip hourglass", "바이올린 힙 아워글래스", "허리가 극소이고 엉덩이와 허벅지가 바이올린 곡선처럼 크게 퍼지는 하체 우세 아워글래스",
  f"an extraordinarily curvaceous woman, far beyond any real person; a sharply cinched waist rises out of hips that sweep outward in a single smooth violin-shaped curve, the hips and thick rounded thighs flaring many times wider than the waist and dominating her silhouette from the front and side, a firm high rounded rear, a full round bust balancing the curve above; the line from waist to hip to thigh is one long unbroken curve; not thin, not boyish, not a straight figure; {TAIL}"),
 ("towering hourglass", "타워링 아워글래스", "키가 아주 크고 다리가 끝없이 길면서도 허리는 극단적으로 잘록한 장신 아워글래스",
  f"an extraordinarily tall and curvaceous woman, far beyond any real person; a towering frame with legs that seem endless, thick smooth thighs and calves, hips wide and rounded, a sharply cinched narrow waist pulled in far tighter than her bust and hips, and a full heavy bust high on her chest; her height and long legs make every curve look longer and more dramatic; not stocky, not thin, not boyish; {TAIL}"),
 ("S-curve bombshell", "S커브 밤쉘", "가슴은 앞으로, 엉덩이는 뒤로 크게 내밀어 옆모습이 깊은 S자를 그리는 체형",
  f"an extraordinarily curvaceous woman, far beyond any real person; her spine carries a deep, dramatic S-curve, a colossal bust pushed far forward on one side and a massive high rounded rear pushed far backward on the other, with a narrow waist pulled in sharply between them, so her side profile is one exaggerated S-shaped line; thick soft thighs, soft arms; not thin, not straight, not boyish; {TAIL}"),
 ("toned bombshell", "토너드 밤쉘", "복근과 허벅지·둔근이 단단히 잡히면서도 가슴과 엉덩이는 과장되게 큰 피트니스형",
  f"an extraordinarily curvaceous but athletic woman, far beyond any real person; a flat, firmly defined stomach with faint abdominal muscle lines, a very narrow waist, strong rounded shoulders and toned arms, powerful toned thighs and a high firm rounded rear, yet a colossal full bust and wide round hips that keep the dramatic hourglass shape; hard fit muscle under glowing skin, not bulky, not thin, not boyish; {TAIL}"),
 ("apex siren", "에이펙스 사이렌", "키·가슴·허리·엉덩이·허벅지를 전부 극단으로 끌어올린 최대치 조합",
  f"an extraordinarily tall and curvaceous woman, far beyond any real person; everything about her is at its extreme at once: a towering frame with endless legs, a colossal heavy bust wider than her shoulders, a waist cinched to an impossible minimum, enormous round hips and a high rounded rear, gigantic thick thighs pressed together, smooth glowing skin over soft full curves; her silhouette is an exaggerated hourglass that dominates the whole frame from head to toe; not thin, not boyish, not evenly proportioned; her head looks small above her body; {TAIL}"),
]
for nm, ko, kod, desc in NB: BODY[nm] = (nm, desc)
COSTS = ["바니걸", "카우걸", "여왕", "악마", "레이싱 퀸", "천사"]
rg = random.Random(20267701); rr.seed(20267701); ns2["JR"].seed(20267701)
o = ["# LumineX — 새 체형 6종 초안 + 코스튬 솔로 샘플 6개\n", "## 새 체형\n", "| 번호 | 이름 | 한글 | 특징 |", "|---|---|---|---|"]
for i, (nm, ko, kod, desc) in enumerate(NB, 1): o.append(f"| {i} | {nm} | {ko} | {kod} |")
o.append("\n체형 문구 원문(영문)은 각 샘플 아래에 붙였습니다. 샘플은 코스튬 틀(성공 경험이 가장 많은 틀)에 체형만 새로 지정했고, 나머지 축(나이·포즈·인종·배경·힐·네일·주얼리·메이크업)은 기본 랜덤입니다. 번호별로 성공/실패만 알려주세요.\n")
for i, ((nm, ko, kod, desc), c) in enumerate(zip(NB, COSTS), 1):
    r = gen([COST[c]], [lambda nm=nm: nm], [None])
    pose = pose_ko(r["poses"][0]); hk = "힐 40인치" if r["heel"] == "forty" else "힐 숫자 없음"
    o.append(f"## {i}. {ko}({nm}) · 코스튬 {c} · 인종 {r['eths'][0]} · {pose} · 배경 {BGL.BG[r['bid']][2]} · {hk}\n\n```\n{r['t']}\n```\n")
    print(i, nm, c, len(r['t'].split()))
open(O_ + "LumineX_NewBody6_Costume_Samples.md", "w", encoding="utf-8").write("\n".join(o))
