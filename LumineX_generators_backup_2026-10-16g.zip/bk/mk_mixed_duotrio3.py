# -*- coding: utf-8 -*-
# 여성 바디페인팅 정면 비교 샘플 4개 (부피 큰 체형 2 + 근육질 2) — 남성 정면 실패 대조용
import re, sys
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity"); sys.path.insert(0, "../../master")
_g = open("gen_pierce_statue.py", encoding="utf-8").read()
exec(_g[:_g.index("def build(")])
import mdefs as D
exec(open("../../bk/newbody_defs.py", encoding="utf-8").read(), globals())
_src = open("../../bk/mk_statue_obj11.py", encoding="utf-8").read()
exec(_src[_src.index("rnd.seed("):_src.index("LABEL = ['Physique']")])      # KO 등
rnd.seed(20261301)
sys.path.insert(0, '../../bk')
import bg_library as _BG
OUTD = [b[0] for b in _BG.B if b[4]]
POOL = {b[0]: b[1] for b in D.BODIES}; POOL.update({nm: desc for nm, ko, kod, desc in NB})
_NBd = POOL["Nubian booty builder"]
POOL["Nubian bust builder"] = _NBd.replace("wide flaring lats", "a full, heavy, firm bust standing out on her chest").replace("a deeply carved abdomen with sharp obliques", "a deeply carved six-pack abdomen with sharp obliques")
POSES = {"s_curve": "standing facing the camera in a graceful S-curve, her left hand resting on her flared hip and her right hand lifting her hair away from her neck",
         "walk": "walking toward the camera with a slow swaying runway stride, one hand brushing her hair back",
         "over_shoulder": "standing in three-quarter view with her weight on one leg, one hand on her flared hip, looking back over her shoulder at the camera",
         "crossed": "standing facing the camera with one leg crossed in front of the other, both hands resting on her hips, her head tilted slightly",
         "wide": "standing in a wide confident stance facing the camera, both hands resting on her flared hips, her chin lifted"}
SHOES = ["Extreme gold ballet heels", "Extreme black patent stiletto pumps", "Extreme silver platform sandals", "Extreme red lacquer platform pumps"]
NAILS = ["Long square nails, glossy finish.", "Long almond nails, chrome finish.", "Long coffin nails, deep burgundy.", "Long stiletto nails, glossy black."]
BG = ["plain seamless deep-charcoal", "plain seamless mid-grey", "plain seamless deep-navy"]
NATSM = [("Korean", "smooth fair skin with a warm undertone"), ("Korean", "luminous porcelain skin"), ("Chinese", "smooth fair skin with a neutral undertone"), ("Chinese", "light skin with a warm golden undertone"), ("Japanese", "smooth pale skin with a cool undertone"), ("Japanese", "smooth fair skin with a neutral undertone")]
FACEM = ["a rugged masculine face with a strong square jaw, heavy straight brows and prominent cheekbones", "a chiseled masculine face with a broad jaw, deep-set eyes and a strong brow ridge", "a mature masculine face with a squared chin, a strong nose and a thick neck", "a hard-edged masculine face with a wide jaw, thick brows and a defined Adam's apple"]
MKUM = [""]
BEARDM = ["light stubble", "a short neatly trimmed beard", "a short trimmed beard and moustache", "a dark five-o'clock shadow"]
NATHC = [i for i, h in enumerate(HC) if h[:4] in ("HCJB", "HCNB", "HCDB", "HCCB", "HCAB")]
HKM = ["HSS스트레이트", "HSW웨이브", "HSSK슬릭백", "HSSH샤기컷"]
AGESM = ["in his late 20s", "in his early 30s", "in his mid 30s", "in his late 30s"]
import full_dicts as _F
SHOECOL = ["gold", "black", "red", "silver", "white", "cobalt-blue", "hot-pink"]
def craft(c):
    cn, cd, cb, cf = CRAFT_DB_FULL[c]
    return f"{cn} ({cd}), wide {cb} bands following every deep crease and curving around the hips and thighs like contour lines, dense {cf} filling the space between every band", cn

import json, collections
import full_dicts as F
CORE = ["legendary bust", "curved bust", "siren bust hourglass", "glamour hourglass", "hourglass bombshell", "black glamour", "apex siren", "violin hip hourglass", "latina curves", "Brazilian booty glam"]
for _k in CORE: assert _k in POOL, _k
JTYPE_EN = {"JE":"earrings","JN":"necklaces","JB":"bracelets","JR":"rings","JA":"anklets","JH":"hair ornaments"}
JSING = {"JE":"earring","JN":"necklace","JB":"bracelet","JR":"ring","JA":"anklet","JH":"hair ornament"}
JMETAL_EN = {"JMG":"gold","JMS":"silver","JMR":"rose-gold","JMP":"platinum","JMX":"mixed-metal"}
JQ_SHORT = {"JQ1":"a single {m} {s}","JQ2":"two to three {m} {p}","JQ3":"four to six layered {m} {p}","JQ4":"seven to ten heavily stacked {m} {p}","JQ5":"an extreme maximalist stack of well over ten {m} {p}"}
MALEIDOL = ["a handsome young man's idol face with a clean sharp jawline, straight thick brows and long defined eyes", "a handsome male model face with high cheekbones, a straight nose, a firm jaw and straight dark brows", "a striking young male model face with sharp straight brows, a strong chin and a visible Adam's apple",
            "a sleek K-pop male idol face with a straight nose, a sharp jawline, thick brows and cool narrow eyes", "a clean-cut young male model face with defined cheekbones, a firm jaw and strong straight brows", "an elegant handsome young male face with a high nose bridge, a defined jaw, straight brows and a strong neck"]
BOYISH = ["a pretty-boy idol face with flawless smooth skin, large clear eyes, a slim jaw and soft full lips", "a youthful K-pop idol face with a small V-line jaw, bright double-lidded eyes and a straight nose", "a delicate beautiful-boy face with long lashes, a slim straight nose and a clean jawline", "a fresh-faced boy-group idol face with clear glowing skin, bright eyes and a gentle smile line", "a youthful boy-group center idol face with neat sharp brows, a slim nose and glossy full lips", "a pretty androgynous idol face with large doe eyes, a small chin and a soft jaw"]
PRETTY = ["a pretty-boy idol face with flawless smooth skin, large clear eyes, a slim jaw and soft full lips", "a youthful K-pop idol face with a small V-line jaw, bright double-lidded eyes and a straight nose", "a delicate beautiful-boy face with long lashes, a slim straight nose and a clean jawline"]
IDOLF = ["a pretty-boy idol face with flawless smooth skin, large clear eyes, a slim jaw and soft full lips", "a youthful K-pop idol face with a small V-line jaw, bright double-lidded eyes and a straight nose", "a delicate beautiful-boy face with long lashes, a slim straight nose and a clean jawline", "a fresh-faced boy-group idol face with clear glowing skin, bright eyes and a gentle smile line", "a youthful boy-group center idol face with neat sharp brows, a slim nose and glossy full lips", "a pretty androgynous idol face with large doe eyes, a small chin and a soft jaw"]
IDOLB = ["clean-shaven", "a very faint trace of stubble", "a very faint trace of stubble"]
def face_pick():
    if rnd.random() < 0.65: return rnd.choice(MALEIDOL), rnd.choice(IDOLB), True
    return rnd.choice(BOYISH), "clean-shaven", True
AGESB = ["in his early 20s", "in his mid 20s", "in his late 20s", "in his early 30s", "in his mid 30s", "in his late 30s", "in his early 40s", "in his mid 40s"]
MKB = [("", ""), ("dramatic black smoky eyeshadow with sharp winged eyeliner", "블랙 스모키 윙"), ("metallic gold glitter eyeshadow with defined lashes", "골드 글리터 아이"), ("graphic electric-blue eyeliner extended into bold wings", "그래픽 블루 라인"), ("deep plum smoky eyes with dark lashes", "플럼 스모키"), ("silver foil-lined eyes with a cool shimmer", "실버 포일 아이")]
BADCRAFT = {"CroatianHvar", "FinnishIittala", "UkrainianPysanka"}
CRAFTS = [c for c in T.CRAFTS_39 if c not in BADCRAFT]
PLAT = lambda k: k.startswith("플랫폼") or k.startswith("익스트림플랫폼")
SHOEK = list(T.SHOES_24)
POSE_ALL = [k for k in T.POSE_19 if k != "얼굴감싸기"]
POSE_GRP = ["정면와이드스탠스", "3/4각도", "뒷모습3/4", "걷는동작", "허리손", "머리넘기기"]
LAB3 = ["LEFT", "CENTER", "RIGHT"]; LAB2 = ["LEFT", "RIGHT"]
ART = ("{lab}Body Art: Her bare skin is painted in {ct}. The paint is pigment sitting on living skin, so it distorts slightly over every bulge. The paint covers her whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of her hands, sides, back, rear, lower belly, knees, calves and the tops of her feet. Her face is left unpainted and the pattern fades out at the neck with no hard line.")
def shoe_line(lab):
    k = rnd.choice(SHOEK); en = re.sub(r"^extreme ", "", F.SHOE_EN_FULL[k]); col = rnd.choice(SHOECOL)
    if PLAT(k): return f"{lab}Footwear: Extreme {col} {en}, the platform soles rising far higher than her ankle bone, at least three times the thickness of an ordinary heel.", k
    return f"{lab}Footwear: Extreme {col} {en} with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform.", k

MBODIES = {
 "V자 보디빌더": "An extraordinarily large and powerful man, far beyond any real person. A massive V-shaped torso: enormously broad shoulders with capped, rounded deltoids, a thick heavy chest, a deeply carved six-pack abdomen narrowing to a comparatively small waist, huge thick arms with split biceps and horseshoe triceps, wide flaring lats, and powerful thick quads and diamond calves. His head stays in correct proportion to his broad frame.",
 "린 애슬레틱": "A tall, lean, athletic man built like a swimmer. Broad shoulders tapering cleanly to a narrow waist, a defined chest, a visible eight-pack abdomen with sharp obliques, long strong arms with clear vein definition, and long lean muscular legs with defined calves. Nothing bulky, everything taut and sculpted.",
 "키 큰 슬렌더": "A very tall, slim, long-limbed man with a runway build. Straight shoulders, a flat lean chest, a flat defined stomach, slender strong arms and very long legs, lightly muscled and elegant, with visible collarbones and a narrow waist. His head stays in correct proportion to his long frame.",
 "파워리프터": "A thick, heavy, extremely strong man built like a powerlifter. A huge barrel chest, enormously wide shoulders and back, a thick solid waist with a firm rounded belly over strong abs, massive arms, and enormous thick thighs and calves. Every part is large, dense and continuous rather than sharply cut.",
 "대형 헤비": "A giant, big-bellied man with great natural size throughout. Broad powerful shoulders, a wide heavy chest, a large round soft belly hanging over a thick waist, thick strong arms, and wide heavy thighs beneath. Every curve is large, solid and continuous, with a warm, imposing bearing.",
 "클래식 머슬": "A classically muscular athletic man in the shape of a Greek statue. Wide shoulders, a full defined chest, a clean six-pack abdomen, strong rounded arms, and muscular thighs and calves, balanced and proportionate from head to toe, powerful but not exaggerated.",
 "스트롱맨": "A massive, stocky strongman. A thick short neck, huge round shoulders, an enormously deep chest, a thick powerful midsection with a solid belly, tree-trunk arms, and huge thick legs planted wide. Heavy, dense and immovable, every part solid.",
 "중년 실버 아스레틱": "A fit mature man in his late 40s with an athletic, well-kept build. Broad shoulders, a firm defined chest, a flat strong abdomen with visible lines, strong forearms, and lean strong legs, with the quiet, assured bearing of a man who has trained for decades.",
}
NATS = [("Korean", "smooth fair skin with a warm undertone"), ("Korean", "luminous porcelain skin"), ("Chinese", "smooth fair skin with a neutral undertone"), ("Chinese", "light skin with a warm golden undertone"), ("Japanese", "smooth pale skin with a cool undertone"), ("Japanese", "smooth fair skin with a neutral undertone")]
FACE = ["a refined idol face with a clean sharp jawline and long defined eyes", "a handsome model face with high cheekbones and a straight nose", "a soft-featured idol face with large clear eyes and a defined jaw", "a striking model face with sharp brows and a narrow chin"]
BEARD = ["clean-shaven", "clean-shaven", "clean-shaven", "a very faint trace of stubble"]
MKU = [("natural idol makeup with soft brown eyeshadow and a tinted lip", "아이돌 내추럴 메이크업"), ("light smoky eyeliner and glossy skin", "라이트 스모키"), ("glass-skin makeup with a faint shimmer on the cheekbones", "글래스 스킨"), ("", "메이크업 없음")]
MOOD = ["calm and cool", "intense and focused", "composed and elegant", "relaxed with a faint half-smile", "fierce and charismatic"]
HK = ["HSS스트레이트", "HSW웨이브", "HSSK슬릭백", "HSSH샤기컷", "HSWF울프컷", "HSPX픽시컷", "HSTN탑노트"]
AGES = ["in his early 20s", "in his mid 20s", "in his late 20s", "in his early 30s", "in his mid 30s"]
NAILS = ["Short, clean nails with a matte black polish.", "Short natural nails.", "Short nails with a glossy dark-grey polish.", "Short nails with a metallic gold polish."]
MBODY = ["V자 보디빌더", "린 애슬레틱", "키 큰 슬렌더", "파워리프터", "대형 헤비", "클래식 머슬", "스트롱맨"]
MNATS = [("Korean", "smooth fair skin with a warm undertone"), ("Korean", "luminous porcelain skin"), ("Chinese", "smooth fair skin with a neutral undertone"), ("Chinese", "light skin with a warm golden undertone"), ("Japanese", "smooth pale skin with a cool undertone"), ("Japanese", "smooth fair skin with a neutral undertone")]
BOYF = ["a pretty-boy idol face with flawless smooth skin, large clear eyes, a slim jaw and soft full lips", "a youthful K-pop idol face with a small V-line jaw, bright double-lidded eyes and a straight nose", "a delicate beautiful-boy face with long lashes, a slim straight nose and a clean jawline", "a fresh-faced boy-group idol face with clear glowing skin, bright eyes and a gentle smile line", "a youthful boy-group center idol face with neat sharp brows, a slim nose and glossy full lips", "a pretty androgynous idol face with large doe eyes, a small chin and a soft jaw"]
EYEMK = [x[0] for x in MKB if x[0]]
MMOOD = ["calm and cool", "intense and focused", "composed and elegant", "relaxed with a faint half-smile", "fierce and charismatic"]
FHS = [h for h in T.HAIR_STYLE if h[:4] not in ("HSTT", "HSSB")]
FEMBODY = ["legendary bust", "curved bust", "siren bust hourglass", "glamour hourglass", "hourglass bombshell", "black glamour", "apex siren", "violin hip hourglass", "latina curves", "Brazilian booty glam"]
MART = ("{lab} Body Art: His bare skin is painted in {ct}. The paint is pigment sitting on living skin, so it distorts slightly over every muscle and bulge. The paint covers his whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of his hands, sides, back, rear, lower belly, knees, calves and the tops of his feet. His face is left unpainted and the pattern fades out at the neck with no hard line.")
FART = ("{lab} Body Art: Her bare skin is painted in {ct}. The paint is pigment sitting on living skin, so it distorts slightly over every bulge. The paint covers her whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of her hands, sides, back, rear, lower belly, knees, calves and the tops of her feet. Her face is left unpainted and the pattern fades out at the neck with no hard line.")
def pose_t(k, male):
    t = F.POSE_EN_FULL[k]
    return re.sub(r"\bherself\b", "himself", re.sub(r"\bher\b", "his", t)) if male else t
def shoe2(lab, male):
    k = rnd.choice(list(T.SHOES_24)); en = re.sub(r"^extreme ", "", F.SHOE_EN_FULL[k]); col = rnd.choice(SHOECOL); pr = "his" if male else "her"
    if PLAT(k): return f"{lab} Footwear: Extreme {col} {en}, the platform soles rising far higher than {pr} ankle bone, at least three times the thickness of an ordinary heel."
    return f"{lab} Footwear: Extreme {col} {en} with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform."
def jw():
    q = rnd.choice(list(JQ_SHORT)); jm = JMETAL_EN[rnd.choice(list(JMETAL_EN))]; jt = rnd.choice(list(JTYPE_EN)); return JQ_SHORT[q].format(m=jm, s=JSING[jt], p=JTYPE_EN[jt])
def nailz():
    return f"Long {NAIL_SHAPE_EN_FULL[rnd.choice(T.NAIL_SHAPES)]} nails, {NAIL_FIN_EN_FULL[rnd.choice(T.NAIL_FINISH)]} finish."
def person(lab, kind, bkey, pk):
    ck = rnd.choice(CRAFTS); ct, cn = craft(ck)
    hs = rnd.choice(FHS); hc = rnd.choice(T.HAIR_COLOR); hair = f"{HAIR_COLOR_EN_FULL[hc]} hair styled in {HAIR_EN_FULL[hs]}"
    if kind == "F":
        mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk)
        t1 = f"{lab}: ONE real adult {nat} woman, her face exactly the same tone as her body, real skin texture with visible pores and fine grain, {fa}, {hair}, real living eyes, wearing {jw()}. {nailz()}"
        ph = f"{lab} Physique: {POOL[bkey]} Her arms, hands, legs and feet stay in correct proportion to each other."
        art = FART.format(lab=lab, ct=ct); pose = f"{lab} Pose: {pose_t(pk, False)}."; tag = f"여성 {KO.get(bkey, bkey)}·메이크업 {mk}"
    elif kind == "MF":
        natm, skinm = rnd.choice(NATSM); agem = rnd.choice(AGESB[:3]); mkt, mko = rnd.choice(MKB)
        if rnd.random() < 0.65: fc, bd = rnd.choice(MALEIDOL), rnd.choice(IDOLB)
        else: fc, bd = rnd.choice(BOYISH), "clean-shaven"
        mk = (", " + mkt) if mkt and False else ""
        t1 = f"{lab}: ONE real adult {natm} person with a handsome man's face on a full, curvaceous female body — a man {agem}, his face exactly the same tone as his body, real skin texture with visible pores and fine grain, {fc}, {bd}, {skinm}, {hair}, real living eyes, wearing {jw()}. {nailz()}"
        ph = f"{lab} Physique: {POOL[bkey]} Her arms, hands, legs and feet stay in correct proportion to each other."
        art = FART.format(lab=lab, ct=ct); pose = f"{lab} Pose: {pose_t(pk, False)}."; tag = f"남성얼굴·여성체형 {KO.get(bkey, bkey)}"
    else:
        nat, skin = rnd.choice(MNATS); age = rnd.choice(["in his early 20s", "in his early 20s", "in his mid 20s", "in his mid 20s", "in his late 20s"]); mkt = rnd.choice(EYEMK)
        t1 = f"{lab}: ONE real adult {nat} man {age}, his face exactly the same tone as his body, real skin texture with visible pores and fine grain, {rnd.choice(BOYF)}, clean-shaven, {mkt}, {skin}, {rnd.choice(MMOOD)}, {hair}, real living eyes, wearing {jw()}. {nailz()}"
        ph = f"{lab} Physique: {MBODIES[bkey]} His arms, hands, legs and feet stay in correct proportion to each other."
        art = MART.format(lab=lab, ct=ct); pose = f"{lab} Pose: {pose_t(pk, True)}."; tag = f"남성 {bkey}"
    return "\n".join([t1, ph, art, pose, shoe2(lab, kind == "M")]), f"{tag}({cn})"
SKINP = "Real photographic skin — visible pores and fine grain, a taut surface with natural creases and shadow only where the flesh and muscle fold. No smooth illustration finish, no plastic CG sheen."
def build(kinds):
    n = len(kinds); labs = ["LEFT", "RIGHT"] if n == 2 else ["LEFT", "CENTER", "RIGHT"]
    _bid = rnd.choice(OUTD); BGD = _BG.desc(_bid); BGK = [b[2] for b in _BG.B if b[0] == _bid][0]
    BGD = BGD.replace("completely empty of other people", "empty of any people other than the subjects").replace("made of the same material as her", "made of the same material as them")
    blocks, tags = [], []
    for lab, kd in zip(labs, kinds):
        bk = rnd.choice(MBODY) if kd == "M" else rnd.choice(FEMBODY)
        t, tg = person(lab, kd, bk, rnd.choice(POSE_GRP)); blocks.append(t); tags.append(tg)
    if n == 2:
        fmt = "a vertical portrait-orientation photograph, 4:5 aspect ratio, taller than it is wide"; word = "TWO people standing side by side with generous spacing so every figure reads clearly and nobody's arms cross a neighbour"; cam = "the camera set back so both are visible from head to toe"; endl = "Vertical 4:5 portrait-orientation full-body photograph, taller than it is wide, all faces toward the camera."
    else:
        fmt = "a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide"; word = "THREE people standing close side by side, shoulder to shoulder in a single row, with just enough spacing that every figure reads clearly and nobody's arms cross a neighbour"; cam = "the camera set back far enough that all three are visible from head to toe, the whole row filling the width of the tall frame"; endl = "Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide, all faces toward the camera."
    p = (f"Image format: {fmt}.\n\n"
         f"A full-body photograph in {BGD}, {word}, {cam}, shot on a medium format camera with an 85mm lens at f/8, in natural sunlight, sharp focus on every figure, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n"
         + "\n\n".join(blocks) + "\n\n" + f"Skin (everyone): {SKINP}\n\n"
         f"Background & Lighting: each painted pattern catching the sunlight in sharp glints, the sunlight carving every fold, curve and muscle. {endl}")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), re.findall(r"\b(\w+) \1\b", p)
    return p, " / ".join(tags), BGK
PLANS = [("듀오", ["F", "M"]), ("듀오", ["MF", "M"]), ("트리오", ["F", "MF", "M"])]
L = ["# LumineX — 혼합 듀오·트리오 샘플 3개 (여성 / 남성 얼굴+여성 체형 / 남성)\n", "한 화면에 서로 다른 유형이 함께 서 있습니다. 전원 바디페인팅·40인치 힐 계열 신발·주얼리·긴 손톱, 야외 세로 구도입니다. 성공/실패 번호만 알려주세요. 중성적으로 나와도 변주로 봅니다.\n"]
for n, (kind, kinds) in enumerate(PLANS, 1):
    while True:
        try: p, d, bk = build(kinds); break
        except AssertionError: continue
    L.append(f"## {n}. {kind} · {d} · 배경 {bk}\n\n```\n{p}\n```\n"); print(n, kind, d, bk, len(p.split()))
open("/mnt/user-data/outputs/LumineX_Mixed_DuoTrio3.md", "w", encoding="utf-8").write("\n".join(L))
