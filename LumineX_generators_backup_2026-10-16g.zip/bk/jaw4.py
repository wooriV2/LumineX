import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
from cover_lib import SAFE
HEAD="Professional fashion photograph, close-up beauty portrait. ONE woman, facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp. Mid 20s."
HEAD_W=HEAD.replace("down to the base of her neck and the tops of her collarbones, the frame cutting off there","down to her collarbones and the tops of her shoulders, the frame cutting off there, so the earrings fully hang in view")
TAIL=" Every feature is exaggerated but beautiful, balanced and refined, in harmony with the rest of her face, never distorted, never grotesque. Real skin fine grain and a soft sheen of natural oils on her face, ears and neck, individual hair strands catching the light — a photograph of a real woman, not an illustration, not a render."
SK="The skin around every piece is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
IRON="rough black cast iron with a hammered, pitted, matte surface"
def sub(txt): return "Subject: "+txt+TAIL


ANG_TXT="her head turned about forty-five degrees to her left in a three-quarter view, her eyes still looking straight into the camera, one ear and the turned cheek clearly visible, and from this angle the full projection of her lips from her face is clearly visible,"
H45=HEAD.replace("facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face,",ANG_TXT)
assert H45!=HEAD
def lipsub(face,lips):
    return sub("A real photograph of a strikingly beautiful adult woman, mid 20s, "+face+" Her lips are the star of her face: "+lips+" Her eyes are large and bright with bright real catchlights and a round natural pupil, her skin flawless and glowing, a small refined nose and a soft defined jaw. A confident, alluring gaze into the camera.")
def jawsub(face,jaw):
    return sub("A real photograph of a strikingly beautiful adult woman, mid 20s, "+face+" The jawline and chin are the star of her face: "+jaw+" Her eyes are large and bright with bright real catchlights and a round natural pupil, her skin flawless and glowing, softly full lips and a refined nose. A confident gaze into the camera.")
VL=jawsub("a Korean woman with long, sleek dark-brown hair swept behind her ears and luminous fair skin.","an extreme, razor-sharp V-line: the cheeks taper in a long, smooth, straight diagonal from the ears down to a small, narrow, pointed chin, a very slim lower face with no jaw width at all, a sharply defined sculpted jaw edge, high soft cheekbones, and a delicate small chin tip.")
SQ=jawsub("a Western woman with long platinum-blonde hair swept back behind her ears and fair skin.","a strong, angular, square jawline: a wide, clearly defined, sharp-cornered jaw angle just below each ear, a broad flat chin with a slight cleft, hollow sculpted cheeks and very high, razor-sharp cheekbones, a powerful, chiselled, statuesque lower face.")
HEART=jawsub("a Mediterranean woman with long dark curly hair swept behind her ears and warm golden skin.","a heart-shaped face: a wide forehead and high, full cheekbones narrowing in a smooth curve into a delicate, pointed, softly rounded chin like the tip of a heart, with soft, smooth jaw edges.")
ROUND=jawsub("a Japanese woman with a soft bob with blunt bangs, dark-brown hair and fair skin with a pink blush.","a soft, round, 'baby face' jaw: full, plump, rounded cheeks, a short, soft, rounded jawline with no sharp angles and a small, round, slightly full chin, youthful and sweet.")
def gold(): return "Piercings: Exactly four piercings in total, only on the ear and nostril visible in this view: on the visible ear a large gold hoop with small diamonds in the lobe and two gold studs with diamonds up the rim; and one gold stud with a diamond in the nostril wing. Each piece is large and clearly visible, and nothing else on the face is pierced, her lips carry no piercing. "+SK+" All jewelry is real polished yellow gold set with clear diamonds,"+SAFE
def pearl(): return "Piercings: Exactly four piercings in total, only on the ear and nostril visible in this view: on the visible ear a large pastel-pink enamel hoop in the lobe and two small pearl studs up the rim; and one small pearl stud in the nostril wing. Each piece is large and clearly visible, and nothing else on the face is pierced, her lips carry no piercing. "+SK+" All jewelry is real polished gold with pastel-pink enamel and white pearls,"+SAFE
def steel(): return "Piercings: Exactly four piercings in total, only on the ear and nostril visible in this view: on the visible ear a large black steel hoop in the lobe and two black steel studs up the rim; and one black steel ring around the nostril wing. Each piece is large and clearly visible, and nothing else on the face is pierced, her lips carry no piercing. "+SK+" All jewelry is real blackened steel,"+SAFE
def anime_p(): return "Piercings: Exactly eight piercings in total, cute and colourful: on each ear a large glossy pastel-pink enamel hoop in the lobe and three small star-shaped studs in pastel enamel up the rim, symmetrical on both sides. Each piece is large and clearly visible, and nothing else on the face is pierced. "+SK+" All jewelry is real polished gold with pastel enamel and small gems,"+SAFE
V=[("V라인 (45도) — 한국·긴 직모·쇄골 위까지 갸름한 턱 · 골드+다이아 4",VL,gold(),H45,True),
   ("각진 강한 턱 (45도) — 서양인·플래티넘 금발·사각 턱+높은 광대 · 블랙 스틸 4",SQ,steel(),H45,True),
   ("하트형 턱 (45도) — 남유럽·검은 곱슬·부드럽게 뾰족한 턱 · 진주+핑크 에나멜 4",HEART,pearl(),H45,True),
   ("둥근 베이비 페이스 (45도) — 일본·단발·통통한 볼과 둥근 턱 · 골드+핑크 에나멜 4",ROUND,pearl(),H45,True)]
o=["# LumineX — 턱선 4종 (45도): V라인·각진 턱·하트형·둥근 베이비 페이스\n","- 45도 구도는 턱선과 광대 윤곽이 보이게 하려는 것. 피어싱은 보이는 쪽 귀·콧볼 4개만(3/4 구도에서 피어싱이 사라지는 경향 대비), 입술 피어싱 없음.","- 정상/이상(+ 턱선 모양이 보이는지)만 번호로 알려주세요.\n"]
for i,(lab,sj,p,h,tq) in enumerate(V,1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(85000+i*100+tr),"한국","20대","도도한",style="NONE",slots=["pierce"],pier_level="P5"); break
        except AssertionError: continue
    else: raise SystemExit(i)
    ps=t.split("\n\n")
    depth=[x for x in ps if x.startswith("Piercing depth:")][0]; light=[x for x in ps if x.startswith("Lighting:")][0]
    if tq:
        light,n=re.subn(r"A soft frontal light on her face and ears","A soft key light from the front and slightly to the side on her face, shaping the cheek and jawline with a soft shadow below the jaw",light,count=1); assert n==1
    new="\n\n".join([h,sj,p,depth,light]); assert not re.search(r"[가-힣]",new)
    o.append(f"## {i}. {lab}\n\n```\n{new}\n```\n")
open('/mnt/user-data/outputs/LumineX_Jawline45_4.md','w',encoding='utf-8').write("\n".join(o)); print("ok")
