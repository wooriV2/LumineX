import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
def run_until(fn,marker):
    src=open(fn).read(); src=src[:src.index(marker)]
    ns={}; exec(compile(src,fn,'exec'),ns); return ns
HL=run_until('heavy_ladder.py','PL=[')
M2=run_until('random_mix2.py','rr=random.Random(')
NSC=run_until('combo_C.py','CFG=')
w=HL['w']; pl=HL['pl']; rim=HL['rim']; ears=HL['ears']; HW=HL['HW']; COL=HL['COL']; SAFE=HL['SAFE']; counts=HL['counts']; HENNA=HL['HENNA']; STICK=HL['STICK']; TH=HL['TH']
EYES=M2['EYES']; LIPS=M2['LIPS']; NOSES=M2['NOSES']; JAWS=M2['JAWS']; MATS=M2['MATS']
OUT='/mnt/user-data/outputs/'
SK="The skin around every piece is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
WEIGHT="carrying one massive solid weight of rough black cast iron with a hammered, pitted, matte surface, a squat solid cube-shaped block as big as a fist, which hangs below her chin onto her neck and looks crushingly heavy; the chain is thin enough that both of her lips stay clearly visible on either side of it, and the weight pulls the chain bar-straight and taut"
def tuskcore(mat):
    return ("a single thick, solid, sharp tusk of "+mat[1]+" as thick as her thumb in the middle passes straight through the lower part of the septum, the thin soft wall between the nostrils, and sweeps out sideways just beneath her nostril wings, only as far as their outer edges and not one bit further, in a short, smooth boar-tusk curve, its two ends rising clearly upward and tapering to needle-sharp points, the tips ending far below her eyes at the height of her nostrils; the tusk sits clearly above her upper lip and does not touch or cover her lips")
def para2(N,nw,metal,gems,deco,rr,pat=None,mat=None,zero=()):
    c=counts(N)
    for k in zero: c[k]=0
    seg=[]
    if pat:
        core=tuskcore(mat)
        if pat=="A": seg.append(core+"; from the exact middle of the tusk a thick iron connector ring hangs down, and from this ring a thick, heavy chain of black iron links drops straight down in front of her mouth and chin, "+WEIGHT)
        elif pat=="B": seg.append(core+"; from the exact middle of the tusk a thick iron connector ring hangs down, and from it a short, thick chain of a few heavy black iron links drops straight down in front of her closed mouth and is fastened to a thick iron ring through the middle of her lower lip's edge, a plain round ring as wide as a large coin, and from this lip ring a thick, heavy chain of black iron links continues straight down in front of her chin, "+WEIGHT)
        else: seg.append(core+"; nothing hangs from the tusk")
    else:
        seg.append(("a single large " if c["sep"]==1 else f"{w(c['sep'])} separate ")+"septum ring"+("" if c["sep"]==1 else "s")+" of different sizes and shapes through the thin soft wall between the nostrils, in a short stack that ends above the upper lip")
    h=c["nos"]//2
    if h: seg.append(f"{pl(h,'small ring')} wrapping snugly around each nostril wing")
    if c['bri']: seg.append(f"{pl(c['bri'],'straight bar')} across the bridge of the nose, from just below the inner ends of the brows (well clear of the eyes) down to the middle of the nose, each with a gem cap at both ends")
    h=c["brow"]//2
    if h: seg.append(f"{pl(h,'small bar or ring')} through each eyebrow, all on the brow bone above the eyes and never on the eyelids")
    if c['ul']: seg.append(f"{pl(c['ul'],'small hoop or stud')} along the edge of the upper lip")
    if pat!="B" and c['ll']: seg.append(f"{pl(c['ll'],'small hoop or stud')} across the lower lip's edge")
    if pat=="C": seg.append(NSC['CHIN'].rstrip('.'))
    elif c['chin']: seg.append(f"{pl(c['chin'],'small ring or stud')} on the chin")
    h=c["ear"]//2
    seg.append(f"on each ear, one very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel, passes through one large healed opening in the stretched lobe, and above it sit {rim(h-1)}")
    if c['fh']: seg.append(f"{pl(c['fh'],'small stud')} across the lower half of the forehead just above the brows in even rows, leaving the upper forehead free")
    h=c["tmp"]//2
    if h: seg.append(f"{pl(h,'small stud')} on each temple bone, well clear of the eyes")
    h=c["chk"]//2
    if h: seg.append(f"{pl(h,'small stud')} along each cheekbone, well clear of the eyes")
    tot=sum(c.values())+(1 if pat else 0)
    dens=("The piercings are packed so densely that the rows touch and overlap, leaving only hairline gaps of bare skin between them, until the face reads as a single armour of metal; the eyes and eyelids stay clear. " if N>=100 else "The pieces are spread over the whole face in clear rows so every one reads individually, with bare skin between them; the eyes and eyelids stay clear. ")
    heavy=f"All the ear weights hang from the bottom of each lobe's one iron ring, and they are not counted in the piercing total: on each ear there are exactly {w(nw)} separate massive solid weights, each of a different shape: "+ears(nw,rr)+". "+HW.format(col=COL[nw])
    tail=f" The face and ear jewelry is real {metal} set with {gems}"
    if pat: tail+=f", the tusk and its rings are real {mat[2]}, while the connector ring, the chains and all the hanging weights are always black cast iron,"
    else: tail+=", while the hanging weights are always black cast iron,"
    return (f"Piercings: A face fully covered with real piercings, about {w(tot)} in total (not counting the hanging weights), spread over every area so that no area is empty: "+"; ".join(seg)+". The left and right sides are balanced. "+dens+deco+" "+heavy+tail+SAFE),tot
HDR="facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face,"
LIT="A soft frontal light on her face and ears;"
ANG45="her head turned about forty-five degrees to her left in a three-quarter view, her eyes still looking straight into the camera, one ear and the turned cheek clearly visible, and from this angle the full projection of her lips from her face is clearly visible,"
KEY="A soft key light from the front and slightly to the side on her face;"
FR_OLD="down to the base of her neck and the tops of her collarbones, the frame cutting off there"
FR={"sh":"down to the line of her shoulders, the frame cutting off just below them, so the weights fully hang in view","ch":"down to the middle of her chest, the frame cutting off there, so the weights and chains fully hang in view"}
def build(i,seed,nat,grp,expr,star,item,N,nw,v,deco,pat,zero):
    rr=random.Random(seed); jaw=rr.choice(JAWS); nose=rr.choice(NOSES); mat=rr.choice(MATS) if pat else None
    metal,gems=TH[v]
    for tr in range(80):
        try: t,title,meta=G.make(random.Random(seed*7+tr),nat,grp,expr,style="NONE",slots=["pierce","lens"],pier_level="P150" if N>=100 else ("P50" if N>=50 else "P25")); break
        except AssertionError: continue
    else: raise SystemExit("gen fail")
    pp=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    new,tot=para2(N,nw,metal,gems,deco,random.Random(seed+5),pat,mat,zero)
    t=re.sub(r'\n\nJewelry:[^\n]*','',t.replace(pp,new))
    sj=[x for x in t.split("\n\n") if x.startswith("Subject:")][0]
    if star=="eye": star_s=f"her eyes are the star of her face: {item[1].format(lens='coloured')}"
    else: star_s=f"her lips are the star of her face: {item[1]}"
    add=f" Her face has been surgically sculpted far beyond her natural look, and these changes override her natural features: {star_s}; her nose: {nose[1]}; her jawline and chin: {jaw[1]}. Every feature is exaggerated but beautiful, balanced and refined, in harmony with the rest of her face, never distorted, never grotesque."
    t=t.replace(sj,sj+add)
    fr=FR["ch"] if pat else FR["sh"]
    t,n=re.subn(re.escape(FR_OLD),fr,t,count=1); assert n==1
    if star=="lip":
        t=t.replace(HDR,ANG45,1); t=t.replace(LIT,KEY,1)
    t=t.replace("\n\nLighting:","\n\nHair: her hair is swept back behind both ears, leaving both ears, her jawline and her neck fully visible so every hanging piece is in clear view.\n\nLighting:",1)
    assert not re.search(r"[가-힣]",t)
    ang="정면" if star=="eye" else "45도"
    lab=f"{nat} · {grp} · {expr} · {item[0]} · {nose[0]} · {jaw[0]} · {ang} · P{N}({v})+귀 추 {nw}개/귀"+(f" · 엄니({mat[0]}) 패턴{pat}" if pat else "")+(" · 헤나" if "Henna" in deco else "")+(" · 스티커" if "Stickers" in deco else "")+f" · {title.split(' · ')[-1]} · 피어싱 합계 약 {tot}개"
    return lab,t
BOTH=HENNA+" "+STICK
PLAN=[("eye",EYES[1],"한국","20대","도도한",100,9,"화려",HENNA,"A",("tmp",)),
("eye",EYES[0],"중국","20대","섹시한",50,8,"수수",STICK,None,()),
("eye",EYES[2],"일본","아이돌","몽환적인",50,8,"귀여움",BOTH,"C",()),
("eye",EYES[3],"한국","30대","고혹적인",100,10,"수수",HENNA,None,()),
("lip",LIPS[0],"일본","20대","카리스마 있는",50,8,"화려",STICK,"B",("ul","ll")),
("lip",LIPS[1],"한국","아이돌","귀여운",25,8,"귀여움",BOTH,None,("ul","ll")),
("lip",LIPS[2],"중국","30대","군림하는",50,10,"수수",HENNA,"A",("ul","ll")),
("lip",LIPS[3],"한국","20대","도도한",25,8,"화려",STICK,None,("ul","ll"))]
o=["# LumineX — 채택 항목 섞은 확인 세트 v2 (8개 · 귀 추·피어싱 전면·스티커·헤나·렌즈 포함)\n",
"- 기본값 복원: 모든 프롬프트에 귀 무쇠 링+뭉툭한 무쇠 추 8~10개/귀, 얼굴 전체 피어싱 채우기(P25~P100), 렌즈, 헤나/스티커(랜덤)가 들어감. 오늘 정리한 축(눈 4·입술 4·성형 코·턱선·새 엄니 3패턴·옆트임 5배)을 그 위에 얹음.",
"- 1~4 눈 별 정면, 5~8 입술 별 45도(입술 별은 입술 피어싱 제외). 엄니 있는 1·3·5·7번은 엄니가 코 사이 기본 링을 대신함. 메이크업은 별 특징과 겹쳐 없음으로 고정.",
"- 정상/이상(+ 별 특징이 보이는지, 귀 추·피어싱·헤나·스티커가 빠졌는지)만 번호로 알려주세요.\n"]
for k,(st,it,nat,grp,ex,N,nw,v,deco,pat,zero) in enumerate(PLAN,1):
    lab,t=build(k,3000+k*11,nat,grp,ex,st,it,N,nw,v,deco,pat,zero)
    o.append(f"## {k}. {lab}\n\n```\n{t}\n```\n"); print(k,lab,len(t.split()))
open(OUT+'LumineX_MixedCheck_v2_8.md','w',encoding='utf-8').write("\n".join(o))
