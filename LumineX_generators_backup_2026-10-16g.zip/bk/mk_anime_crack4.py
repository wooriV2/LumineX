import re,sys
sys.path.insert(0,'.')
src=open('mk_anime_crack3.py',encoding='utf-8').read()
exec(src.split("RU2=RU")[0])
def STYLE3(a):
    r="left" if a=="right" else "right"
    return (f"Style: The whole image is a real photograph of a real woman, except for one part of her face. Her neck, collarbones, shoulders, the background and the {r} side of her face are real photographic skin, hair and light. A jagged, irregular crack runs down her face like a crack in glass, from the hairline above the middle of her forehead, between her eyes, down along the {r} edge of her nose so that her whole nose lies on the {a} side of the crack, then across to the exact middle of her lips, so the lips are split evenly in half, and on to the middle of her chin, never cutting through either eye. Everything {a} of the crack is a high-quality Japanese anime illustration with clean cel shading, crisp line art and vibrant colours: her {a} eye, brow, cheek, her whole nose, the {a} half of her lips, her {a} ear with every earring and piercing on it, and the hair above them. The crack ends at her chin and does not continue onto her neck, which is entirely real. It is one woman, one face, one pose: the anime part has the same shape, size and position as the real face it replaces, as if part of a photographed face has broken away to show a drawing beneath.")
IRON2=IRON.replace("blackened cast iron","dark iron").replace("blackened-iron ring","dark iron ring")
def subj4(hair,eye,extra=""):
    s=SUBJ("right",hair,eye).replace("an anime-drawn lip half with a tiny fang at the corner of the mouth","an anime-drawn nose and lip half with a tiny fang at the corner of the mouth")
    return s+(" "+extra if extra else "")
RU3=RU.replace("a cartoon-doll mouth made real:","a cartoon-doll mouth:")
S=[("피어싱 많음 · 금 피어싱 갑옷(약 100개) · 코 전체 애니",build3(subj4("long straight jet-black hair swept back","a sharp upturned anime eye with a cold iris and crisp highlights"),PIERCE3("right",P_C))),
   ("진한 메이크업 · 비주얼계 블랙립 5단계(극한) · 코 전체 애니 · 추 재질 단어 교체",build3(subj4("long straight silver-white hair","a huge glittering anime eye with a star-shaped pupil","Her makeup is the same on both sides, real on the real side and drawn in anime style on the anime side: "+MK+"."),PIERCE3("right",IRON2))),
   ("러시안 립 극한 · 입술 반반 재시도 · 코 전체 애니",build3(subj4("long straight pastel-pink hair with a blunt fringe","a huge sparkling anime eye with a heart-shaped pupil","Her lips are the star of her face, split down the middle by the crack: the left half is a real photographic lip, and the right half is the same extreme lip drawn in anime style, flat glossy cel-shaded pink with painted white highlights and crisp outlines, just as tall and plump as the real half: "+RU3+"."),PIERCE3("right",IRON2)))]
S[2]=(S[2][0],S[2][1].replace("real lips with fine vertical lines","real lips").replace(", and an anime-drawn nose and lip half with a tiny fang at the corner of the mouth",", and an anime-drawn nose and lip half"))
o=["# LumineX — 쪼개진 얼굴 v3: 피어싱 많음 · 진한 메이크업 · 러시안 립 (3개)\n","- 고친 점: ① 코 전체를 애니 쪽에 두도록 균열 경로 변경(코 바깥 옆을 따라 내려오다 입술 정중앙에서 합류, 입술은 반반 유지) ② 2·3번 추 설명의 재질 단어(blackened cast iron → dark iron) 교체 ③ 3번 러시안 립: 애니 쪽 입술을 \"셀 음영·윤곽선, 실사 쪽과 같은 높이·볼륨\"으로 명시하고 \"made real\" 삭제 — 반반 재시도.","- 정상/이상(+ 코가 애니 쪽에 통째로 있는지, 귀걸이가 그림인지, 3번 입술이 양쪽 다 나오는지)만 번호로 알려주세요.\n"]
for i,(lab,t) in enumerate(S,1):
    assert not re.search(r"[가-힣]",t) and "three-quarter" not in t
    o.append(f"## {i}. {lab}\n\n```\n{t}\n```\n"); print(i,len(t.split()))
open(OUT+'LumineX_FaceCrack_Fix_v3_3.md','w',encoding='utf-8').write("\n".join(o))
