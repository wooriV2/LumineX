import sys,re,random,copy
sys.path.insert(0,'.')
import gen_cjk_v2 as G
for x in [f for f in G.F if f["meta"]["piercing"]=="P150"]:
    y=copy.deepcopy(x); y["meta"]["piercing"]="P200"; p=y["prompt"]
    p=p.replace("about one hundred and fifty","about two hundred").replace("ten fine","twelve fine")
    y["prompt"]=p; y["key"]=x["key"]+"_p200"; G.F.append(y)
MAT={"화려":"All jewelry is real, made of yellow gold, silver and rose gold with glossy enamel in red, blue, green, yellow, pink and purple and large cut rainbow gemstones (diamond, ruby, sapphire, emerald, amethyst, opal and pearl) mixed piece by piece — ",
     "귀여움":"All jewelry is real, made of pastel enamel in baby pink, mint, lavender and baby blue, white pearls, pastel gemstones and polished gold, cute and playful — "}
SH={"수수":["round","triangle","square","pentagon","hexagon","diamond-lozenge","oval"],
    "화려":["round","triangle","square","pentagon","hexagon","star","heart"],
    "귀여움":["heart","star","four-leaf clover","butterfly","flower","bow","round"]}
CEN={"P3":1,"P5":2,"P8":3,"P15":3,"P25":3,"P50":4,"P100":5,"P150":6,"P200":7}
NUM={3:"three",5:"five",8:"eight",15:"fifteen"}
def S(sh): return "round O-ring" if sh=="round" else f"{sh}-shaped frame"
def mt(v,rr,metal):
    if v=="수수": return f"polished {metal} with a clear diamond"
    c=rr.choice(["red","cobalt-blue","emerald-green","hot-pink","violet"] if v=="화려" else ["baby-pink","mint","lavender","baby-blue"])
    g=rr.choice(["ruby","sapphire","emerald","amethyst","opal"] if v=="화려" else ["pearl","rose quartz","moonstone"])
    return f"glossy {c} enamel with a {g}"
def pc(k,sd,sh,v,rr,metal):
    m=mt(v,rr,metal)
    return {"ear_o":f"a large classic round O-ring hoop in the {sd} ear lobe, in {m}",
     "ear_up":f"a medium classic round O-ring high on the {sd} ear, in {m}",
     "ear_sh":f"a large {S(sh)} in the {sd} ear, in {m}",
     "nostril":f"a classic round hoop wrapping snugly around the {sd} nostril wing, in {m}",
     "brow":f"a thick bar with a large gem at each end through the outer end of the {sd} eyebrow, in {m}",
     "lip":f"a large classic round O-ring through the lower lip's edge on the {sd}, in {m}",
     "labret":f"a big gem labret stud beneath the lower lip, in {m}",
     "c_bridge":f"a large {S(sh)} bar piece through the bridge of the nose, well below the eyes, in {m}",
     "c_tip":f"a gem stud at the tip of the nose, in {m}",
     "c_sept":f"a large {S(sh)} septum piece hanging from the middle of the nose, in {m}"}[k]
def plan(P,rr):
    a=rr.choice(["left","right"]); b="right" if a=="left" else "left"
    return {"P3":[("c_sept",""),("ear_o",a),("nostril",b)],
      "P5":[("c_sept",""),("c_tip",""),("ear_o",a),("ear_sh",a),("nostril",b)],
      "P8":[("c_bridge",""),("c_tip",""),("c_sept",""),("ear_o",a),("ear_sh",a),("ear_up",a),("nostril",b),("brow",b)],
      "P15":[("c_bridge",""),("c_tip",""),("c_sept",""),("ear_o",a),("ear_sh",a),("ear_up",a),("ear_sh",a),("ear_up",a),("ear_o",b),("nostril",a),("nostril",b),("brow",b),("brow",b),("lip",a),("labret","")]}[P]
SAFE=" sitting in real, calm, healthy skin — no redness, no swelling, no irritation — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes."
def post(t,P,v,rr):
    lvl=int(P[1:]); metal=rr.choice(["yellow gold","silver","rose gold"])
    pp=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]; shs=list(SH[v]); rr.shuffle(shs)
    if lvl<=15:
        L=plan(P,rr); pcs=[pc(k,sd,shs[i%len(shs)],v,rr,metal) for i,(k,sd) in enumerate(L)]
        safe={"수수":f"All jewelry is real polished {metal} set with clear diamonds,"}.get(v,MAT.get(v))
        new=(f"Piercings: Exactly {NUM[lvl]} piercings in total, placed asymmetrically and spread over the nose centreline, the ears and the nostril"+(", the eyebrow and the lips" if lvl>=8 else "")+": "+"; ".join(pcs)+". Each piece is large and clearly visible"+(", and nothing else on the face is pierced" if lvl<=8 else "")+". "+safe+SAFE)
        return t.replace(pp,new)
    if v!="수수":
        t,n=re.subn(r'All jewelry is real [^,]+?(?: \([^)]*\))?, sitting',MAT[v]+'sitting',t,count=1); assert n==1
    N=CEN[P]; cen=", ".join(shs[:N]); ears=", ".join(shs[:3])
    st={"수수":"polished metal set with large clear gemstones","화려":"glossy multicoloured enamel and large rainbow gemstones","귀여움":"pastel enamel, pearls and pastel gemstones"}[v]
    look=(f"Piercing look: the pieces are in {st}. Down the centreline of her nose runs a column of exactly {N} piercings, one under another, made up of the septum ring and the nose-bridge and nose-tip pieces already named above plus enough extra pieces to reach {N}, every one in a different shape ({cen}); the bridge pieces sit well below the eyes. The nostril rings are classic round hoops wrapping snugly around the nostril wing. The ear pieces are mostly large classic round O-ring hoops with a few in other shapes ({ears}). Every piece is large and clearly visible.")
    return t.replace("\n\nLighting:","\n\n"+look+"\n\nLighting:",1)
PL=[("P3","수수","도도한","한국","20대","글래스 스킨",["pierce"]),
    ("P5","귀여움","귀여운","일본","아이돌","아마갸루",["pierce","sticker"]),
    ("P8","화려","섹시한","중국","20대","강남언니",["pierce"]),
    ("P15","수수","고혹적인","한국","30대","글래스 스킨",["pierce"]),
    ("P25","귀여움","발랄한","일본","아이돌","아마갸루",["pierce","sticker"]),
    ("P50","화려","카리스마 있는","중국","아이돌","블러드 립",["pierce"]),
    ("P100","수수","냉혹한","한국","20대","립온리 블랙",["pierce"]),
    ("P150","화려","군림하는","일본","20대","비주얼계 블랙립",["pierce"]),
    ("P200","수수","도도한","중국","30대","립온리 블랙",["pierce"])]
o=["# LumineX — 피어싱 단계 P3~P200 (단계마다 분위기 1가지, 9개) · 한중일 수수/아이돌 메이크업\n",
   "- 가볍게: 초대형 귀걸이·크기 반복문·쇼케이스 문단 제거, 프레임은 원래대로. 코 가운데 줄(모양 다르게), 콧볼은 감싸는 O링 훅, 귀는 큰 O링 + 일부 모양.",
   "- 코 가운데 개수: P3 1(septum) · P5 2 · P8~P25 3 · P50 4 · P100 5 · P150 6 · P200 7. 메이크업은 P25까지 수수/아이돌풍, P50 이상은 검증 규칙대로 립만 진한 어두운 메이크업.",
   "- 정상/이상(+ 코 가운데 개수·모양, 귀 O링+모양)만 번호로 알려주세요.\n"]
for i,(P,v,ex,nat,grp,sty,slots) in enumerate(PL,1):
    for tr in range(40):
        try: t,title,meta=G.make(random.Random(17000+i*100+tr),nat,grp,ex,style=sty,slots=slots,pier_level=P); break
        except AssertionError: continue
    else: raise SystemExit(P)
    t=post(t,P,v,random.Random(19000+i)); assert not re.search(r"[가-힣]",t)
    o.append(f"## {P}-{v} — {title}\n\n```\n{t}\n```\n"); print(P,v,len(t.split()))
open('/mnt/user-data/outputs/LumineX_PierceLadder_v4_P3toP200_x9.md','w',encoding='utf-8').write("\n".join(o))
