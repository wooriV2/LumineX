# -*- coding: utf-8 -*-
import json, re
O = "/mnt/user-data/outputs/"
core = json.load(open(O + "la_core_bundle.json", encoding="utf-8")); mx = json.load(open(O + "la_maximalist_bundle.json", encoding="utf-8"))
get = lambda L, k: [p for p in L if p["key"] == k][0]
HE = ["thirty-six inches", "thirty inches", "forty inches", "thirty-two inches"]; c = [0]
def tail_h():
    h = HE[c[0] % 4]; c[0] += 1; return h
BODYLIFT = "her feet arched fully vertical on the very tips of her toes like a dancer on pointe, her legs stretched impossibly long and her whole body lifted far above the ground on them as if standing on stilts"
LOW = " Very low camera angle with the full length of every boot visible down to the floor, the towering heel height dominating the silhouette and lifting her far above the floor."
def core_fix(t):
    def f(m):
        lead, desc = m.group(1), re.sub(r"^[Ee]xtreme ", "", m.group(2)); h = tail_h()
        return f"{lead}ootwear: the most absurdly extreme heels imaginable — {desc}, each with a razor-thin tapered heel a full {h} tall and a twelve-inch hidden front platform, {BODYLIFT}."
    t, k = re.subn(r"((?:[Ll]eft woman's f|[Rr]ight woman's f|F))ootwear: (.*?), the platform soles rising far higher than her ankle bone, at least three times the thickness of an ordinary heel\.", f, t)
    assert k >= 1; return t.rstrip("\n") + LOW
def mx_fix(t):
    def f(m):
        h = tail_h()
        return f"thigh-high platform stiletto boots in the colours of the body art, each with a razor-thin tapered heel a full {h} tall and a twelve-inch hidden front platform, {BODYLIFT}, extra long stiletto nails"
    t, k = re.subn(r"platform boots 8 inch, extra long stiletto nails", f, t); assert k >= 1
    a = " 8K"; i = t.rindex(a); return t[:i] + LOW + t[i:]
def phys(t): return ", ".join(re.findall(r"goddess, (.+?) physique", t))
items = [("바디페인팅", "솔로", get(core, "la_core_solo_01"), core_fix), ("바디페인팅", "듀오", get(core, "la_core_duo_01"), core_fix)]
for tr in ["irezumi", "uvneon"]:
    for g, n in [("solo", "솔로"), ("duo", "듀오")]:
        items.append(({"irezumi": "이레즈미", "uvneon": "UV네온"}[tr], n, get(mx, f"la_{tr}_{g}_01"), mx_fix))
o = ["# 극단 힐 높이 — 바디페인팅 · 이레즈미 · UV네온 (솔로·듀오)\n", "각 트랙의 등록 프롬프트(솔로 01, 듀오 01)에서 신발 문장만 초극단 힐로 교체했습니다. 번호별로 정상/이상만 알려주세요.\n"]
for i, (tr, g, p, fix) in enumerate(items, 1):
    t = fix(p["prompt"])
    assert not re.search(r"[가-힣]", t)
    body = phys(t) or " / ".join(p["meta"].get("composition", []))
    ti = f"{tr} {g} · {body} · 초극단 힐"
    o.append(f"## {i}. {ti}\n\n```\n{t}\n```\n"); print(i, ti[:140], len(t.split()))
open(O + "LumineX_ExtremeHeels_Tracks6.md", "w", encoding="utf-8").write("\n".join(o))
