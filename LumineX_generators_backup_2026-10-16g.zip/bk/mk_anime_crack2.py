import re,sys
sys.path.insert(0,'.')
src=open('mk_anime_crack.py',encoding='utf-8').read()
exec(src.split("S=[(\"right\",IRON")[0])
import gen_cjk_v2 as G
ctl=open(OUT+'LumineX_EarShapes_Face5.md',encoding='utf-8').read()
C=re.search(r"## 1번.*?```\n(.*?)\n```",ctl,re.S).group(1).split("\n\n")
P_C=[p for p in C if p.startswith("Piercings:")][0]
P_C=P_C.replace("real yellow-gold","yellow-gold").replace("real yellow gold","yellow gold").replace("sitting in real, calm, healthy skin","sitting in calm, healthy skin")
P_C=P_C.replace(" Every piece stays at least a finger's width from the eyeballs, and no chain or bar crosses the eyes.","")
MK=G.C.INT+" "+[t for l,t,tan in G.POOL['비주얼계 블랙립'] if l.startswith('5단계')][0]
ns={}
g=open('gen_fs2.py',encoding='utf-8').read()
exec(compile(g[:g.index('if __name__=="__main__":')],'gfs2','exec'),ns)
RU=[t for n,t,c in ns['LIP'] if n=="러시안 립 극한"][0].replace("in this three-quarter view","in this frontal view")
STYLE_LIP=("Style: The whole image is a real photograph of a real woman, except for one part of her face. Her neck, collarbones, shoulders, the background and most of her face are real photographic skin, hair and light. On the right side of the picture, a jagged, irregular crack runs down her face like a crack in glass, from the hairline above the outer end of her right brow, down the outer edge of her right eye and cheekbone, outside the corner of her mouth to the jawline, so that her lips stay completely whole and untouched on the real side. Everything right of the crack, her right eye, brow, outer cheek, right ear and the hair above them, is a high-quality Japanese anime illustration with clean cel shading, crisp line art and vibrant colours. The crack ends at her jawline and does not continue onto her neck, which is entirely real. It is one woman, one face, one pose: the anime part has the same shape, size and position as the real face it replaces, as if part of a photographed face has broken away to show a drawing beneath.")
def subj(a,hair,eye,extra):
    return SUBJ(a,hair,eye)+" "+extra
def build(style,subject,pier):
    return "\n\n".join([HEAD,style,subject,pier+SAFE,FRAG("right"),LIGHT])
PIER_MANY=PIERCE("right",P_C)
PIER_IRON=PIERCE("right",IRON)
S=[("피어싱 많음 · 금 피어싱 갑옷(약 100개)",build(STYLE("right"),subj("right","long straight jet-black hair swept back","a sharp upturned anime eye with a cold iris and crisp highlights",""),PIER_MANY)),
   ("진한 메이크업 · 비주얼계 블랙립 5단계(극한)",build(STYLE("right"),subj("right","long straight silver-white hair","a huge glittering anime eye with a star-shaped pupil","Her makeup is the same on both sides, real on the real side and drawn in anime style on the anime side: "+MK+"."),PIER_IRON)),
   ("러시안 립 극한 (입술은 실사 쪽에 온전히)",build(STYLE_LIP,subj("right","long straight pastel-pink hair with a blunt fringe","a huge sparkling anime eye with a heart-shaped pupil","Her lips are the star of her face, and they are completely real: "+RU+"."),PIER_IRON))]
S[2]=(S[2][0],S[2][1].replace(", and an anime-drawn lip half with a tiny fang at the corner of the mouth","").replace("real lips with fine vertical lines","real lips")) 
o=["# LumineX — 쪼개진 얼굴 혼합: 피어싱 많음 · 진한 메이크업 · 러시안 립 (3개)\n","- 직전 쪼개진 얼굴(오른쪽이 애니, 목 아래 전부 실사) 틀 그대로. 1: 금 피어싱 갑옷 약 100개 · 2: 비주얼계 블랙립 5단계(극한) 메이크업, 양쪽에 같은 메이크업 · 3: 러시안 립 극한 — 입술이 갈라지지 않도록 균열을 입 바깥으로 돌려 입술을 실사 쪽에 온전히 남겼습니다.","- 정상/이상(+ 피어싱 개수·메이크업·입술이 실제로 표현되는지)만 번호로 알려주세요. 1번은 길이가 길어 약해질 수 있습니다.\n"]
for i,(lab,t) in enumerate(S,1):
    assert not re.search(r"[가-힣]",t) and "three-quarter" not in t
    o.append(f"## {i}. {lab}\n\n```\n{t}\n```\n"); print(i,len(t.split()))
open(OUT+'LumineX_FaceCrack_Heavy_3.md','w',encoding='utf-8').write("\n".join(o))
