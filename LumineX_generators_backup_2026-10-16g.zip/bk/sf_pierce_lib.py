# -*- coding: utf-8 -*-
# 등록된 맥시멀리스트 피어싱 클로즈업 프레임(Piercing Frame Formula 얼굴·가슴·허리 컷)의 인물을 실버폭스로 치환.
import re, random
import sf_blend_lib as L
SUBJ = re.compile(r"(Subject: A real photograph of a striking adult woman — )(?P<skin>.+?), (?P<age>(?:early|mid|late) \d0s) goddess, (?P<body>.+? physique THE MOST EXTREME.+?)\. Real pores and fine skin grain on her skin", re.S)
def convert_close(t, kind, seed):
    rr = random.Random(seed); age = rr.choice(L.SF_AGES); hair = rr.choice(L.HAIR16)
    m = SUBJ.search(t); assert m, t[:200]
    body = m.group("body"); j = body.rfind(", "); oh = body[j + 2:]
    assert re.search(r"hair|braid|bun|bob|ponytail|crop|cut|waves|curls|locs|afro|updo|crown|chignon|twist|tresses|mane|shag|rolls|mohawk|fro|knot", oh, re.I), oh
    body = body[:j + 2] + hair
    if kind == "I": head = f"{L.BLACK}, {age} silver fox goddess, {body}"
    else: head = f"Korean silver fox goddess {L.SKIN[rr.choice('BCD')]} elegant silver-era maturity, {age}, {body}"
    t2 = t[:m.start("skin")] + head + ". Real pores and fine skin grain on her skin" + t[m.end():]
    # 첫 문단의 고정 연령 태그("Mid 20s.")를 실제 연령으로
    t2, n = re.subn(r"((?:Early|Mid|Late) [0-9]0s)\.\n", lambda mm: age[0].upper() + age[1:] + ".\n", t2, count=1); assert n == 1
    assert not re.search(r"[가-힣]", t2) and not re.search(r"\b(\w+) \1\b", t2)
    if kind == "K": assert "DARKEST BLACK" not in t2
    return t2
