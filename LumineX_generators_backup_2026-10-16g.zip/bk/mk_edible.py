# -*- coding: utf-8 -*-
import re, random, sys
_s = open("mk_doll3.py", encoding="utf-8").read()
exec(_s[:_s.index("rg = random.Random(")])
rg = random.Random(int(sys.argv[1]) if len(sys.argv) > 1 else 20261017)
V = lambda nm, desc, solid, nmw, base, acc, fin, tag: (nm, desc, solid, nmw, base, acc, fin, tag)
EDIBLE = {
 "choc": V("chocolate", "glossy tempered dark chocolate", "chocolate", "chocolate", "BLAZING deep glossy dark-chocolate brown across the full torso both legs neck to ankle", "VIVID creamy white-chocolate drizzle lines and tiny gold-leaf flecks running between the sections", "mirror-glossy tempered", "다크 초콜릿"),
 "honey": V("honeycomb", "golden honey-filled honeycomb", "honeycomb wax and honey", "honeycomb wax", "BLAZING hexagonal wax cells brimming with glowing golden honey across the full torso both legs neck to ankle", "VIVID thick amber honey slowly dripping from the edges of the cells and catching the light", "wet glossy", "벌집 꿀"),
 "candy": V("candy", "glossy swirled hard candy", "hard candy", "hard candy", "BLAZING candy-red and cream-white swirled stripes across the full torso both legs neck to ankle", "VIVID clear sugar-glass edges glinting between the sections and tiny rainbow sprinkles pressed into the surface", "high-gloss glassy", "스트라이프 캔디"),
 "jelly": V("jelly", "wobbling raspberry gelatin jelly", "jelly", "jelly", "BLAZING glossy translucent raspberry-red jelly across the full torso both legs neck to ankle", "VIVID tiny suspended fruit slices and air bubbles glowing inside every section", "wet glossy", "라즈베리 젤리"),
 "icecream": V("ice cream", "soft-serve strawberry and vanilla ice cream", "ice cream", "ice cream", "BLAZING pale pink strawberry and cream-white vanilla swirls across the full torso both legs neck to ankle", "VIVID colorful sprinkles and thick chocolate sauce drips running between the sections", "glossy melting", "딸기 바닐라 아이스크림"),
 "cake": V("buttercream", "pastel buttercream-frosted cake", "frosted cake", "pastel sugar paste", "BLAZING smooth pastel pink buttercream frosting across the full torso both legs neck to ankle", "VIVID piped white rosettes, pearl-white sugar beads and tiny macarons set along every joint", "soft matte frosted", "버터크림 케이크"),
}
TRANSL = {"honey", "candy", "jelly"}
EPAT = ["fine edible gold-leaf flecks scattered across the sections", "thin glossy drizzle lines tracing every joint between the sections", "tiny sugar pearls pressed along the edges of the sections"]
for k, v in EDIBLE.items(): NEWV[k] = [v]
_prev_nv = person_nv
def person_nv(label, key, phys, age, pose, eth):
    if key not in EDIBLE: return _prev_nv(label, key, phys, age, pose, eth)
    global PAT
    old = PAT; PAT = EPAT
    try: t, info = _orig_nv(label, key, phys, age, pose, eth)
    finally: PAT = old
    if key in TRANSL: t = t.replace("completely opaque", "richly saturated in colour", 1)
    return t, info
out = ["# 먹을 수 있는 재질 샘플 6개 — 초콜릿 · 벌집 꿀 · 스트라이프 캔디 · 젤리 · 아이스크림 · 버터크림 케이크\n",
       "Material Mix와 같은 기본 랜덤입니다. 번호별로 정상/이상만 알려주세요. 이상이면 한 줄만요(예: 몸이 재질로 안 덮임, 얼굴도 재질이 됨, 재질 질감이 안 나옴).\n"]
for i, (k, v) in enumerate(EDIBLE.items(), 1):
    for attempt in range(300):
        physs = [rg.choices(BIG5, W5)[0]]
        CUR_VAR.clear(); CUR_VAR[(None, k)] = v
        ages = [rg.choice(AGES)]; poses = [rg.choice(POSES)]; eths = rg.sample(ETH, 1)
        bid, wx = BGL.pick(rg, 1)
        scene = BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        HEELMODE[0] = "forty" if rg.random() < 0.55 else "relative"
        ns2["JR"].seed(rg.randrange(10**9))
        t, infos = build3([k], [v], physs, ages, poses, eths, scene)
        t = t.replace("NO dark background NO black void.", "NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as her.", 1)
        if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t): continue
        break
    else: raise SystemExit("fail")
    hko = "힐 40인치" if HEELMODE[0] == "forty" else "힐 숫자 없음"
    out.append(f"## {i}. {v[7]} 솔로 · 체형 {physs[0][0]} · 인종 {eths[0][0]} · {infos[0]} · 배경 {BGL.BG[bid][2]}{'('+wx[0]+')' if wx else ''} · {hko}\n\n```\n{t}\n```\n")
    print(i, v[7], len(t.split()))
open(O + "LumineX_Edible_Solo_6.md", "w", encoding="utf-8").write("\n".join(out))
