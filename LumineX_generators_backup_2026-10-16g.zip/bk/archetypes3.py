import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
from cover_lib import SAFE
HEAD="Professional fashion photograph, close-up beauty portrait. ONE woman, facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp. Mid 20s."
HEAD_W=HEAD.replace("down to the base of her neck and the tops of her collarbones, the frame cutting off there","down to her collarbones and the tops of her shoulders, the frame cutting off there, so the earrings fully hang in view")
TAIL=" Every feature is exaggerated but beautiful, balanced and refined, in harmony with the rest of her face, never distorted, never grotesque. Real skin fine grain and a soft sheen of natural oils on her face, ears and neck, individual hair strands catching the light — a photograph of a real woman, not an illustration, not a render."
SK="The skin around every piece is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
IRON="rough black cast iron with a hammered, pitted, matte surface"
def sub(txt): return "Subject: "+txt+TAIL
BRATZ=sub("A real photograph of a strikingly beautiful adult woman, mid 20s, with the glamorous Y2K 'Bratz doll' face brought to life: warm golden-tan skin with a high-gloss, airbrushed, glossy finish and a shimmering highlight on the cheekbones, long sleek straight jet-black hair with bright pink streaks past her shoulders. Her eyes are huge, wide, saucer-shaped almond eyes, extra-large with a big visible iris in vivid honey-amber doll-eye contact lenses, both eyes the same, with a round natural pupil and bright catchlights, framed by very bold, thick, long lashes and heavy pink-and-gold shimmer eyeshadow with a sharp winged liner, and thin, high, sharply arched brows. Her lips are extremely plump, big, glossy hot-pink lips with a darker pink lip liner outline and a pronounced cupid's bow, slightly pouting. A small, narrow, upturned nose, high sculpted cheekbones, and a small pointed chin. A sassy, confident, playful look straight into the camera.")
IGFACE=sub("A real photograph of a strikingly beautiful adult Korean woman, mid 20s, with the 'Instagram baby-doll' face pushed to its extreme: flawless glass-skin with a dewy, contoured finish, strong peach-pink highlighter on the cheekbones and the bridge of the nose, long glossy dark-brown hair past her shoulders. Her eyes are large, upturned, cat-shaped eyes with the outer corners lifted and a wide, innocent doll roundness in the centre, a big visible iris in soft grey-brown doll-eye contact lenses, both eyes the same, with a round natural pupil and bright catchlights, lined with a delicate wing and long fluttering lashes, and softly arched brows. Her lips are full, pouty, overlined lips in glossy peachy-nude with a pronounced cupid's bow and a plump lower lip, softly closed. A small, refined nose with a delicate tip, very high and sharply sculpted cheekbones, a slim V-line jaw and a small tapered chin. A soft, flirty, doll-like gaze.")
ELF=sub("A real photograph of a strikingly beautiful adult woman, mid 20s, an elf brought to life: luminous, flawless, pale porcelain skin with a faint pearly shimmer on the cheekbones, long straight silver-white hair swept back behind her ears. Her ears are long, slender, elf ears that taper into pointed, upswept tips rising well above the level of her brows, fully visible. Her eyes are large, slightly upturned almond eyes with a big visible iris in pale silver-green contact lenses, both eyes the same, with a round natural pupil and bright catchlights and long, pale lashes, under thin, high, delicate brows. Her lips are soft, slightly full, in a pale rose tone. A slender straight nose, high refined cheekbones and a delicate pointed chin. A calm, ethereal, otherworldly gaze.")
BRATZ_P=("Piercings: Exactly twelve piercings in total, Y2K maximalist and asymmetrical: on each ear a large glossy hot-pink enamel hoop in the lobe, a row of three rhinestone studs up the rim and one heart-shaped ring above them; one rhinestone stud in the left nostril wing; and one thick bar with star-shaped gem ends through the outer end of the right eyebrow. Each piece is large and clearly visible, and nothing else on the face is pierced. "+SK+" All jewelry is real polished gold with glossy hot-pink, turquoise and yellow enamel and sparkling rhinestones,"+SAFE)
IG_P=("Piercings: Exactly twelve piercings in total, in luxurious gold: on each ear a large gold hoop in the lobe and four graduated gold hoops with small diamonds up the helix rim, one gold septum ring as wide as her nose, and one gold stud with a large clear diamond in the left nostril wing. Each piece is large and clearly visible, and nothing else on the face is pierced. "+SK+" All jewelry is real polished yellow gold set with clear diamonds,"+SAFE)
def elf_p():
    W=["a solid rough cube-shaped block","a solid rough cannonball","a chunky solid hexagonal block"]
    r=random.Random(5)
    ear=lambda s: f"on the {s} ear "+", ".join(f"{x} on its own thick chain of heavy black iron links" for x in r.sample(W,3))
    return ("Piercings: Exactly ten piercings in total, only on the ears: each pointed ear has a single very thick, heavy black cast-iron ring as thick as a finger, a plain solid ring with no open tunnel, through one large healed opening in the stretched lobe, with three separate massive solid weights hanging from it: "+ear("left")+"; "+ear("right")+". Each weight is as big as a fist, dense, solid and blunt, crushingly heavy, the chains are pulled bar-straight and taut, and together they stretch each earlobe into a long, thin, smooth loop of skin down to the middle of the neck. Along the long pointed rim of each ear above the lobe sit four slender silver rings, graduated in size, following the line of the point up to the tip. "+SK+" The iron is blackened cast iron and the rim rings are polished silver,"+SAFE)
PD=None
V=[("브랫츠 돌 — 브랫츠풍 글램(핑크·골드 아이섀도, 핫핑크 립) · 피어싱 12",BRATZ,BRATZ_P,HEAD),
   ("인스타 베이비돌 — 한국 · 글래스 스킨·컨투어 메이크업 · 피어싱 12",IGFACE,IG_P,HEAD),
   ("엘프 — 뾰족한 귀 · 실버 화이트 헤어 · 무쇠 추 귀걸이 + 실버 링 · 피어싱 10",ELF,elf_p(),HEAD_W)]
o=["# LumineX — 추천 얼굴 3종 (브랫츠 돌·인스타 베이비돌·엘프)\n","- 브랫츠: 화려 피어싱(핑크 에나멜·스타 바), 인스타: 골드·다이아 피어싱, 엘프: 뾰족한 귀 + 터널 없는 무쇠 추 3개/귀 + 실버 귀 테두리 링. 모두 성인, 균방 잡힌 예쁜 극단.","- 정상/이상(+ 유형 특징이 보이는지)만 번호로 알려주세요.\n"]
for i,(lab,s,p,h) in enumerate(V,1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(78000+i*100+tr),"한국","20대","도도한",style="NONE",slots=["pierce"],pier_level="P5"); break
        except AssertionError: continue
    else: raise SystemExit(i)
    ps=t.split("\n\n")
    depth=[x for x in ps if x.startswith("Piercing depth:")][0]; light=[x for x in ps if x.startswith("Lighting:")][0]
    parts=[h,s,p,depth]
    if i==3: parts.append("Hair: her silver-white hair is swept back behind both pointed ears, leaving both ears, her jawline and her neck fully visible so every iron weight hangs in clear view.")
    parts.append(light)
    new="\n\n".join(parts); assert not re.search(r"[가-힣]",new)
    o.append(f"## {i}. {lab}\n\n```\n{new}\n```\n")
open('/mnt/user-data/outputs/LumineX_FaceTypes_Bratz_IG_Elf_3.md','w',encoding='utf-8').write("\n".join(o).replace("균방","균형")); print("ok")
