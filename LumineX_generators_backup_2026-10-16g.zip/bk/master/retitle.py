# -*- coding: utf-8 -*-
"""공통 제목 틀: [시리즈 인원 #번호] · 체형 · 재질 · 포즈 · 배경 · 메이크업 (길이 약 50~80자). 기존 번들(title+meta)에서 항목을 뽑아 새 제목 매핑을 만든다."""
import re, json, collections
CNT = {"Solo": "솔로", "Duo": "듀오", "Trio": "트리오", "Quartet": "쿼르텟", "Quintet": "퀸텟"}
CNT_KO = ("솔로", "듀오", "트리오", "쿼르텟", "퀸텟")
POSE_RULES = [
 (r"^seated.*(bench)", "벤치 앉기"), (r"^seated.*(stool)", "스툴 앉기"), (r"^seated.*(chair|armchair)", "의자 앉기"),
 (r"^seated.*(steps|stairs|flight)", "계단 앉기"), (r"^seated.*(ledge|wall)", "턱 앉기"), (r"^seated", "앉기"),
 (r"kneeling on one knee", "한쪽 무릎 꿇기"), (r"kneeling on both", "양 무릎 꿇기"), (r"^reclining", "기대어 눕기"),
 (r"walking away", "뒤돌아 걷기"), (r"walk|stride", "걷기"), (r"leaning", "기대기"),
 (r"back fully|^back to the camera|^back three|back three", "뒷모습"), (r"hip pop", "힙 팝"),
 (r"profile", "옆모습"), (r"hands pressed together", "기도 자세"), (r"arms raised|raised above her head|raised overhead", "양팔 들기"),
 (r"sweeping her hair|hair streaming", "머리 넘기기"), (r"framing (her own |the )?face", "얼굴 감싸기"),
 (r"jump", "점프"), (r"lung", "런지"), (r"arms crossed", "팔짱"), (r"clasped behind her head", "손 깍지"),
 (r"s-curve", "S라인"), (r"hands? on (her|the) (hips|waist)|on her hips|fists pressing", "손 허리"),
 (r"three-quarter", "3/4 각도"), (r"one hand on her waist", "손 허리")]
def pose_ko(p):
    q = p.lower()
    for rx, ko in POSE_RULES:
        if re.search(rx, q): return ko
    return "서 있기"
def uniq(L):
    o = []
    for x in L:
        if x and x not in o: o.append(x)
    return o
def agg(L):
    u = uniq(L)
    if len(u) <= 2: return " / ".join(u)
    return f"{u[0]} 외 {len(u)-1}"
def mk_clean(s):
    s = s.strip()
    for _ in range(3):
        s = re.sub(r"\s*(아주 강함|강함|강화|포인트|\d단계)\s*$", "", s)
        s = re.sub(r"\((강화|포인트|강함)\)$", "", s).strip()
    return s
def mat_short(s):
    m = re.match(r"^([가-힣+]+)\s+(.*)$", s)
    if m:
        cat, var = m.group(1), m.group(2)
        w = var.split()
        return f"{cat} {' '.join(w[:2])}"
    return " ".join(s.split()[:3])
def parse(title):
    head, _, rest = title.partition(" (")
    rest = rest.rstrip(")")
    items = [x.strip() for x in re.split(r" · | ‖ ", rest)]
    return head, items
def build_head(head):
    for k, v in CNT.items(): head = re.sub(rf"\b{k}\b", v, head)
    return head
def material(items):
    ci = next((i for i, x in enumerate(items) if re.search(r"(솔로|듀오|트리오|쿼르텟|퀸텟)$", x)), None)
    if ci is None: return ""
    pre = re.sub(r"\s*(솔로|듀오|트리오|쿼르텟|퀸텟)$", "", items[ci]).strip()
    mats = []
    for x in items[ci + 1:]:
        if re.match(r"(앵글|조명|시간대|분위기|체형|인종|헤어|메이크업|배경|힐|신발|몸|극단)", x): break
        mats.append(x)
    mats = [m for m in mats if not any(m != n and n.startswith(m) for n in mats)]
    if len(mats) >= 2: mats = mats[-1:]
    mats = [y.strip() for m in mats for y in m.split(" / ")]
    if pre and "+" not in pre and pre != "새 재질" and not any(pre in m for m in mats): mats = [pre + " " + m for m in mats]
    mats = [mat_short(m) for m in mats]
    return agg(mats)
def retitle(p):
    head, items = parse(p["title"]); m = p["meta"]
    body = agg(m.get("physiques") or [x[3:] for x in items if x.startswith("체형 ")] and [y.strip() for x in items if x.startswith("체형 ") for y in x[3:].split(",")])
    mk = agg([mk_clean(x[5:]) for x in items if x.startswith("메이크업 ")])
    bg = next((re.sub(r"\(.*\)$", "", x[3:]) for x in items if x.startswith("배경 ")), "")
    poses = agg([pose_ko(x) for x in (m.get("poses") or []) if isinstance(x, str)]) if (m.get("group_size") or 1) == 1 else ""
    return " · ".join(x for x in [build_head(head), body, material(items), poses, bg, mk] if x)
def retitle_tank(p):
    head, items = parse(p["title"]); m = p["meta"]
    fills = "/".join(m["fills"]); cont = agg([c for c in m["contents"] if c])
    mk = agg([mk_clean(y) for x in items if x.startswith("메이크업 ") for y in x[5:].split(" / ")])
    kind = "듀얼바디 L3" if m["frame"] == "full" else "프레임 힙컷"
    return " · ".join(x for x in [head, kind, fills, "USSBBW", "수조" + ("+" + cont if cont else ""), mk] if x)
