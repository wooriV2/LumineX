# -*- coding: utf-8 -*-
"""주제 그룹 바디페인팅: 사람마다 주제 항목 하나(색·모티프)를 맡는다. 체형·포즈·신발·헤어·배경 등 나머지는 기본 랜덤(master v2 생성기 재사용)."""
import sys, os, re
sys.argv = ['x', os.environ.get('SEED', '5151')]
import gen_theme_base as B
D, R, rg = B.D, B.R, B.rg
def spec(name, color, motif):
    text = (f"painted entirely in one single flat colour, vivid {color} — {motif}, the same {color} from her neck to her toes with no other colour anywhere on her body, "
            f"this is wet body paint brushed directly onto her bare skin — not clothing, not a bodysuit, not a catsuit, not fabric, not latex, with no seams, no hems, no straps and no neckline anywhere — so her natural skin texture, pores, fine hairs and every natural body crease stay visible through the thin glossy paint, the paint edge following her bare jaw and neck, covering her whole body below the jaw with no bare skin anywhere, face unpainted")
    return dict(text=text, nm="painted", nail="painted in the same colours as her body art", track="paint", cols=color, name=f"바디페인팅 {name}")
THEMES = {
 "삼원색": ("three primary colours", [("빨강", "pure red", "a flat, saturated glossy primary-red paint"), ("노랑", "pure yellow", "a flat, saturated glossy primary-yellow paint"), ("파랑", "pure blue", "a flat, saturated glossy primary-blue paint")]),
 "오행": ("five elements", [("목(청)", "azure green-blue", "leaf-and-branch linework of the wood element"), ("화(적)", "crimson red", "licking flame linework of the fire element"),
                          ("토(황)", "ochre yellow", "layered rock-strata linework of the earth element"), ("금(백)", "white and silver", "fine metallic ore-vein linework of the metal element"),
                          ("수(흑)", "deep black-indigo", "flowing wave linework of the water element")]),
 "무지개": ("rainbow", [("빨강", "pure red", "a flat, saturated glossy red paint"), ("주황", "pure orange", "a flat, saturated glossy orange paint"), ("노랑", "pure yellow", "a flat, saturated glossy yellow paint"),
                       ("초록", "pure green", "a flat, saturated glossy green paint"), ("파랑", "pure blue", "a flat, saturated glossy blue paint"), ("남색", "deep indigo", "a flat, saturated glossy indigo paint"),
                       ("보라", "pure violet", "a flat, saturated glossy violet paint")]),
}
B.SEEN = set()
D.NUM.update({6: 'SIX', 7: 'SEVEN'}); D.TYPEN.update({6: 'sextet', 7: 'septet'}); D.TKO.update({6: '6인', 7: '7인'}); D.ASPECT.update({6: D.ASPECT[5], 7: D.ASPECT[5]})
B.pick_kinds = lambda n, kk: ["bodypaint"] * n
CALL = [0]; ITEMS = []
def mat_spec(rng, kind):
    s = ITEMS[CALL[0] % len(ITEMS)]; CALL[0] += 1; return s
R.mat_spec = mat_spec
POS = {2: ["left", "right"], 3: ["left", "centre", "right"]}
def run(theme, kk=1):
    title, items = THEMES[theme]; n = len(items)
    ITEMS[:] = [spec(*it) for it in items]; CALL[0] = 0
    B.CLS[(n, kk)] = rg.choice(["stil", "stil", "flat"])
    r = B.build(n, kk)
    t = r["t"]
    order = ", ".join(f"{it[1]}" for it in items)
    line = (f"Theme: {title}. The {n} women form one themed set; reading from left to right, each woman is painted entirely in her own single theme colour, in exactly this order: {order}. "
            f"Every woman keeps her own colour from head to toe, and no colour appears on two women.")
    paras = t.split("\n\n"); paras.insert(1, line); t = "\n\n".join(paras)
    return t, r, [it[0] for it in items]

import re
def dedupe(t):
    seen = set(); out = []
    for ln in t.split("\n"):
        parts = re.split(r"(?<=\.) ", ln); keep = []
        for p in parts:
            key = re.sub(r"^#\d+:? ", "", p).strip()
            if len(key) > 90 and key in seen: continue
            if len(key) > 90: seen.add(key)
            keep.append(p)
        out.append(" ".join(keep))
    return re.sub(r"\n{3,}", "\n\n", "\n".join(out))
def run2(theme, kk=1):
    t, r, lab = run(theme, kk)
    title, items = THEMES[theme]; n = len(items)
    t = dedupe(t)
    # 각 사람 본문 맨 앞에 색 선언
    for k, it in enumerate(items, 1):
        t = re.sub(rf"(?m)^#{k}: (?=[a-zA-Z])", f"#{k}: THE {it[1].split()[-1].upper()} WOMAN, painted entirely in {it[1]} from the neck down. ", t, count=1) if not re.search(rf"(?m)^#{k}: THE ", t) else t
    pos = {3: ["left", "centre", "right"], 5: ["far left", "centre-left", "centre", "centre-right", "far right"], 7: ["far left", "second from left", "third from left", "centre", "third from right", "second from right", "far right"]}[n]
    sumline = "Left to right: " + "; ".join(f"{p} = {it[1]}" for p, it in zip(pos, items)) + "."
    t = t.replace("Every woman keeps her own colour from head to toe, and no colour appears on two women.", "Every woman keeps her own colour from the neck down to her toes, and no colour appears on two women. " + sumline, 1)
    return t, r, lab
