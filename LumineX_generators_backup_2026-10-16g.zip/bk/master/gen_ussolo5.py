# -*- coding: utf-8 -*-
"""LumineX Master Mix 300 — 정의된 모든 축을 기본 랜덤으로 쓰는 새 생성기 (이전 번들 생성기 비상속).
출력: la_mastermix_300_bundle.json + 축별 '정의 수 / 사용 수' 표."""
import sys, re, json, random, collections
import mdefs as D, mrecipes as R
D.KO.update({"kintsugi": "킨츠기", "kintsugi_p": "킨츠기(그림)", "liquidgold": "리퀴드골드", "liquidsilver": "리퀴드실버"})
NEWK = ["kintsugi", "kintsugi_p", "liquidgold", "liquidsilver"]; OLDK = list(D.ALL_KINDS); D.ALL_KINDS[:] = OLDK + NEWK

SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 20261201
OUT = "ussolo5.json"
class BRandom(random.Random):
    """랜덤하되, 같은 풀에서 덜 쓰인 값이 더 잘 뽑히게 해서 정의된 값이 모두 쓰이도록 한다 (채택된 프롬프트만 집계)."""
    def __init__(self, seed):
        super().__init__(seed); self.cnt = collections.Counter(); self.pend = collections.Counter()
    def choice(self, seq):
        if len(seq) < 2: return super().choice(seq)
        c = [self.cnt[(id(seq), i)] + self.pend[(id(seq), i)] for i in range(len(seq))]
        if self.random() < 0.6:
            m = min(c); i = self.choice_idx([j for j in range(len(seq)) if c[j] == m])
        else:
            w = [1.0 / (1 + x) ** 6 for x in c]; i = self.choices(range(len(seq)), w)[0]
        self.pend[(id(seq), i)] += 1
        return seq[i]
    def choice_idx(self, L): return L[int(self.random() * len(L))]
    def commit(self): self.cnt.update(self.pend); self.pend.clear()
    def rollback(self): self.pend.clear()

D.ARR["steps_pair"] = dict(ko="계단 나란히 앉기", aspect="3:2", scene="TWO women seated side by side on one broad flight of weathered stone steps, both on the same wide step, set in the scene",
    roles=["seated on the step with her knees apart and her legs stretched down the steps in front of her", "seated on the step with her knees apart and her legs stretched down the steps in front of her"], names=["Left woman", "Right woman"])
D.ARR["steps_tiers"] = dict(ko="계단 위아래 앉기", aspect="3:2", scene="TWO women seated on one broad flight of weathered stone steps, one on the step above the other, set in the scene",
    roles=["seated on the higher step at the left with her knees apart and her legs stretched down in front of her", "seated on the lower step at the right with her knees apart and her legs stretched out in front of her"], names=["Woman on the higher step, at the left", "Woman on the lower step, at the right"])
D.ARR_FLOOR["steps_pair"] = ("seat", "seat"); D.ARR_FLOOR["steps_tiers"] = ("seat", "seat")
FORCE = {1: "steps_pair", 2: "bench_pair", 3: "steps_tiers"}; FORCEBG = {1: "art_museum", 2: "autumn_park"}
_u = [b for b in D.BODIES if b[0] == "USSBBW"][0]
USSX = _u
SOLOPOSE = {1: "seated on a long backless gallery bench in the middle of the hall with her knees apart and her hands resting on her thighs", 2: "seated on the park bench with its backrest behind her, her knees apart and her hands resting on her thighs"}
for _p in SOLOPOSE.values(): D.POSE_FLOOR[_p] = "seat"
FORCEBG = {1: "art_museum", 2: "autumn_park"}
PAINT = ["bodypaint"]
rg = BRandom(SEED)
CAT = "🏺 Living Artifact · Kintsugi Liquid Metal Formula"
USED = collections.defaultdict(collections.Counter)
def use(axis, v): USED[axis][v] += 1

# 신발 종류 비율 (프롬프트 단위): 스틸레토 / 발레(1~2인만) / 일반
CLS = {}
for n_ in range(1, 6):
    L = (["stil"] * 13 + ["ballet"] * 4 + ["flat"] * 7) if n_ == 1 else (["stil"] * 14 + ["ballet"] * 2 + ["flat"] * 8) if n_ == 2 else (["stil"] * 17 + ["flat"] * 7)
    rg.shuffle(L)
    for k_, c_ in enumerate(L, 1): CLS[(n_, k_)] = c_
CLS[(1, 1)] = "stil"; CLS[(1, 2)] = "stil"; CLS[(1, 3)] = "flat"
BLACK_ONLY = ("goldleaf", "wax", "obsidian")


def pick_kinds(n, kk):
    if n == 1:
        return [rg.choice(PAINT)]
    while True:
        ks = []
        for _ in range(60):
            k = rg.choice(D.ALL_KINDS)
            if k not in ks: ks.append(k)
            if len(ks) == n: break
        if len(ks) < n or ks.count("uvneon") > 1 or sum(k in BLACK_ONLY for k in ks) > 2: rg.rollback(); continue
        return ks


def pick_bodies(n):
    out = []
    while len(out) < n:
        b = rg.choice(D.BODIES)
        if b not in out: out.append(b)
    return out


def pick_eths(kinds, bodies):
    """인종: 체형 연결(블랙글래머 등) + 재질 조건(금박·왁스·흑요암=검은 피부, UV=브론즈 제외) + 컨셉(재질별 신화 인물 80%) + 중복 없음."""
    n = len(kinds); eths = [None] * n; concepts = [None] * n; used = set()
    def allowed(i, e):
        k = kinds[i]; lk = D.BODY_LINK.get(bodies[i][0].replace("pregnant ", ""))
        return e not in used and (k not in D.SKIN_ONLY or e in D.SKIN_ONLY[k]) and (k not in D.SKIN_NOT or e not in D.SKIN_NOT[k]) and (lk is None or e in lk)
    order = sorted(range(n), key=lambda i: (D.BODY_LINK.get(bodies[i][0].replace("pregnant ", "")) is None, kinds[i] not in D.SKIN_ONLY))
    for i in order:
        k = kinds[i]
        if k in D.PERSONA and rg.random() < 0.8:
            ko, en, e = rg.choice(D.PERSONA[k])
            if allowed(i, e): eths[i] = D.ETH_BY[e]; concepts[i] = (ko, en); used.add(e); continue
        cands = [e for e in D.ETH_BY if allowed(i, e)]
        if not cands: return None, None
        e = rg.choice(cands); eths[i] = D.ETH_BY[e]; used.add(e)
    return eths, concepts


ARR_KEYS = list(D.ARR)
def pick_poses(pool, n):
    # 균형 랜덤: 정의된 포즈 전체를 고르게 쓰되 한 장면 안에서는 중복 없음 (풀 id 고정)
    got = []
    for _ in range(200):
        i = rg.choice(D.POSES_ALL)
        if i in pool and i not in got: got.append(i)
        if len(got) == n: return got
    return rg.sample(pool, n)


def pick_bg(n):
    items = [b for b in D.BGL.BG.values() if not (n >= 4 and b[0] in D.BGL.NARROW)]
    w = [D.BGL.WEIGHT[b[1]] / (1 + USED["bg"][b[0]]) ** 4 for b in items]
    b = rg.choices(items, w)[0]
    return b[0], (rg.choice(D.BGL.WX) if b[5] else None)


def lighting(n, uv, outdoor, bid):
    tk = None; wxdrop = False
    if outdoor and (uv or rg.random() < 0.7): tk = "night" if uv else rg.choice(list(D.TIME)); wxdrop = True
    if tk: lk = rg.choice(D.TIME[tk][1]); tp = D.TIME[tk][0]
    else: lk = rg.choice(D.INDOOR_LIGHT if not outdoor else D.OUTDOOR_LIGHT); tp = ""
    if uv and not tk: lk = rg.choice(D.UV_LIGHT)
    if uv and tk: lk = rg.choice(["moon", "neon", "pink"])
    if bid == "pool" and rg.random() < 0.5: lk = "rim"
    return tk, tp, lk, wxdrop


def build(n, kk):
    cls = CLS[(n, kk)]
    for attempt in range(800):
        rg.rollback()
        kinds = pick_kinds(n, kk)
        bodies = [USSX]
        eths, concepts = pick_eths(kinds, bodies)
        if eths is None: continue
        arr = "side"
        if n == 2: arr = FORCE[kk]
        elif n == 2: arr = "side"
        ang = "base"
        specs = [R.mat_spec(rg, k) for k in kinds]
        ages = [rg.choice(D.AGES) for _ in range(n)]
        # 포즈
        floor_keys = [None] * n
        if arr == "side":
            okp = [p for p in D.POSES_ALL if not (ang != "base" and ("camera" in p or "back" in p))]
            poses = [SOLOPOSE[kk]]
            if cls == "ballet": poses = [D.BAL_POSE] * n
            floor_keys = [D.POSE_FLOOR.get(p) for p in poses]
        else:
            A = D.ARR[arr]; poses = list(A["roles"]) if A["roles"] else pick_poses(D.POSES_ALL, n)
            floor_keys = list(D.ARR_FLOOR[arr])
        # 헤어
        hairs = []; hinfo = []
        for i in range(n):
            snake = bool(concepts[i] and concepts[i][0] == "메두사")
            h, lab = R.hair(rg, eths[i], specs[i], snake); hairs.append(h); hinfo.append(lab)
        # 장면
        bid, wx = FORCEBG[kk], None; outdoor = D.BGL.BG[bid][4]
        uv = "uvneon" in kinds
        tk, tp, lk, wxdrop = lighting(n, uv, outdoor, bid)
        if wxdrop: wx = None
        mood = rg.choice(D.MOODS)
        scene = D.BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        if tk in ("blue", "dusk", "night"): scene = re.sub(r"\b(sunlit|sunny|bright|midday) ", "", re.sub(r" at midday\b", "", scene))
        scene = re.sub(r"\ba (?=[aeiou])", "an ", scene)
        keep = D.KEEP_LIT if (tk in ("blue", "dusk", "night") or lk in ("chiaro", "moon", "fire", "neon", "pink") or uv) else ""
        env = f"{scene}, {D.LIGHT[lk]}" + (f", {tp}" if tp else "") + f", {mood}{keep}, the whole floor and surroundings clearly visible and in focus, NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as " + ("her" if n == 1 else "any of them") + "."
        # 신발
        if cls == "stil": forms = [rg.choice(D.STIL) for _ in range(n)]
        elif cls == "flat": forms = [rg.choice(D.FLAT) for _ in range(n)]
        else: forms = [D.BAL_FORM] * n
        # 사람 블록
        blocks = []; infos = []; boots = []
        for i in range(n):
            lab = f"#{i + 1}" if n > 1 else None
            b, info, bt = R.person(rg, lab, kinds[i], specs[i], bodies[i], ages[i], poses[i], eths[i], hairs[i], concepts[i], cls, forms[i], floor_keys[i])
            blocks.append(b); infos.append(info); boots.append(bt)
        # 프레임
        endc = {"stil": "the towering heels clearly separating the soles from the floor", "flat": "the towering soles clearly lifting her far above the floor",
                "ballet": "the tip of each pointed boot clearly touching the floor"}[cls]
        if any(floor_keys) and cls != "ballet": endc = f"the towering {'soles' if cls == 'flat' else 'heels'} clearly in view"
        cam_core = f" the whole figure from the soles of the shoes to the top of her head completely visible, with the door, railing or steps beside her at normal human scale so her extreme height reads at a glance, {endc}."
        if arr != "side":
            cam = "Full-length wide shot with the camera set at platform level and pushed close so the two of them fill the frame edge to edge," + cam_core
        else: cam = D.ANGLES[ang][1] + cam_core
        A = D.ARR[arr]
        if arr == "side": head = f"Professional fashion photograph, full body shot. {D.NUM[n]} wom{'a' if n == 1 else 'e'}n {'seated' if n == 1 else 'standing'}{' side by side' if n > 1 else ''}."
        else: head = f"Professional fashion photograph, full body shot. {A['scene']}{D.ARR_CONTACT}."
        asp = A["aspect"] if arr != "side" else D.ASPECT[n]
        fmt = "landscape" if asp in ("3:2", "5:4") else "portrait"
        zero = "zero bare skin anywhere from neck to ankle"
        if any(boots): zero = "zero bare skin anywhere from neck " + (R.BOOTEND if all(boots) else "down to the ankles or to the top edge of the boots")
        if n == 1: tail = f"Background: {env} ONE woman only. Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — {zero}."
        else:
            hip = "from hip " + (R.BOOTEND if all(boots) else "down to the ankles or to the top edge of the boots") if any(boots) else "from hip to ankle to toe"
            role = f" Arrangement: " + " and ".join(f"#{i + 1} is the {A['names'][i].lower()}" for i in range(n)) + "." if arr != "side" and A.get("names") else ""
            tail = f"Environment: {env}{role}\nAll: Extreme macro detail on every surface texture and shadow. CRITICAL: all {n} women's legs must show FULL BODY ART coverage {hip} with NO bare untattooed skin visible anywhere, every element standing in true relief, nothing flat. {D.NUM[n]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame."
        t = f"{head}\n\n" + "\n\n".join(blocks) + f"\n\n{tail} {cam} 8K {fmt} {asp} aspect ratio."
        if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t): continue
        if t.count("Jewelry:") != n or "forty" in t or t in SEEN: continue
        rg.commit()
        return dict(t=t, n=n, cls=cls, kinds=kinds, specs=specs, eths=eths, concepts=concepts, bodies=bodies, ages=ages, poses=poses, hinfo=hinfo, infos=infos, forms=forms,
                    arr=arr, ang=ang, bid=bid, wx=wx, tk=tk, lk=lk, mood=mood, asp=asp)
    raise SystemExit(f"fail {n} {kk}")


out = []; seen = set(); SEEN = seen
for n in (1,):
    for kk in range(1, 3):
        while True:
            r = build(n, kk)
            if r["t"] not in seen: break
        seen.add(r["t"]); t = r["t"]
        mats = " / ".join(s["name"] for s in r["specs"])
        shoeko = {"stil": "스틸레토", "flat": "일반 신발", "ballet": "발레 부츠"}[r["cls"]]
        mshort = r["mood"].split(" mood")[0]
        arrko = D.ARR[r["arr"]]["ko"] if n == 2 else ""
        title = (f"KintsuLiquid {D.TYPEN[n].capitalize()} #{kk:02d} ({shoeko} · {D.TKO[n]}{' · ' + arrko if arrko else ''} · {mats} · 앵글 {D.ANGLES[r['ang']][0]} · 조명 {r['lk']} · 시간대 {r['tk'] or '없음'} · 분위기 {mshort} · "
                 f"체형 {', '.join(b[0] for b in r['bodies'])} · 인종 {', '.join(e[0] for e in r['eths'])} · 헤어 {', '.join(r['hinfo'])} · {' ‖ '.join(r['infos'])} · 배경 {D.BGL.BG[r['bid']][2]}{'(' + r['wx'][0] + ')' if r['wx'] else ''} · 몸 주얼리)")
        out.append({"key": f"la_kl_{D.TYPEN[n]}_{kk:02d}", "category": CAT, "title": title, "prompt": t,
                    "meta": {"group_size": n, "aspect_ratio": r["asp"], "format": "kintsuliquid", "shoe_class": r["cls"], "kinds": r["kinds"], "materials": [s["name"] for s in r["specs"]],
                             "arrangement": r["arr"], "angle": r["ang"], "poses": r["poses"], "lighting": r["lk"], "time_of_day": r["tk"], "mood": mshort,
                             "physiques": [b[0] for b in r["bodies"]], "ethnicity": [e[0] for e in r["eths"]], "ages": r["ages"], "background": r["bid"], "weather": r["wx"][0] if r["wx"] else None,
                             "concepts": [c[0] if c else None for c in r["concepts"]], "shoes": [f if isinstance(f, str) else f[0] for f in r["forms"]], "jewelry": True}})
        for i in range(n):
            use("kind", r["kinds"][i]); use("body", r["bodies"][i][0]); use("eth", r["eths"][i][0]); use("age", r["ages"][i]); use("pose", r["poses"][i]) if r["poses"][i] in D.POSES_ALL else None; use("material", r["specs"][i]["name"])
            use("shoe", r["forms"][i] if isinstance(r["forms"][i], str) else r["forms"][i][0])
        use("bg", r["bid"]); use("light", r["lk"]); use("time", r["tk"]); use("mood", r["mood"]); use("angle", r["ang"]); use("arr", r["arr"]); use("class", r["cls"])


json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
