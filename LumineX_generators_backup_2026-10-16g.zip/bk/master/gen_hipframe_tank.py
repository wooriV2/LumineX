# -*- coding: utf-8 -*-
"""프레임 힙컷 수조 그룹(3인/4인): 수위(100/75/50/25/0%) × 내용물 × 유리 색조. 등록 프레임 트리오(demi)의 틀을 쓰고 컷 위치만 힙컷으로 교체."""
import json, re, sys
sys.argv = sys.argv[:1]
import gen_trio_mix as T
rr = T.rr
o = json.load(open('/mnt/user-data/outputs/la_pstatue_geo_300_bundle.json', encoding='utf-8'))
trios = [p for p in o if p['meta']['group_size'] == 3 and p['meta']['frame'] == 'demi']
HIP = "a short way down her thighs, just below the hip line"
WORLDS = {
 "lily": ("백합 들판", "pale mist drifting low over a field of white lilies: the lilies standing in clear water that fills her body, denser near the chest and thinning toward the thighs, with plenty of perfectly clear space between them", "a field of white lilies standing in the clear water, with plenty of perfectly clear space between them"),
 "rose": ("장미 정원", "a rose garden at dawn: red and white roses among dark green leaves, a few drifting petals, standing in the clear water that fills her body, denser near the chest and thinning toward the thighs", "a rose garden at dawn: red and white roses among dark green leaves and a few drifting petals, standing in the clear water"),
 "firefly": ("반딧불이 밤", "a warm summer night: hundreds of small glowing fireflies and a scatter of tiny floating paper lanterns drifting in the clear water that fills her body, from her chest down through her thighs", "a warm summer night: hundreds of small glowing fireflies and a scatter of tiny floating paper lanterns drifting in the clear water"),
 "cherry": ("벚꽃잎(미등록 문구)", "a spring evening: hundreds of pale pink cherry-blossom petals drifting slowly in the clear water that fills her body, from her chest down through her thighs", "a spring evening: hundreds of pale pink cherry-blossom petals drifting slowly in the clear water"),
}
TINTS = [("pale aquamarine-blue", "아쿠아마린"), ("soft rose-pink", "로즈핑크"), ("pale amber-gold", "앰버"), ("delicate lilac-violet", "라일락"), ("pale emerald-green", "에메랄드"), ("pale smoky grey", "스모키")]
LINE = {75: "at the height of her breasts", 50: "at the height of her waist, just above her navel", 25: "at the height of her hips"}

def glass(tint):
    return (f"The glass is unmistakably glass but extraordinarily thin and transparent: a single hair-thin, polished shell carrying only a faint {tint} tint, like a delicate coloured film — the colour deepens only slightly along its thin rims and where the glass curves edge-on, while the face of every surface stays almost perfectly clear — so delicate that it is almost invisible, revealed by bright specular reflections sliding along every curved surface, sharp white highlights, fine refraction edges along its thin rims and tiny bubbles trapped in the glass itself; the backdrop and its light sources are seen straight through the vessel with almost no distortion.")

def fillc(pct, wk):
    nm, full, wat = WORLDS[wk]
    if pct == 100:
        return f"filled completely to the brim so nothing is hollow and there is no air gap. The vessel holds ONE single world, unbroken and continuous through her whole chest, belly, hips and both thighs, with no split, no second world and no change of contents anywhere: {full}."
    if pct == 0:
        return "completely empty: the vessel holds no water, no liquid and no objects of any kind, only clear air inside its sealed hollow. The vessel is her body itself, not a shell worn around a body, with no human body, skin, flesh or organs inside it, so the backdrop is plainly visible straight through it."
    up = "the whole upper part of the vessel, up to the collarbones," if pct <= 50 else "the upper part of the vessel, up to the collarbones,"
    return (f"only partly filled: the clear water stands at one single flat, level waterline {LINE[pct]}, filling the vessel from the tips of her thighs up to there; above that line the vessel is simply empty, clear and transparent, with nothing inside, only clear air, and a thin bright line marks the water surface where it meets the glass. The vessel is her body itself, not a shell worn around a body: there is no human body, no skin, no flesh, no bones and no organs anywhere inside it, so {up} is only clear air inside a hair-thin glass outline of her shape, and the backdrop is plainly visible straight through it. The vessel holds ONE single world, kept entirely within the water below the waterline, nothing floating above it: {wat}.")

def body(n, pct, wk, tint):
    return (f"#{n} Body: From the collarbones down, her whole body — shoulders, arms, hands, chest, belly, hips and both distinct thighs — is a sculpted vessel of extremely thin, crystal-clear glass in the exact shape of her body, {fillc(pct, wk)} {glass(tint)} Her shoulders, chest, belly, hips and both thighs keep their exact sculpted shapes as clear glass outlines, and a clean glass rim runs along the boundary where the vessel meets the neck. {HIP[0].upper() + HIP[1:]}, each thigh individually curves inward and seals shut into its own smooth, rounded, closed tip — the two thighs stay clearly separate, never merging into a single base — nothing continues below either tip. Her body below the collarbones is a transparent material that light passes through; her face, ears and neck stay opaque living flesh.")

def nat(p): return re.search(r"adult (\w+) woman", p).group(1)

def make(n, pcts, wks, tints):
    src = rr.choice(trios); P = src['prompt']; paras = P.split("\n\n")
    if n == 4:
        used = set(re.findall(r"adult (\w+) woman", P))
        for _ in range(60):
            s2 = rr.choice([t for t in trios if t is not src]); blk = s2['prompt'].split("\n\n")[1]
            if nat(blk) not in used: break
        blk4 = "\n".join(re.sub(r"^#1", "#4", ln) if ln.startswith("#1") else ln for ln in blk.split("\n"))
        paras = paras[:4] + [blk4] + paras[4:]
    out = []
    for q in paras:
        new = []
        for ln in q.split("\n"):
            mm = re.match(r"#(\d) Body:", ln)
            new.append(body(int(mm.group(1)), pcts[int(mm.group(1)) - 1], wks[int(mm.group(1)) - 1], tints[int(mm.group(1)) - 1]) if mm else ln)
        out.append("\n".join(new))
    t = "\n\n".join(out)
    t = t.replace("a little further below the middle of her thighs", HIP).replace("demi statue portrait", "hip statue portrait")
    t = t.replace(", while the opaque bodies block it completely and are lit by two large softboxes raking from either side", "")
    if n == 4: t = t.replace("THREE women", "FOUR women")
    assert t.count("Body:") == n and "middle of her thighs" not in t
    return re.sub(r"\ba (?=[aeiou])", "an ", t), src['key']

def lab(pcts, wks, tints):
    return ", ".join(f"#{i+1} {p}%" + (f"({WORLDS[w][0]})" if p else "(내용물 없음)") + f" · 유리 {t[1]}" for i, (p, w, t) in enumerate(zip(pcts, wks, tints)))

if __name__ == "__main__":
    rr.seed(int(sys.argv[1]) if len(sys.argv) > 1 else 8282)
    res = []
    for n, base in ((3, [100, 50, 0]), (4, [100, 50, 25, 0])):
        p = base[:]; rr.shuffle(p)
        w = list(WORLDS); rr.shuffle(w); w = w[:n]
        ti = rr.sample(TINTS, n)
        t, key = make(n, p, w, [x[0] for x in ti])
        res.append((n, t, key, lab(p, w, ti))); print(n, len(t.split()), key, p)
    L = ["# LumineX — 프레임 힙컷 수조 내용물: 3인(100/50/0) · 4인(100/50/25/0), 얇고 투명한 유리에 옅은 색조 (세로 4:5)\n",
         "- 수위를 100/50/25/0%로 정리했습니다(75%는 가슴 높이라 표현이 어려워 제외). 50% = 허리(배꼽 바로 위), 25% = 엉덩이 높이.",
         "- 유리는 지난번처럼 머리카락처럼 얇고 투명하되, 사람마다 **옅은 색조**를 줬습니다(표면 중앙은 거의 투명, 가장자리·곡면 모서리에서만 색이 약간 진해짐). 물 자체는 맑은 물입니다.",
         "- 내용물은 사람마다 다르고(백합·장미·반딧불이 + 4인용 벚꽃잎은 새로 쓴 미등록 문구), 0%는 내용물이 없습니다.",
         "- 정상/이상만 번호로 알려주세요.\n"]
    for i, (n, t, key, lb) in enumerate(res, 1):
        L.append(f"## {i}번 — {n}인 (프레임 힙컷)\n\n구성: {lb}\n\n```\n{t}\n```\n")
    open('/mnt/user-data/outputs/LumineX_HipFrame_TankContents_Tinted_3_4.md', 'w', encoding='utf-8').write("\n".join(L))
