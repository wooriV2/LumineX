# -*- coding: utf-8 -*-
"""수조 2/3/4인 v3: A 듀얼바디 전신(L3) · B 프레임 힙컷. 가는 드문 선 배경, 물 색 선명, 프레임 컷 끝은 바닥에 닿음."""
import sys, re, pickle
sys.argv = ['x']
import gen_trio_mix2 as G
import gen_trio_mix as T, mdefs as D
import gen_hipframe_tank2 as G2
H = G2.H; rr = T.rr; rr.seed(int(__import__('os').environ.get('SEED','5151')))
KO = {"full": "가득", "p50": "50%", "p25": "25%", "empty": "비움"}
THIN = ["a few very thin, hairline black vertical lines, widely spaced about a hand's width apart, never thick, never bold, never dense",
        "a few very thin, hairline black horizontal lines, widely spaced about a hand's width apart, never thick, never bold, never dense",
        "a sparse grid of very thin hairline black lines in large squares, widely spaced, never thick, never bold, never dense"]
G.ARMPIT = True; G.DBTYPE = 'tank'; G.DBFILL = None
G.HAIRNOTE = "Any hair hanging behind a body is plainly visible through the empty glass, and the few thin lines of the wall bend slightly as they are seen through the thin glass of every body."
indoor = [k for k, v in D.BGL.BG.items() if not v[4]][:1]
resA = []
for n, base in ((4, ["full", "p50", "p25", "empty"]),):
    fl = base[:]; rr.shuffle(fl); w = list(H.WORLDS); rr.shuffle(w); w = w[:n]; ti = rr.sample(H.TINTS, n)
    wc = rr.sample(list(T.WATERS), n)
    G.SCENE_OVERRIDE = "a bright studio with a huge plain white backdrop wall marked with " + rr.choice(THIN) + ", and a pale polished floor"
    G.DBFILLS[:] = fl; G.DBTIERS[:] = [("L3", "L3")] * n; G.DBWATERS[:] = wc; G.DBTINTS[:] = [x[0] for x in ti]; G.DBWORLDS[:] = w; G.USED_MATS.clear(); G.URKINDS[:] = []
    t, meta = G.build(["db"] * n, None, "demi", ("L3", "L3"), wc[0], indoor[0])
    lab = ", ".join(f"#{i+1} {KO[f]}" + (f"({H.WORLDS[x][0]}, {c} 물)" if f != "empty" else "(내용물 없음)") + f" · 유리 {tt[1]}" for i, (f, x, tt, c) in enumerate(zip(fl, w, ti, wc)))
    resA.append((n, t, lab)); print("A", n, len(t.split()), fl)
resB = []
for n, base in ((4, [100, 50, 25, 0]),):
    p = base[:]; rr.shuffle(p); w = list(H.WORLDS); rr.shuffle(w); w = w[:n]; ti = rr.sample(H.TINTS, n)
    wcn = rr.sample(G2.WATERC, n)
    t, key, back = G2.make(n, p, w, [x[0] for x in ti], wcn)
    lab = ", ".join(f"#{i+1} {pp}%" + (f"({H.WORLDS[x][0]}, {c} 물)" if pp else "(내용물 없음)") + f" · 유리 {tt[1]}" for i, (pp, x, tt, c) in enumerate(zip(p, w, ti, wcn)))
    resB.append((n, t, lab)); print("B", n, len(t.split()), p, 'floor' in t)
common = ["- 뒷배경 선: **드문드문한 아주 가는 선**(손 한 뼘 간격, 굵지 않게)으로 바꿨습니다.",
          "- 물 양이 잘 보이게: 물을 **선명한 색**(유리 색조보다 훨씬 진하게)으로 칠하고, 수면을 \"또렷하고 밝은 선\"으로, 수면 위 빈 부분은 \"맑고 색 없음\"으로 썼습니다.",
          "- 수위 50% 기준은 이전과 같습니다. 정상/이상만 번호로 알려주세요.\n"]
LA = ["# LumineX — A. 듀얼바디 수조 2·3·4인 v4 (전신, 다리 L3, 겨드랑이 일자 경계, 세로 4:5)\n"] + common
for i, (n, t, lab) in enumerate(resA, 1): LA.append(f"## A-{i}번 — {n}인\n\n구성: {lab}\n\n```\n{t}\n```\n")
open('/mnt/user-data/outputs/LumineX_TankFill_A_DualBody_2_3_4_v4.md', 'w', encoding='utf-8').write("\n".join(LA))
LB = ["# LumineX — B. 프레임 힙컷 수조 2·3·4인 v4 (겨드랑이 일자 경계, 세로 4:5)\n"] + common[:2] + ["- **컷 끝이 바닥에 닿도록**: 모든 조각이 자기 두 둥근 끝 위에 바닥에 직접 서 있고(받침대 없음), 끝 아래에 틈이 없으며 접촉 그림자가 지게 썼습니다.", common[2]]
for i, (n, t, lab) in enumerate(resB, 1): LB.append(f"## B-{i}번 — {n}인\n\n구성: {lab}\n\n```\n{t}\n```\n")
open('/mnt/user-data/outputs/LumineX_TankFill_B_HipFrame_2_3_4_v4.md', 'w', encoding='utf-8').write("\n".join(LB))
