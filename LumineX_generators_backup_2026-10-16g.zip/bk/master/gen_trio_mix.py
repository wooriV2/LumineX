# -*- coding: utf-8 -*-
"""트리오 시험: 실사(바디페인팅) 1 + 프레임 컷 조각(받침대 위, 허벅지에서 끝남) 1 + 듀얼바디(좌우 다리 단계 다름) 1. 전원 USSBBW."""
import sys, re, json, random
import mdefs as D, mrecipes as R
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 1
rr = random.Random(SEED)
R.JN = 3
USS = [b for b in D.BODIES if b[0] == "USSBBW"][0]
SETTLES = ("every fold and curve keeps its own clear rounded outline with a deep shadowed crease between them, never merging into one shapeless mass, the sheer weight of the flesh visible in how it spills forward and settles")
SKIN = "real photographic skin with visible pores and fine grain, natural creases and shadow where the flesh folds, faint stretch marks where the great curves have expanded"
GLASS = "The glass is unmistakably glass: thick, crystal-clear and polished, with bright specular reflections sliding along every curved surface, sharp white highlights and dark refraction edges where the walls are thickest, tiny bubbles trapped in the glass itself."
WATERS = {"amethyst": "clear amethyst-violet water", "turquoise": "clear turquoise water", "coral": "clear coral-pink water", "sapphire": "clear sapphire-blue water", "citrine": "clear citrine-gold water", "emerald": "clear emerald-green water"}
BOUND = "A single straight, flat line runs around the base of her neck and across both collarbones, never jagged, never zigzag — real skin above, glass immediately below. At that line the glass edge rises in a small raised step above her flesh, casting a crisp shadow."
FLAT_CUT = ("a perfectly flat, deliberately cut cross-section, exactly like a clean slice cut through a cast-glass sculpture — at that flat cut face, the full thickness of the glass wall and the clear water sealed inside it are visible edge-on, the cut always clean, deliberate and precise, never jagged or torn, always the finish of a sculpture")
def leg_tr(side, tier):
    if tier == "L1":
        return (f"On the {side} leg, exactly at the very top of the thigh, near the hip, the glass ends in {FLAT_CUT}. Her real {side} leg is a separate thing entirely: it simply begins at that same height, flush against the cut face of the glass above it, sharing nothing with it — an ordinary, undisturbed real leg, with real skin, real pores and fine grain, warm in tone, completely opaque, never itself cut, never marked, the entire thigh, knee, calf, ankle and foot all real.")
    if tier == "L2":
        return (f"On the {side} leg, a little above the knee, the glass ends in {FLAT_CUT}. Her real {side} knee, calf and foot are a separate thing entirely: they simply begin at that same height, flush against the cut face of the glass above them, sharing nothing with it — an ordinary, undisturbed real leg, with real skin, real pores and fine grain, warm in tone, completely opaque, never itself cut, never marked.")
    if tier == "L3":
        return (f"On the {side} leg, the glass continues, unbroken, down through the entire calf, narrowing naturally with the shape of the leg, and ends only at the very last possible point — exactly just above the ankle bone — in {FLAT_CUT}. Her real {side} ankle bone and foot are a separate thing entirely: they simply begin at that same low point, flush against the cut face of the glass above them, sharing nothing with it — an ordinary, undisturbed real ankle and foot, with real skin, real pores and fine grain, warm in tone, completely opaque, never itself cut, never marked.")
LEGDESC = {"L1": "her {s} thigh, only its very top near the hip, is part of the glass body", "L2": "her {s} thigh, down to just above the knee, is part of the glass body", "L3": "her {s} thigh and her entire {s} calf, all the way down to just above the ankle bone, are part of the glass body"}
def person_bits(label, eth, age_):
    feat, seg, info = R.face(rr, eth)
    jw = rr.sample(D.JEWEL_BODY, R.JN)
    jt = ", ".join(jw[:-1]) + ", and " + jw[-1] + ". Jewelry is metal and pearl only, worn on the body, nothing added to her face or ears."
    face = f"{label}: Face: her face and ears are real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    return face, f"{label}: Jewelry: {jt}", info
def hair_(eth):
    return R.hair(rr, eth, {})[0]
def eth_pick(used):
    k = [e for e in D.ETH_BY if e not in used]; e = rr.choice(k); used.add(e); return D.ETH_BY[e]
def build(water2, water3, tiers, bgkey):
    used = set(); ages = rr.sample(D.AGES, 3)
    b_real = USS[1] + "; " + SETTLES + "; " + SKIN
    b_mat = USS[1] + "; " + SETTLES
    # #1 실사
    e1 = eth_pick(used); spec = R.mat_spec(rr, "bodypaint"); h1, l1 = R.hair(rr, e1, spec)
    blk1, info1, _ = R.person(rr, "#1", "bodypaint", spec, ("USSBBW", b_real), ages[0], "standing with both hands on her hips in a powerful stance, chin lifted, weight on one leg", e1, h1, None, "stil", rr.choice(D.STIL), None)
    blk1 = blk1.replace(". Pose:", "; the pigment sits on living skin so it distorts slightly over every bulge and cracks a little where the skin folds. Pose:", 1)
    # #2 프레임 컷 조각(받침대)
    e2 = eth_pick(used); h2 = hair_(e2); face2, jew2, info2 = person_bits("#2", e2, ages[1])
    body2 = (f"#2: {e2[1]}, {ages[1]} goddess, USSBBW physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {b_mat}, {h2} — a sculpture-woman: her face, ears and neck are real living flesh, and below the collarbones her whole body is a sculpted vessel of thick, crystal-clear glass completely filled with {WATERS[water2]} from the collarbone line down to the cut, with no hollow space and no air gap anywhere inside it. {GLASS} Both arms below the shoulder, both hands, and every finger and knuckle, are the same solid clear glass, with no skin anywhere on them. Small bright fish and slow-drifting water plants move through the whole filled volume, never crowding, always with open water around each one. {BOUND} "
             f"Her body ends at the upper thighs in {FLAT_CUT}, and that flat cut stands directly on the top of a low pale stone plinth about as high as the hips of the two standing women, so that from the plinth up she is a complete glass torso with her thighs and her head is level with theirs; below the plinth nothing of her exists. Pose: upright on the plinth with her solid glass hands resting on her flared hips, her head tilted slightly toward the camera — most extreme USSBBW silhouette ever displayed.")
    nails2 = "#2: Nails: the longest nails physically imaginable, " + rr.choice(D.NAIL_SHAPES) + " nails each " + rr.choice(D.NAIL_LEN) + ", made of the same clear glass with a high polish."
    # #3 듀얼바디
    e3 = eth_pick(used); h3 = hair_(e3); face3, jew3, info3 = person_bits("#3", e3, ages[2]); lt, rt = tiers
    legs = LEGDESC[lt].format(s="left") + "; " + LEGDESC[rt].format(s="right")
    body3 = (f"#3: {e3[1]}, {ages[2]} goddess, USSBBW physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {b_mat}, {h3} — a dual-body woman: her face, ears and neck are real living flesh, and below the collarbones her chest, both arms, both hands, belly, hips and the upper parts of her legs ({legs}) are a sculpted vessel of thick, crystal-clear glass completely filled with {WATERS[water3]}, with no hollow space and no air gap anywhere inside it. {GLASS} Both arms below the shoulder, both hands, and every finger and knuckle, are the same solid clear glass, with no skin anywhere on them. Small bright fish and slow-drifting water plants move through the whole filled volume, never crowding. {BOUND} "
             f"Left leg: {leg_tr('left', lt)} Right leg: {leg_tr('right', rt)} Both of her real feet stand in real extreme platform stiletto sandals of glossy black leather. Pose: standing tall with her solid glass left hand resting on her flared hip and her right arm held clear of her body, the hand solid glass and relaxed at hip height, her head tilted slightly toward the camera — most extreme USSBBW silhouette ever displayed.")
    nails3 = "#3: Nails: the longest nails physically imaginable, " + rr.choice(D.NAIL_SHAPES) + " nails each " + rr.choice(D.NAIL_LEN) + ", made of the same clear glass with a high polish."
    bg = D.BGL.BG[bgkey]; scene = re.sub(r"\ba (?=[aeiou])", "an ", bg[3])
    head = "Professional fashion photograph, full body group shot. THREE women side by side in a row: on the left a real living woman standing, in the centre a woman whose glass body ends at the upper thighs and stands on a low stone plinth, and on the right a standing woman whose glass body turns back into real skin part-way down her legs."
    env = f"Environment: {scene}, soft even gallery light from the front with a thin cool rim light along each figure and a gentle glow passing through the glass bodies, the whole floor and surroundings clearly visible and in focus, NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no other statues or props. Arrangement: #1 is the real woman on the left, #2 is the glass sculpture-woman on the plinth in the centre, #3 is the dual-body woman on the right."
    allp = "All: Extreme macro detail on every surface texture and shadow. All three women are USSBBW giants of the same overwhelming scale, with their heads at the same height, the real woman's body art and the glass bodies each in true relief."
    cam = "Full-length wide shot with the camera at waist height looking straight on, no high angle, pushed close so the three fill the frame edge to edge, the real woman and the dual-body woman completely visible from the soles of their shoes to the top of their heads, the whole plinth in view. 8K portrait 4:5 aspect ratio."
    blocks = "\n".join([blk1, "", body2, nails2, jew2, face2, "", body3, nails3, jew3, face3])
    t = f"{head}\n\n{blocks}\n\n{env}\n{allp} {cam}"
    t = re.sub(r"\ba (?=[aeiou])", "an ", t)
    assert not re.search(r"[가-힣]", t), re.findall(r".{20}[가-힣]+", t)
    d = re.findall(r"\b(\w+) \1\b", t); assert not d, d
    return t, [spec["name"], info1, info2, info3, f"#2 물색 {water2}", f"#3 물색 {water3}", f"#3 다리 좌{lt}/우{rt}", bg[2], [e1[0], e2[0], e3[0]]]
if __name__ == "__main__":
    import itertools
    indoor = [k for k, v in D.BGL.BG.items() if not v[4] and v[0] not in D.BGL.NARROW]
    out = []
    for water2, water3, tiers in (("amethyst", "turquoise", ("L2", "L3")), ("coral", "sapphire", ("L1", "L2"))):
        bgk = rr.choice(indoor); t, meta = build(water2, water3, tiers, bgk); out.append((t, meta))
    json.dump(out, open("trio_mix.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for t, m in out: print(len(t.split()), m)
