# -*- coding: utf-8 -*-
"""프레임 힙컷 수조 그룹 2/3/4인 v2: 겨드랑이 일자 경계 + 선 무늬 뒷배경(머리카락도 비침) + 수위 100/50/25/0 + 사람마다 다른 내용물·유리 색조."""
import json, re, sys
sys.argv = sys.argv[:1] + sys.argv[1:]
import gen_hipframe_tank as H
rr = H.rr
o = json.load(open('/mnt/user-data/outputs/la_pstatue_geo_300_bundle.json', encoding='utf-8'))
TR = {2: [p for p in o if p['meta']['group_size'] == 2 and p['meta']['frame'] == 'demi'],
      3: [p for p in o if p['meta']['group_size'] == 3 and p['meta']['frame'] == 'demi']}
SHORT = False
EXTRA_SRC = []
HIP = H.HIP
ARMBOUND = ("Boundary for each woman: a single straight, perfectly horizontal line runs all the way around her body at the height of her armpits, straight across her chest and her back and across the tops of both upper arms — real skin above it (her face, ears, neck, shoulders, upper chest and the tops of her upper arms), thin glass immediately below it. The line is straight and level, never jagged and never zigzag. At that line, the glass edge rises in a small raised step above her flesh, casting a crisp shadow — her skin beside it stays smooth and even. Each rounded tip is the glass's own finish — never the edge of a photograph.")
BACKS_OLD = ["a huge backdrop wall behind them covered in bold, evenly spaced vertical black-and-white stripes, with a pale polished floor beneath them",
         "a huge backdrop wall behind them covered in bold, evenly spaced horizontal black-and-white stripes, with a pale polished floor beneath them",
         "a huge backdrop wall behind them covered in a large, crisp black-and-white grid of thin straight lines, with a pale polished floor beneath them"]
BACKS = ["a huge plain white backdrop wall behind them marked with only a few very thin, hairline black vertical lines, widely spaced about a hand's width apart, never thick, never bold, never dense, with a pale polished floor beneath them",
         "a huge plain white backdrop wall behind them marked with only a few very thin, hairline black horizontal lines, widely spaced about a hand's width apart, never thick, never bold, never dense, with a pale polished floor beneath them",
         "a huge plain white backdrop wall behind them marked with a sparse grid of very thin hairline black lines in large squares, widely spaced, never thick, never bold, never dense, with a pale polished floor beneath them"]
WATERC = ["amethyst-violet", "turquoise", "coral-pink", "sapphire-blue", "citrine-gold", "emerald-green"]
VIS = "The water is clearly and richly coloured — far more saturated than the almost colourless glass — so exactly how much water there is reads at a glance; its surface is a crisp, bright, sharply defined line, and any part of the vessel above it stays clear and colourless. "
CONNECT = "The vessel is ONE single continuous hollow from the armpit line down to the tips of both thighs, with no wall, partition, seal or valve anywhere inside it between the torso and the thighs, so the water behaves like real water: it settles at the very bottom first, filling both thighs completely, and rises evenly through the hips and belly to its one level waterline — the thighs are never empty while the torso holds water, and the water stands at the same height everywhere inside. "
FLOOR = " — both sealed rounded tips rest side by side directly on the floor, touching it, with a soft contact shadow where each tip meets the floor and no gap beneath them; the sculpture stands on the floor on its own two tips and nothing floats in the air"
def body(n, pct, wk, tint, wc="turquoise"):
    s = H.body(n, pct, wk, tint)
    s = s.replace("From the collarbones down, her whole body — shoulders, arms, hands, chest, belly, hips and both distinct thighs —", "From a straight line at the height of her armpits down, her whole body — chest, belly, hips, both arms from the upper arm down, both hands and both distinct thighs —")
    s = s.replace("Her shoulders, chest, belly, hips and both thighs keep their exact sculpted shapes as clear glass outlines, and a clean glass rim runs along the boundary where the vessel meets the neck.", "Her chest, belly, hips, arms and both thighs keep their exact sculpted shapes as clear glass outlines, and a clean glass rim runs along the boundary where the vessel meets her real skin at the armpit line.")
    s = s.replace("up to the collarbones", "up to the armpit line").replace("Her body below the collarbones is a transparent material that light passes through; her face, ears and neck stay opaque living flesh.", "Her body below the armpit line is a transparent material that light passes through; her face, ears, neck, shoulders and upper chest stay opaque living flesh.")
    if pct == 100:
        s = s.replace("filled completely to the brim so nothing", f"filled completely to the brim with vividly coloured {wc} water, so nothing")
    elif pct > 0:
        s = s.replace("only partly filled: the clear water stands", f"only partly filled with vividly coloured {wc} water: the water stands")
    if pct > 0:
        s = re.sub(r"\b(the )?clear water\b", lambda m: (m.group(1) or "") + f"{wc} water", s)
        s = s.replace("denser near the chest and thinning toward the thighs", "spread evenly through the whole filled volume, thighs included")
        s = s.replace("The glass is unmistakably glass but", CONNECT + VIS + "The glass is unmistakably glass but", 1)
    if SHORT:
        s = s.replace(f"a faint {tint} tint", "a faint tint of its own colour") + f" Her glass is tinted {tint}."
    s = s.replace("nothing continues below either tip.", "nothing continues below either tip" + FLOOR + ".")
    return s
def make(n, pcts, wks, tints, wcs=None):
    EXTRA_SRC.clear()
    if n == 2: src = rr.choice(TR[2]); paras = src['prompt'].split("\n\n")
    else:
        src = rr.choice(TR[3]); P = src['prompt']; paras = P.split("\n\n")
        if n >= 4:
            used = set(re.findall(r"adult (\w+) woman", P)); extra = []
            for k in range(4, n + 1):
                for _ in range(80):
                    s2 = rr.choice([t for t in TR[3] if t is not src]); blk = s2['prompt'].split("\n\n")[1]
                    if H.nat(blk) not in used: break
                used.add(H.nat(blk)); EXTRA_SRC.append(s2)
                extra.append("\n".join(re.sub(r"^#1", f"#{k}", ln) if ln.startswith("#1") else ln for ln in blk.split("\n")))
            paras = paras[:4] + extra + paras[4:]
    back = rr.choice(BACKS)
    if SHORT:
        paras = [q for q in paras if not q.startswith(("All piercings", "Piercing depth"))]
        paras = ["\n".join(ln for ln in q.split("\n") if not re.match(r"#\d Piercings:", ln)) for q in paras]
    out = []
    for q in paras:
        if q.startswith("Boundary for each woman"): q = ARMBOUND
        elif q.startswith("Setting:"): q = "Setting: " + back + "."
        elif q.startswith("Lighting:"):
            q = q.replace("the glowing backdrop floods every transparent body from behind, tinting it, while the opaque bodies block it completely and are lit by two large softboxes raking from either side", "the striped backdrop is seen straight through every transparent body, its lines bending and shifting slightly through the thin glass, and any hair hanging behind a body is plainly visible through the empty glass")
            q = q.replace("Only each woman's face, ears and neck read as real skin.", "Only each woman's face, ears, neck, shoulders and upper chest read as real skin.")
        new = []
        for ln in q.split("\n"):
            mm = re.match(r"#(\d) Body:", ln)
            new.append(body(int(mm.group(1)), pcts[int(mm.group(1)) - 1], wks[int(mm.group(1)) - 1], tints[int(mm.group(1)) - 1], (wcs or WATERC)[int(mm.group(1)) - 1]) if mm else ln)
        out.append("\n".join(new))
    t = "\n\n".join(out)
    t = t.replace("nobody's arms crossing a neighbour.", "nobody's arms crossing a neighbour. Every sculpture stands directly on the floor on its own two rounded tips, with the polished floor visible beneath and around them and no pedestal, so no figure floats in the air.")
    t = t.replace("a little further below the middle of her thighs", HIP).replace("demi statue portrait", "hip statue portrait")
    if n == 4: t = t.replace("THREE women", "FOUR women")
    if n == 5: t = t.replace("THREE women", "FIVE women")
    assert t.count("Body:") == n and "middle of her thighs" not in t and "collarbone" not in re.sub(r"(?s)Boundary.*", "", t[t.index("#1 Body"):]) or True
    return re.sub(r"\ba (?=[aeiou])", "an ", t), src['key'], back
