# -*- coding: utf-8 -*-
"""테마 바디페인팅: Core 번들 원문 + 공예 앵커 + 테마 모티프 + 보통 체형 (2~5인 Core, 7인 septet)."""
import json,re,random
pool=json.load(open('/tmp/claude-0/-home-claude/62db5eea-2487-540b-9935-a7df06448e2a/scratchpad/master/craft_pool.json',encoding='utf-8'))
core=json.load(open('/mnt/user-data/outputs/la_core_bundle.json',encoding='utf-8')); cby={x['key']:x for x in core}
sep=json.load(open('/mnt/user-data/outputs/la_core_7to10_bundle.json',encoding='utf-8')); sby={x['key']:x for x in sep}
def P(name):
    g,b,f=pool[name]; return (name,g,b,f)
CR={
 'spring':("Norwegian rosemaling folk painting","a fresh spring-green ground with bold cream and pink tulip, blossom and acanthus scrollwork","cream","dense tulip-and-blossom scrollwork filling the space between bands"),
 'summer':("Dutch Delft blue-and-white pottery","a deep cobalt-blue ground with bold white wave and seashell motifs","white","dense wave-and-seashell linework filling the space between bands"),
 'autumn':("Japanese Kutani porcelain","a vivid, opaque russet-orange ground, far more saturated than any skin tone, with bold red and gold maple-leaf overglaze enamels","gold-and-red","dense falling maple-leaf enamel motifs filling the space between bands"),
 'winter':("Russian Gzhel blue-and-white ceramics","a brilliant white ground with bold icy cobalt-blue and silver snowflake and frost-crystal motifs","icy blue","dense snowflake-and-frost-crystal linework filling the space between bands"),
 'celadon':("Chinese Longquan celadon ceramic","a jade-green celadon glaze carved with bold bamboo and pine-branch motifs","pale jade","dense bamboo-leaf and pine-needle carving filling the space between bands"),
 'cinnabar':("Chinese carved cinnabar lacquer","a vivid vermilion-red lacquer ground with bold gold flame-and-cloud scroll motifs","gold","dense flame-and-cloud scrollwork filling the space between bands"),
 'nazca':P("Peruvian Nazca painted pattern"),'eunipsa':P("Korean eunipsa silver inlay"),'iittala':P("Finnish Iittala glass-inspired linework"),
 'boles':P("Polish Bolesławiec pottery"),'dalarna':P("Swedish Dalarna kurbits folk painting"),
 'kyellow':("Japanese Kutani porcelain","a vivid, opaque golden-yellow overglaze ground, far more saturated than any skin tone, with bold green and red leaf-and-flower enamels","green-and-red","dense leaf-and-flower enamel motifs filling the space between bands"),
 'ksun':("Japanese Kutani porcelain","a vivid, opaque golden-yellow overglaze ground, far more saturated than any skin tone, with bold orange and gold sunburst-and-cloud enamels","orange-and-gold","dense sunburst-and-cloud enamel motifs filling the space between bands"),
 'moon':("Finnish Iittala glass-inspired linework","a deep indigo ground with bold cream full-moon disc and drifting-cloud motifs","cream","dense moon-disc and cloud linework filling the space between bands"),
 'water':("Finnish Iittala glass-inspired linework","a deep indigo ground with bold cream concentric ripple-line motifs","cream","dense ripple-line linework filling the space between bands"),
 'aubergine':("Chinese Qing aubergine-glazed porcelain","a vivid, opaque aubergine-purple glazed ground with bold pale-lilac and gold lotus-scroll motifs","gold","dense lotus-scroll medallions filling the space between bands"),
 'orange':("Peruvian Nazca painted pattern","a vivid, opaque terracotta-orange ground, far more saturated than any skin tone, densely painted with stylised gold figures","gold",pool["Peruvian Nazca painted pattern"][2]),
 'dragon':("Chinese Longquan celadon ceramic","a jade-green celadon glaze carved with bold coiling dragon-and-cloud motifs","pale jade","dense dragon-scale and cloud carving filling the space between bands"),
 'tiger':("Chinese Jingdezhen porcelain","a brilliant white porcelain ground with bold black ink-brush tiger-and-bamboo motifs","black","dense ink-brush bamboo-leaf linework filling the space between bands"),
 'phoenix':("Chinese carved cinnabar lacquer","a vivid vermilion-red lacquer ground with bold gold phoenix-and-flame motifs","gold","dense phoenix-feather and flame scrollwork filling the space between bands"),
 'turtle':("Korean eunipsa silver inlay","a deep black ground with thick bright silver turtle-and-serpent and wave linework","bold silver","dense turtle-shell and wave silver linework filling the space between bands"),
}
BODY=["A tall, athletic, toned woman with broad shoulders, a defined waist and strong legs; natural, realistic proportions.",
      "A curvy hourglass woman with a full bust, a defined waist and rounded hips; natural, realistic proportions.",
      "A tall, slender woman with long legs and a graceful, elegant build; natural, realistic proportions.",
      "A strong, muscular woman with defined arms and thighs and a powerful but feminine build; natural, realistic proportions.",
      "A full-figured, soft curvy woman with generous hips and thighs and a defined waist; natural, realistic proportions."]
NUMW={2:"two",3:"three",4:"four"}; RATIO={2:"3:4",3:"4:5",4:"4:5"}
COVER="covering her whole body below the jaw — her neck, shoulders, bust, belly, hips, rear, both arms down to the fingertips and both legs down to the ankles — with no bare skin anywhere"
def art(c,pos):
    craft,g,b,f=c
    return f"{pos}'s body art: painted in {craft} — {g}, wide {b} bands following every deep crease, {f}, pigment on living skin, {COVER}, face unpainted, pattern fading at the neck."
def shoe(sh,pos):
    return f"{pos}'s footwear: extreme {sh} platform stiletto sandals in the same colour as her body, her painted legs running unbroken from hip to ankle into the sandals, the platform soles rising far higher than her ankle bone, at least three times the thickness of an ordinary heel."
def core_theme(base,items,pos,theme,portrait=True):
    n=len(pos); t=cby[base]['prompt']; paras=t.split("\n\n"); bodies=random.sample(BODY,n)
    for (k,sh),p,bd in zip(items,pos,bodies):
        for pre,new in [("body art",art(CR[k],p)),("footwear",shoe(sh,p)),("physique",f"{p}'s physique: {bd}")]:
            i=[j for j,x in enumerate(paras) if x.startswith(f"{p}'s {pre}:")]; assert len(i)==1,(p,pre); paras[i[0]]=new
    paras.insert(2,theme); t="\n\n".join(paras)
    if portrait and n in NUMW:
        h=f"a landscape-orientation photograph, {RATIO[n]} aspect ratio, {NUMW[n]} women in a single row."
        assert h in t,h; t=t.replace(h,f"a vertical portrait-orientation photograph, {RATIO[n]} aspect ratio, taller than it is wide, {NUMW[n]} women in a single row.").replace(f"{RATIO[n]} landscape 8K",f"{RATIO[n]} portrait 8K")
    return t
def septet_theme(base,items,theme):
    t=sby[base]['prompt']; i=t.index("Left to right:"); head,body=t[:i],t[i:]
    paras=body.split("\n\n"); first=paras[0].split("\n"); lead=first[0]; women=first[1:]+[x for x in paras[1:] if x.startswith("[")]; rest=[x for x in paras[1:] if not x.startswith("[")]
    out=[]
    for (k,sh),w in zip(items,women):
        craft,g,b,f=CR[k]
        rep=f"Painted in {craft} ({g}, with wide {b} bands following every deep crease and {f.replace(' filling the space between bands','')}), covering her whole body from the jaw down to the tips of her toes — her neck, shoulders, bust, belly, hips, rear, both arms down to the fingertips and both legs down to the ankles — with no bare skin anywhere, face unpainted."
        w2,n1=re.subn(r"Painted in (.*?), covering her whole body below the jaw with no bare skin, face unpainted\.",lambda m:rep,w)
        w2,n2=re.subn(r"Shoes: [^\n]*$",f"Shoes: extreme {sh} platform stiletto sandals in the same colour as her body, her painted legs running unbroken from hip to ankle into the sandals.",w2)
        assert n1==1 and n2==1; out.append(w2)
    return head.rstrip("\n")+"\n\n"+theme+"\n\n"+lead+"\n"+"\n\n".join(out)+("\n\n"+"\n\n".join(rest) if rest else "")
C2=["Left woman","Right woman"]; C3=["Left woman","Center woman","Right woman"]; C4=["Far-left woman","Left woman","Right woman","Far-right woman"]; C5=["Far-left woman","Left woman","Center woman","Right woman","Far-right woman"]
