# -*- coding: utf-8 -*-
"""수조 4인 v5(짧은 버전): 사람마다 같은 문장은 한 번만 쓰고, 달라지는 부분(수위·물 색·내용물·유리 색조)만 사람별로 남긴다. B는 피어싱 문단 제거."""
import sys, re, os
sys.argv = ['x']
import gen_trio_mix2 as G
import gen_trio_mix as T, mdefs as D
import gen_hipframe_tank2 as G2
H = G2.H; rr = T.rr; rr.seed(int(os.environ.get('SEED', '7373')))
G.SHORTMODE = True; G2.SHORT = True
KO = {"full": "가득", "p50": "50%", "p25": "25%", "empty": "비움"}
THIN = ["a few very thin, hairline black vertical lines, widely spaced about a hand's width apart, never thick, never bold, never dense",
        "a few very thin, hairline black horizontal lines, widely spaced about a hand's width apart, never thick, never bold, never dense",
        "a sparse grid of very thin hairline black lines in large squares, widely spaced, never thick, never bold, never dense"]
NOTE = "Every woman below is built exactly like #1 in everything not restated for her (same vessel construction, glass finish, boundary line, water behaviour, physique and pose); only her water level, water colour, contents and glass tint differ."
KEEP = ("continuous hollow", "seals shut", "directly on the floor", "flat, deliberately cut cross-section")
def dedupe(t):
    seen = set(); out = []
    for ln in t.split("\n"):
        parts = re.split(r"(?<=\.) ", ln); keep = []
        for p in parts:
            key = re.sub(r"^#\d+:? ", "", p).strip()
            if len(key) > 90 and key in seen and not any(k in key for k in KEEP): continue
            if len(key) > 90: seen.add(key)
            keep.append(p)
        out.append(" ".join(keep))
    return re.sub(r"\n{3,}", "\n\n", "\n".join(out))
G.ARMPIT = True; G.DBTYPE = 'tank'; G.DBFILL = None
G.HAIRNOTE = "Any hair hanging behind a body is plainly visible through the empty glass, and the few thin lines of the wall bend slightly as they are seen through the thin glass of every body."
indoor = [k for k, v in D.BGL.BG.items() if not v[4]][:1]
n = 4
fl = ["full", "p50", "p25", "empty"]; rr.shuffle(fl); w = list(H.WORLDS); rr.shuffle(w); w = w[:n]; ti = rr.sample(H.TINTS, n); wc = rr.sample(list(T.WATERS), n)
G.SCENE_OVERRIDE = "a bright studio with a huge plain white backdrop wall marked with " + rr.choice(THIN) + ", and a pale polished floor"
G.DBFILLS[:] = fl; G.DBTIERS[:] = [("L3", "L3")] * n; G.DBWATERS[:] = wc; G.DBTINTS[:] = [x[0] for x in ti]; G.DBWORLDS[:] = w; G.USED_MATS.clear(); G.URKINDS[:] = []
tA0, _ = G.build(["db"] * n, None, "demi", ("L3", "L3"), wc[0], indoor[0])
tA = dedupe(tA0)
tA = tA.replace("\n\n#1:", "\n\n" + NOTE + "\n\n#1:", 1) if "\n\n#1:" in tA else tA
labA = ", ".join(f"#{i+1} {KO[f]}" + (f"({H.WORLDS[x][0]}, {c} 물)" if f != "empty" else "(내용물 없음)") + f" · 유리 {tt[1]}" for i, (f, x, tt, c) in enumerate(zip(fl, w, ti, wc)))
print("A", len(tA0.split()), "->", len(tA.split()))
p = [100, 50, 25, 0]; rr.shuffle(p); w2 = list(H.WORLDS); rr.shuffle(w2); w2 = w2[:n]; ti2 = rr.sample(H.TINTS, n); wcn = rr.sample(G2.WATERC, n)
tB0, key, back = G2.make(n, p, w2, [x[0] for x in ti2], wcn)
tB = dedupe(tB0)
tB = tB.replace("\n\n#1:", "\n\n" + NOTE + "\n\n#1:", 1)
labB = ", ".join(f"#{i+1} {pp}%" + (f"({H.WORLDS[x][0]}, {c} 물)" if pp else "(내용물 없음)") + f" · 유리 {tt[1]}" for i, (pp, x, tt, c) in enumerate(zip(p, w2, ti2, wcn)))
print("B", len(tB0.split()), "->", len(tB.split()))
head = ["- 프롬프트를 줄였습니다: **사람마다 똑같은 문장은 한 번만** 쓰고 맨 앞에 \"나머지는 #1과 동일, 달라지는 건 수위·물 색·내용물·유리 색조뿐\"이라는 문장을 넣었습니다.",
        "- 4인 한 세트만 새로 뽑았고, 수위·내용물·물 색·유리 색조는 랜덤입니다. 정상/이상만 알려주세요.\n"]
open('/mnt/user-data/outputs/LumineX_TankFill_A_DualBody_4_short.md', 'w', encoding='utf-8').write("\n".join(["# LumineX — A. 듀얼바디 전신 4인 짧은 버전 (세로 4:5)\n"] + head + [f"## A-short\n\n구성: {labA}\n\n```\n{tA}\n```\n"]))
open('/mnt/user-data/outputs/LumineX_TankFill_B_HipFrame_4_short.md', 'w', encoding='utf-8').write("\n".join(["# LumineX — B. 프레임 힙컷 4인 짧은 버전 (세로 4:5, 피어싱 문단 제외)\n"] + head + [f"## B-short\n\n구성: {labB}\n\n```\n{tB}\n```\n"]))
