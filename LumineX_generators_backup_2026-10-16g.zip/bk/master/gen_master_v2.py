# -*- coding: utf-8 -*-
"""LumineX Master Mix 300 — 정의된 모든 축을 기본 랜덤으로 쓰는 새 생성기 (이전 번들 생성기 비상속).
출력: la_mastermix_300_bundle.json + 축별 '정의 수 / 사용 수' 표."""
import sys, re, json, random, collections
import mdefs as D, mrecipes as R
# ── v2 (2026-10-11): 새 재질 4종 포함 · 극단 체형 A/B 표현 · 앉은 자세 · 하이앵글/극단 포즈 제외 ──
D.KO.update({"kintsugi": "킨츠기", "kintsugi_p": "킨츠기(그림)", "liquidgold": "리퀴드골드", "liquidsilver": "리퀴드실버"})
D.ALL_KINDS[:] = list(D.ALL_KINDS) + [k for k in ("kintsugi", "kintsugi_p", "liquidgold", "liquidsilver") if k not in D.ALL_KINDS]
EXTREME = ("USSBBW", "hourglass SSBBW")              # A/B 체형 표현 + 하이앵글 제외 + 솔로 앉은 자세 대상 (임산부 변형은 보류: 41-6, 코드 a_variant()는 남겨 둠)
AB = ["B", "B", "B", "A", "A"]                        # 페인트 재질에서 B 60 : A 40 (균형 랜덤). 페인트가 아니면 B 고정
SEAT_P = 0.7                                          # 극단 체형 솔로의 앉은 자세 비율
EXC_IDX = (17, 1, 12, 19, 23, 38, 40)                 # 듀오 이상에서 제외: 점프·한쪽 다리 들기·런지·극단 아치·전신 뻗기·역동 포즈
EXC = {D.POSES_ALL[i] for i in EXC_IDX}
A_PN = "heavily oversized SuperBBW"
A_PD = "overwhelmingly massive bust, maximum hip expansion, heavy thighs, profound physical volume dominating the frame"
B_INS = ("every fold and curve keeps its own clear rounded outline with a deep shadowed crease between them, never merging into one shapeless mass, the sheer weight of the flesh visible in how it spills forward and settles{edge}; "
         "real photographic skin with visible pores and fine grain, natural creases and shadow where the flesh folds, faint stretch marks where the great curves have expanded")
PAINT_S = "; the pigment sits on living skin so it distorts slightly over every bulge and cracks a little where the skin folds"
def a_variant(name):
    if name.startswith("pregnant"): return (A_PN.replace("oversized ", "oversized pregnant "), A_PD + "; a huge full-term pregnant belly projecting far forward in front of her")
    return (A_PN, A_PD)
SEAT = ["seated on a backless stone bench with her knees apart and her feet planted in front of her, both hands resting on her thighs",
 "seated on a long wooden bench with a high backrest, leaning back with her legs stretched out in front of her",
 "seated on a low stone wall with her knees apart, one hand resting on her thigh",
 "seated on a wide stone ledge with her legs stretched out in front of her, leaning back on her hands",
 "seated on a carved stone chair with her knees apart, her hands on the armrests",
 "seated in a sturdy wooden armchair, leaning back with her legs stretched out in front of her",
 "seated on a long backless gallery bench with her knees apart and her hands resting on her thighs",
 "seated on a wide wooden chair with a tall backrest, her legs stretched out in front of her",
 "seated on a broad flight of stone steps with her knees apart and her legs stretched down the steps in front of her",
 "seated on a low wooden stool with her knees apart, hands on her knees",
 "seated on a long upholstered bench with her legs crossed at the ankle, one hand resting on her thigh"]
for _p in SEAT: D.POSE_FLOOR[_p] = "seat"
VARS = {}

SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 20261201
OUT = "mastermix_v2_test.json"
class BRandom(random.Random):
    """랜덤하되, 같은 풀에서 덜 쓰인 값이 더 잘 뽑히게 해서 정의된 값이 모두 쓰이도록 한다 (채택된 프롬프트만 집계)."""
    def __init__(self, seed):
        super().__init__(seed); self.cnt = collections.Counter(); self.pend = collections.Counter()
    def choice(self, seq):
        if len(seq) < 2: return super().choice(seq)
        c = [self.cnt[(id(seq), i)] + self.pend[(id(seq), i)] for i in range(len(seq))]
        if self.random() < 0.6:
            m = min(c); i = self.choice_idx([j for j in range(len(seq)) if c[j] == m])
        else:
            w = [1.0 / (1 + x) ** 6 for x in c]; i = self.choices(range(len(seq)), w)[0]
        self.pend[(id(seq), i)] += 1
        return seq[i]
    def choice_idx(self, L): return L[int(self.random() * len(L))]
    def commit(self): self.cnt.update(self.pend); self.pend.clear()
    def rollback(self): self.pend.clear()
rg = BRandom(SEED)
CAT = "🏺 Living Artifact · Master Mix Formula"
USED = collections.defaultdict(collections.Counter)
def use(axis, v): USED[axis][v] += 1

# 신발 종류 비율 (프롬프트 단위): 스틸레토 / 발레(1~2인만) / 일반
CLS = {}
for n_ in range(1, 6):
    L = (["stil"] * 33 + ["ballet"] * 9 + ["flat"] * 18) if n_ == 1 else (["stil"] * 36 + ["ballet"] * 6 + ["flat"] * 18) if n_ == 2 else (["stil"] * 42 + ["flat"] * 18)
    rg.shuffle(L)
    for k_, c_ in enumerate(L, 1): CLS[(n_, k_)] = c_
BLACK_ONLY = ("goldleaf", "wax", "obsidian")


def pick_kinds(n, kk):
    if n == 1:
        k = D.ALL_KINDS[(kk - 1) % len(D.ALL_KINDS)]; rg.pend[(id(D.ALL_KINDS), D.ALL_KINDS.index(k))] += 1
        return [k]
    while True:
        ks = []
        for _ in range(60):
            k = rg.choice(D.ALL_KINDS)
            if k not in ks: ks.append(k)
            if len(ks) == n: break
        if len(ks) < n or ks.count("uvneon") > 1 or sum(k in BLACK_ONLY for k in ks) > 2: rg.rollback(); continue
        return ks


def pick_bodies(n):
    out = []
    while len(out) < n:
        b = rg.choice(D.BODIES)
        if b not in out: out.append(b)
    return out


def pick_eths(kinds, bodies):
    """인종: 체형 연결(블랙글래머 등) + 재질 조건(금박·왁스·흑요암=검은 피부, UV=브론즈 제외) + 컨셉(재질별 신화 인물 80%) + 중복 없음."""
    n = len(kinds); eths = [None] * n; concepts = [None] * n; used = set()
    def allowed(i, e):
        k = kinds[i]; lk = D.BODY_LINK.get(bodies[i][0].replace("pregnant ", ""))
        return e not in used and (k not in D.SKIN_ONLY or e in D.SKIN_ONLY[k]) and (k not in D.SKIN_NOT or e not in D.SKIN_NOT[k]) and (lk is None or e in lk)
    order = sorted(range(n), key=lambda i: (D.BODY_LINK.get(bodies[i][0].replace("pregnant ", "")) is None, kinds[i] not in D.SKIN_ONLY))
    for i in order:
        k = kinds[i]
        if k in D.PERSONA and rg.random() < 0.8:
            ko, en, e = rg.choice(D.PERSONA[k])
            if allowed(i, e): eths[i] = D.ETH_BY[e]; concepts[i] = (ko, en); used.add(e); continue
        cands = [e for e in D.ETH_BY if allowed(i, e)]
        if not cands: return None, None
        e = rg.choice(cands); eths[i] = D.ETH_BY[e]; used.add(e)
    return eths, concepts


def pick_bg(n):
    items = [b for b in D.BGL.BG.values() if not (n >= 4 and b[0] in D.BGL.NARROW)]
    w = [D.BGL.WEIGHT[b[1]] / (1 + USED["bg"][b[0]]) ** 2 for b in items]
    b = rg.choices(items, w)[0]
    return b[0], (rg.choice(D.BGL.WX) if b[5] else None)


def lighting(n, uv, outdoor, bid):
    tk = None; wxdrop = False
    if outdoor and (uv or rg.random() < 0.7): tk = "night" if uv else rg.choice(list(D.TIME)); wxdrop = True
    if tk: lk = rg.choice(D.TIME[tk][1]); tp = D.TIME[tk][0]
    else: lk = rg.choice(D.INDOOR_LIGHT if not outdoor else D.OUTDOOR_LIGHT); tp = ""
    if uv and not tk: lk = rg.choice(D.UV_LIGHT)
    if uv and tk: lk = rg.choice(["moon", "neon", "pink"])
    if bid == "pool" and rg.random() < 0.5: lk = "rim"
    return tk, tp, lk, wxdrop


def build(n, kk):
    cls = CLS[(n, kk)]
    for attempt in range(800):
        rg.rollback()
        kinds = pick_kinds(n, kk)
        bodies = pick_bodies(n)
        eths, concepts = pick_eths(kinds, bodies)
        if eths is None: continue
        arr = "side"
        if n == 2 and cls != "ballet": arr = rg.choice(list(D.ARR))
        elif n == 2: arr = "side"
        ext = any(b[0] in EXTREME for b in bodies)
        if cls == "ballet" or arr != "side": ang = "base"
        else:
            names_, ws_ = D.ANGLE_W["big" if n >= 4 else "small"]
            pr_ = [(a_, w_) for a_, w_ in zip(names_, ws_) if not (ext and a_ == "high")]
            ang = rg.choices([a_ for a_, _ in pr_], [w_ for _, w_ in pr_])[0]
        seated = False
        specs = [R.mat_spec(rg, k) for k in kinds]
        ages = [rg.choice(D.AGES) for _ in range(n)]
        # 포즈
        floor_keys = [None] * n
        if arr == "side":
            okp = [p for p in D.POSES_ALL if not (ang != "base" and ("camera" in p or "back" in p))]
            if n >= 2: okp = [p for p in okp if p not in EXC]
            poses = rg.sample(okp, n)
            if n == 1 and ext and cls != "ballet" and rg.random() < SEAT_P: poses = [rg.choice(SEAT)]; seated = True
            if cls == "ballet": poses = [D.BAL_POSE] * n
            floor_keys = [D.POSE_FLOOR.get(p) for p in poses]
        else:
            A = D.ARR[arr]; poses = list(A["roles"]) if A["roles"] else rg.sample([p for p in D.POSES_ALL if p not in EXC], n)
            floor_keys = list(D.ARR_FLOOR[arr])
        # 헤어
        hairs = []; hinfo = []
        for i in range(n):
            snake = bool(concepts[i] and concepts[i][0] == "메두사")
            h, lab = R.hair(rg, eths[i], specs[i], snake); hairs.append(h); hinfo.append(lab)
        # 장면
        bid, wx = pick_bg(n); outdoor = D.BGL.BG[bid][4]
        uv = "uvneon" in kinds
        tk, tp, lk, wxdrop = lighting(n, uv, outdoor, bid)
        if wxdrop: wx = None
        mood = rg.choice(D.MOODS)
        scene = D.BGL.BG[bid][3] + (f", {wx[1]}" if wx else "")
        if tk in ("blue", "dusk", "night"): scene = re.sub(r"\b(sunlit|sunny|bright|midday) ", "", re.sub(r" at midday\b", "", scene))
        scene = re.sub(r"\ba (?=[aeiou])", "an ", scene)
        keep = D.KEEP_LIT if (tk in ("blue", "dusk", "night") or lk in ("chiaro", "moon", "fire", "neon", "pink") or uv) else ""
        env = f"{scene}, {D.LIGHT[lk]}" + (f", {tp}" if tp else "") + f", {mood}{keep}, the whole floor and surroundings clearly visible and in focus, NO dark background NO black void, completely empty of other people, no readable signs or text anywhere, no props or statues made of the same material as " + ("her" if n == 1 else "any of them") + "."
        # 신발
        if cls == "stil": forms = [rg.choice(D.STIL) for _ in range(n)]
        elif cls == "flat": forms = [rg.choice(D.FLAT) for _ in range(n)]
        else: forms = [D.BAL_FORM] * n
        # 사람 블록
        blocks = []; infos = []; boots = []; vlist = []
        for i in range(n):
            lab = f"#{i + 1}" if n > 1 else None
            bd = bodies[i]; var = None
            if bd[0] in EXTREME:
                var = rg.choice(AB) if specs[i]["track"] == "paint" else "B"
                if var == "A": bd = a_variant(bd[0])
                else: bd = (bd[0], bd[1] + "; " + B_INS.format(edge=", her body so wide that her hips nearly touch the left and right edges of the frame" if n == 1 else ""))
            vlist.append(var)
            b, info, bt = R.person(rg, lab, kinds[i], specs[i], bd, ages[i], poses[i], eths[i], hairs[i], concepts[i], cls, forms[i], floor_keys[i])
            if var == "B" and specs[i]["track"] == "paint": b = b.replace(". Pose:", PAINT_S + ". Pose:", 1)
            blocks.append(b); infos.append(info); boots.append(bt)
        # 프레임
        endc = {"stil": "the towering heels clearly separating the soles from the floor", "flat": "the towering soles clearly lifting her far above the floor",
                "ballet": "the tip of each pointed boot clearly touching the floor"}[cls]
        if any(floor_keys) and cls != "ballet": endc = f"the towering {'soles' if cls == 'flat' else 'heels'} clearly in view"
        cam_core = f" the whole figure from the soles of the shoes to the top of her head completely visible, with the door, railing or steps beside her at normal human scale so her extreme height reads at a glance, {endc}."
        if arr != "side":
            cam = "Full-length wide shot with the camera set at platform level and pushed close so the two of them fill the frame edge to edge," + cam_core
        else: cam = D.ANGLES[ang][1] + cam_core
        A = D.ARR[arr]
        if arr == "side": head = f"Professional fashion photograph, full body shot. {D.NUM[n]} wom{'a' if n == 1 else 'e'}n {'seated' if seated else 'standing'}{' side by side' if n > 1 else ''}."
        else: head = f"Professional fashion photograph, full body shot. {A['scene']}{D.ARR_CONTACT}."
        asp = A["aspect"] if arr != "side" else D.ASPECT[n]
        fmt = "landscape" if asp in ("3:2", "5:4") else "portrait"
        zero = "zero bare skin anywhere from neck to ankle"
        if any(boots): zero = "zero bare skin anywhere from neck " + (R.BOOTEND if all(boots) else "down to the ankles or to the top edge of the boots")
        if n == 1: tail = f"Background: {env} ONE woman only. Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — {zero}."
        else:
            hip = "from hip " + (R.BOOTEND if all(boots) else "down to the ankles or to the top edge of the boots") if any(boots) else "from hip to ankle to toe"
            role = f" Arrangement: " + " and ".join(f"#{i + 1} is the {A['names'][i].lower()}" for i in range(n)) + "." if arr != "side" and A.get("names") else ""
            tail = f"Environment: {env}{role}\nAll: Extreme macro detail on every surface texture and shadow. CRITICAL: all {n} women's legs must show FULL BODY ART coverage {hip} with NO bare untattooed skin visible anywhere, every element standing in true relief, nothing flat. {D.NUM[n]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame."
        t = f"{head}\n\n" + "\n\n".join(blocks) + f"\n\n{tail} {cam} 8K {fmt} {asp} aspect ratio."
        if re.search(r"[가-힣]", t) or re.search(r"\b(\w+) \1\b", t): continue
        if t.count("Jewelry:") != n or "forty" in t or t in SEEN: continue
        rg.commit()
        return dict(t=t, n=n, cls=cls, kinds=kinds, specs=specs, eths=eths, concepts=concepts, bodies=bodies, ages=ages, poses=poses, hinfo=hinfo, infos=infos, forms=forms,
                    arr=arr, ang=ang, bid=bid, vlist=vlist, seated=seated, wx=wx, tk=tk, lk=lk, mood=mood, asp=asp)
    raise SystemExit(f"fail {n} {kk}")


out = []; seen = set(); SEEN = seen
for n in range(1, 6):
    for kk in range(1, 61):
        while True:
            r = build(n, kk)
            if r["t"] not in seen: break
        seen.add(r["t"]); t = r["t"]
        mats = " / ".join(s["name"] for s in r["specs"])
        shoeko = {"stil": "스틸레토", "flat": "일반 신발", "ballet": "발레 부츠"}[r["cls"]]
        mshort = r["mood"].split(" mood")[0]
        arrko = D.ARR[r["arr"]]["ko"] if n == 2 else ""
        title = (f"MasterMix {D.TYPEN[n].capitalize()} #{kk:02d} ({shoeko} · {D.TKO[n]}{' · ' + arrko if arrko else ''} · {mats} · 앵글 {D.ANGLES[r['ang']][0]} · 조명 {r['lk']} · 시간대 {r['tk'] or '없음'} · 분위기 {mshort} · "
                 f"체형 {', '.join(b[0] for b in r['bodies'])} · 인종 {', '.join(e[0] for e in r['eths'])} · 헤어 {', '.join(r['hinfo'])} · {' ‖ '.join(r['infos'])} · 배경 {D.BGL.BG[r['bid']][2]}{'(' + r['wx'][0] + ')' if r['wx'] else ''} · 몸 주얼리)")
        out.append({"key": f"la_mx_{D.TYPEN[n]}_{kk:02d}", "category": CAT, "title": title, "prompt": t,
                    "meta": {"group_size": n, "aspect_ratio": r["asp"], "format": "mastermix", "shoe_class": r["cls"], "kinds": r["kinds"], "materials": [s["name"] for s in r["specs"]],
                             "arrangement": r["arr"], "angle": r["ang"], "poses": r["poses"], "lighting": r["lk"], "time_of_day": r["tk"], "mood": mshort,
                             "physiques": [b[0] for b in r["bodies"]], "ethnicity": [e[0] for e in r["eths"]], "ages": r["ages"], "background": r["bid"], "weather": r["wx"][0] if r["wx"] else None,
                             "physique_variant": r["vlist"], "seated_solo": r["seated"], "concepts": [c[0] if c else None for c in r["concepts"]], "shoes": [f if isinstance(f, str) else f[0] for f in r["forms"]], "jewelry": True}})
        for i in range(n):
            use("kind", r["kinds"][i]); use("body", r["bodies"][i][0]); use("eth", r["eths"][i][0]); use("age", r["ages"][i]); use("pose", r["poses"][i]) if r["poses"][i] in D.POSES_ALL else None; use("material", r["specs"][i]["name"])
            use("shoe", r["forms"][i] if isinstance(r["forms"][i], str) else r["forms"][i][0])
        use("bg", r["bid"]); use("light", r["lk"]); use("time", r["tk"]); use("mood", r["mood"]); use("angle", r["ang"]); use("arr", r["arr"]); use("class", r["cls"])

assert len(out) == 300 and len({p["key"] for p in out}) == 300
json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
words = [len(p["prompt"].split()) for p in out]
print(len(out), "words", min(words), max(words))
# ───────── 정의 수 / 사용 수 ─────────
def row(name, defined, axis=None, vals=None):
    u = len(USED[axis]) if axis else len(set(vals))
    flag = "" if u >= defined else "  ← 일부만 사용"
    print(f"  {name:<14} 정의 {defined:>4} / 사용 {u:>4}{flag}")
print("축별 정의 수 / 실제 사용 수")
row("체형", len(D.BODIES), "body"); row("포즈", len(D.POSES_ALL), "pose"); row("나이", len(D.AGES), "age"); row("인종", len(D.ETHS), "eth")
row("재질 종류", len(D.ALL_KINDS), "kind"); row("재질 변종 합", sum(len(v) for v in {"bp": D.CRAFTS, "ir": D.IREZUMI, "uv": D.UVNEON, "wd": D.WOODS, "st": D.STONES}.values()) + sum(len(v) for v in D.NEWV.values()) + len(D.GLASS_COLORS) + len(D.LEAF) + len(D.FLOWERS) + len(D.CRYSTAL_COLORS) + 6 + 1 + len(D.WAX_COLORS), "material")
row("배경", len(D.BGL.BG), "bg"); row("조명", len(D.LIGHT), "light"); row("시간대", len(D.TIME) + 1, "time"); row("분위기", len(D.MOODS), "mood"); row("앵글", len(D.ANGLES), "angle")
row("듀오 구도", len(D.ARR), "arr"); row("신발 종류", len(set(D.STIL) | {f[0] for f in D.FLAT} | {D.BAL_FORM}), "shoe"); row("신발 클래스", 3, "class")
print("재질별 사용 수:", dict(USED["kind"]))
print("구도:", dict(USED["arr"])); print("클래스:", dict(USED["class"]))
print("체형 최소/최대 사용:", min(USED["body"].values()), max(USED["body"].values()), "| 포즈 최소:", min(USED["pose"].values()))
json.dump({k: dict(v) for k, v in USED.items()}, open(D.MD + "/usage.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
