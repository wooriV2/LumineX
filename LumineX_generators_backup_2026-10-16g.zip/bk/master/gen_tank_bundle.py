# -*- coding: utf-8 -*-
"""수조 그룹 등록 번들: 듀얼바디 전신 2~5인 + 프레임 힙컷 2~4인, 칸당 30개 = 210개 (짧은 방식)."""
import sys, re, os, json
sys.argv = ['x']
import gen_trio_mix2 as G
import gen_trio_mix as T, mdefs as D
import gen_hipframe_tank2 as G2
H = G2.H; rr = T.rr; rr.seed(int(os.environ.get('SEED', '20261011')))
G.SHORTMODE = True; G2.SHORT = True
KO = {"full": "가득", "p50": "50%", "p25": "25%", "empty": "비움"}
THIN = ["a few very thin, hairline black vertical lines, widely spaced about a hand's width apart, never thick, never bold, never dense",
        "a few very thin, hairline black horizontal lines, widely spaced about a hand's width apart, never thick, never bold, never dense",
        "a sparse grid of very thin hairline black lines in large squares, widely spaced, never thick, never bold, never dense"]
NOTE = "Every woman below is built exactly like #1 in everything not restated for her (same vessel construction, glass finish, boundary line, water behaviour, physique and pose); only her water level, water colour, contents and glass tint differ."
KEEP = ("continuous hollow", "seals shut", "directly on the floor", "flat, deliberately cut cross-section")
def dedupe(t):
    seen = set(); out = []
    for ln in t.split("\n"):
        parts = re.split(r"(?<=\.) ", ln); keep = []
        for p in parts:
            key = re.sub(r"^#\d+:? ", "", p).strip()
            if len(key) > 90 and key in seen and not any(k in key for k in KEEP): continue
            if len(key) > 90: seen.add(key)
            keep.append(p)
        out.append(" ".join(keep))
    return re.sub(r"\n{3,}", "\n\n", "\n".join(out))
G.ARMPIT = True; G.DBTYPE = 'tank'; G.DBFILL = None
G.HAIRNOTE = "Any hair hanging behind a body is plainly visible through the empty glass, and the few thin lines of the wall bend slightly as they are seen through the thin glass of every body."
indoor = [k for k, v in D.BGL.BG.items() if not v[4]][:1]
MK = []; ETH = []
_pb = T.person_bits
def pb(label, eth, age_):
    r = _pb(label, eth, age_); MK.append(r[2].replace("메이크업 ", "")); ETH.append(eth); return r
T.person_bits = pb
def levels(n):
    base = [[100, 0], [100, 50, 0], [100, 50, 25, 0], [100, 50, 25, 0]][n - 2]
    l = list(base)
    if n == 5: l.append(rr.choice([100, 50, 25]))
    rr.shuffle(l); return l
P2K = {100: "full", 50: "p50", 25: "p25", 0: "empty"}
SIZE = {2: "duo", 3: "trio", 4: "quad", 5: "quint"}; SKO = {2: "듀오", 3: "트리오", 4: "쿼르텟", 5: "퀸텟"}
CAT = "🏺 Living Artifact · Tank Body Formula"
out = []
def one(kind, n, idx):
    MK.clear(); ETH.clear()
    w = list(H.WORLDS); rr.shuffle(w); w = w[:n]; ti = rr.sample(H.TINTS, n); lv = levels(n)
    if kind == "B":
        wcn = rr.sample(G2.WATERC, n)
        t0, src, back = G2.make(n, lv, w, [x[0] for x in ti], wcn)
        t = dedupe(t0)
        if n >= 3: t = t.replace("\n\n#1:", "\n\n" + NOTE + "\n\n#1:", 1)
        mkf = lambda ttl: re.findall(r"메이크업 ([^\]·;]+)", ttl)
        mk = mkf([p for p in G2.TR[2] + G2.TR[3] if p['key'] == src][0]['title'])[:min(n, 3)] + [mkf(s2['title'])[0] for s2 in G2.EXTRA_SRC]
        assert len(mk) == n, (n, mk)
        wcs = wcn
    else:
        fl = [P2K[x] for x in lv]; wc = rr.sample(list(T.WATERS), n)
        G.SCENE_OVERRIDE = "a bright studio with a huge plain white backdrop wall marked with " + rr.choice(THIN) + ", and a pale polished floor"
        G.DBFILLS[:] = fl; G.DBTIERS[:] = [("L3", "L3")] * n; G.DBWATERS[:] = wc; G.DBTINTS[:] = [x[0] for x in ti]; G.DBWORLDS[:] = w; G.USED_MATS.clear(); G.URKINDS[:] = []
        t0, _ = G.build(["db"] * n, None, "demi", ("L3", "L3"), wc[0], indoor[0])
        t = dedupe(t0)
        if n >= 3 and "\n\n#1:" in t: t = t.replace("\n\n#1:", "\n\n" + NOTE + "\n\n#1:", 1)
        mk = list(MK); wcs = wc
    assert not re.search(r"[가-힣]", t)
    assert t.count("#1") >= 1 and f"#{n}" in t
    assert not re.search(r"\bpierc", t, re.I), "piercing"
    fills = "/".join(KO[P2K[x]] for x in lv)
    cont = "/".join(re.sub(r"\(.*?\)", "", H.WORLDS[x][0]).strip() if p else "없음" for x, p in zip(w, lv))
    asp = (re.findall(r"(\d:\d) aspect", t) or ["4:5"])[-1]
    num = f"{idx:02d}"
    key = f"la_tank_{'db' if kind=='A' else 'hip'}_{SIZE[n]}_{num}"
    kor = "듀얼바디 전신 L3" if kind == "A" else "프레임 힙컷"
    title = f"Tank {'DB' if kind=='A' else 'Hip'} {SKO[n]} #{num} ({kor} · 수조 수위 {fills} · 체형 USSBBW · 메이크업 {' / '.join(mk)} · 물색 {', '.join(wcs)} · 내용물 {cont} · 유리 {', '.join(x[1] for x in ti)})"
    meta = {"group_size": n, "aspect_ratio": asp, "format": "tank-dualbody" if kind == "A" else "tank-hipframe",
            "frame": "full" if kind == "A" else "hip", "fills": [KO[P2K[x]] for x in lv], "water_colors": list(wcs),
            "contents": [re.sub(r"\(.*?\)", "", H.WORLDS[x][0]).strip() if p else None for x, p in zip(w, lv)], "glass_tints": [x[1] for x in ti], "jewelry": bool(re.search(r"Jewelry:", t)), "piercing": False}
    out.append({"key": key, "category": CAT, "title": title, "prompt": t, "meta": meta})
for kind, ns in (("A", (2, 3, 4, 5)), ("B", (2, 3, 4))):
    for n in ns:
        for i in range(1, 31): one(kind, n, i)
json.dump(out, open('/mnt/user-data/outputs/la_tank_210_bundle.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
import collections
c = collections.defaultdict(list)
for p in out: c[p['key'].rsplit('_', 1)[0]].append(len(p['prompt'].split()))
for k, v in c.items(): print(k, len(v), min(v), sum(v) // len(v), max(v))
print(len(out)); print(out[0]['title'][:400])
