# -*- coding: utf-8 -*-
"""번호만 있던 시리즈(Core·Maximalist·Wax/Crystal 계열·Mixed·Pregnant·Mix3) 제목 개편: meta.composition 또는 프롬프트에서 항목을 뽑는다."""
import re
import retitle as R
CNT2 = {"Solo": "솔로", "Duo": "듀오", "Trio": "트리오", "Quartet": "쿼르텟", "Quintet": "퀸텟", "Sextet": "6인", "Septet": "7인", "Octet": "8인", "Nonet": "9인", "Decet": "10인"}
def head2(h):
    h = re.sub(r"\b(\d+)-Woman\b", r"\1인", h)
    for k, v in CNT2.items(): h = re.sub(rf"\b{k}\b", v, h)
    return h
def short(s, n=4): return " ".join(s.split()[:n])
def join(parts): return " · ".join(x for x in parts if x)
def core(p):
    comp = p["meta"].get("composition") or []
    rows = [c.split("/") for c in comp]
    rows = [r for r in rows if len(r) >= 3]
    pat = R.agg([short(r[2]) for r in rows])
    if len(rows) >= 6: return join([head2(p["title"]), pat])
    return join([head2(p["title"]), R.agg([r[1] for r in rows]), pat, R.agg([r[0] for r in rows])])
def mixed(p):
    comp = p["meta"].get("composition") or []
    rows = [c.split("·") for c in comp]
    rows = [r for r in rows if len(r) >= 3]
    pat = R.agg([short(r[2]) for r in rows])
    if len(rows) >= 6: return join([head2(p["title"]), pat])
    return join([head2(p["title"]), R.agg([r[1] for r in rows]), pat])
def preg(p):
    comp = p["meta"].get("composition") or []
    rows = [c.split("/") for c in comp]
    rows = [r for r in rows if len(r) >= 2]
    pat = R.agg([short(r[1]) for r in rows])
    if len(rows) >= 6: return join([head2(p["title"]), pat])
    return join([head2(p["title"]), R.agg([r[0] for r in rows]), pat])
def maxi(p):
    t = p["prompt"]
    body = R.agg([x.strip() for x in re.findall(r",\s*([A-Za-z][A-Za-z \-]*?) physique THE MOST EXTREME", t)])
    mot = R.agg([short(x) for x in re.findall(r"full body (.*?) (?:covering|flowing|clusters|growing|set directly|erupting)", t)] or [""])
    pose = ""
    if p["meta"].get("group_size", 1) == 1:
        ps = re.findall(r"Pose: ([^.\n—]*)", t); pose = R.agg([R.pose_ko(x) for x in ps]) if ps else ""
    n = p["meta"].get("group_size", 1)
    if n >= 6: return join([head2(p["title"]), mot])
    return join([head2(p["title"]), body, mot, pose])
def mix3(p):
    h = p["title"]; m = re.match(r"^(\w+) #(\d+) \((.*)\)$", h)
    n = p["meta"]["group_size"]
    return join([f"Mix3 고정조합 {n}인 #{m.group(2)}" if m else head2(h), m.group(3).replace("+", " / ") if m else ""])
FAM = {"la_core": core, "la_core_7to10": core, "la_core_11to14": core, "la_core_11to14_compact": core, "la_mixed": mixed, "la_pregnant_solo": preg,
       "la_maximalist": maxi, "la_120": maxi, "la_180": maxi, "la_fix_ire_uv": maxi, "la_330": mix3}
