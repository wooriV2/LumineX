# -*- coding: utf-8 -*-
"""LumineX 마스터 생성기 — 정의 모듈.
모든 풀(체형·포즈·헤어·나이·네일·신발·재질·메이크업·주얼리·배경 …)은 원본 정의에서만 읽는다.
이전 번들 생성기 체인(gen_matmix*, gen_shoemix*)을 상속·exec 하지 않는다.
"""
import sys, os, re, json, ast, collections

SC = "/tmp/claude-0/-home-claude/62db5eea-2487-540b-9935-a7df06448e2a/scratchpad"
ZALL = SC + "/zall"; ZG = ZALL + "/glassface"; MD = SC + "/master"
sys.path[:0] = [ZALL, ZG]
_cw = os.getcwd(); os.chdir(ZG)
import full_dicts as FD        # 헤어·나이·네일·포즈·신발·공예·비늘 원본 정의
import body_full as BF         # 체형 원본 정의
os.chdir(ZALL)
import gen_cjk_v2 as G         # 메이크업 스타일 원본 정의 (pick_makeup)
import bg_library as BGL       # 배경 라이브러리 70곳
os.chdir(_cw)


def grab(path, names):
    """파일의 최상위 대입문 중 names 에 있는 것만 순서대로 실행해서 돌려준다 (파일의 나머지 코드는 실행하지 않는다)."""
    ns = {}
    src = open(path, encoding="utf-8").read()
    for node in ast.parse(src).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id in names:
            exec(compile(ast.Module([node], []), path, "exec"), ns)
    return {k: ns[k] for k in names if k in ns}


# ───────────────── 나이 · 헤어 · 네일 ─────────────────
AGES = list(FD.AGE_EN_FULL.values())
HAIR_STYLES = list(FD.HAIR_EN_FULL.values()); HAIR_COLORS = list(FD.HAIR_COLOR_EN_FULL.values())
SIMPLE_HAIR = {"sleek straight", "wavy", "curly", "braided"}
HAIR_ART = {"high ponytail": "a high ponytail", "elegant updo": "an elegant updo", "low bun": "a low bun", "twin-tail": "twin-tails",
            "half-up, top section lifted with the length flowing loose below": "half-up with the top section lifted and the length flowing loose below"}
_PERSONA = json.load(open(MD + "/defs_persona.json", encoding="utf-8"))
HAIR_PROTECT = _PERSONA["HAIRB"]                  # 흑인 인물 보호 스타일 8종 (36-1)
NAIL_SHAPES = list(FD.NAIL_SHAPE_EN_FULL.values()) + ["coffin", "curved talon", "ballerina"]   # 6 + 3 (정의된 모양)
NAIL_SHAPES = sorted(set(NAIL_SHAPES), key=NAIL_SHAPES.index)
_WS = json.load(open(MD + "/defs_woodstone.json", encoding="utf-8"))
NAIL_LEN = _WS["NAILLEN"]

# ───────────────── 체형 ─────────────────
ENB = {"글래머아워글래스": "glamour hourglass", "머슬아워글래스BBW": "muscular hourglass BBW", "헤비머슬": "heavy muscle", "USSBBW": "USSBBW", "아워글래스SSBBW": "hourglass SSBBW",
       "파워리프터": "powerlifter", "아마조네스": "amazoness", "슈퍼글래머": "super glamour", "블랙글래머": "black glamour", "레전드바스트": "legendary bust", "커브드바스트": "curved bust",
       "브라질부티글램": "Brazilian booty glam", "폴리네시안여신": "Polynesian goddess", "누비안부티빌더": "Nubian booty builder", "글래머": "glamour", "콜로설": "colossal", "풀텀트윈즈": "full-term twins"}


def _cl(x):
    x = x.replace(" — ", ", ").replace("—", ",")
    x = re.sub(r"\.\s+([A-Z])", lambda m: "; " + m.group(1).lower(), x)
    x = re.sub(r"\s+,", ",", x); x = re.sub(r",\s*,", ",", x)
    return x.strip().rstrip(".").strip()


BODIES = [tuple(x) for x in _WS["PH0"]]           # 기본 체형 8
for k, v in BF.BODY_FULL.items(): BODIES.append((ENB[k], _cl(v)))
for dd in (BF.BODY_PREGNANT, BF.BODY_PREGNANT_MUSCLE, BF.BODY_PREGNANT_MORE):
    for k, v in dd.items(): BODIES.append(("pregnant " + ENB[k.replace("임산부", "")], _cl(v)))
BODY_LINK = {"black glamour": {"ebony", "blue-black"}, "Nubian booty builder": {"ebony", "blue-black"},
             "Polynesian goddess": {"Polynesian"}, "Brazilian booty glam": {"Latina"}}

# ───────────────── 인종 · 얼굴 · 메이크업 ─────────────────
ETHS = [tuple(e) for e in _WS["ETH"]]             # (이름, 피부, 얼굴 특징, 로컬 스타일)
ETH_BY = {e[0]: e for e in ETHS}
MAKEUP_BAD = ["blood", "wound", "fracture", "spike", "bite", "biting", "doll", "spalt", "rot", "decay", "fungus", "fungal", "worm", "safety pin", "gash", "crack"]
PALE = re.compile(r"pale|porcelain|ivory|fair|milky|white complexion|deathly|tan\b", re.I)

# ───────────────── 포즈 ─────────────────
CORE_POSES = list(FD.POSE_EN_FULL.values())
POSES_ALL = []
for p in CORE_POSES + _WS["POSES"] + _PERSONA["NEWPOSES"]:
    if p not in POSES_ALL: POSES_ALL.append(p)
FLOOR_KEY = {"한쪽무릎꿇기": "kneel1", "의자앉기": "seat", "계단에앉기": "seat", "바닥옆으로기대기": "recline", "점프동작": "jump", "양무릎꿇고정면": "kneel2"}
POSE_FLOOR = {FD.POSE_EN_FULL[k]: v for k, v in FLOOR_KEY.items()}
FLIFT = {"kneel1": "one knee resting on the floor while her raised leg lifts the towering {h} high into plain view, her legs stretched impossibly long",
         "seat": "seated with her legs stretched impossibly long and extended out in front of her so the towering {h} project into plain view",
         "recline": "reclining with her legs stretched impossibly long and extended along the floor, the towering {h} raised and clearly in view",
         "jump": "caught high in the air with her legs stretched impossibly long and the towering {h} trailing far below her",
         "kneel2": "kneeling with her legs folded beneath her and the towering {h} rising high behind her, clearly in view"}
BAL_POSE = "standing perfectly upright and tall in a pointe stance with both legs pressed together and arms relaxed at her sides, looking straight at the camera"

# ───────────────── 신발 ─────────────────
_OWN_STIL = ["thigh-high platform stiletto boots", "strappy platform stiletto sandals", "pointed platform stiletto pumps", "knee-high lace-up platform stiletto boots",
             "platform stiletto corset-lace boots", "platform stiletto knee-high boots", "platform stiletto peep-toe heels", "extreme platform square-toe heels",
             "ankle-strap platform stilettos", "extreme platform lace-up sandals", "extreme platform thigh-skimming boots", "platform stiletto ankle boots",
             "platform stiletto cross-strap sandals", "platform stiletto studded boots", "platform stiletto Mary Janes", "platform stiletto slingbacks",
             "backless platform stiletto mule pumps"]
STIL = list(_OWN_STIL)
for v in FD.SHOE_EN_FULL.values():
    if "clear" in v or v in STIL: continue
    STIL.append(v)
FLAT = [  # (신발, 밑창 문장) — 일반 신발 6종
    ("extreme platform sneakers with enormous chunky soles", "a very thick monolithic rubber sole column from the floor up to the ankle"),
    ("chunky block-heel pumps with a thick square heel", "a very tall thick square block heel and a thick hidden platform under the toes"),
    ("solid wedge-heel sandals", "one very tall solid wedge sole at the heel sloping down to a tall platform under the toes"),
    ("knee-high mega platform boots", "a very thick monolithic platform sole"),
    ("extreme chunky platform sandals", "a very thick monolithic chunky sole with a thick strap-covered platform"),
    ("extreme platform wedges", "a very tall massive wedge-shaped platform sole at the heel rising from a thick platform under the toes")]
BAL_FORM = "ballet boots with a rigid sharply pointed toe box encasing the whole foot like a ballerina's pointe shoe"
BAL_HEEL = "a razor-thin tapered heel spike attached to the back of the boot behind the ankle and angled backward, NOT touching the floor, NO platform and NO thick sole anywhere under the foot"
BAL_STANCE = "her feet arched fully vertical with the tip of each pointed toe resting directly on the floor like a dancer on pointe, her legs stretched impossibly long in one unbroken vertical line straight down to the floor"
STIL_HEEL = "a very tall razor-thin tapered heel and a hidden front platform"
NATURAL = "a natural relaxed stance with her weight settled on her feet"
LEATHER = ["glossy patent leather", "smooth polished leather", "high-shine leather", "satin-finish leather"]
JEWEL_BODY = grab(ZALL + "/gen_woodstone_trio2.py", {"JW"})["JW"]      # 몸 주얼리 9종 (얼굴·귀 없음)

# ───────────────── 재질 ─────────────────
NEWV = grab(ZALL + "/gen_matmix_bundle.py", {"V", "NEWV"})["NEWV"]     # 옥·도자기·청동·옻칠·호박·산호 (각 3~4 변종)
WOODS = [tuple(x) for x in _WS["WOODS"]]; STONES = [tuple(x) for x in _WS["STONES"]]
PAT = _WS["PAT"]                                                         # 고체 재질 표면 문양
_B = grab(ZALL + "/glassface/gen_blend_540.py", {"CRYSTAL_COLORS", "GLASS_COLORS", "WAX_COLORS", "FLOWERS", "PEACOCK"})
CRYSTAL_COLORS, GLASS_COLORS, WAX_COLORS, FLOWERS, PEACOCK = (_B[k] for k in ("CRYSTAL_COLORS", "GLASS_COLORS", "WAX_COLORS", "FLOWERS", "PEACOCK"))
LEAF = list(grab(ZG + "/gen_goldleaf_test.py", {"LEAF"})["LEAF"].keys())  # 금박 색 10종
SCALE_DB = FD.SCALE_ANIMAL_DB                                            # 비늘 동물 5종
_src = open(ZG + "/gen_fix_ire_uv_6to10.py", encoding="utf-8").read(); _ns = {}
exec(re.search(r"IREZUMI_FULL = \[.*?\n\]\n", _src, re.S).group(0), _ns); exec(re.search(r"UV_FULL = \[.*?\n\]\n", _src, re.S).group(0), _ns)
IREZUMI, UVNEON = _ns["IREZUMI_FULL"], _ns["UV_FULL"]
CRAFTS = FD.CRAFT_DB_FULL                                                # 바디페인팅 전통 공예 41종
PAINT_SHOES = [v for v in FD.SHOE_EN_FULL.values() if "clear" not in v]

KO = {"bodypaint": "바디페인팅", "irezumi": "이레즈미", "uvneon": "UV네온", "wood": "목재", "stone": "석재", "jade": "옥", "porcelain": "도자기", "bronze": "청동",
      "lacquer": "옻칠", "amber": "호박", "coral": "산호·조개", "glass": "스테인드글라스", "goldleaf": "금박", "botanical": "보태니컬", "crystal": "크리스탈",
      "scale": "비늘", "obsidian": "흑요암금", "wax": "왁스"}
ALL_KINDS = list(KO)
# 조건(원본 핸드오프 기준): 금박은 검은 피부(맥시멀리스트 틀)에서만 · 왁스/흑요암은 블루블랙 피부 틀 · UV네온은 브론즈 피부에서 실패
SKIN_ONLY = {"goldleaf": {"blue-black", "ebony"}, "wax": {"blue-black", "ebony"}, "obsidian": {"blue-black", "ebony"}}
SKIN_NOT = {"uvneon": {"Polynesian"}}
PERSONA = {k: [tuple(x) for x in v] for k, v in _PERSONA["P"].items()}  # 재질별 신화 컨셉 (36장)
SNAKE = "a mass of dozens of thick coiling snakes carved from the same {m}, each snake with a detailed head, open eyes and a flicking tongue, writhing around her head and falling down her back, the snakes are her hair"

# ───────────────── 장면 · 카메라 · 조명 ─────────────────
LIGHT = {"golden": "golden hour warm backlight, skin luminosity, glowing", "octa": "professional octabox strobe, high-contrast glamour lighting",
         "neon": "multi-colored neon edge glow, cyberpunk light", "chiaro": "dramatic chiaroscuro, deep shadows and sharp highlights",
         "beauty": "soft beauty dish light, even flattering illumination", "hard": "harsh direct strobe, body muscle definition emphasis",
         "fog": "volumetric fog cinematic light, atmospheric mood", "rim": "strong rim backlight, silhouette definition, halo effect",
         "moon": "moonlight, silvery blue natural light, mysterious outdoor glow", "pink": "pink neon accent light, rose-toned atmospheric glow, fashion editorial lighting",
         "fire": "firelight, warm flickering flames, dramatic orange glow", "sun": "harsh direct sunlight, strong sharp shadows, high contrast"}
TIME = {"blue": ("blue hour just before dawn, mystical pre-sunrise light, cool blue atmospheric glow", ["rim", "fog", "moon"]),
        "morning": ("morning golden hour, soft warm early sunlight, fresh dewy atmosphere", ["golden", "rim", "fog"]),
        "noon": ("midday harsh sunlight, strong direct light, sharp shadows, high contrast", ["sun"]),
        "afternoon": ("late afternoon warm sunlight, relaxed golden atmosphere, soft shadows", ["golden", "rim"]),
        "dusk": ("dusk twilight, dramatic sunset colors, sky ablaze with color", ["rim", "golden", "fire"]),
        "night": ("deep midnight, a dark sky overhead, mysterious nocturnal atmosphere", ["moon", "neon", "pink", "fire"])}
MOODS = ["dark glamour mood, intense dramatic atmosphere, powerful editorial energy", "dreamy ethereal mood, soft romantic atmosphere, fantasy editorial",
         "high fashion editorial mood, cold sophisticated atmosphere, sharp luxury", "bohemian free-spirited mood, natural earthy atmosphere, artistic editorial",
         "retro pin-up mood, vintage glamour atmosphere, classic playful editorial", "cyberpunk glamour mood, futuristic neon atmosphere, dystopian editorial",
         "romantic mood, soft warm atmosphere, tender feminine editorial", "powerful commanding mood, intense dominant atmosphere, fierce editorial",
         "mysterious alluring mood, enigmatic atmosphere, captivating editorial", "luxury opulent mood, sophisticated elegant atmosphere, high-end editorial",
         "playful vibrant mood, energetic joyful atmosphere, fresh editorial", "serene tranquil mood, peaceful calm atmosphere, meditative editorial"]
INDOOR_LIGHT = ["octa", "beauty", "chiaro", "hard", "neon", "pink", "rim", "fire"]
OUTDOOR_LIGHT = ["golden", "rim", "fog", "beauty", "sun"]
UV_LIGHT = ["neon", "pink", "chiaro"]
ANGLES = {"base": ("기본(허리 높이)", "Full-length wide shot from a moderate distance with the camera at waist height,"),
          "high": ("하이앵글 70도", "Full-length steep high-angle shot taken from far above with a long telephoto lens, the camera directly above and in front of her angled roughly seventy degrees downward as if from a high ceiling or drone, flat telephoto compression with natural proportions and no wide-angle distortion, the whole figure from head to boots fully visible,"),
          "side": ("측면", "Full-length side view with the camera at waist height, her body in clean profile,"),
          "low": ("극단 로우앵글", "Full-length EXTREME worm's-eye view shot with the camera placed on the floor at foot level and tilted steeply upward, the soles and heels huge in the foreground, her legs rising in exaggerated perspective and her head far above at the top of the frame,"),
          "tq": ("극단 3/4 앵글", "Full-length EXTREME three-quarter view from the far front-left, her whole body turned a full sixty degrees away from the camera with her shoulders and hips twisted, the camera at waist height and pushed close for strong foreshortening,")}
ANGLE_W = {"small": (["base", "high", "low", "side", "tq"], [38, 20, 15, 15, 12]), "big": (["base", "high", "side"], [55, 30, 15])}
CAM_TAIL = " the whole figure from the soles of the shoes to the top of her head completely visible, with the door, railing or steps beside her at normal human scale so her extreme height reads at a glance."
KEEP_LIT = ", every person's whole figure from the shoes to the top of her head clearly lit and fully visible with every material detail sharp"

# ───────────────── 구성(그룹) ─────────────────
NUM = {1: "ONE", 2: "TWO", 3: "THREE", 4: "FOUR", 5: "FIVE"}
ASPECT = {1: "2:3", 2: "3:4", 3: "4:5", 4: "4:5", 5: "5:4"}
TYPEN = {1: "solo", 2: "duo", 3: "trio", 4: "quartet", 5: "quintet"}; TKO = {1: "솔로", 2: "듀오", 3: "트리오", 4: "4인", 5: "5인"}
# 실사 듀오 자세 8종 (핸드오프 8-2) — 인물별 자세 문장 + 장면 문장 + 프레임
ARR = {
    "side": dict(ko="나란히 서기", aspect="3:4", scene="TWO women standing side by side", roles=None),
    "stand_pair": dict(ko="나란히 정면 서기", aspect="2:3",
                       scene="TWO women standing side by side, pressed shoulder to shoulder with their sides squeezed against each other",
                       roles=["standing square to the camera with her feet planted far apart", "standing square to the camera with her feet planted far apart"], names=["Left woman", "Right woman"]),
    "stand_mixed": dict(ko="정면 + 3/4 서기", aspect="2:3",
                        scene="TWO women standing side by side, their sides pressed against each other",
                        roles=["standing square to the camera", "turned about 45 degrees toward the first woman with the front of her body still mostly toward the lens"], names=["Left woman, square to the camera", "Right woman, turned 45 degrees"]),
    "bench_pair": dict(ko="둘 다 걸터앉기", aspect="2:3",
                       scene="TWO women seated side by side on one short backless bench carved from a solid block of pale grey stone, just long enough for the two of them and no longer, set in the scene",
                       roles=["seated with her knees apart and her feet flat on the floor", "seated with her knees apart and her feet flat on the floor"], names=["Left woman", "Right woman"]),
    "recline_pair": dict(ko="나란히 기대기", aspect="3:2",
                         scene="TWO women reclining side by side against the same padded backrest on a low platform set in the scene",
                         roles=["propped at about 45 degrees against the backrest with her legs stretched out in front of her", "propped at about 45 degrees against the backrest with her legs stretched out in front of her"], names=["Left woman", "Right woman"]),
    "recline_sit": dict(ko="기대기 + 걸터앉기", aspect="3:2",
                        scene="TWO women on a low platform with a padded backrest at its left end and a short stone bench at its right end, set in the scene",
                        roles=["reclining against the backrest at the left of the frame with her legs stretched out toward the right", "sitting upright on the stone bench at the right of the frame, rising to fill the full height of the picture"],
                        names=["Reclining woman at the left", "Seated woman at the right"]),
    "lie_recline": dict(ko="눕기 + 기대기", aspect="3:2",
                        scene="TWO women on a low platform with a padded backrest at its right end, set in the scene, lying head to toe in opposite directions",
                        roles=["reclining against the backrest at the right with her head at the right edge and rising to fill the full height of the picture", "lying on her side along the front of the platform with her head at the left edge and her legs stretching back beneath the reclining woman's raised torso"],
                        names=["Reclining woman, head at the right", "Lying woman, head at the left"]),
    "lie_bench": dict(ko="눕기 + 걸터앉기", aspect="3:2",
                      scene="TWO women with one short backless stone bench just long enough for the two of them and no longer, set in the scene",
                      roles=["lying on her side along the near length of the stone with her head at the left edge", "sitting upright on the right end of the same bench with her hips overhanging the narrow stone on both sides, rising to fill the full height of the picture"],
                      names=["Lying woman, head at the left", "Seated woman at the right"]),
    "lie_pair": dict(ko="둘 다 눕기", aspect="3:2",
                     scene="TWO women lying on one low flat platform set in the scene, on their sides one behind the other and both facing the camera but head to toe in opposite directions",
                     roles=["lying on her side with her head at the left edge", "lying on her side with her head at the right edge, her shoulders behind the nearer woman's legs"], names=["Nearer woman, head at the left", "Farther woman, head at the right"]),
}
ARR_FLOOR = {"bench_pair": ("seat", "seat"), "recline_pair": ("recline", "recline"), "recline_sit": ("recline", "seat"), "lie_recline": ("recline", "recline"),
             "lie_bench": ("recline", "seat"), "lie_pair": ("recline", "recline"), "stand_pair": (None, None), "stand_mixed": (None, None)}
ARR_CONTACT = ", their hips and sides pressed against each other and the flesh bulging out where they touch"
