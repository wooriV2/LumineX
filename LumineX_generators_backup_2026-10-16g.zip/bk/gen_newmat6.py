# -*- coding: utf-8 -*-
# 새 재질 6종(옥·도자기·청동 녹청·옻칠·호박 수지·산호·진주조개) 솔로 시험 — v2 틀(부피 큰 체형·메이크업만·몸 주얼리·40인치 힐·밝은 배경)
import re, random
src = open("gen_woodstone_full10.py", encoding="utf-8").read()
exec(src[:src.index("PLAN = [")])
exec(open("gen_woodstone2_600.py", encoding="utf-8").read().split("TYPEN =")[0].split("exec(src[:src.index(\"sel = []\")])")[1].split("\n",1)[1].split("O = ")[0]) if False else None
# 주얼리 모듈(v2에서 쓰는 것) 가져오기
s2 = open("gen_woodstone_trio2.py", encoding="utf-8").read()
ns2 = {}
exec(s2[:s2.index("sel = []")], ns2)
JR = ns2["JR"]; person_v2 = ns2["person"]; build_v2 = ns2["build"]
# v2 build/person 을 그대로 쓰되 재질 문장만 갈아끼운다
NEW = {
 "jade": ("jade", "polished carved imperial jade", "jade", "jade",
          "BLAZING deep imperial-green jade surface across the full torso both legs neck to ankle", "VIVID pale celadon veins and creamy white cloud-like flecks running between the sections", "high-gloss polished"),
 "porcelain": ("porcelain", "glazed blue-and-white porcelain", "glazed porcelain", "porcelain",
          "BLAZING glossy white glaze painted with cobalt-blue dragons, clouds and waves across the full torso both legs neck to ankle", "VIVID deep cobalt-blue borders and fine crackle lines running between the sections", "high-gloss glazed"),
 "bronze": ("bronze", "aged ancient bronze", "cast bronze", "bronze",
          "BLAZING warm copper-gold bronze metal across the full torso both legs neck to ankle", "VIVID turquoise-green verdigris patina gathering in every recess and joint", "satin-polished raised edges"),
 "lacquer": ("lacquer", "glossy urushi lacquer", "lacquered", "lacquer",
          "BLAZING deep vermilion-red urushi lacquer across the full torso both legs neck to ankle", "VIVID jet-black lacquer panels with fine gold maki-e flowers and cranes between the sections", "mirror-gloss lacquered"),
 "amber": ("amber", "polished honey amber resin", "amber resin", "amber",
          "BLAZING warm honey-orange amber surface across the full torso both legs neck to ankle", "VIVID deeper red-brown swirls and tiny golden bubbles flowing through every section", "high-gloss polished"),
 "coral": ("coral", "carved pink coral and iridescent mother-of-pearl", "coral and shell", "coral and mother-of-pearl",
          "BLAZING coral-pink branching coral relief across the full torso both legs neck to ankle", "VIVID iridescent pearl-white nacre sections shimmering pink, green and violet between the coral", "high-gloss polished"),
}
def person_new(label, key, phys, age, pose, eth):
    nm, desc, solid, nmw, base, acc, fin = NEW[key]; pn, pd = phys; p = f"{label}: " if label else ""
    pat = rr.choice(PAT)
    mat = (f"full body {desc} fused directly to her own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, this is solid {solid} curving to follow her body's true three-dimensional shape, divided into dozens of fitted {nm} sections, each joint standing in a thin raised ridge catching its own bright glint and casting its own small shadow, nothing lying flat. Dense fitted sections — {base}, {acc}, with {pat}, {fin}, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
    feat, seg, info = face(eth); skin = eth[1]
    shoe = f"{p}Footwear: heels of the most absurdly extreme height imaginable, {rr.choice(FORM)} made of the same {nmw}, each with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform, {BODYLIFT}."
    nails = f"{p}Nails: the longest nails physically imaginable, {rr.choice(NAILSHAPE)} nails each {rr.choice(NAILLEN)}, made of the same {nmw} with a high polish."
    fc = f"{p}Face: her face and ears are NOT {nm} — they are real living flesh with real pores, a soft sheen of natural oils and bright real catchlights, {feat}, an unmistakably feminine face with a calm, composed expression, makeup: {seg}."
    body = f"{p}{skin}, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair()} — {mat}. Pose: {pose} — most extreme {pn} silhouette ever displayed."
    jw = f"{p}Jewelry: {ns2['jewel'](p)}"
    return "\n".join([body, shoe, nails, jw, fc]), info
SETLIST = SETS
ETHS = {k: next(e for e in ETH if e[0] == v) for k, v in [("jade", "Korean"), ("porcelain", "Latina"), ("bronze", "Indian"), ("lacquer", "Middle Eastern"), ("amber", "Polynesian"), ("coral", "Chinese")]}
PHS = {"jade": ns["PH0"][0], "porcelain": ns["PH0"][2], "bronze": ns["PH0"][4], "lacquer": ns["PH0"][5] if len(ns["PH0"]) > 5 else ns["PH0"][0], "amber": ns["PH0"][2], "coral": ns["PH0"][6]}
o = ["# 새 재질 6종 솔로 시험 — 옥 · 도자기 · 청동 · 옻칠 · 호박 수지 · 산호/진주조개 (6개)\n",
     "v2 틀(부피 큰 체형, 얼굴은 살색+메이크업만, 몸 주얼리, 40인치 힐, 밝은 배경)을 그대로 쓰고 재질 문장만 바꿨습니다. 번호별로 정상/이상만 알려주세요. 이상이면 어떤 점인지 한 줄(예: 몸이 재질로 안 덮임, 얼굴도 재질이 됨, 재질 무늬가 안 나옴)만 알려주세요.\n"]
for i, key in enumerate(NEW, 1):
    JR.seed(rr.randrange(10**9))
    for attempt in range(200):
        eth = ETHS[key]; phys = PHS[key]; si = rr.randrange(8)
        t, info = person_new(None, key, phys, rr.choice(AGES), rr.choice(POSES), eth)
        # 주얼리·배경·카메라는 v2 build 로직을 재사용
        full, infos = build_v2(["wood"], [("x","x","x","x")], [phys], [rr.choice(AGES)], [rr.choice(POSES)], [eth], SETS[si]) if False else (None, None)
        break
    # build_v2 는 wood/stone 분기라 직접 조립
    env = f"{SETS[si]}, bright and evenly lit, shadows soft, the whole floor and surroundings clearly visible and in focus, NO dark background NO black void."
    tail = f"Background: {env} ONE woman only. Extreme macro detail on every surface texture and shadow. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle."
    body = t
    prompt = f"Professional fashion photograph, full body shot. ONE woman standing.\n\n{body}\n\n{tail}{CAM} 8K portrait {ASP[1]} aspect ratio."
    assert not re.search(r"[가-힣]", prompt) and not re.search(r"\b(\w+) \1\b", prompt), re.findall(r"\b(\w+) \1\b", prompt)
    o.append(f"## {i}. {key} 솔로 · 체형 {phys[0]} · 인종 {eth[0]} · {info} · 배경 {SETKO[si]} · 힐 40인치\n\n```\n{prompt}\n```\n"); print(i, key, len(prompt.split()))
open(O + "LumineX_NewMaterials6.md", "w", encoding="utf-8").write("\n".join(o))
