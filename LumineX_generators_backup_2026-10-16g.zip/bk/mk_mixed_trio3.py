# -*- coding: utf-8 -*-
# 여성 바디페인팅 정면 비교 샘플 4개 (부피 큰 체형 2 + 근육질 2) — 남성 정면 실패 대조용
import re, sys
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity"); sys.path.insert(0, "../../master")
_g = open("gen_pierce_statue.py", encoding="utf-8").read()
exec(_g[:_g.index("def build(")])
import mdefs as D
exec(open("../../bk/newbody_defs.py", encoding="utf-8").read(), globals())
_src = open("../../bk/mk_statue_obj11.py", encoding="utf-8").read()
exec(_src[_src.index("rnd.seed("):_src.index("LABEL = ['Physique']")])      # KO 등
rnd.seed(20261049)
sys.path.insert(0, '../../bk')
import bg_library as _BG
OUTD = [b[0] for b in _BG.B if b[4]]
POOL = {b[0]: b[1] for b in D.BODIES}; POOL.update({nm: desc for nm, ko, kod, desc in NB})
_NBd = POOL["Nubian booty builder"]
POOL["Nubian bust builder"] = _NBd.replace("wide flaring lats", "a full, heavy, firm bust standing out on her chest").replace("a deeply carved abdomen with sharp obliques", "a deeply carved six-pack abdomen with sharp obliques")
POSES = {"s_curve": "standing facing the camera in a graceful S-curve, her left hand resting on her flared hip and her right hand lifting her hair away from her neck",
         "walk": "walking toward the camera with a slow swaying runway stride, one hand brushing her hair back",
         "over_shoulder": "standing in three-quarter view with her weight on one leg, one hand on her flared hip, looking back over her shoulder at the camera",
         "crossed": "standing facing the camera with one leg crossed in front of the other, both hands resting on her hips, her head tilted slightly",
         "wide": "standing in a wide confident stance facing the camera, both hands resting on her flared hips, her chin lifted"}
SHOES = ["Extreme gold ballet heels", "Extreme black patent stiletto pumps", "Extreme silver platform sandals", "Extreme red lacquer platform pumps"]
NAILS = ["Long square nails, glossy finish.", "Long almond nails, chrome finish.", "Long coffin nails, deep burgundy.", "Long stiletto nails, glossy black."]
BG = ["plain seamless deep-charcoal", "plain seamless mid-grey", "plain seamless deep-navy"]
NATSM = [("Korean", "smooth fair skin with a warm undertone"), ("Korean", "luminous porcelain skin"), ("Chinese", "smooth fair skin with a neutral undertone"), ("Chinese", "light skin with a warm golden undertone"), ("Japanese", "smooth pale skin with a cool undertone"), ("Japanese", "smooth fair skin with a neutral undertone")]
FACEM = ["a rugged masculine face with a strong square jaw, heavy straight brows and prominent cheekbones", "a chiseled masculine face with a broad jaw, deep-set eyes and a strong brow ridge", "a mature masculine face with a squared chin, a strong nose and a thick neck", "a hard-edged masculine face with a wide jaw, thick brows and a defined Adam's apple"]
MKUM = [""]
BEARDM = ["light stubble", "a short neatly trimmed beard", "a short trimmed beard and moustache", "a dark five-o'clock shadow"]
NATHC = [i for i, h in enumerate(HC) if h[:4] in ("HCJB", "HCNB", "HCDB", "HCCB", "HCAB")]
HKM = ["HSS스트레이트", "HSW웨이브", "HSSK슬릭백", "HSSH샤기컷"]
AGESM = ["in his late 20s", "in his early 30s", "in his mid 30s", "in his late 30s"]
import full_dicts as _F
SHOECOL = ["gold", "black", "red", "silver", "white", "cobalt-blue", "hot-pink"]
def craft(c):
    cn, cd, cb, cf = CRAFT_DB_FULL[c]
    return f"{cn} ({cd}), wide {cb} bands following every deep crease and curving around the hips and thighs like contour lines, dense {cf} filling the space between every band", cn

JMETAL_EN = {"JMG":"gold","JMS":"silver","JMR":"rose-gold","JMP":"platinum","JMX":"mixed-metal"}
JSING = {"JE":"earring","JN":"necklace","JB":"bracelet","JR":"ring","JA":"anklet","JH":"hair ornament"}
JTYPE_EN = {"JE":"earrings","JN":"necklaces","JB":"bracelets","JR":"rings","JA":"anklets","JH":"hair ornaments"}
JQ_SHORT = {"JQ1":"a single {m} {s}","JQ2":"two to three {m} {p}","JQ3":"four to six layered {m} {p}","JQ4":"seven to ten heavily stacked {m} {p}","JQ5":"an extreme maximalist stack of well over ten {m} {p}"}
LAB = ["LEFT", "CENTER", "RIGHT"]

BODIES = {
 "V자 보디빌더": "An extraordinarily large and powerful man, far beyond any real person. A massive V-shaped torso: enormously broad shoulders with capped, rounded deltoids, a thick heavy chest, a deeply carved six-pack abdomen narrowing to a comparatively small waist, huge thick arms with split biceps and horseshoe triceps, wide flaring lats, and powerful thick quads and diamond calves. His head stays in correct proportion to his broad frame.",
 "린 애슬레틱": "A tall, lean, athletic man built like a swimmer. Broad shoulders tapering cleanly to a narrow waist, a defined chest, a visible eight-pack abdomen with sharp obliques, long strong arms with clear vein definition, and long lean muscular legs with defined calves. Nothing bulky, everything taut and sculpted.",
 "키 큰 슬렌더": "A very tall, slim, long-limbed man with a runway build. Straight shoulders, a flat lean chest, a flat defined stomach, slender strong arms and very long legs, lightly muscled and elegant, with visible collarbones and a narrow waist. His head stays in correct proportion to his long frame.",
 "파워리프터": "A thick, heavy, extremely strong man built like a powerlifter. A huge barrel chest, enormously wide shoulders and back, a thick solid waist with a firm rounded belly over strong abs, massive arms, and enormous thick thighs and calves. Every part is large, dense and continuous rather than sharply cut.",
 "대형 헤비": "A giant, big-bellied man with great natural size throughout. Broad powerful shoulders, a wide heavy chest, a large round soft belly hanging over a thick waist, thick strong arms, and wide heavy thighs beneath. Every curve is large, solid and continuous, with a warm, imposing bearing.",
 "클래식 머슬": "A classically muscular athletic man in the shape of a Greek statue. Wide shoulders, a full defined chest, a clean six-pack abdomen, strong rounded arms, and muscular thighs and calves, balanced and proportionate from head to toe, powerful but not exaggerated.",
 "스트롱맨": "A massive, stocky strongman. A thick short neck, huge round shoulders, an enormously deep chest, a thick powerful midsection with a solid belly, tree-trunk arms, and huge thick legs planted wide. Heavy, dense and immovable, every part solid.",
 "중년 실버 아스레틱": "A fit mature man in his late 40s with an athletic, well-kept build. Broad shoulders, a firm defined chest, a flat strong abdomen with visible lines, strong forearms, and lean strong legs, with the quiet, assured bearing of a man who has trained for decades.",
}
NATS = [("Korean", "smooth fair skin with a warm undertone"), ("Korean", "luminous porcelain skin"), ("Chinese", "smooth fair skin with a neutral undertone"), ("Chinese", "light skin with a warm golden undertone"), ("Japanese", "smooth pale skin with a cool undertone"), ("Japanese", "smooth fair skin with a neutral undertone")]
FACE = ["a refined idol face with a clean sharp jawline and long defined eyes", "a handsome model face with high cheekbones and a straight nose", "a soft-featured idol face with large clear eyes and a defined jaw", "a striking model face with sharp brows and a narrow chin"]
BEARD = ["clean-shaven", "clean-shaven", "clean-shaven", "a very faint trace of stubble"]
MKU = [("natural idol makeup with soft brown eyeshadow and a tinted lip", "아이돌 내추럴 메이크업"), ("light smoky eyeliner and glossy skin", "라이트 스모키"), ("glass-skin makeup with a faint shimmer on the cheekbones", "글래스 스킨"), ("", "메이크업 없음")]
MOOD = ["calm and cool", "intense and focused", "composed and elegant", "relaxed with a faint half-smile", "fierce and charismatic"]
HK = ["HSS스트레이트", "HSW웨이브", "HSSK슬릭백", "HSSH샤기컷", "HSWF울프컷", "HSPX픽시컷", "HSTN탑노트"]
AGES = ["in his early 20s", "in his mid 20s", "in his late 20s", "in his early 30s", "in his mid 30s"]
NAILS = ["Short, clean nails with a matte black polish.", "Short natural nails.", "Short nails with a glossy dark-grey polish.", "Short nails with a metallic gold polish."]

MNATS_NAILS = ["Short, clean nails with a matte black polish.", "Short natural nails.", "Short nails with a glossy dark-grey polish.", "Short nails with a metallic gold polish."]
MPOSES = {"contra": "standing facing the camera with his weight on one leg, one hand resting on his hip and the other hand running through his hair",
          "wide": "standing in a wide power stance facing the camera, both hands resting on his hips, chin lifted",
          "over_shoulder": "standing in three-quarter back view with his hands on his hips, looking back over his shoulder at the camera"}
NONPLAT2 = ["순수스틸레토펌프스", "발레힐", "니들힐", "싸이하이스틸레토부츠", "스컬프처럴힐", "앵클스트랩스틸레토"]
def shoe(ko, lab):
    en = re.sub(r'^extreme ', '', _F.SHOE_EN_FULL[ko]); col = rnd.choice(SHOECOL)
    return f"{lab} Footwear: Extreme {col} {en} with a razor-thin tapered heel a full forty inches tall and a twelve-inch hidden front platform."
def person(i, kind, bkey, PK, sk):
    lab = LAB[i]
    c = rnd.choice(T.CRAFTS_39); ct, cn = craft(c)
    _q = rnd.choice(list(JQ_SHORT)); _m = JMETAL_EN[rnd.choice(list(JMETAL_EN))]; _t = rnd.choice(list(JTYPE_EN))
    jw = JQ_SHORT[_q].format(m=_m, s=JSING[_t], p=JTYPE_EN[_t])
    ART = ("{lab} Body Art: {P} bare skin is painted in {ct}. The paint is pigment sitting on living skin, so it distorts slightly over every {bump}. The paint covers {p} whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of {p} hands, sides, back, rear, lower belly, knees, calves and the tops of {p} feet. {P} face is left unpainted and the pattern fades out at the neck with no hard line.")
    extra = ""
    if kind == "F":
        mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC) + 1)
        hair = f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}"
        t1 = f"{lab}: ONE real adult {nat} woman, her face exactly the same tone as her body, real skin texture with visible pores and fine grain, {fa}, {hair}, real living eyes, wearing {jw}. {rnd.choice(NAILS)}"
        ph = f"{lab} Physique: {POOL[bkey]} Her arms, hands, legs and feet stay in correct proportion to each other."
        art = ART.format(lab=lab, P="Her", p="her", ct=ct, bump="bulge")
        pose = f"{lab} Pose: {POSES[PK]}."; tag = f"여성 {KO.get(bkey, bkey)}·메이크업 {mk}"
    elif kind == "MF":
        natm, skinm = rnd.choice(NATSM); agem = rnd.choice(AGESM)
        hairm = f"{HAIR_COLOR_EN_FULL[HC[rnd.choice(NATHC)]]} hair styled in {HAIR_EN_FULL[rnd.choice(HKM)]}"
        t1 = f"{lab}: ONE real adult {natm} person with a handsome man's face on a full, curvaceous female body — a man {agem}, his face exactly the same tone as his body, real skin texture with visible pores and fine grain, {rnd.choice(FACEM)}, {rnd.choice(BEARDM)}, {skinm}, {hairm}, real living eyes, wearing {jw}. {rnd.choice(NAILS)}"
        ph = f"{lab} Physique: {POOL[bkey]} Her arms, hands, legs and feet stay in correct proportion to each other."
        art = ART.format(lab=lab, P="Her", p="her", ct=ct, bump="bulge")
        pose = f"{lab} Pose: {POSES[PK]}."; tag = f"남성얼굴·여성체형 {KO.get(bkey, bkey)}"
    else:
        natm, skinm = rnd.choice(NATSM); agem = rnd.choice(AGESM)
        hairm = f"{HAIR_COLOR_EN_FULL[HC[rnd.choice(NATHC)]]} hair styled in {HAIR_EN_FULL[rnd.choice(HKM)]}"
        t1 = f"{lab}: ONE real adult {natm} man {agem}, his face exactly the same tone as his body, real skin texture with visible pores and fine grain, {rnd.choice(FACEM)}, {rnd.choice(BEARDM)}, {skinm}, {hairm}, real living eyes, wearing {jw}. {rnd.choice(MNATS_NAILS)}"
        ph = f"{lab} Physique: {BODIES[bkey]} His arms, hands, legs and feet stay in correct proportion to each other."
        art = ART.format(lab=lab, P="His", p="his", ct=ct, bump="muscle and bulge")
        pose = f"{lab} Pose: {MPOSES[PK]}."; tag = f"남성 {bkey}"
    return "\n".join([t1, ph, art, pose, shoe(sk, lab)]), f"{tag}({cn})"
def build(plan):
    _bid = rnd.choice(OUTD); BGD = _BG.desc(_bid); BGK = [b[2] for b in _BG.B if b[0] == _bid][0]
    BGD = BGD.replace("completely empty of other people", "empty of any people other than the subjects").replace("made of the same material as her", "made of the same material as them")
    blocks, tags = [], []
    for i, (kind, bkey, pk, sk) in enumerate(plan):
        t, tg = person(i, kind, bkey, pk, sk); blocks.append(t); tags.append(tg)
    p = ("Image format: a horizontal landscape-orientation photograph, 3:2 aspect ratio, wider than it is tall.\n\n"
         f"A full-body photograph in {BGD}, THREE people standing side by side with generous spacing so every figure reads clearly and nobody's arms cross a neighbour, the camera set back so all of them are visible from head to toe, shot on a medium format camera with an 85mm lens at f/8, in natural sunlight, sharp focus on every figure, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n"
         + "\n\n".join(blocks) + "\n\n"
         "Skin (everyone): Real photographic skin — visible pores and fine grain, a taut surface with natural creases and shadow only where the flesh and muscle fold. No smooth illustration finish, no plastic CG sheen.\n\n"
         "Background & Lighting: each painted pattern catching the sunlight in sharp glints, the sunlight carving every fold, curve and muscle. Horizontal 3:2 full-body photograph, all faces toward the camera.")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), re.findall(r"\b(\w+) \1\b", p)
    return p, " / ".join(tags), BGK
PLANS = [[("F","legendary bust","s_curve","싸이하이스틸레토부츠"),("MF","siren bust hourglass","over_shoulder","싸이하이스틸레토부츠"),("M","V자 보디빌더","wide","싸이하이스틸레토부츠")],
         [("M","클래식 머슬","contra","순수스틸레토펌프스"),("F","hourglass bombshell","wide","순수스틸레토펌프스"),("MF","glamour hourglass","crossed","순수스틸레토펌프스")],
         [("MF","curved bust","s_curve","니들힐"),("M","린 애슬레틱","over_shoulder","니들힐"),("F","siren bust hourglass","crossed","니들힐")]]
L = ["# LumineX — 혼합 트리오 3종 (여성 / 남성얼굴·여성체형 / 남성체형, 전원 바디페인팅, 40인치 여성 신발)\n", "한 화면에 세 명: 여성 + 여성 체형·남성 얼굴 + 남성이 함께 있고, 모두 서로 다른 패턴·주얼리입니다. 번호별로 성공/실패만 알려주세요(실패는 한 줄 이유만).\n"]
for n, plan in enumerate(PLANS, 1):
    p, d, bk = build(plan); L.append(f"## {n}. 트리오 · {d} · 배경 {bk}\n\n```\n{p}\n```\n"); print(n, d, bk, len(p.split()))
open("/mnt/user-data/outputs/LumineX_BodyPaint_MixedTrio3_40in.md", "w", encoding="utf-8").write("\n".join(L))
