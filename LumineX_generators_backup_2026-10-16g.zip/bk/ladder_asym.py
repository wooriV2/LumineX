import sys,re,random,copy
sys.path.insert(0,'.')
import cjk_face_lib as C
import gen_cjk_v2 as G
for x in [f for f in G.F if f["meta"]["piercing"]=="P150"]:
    y=copy.deepcopy(x); y["meta"]["piercing"]="P200"; p=y["prompt"]
    p=p.replace("about one hundred and fifty","about two hundred").replace("ten fine","twelve fine")
    y["prompt"]=p; y["key"]=x["key"]+"_p200"; G.F.append(y)
MAT=("All jewelry is real, made of many different materials and colours mixed piece by piece — yellow gold, silver, rose gold and platinum, glossy enamel in red, blue, green, yellow, pink, turquoise and purple patterned with stripes, polka dots, checks, filigree and mosaic inlay, and large cut rainbow gemstones (diamond, ruby, sapphire, emerald, amethyst, opal, topaz and pearl) — ")
SH=["a triangle","a square","a pentagon","a hexagon","a star","a heart","an infinity symbol","a teardrop","a lozenge"]
SIZE="Size is maximal in every version: each piece is as large as physically possible, far bigger than real-life jewelry, bold enough to be seen at a glance from across the room."
def post(t,P,colour,rr):
    t,n=re.subn(r'down to the base of her neck and the tops of her collarbones, the frame cutting off there','down to her collarbones and the tops of her shoulders, the frame cutting off there, so the long earrings fully hang in view',t,count=1); assert n==1
    pp=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    if colour:
        t,n=re.subn(r'All jewelry is real [^,]+?(?: \([^)]*\))?, sitting',MAT+'sitting',t,count=1); assert n==1
    shapes=", ".join(rr.sample(SH,6))
    st=("in glossy multicoloured enamel patterned with stripes, polka dots, checks and filigree, set with large rainbow gemstones" if colour else
        "in a single polished metal with huge clear gemstones, a simple one-colour palette but with enormous, imposing pieces")
    lvl=int(P[1:])
    if lvl<=8: ear="The ear piece is a gigantic showpiece earring as wide as her palm and as long as her hand — a huge star-shaped frame "+st+" with a long waterfall of shaped drops hanging below it to her collarbones and shoulders, passing through the real earlobe with the skin wrapping snugly around it."
    elif lvl<=50: ear="The biggest ear ring is a gigantic shaped frame as wide as her palm "+st+" with a long shaped-drop chandelier hanging from it to her shoulders, and the smaller rings above it are bold, large shaped frames, each passing through the real ear tissue."
    else: ear="Each ear's dense row is made of oversized shaped frames, thick bars and stretched plugs "+st+", topped by a gigantic chandelier earring as wide as her palm and as long as her hand that hangs to her shoulders."
    face=[]
    if "nostril" in pp: face.append("each nostril piece is a very large shaped frame the size of a big coin (square, pentagon or hexagon)"+(" with a gemstone drop" if lvl<=25 else ""))
    if "eyebrow" in pp: face.append("each eyebrow bar is thick and long and ends in two large gemstone stars or hearts")
    if "septum" in pp: face.append("the septum piece is a huge shaped frame nearly as wide as her nose")
    if "lip" in pp or "labret" in pp: face.append("the lip and chin pieces are large bold shaped frames and big gem studs")
    fc=(" Also, "+"; ".join(face)+", all passing through the real skin.") if face else ""
    if lvl<=15:
        sd=rr.choice(["left","right"]); od="right" if sd=="left" else "left"
        face=[x.replace("each nostril piece","the "+sd+" nostril piece").replace("each eyebrow bar","the "+sd+" eyebrow bar") for x in face if "lip" not in x and "septum" not in x]
        fc=(" On the same "+sd+" side only, "+"; ".join(face)+", all passing through the real skin.") if face else ""
        ear=ear.replace("The ear piece","The "+sd+" ear piece").replace("The biggest ear ring","The biggest ring on the "+sd+" ear")
        asym=(" The arrangement is deliberately asymmetric, not mirrored: everything bold is concentrated on her "+sd+" side as one single dramatic focal point, while her "+od+" side stays almost bare, with at most one small plain stud on the "+od+" ear and no other piercing, so the eye goes straight to the "+sd+" side.")
    else: asym=""
    look=("Piercing look: every piece named in the Piercings paragraph is an oversized showpiece, the biggest, boldest and most eye-catching version of itself — instead of plain round metal, each is a distinctive geometric shape ("+shapes+", no two the same), "+st+". "+ear+fc+asym+" "+SIZE)
    show=("Jewelry showcase: the piercings and jewelry are the unmistakable star of the image, big, striking, sexy and a feast for the eye; every gemstone flashes a hard bright glint, her hair is swept back behind her ears, and nothing covers her eyes, her face or her piercings, with every piece clear of the eyes by at least a finger's width.")
    return t.replace("\n\nLighting:","\n\n"+look+"\n\n"+show+"\n\nLighting:",1)
PLAN=[("P3",("NONE",["pierce","lens"]),("NONE",["pierce","henna"])),
 ("P5",("글래스 스킨",["pierce","sticker"]),("NONE",["pierce","lens"])),
 ("P8",("강남언니",["pierce","sticker","lens"]),("NONE",["pierce"])),
 ("P15",("NONE",["pierce","henna"]),("글래스 스킨",["pierce","lens"])),
 ("P25",("인스타글램",["pierce","sticker"]),("NONE",["pierce"])),
 ("P50",("립온리 블랙",["pierce","lens"]),("블러드 립",["pierce"])),
 ("P100",("비주얼계 블랙립",["pierce","lens"]),("뱀파이어 다크",["pierce"])),
 ("P150",("립온리 블랙",["pierce","lens"]),("블러드 립",["pierce"])),
 ("P200",("뱀파이어 다크",["pierce","lens"]),("고스 블랙립",["pierce"]))]
NA=[("한국","20대"),("일본","아이돌"),("중국","30대"),("한국","아이돌"),("일본","20대"),("중국","20대")]
EX=["도도한","섹시한","고혹적인","발랄한","카리스마 있는","군림하는","몽환적인","귀여운","냉혹한"]
o=["# LumineX — 피어싱 적은 단계(P3·P5·P8·P15) 비대칭 포인트 버전 8개 (크기 최대)\n",
   "- 각 단계 A = 알록달록·무늬·소재 혼합 극대화(+ 스티커/헤나/렌즈), B = 색은 수수(한 가지 금속 + 큰 보석)하지만 크기는 A와 똑같이 최대.",
   "- 모든 조각을 '현실 주얼리보다 훨씬 크게' 지정(귀걸이 손바닥 너비·손 길이, 콧망울 프레임 큰 동전 크기, 코 사이 링은 코 폭 가까이). 긴 귀걸이가 보이도록 프레임을 어깨 윗부분까지 넓힘.",
   "- P50 이상은 어두운 메이크업(블랙립·레드립) 위에서만, 스티커·헤나는 P50 미만에서만. P200은 P150 원문의 개수·체인만 늘림.",
   "- 한쪽(좌/우 무작위)에만 큰 포인트를 몰고 반대쪽은 거의 비움. P25 이상은 v2 그대로 쓰시면 됩니다.","- 정상/이상(+ 비대칭·크기·모양이 나왔는지)만 번호로 알려주세요.\n"]
k=0
for P,A,B in PLAN:
    if int(P[1:])>15: k+=2; continue
    for tag,(sty,slots) in (("A 알록달록",A),("B 수수·초대형",B)):
        colour=tag.startswith("A"); nat,grp=NA[k%6]; ex=EX[k%9]; k+=1
        for tr in range(30):
            try:
                t,title,meta=G.make(random.Random(7000+k*100+tr),nat,grp,ex,style=sty,slots=slots,pier_level=P); break
            except AssertionError: continue
        else: raise SystemExit("fail "+P+tag)
        t=post(t,P,colour,random.Random(9000+k)); assert not re.search(r"[가-힣]",t)
        o.append(f"## {P}-{tag} — {title}\n\n```\n{t}\n```\n")
open('/mnt/user-data/outputs/LumineX_JewelryMax_Asym_P3toP15_x8.md','w',encoding='utf-8').write("\n".join(o)); print(len(o)-5)
