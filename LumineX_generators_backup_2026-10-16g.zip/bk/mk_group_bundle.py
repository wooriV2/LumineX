import re,random,sys,json,collections
sys.path.insert(0,'.')
exec(open('mk_group_v2.py',encoding='utf-8').read().split('if __name__=="__main__":')[0])
CAT="🏺 Living Artifact · Face Sculpt Group Formula"
COUNTS={2:60,3:40,4:25,5:15}
RATIO={2:"4:3",3:"3:2",4:"16:9",5:"16:9"}
R=random.Random(20261025)
order=[n for n,c in COUNTS.items() for _ in range(c)]
out=[]
for i,n in enumerate(order,1):
    spec,bg,mode,t,labs=sample(R,n)
    t,nB=real2(t); t,k,k2=shorten(t); t=re.sub(r"  +"," ",t)
    assert not re.search(r"[가-힣]",t) and "{" not in t
    d=re.search(r"\b(\w+) \1\b",t); assert not d or d.group(1).lower() in("had","that"),d.group(0)
    ears=[l.split(" · 귀 ")[-1] for l in labs]
    names=" + ".join(nm for kk,nm in spec)
    title=f"Face Sculpt Group #{i:03d} ({n}인 · {names} · "+("45도" if mode!="front" else "정면")+f" · 배경 {bg} · 귀 "+" / ".join(ears)+")"
    out.append(dict(key=f"la_facesculpt_grp_{i:03d}",category=CAT,title=title,prompt=t,
      meta=dict(group_size=n,aspect_ratio=RATIO[n]+" horizontal",format="face-sculpt-group",kinds=[kk for kk,nm in spec],stars=[nm for kk,nm in spec],angle=("45deg" if mode!="front" else "front"),background=bg,ear_modes=ears,persons=labs)))
    if i%20==0: print(i,file=sys.stderr)
json.dump(out,open(OUT+'la_facesculpt_grp_140_bundle.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
print(len(out),len(set(x["key"] for x in out)))
for n in COUNTS:
    w=[len(x["prompt"].split()) for x in out if x["meta"]["group_size"]==n]; print(n,len(w),min(w),max(w),round(sum(w)/len(w)))
print(collections.Counter(a for x in out for a in x["meta"]["ear_modes"] if a.startswith(("철","혼합","단일","대형"))))
alld=sum(1 for x in out if x["meta"]["group_size"]<5 and len(set(e.split("(")[0] for e in x["meta"]["ear_modes"]))==x["meta"]["group_size"])
print("전원 다른 귀 종류(2~4인):",alld,"/",sum(1 for x in out if x["meta"]["group_size"]<5))
print(collections.Counter(x["meta"]["angle"] for x in out), collections.Counter(x["meta"]["background"] for x in out).most_common(3))
print("lip groups",sum(1 for x in out if "lip" in x["meta"]["kinds"]),"arch",sum(1 for x in out if "arch" in x["meta"]["kinds"]))
