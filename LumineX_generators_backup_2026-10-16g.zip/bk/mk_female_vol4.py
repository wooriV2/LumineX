# -*- coding: utf-8 -*-
# 여성 바디페인팅 정면 비교 샘플 4개 (부피 큰 체형 2 + 근육질 2) — 남성 정면 실패 대조용
import re, sys
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/diversity"); sys.path.insert(0, "../../master")
_g = open("gen_pierce_statue.py", encoding="utf-8").read()
exec(_g[:_g.index("def build(")])
import mdefs as D
exec(open("../../bk/newbody_defs.py", encoding="utf-8").read(), globals())
_src = open("../../bk/mk_statue_obj11.py", encoding="utf-8").read()
exec(_src[_src.index("rnd.seed("):_src.index("LABEL = ['Physique']")])      # KO 등
rnd.seed(20261019)
POOL = {b[0]: b[1] for b in D.BODIES}; POOL.update({nm: desc for nm, ko, kod, desc in NB})
_NBd = POOL["Nubian booty builder"]
POOL["Nubian bust builder"] = _NBd.replace("wide flaring lats", "a full, heavy, firm bust standing out on her chest").replace("a deeply carved abdomen with sharp obliques", "a deeply carved six-pack abdomen with sharp obliques")
POSES = {"front_arms": "standing tall facing the camera straight on, arms relaxed at her sides, weight even on both feet",
         "front_hips": "standing in a wide stance facing the camera straight on, both hands resting on her flared hips",
         "front_hip1": "standing facing the camera straight on, her left hand resting on her flared hip and her right arm relaxed at her side",
         "front_hair": "standing facing the camera straight on with her weight on one leg, one hand running through her hair, the other arm relaxed at her side"}
SHOES = ["Extreme gold ballet heels", "Extreme black patent stiletto pumps", "Extreme silver platform sandals", "Extreme red lacquer platform pumps"]
NAILS = ["Long square nails, glossy finish.", "Long almond nails, chrome finish.", "Long coffin nails, deep burgundy.", "Long stiletto nails, glossy black."]
BG = ["plain seamless deep-charcoal", "plain seamless mid-grey", "plain seamless deep-navy"]
def craft(c):
    cn, cd, cb, cf = CRAFT_DB_FULL[c]; return f"{cn} ({cd}), rendered in {cb} with {cf} filling the space between, flowing over every curve", cn
def build(bkey, PK):
    mk = rnd.choice(T.MAKEUP_48); nat, fa = face_nohair(mk); si = rnd.choice(EXPOSED); ci = rnd.randrange(1, len(HC) + 1)
    hair = f"{HAIR_COLOR_EN_FULL[HC[ci-1]]} hair styled in {HAIR_EN_FULL[HS[si-1]]}"
    c = rnd.choice(T.CRAFTS_39); ct, cn = craft(c)
    p = (f"Image format: a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide.\n\n"
         f"A full-body photograph with a {rnd.choice(BG)} backdrop, shot on a medium format camera with an 85mm lens at f/8, a single hard key light raking in from one side, sharp focus from head to toe, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.\n\n"
         f"Subject: ONE real adult {nat} woman, her face exactly the same tone as her body, real skin texture with visible pores and fine grain, {fa}, {hair}, real living eyes. {rnd.choice(NAILS)}\n\n"
         f"Physique: {POOL[bkey]} Her arms, hands, legs and feet stay in correct proportion to each other.\n\n"
         f"Skin: Real photographic skin — visible pores and fine grain, a smooth taut surface with natural creases and shadow only where the flesh folds. No smooth illustration finish, no plastic CG sheen.\n\n"
         f"Body Art: Her bare skin is painted in {ct}. The paint is pigment sitting on living skin, so it distorts slightly over every bulge. The paint covers her whole body with no bare skin left anywhere below the jaw: shoulders, upper arms, forearms, backs of her hands, chest, sides, back, belly, rear, thighs, knees, calves and the tops of her feet. Her face is left unpainted and the pattern fades out at the neck with no hard line.\n\n"
         f"Pose: {POSES[PK]}.\n\n"
         f"Footwear: {rnd.choice(SHOES)}, the platform soles rising far higher than her ankle bone, at least three times the thickness of an ordinary heel.\n\n"
         f"Background & Lighting: the painted pattern catching the light in sharp glints, the hard raking light carving every fold and curve.\n\n"
         f"Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide. portrait 2:3 vertical.")
    p = dd(p).replace(",,", ",").replace(".,", ",")
    assert not re.search(r"[가-힣]", p) and not re.search(r"\b(\w+) \1\b", p), re.findall(r"\b(\w+) \1\b", p)
    return p, f"{KO.get(bkey, bkey)} · {cn} · 메이크업 {mk}"
PLAN = [("USSBBW", "front_arms"), ("hourglass SSBBW", "front_hips"), ("powerlifter bombshell", "front_hip1"), ("Nubian bust builder", "front_hair")]
L = ["# LumineX — 여성 바디페인팅 정면 비교 4종 (부피 큰 체형 2 + 근육질 2)\n", "남성 정면이 모두 실패해서, 여성 체형이 같은 정면 포즈에서 생성되는지 비교하는 시험입니다. 번호별로 성공/실패만 알려주세요.\n"]
for n, (b, pk) in enumerate(PLAN, 1):
    p, d = build(b, pk); L.append(f"## {n}. 여성 바디페인팅 · {d} · 포즈 {pk}\n\n```\n{p}\n```\n"); print(n, d, pk, len(p.split()))
open("/mnt/user-data/outputs/LumineX_Female_BodyPaint_Front4.md", "w", encoding="utf-8").write("\n".join(L))
