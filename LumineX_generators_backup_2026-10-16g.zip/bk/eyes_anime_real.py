import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
from cover_lib import SAFE
HEAD="Professional fashion photograph, close-up beauty portrait. ONE woman, facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp. Mid 20s."
HEAD_W=HEAD.replace("down to the base of her neck and the tops of her collarbones, the frame cutting off there","down to her collarbones and the tops of her shoulders, the frame cutting off there, so the earrings fully hang in view")
TAIL=" Every feature is exaggerated but beautiful, balanced and refined, in harmony with the rest of her face, never distorted, never grotesque. Real skin fine grain and a soft sheen of natural oils on her face, ears and neck, individual hair strands catching the light — a photograph of a real woman, not an illustration, not a render."
SK="The skin around every piece is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
IRON="rough black cast iron with a hammered, pitted, matte surface"
def sub(txt): return "Subject: "+txt+TAIL



def eyesub(face,eyes,brows,rest):
    return sub("A real photograph of a strikingly beautiful adult woman, mid 20s, "+face+" Her eyes are the star of her face: "+eyes+" "+brows+" "+rest+" Looking straight into the camera.")
def pier(mat,desc,col):
    return ("Piercings: Exactly six piercings in total, symmetrical: on each ear a large "+desc+" hoop in the lobe and two matching studs up the rim. Each piece is large and clearly visible, and nothing else on the face is pierced. "+SK+" All jewelry is real "+mat+","+SAFE)
V=[("애니 돌 아이 실사형 A — 큰 눈 · 서양풍 여성 · 라일락 머리 · 핑크 립 · 피어싱 6",
    eyesub("a real-looking young woman with natural human proportions, realistic fair skin with visible fine pores, a soft pink blush and long straight pastel-lilac hair with a fringe.","very large, perfectly round doll eyes, clearly bigger than normal but still a real human eye on a real face: a big visible iris in vivid violet doll-eye contact lenses with a round natural pupil, both eyes the same, bright catchlights and real moist reflections, a darker limbal ring and a lighter violet gradient at the bottom of the iris, long thick curled real lashes with a few lower lashes, and soft natural brows.","The rest of the face is completely realistic and photographic: a natural, realistically proportioned nose, natural soft pink glossy lips of normal size, real cheeks with natural skin texture and a natural jaw, with no cartoon features at all.","A sweet, wide-eyed gaze straight into the camera."),
    pier("polished gold with pastel enamel and small gems","pastel-pink enamel",1)),
   ("애니 돌 아이 실사형 B — 거대한 눈 · 동아시아 여성 · 라일락 머리 · 핑크 립 · 피어싱 6",
    eyesub("a real-looking young East Asian woman with natural human proportions, realistic fair skin with visible fine pores and a soft pink blush, and long straight pastel-lilac hair with a fringe.","extremely large, perfectly round doll eyes, about one and a half times the normal size, taking up a big part of her upper face but still a real human eye: a massive visible iris in vivid violet doll-eye contact lenses that fills almost the whole eye opening, with a round natural pupil, both eyes the same, bright catchlights and real moist reflections, a darker limbal ring, very long thick curled real lashes, and soft natural brows.","The rest of the face is completely realistic and photographic: a natural, realistically proportioned nose, natural soft pink glossy lips of normal size, real cheeks with natural skin texture and a natural jaw, with no cartoon or painted features at all.","A sweet, wide-eyed gaze straight into the camera."),
    pier("polished gold with pastel enamel and small gems","pastel-pink enamel",1))]
o=["# LumineX — 애니 돌 아이 실사형 2개 (정면)\n","- 눈만 크고 둥글게(큰 홍채 렌즈), 얼굴 나머지는 실사 비율·피부 질감·보통 크기 코와 입술. A는 큰 눈, B는 1.5배 거대한 눈.","- 정상/이상(+ 얼굴이 실사 같은지, 눈이 커 보이는지)만 번호로 알려주세요.\n"]
for i,(lab,sj,p) in enumerate(V,1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(95000+i*100+tr),"한국","20대","도도한",style="NONE",slots=["pierce"],pier_level="P5"); break
        except AssertionError: continue
    else: raise SystemExit(i)
    ps=t.split("\n\n")
    depth=[x for x in ps if x.startswith("Piercing depth:")][0]; light=[x for x in ps if x.startswith("Lighting:")][0]
    new="\n\n".join([HEAD,sj,p,depth,light]); assert not re.search(r"[가-힣]",new)
    o.append(f"## {i}. {lab}\n\n```\n{new}\n```\n")
open('/mnt/user-data/outputs/LumineX_AnimeEye_Realistic_2.md','w',encoding='utf-8').write("\n".join(o)); print("ok")
