# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g2 = load("g2","gen2.py"); g3 = load("g3","gen3.py"); g4 = load("g4","gen4.py")
MAT = g2.MAT
BUST_BODY = g2.BODY; FULL_BODY = g4.BODY; WAIST_BODY = g3.WAIST_BODY

def mats(a, b):
    an, ad, ai = MAT[a]; bn, bd, bi = MAT[b]
    return an, ad, ai, bn, bd, bi

REAL_FACE = "Her whole face, ears and neck are real living flesh with real pores and fine grain."

# ================= 1. 표면 상태 (가슴) =================
nat, mk, fc = g3.face_of("슬라브 글램(러시아·동유럽)")
an, ad, ai, bn, bd, bi = mats("cobalt","amethyst")
P1 = f"""Professional fashion photograph, bust shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head to just below her chest, the frame cutting off beneath the chest. Her face sits large and sharp in the upper half of the frame. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}. {REAL_FACE} On each ear a big silver hoop with a filigree silver drop hangs clear of the neck down to the shoulder, real silver on real skin, healed, clean and calm.

Physique: {BUST_BODY['bust'][1]}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest): solid {ad}, with {ai}. Right half: solid {bd}, with {bi}. Each is carved as one solid sculpted mass like a statue, never hollow, the chest two great rounded masses with the groove between them cut into the material itself. The arms flow into the chest with no seam, and every wrist, palm, finger and knuckle is the same material as its arm.

Surface state: the two halves differ in surface as well as material. The cobalt glass on the left is freshly wet, covered in hundreds of tiny beaded water droplets and a few slow rivulets running down the chest and the arm, each droplet catching a point of light and bending the glass beneath it. The amethyst on the right is frozen, with a fine white frost rime along every edge and crease and tiny ice needles on the shoulder and the hand, the frost thickest in the grooves and thinning over the polished high points.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the chest and out of the bottom of the frame where the wet glass and the frosted crystal meet, never horizontal. Shards interlock along the lines only, every edge solid all the way through.

Pose: body angled 45 degrees, her left hand (solid glass) held low at the frame edge beside her chest, her right hand (solid crystal) held at chest height clear of her body, well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal light on her face and ears; a strong backlight through each half so both glow from within and the droplets and frost sparkle; a thin cool rim light along the centre line. 2:3 vertical 8K portrait."""

# ================= 2. 색 그림자(카우스틱) (전신) =================
nat, mk, fc = g3.face_of("서아프리카 파티·웨딩 글램")
an, ad, ai, bn, bd, bi = mats("amethyst","amber")
P2 = f"""Professional fashion photograph, full body shot, head to toe. ONE woman standing, angled 45 degrees toward the camera, the camera set back so her whole body fits in the frame from the top of her head to her feet and the floor and wall around her are visible, her face still sharp. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}. {REAL_FACE} On each ear a big gold hoop with gold beads hangs clear of the neck down to the shoulder, real gold on real skin, healed, clean and calm.

Physique: {FULL_BODY['hgu'][1]}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest, belly, left hip and the whole left leg down through the foot): solid {ad}, with {ai}. Right half: solid {bd}, with {bi}. Each is carved as one solid sculpted mass like a statue, never hollow. The arms flow into the torso and the torso into the legs with no seam, and every wrist, palm, finger, knuckle and toe is the same material as its limb. Her extreme platform stiletto sandals are carved from the same material as the leg each one sits under, running unbroken through the ankle and every toe.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the body, between the hips and legs and down to the floor, where the two materials meet, never horizontal. Shards interlock along the lines only, every edge solid all the way through.

Setting and light: she stands on a matte pale-grey studio floor in front of a plain pale-grey wall, lit by one strong hard warm light from the upper left behind her. The light passes through her transparent body and throws long, sharply coloured caustic shadows across the floor and the wall — deep violet patches from the amethyst side and warm orange-gold patches from the amber side, each with bright bending edges of concentrated light — while her real face stays softly lit from the front.

Pose: body angled 45 degrees, feet planted apart, her left hand (solid material) resting on her flared hip, her right arm held clear of her body with the hand (solid material) relaxed at hip height, well away from her face, head tilted slightly toward the camera. Only her face, ears and neck read as real skin. 2:3 vertical 8K portrait."""

# ================= 3. 무릎 꿇기 (전신) =================
nat, mk, fc = g3.face_of("발칸 글램(루마니아·불가리아)")
an, ad, ai, bn, bd, bi = mats("ruby","jade")
P3 = f"""Professional fashion photograph, full body shot, head to toe. ONE woman kneeling upright, square to the camera, the camera set back so her whole body and the low black stone plinth she kneels on fit in the frame, her face sharp. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}. {REAL_FACE} On each ear a thick gold hoop with a gold coin drop hangs clear of the neck down to the shoulder, real gold on real skin, healed, clean and calm.

Physique: {FULL_BODY['top'][1]}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest, belly, left hip, thigh, knee, calf and foot): solid {ad}, with {ai}. Right half: solid {bd}, with {bi}. Each is carved as one solid sculpted mass like a statue, never hollow. The arms flow into the torso and the torso into the legs with no seam, and every wrist, palm, finger, knuckle and toe is the same material as its limb, including the soles of the feet folded beneath her.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the body, between the thighs and the knees and down to the plinth, where the two materials meet, never horizontal. Shards interlock along the lines only, every edge solid all the way through.

Pose: kneeling upright on the plinth, square to the camera, her knees planted beneath her body and set apart, not squatting and not crouching, her calves folded flat back beneath her with her weight resting on her heels, her spine straight and vertical, both hands (solid material) resting on her thighs, her face turned to the camera with a calm direct gaze.

Lighting: pure pitch black background. A soft frontal light on her face and ears; a strong warm-red backlight from behind-left through the ruby half and a strong green backlight from behind-right through the jade half; a thin cool rim light along the centre line. Only her face, ears and neck read as real skin. 2:3 vertical 8K portrait."""

# ================= 4. 식물이 자라나는 몸 (허리) =================
nat, mk, fc = g3.face_of("노르딕 발키리(노르웨이)")
an, ad, ai, bn, bd, bi = mats("jade","amber")
P4 = f"""Professional fashion photograph, upper-body shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head down to the middle of her belly, the frame cutting off across the belly so no hips, legs or feet are visible. Her face sits in the upper part of the frame. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}. {REAL_FACE} On each ear a thick silver knotted hoop hangs clear of the neck down to the shoulder, real silver on real skin, healed, clean and calm.

Physique: {WAIST_BODY['hgs'][1]}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid translucent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest and belly): solid {ad}, with {ai}. Right half: solid {bd}, with {bi}. Each is carved as one solid sculpted mass like a statue, never hollow, the chest two great rounded masses and the belly folds cut into the material itself. The arms flow into the torso with no seam, and every wrist, palm, finger and knuckle is the same material as its arm.

Growth: real small plants grow out of the material below the collarbones, rooted in fine cracks inside the stone, their pale roots visible as threads through the translucent material. On the left jade, a climbing vine of white jasmine with green leaves and small white star flowers winds down from the shoulder along the arm and across the chest. On the right amber, a few red poppies with slender stems and buds rise from the shoulder and the upper arm. The leaves and petals are real and soft, and the material around each root is cracked just enough to hold it. The plants grow only from the shoulders, arms and chest — never on the neck, the face or the hair, and never covering the hands.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the chest and belly and out of the bottom of the frame where the two materials meet, never horizontal. Shards interlock along the lines only.

Pose: body angled 45 degrees, her left hand (solid jade) held low at the frame edge beside her belly, her right hand (solid amber) held at chest height clear of her body, well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal light on her face and ears; a strong warm backlight through the amber half and a soft green backlight through the jade half so both glow from within and the plants are lit from behind; a thin cool rim light along the centre line. 2:3 vertical 8K portrait."""

# ================= 5. 박물관 전시 (전신) =================
nat, mk, fc = g3.face_of("소피아 로렌풍(이탈리아)")
an, ad, ai, bn, bd, bi = mats("opal","ruby")
P5 = f"""Professional fashion photograph, full body shot, head to toe. ONE woman standing on a low black stone plinth in the middle of a dim museum gallery, angled 45 degrees toward the camera, the camera set back so her whole body, the plinth and the gallery around her fit in the frame, her face sharp. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}. {REAL_FACE} On each ear a large real pearl drop with a gold clip.

Physique: {FULL_BODY['colo'][1]}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest, belly, left hip and the whole left leg down through the foot): solid {ad}, with {ai}. Right half: solid {bd}, with {bi}. Each is carved as one solid sculpted mass like a statue, never hollow. The arms flow into the torso and the torso into the legs with no seam, and every wrist, palm, finger, knuckle and toe is the same material as its limb. Her extreme platform stiletto sandals are carved from the same material as the leg each one sits under, running unbroken through the ankle and every toe.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the body, between the hips and legs and down to the plinth, where the two materials meet, never horizontal. Shards interlock along the lines only, every edge solid all the way through.

Setting: she is an exhibit, a living artifact. The gallery has dark walls and a polished dark floor, a small brass placard sits on the front edge of the plinth, and a single warm museum spotlight shines down on her from above. Far behind her, a few small, soft-focus dark silhouettes of visitors stand looking up at her, and they only reach her knees, showing how enormous she is.

Pose: standing tall, body angled 45 degrees, feet planted apart, her left hand (solid material) resting on her flared hip, her right arm held clear of her body with the hand (solid material) relaxed at hip height, well away from her face, her calm eyes looking directly at the camera.

Lighting: dim gallery light. A warm overhead spotlight from above and slightly in front, soft on her real face; a strong backlight through the body so the opal glows milky with flashes of colour on one side and the ruby glows deep crimson on the other, throwing soft coloured light onto the plinth and floor; a thin cool rim light along the centre line. Only her face, ears and neck read as real skin. 2:3 vertical 8K portrait."""

ITEMS = [
 ("1","표면 상태(젖음×서리)","가슴","슬라브 글램 · 바스트 퀸 · 코발트 유리(물방울) × 자수정(서리)",P1),
 ("2","색 그림자(카우스틱)","전신","서아프리카 글램 · 아워글래스 USSBBW · 자수정 × 호박 · 회색 스튜디오 바닥·벽",P2),
 ("3","무릎 꿇기","전신","발칸 글램 · 톱헤비 아워글래스 · 루비색 유리 × 비취 · 낮은 돌 받침대",P3),
 ("4","식물이 자라나는 몸","허리","노르딕 발키리 · 아워글래스 SSBBW · 비취(재스민 덩굴) × 호박(양귀비)",P4),
 ("5","박물관 전시","전신","소피아 로렌풍 · 콜로설 · 오팔 × 루비색 유리 · 받침대와 방문객 실루엣",P5),
]
if __name__ == "__main__":
    for n,t,f,d,p in ITEMS:
        print(n,t,f,len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
