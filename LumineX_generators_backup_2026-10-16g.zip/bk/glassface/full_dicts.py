# -*- coding: utf-8 -*-
import io, contextlib, importlib.util
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g3 = load("g3","/home/claude/glassface/gen3.py")

STYLE_MAP_FULL = {
 '코갸루':"코갸루",'히메갸루':"히메갸루",'아게하':"아게하",'오네에갸루':"오네에갸루",'아마갸루':"아마갸루",'야마바':"야마바",
 '만바':"만바",'반바':"반바",'비주얼계':"비주얼계",'지뢰계':"지뢰계",'야미카와':"야미카와",'데코라':"데코라",
 '강남언니':"강남언니",'글래머러스파티':"글래머러스 파티",'걸크러시':"걸크러시",'뱀파이어다크':"뱀파이어 다크",'한복화보':"한복 화보(연지곤지)",
 '구풍':"구풍",'웨이쉰':"웨이쉰",'홍콩풍':"홍콩풍",
 '락혼글램':"락혼 글램(태국)",'파케앙트글램':"파케앙트 글램(필리핀)",'텔레노벨라글램':"텔레노벨라 글램(멕시코·콜롬비아)",
 '프렌치레드립':"프렌치 레드립(프랑스)",'슬라브글램':"슬라브 글램(러시아·동유럽)",'인스타글램':"인스타 글램(미국·영국)",
 '서아프리카글램':"서아프리카 파티·웨딩 글램",'하베샤화장':"하베샤 화장(에티오피아·에리트레아)",'요루바신부화장':"요루바 신부 화장(나이지리아)",
 '소피아로렌풍':"소피아 로렌풍(이탈리아)",'화환화장':"화환 화장(우크라이나)",'스칸디프로스트':"스칸디 프로스트(스웨덴)",
 '발칸글램':"발칸 글램(루마니아·불가리아)",'노르딕발키리':"노르딕 발키리(노르웨이)",
}
CUSTOM_FACE_FULL = {
 "페르시안글램": ("Iranian", "richly kohl-lined almond eyes, a deep berry-red lip, thick dark brows, warm olive skin"),
 "레바논웨딩글램": ("Lebanese", "radiant glowing bridal makeup, dramatic long lashes, a soft rose lip, warm fair skin"),
 "걸프아바야글램": ("Emirati", "smoky bronze eyes, a soft nude lip, warm golden-tan skin, an elegant composed expression"),
 "파키스탄브라이덜글램": ("Pakistani", "gold-dust eyeshadow, a deep maroon lip, richly detailed bridal makeup, warm brown skin"),
 "우즈벡실크로드글램": ("Uzbek", "a jewelled brow ornament, deep red lips, warm olive skin, a regal composed expression"),
 "자메이카댄스홀글램": ("Jamaican", "bold bright eyeshadow, a confident energetic expression, deep rich brown skin"),
 "하와이안훌라": ("Hawaiian", "a natural glowing complexion, a flower tucked behind one ear, warm golden-tan skin"),
 "스페인플라멩코글램": ("Spanish", "dramatic winged liner, a deep red lip, a passionate expression, warm olive skin"),
 "BollywoodGlam": ("Indian", "kohl-lined almond eyes, a small gold bindi, a deep maroon-red lip, warm golden-brown skin"),
 "CarnivalGlam": ("Brazilian", "sun-bronzed glowing skin, gold and copper shimmer eyes, a glossy nude-coral lip"),
 "AoDaiGlam": ("Vietnamese", "soft porcelain skin, delicate rose-pink eyeshadow, glossy soft-coral lips"),
 "TurkishGlam": ("Turkish", "warm olive skin, smoky bronze eyes, a deep rose-nude lip"),
 "GermanGlam": ("German", "fair cool-toned skin, soft taupe eyeshadow, a glossy nude-pink lip"),
 "EgyptianGlam": ("Egyptian", "warm golden-bronze skin, sharp winged kohl liner, a deep terracotta-red lip"),
}
def face(key):
    if key in CUSTOM_FACE_FULL: return CUSTOM_FACE_FULL[key]
    sty = STYLE_MAP_FULL[key]
    n,k,f = g3.face_of(sty)
    return n,f

BODY_SHORT_FULL = {
"글래머아워글래스": "a stunning hourglass figure, full rounded bust, dramatically narrow cinched waist, wide curvaceous hips.",
"머슬아워글래스BBW": "huge, powerfully muscular yet hourglass-shaped — thick muscular arms, colossal bust, a waist that still draws in, huge muscular-soft hips.",
"헤비머슬": "massive thick arms, broad muscular back, huge chest, dense muscular torso and legs with only a soft hint of a waist.",
"USSBBW": "an immense hanging belly in heavy rounded folds, no waist at all, colossal hips more than three times the shoulder width.",
"아워글래스SSBBW": "a colossal bust, a waist that still draws in even at extreme size, soft belly projecting forward, enormous hips.",
"파워리프터": "huge trapezius rising around the neck, boulder shoulders, dense thick arms, colossal glutes and hips extending past the shoulders.",
"아마조네스": "a towering, statuesque, overwhelmingly tall woman — broad shoulders, powerful muscular arms, colossal long thighs.",
"슈퍼글래머": "every curve oversized at once — colossal bust, sharply cinched waist, enormous hips, an overwhelming maximalist hourglass.",
"블랙글래머": "a shockingly extreme waist-to-hip contrast — a colossal bust, an extremely narrow cinched waist, hips flaring to many times that width.",
"레전드바스트": "an upper body dominated entirely by one mythologically enormous bust, far wider than her own shoulders, the defining feature.",
"커브드바스트": "bust and hips both dramatically enormous, but the waistline stays soft and only gently defined, a full natural figure.",
"브라질부티글램": "dominated by hips and rear — a sharply cinched waist above a rear curving outward and upward in a high rounded shelf.",
"폴리네시안여신": "a broad, continuous silhouette — strong shoulders, full heavy bust, soft gentle waistline, enormous broad hips and thighs.",
"누비안부티빌더": "a professional bodybuilder physique with extreme glute/hip development, dense muscle throughout, colossal hips far beyond the shoulders.",
}
CRAFT_DB_FULL = {
 "VietnameseSonMai": ("Vietnamese sơn mài lacquer","deep glossy black lacquer inlaid with gold-leaf lotus blossoms","gold-leaf","eggshell-white scrollwork"),
 "TurkishIznik": ("Turkish İznik tile","a brilliant white ground with cobalt-blue tulips and curling stems","cobalt-and-coral","floral scrollwork"),
 "IndianMughal": ("Indian Mughal miniature gold-work","a deep midnight-blue ground with fine gold linework and medallions","gold-and-crimson","jewel-toned scrollwork"),
 "KoreanNajeon": ("Korean najeon mother-of-pearl lacquer","glossy black lacquer with shimmering mother-of-pearl vines","mother-of-pearl","dense scrollwork"),
 "ChineseCizhou": ("Chinese Cizhou sgraffito ceramic","a glossy jet-black glaze carved to cream-white peony scrolls","carved cream","leaf scrolls"),
 "MexicanTalavera": ("Mexican Talavera ceramic","a glossy white tin glaze with cobalt blue and marigold medallions","cobalt","medallion scrollwork"),
 "KoreanEunipsa": ("Korean eunipsa silver inlay","a deep black ground with thick bright silver linework","bold silver","lattice fills"),
 "RussianPalekh": ("Russian Palekh miniature lacquer","a deep black ground with fine gold linework and firebirds","gold","jewel-toned scenework"),
 "JapaneseKutani": ("Japanese Kutani porcelain","a cream-white ground with bold red, gold and green overglaze enamels","gold-and-red","overglaze florals"),
 "ThaiBenjarong": ("Thai Benjarong porcelain","a black ground with five-colour jewel enamels in lotus-petal motifs","gold","tiered lotus-petal work"),
 "FilipinoYakan": ("Filipino Yakan painted pattern","a black ground densely patterned with bright geometric diamond bands","magenta-and-gold","geometric diamond work"),
 "PeruvianNazca": ("Peruvian Nazca painted pattern","a deep terracotta ground densely painted with stylised gold figures","gold","stepped geometric borders"),
 "FrenchLimoges": ("French Limoges enamel","a deep cobalt-blue ground with fine white and gold grisaille scrollwork","gold","grisaille scrollwork"),
 "UkrainianPetrykivka": ("Ukrainian Petrykivka floral painting","a black ground with bright red, orange and gold folk-art flowers","gold","folk-art florals"),
 "AmericanArtDeco": ("American Art Deco chrome-and-lacquer","a deep black lacquer ground with bold silver chrome sunburst","silver chrome","zigzag linework"),
 "NigerianAdire": ("Nigerian Adire indigo resist-dye","a deep indigo-blue ground with bold white resist-dyed motifs","white","spiral resist motifs"),
 "EthiopianCrossLattice": ("Ethiopian cross-and-lattice gold pattern","a deep wine-red ground with fine gold lattice linework","gold","lattice linework"),
 "YorubaAdireEleko": ("Yoruba adire eleko pattern","a deep indigo ground with bold cream resist-painted geometric motifs","cream","geometric bird motifs"),
 "ItalianDeruta": ("Italian Deruta majolica","a warm ivory ground with cobalt-blue and ochre-yellow floral medallions","cobalt-and-ochre","repeating floral border"),
 "UkrainianPysanka": ("Ukrainian pysanka egg-art linework","a deep black ground with fine red, gold and white geometric linework","gold-and-red","geometric wax-resist linework"),
 "SwedishKurbits": ("Swedish Dalarna kurbits folk painting","a deep barn-red ground with bold cream and gold curling scrollwork","gold","curling floral scrollwork"),
 "RomanianHorezu": ("Romanian Horezu ceramic","a cream ground with green, brown and ochre spiral floral motifs","ochre","spiral floral bands"),
 "NorwegianRosemaling": ("Norwegian rosemaling folk painting","a deep forest-green ground with bold cream and gold acanthus scrollwork","gold","acanthus scrollwork"),
 "EgyptianMamluk": ("Egyptian Mamluk brass-and-enamel inlay","a deep black ground with fine gold and silver geometric star inlay","gold-and-silver","geometric star inlay"),
 "MoroccanZellige": ("Moroccan zellige tile mosaic","a deep cobalt ground with interlocking white, terracotta and gold motifs","gold","interlocking star-and-cross motifs"),
 "SpanishTalaveraReina": ("Spanish Talavera de la Reina ceramic","a warm ivory ground with cobalt-blue and ochre floral medallions","cobalt","floral medallion border"),
 "GeorgianMinonkari": ("Georgian minonkari cloisonné enamel","a deep black ground with fine gold cloisonné wirework","gold","cloisonné floral wirework"),
 "HungarianKalocsa": ("Hungarian Kalocsa folk painted motif","a deep black ground with bright red, pink and gold folk-art florals","gold","folk-art floral motifs"),
 "PolishBoleslawiec": ("Polish Bolesławiec pottery","a deep cobalt ground with bold white peacock-eye dot motifs","white","peacock-eye dot motifs"),
 "CzechBohemian": ("Czech Bohemian crystal-engraving motif","a deep black ground with fine engraved silver linework","silver","engraved floral facets"),
 "FinnishIittala": ("Finnish Iittala glass-inspired linework","a deep indigo ground with bold cream concentric ripple-line motifs","cream","concentric ripple linework"),
 "CroatianHvar": ("Croatian Hvar filigree-inspired linework","an ivory ground with fine cream and gold painted filigree linework","gold","fine filigree linework"),
 "PortugueseAzulejo": ("Portuguese azulejo tile","a brilliant white ground with deep cobalt-blue floral borders","cobalt","repeating panel scrollwork"),
 "SpanishAndalusian": ("Spanish Andalusian filigree","a deep black ground with fine silver filigree in geometric star patterns","silver","geometric star filigree"),
 "KlimtMosaic": ("Klimt-inspired organic mosaic","an organic mosaic of small irregular tesserae with gold-leaf borders","gold","organic curved mosaic"),
 "EscherTessellation": ("Escher-inspired tessellation","a tessellating pattern of interlocking shapes that morph as they repeat","gold","morphing tessellation"),
 "CubistFragment": ("Cubist-fragmented pattern","sharp angular asymmetric flat planes seen from several angles at once","silver","angular fragment planes"),
 "IslamicGeometric": ("Islamic geometric star-tile pattern","a dense precise pattern of interlocking eight-pointed stars","gold","geometric star-and-polygon tile"),
 "VasarelyOpArt": ("Vasarely-inspired optical-illusion pattern","a repeating grid of squares bulging in a 3D illusion","silver","optical illusion grid"),
 "Kintsugi": ("Japanese kintsugi gold-seam ceramic","a glazed ceramic ground rejoined with flowing veins of molten gold lacquer along every seam","gold-veined","fine branching gilded seams"),
 "JapaneseMakie": ("Japanese maki-e gold-powder lacquer","a deep glossy black urushi lacquer ground scattered with a traditional motif — cherry blossoms, cranes among pine, or maple leaves — rendered in fine sprinkled gold powder","gold-powder","gold powder glittering densely"),
}
NAIL_SHAPE_EN_FULL = {"NA아몬드":"almond","NS스퀘어":"square","NC코핀":"coffin","NT스틸레토":"stiletto","NO오벌":"oval","NR라운드":"round"}
NAIL_FIN_EN_FULL = {"FG글로시":"glossy","FM매트":"matte","FC크롬":"chrome","FT글리터":"glittery","FH홀로그래픽":"holographic"}
HAIR_EN_FULL = {"HSS스트레이트":"sleek straight","HSW웨이브":"wavy","HSC컬":"curly","HSPT포니테일":"high ponytail","HSU업두":"elegant updo","HSB브레이드":"braided","HSBN번":"low bun","HSTT트윈테일":"twin-tail",
 "HSAF아프로":"a natural afro in a full rounded silhouette","HSLC락스":"long locs gathered loosely","HSCR콘로우":"cornrows braided tight against the scalp","HSHU하프업":"half-up, top section lifted with the length flowing loose below","HSPX픽시컷":"a short pixie cut","HSBC보브컷":"a chin-length bob","HSCH쉬농":"a low chignon knot at the nape","HSFB피쉬테일브레이드":"an intricate fishtail braid","HSTN탑노트":"a high top-knot bun","HSSK슬릭백":"a sleek wet-look slicked straight back",
 "HSSB스페이스번":"two small space buns on top of the head","HSBK반투노트":"many small bantu knots covering the scalp","HSFW핑거웨이브":"flat glossy finger waves styled close to the scalp","HSCP크림프":"tight zigzag crimped waves","HSBX박스브레이드":"long thick box braids","HSFR프렌치브레이드":"a classic French braid from the crown","HSMB마이크로브레이드":"countless fine micro braids","HSSH샤기컷":"a layered tousled shag cut","HSWF울프컷":"a layered wolf cut with curtain bangs","HSMH모호크":"a mohawk with volume along the centre of the scalp","HSVR빅토리롤":"vintage victory rolls framing the face","HSCB크라운브레이드":"a crown braid wrapping around the head","HSHP하이퍼프":"natural curls gathered into a high rounded puff"}

HAIR_COLOR_EN_FULL = {
 "HCJB제트블랙":"deep jet-black with a glossy sheen","HCNB내추럴블랙":"natural soft black","HCDB다크브라운":"deep dark brown","HCCB체스트넛브라운":"warm chestnut-brown",
 "HCAB애쉬브라운":"cool ash-brown","HCCH초콜릿브라운":"rich chocolate-brown","HCMH마호가니":"deep reddish mahogany-brown","HCCP코퍼":"vivid copper-orange",
 "HCAU오번":"warm auburn red-brown","HCSB스트로베리블론드":"soft strawberry-blonde","HCHB허니블론드":"warm honey-blonde","HCGB골든블론드":"bright golden-blonde",
 "HCPB플래티넘블론드":"icy platinum-blonde","HCCM샴페인블론드":"soft champagne-blonde","HCSG실버그레이":"sleek silver-grey","HCAG애쉬그레이":"cool ash-grey",
 "HCBG버건디":"deep burgundy wine-red","HCRG로즈골드":"soft rose-gold","HCBL발레아쥬":"dark roots fading smoothly into sun-kissed lighter ends (balayage)","HCOM옴브레":"a distinct two-tone ombre with dark roots and a sharp transition to light ends",
 "HCPP파스텔핑크":"soft pastel-pink","HCPL파스텔라벤더":"soft pastel-lavender","HCPM파스텔민트":"soft pastel-mint-green","HCPC파스텔피치":"soft pastel-peach",
 "HCVB비비드블루":"bold vivid electric-blue","HCVV비비드바이올렛":"bold vivid violet-purple","HCVM비비드마젠타":"bold vivid magenta-pink","HCVG비비드그린":"bold vivid emerald-green",
 "HCVO비비드오렌지":"bold vivid tangerine-orange","HCIW아이시화이트":"pure icy-white",
}
SHOE_EN_FULL = {
 "플랫폼스틸레토힐":"platform stiletto heels","익스트림플랫폼하이힐":"extreme platform high heels","플랫폼스틸레토펌프스":"platform stiletto pumps",
 "플랫폼스틸레토앵클부츠":"platform stiletto ankle boots","플랫폼하이힐뮬":"platform high-heel mules","익스트림플랫폼웨지":"extreme platform wedges",
 "플랫폼스틸레토메리제인":"platform stiletto Mary Janes","익스트림플랫폼싸이하이부츠":"extreme platform thigh-skimming boots",
 "플랫폼스틸레토슬링백":"platform stiletto slingbacks","익스트림플랫폼레이스업샌들":"extreme platform lace-up sandals",
 "플랫폼스틸레토니하이부츠":"platform stiletto knee-high boots","플랫폼스틸레토크로스스트랩샌들":"platform stiletto cross-strap sandals",
 "익스트림플랫폼스퀘어토힐":"extreme platform square-toe heels","플랫폼스틸레토페탈토힐":"platform stiletto peep-toe heels",
 "익스트림플랫폼버클부츠":"extreme platform buckled boots","플랫폼스틸레토코르셋레이스부츠":"platform stiletto corset-lace boots",
 "익스트림플랫폼클리어힐":"extreme platform clear heels","플랫폼스틸레토스터드부츠":"platform stiletto studded boots",
 "순수스틸레토펌프스":"plain stiletto pumps","발레힐":"ballet heels","니들힐":"needle heels",
 "싸이하이스틸레토부츠":"thigh-high stiletto boots","스컬프처럴힐":"sculptural heels","앵클스트랩스틸레토":"ankle-strap stilettos",
}
POSE_EN_FULL = {
 "정면와이드스탠스":"square to camera, feet wide, arms clear of her body","한쪽무릎꿇기":"kneeling on one knee, the other raised",
 "3/4각도":"three-quarter angle, one hand on her hip","옆모습":"full side profile, one arm reaching forward",
 "뒷모습3/4":"back three-quarters to camera, head turned back","걷는동작":"mid-stride walking toward camera",
 "벽에기대기":"leaning against a wall just out of frame","의자앉기":"seated on a low stool, hands on knees",
 "바닥옆으로기대기":"reclining on her side, propped on one elbow","양팔위로":"both arms raised overhead",
 "허리손":"both hands on her hips, elbows out","머리넘기기":"both hands sweeping her hair back",
 "런지자세":"wide lunging stance, one leg forward","완전뒷모습":"back fully to camera",
 "창가기대기":"leaning one arm on a window frame","계단에앉기":"seated across two steps",
 "얼굴감싸기":"both hands framing her own face","점프동작":"caught mid-jump, feet off the ground",
 "양무릎꿇고정면":"kneeling on both knees, facing camera",
}
AGE_EN_FULL = {"A20E":"early 20s","A20M":"mid 20s","A20L":"late 20s","A30E":"early 30s","A30M":"mid 30s","A30L":"late 30s","A40E":"early 40s","A40M":"mid 40s","A40L":"late 40s","A50E":"early 50s","A50M":"mid 50s","A50L":"late 50s"}
VIBE_EN_FULL = {"VC귀여운":"cheerful","VS섹시한":"sultry","VCH시크한":"cool and composed","VP청순한":"demure and soft","VPR도발적인":"bold and confident"}

CUSTOM_LABEL_EN = {
 "페르시안글램": "Persian Glam", "레바논웨딩글램": "Lebanese Wedding Glam", "걸프아바야글램": "Gulf Abaya Glam",
 "파키스탄브라이덜글램": "Pakistani Bridal Glam", "우즈벡실크로드글램": "Uzbek Silk Road Glam",
 "자메이카댄스홀글램": "Jamaican Dancehall Glam", "하와이안훌라": "Hawaiian Hula",
 "스페인플라멩코글램": "Spanish Flamenco Glam", "BollywoodGlam": "Bollywood Glam", "CarnivalGlam": "Carnival Glam",
 "AoDaiGlam": "Ao Dai Glam", "TurkishGlam": "Turkish Glam", "GermanGlam": "German Glam", "EgyptianGlam": "Egyptian Glam",
}

# ===== 비늘(Scale) 통합 재질 — 동물타입별 모양 정의 =====
SCALE_ANIMAL_DB = {
 "butterfly": ("thousands of microscopic powder-fine scales layered like overlapping roof tiles, each scale individually distinct catching its own glint", [("ELECTRIC BLUE","DEEP BLACK"),("ELECTRIC EMERALD","GOLD"),("ELECTRIC VIOLET","MAGENTA")]),
 "koi": ("rounded smooth scales with fine visible growth rings, each scale glossy and slightly domed", [("ELECTRIC CRIMSON","PEARL WHITE"),("ELECTRIC BLUE","VIVID ORANGE"),("METALLIC GOLD","PLATINUM")]),
 "snake": ("diamond-shaped angular scales aligned in neat overlapping rows", [("DEEP EMERALD","JADE"),("WARM BRONZE","BLACK"),("PALE GOLD","IVORY WHITE")]),
 "dragon": ("large thick armor-plate scales, each one substantial and sharply faceted", [("BLAZING CRIMSON","DEEP EMBER"),("METALLIC GOLD","AMBER"),("DEEP EMERALD","JADE"),("ELECTRIC SAPPHIRE","DEEP COBALT"),("GLOSSY JET BLACK","DEEP PURPLE"),("METALLIC SILVER","PALE BLUE")]),
 "mermaid": ("fine delicate scales, small and closely overlapping with a soft iridescent sheen", [("ELECTRIC TEAL","SILVER"),("ELECTRIC VIOLET","PEARL"),("ELECTRIC CYAN","GOLD")]),
}
