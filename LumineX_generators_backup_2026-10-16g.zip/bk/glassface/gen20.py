# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g3 = load("g3","gen3.py")
def face(n):
    return g3.face_of(n)

# ---------------- 1. 머리카락만 재질 ----------------
P1 = """Professional fashion photograph, close-up beauty portrait. ONE woman, her face turned about 30 degrees toward the camera, framed tightly from the very top of her hair down to the base of her neck and the tops of her bare shoulders and collarbones. Her face is large and sharp. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult Japanese woman in age-gyaru makeup — luminous glossy skin with a bright highlighter, thick black eyeliner, extremely long dramatic false lashes top and bottom, large eyes with bright real catchlights, glossy peach-pink lips, a confident sparkling expression. Her face, ears, neck and shoulders are entirely real living skin with real pores and fine grain, with real living eyes and real lips. On each ear a huge thick gold hoop hangs clear of the neck down to the shoulder, with a large gold stud above it, all real gold on real skin, healed, clean and calm.

Hair: her hair is the only material on her body. The towering teased hair is carved of solid Murano glass — tall, teased sculpted locks standing high above the crown and falling in long ribbons around the face and over her shoulders, each lock a chiselled ribbon of solid clear glass with twisted ribbons of cobalt, red, yellow and white swirling through it and tiny gold flecks suspended inside. It is solid glass all the way through, never hollow, never a wig or a covering, and it grows straight out of her real scalp along the hairline with a clean, crisp edge. The glass locks catch hard glints and throw soft coloured light across her real skin.

Boundary: the hairline is the only boundary — real forehead and temples below it, glass hair above it, with no soft transition. Small shards of glass interlock along the hairline, and a few pieces lift and cast real shadows on her forehead.

Lighting: pure pitch black background. A soft frontal light on the face; a strong backlight from behind through the glass hair so every ribbon of colour glows from within; a thin cool rim light along the glass. Only the hair is glass — everything else reads as real photographic skin. 2:3 vertical 8K portrait."""

# ---------------- 2. 변환 진행도 (S4) ----------------
nat, mk, fc = face("노르딕 발키리(노르웨이)")
P2 = f"""Professional fashion photograph, bust shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head to just below her chest, the frame cutting off beneath the chest. Her face sits large and sharp in the upper half of the frame. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}. She wears a plain black high-neck sleeveless top of real matte fabric. Her face, hair, neck, right shoulder, right arm and right hand are real living skin with real pores and fine grain. On each ear a huge thick silver hoop hangs clear of the neck down to the shoulder, real silver on real skin, healed, clean and calm.

Transformation (stage 4 of 7): she is turning into solid amethyst crystal, and the change has spread from her left hand up her left arm, across her left shoulder and up the left side of her neck as far as the jawline. Her whole left hand, every finger and knuckle, her whole left arm, the left shoulder cap coming out of the armhole and the left side of her neck are solid amethyst crystal with nothing beneath and no skin on them — carved as one solid mass like a statue, never hollow, with internal facets and colour zoning, deep violet where thickest and pale lilac at every thin edge. The crystal continues under the edge of the top. Her face, right side and everything above the jawline stay entirely real flesh.

Front line: the change ends at a sharp jagged front line running up the left side of the neck below the jaw and around the edge of the armhole. Along the front line, small crystal facets and shards rise and interlock with the warm living skin beside them, which keeps its real pores and warm colour right up to the edge; a few tiny fragments lift and cast real shadows. Beyond the front line there is no blending, no gradient and no paint — real skin on one side, solid crystal on the other.

Pose: body angled 45 degrees, her left hand (solid crystal) held low at the frame edge beside her chest, her right hand (real skin) resting at the opposite edge, both well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft frontal light on her face; a strong magenta-violet backlight through the crystal so the whole left arm and shoulder glow from within; a thin cool rim light along the front line. 2:3 vertical 8K portrait."""

STAGES = [
 ("S1","왼손 손끝만 재질"),
 ("S2","왼손과 팔뚝"),
 ("S3","왼팔 전체(어깨까지)"),
 ("S4","왼팔 + 왼쪽 어깨 + 왼쪽 목(턱선까지) ← 위 프롬프트"),
 ("S5","S4 + 왼쪽 얼굴 절반(왼쪽 눈알은 실사)"),
 ("S6","S5 + 오른팔"),
 ("S7","양팔, 목, 얼굴 전체(눈알과 입술만 실사)"),
]

# ---------------- 3. 실사 인물 + 재질 조각상 듀오 ----------------
nat3, mk3, fc3 = face("소피아 로렌풍(이탈리아)")
P3 = f"""Professional fashion photograph, double portrait. TWO figures side by side, shoulder to shoulder, both turned about 30 degrees toward the camera, framed from the top of their heads down to the collarbones and upper chest. Both faces are large and sharp.

The left figure is a real living woman: a strikingly beautiful adult {nat3} woman in {mk3} makeup — {fc3}. Her face, ears, neck and bare shoulders are entirely real living skin with real pores and fine grain, real living eyes and real lips. On each ear she wears a large real pearl drop with a gold clip.

The right figure is her exact twin as a sculpture: the same face, the same expression, the same pose mirrored, the same backcombed hairstyle, carved as one solid statue of amethyst crystal, with nothing beneath and no skin anywhere. The whole head, hair, neck and shoulders are solid crystal with internal facets and colour zoning, deep violet where thickest and pale lilac at every thin edge, sculpted with the fine detail of a master portrait sculptor. The eyes are carved with polished clear gem irises. The makeup is colour inside the crystal, never paint: a long upswept liner as a fine dark line at each outer corner, strongly arched brows as raised lines, a deep red glow in the carved lips, a soft warm tone in the cheeks. The same large pearl drops with gold clips hang on her carved ears, real pearls and metal on drilled openings in the stone.

The statue is unmistakably a solid three-dimensional carved object, never a person painted violet, and the real woman is unmistakably alive — warm skin, moist eyes, individual hair strands. Their shoulders touch and the two are equally sharp.

Lighting: pure pitch black background. A soft warm frontal light on the real woman; a strong magenta-violet backlight through the crystal so the statue glows from within; a thin cool rim light along the statue's edge. 2:3 vertical 8K portrait."""

# ---------------- 4. 재질 의상 ----------------
nat4, mk4, fc4 = face("슬라브 글램(러시아·동유럽)")
P4 = f"""Professional fashion photograph, three-quarter portrait. ONE woman standing, angled 45 degrees toward the camera, framed from the very top of her head down through the hips, the frame cutting off across the upper thighs. Her face sits large and sharp in the upper part of the frame. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat4} woman in {mk4} makeup — {fc4}. Her face, hair, neck, shoulders, arms and hands are entirely real living skin with real pores and fine grain. On each ear a big silver hoop with a filigree silver drop, real silver on real skin, healed, clean and calm.

Couture: she wears a gown and a crown made of solid glacial ice, sculpted as garments resting over her real body. The gown has a fitted corset bodice with a sweetheart neckline and a wide skirt fanning out below the hips, carved with deep pleats and folds from thick frosted ice — milky, semi-translucent and thick enough that nothing beneath it shows but a plain white satin slip. Deep cyan sits where the ice is thickest, with white streaks of compressed layers, trapped air bubbles and frost gathering in every fold, and the edges are clear and sharp. Her bare shoulders, arms and collarbones remain real skin above and beside the bodice. On her head sits a tall crown of clear ice crystals rising in points. The ice is a garment, not her body: it rests on her, follows her shape and has visible thickness, and her real skin meets it in a crisp clean edge along the neckline.

Pose: body angled 45 degrees, one real hand resting on the ice bodice at her waist, the other arm relaxed at her side, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft cool frontal light on her face and skin; a strong blue-white backlight through the ice so the gown and crown glow from within; a thin cool rim light along the crown. Only the gown and crown are ice — everything else reads as real photographic skin. 2:3 vertical 8K portrait."""

# ---------------- 5. 그릇 몸 ----------------
nat5, mk5, fc5 = face("스칸디 프로스트(스웨덴)")
P5 = f"""Professional fashion photograph, bust shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head to just below her chest, the frame cutting off beneath the chest. Her face sits large and sharp in the upper half of the frame. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat5} woman in {mk5} makeup — {fc5}. Her whole face, ears and neck are real living flesh with real pores and fine grain. On each ear a big smooth silver hoop hangs clear of the neck down to the shoulder, real silver on real skin, healed, clean and calm.

Vessel body: from the collarbones down, her body is not skin — it is a sculpted vessel of thick clear glass in the exact shape of her chest, shoulder, arm and hand, filled to the brim so nothing is hollow and there is no air gap. The glass walls are thick and polished, with crisp glints along every edge. The left half (left shoulder, whole arm and hand, half the chest) is an aquarium: deep blue water filling the whole shape, with five or six glowing jellyfish of different sizes drifting inside the chest and the arm, trailing pale tentacles, tiny air bubbles rising and fine specks of light suspended in the water. The right half is a terrarium: a miniature forest filling the whole shape, with dense green moss, small ferns, tiny mushrooms, a few small white flowers and a scatter of fireflies glowing among them. The hands are solid clear glass with tiny bubbles inside, the fingers and knuckles the same glass as the arms.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, the glass vessel immediately below. A second jagged line runs down the centre of the chest where the aquarium and the terrarium meet, out of the bottom of the frame, never horizontal. A few small shards of glass interlock along the lines and cast real shadows.

Pose: body angled 45 degrees, her left hand (solid glass) held low at the frame edge beside her chest, her right hand (solid glass) held at chest height clear of her body, well away from her face, head tilted slightly toward the camera.

Lighting: pure pitch black background. A soft cool frontal light on her face and ears; a strong blue backlight through the aquarium half so the jellyfish glow, and a soft green backlight through the terrarium half so the fireflies and moss glow; a thin cool rim light along the centre line. Only her face, ears and neck read as real skin. 2:3 vertical 8K portrait."""

ITEMS = [
 ("1","머리카락만 재질","아게하 · 무라노 유리 머리카락 · 얼굴·몸 실사", P1),
 ("2","변환 진행도(S4)","노르딕 발키리 · 왼팔·어깨·목이 자수정으로 · 실사 얼굴", P2),
 ("3","실사 인물 + 재질 조각상 듀오","소피아 로렌풍 · 실사 여성 + 자수정 조각상 쌍둥이", P3),
 ("4","재질 의상","슬라브 글램 · 빙하 얼음 드레스와 왕관 · 몸은 실사", P4),
 ("5","그릇 몸","스칸디 프로스트 · 왼쪽 아쿠아리움 × 오른쪽 테라리움 유리 몸", P5),
]
if __name__ == "__main__":
    for n, t, d, p in ITEMS:
        print(n, t, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
