# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
exec(open('gen_final3.py', encoding='utf-8').read().split("\n# ================= A.")[0])     # 덮어쓰기·UV_TAKEN·s_* 구조 함수·hz·region_sents·person 계열 상수
rnd.seed(20261030)
def pct(lo, hi, step=1): return rnd.randrange(lo, hi+1, step)
NW[4]="FOUR"
KEY={"MON":"mon","SG":"sg","DOT":"dot","STR":"str","CHV":"chv"}; KO={"MON":"비대칭 몬드리안","SG":"큰 조각 4개","DOT":"폴카도트","STR":"굵은 스트라이프","CHV":"셰브론"}

def s_sg2(shape):
    while True:
        r = s_sg(shape); m = re.search(r"분기 (\d+)/(\d+)%", r[4])
        if abs(int(m.group(1)) - int(m.group(2))) >= 20: return r        # 분기선 간격 20% 이상(작은 조각 방지)
def struct2(typ, shape):
    if typ == "MON": return s_mon(4, shape)
    if typ == "SG":  return s_sg2(shape)
    if typ == "DOT": return s_dot(rnd.choice([3,4]), shape)
    if typ == "STR": return s_stripe(rnd.choice(["H","V","D"]), 4, rnd.choice([2,3]), shape)
    return s_chev(rnd.choice([3,4]), rnd.random()<0.5, shape)
def matwords(t): return t.replace("patterns","materials").replace("pattern","material").replace("motifs","elements")
def hz_mat(shape, typ): return matwords(hz(shape, KEY[typ]))

def parts(typ, shape, allow_uv):
    pre, reg, seq, m, lab = struct2(typ, shape); pre = matwords(pre)
    assert sens_count(pre+" "+" ".join(reg)) == 0, typ
    mats = pick_ex(m, allow_uv); texts = [mat_text(k)[0] for k in mats]
    return pre, reg, seq, m, lab, mats, region_sents(reg, seq, texts, "carries")

def p_max(label, typ, shape, phys, hair, age, pose):
    pre, reg, seq, m, lab, mats, sents = parts(typ, shape, True); pn, pd = phys; px = f"{label}: " if label else ""
    uv = " A standard hard key light illuminates most of her body; a separate dedicated UV blacklight illuminates the UV-reactive region specifically, making it glow at full intensity while the rest reads under normal light." if "uvneon" in mats else ""
    txt = (f"{px}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {pn} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {pd}, {hair} — her body carries {m} different materials at once, each claiming its own region of her figure. {pre} {sents} {hz_mat(shape, typ)}, no fabric no seam no garment anywhere, every material fused to or erupting from her own living skin, covering her completely with no bare skin anywhere from neck to ankle. Pose: {pose}, every region clearly visible to the camera — most extreme {pn} silhouette ever displayed.{uv}\n"
           f"{px}extreme platform heels/boots blending the relevant materials at her feet, extra long nails each matching whichever region that hand falls in.")
    return txt, f"맥시 {KO[typ]}·{'물결' if shape=='undulating' else '매끈'}", f"{pn}", "+".join(MAT_KO[k] for k in mats)

def real_row():
    row = rnd.randrange(len(D["makeup"]))
    return (AGE_EN_FULL[D["age"][row]], VIBE_EN_FULL[D["vibe"][row]], SHOE_EN_FULL[D["shoe"][row]],
            pierce_phrase(D["pierce_p"][row],D["pierce_c"][row],D["pierce_g"][row],D["pierce_f"][row],D["pierce_s"][row],D["pierce_m"][row]),
            f"{JQ_SHORT[D['jq'][row]]} of {JMETAL_EN[D['jmetal'][row]]} {JTYPE_EN[D['jtype'][row]]}")
def p_real(label, typ, shape, makeup, bodykey, solo, pregnant):
    nat, fa = face_nohair(makeup); age, vibe, shoe, pierce, jewelry = real_row()
    hair = f"{HAIR_COLOR_EN_FULL[rnd.choice(T.HAIR_COLOR)]} hair styled in {HAIR_EN_FULL[rnd.choice(T.HAIR_STYLE)]}"
    pre, reg, seq, m, lab, mats, sents = parts(typ, shape, False)
    if pregnant:
        bodytext = ALL_PREG[bodykey].replace("a high, smoothly rounded pregnant belly", f"a high, smoothly rounded pregnant belly, {BELLY_BOOST},", 1); pose = rnd.choice(POSES)
        belly = "The materials of every region curve fully around her belly like contour lines circling a globe, the rounded surface of her belly staying fully covered as part of whichever region it falls in, with the same density continuing in full strength over her bust, nowhere on her body left bare, no fabric no seam no garment anywhere. "
        phys = f"extraordinarily large pregnant physique far beyond any real person — {bodytext}"
    else:
        pose = POSE_EN_FULL[rnd.choice(FRONT_POSES)]
        belly = "The materials of every region continue in full strength over her whole figure, nowhere on her body left bare, no fabric no seam no garment anywhere. "
        phys = BODY_FULL[bodykey]
    body = (f"{'Full body fused' if solo else 'Fused'} with {m} different materials instead of ordinary skin below the collarbones, each material claiming its own region of her figure, covering every inch from neck to ankle without exception, the materials reading as one continuous second skin with no gaps. {pre} {sents} {hz_mat(shape, typ)} {belly}")
    head = f"{nat} woman, an adult, in her {age}, {vibe} expression" if solo else f"{label}: {nat}, in her {age}, {vibe} expression"
    txt = (f"{head}, warm radiant skin tone{',' if pregnant else ' —'} {phys} Her face is a real living adult face, {fa}, {hair}, real pores, real living eyes, {pierce}, wearing {jewelry}. {body}Pose: {pose}, " +
           (f"her whole silhouette filling the frame from head to her {shoe}, the platform soles rising far higher than her ankle bone." if solo else f"her {shoe}, the platform soles rising far higher than her ankle bone."))
    return txt, f"{'임산부' if pregnant else '일반'} {KO[typ]}·{'물결' if shape=='undulating' else '매끈'}", f"{bodykey}/{makeup}", "+".join(MAT_KO[k] for k in mats)

def build(specs):
    g = len(specs); UV_TAKEN[0] = False
    mk = rnd.sample(T.MAKEUP_48, g); bgen = rnd.sample(VOLBODY, g); bpre = rnd.sample(STABLE_BODIES, g); bmax = rnd.sample(PHYS, g)
    blocks=[]; descs=[]
    for i,(track,typ) in enumerate(specs):
        shape = rnd.choice(["smooth","undulating"]); lab = f"#{i+1}" if g>1 else None
        if track == "맥시": b, st, who, ms = p_max(lab, typ, shape, bmax[i], rnd.choice(HAIRS_MX), rnd.choice(AGES_MX), rnd.choice(POSES_MX))
        elif track == "임산부": b, st, who, ms = p_real(lab, typ, shape, mk[i], bpre[i], g==1, True)
        else: b, st, who, ms = p_real(lab, typ, shape, mk[i], bgen[i], g==1, False)
        blocks.append(b); descs.append(f"[{st} / {who} / {ms}]")
    tracks = [t for t,_ in specs]
    if g == 1 and tracks[0] == "맥시":
        p = f"Professional fashion photograph, full body shot. ONE woman standing.\n\n{blocks[0]}\n\nMANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. ONE woman only. Extreme macro detail on every material and every blended transition. Pattern density MAXIMUM — zero bare skin anywhere from neck to ankle. 8K portrait 2:3 aspect ratio."
    elif g == 1:
        p = f"Professional fashion photograph, full body shot. ONE woman standing or kneeling as described.\n\nSubject: {blocks[0]}\n\nBackground: a plain seamless deep-charcoal backdrop, nothing else in frame. Lighting: a single hard key light raking in from one side, sharp focus head to toe, realistic photographic grain, a real photograph not an illustration not CGI not a render. Pattern density maximum, zero bare skin from neck to ankle. 2:3 vertical 8K portrait, taller than it is wide."
    else:
        tail = (f"Environment: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.\nAll: Extreme macro detail on every material and every blended transition, realistic photographic grain on the realistic-skin and pregnant women, extreme high-gloss oil on the darkest-skin women. CRITICAL: all {g} women's legs must show FULL BODY ART coverage from hip to ankle to toe with NO bare untattooed skin visible anywhere. {NW[g]} completely different extreme physiques must CONTRAST and DOMINATE every inch of frame. 8K portrait {ASP[g]} aspect ratio." if "맥시" in tracks else
                f"Background: a plain seamless deep-charcoal backdrop, nothing else in frame. Lighting: a single hard key light raking across all of them from one side, sharp focus head to toe on each, realistic photographic grain, a real photograph not an illustration not CGI not a render. Pattern density maximum, zero bare skin from neck to ankle on any of them. Shot on a Hasselblad X2D, {ASP[g]} aspect ratio, 8K.")
        p = f"Professional fashion photograph, full body shot. {NW[g]} women standing side by side, each from a different look, each with her own multi-material blended body.\n\n" + "\n\n".join(blocks) + f"\n\n{tail}"
    return p, " ; ".join(descs)

SPECS = [[("맥시","STR")], [("임산부","CHV"),("임산부","DOT")], [("일반","MON"),("일반","STR")],
         [("맥시","SG"),("맥시","CHV"),("맥시","DOT")], [("일반","STR"),("임산부","MON"),("맥시","CHV")], [("임산부","SG")]]
items=[]
for sp in SPECS:
    p, desc = build(sp); p = fix(p); check("s2e", p, allow_uv=True, mat=True); items.append((len(sp), desc, p))
order=list(range(6)); rnd.shuffle(order); no={i:order.index(i)+1 for i in range(6)}; ranked=sorted(range(6), key=lambda i:no[i])
GN={1:"솔로",2:"듀오",3:"트리오"}
L=["# LumineX · 2단계 구조(스트라이프·셰브론·몬드리안·폴카도트·큰 조각)를 실제 환경에서 시험 6개\n",
   "2단계 구조를 맥시멀리스트·임산부·일반인 문장 구조(재질 혼합)에서, 솔로·듀오·트리오로 확인합니다. 큰 조각 4개는 분기선 간격을 20% 이상으로 제한했습니다. 재질은 꽃·수정·촛농을 뺐고 UV네온은 맥시멀리스트에게만 넣었습니다. 번호는 섞여 있습니다. **성공/실패만** 알려주세요(최대 3회, 1회/2회/3회/실패). 예: `3: 2회 / 5: 실패 / 나머지 1회`\n",
   "## 색인\n","| 번호 | 인원 | 구성 (트랙 구조·경계선 / 체형 / 메이크업 / 재질) |","|---|---|---|"]
for i in ranked: g,desc,p = items[i]; L.append(f"| {no[i]:02d} | {GN[g]} | {desc} |")
L.append("")
for i in ranked: g,desc,p = items[i]; L.append(f"## {no[i]:02d}. {GN[g]}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_Stage2_Env_Test_6.md","w",encoding="utf-8").write("\n".join(L))
json.dump([{"no":no[i],"gsize":items[i][0],"desc":items[i][1]} for i in ranked], open("/home/claude/s2env_meta.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
print("6개 저장")
for i in ranked: print(f"  {no[i]:02d} {GN[items[i][0]]} {len(items[i][2].split()):>4}단어 | {items[i][1][:105]}")
