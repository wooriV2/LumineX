# -*- coding: utf-8 -*-
import re, sys, random, json
sys.path.insert(0, '.')
sys.path.insert(0, '/home/claude/diversity')
from full_dicts import face, NAIL_SHAPE_EN_FULL, NAIL_FIN_EN_FULL, HAIR_EN_FULL, HAIR_COLOR_EN_FULL, SHOE_EN_FULL, POSE_EN_FULL, AGE_EN_FULL, VIBE_EN_FULL, CRAFT_DB_FULL
from body_full import BODY_FULL, BODY_PREGNANT, BODY_PREGNANT_MORE
import tracker as T

banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","snake","safety pin","gash"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    low = p.lower()
    hits = [w for w in banned if w in low and w not in ("bite","snake")]
    assert not hits, (name,hits)
    risky = ['embroider','weav','woven','textile','stitch']
    rh = [w for w in risky if w in low]
    assert not rh, (name, "FABRIC_WORD", rh)
    lace_bad = re.findall(r'(?<!corset-)\blace\b(?!-up)', low)
    assert not lace_bad, (name, "LACE")

ALL_PREG = {**BODY_PREGNANT, **BODY_PREGNANT_MORE}
PREG_BODIES = list(ALL_PREG.keys())
GEM_EN = {"GD":"diamonds","GP":"pearls","GO":"opals","GA":"amethysts","GR":"rubies","GS":"sapphires","GX":"mixed gems"}
FORM_EN = {"FH":"hoops","FS":"studs","FB":"bars","FC":"clicker rings","FD":"drop dangles","FG":"segment rings","FX":"mixed"}
METAL_EN = {"MG":"gold","MR":"rose-gold","MS":"silver","MC":"copper","MBR":"brass","MBZ":"bronze","MX":"mixed"}
PCOUNT = {"P0":"0","P3":"3","P5":"5","P8":"8","P15":"15","P25":"25","P50":"50","P100":"100","P150":"150","P200":"200"}
JTYPE_EN = {"JE":"earrings","JN":"a necklace","JB":"a bracelet","JR":"a ring","JA":"an anklet","JH":"a hair ornament"}
JMETAL_EN = {"JMG":"gold","JMS":"silver","JMR":"rose-gold","JMP":"platinum","JMX":"mixed-metal"}
JQ_SHORT = {"JQ1":"a single piece","JQ2":"two to three pieces","JQ3":"four to six pieces, layered","JQ4":"seven to ten pieces, heavily stacked","JQ5":"well over ten pieces, an extreme maximalist stack"}
def pierce_phrase(p,f,g,m):
    if p=="P0": return "ears bare, no piercings"
    return f"{PCOUNT[p]} {FORM_EN[f]} piercings set with {GEM_EN[g]} in {METAL_EN[m]}-toned metal"
BELLY_BOOST = "larger and more dramatically rounded than an ordinary full-term pregnancy, projecting forward well beyond the line of her own chest"

PHYSIQUES = [
 ("super hourglass", "waist cinched to absolute impossible minimum, hips AND bust simultaneously flaring to absolute maximum beyond any proportion, most dramatic hourglass ratio ever recorded on any human body, thighs so thick pressing together"),
 ("wide hip narrow", "hips so impossibly wide extending beyond frame creating the most extreme hip-to-waist ratio ever, waist cinched to absolute impossible minimum, upper body slim emphasizing the dramatic hip explosion"),
 ("BBW bombshell", "most massive full-figure BBW body ever at absolute maximum in every dimension, hips so wide beyond proportion dominating the entire frame, bust so enormous overwhelming gravity, waist deeply snatched despite impossible volume"),
 ("curvy petite", "smallest most compact frame possible yet curves exploding at absolute maximum in every direction, bubble butt projecting dramatically backward from the tiny frame, thighs so thick they dwarf the petite frame"),
 ("amazon bombshell", "impossibly tall commanding frame with simultaneously the most massive full-figure curves, enormous powerful presence dominating the entire frame top to bottom, legs endlessly long massively thick and powerful"),
]
HAIRS_MX = ["long sleek jet-black hair cascading past hips","silver-white natural hair swept into a high sculpted crown","loose beach waves mid-length tousled","blunt collarbone-length bob thick heavy","silver-white locs cascading to her waist"]
POSES_MX = ["strong hip pop right, both hands pressing sides of hips outward simultaneously arching back to extreme",
 "full frontal wide stance, both fists pressing outer hips outward to absolute maximum",
 "standing full height, both arms slightly spread commanding the frame",
 "back three-quarter turned, face over shoulder direct eye contact, bubble butt projected backward",
 "strong hip pop left, both hands pressing outer hips outward arching back to extreme"]
AGES_MX = ["early 20s","late 20s","early 30s","mid 30s","late 30s","mid 40s","early 50s","mid 50s"]

rnd = random.Random()

def rpick(pool): return rnd.choice(pool)

# ---- 자유축 블록 ----
def bp_block(label):
    makeup = rpick(T.MAKEUP_48); craft = rpick(T.CRAFTS_39)
    nat, fa = face(makeup)
    bodykey = rpick(T.BODY_14); bodytext = BODY_FULL[bodykey]
    cn, cd, cb, cf = CRAFT_DB_FULL[craft]
    nail = f"{NAIL_SHAPE_EN_FULL[rpick(T.NAIL_SHAPES)]} nails, {NAIL_FIN_EN_FULL[rpick(T.NAIL_FINISH)]} finish"
    hair_style = HAIR_EN_FULL[rpick(T.HAIR_STYLE)]; hair_color = HAIR_COLOR_EN_FULL[rpick(T.HAIR_COLOR)]
    age = AGE_EN_FULL[rpick(T.AGE_12)]; vibe = VIBE_EN_FULL[rpick(T.VIBE_5)]
    pose = POSE_EN_FULL[rpick(T.POSE_19)]; shoe = SHOE_EN_FULL[rpick(T.SHOES_24)]
    return (f"{label} (Bodypaint): a real adult {nat} woman in her {age}, her face exactly the same tone as her body, real skin texture with visible pores, {fa}, {vibe}, {hair_color} hair styled in {hair_style}, real living eyes. Long {nail}. "
            f"{bodytext} "
            f"Painted in {cn} ({cd}), wide {cb} bands following every deep crease, dense {cf} filling the space between bands, pigment on living skin, covering her whole body below the jaw with no bare skin anywhere, face unpainted. "
            f"Pose: {pose}. Footwear: extreme {cb} {shoe}.")

def preg_block(label):
    makeup = rpick(T.MAKEUP_48); craft = rpick(T.CRAFTS_39)
    nat, fa = face(makeup)
    bodykey = rpick(PREG_BODIES)
    bodytext = ALL_PREG[bodykey].replace("a high, smoothly rounded pregnant belly", f"a high, smoothly rounded pregnant belly, {BELLY_BOOST},", 1)
    cn, cd, cb, cf = CRAFT_DB_FULL[craft]
    nail = f"{NAIL_SHAPE_EN_FULL[rpick(T.NAIL_SHAPES)]} nails, {NAIL_FIN_EN_FULL[rpick(T.NAIL_FINISH)]} finish"
    hair_style = HAIR_EN_FULL[rpick(T.HAIR_STYLE)]; hair_color = HAIR_COLOR_EN_FULL[rpick(T.HAIR_COLOR)]
    age = AGE_EN_FULL[rpick(T.AGE_12)]; vibe = VIBE_EN_FULL[rpick(T.VIBE_5)]
    shoe = SHOE_EN_FULL[rpick(T.SHOES_24)]
    pierce = pierce_phrase(rpick(T.PIERCE_P), rpick(T.PIERCE_F), rpick(T.PIERCE_G), rpick(T.PIERCE_M))
    jq = rpick(list(T.JEWELRY_QTY.keys())) if isinstance(T.JEWELRY_QTY, dict) else rpick(T.JEWELRY_QTY)
    jtype = rpick(['JE','JN','JB','JR','JA','JH']); jmetal = rpick(['JMG','JMS','JMR','JMP','JMX'])
    jewelry = f"{JQ_SHORT[jq]} of {JMETAL_EN[jmetal]} {JTYPE_EN[jtype]}"
    return (f"{label} (Pregnant): {nat}, in her {age}, {vibe} expression, warm radiant skin tone, extraordinarily large pregnant physique far beyond any real person — {bodytext} "
            f"Her face is a real living adult face, {fa}, {hair_color} hair styled in {hair_style}, real pores, real living eyes, {pierce}, wearing {jewelry}. "
            f"Painted in {cn}, {cd}, covering every inch of skin from neck to ankle, wide {cb} bands curving fully around her belly, the densest concentration of {cf} wrapping the belly as centrepiece and continuing over her bust, nowhere left bare. "
            f"Pose: standing frontal, both hands cradling the underside of her belly, extreme {cb} {shoe}.")

# ---- 맥시멀리스트 블록 ----
IREZUMI_MOTIFS = [
 ("dragon phoenix", "BLAZING ELECTRIC GOLD dragon coiling the full torso and both legs neck to ankle, VIVID CRIMSON phoenix wings spreading across the full chest"),
 ("koi sakura", "BLAZING CRIMSON koi ascending spiral full torso both legs neck to ankle, VIVID PINK sakura petal cascade filling every gap"),
 ("chrysanthemum", "BLAZING DEEP GOLD chrysanthemum blooms enormous layered petals full torso both legs neck to ankle, VIVID EMERALD leaf lattice filling every gap"),
 ("wisteria", "BLAZING ELECTRIC VIOLET wisteria cascading full torso both legs neck to ankle, STARK WHITE highlight detail filling every gap"),
 ("plum crane", "BLAZING VIVID CRIMSON plum blossom storm full torso both legs neck to ankle, VIVID GOLD crane pair soaring filling every gap"),
 ("peony", "BLAZING VIVID PINK peony blooms cascading full torso both legs neck to ankle, ELECTRIC GOLD centre highlights filling every gap"),
]
def irezumi_block(label):
    idx = rnd.randrange(5)
    phy_name, phy_detail = PHYSIQUES[idx]
    motif_name, motif_ink = rpick(IREZUMI_MOTIFS)
    return (f"{label} (Irezumi): THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {rpick(AGES_MX)} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {HAIRS_MX[idx]} — full body {motif_name} irezumi covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Bold black ink outlines — {motif_ink}, NO airbrush NO gradient wash. Pose: {POSES_MX[idx]} — most extreme {phy_name} silhouette ever displayed. Footwear: platform boots 8 inch, extra long stiletto nails to match.")

UV_MOTIFS = [
 ("cosmic nebula", "ELECTRIC MAGENTA nebula cloud formations swirling across the chest and upper body, VIVID NEON CYAN plasma stream formations flowing down both legs, BLAZING NEON GOLD star cluster formations filling every gap"),
 ("lightning web", "ELECTRIC EMERALD lightning bolt formations branching across the full torso both legs neck to ankle, VIVID NEON YELLOW spark burst formations filling every gap"),
 ("crystal lattice", "ELECTRIC VIOLET geometric lattice facets full torso both legs to ankle, prismatic crystal faces refracting CYAN light"),
 ("ocean wave", "ELECTRIC CYAN ocean wave formations flowing organically full torso both legs neck to ankle, VIVID WHITE seafoam accent filling every gap"),
]
def uvneon_block(label):
    idx = rnd.randrange(5)
    phy_name, phy_detail = PHYSIQUES[idx]
    motif_name, motif_ink = rpick(UV_MOTIFS)
    return (f"{label} (UV Neon): THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {rpick(AGES_MX)} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, UV-reactive BLAZING {HAIRS_MX[idx]} — full body UV neon {motif_name} bodypaint covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Bold formations — BLAZING {motif_ink}, NO airbrush NO gradient wash. Pose: {POSES_MX[idx]} — most extreme {phy_name} silhouette ever displayed. Under her own dedicated UV blacklight spot, zero white light reaching her specifically. Footwear: platform boots 8 inch, extra long stiletto nails BLAZING NEON UV reactive tips.")

GLASS_COLORS = [("ELECTRIC CRIMSON","VIVID GOLD"),("ELECTRIC VIOLET","VIVID CYAN"),("ELECTRIC EMERALD","VIVID GOLD"),("ELECTRIC MAGENTA","VIVID SILVER")]
def glass_block(label):
    idx = rnd.randrange(5)
    phy_name, phy_detail = PHYSIQUES[idx]
    c1,c2 = rpick(GLASS_COLORS)
    return (f"{label} (Stained Glass): THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {rpick(AGES_MX)} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {HAIRS_MX[idx]} — full body stained glass covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is solid thick glass fused directly to her form, not a garment, made of hundreds of small individual panes each no larger than a coin, densely packed edge to edge, never large sheets, each tiny pane curving to follow her body's true shape with real physical thickness, dark lead-line seams webbing between every pane, each seam standing in a small raised ridge casting its own shadow, never flat. BLAZING {c1} and VIVID {c2} panes alternating in a dense irregular mosaic, bright light passing through each tiny pane with sharp refraction glints, NO airbrush NO gradient wash. Pose: {POSES_MX[idx]} — most extreme {phy_name} silhouette ever displayed. Footwear: leaded-glass platform boots 8 inch, the same dense small-pane mosaic continuing onto the shoe, extra long stiletto nails to match.")

LEAF_COLORS = [("ELECTRIC CRIMSON","GOLD"),("ELECTRIC VIOLET","CYAN"),("ELECTRIC EMERALD","GOLD"),("ELECTRIC MAGENTA","SILVER")]
def goldleaf_block(label):
    idx = rnd.randrange(5)
    phy_name, phy_detail = PHYSIQUES[idx]
    c1,c2 = rpick(LEAF_COLORS)
    return (f"{label} (Gold Leaf): THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {rpick(AGES_MX)} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {HAIRS_MX[idx]} — full body applied {c1} leaf covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE. Thin irregular metallic sheets — BLAZING {c1} leaf with fine natural creases and overlapping seams, VIVID {c2} undertone glinting through the thinnest points, a soft warm metallic sheen filling every gap, NO airbrush NO gradient wash. Pose: {POSES_MX[idx]} — most extreme {phy_name} silhouette ever displayed. Footwear: platform boots 8 inch, extra long stiletto nails to match.")

FLOWERS = [("peony","CRIMSON","EMERALD"),("orchid","VIOLET","GOLD"),("sakura","PINK","GOLD"),("lotus","PINK","JADE")]
def botanical_block(label):
    idx = rnd.randrange(5)
    phy_name, phy_detail = PHYSIQUES[idx]
    flower,c1,c2 = rpick(FLOWERS)
    return (f"{label} (Botanical): THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {rpick(AGES_MX)} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, hair threaded through with real trailing vines — full body living {flower} growing directly from her own skin covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not a printed pattern, not a dress, every stem rooted directly into her living skin and every petal standing up in true three-dimensional relief casting its own small shadow, nothing lying flat. BLAZING {c1} {flower} blossoms in full three-dimensional bloom, VIVID {c2} leaves and curling tendrils filling every remaining gap with real depth and texture, NO airbrush NO gradient wash, NO flat printed surface anywhere. Pose: {POSES_MX[idx]} — most extreme {phy_name} silhouette ever displayed. Footwear: extreme platform heels entirely overgrown with the same living {flower} blooms and vines, extra long nails with tiny petals embedded at each tip.")

TRACK_FN = {"bp": bp_block, "preg": preg_block, "ire": irezumi_block, "uv": uvneon_block, "glass": glass_block, "gold": goldleaf_block, "bot": botanical_block}
TRACK_KO = {"bp":"바디페인팅","preg":"임산부","ire":"이레즈미","uv":"UV네온","glass":"스테인드글라스","gold":"금박","bot":"보태니컬"}
LABELS5 = ["#1","#2","#3","#4","#5"]
NUM_WORD = {2:"TWO",3:"THREE",4:"FOUR",5:"FIVE"}
ASPECT = {2:"3:4",3:"4:5",4:"4:5",5:"5:4"}

def build_image(track_keys):
    n = len(track_keys)
    order = track_keys[:]
    rnd.shuffle(order)  # 배치 랜덤화
    labels = LABELS5[:n]
    blocks = [TRACK_FN[order[i]](labels[i]) for i in range(n)]
    body = "\n\n".join(blocks)
    p = f"""Professional fashion photograph, full body shot. {NUM_WORD[n]} women standing side by side, each from a different Living Artifact track.

{body}

MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. Composition: each woman's own pose as described, inner arms not crossing her neighbours. Lighting: a single hard key light raking across all bodypaint/pregnant/irezumi/stained-glass/gold-leaf/botanical women from one side, realistic photographic grain where applicable, extreme high-gloss oil on maximalist tracks — a real photograph, not an illustration, not CGI, not a render; any UV Neon track woman additionally lit by her own dedicated UV blacklight spot. Pattern density maximum on all {n}, zero bare skin from neck to ankle. Shot on a Hasselblad X2D, {ASPECT[n]} aspect ratio."""
    return p, order

# ===== 1) 7개 고정조합 × 30개 = 210개 =====
FIXED_COMBOS = [
 ("3a_bp2preg1", ["bp","bp","preg"]),
 ("3b_preg2bp1", ["preg","preg","bp"]),
 ("3c_preggoldbot", ["preg","gold","bot"]),
 ("4a_bpppregireuv", ["bp","preg","ire","uv"]),
 ("4b_ireuvglassgold", ["ire","uv","glass","gold"]),
 ("5a_bpppregireuvglass", ["bp","preg","ire","uv","glass"]),
 ("5b_ireuvglassgoldbot", ["ire","uv","glass","gold","bot"]),
]

all_presets = []
TYPE_NAME = {2:"duo",3:"trio",4:"quartet",5:"quintet"}

for combo_key, tracks in FIXED_COMBOS:
    n = len(tracks)
    type_name = TYPE_NAME[n]
    for slot in range(1,31):
        p, order = build_image(tracks)
        check(f"{combo_key}_{slot}", p)
        key = f"la_mix3_{combo_key}_{slot:02d}"
        tracks_ko = "+".join(TRACK_KO[t] for t in order)
        all_presets.append({
            "key": key,
            "category": "🏺 Living Artifact · Fixed Combo Formula",
            "title": f"{combo_key} #{slot:02d} ({tracks_ko})",
            "prompt": p,
            "meta": {"group_size": n, "aspect_ratio": ASPECT[n], "format": "fixed-combo-random-order", "tracks": order}
        })

print("고정조합:", len(all_presets), "개")

# ===== 2) 완전 랜덤조합(2~5인) × 30개 = 120개 =====
ALL_TRACKS = ["bp","preg","ire","uv","glass","gold","bot"]
for n in [2,3,4,5]:
    type_name = TYPE_NAME[n]
    for slot in range(1,31):
        tracks = rnd.sample(ALL_TRACKS, n) if n <= len(ALL_TRACKS) else [rnd.choice(ALL_TRACKS) for _ in range(n)]
        p, order = build_image(tracks)
        check(f"rand_{n}_{slot}", p)
        key = f"la_mixedrand_{type_name}_{slot:02d}"
        tracks_ko = "+".join(TRACK_KO[t] for t in order)
        all_presets.append({
            "key": key,
            "category": "🏺 Living Artifact · Random Combo Formula",
            "title": f"Random {type_name.capitalize()} #{slot:02d} ({tracks_ko})",
            "prompt": p,
            "meta": {"group_size": n, "aspect_ratio": ASPECT[n], "format": "fully-random-combo", "tracks": order}
        })

print("합계:", len(all_presets), "개")

with open("/home/claude/glassface/la_330_bundle.json","w",encoding="utf-8") as f:
    json.dump(all_presets, f, ensure_ascii=False, indent=2)
print("저장 완료")
