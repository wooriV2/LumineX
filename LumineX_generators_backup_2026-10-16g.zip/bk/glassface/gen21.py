# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g3 = load("g3","gen3.py"); g2 = load("g2","gen2.py")
MAT = g2.MAT

# ---------------- 힙 버전: 홍콩풍 · 나전칠기 바디페인팅 × 비취 조각상 ----------------
nat, mk, fc = g3.face_of("홍콩풍")
jn, jdesc, jinner = MAT["jade"]
HIP = f"""Professional fashion photograph, double portrait, three-quarter body shot. TWO figures standing side by side, shoulder to shoulder, both angled 45 degrees toward the camera, framed from the very top of their heads down through the hips, the frame cutting off across the upper thighs. Both faces are large and sharp in the upper part of the frame.

The left figure is a real living woman: a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}. Her face is left clear and is entirely real living skin with real pores and fine grain, real living eyes and real lips. On each ear she wears a large real vintage pearl clip earring. The rest of her is a real body covered in full-body najeon mother-of-pearl body painting: a glossy black lacquer ground with shimmering iridescent arabesque vines, peonies and cranes glowing pink, aqua and silver, the pigment lying directly on her real skin, the real curves of her body clearly visible beneath it. The design runs continuously over every surface with no bands and no borders anywhere, dense shell scrollwork fills every gap so no plain lacquer is left, and it reaches every part of her below the jaw — the shoulders, the upper arms, the forearms, the backs of the hands, the chest, the belly, the sides, the hips and the tops of the thighs — as densely as everywhere else. The painting softens away at the neck, and her face stays clear.

The right figure is her exact twin as a sculpture: the same face, the same expression, the same body and the same waved hairstyle, the same pose mirrored, carved as one solid statue of deep green jade with nothing beneath and no skin anywhere — {jdesc}, with {jinner}. The statue is sculpted with the fine detail of a master portrait sculptor, with polished clear-green gem irises for eyes, the makeup as colour inside the stone (thin arched brows as raised lines, a deep red glow in the carved lips, a warm tone in the cheeks), and the same pearl clip earrings — real pearls and metal on drilled openings in the stone. The pattern of the painting appears on the statue only as fine engraved lines cut into the surface, catching the light, so the statue is carved and never painted.

The statue is unmistakably a solid three-dimensional carved object, and the real woman is unmistakably alive — warm skin, moist eyes, individual hair strands. Their shoulders touch, their outer hands rest on their flared hips and their inner arms hang relaxed at their sides. Both figures are equally sharp.

Lighting: pure pitch black background. A soft warm frontal light on the real woman's face and the pearl shimmer of her body painting; a strong soft green backlight through the jade so the statue glows from within; a thin cool rim light along the statue's edge. 2:3 vertical 8K portrait."""

# ---------------- 전신 버전: 화환 화장 · 청화백자 바디페인팅 × 호박 조각상 ----------------
nat2, mk2, fc2 = g3.face_of("화환 화장(우크라이나)")
an, adesc, ainner = MAT["amber"]
FULL = f"""Professional fashion photograph, double portrait, full body shot, head to toe. TWO figures standing side by side with a small gap between them, both angled 45 degrees toward the camera, the camera set back so both whole bodies fit in the frame from the top of their heads to their feet. Both faces stay sharp.

The left figure is a real living woman: a towering, strikingly beautiful adult {nat2} woman in {mk2} makeup — {fc2}. Her face is left clear and is entirely real living skin with real pores and fine grain, real living eyes and real lips. On each ear she wears a big real silver hoop with a small red-enamel bead. The rest of her is a real body covered in full-body blue-and-white porcelain body painting: a brilliant white ground with cobalt peony scrolls, lotus, vines and cranes, the pigment lying directly on her real skin, the real shape of her body clearly visible beneath it. The design runs continuously over every surface with no bands and no borders anywhere, dense scrollwork fills every gap so no plain white is left, and it reaches every part of her below the jaw — the shoulders, the upper arms, the forearms, the backs of the hands, the chest, the belly, the sides, the hips, the thighs, the knees, the calves and the tops of the feet — as densely as everywhere else. The painting softens away at the neck, and her face stays clear. She stands tall on long legs, never short or squat, in real extreme platform stiletto sandals of glossy black leather.

The right figure is her exact twin as a sculpture: the same face, the same expression, the same body and height, the same braid and flower wreath, the same pose mirrored, carved as one solid statue of deep honey-gold amber with nothing beneath and no skin anywhere — {adesc}, with {ainner}. The statue is sculpted with the fine detail of a master portrait sculptor, with polished amber-clear gem irises for eyes, the makeup as colour inside the amber, and the same silver hoops as real metal on drilled openings in the amber. Her wreath is carved of the same amber, its poppies, cornflowers and wheat ears each a chiselled shape of solid amber. Her platform stiletto sandals are carved from the same amber as her legs, the material running unbroken through the ankle, the instep and every toe. The pattern of the painting appears on the statue only as fine engraved lines cut into the surface, catching the light, so the statue is carved and never painted.

The statue is unmistakably a solid three-dimensional carved object, and the real woman is unmistakably alive — warm skin, moist eyes, individual hair strands, and a wreath of real red poppies, blue cornflowers and wheat ears. Both stand with feet planted apart, their outer hands resting on their flared hips and their inner arms hanging relaxed at their sides, their hands well away from their faces. Both figures are equally sharp.

Lighting: pure pitch black background. A soft warm frontal light on the real woman; a strong warm backlight through the amber so the statue glows honey-gold from within; a thin cool rim light along the statue's edge. 2:3 vertical 8K portrait."""

if __name__ == "__main__":
    for n, p in (("HIP", HIP), ("FULL", FULL)):
        print(n, len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
