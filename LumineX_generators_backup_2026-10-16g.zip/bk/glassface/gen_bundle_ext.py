# -*- coding: utf-8 -*-
import re, sys, os, random, json, collections
os.chdir('/home/claude/glassface'); sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/diversity')
# ===== 재질 프레임 확장 =====
_src = open('gen_bundle_statue.py', encoding='utf-8').read().split("# ----- 배정 -----")[0]
sys.argv = [sys.argv[0], "20261410"]
exec(_src)                                  # S·X·Y·GR·R·boundary_variant·jewelry·finish·phys_tag·PLEV·FRKO ...
CM = {"__name__": "ns"}; exec(open('gen_pierce_waist.py', encoding='utf-8').read().split("\nspecs = [")[0], CM)
LEG_A = " (no shins, no ankles and no real skin legs of any kind — below each rounded tip there is only the glossy floor)"
def tq_reinforce(p, kind):
    if kind == "single":
        a = "nothing continues below either tip"; assert a in p; return p.replace(a, a + LEG_A, 1)
    a = "both rounded tips resting side by side on the surface beneath her."; assert a in p
    return p.replace(a, a + " Below each rounded tip there is nothing at all — no shins, no ankles, no feet and no real skin legs; only the glossy floor.", 1)
OBS_V1 = "polished black obsidian stone carved as a mosaic of many large fitted sections, divided by wide, bright molten-gold seams about the width of a finger running between every section, a dense network of gold lines covering her whole body from the collarbones to the thigh tips"
NEWM = {"glass": "스테인드글라스", "scale_koi": "비늘(잉어)", "scale_dragon": "비늘(용)", "scale_mermaid": "비늘(인어)", "obsidian": "흑요암+금빛 이음새"}
def new_single(frame, mkey, P, idx):
    method = "집중형" if P in ("P8", "P25") else "정의형"; ko = NEWM[mkey]
    if mkey == "glass":
        S["MAT"]["_new"] = ("stained glass", re.sub(r"^solid\s+", "", CM["mat_text"]("glass")[0]), "dark lead-line seams webbing between every pane")
        p, d, mname = S["build"](frame, P, method, "T1", "_new")
    else:
        txt = OBS_V1 if mkey == "obsidian" else re.sub(r"^solid\s+", "", CM["mat_text"](mkey)[0])
        S["STONES"][:] = [(mkey.replace("_", " "), txt)]
        p, d, mname = S["build"](frame, P, method, "stone", 0)
        assert "one solid opaque stone, solid " in p; p = p.replace("one solid opaque stone, solid ", "one solid opaque sculpted mass, solid ", 1)
    p = boundary_variant(p, "cur")
    if frame == "tq": p = tq_reinforce(p, "single")
    jew = None
    if R.random() < 0.4:
        types = R.sample(["N", "B", "R", "H"], R.choice([2, 3, 4])); jew = (types, R.randint(1, 5), R.choice(list(JMET)))
    ear = R.random() < 0.2; p = finish(p, jew, ear)
    jko = ("쥬얼리 " + "·".join(JKO[t] for t in jew[0]) + f" JQ{jew[1]}") if jew else "쥬얼리 없음"
    title = f"Piercing Statue Ext Solo #{idx:03d} ({FRKO[frame]} · {P} {method} · 단일 재질 {ko} · 체형 {phys_tag(p)} · {d} · {jko}{' · 귀 보이기' if ear else ''})"
    return title, p, {"group_size": 1, "aspect_ratio": "2:3", "format": "piercing-statue", "frame": frame, "piercing": P, "structure": "single-new", "material": mkey, "jewelry": bool(jew), "pose": "ear" if ear else "stand"}
def big_p(frame, structure, P, idx):
    method = "정의형"
    if structure == "mix5": p, d, pk = X["build"](frame, P, method); sd = f"5재질 혼합 · {pk}"
    else: p, d, pk = Y["build"](frame, P, method, R.choice(["H", "V", "D"])); sd = f"몸통 3조각 · {pk}"
    p = boundary_variant(p, "cur")
    if frame == "tq": p = tq_reinforce(p, "mix")
    jew = None
    if R.random() < 0.4:
        types = R.sample(["N", "B", "R", "H"], R.choice([2, 3, 4])); jew = (types, R.randint(1, 5), R.choice(list(JMET)))
    ear = R.random() < 0.2; p = finish(p, jew, ear)
    jko = ("쥬얼리 " + "·".join(JKO[t] for t in jew[0]) + f" JQ{jew[1]}") if jew else "쥬얼리 없음"
    title = f"Piercing Statue Ext Solo #{idx:03d} ({FRKO[frame]} · {P} {method} · {sd} · 체형 {phys_tag(p)} · {d} · {jko}{' · 귀 보이기' if ear else ''})"
    return title, p, {"group_size": 1, "aspect_ratio": "2:3", "format": "piercing-statue", "frame": frame, "piercing": P, "structure": structure, "jewelry": bool(jew), "pose": "ear" if ear else "stand"}
plan = []
mats = ["glass"] * 8 + ["scale_koi"] * 7 + ["scale_dragon"] * 7 + ["scale_mermaid"] * 7 + ["obsidian"] * 7
for i, m in enumerate(mats): plan.append(("new", ["demi", "tq"][i % 2], m, ["P8", "P25", "P50", "P100"][i % 4]))
for i in range(6): plan.append(("big", "demi", "mix5", "P200"))
for i in range(6): plan.append(("big", "tq", "mix5", "P150"))
for i in range(6): plan.append(("big", "tq", "mix5", "P200"))
for i in range(3): plan.append(("big", "demi", "split3", "P200"))
for i in range(3): plan.append(("big", "tq", "split3", "P200"))
R.shuffle(plan)
CAT = "🏺 Living Artifact · Piercing Statue Formula"; items = []; seen = set(); fails = collections.Counter(); n = 0
for kind, a, b, c in plan:
    for attempt in range(8):
        try:
            t, p, m = new_single(a, b, c, n + 1) if kind == "new" else big_p(a, b, c, n + 1); break
        except (AssertionError, KeyError) as e: fails[str(e)[:60]] += 1
    else: raise SystemExit(f"실패 {kind} {a} {b} {c} {fails.most_common(3)}")
    n += 1; assert p not in seen; seen.add(p)
    items.append({"key": f"la_pstatue_ext_{n:03d}", "category": CAT, "title": t, "prompt": p, "meta": m})
json.dump(items, open("/mnt/user-data/outputs/la_pstatue_ext_60_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
wc = [len(x["prompt"].split()) for x in items]
print("Statue 확장:", len(items), "| 단어", min(wc), sum(wc)//len(wc), max(wc), "| 재시도", dict(fails.most_common(3)), "| 구조", dict(collections.Counter(x["meta"]["structure"] for x in items)), "| 프레임", dict(collections.Counter(x["meta"]["frame"] for x in items)))
# ===== 실사 크롭 확장: 맥시멀리스트 메이크업 얼굴 컷 =====
sys.argv = [sys.argv[0], "20261411"]
_src2 = open('gen_bundle_frame.py', encoding='utf-8').read().split("P_ALL = [")[0]
exec(_src2)                                  # C·M_·GR·R·TRACKS 함수(maximalist ...)
for ns in (C,): ns["rnd"].seed(20261412)
R2 = random.Random(20261413)
TONEWORDS = re.compile(r"skin|complexion|tanned|porcelain|\bfair\b|\bpale\b|\bolive\b|bronze|tan\b|suntan", re.I)
mk_pool = [m for m in C["T"].MAKEUP_48 if "파키스탄" not in m and "Pakistan" not in m]
def makeup_clauses(mk):
    nat, fa = C["face_nohair"](mk); parts = [x.strip() for x in fa.split(", ")]; keep = [x for x in parts if not TONEWORDS.search(x)]
    return ", ".join(keep)
frame_items = []; seen2 = set(); tones = ["블루블랙"] * 30 + ["에보니 브라운"] * 10 + ["올리브"] * 10 + ["포셀린"] * 10; R2.shuffle(tones)
for i, tone in enumerate(tones):
    P = R2.choice(["P25", "P50", "P100"]); jew = (R2.randint(1, 5), R2.choice(list(JMET))) if R2.random() < 0.5 else None
    for attempt in range(8):
        try:
            mk = R2.choice(mk_pool); mkt = makeup_clauses(mk); assert mkt and not TONEWORDS.search(mkt)
            p, d, M = C["maximalist"]("face", P, tone, None, jew); old = ", full lips, a bold, commanding expression"; assert old in p
            p = p.replace(old, f", full lips, {mkt}, a bold, commanding expression", 1)
            p = C["dd"](p).replace(",,", ",").replace(".,", ","); _d = [m.group(0) for m in re.finditer(r"\b(\w+) \1\b", p)]
            assert not re.search(r"[가-힣]", p) and not _d and p not in seen2; break
        except (AssertionError, KeyError) as e: pass
    else: raise SystemExit("메이크업 번들 실패")
    seen2.add(p); method = "집중형" if P in ("P8", "P25") else "정의형"
    frame_items.append({"key": f"la_pframe_maxmk_{i+1:03d}", "category": "🏺 Living Artifact · Piercing Frame Formula", "title": f"Piercing Frame Solo MaxMakeup #{i+1:03d} (맥시멀리스트 얼굴 컷 · {P} {method} · {d} · 메이크업 {mk})", "prompt": p,
                        "meta": {"group_size": 1, "aspect_ratio": "2:3", "format": "piercing-frame", "track": "맥시멀리스트", "frame": "face", "piercing": P, "tone": tone, "makeup": mk}})
json.dump(frame_items, open("/mnt/user-data/outputs/la_pframe_maxmk_60_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
wc = [len(x["prompt"].split()) for x in frame_items]
print("Frame 확장:", len(frame_items), "| 단어", min(wc), sum(wc)//len(wc), max(wc), "| 톤", dict(collections.Counter(x["meta"]["tone"] for x in frame_items)), "| 단계", dict(collections.Counter(x["meta"]["piercing"] for x in frame_items)))
