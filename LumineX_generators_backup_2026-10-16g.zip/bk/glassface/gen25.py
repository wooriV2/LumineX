# -*- coding: utf-8 -*-
import io, contextlib, importlib.util, re
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(m)
    return m
g2 = load("g2","gen2.py"); g3 = load("g3","gen3.py"); g4 = load("g4","gen4.py")
MAT = g2.MAT; BUST_BODY = g2.BODY; FULL_BODY = g4.BODY; WAIST_BODY = g3.WAIST_BODY
REAL_FACE = "Her whole face, ears and neck are real living flesh with real pores and fine grain."

def mats(a, b):
    an, ad, ai = MAT[a]; bn, bd, bi = MAT[b]
    return an, ad, ai, bn, bd, bi

# ---------------- 카우스틱 (전신) ----------------
def caustic(sty, bk, a, b, ear, setting):
    nat, mk, fc = g3.face_of(sty)
    an, ad, ai, bn, bd, bi = mats(a, b)
    return f"""Professional fashion photograph, full body shot, head to toe. ONE woman standing, angled 45 degrees toward the camera, the camera set back so her whole body fits in the frame from the top of her head to her feet and the floor and wall around her are visible, her face still sharp. Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}. {REAL_FACE} {ear} Real jewelry on real skin, healed, clean and calm.

Physique: {FULL_BODY[bk][1]}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid transparent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest, belly, left hip and the whole left leg down through the foot): solid {ad}, with {ai}. Right half: solid {bd}, with {bi}. Each is carved as one solid sculpted mass like a statue, never hollow. The arms flow into the torso and the torso into the legs with no seam, and every wrist, palm, finger, knuckle and toe is the same material as its limb. Her extreme platform stiletto sandals are carved from the same material as the leg each one sits under, running unbroken through the ankle and every toe.

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down the centre of the body, between the hips and legs and down to the floor, where the two materials meet, never horizontal. Shards interlock along the lines only, every edge solid all the way through.

Setting and light: {setting} Her real face stays softly lit from the front.

Pose: body angled 45 degrees, feet planted apart, her left hand (solid material) resting on her flared hip, her right arm held clear of her body with the hand (solid material) relaxed at hip height, well away from her face, head tilted slightly toward the camera. Only her face, ears and neck read as real skin. 2:3 vertical 8K portrait."""

C1 = caustic("텔레노벨라 글램(멕시코·콜롬비아)","colo","cobalt","citrine",
  "On each ear a large gold hoop.",
  "she stands on a matte pale-grey studio floor in front of a plain pale-grey wall, lit by one strong hard cool-white light from the upper right behind her. The light passes through her transparent body and throws long, sharply coloured caustic shadows across the floor and the wall — deep blue patches from the cobalt glass side and warm yellow patches from the citrine side, each with bright bending edges of concentrated light.")
C2 = caustic("홍콩풍","tent","ruby","aquamarine",
  "On each ear a large vintage pearl clip earring.",
  "she stands on a warm cream plaster floor in front of a warm cream plaster wall, lit by one strong hard low golden light from the right behind her. The light passes through her transparent body and throws long, sharply coloured caustic shadows across the floor and the wall — deep crimson patches from the ruby glass side and cool teal patches from the aquamarine side, with bright bending edges of concentrated light, and where the two colours overlap they mix into soft violet.")
C3 = caustic("락혼 글램(태국)","top","resin","murano",
  "On each ear a big gold hoop with a chased-gold drop.",
  "she stands on a pure white studio floor in front of a pure white wall, lit by one strong hard white light from the upper left behind her. The light splits into full rainbow spectral bands as it passes through the clear resin and the Murano glass, casting bands of red, orange, yellow, green, blue and violet across the floor and the wall, with bright bending edges of concentrated light.")

# ---------------- 성장 축 (식물·동물) ----------------
def growth(sty, frame, bk, a, b, ear, para_title, para, pose_note):
    nat, mk, fc = g3.face_of(sty)
    an, ad, ai, bn, bd, bi = mats(a, b)
    if frame == "waist":
        frame_txt = "upper-body shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head down to the middle of her belly, the frame cutting off across the belly so no hips, legs or feet are visible. Her face sits in the upper part of the frame."
        body = WAIST_BODY[bk][1]
        carve = "the chest two great rounded masses and the belly folds cut into the material itself"
        line = "the centre of the chest and belly"
    else:
        frame_txt = "bust shot. ONE woman, angled 45 degrees toward the camera, framed from the very top of her head to just below her chest, the frame cutting off beneath the chest. Her face sits large and sharp in the upper half of the frame."
        body = BUST_BODY[bk][1]
        carve = "the chest two great rounded masses with the groove between them cut into the material itself"
        line = "the centre of the chest"
    return f"""Professional fashion photograph, {frame_txt} Mid 20s.

Subject: A real photograph of a strikingly beautiful adult {nat} woman in {mk} makeup — {fc}. {REAL_FACE} {ear} Real jewelry on real skin, healed, clean and calm.

Physique: {body}

Below the neck: from the collarbones down her body is not painted, covered or clothed — it is physically made of two solid translucent materials split down the centre, with nothing beneath and no skin anywhere. Left half (left shoulder, the whole arm and hand, half the chest{' and belly' if frame=='waist' else ''}): solid {ad}, with {ai}. Right half: solid {bd}, with {bi}. Each is carved as one solid sculpted mass like a statue, never hollow, {carve}. The arms flow into the torso with no seam, and every wrist, palm, finger and knuckle is the same material as its arm.

{para_title}: {para}

Boundary: a sharp jagged line runs around the base of the neck and across both collarbones — real skin above, material immediately below. A second jagged line runs down {line} and out of the bottom of the frame where the two materials meet, never horizontal. Shards interlock along the lines only.

Pose: body angled 45 degrees, her left hand (solid material) held low at the frame edge beside her {'belly' if frame=='waist' else 'chest'}, her right hand (solid material) held at chest height clear of her body, well away from her face, head tilted slightly toward the camera. {pose_note}

Lighting: pure pitch black background. A soft frontal light on her face and ears; a strong backlight through each half so both glow from within and whatever grows or rests on the material is lit from behind; a thin cool rim light along the centre line. 2:3 vertical 8K portrait."""

V1 = growth("웨이쉰","waist","hgu","smoky","emerald",
  "On each ear a big rose-gold hoop hangs clear of the neck down to the shoulder.",
  "Growth",
  "real plants grow out of the material below the collarbones, rooted in fine cracks inside the material, their pale roots visible as threads through it. On the left smoky glass, a branch of cherry blossom with pale pink blossoms, buds and bronze-green leaves grows out of the shoulder and arches over the upper arm, with a few petals drifting down beside the chest. On the right emerald, a shorter branch of white plum blossom rises from the shoulder. The leaves and petals are real and soft. The plants grow only from the shoulders, arms and chest — never on the neck, the face or the hair, and never covering the hands.",
  "")
V2 = growth("프렌치 레드립(프랑스)","bust","bust","glacial","amethyst",
  "A single thick gold hoop hangs on each ear.",
  "Growth",
  "real roses grow out of the material below the collarbones, rooted in fine cracks inside the material, their pale roots visible as threads through it. On the left glacial ice, a cane of white roses with dark green leaves and thin stems winds around the shoulder and the upper arm. On the right amethyst, a cane of deep red roses winds around the shoulder and the edge of the chest. The stems coil around the material with small thorns pointing outward, and the flowers are real and soft. The roses grow only from the shoulders, arms and chest — never on the neck, the face or the hair, and never covering the hands.",
  "")
V3 = growth("하베샤 화장(에티오피아·에리트레아)","waist","hgs","aquamarine","amber",
  "On each ear a big silver filigree hoop hangs clear of the neck down to the shoulder.",
  "Growth",
  "real plants grow out of the material below the collarbones, rooted in fine cracks inside the material, their pale roots visible as threads through it. On the left aquamarine, tall fresh ferns unfurl from the shoulder and the upper arm in soft green fronds. On the right amber, stems of lavender with purple flower spikes rise from the shoulder and the edge of the chest. The leaves and flowers are real and soft. The plants grow only from the shoulders, arms and chest — never on the neck, the face or the hair, and never covering the hands.",
  "")
A1 = growth("화환 화장(우크라이나)","waist","musc","amber","aquamarine",
  "On each ear a big silver hoop with a small red-enamel bead hangs clear of the neck down to the shoulder.",
  "Perched creatures",
  "small living creatures rest on the material as if it were a garden statue, real, alive and still. On the left amber, a small blue songbird with a bright yellow chest perches on the shoulder cap, its tiny claws resting on the material and its head turned toward the camera. On the right aquamarine, three orange-and-black butterflies rest with wings half open, two on the upper arm and one on the back of the raised right hand. The creatures are small, sit only on the shoulders, arms and hands, stay well away from her face and neck, and never cover the boundary line or the piercings.",
  "")

ITEMS = [
 ("C1","색 그림자 A","전신","텔레노벨라 · 콜로설 · 코발트 유리 × 시트린 · 회색 스튜디오, 파랑·노랑 그림자",C1),
 ("C2","색 그림자 B","전신","홍콩풍 · 텐트폴 · 루비색 유리 × 아쿠아마린 · 크림색 벽, 진홍·청록 그림자(겹치면 보라)",C2),
 ("C3","색 그림자 C(무지개)","전신","락혼 · 톱헤비 아워글래스 · 투명 레진 × 무라노 유리 · 흰 스튜디오, 프리즘 무지개 그림자",C3),
 ("V1","식물 A(벚꽃)","허리","웨이쉰 · 아워글래스 USSBBW · 스모키 블랙 유리(벚꽃) × 에메랄드(매화)",V1),
 ("V2","식물 B(장미)","가슴","프렌치 레드립 · 바스트 퀸 · 빙하 얼음(흰 장미) × 자수정(붉은 장미)",V2),
 ("V3","식물 C(고사리·라벤더)","허리","하베샤 · 아워글래스 SSBBW · 아쿠아마린(고사리) × 호박(라벤더)",V3),
 ("A1","동물 A(새·나비)","허리","화환 · 머슬 아워글래스 · 호박(파랑 새) × 아쿠아마린(나비)",A1),
]
if __name__ == "__main__":
    for n,t,f,d,p in ITEMS:
        print(n,t,f,len(p.split()), "KOREAN" if re.search(r'[\uac00-\ud7a3]', p) else "")
