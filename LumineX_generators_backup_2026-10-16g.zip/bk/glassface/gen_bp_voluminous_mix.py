# -*- coding: utf-8 -*-
import re, sys
sys.path.insert(0,'.')
from full_dicts import face, CRAFT_DB_FULL
from body_full import BODY_FULL

banned = ["blood","wound","fracture","spike","bite","biting","doll","spalt","rot","decay","fungus","fungal","worm","safety pin","gash","crack"]
def check(name,p):
    assert not re.search(r'[\uac00-\ud7a3]', p), (name,"KOREAN")
    hits = [w for w in banned if w in p.lower()]
    assert not hits, (name,hits)
    risky = ['embroider','woven','textile','stitch']
    rh = [w for w in risky if w in p.lower()]
    assert not rh, (name,"FABRIC",rh)

VOLBODY = ["USSBBW","슈퍼글래머","아마조네스","블랙글래머","머슬아워글래스BBW","헤비머슬"]
MAKEUP = ['하와이안훌라','화환화장','GermanGlam','만바','스페인플라멩코글램','홍콩풍','발칸글램','노르딕발키리','강남언니','서아프리카글램','우즈벡실크로드글램','하베샤화장','텔레노벨라글램','야마바','스칸디프로스트','소피아로렌풍','야미카와','뱀파이어다크']
CRAFTS = ['ItalianDeruta','JapaneseMakie','VasarelyOpArt','RomanianHorezu','KoreanEunipsa','FrenchLimoges','SpanishTalaveraReina','ChineseCizhou','PolishBoleslawiec','MoroccanZellige','IslamicGeometric','CzechBohemian','FilipinoYakan','CroatianHvar','TurkishIznik','NigerianAdire','RussianPalekh','PeruvianNazca','UkrainianPysanka','SwedishKurbits','EscherTessellation','KoreanNajeon','HungarianKalocsa','MexicanTalavera','VietnameseSonMai','PortugueseAzulejo','ThaiBenjarong','YorubaAdireEleko']

def face_c(sty):
    custom = {
     "하와이안훌라": ("Hawaiian","sun-warmed golden skin, a flower tucked behind one ear, a natural dewy glow"),
     "화환화장": ("Thai","warm golden-tan skin, a soft coral lip, delicate floral garland worn in her hair"),
     "만바": ("Japanese","deep tan skin, bold white eyeliner, colorful glittery eyeshadow, a glossy nude lip"),
     "홍콩풍": ("Chinese","fair skin, a bold red lip, retro Hong Kong glamour styling"),
     "발칸글램": ("Serbian","fair olive skin, dramatic smoky eyes, a deep berry lip"),
     "노르딕발키리": ("Norwegian","fair cool-toned skin, icy pale eyeshadow, strong confident brows"),
     "강남언니": ("Korean","flawless porcelain skin, soft gradient lips, elegant refined eyeliner"),
     "서아프리카글램": ("Nigerian","rich deep-brown skin, bold gold-toned eyeshadow, a vivid red lip"),
     "우즈벡실크로드글램": ("Uzbek","warm olive skin, ornate traditional-inspired eye makeup, a deep wine lip"),
     "하베샤화장": ("Ethiopian","warm umber skin, kohl-rimmed eyes, a deep ochre lip, an elegant composed expression"),
     "텔레노벨라글램": ("Mexican","warm bronze skin, dramatic winged eyeliner, a glossy red lip"),
     "야마바": ("Japanese","deep tan skin, bold gyaru makeup, heavy lashes"),
     "스칸디프로스트": ("Swedish","pale cool-toned skin, frosty silver eyeshadow, a soft nude lip"),
     "소피아로렌풍": ("Italian","warm olive skin, dramatic winged eyeliner, a deep red lip"),
     "야미카와": ("Japanese","pale skin, dark circles accentuated, moody pastel makeup, a melancholic wistful expression"),
     "뱀파이어다크": ("Romanian","porcelain-pale skin, dark smoky eyes, a deep crimson lip, dramatic gothic glam"),
    }
    if sty in custom: return custom[sty]
    return face(sty)

def craft_tuple(key):
    return CRAFT_DB_FULL[key]

def person_bodyart_nmix(bodykey, crafts, label=None):
    """n개(2/3/4) 공예를 자유형 경계흐림으로 혼합한 Body Art 문단"""
    n = len(crafts)
    texts = []
    for k in crafts:
        cn,cd,cb,cf = craft_tuple(k)
        texts.append(f"{cn} ({cd}, wide {cb} bands, dense {cf})")
    if n == 2:
        zones = f"her upper body (collarbones to waistline) is painted in {texts[0]}, pigment on living skin. Her lower body (waistline to ankles) is painted in {texts[1]}, pigment on living skin. Rather than a sharp boundary, the two patterns blend gradually into each other across a soft irregular zone a few inches wide at her waistline, motifs from each pattern scattered into the other's territory, density fading rather than stopping abruptly"
    else:
        zone_sent = " ".join(f"{texts[i]} dominates zone {i+1}." for i in range(n))
        zones = f"her skin carries {n} different painted patterns at once, each claiming roughly an equal irregular share of her body rather than any straight line, zones arranged diagonally and asymmetrically. {zone_sent} Wherever any two zones meet, the boundary is soft and diagonal rather than a straight line, motifs blending gradually across an irregular border a few inches wide, pigment on living skin throughout"
    return f"Body Art: {zones}, covering her whole body below the jaw with no bare skin anywhere, face unpainted."

def person_block_full(idx, bodykey, makeup, crafts, label=None):
    nat, fa = face_c(makeup)
    bodytext = BODY_FULL[bodykey]
    prefix = f"{label} woman" if label else "Subject"
    bodyart = person_bodyart_nmix(bodykey, crafts)
    lp = f"{label} woman's " if label else ""
    return (f"{prefix}: a real adult {nat} woman in her early-to-mid 30s, her face exactly the same tone as her body, real skin texture with visible pores, {fa}, confident expression, long dark wavy hair, real living eyes.\n\n"
            f"{lp}physique: An extraordinarily large woman, far beyond any real person. {bodytext}\n\n"
            f"{lp}{bodyart}\n\n"
            f"{lp}pose: full frontal wide stance, both fists pressing outer hips outward." if label else
            f"{prefix}: a real adult {nat} woman in her early-to-mid 30s, her face exactly the same tone as her body, real skin texture with visible pores, {fa}, confident expression, long dark wavy hair, real living eyes.\n\nPhysique: An extraordinarily large woman, far beyond any real person. {bodytext}\n\n{bodyart}\n\nPose: full frontal wide stance, both fists pressing outer hips outward.")

NUM_WORD = {1:"ONE",2:"TWO",3:"THREE"}
ASPECT = {1:"2:3",2:"3:4",3:"4:5"}
LABELS3 = ["Left","Center","Right"]

def build(gsize, mixn, slot_base):
    if gsize == 1:
        bodykey = VOLBODY[slot_base % 6]
        makeup = MAKEUP[slot_base % 18]
        crafts = [CRAFTS[(slot_base*3+i) % len(CRAFTS)] for i in range(mixn)]
        block = person_block_full(slot_base, bodykey, makeup, crafts)
        return f"""Image format: a vertical portrait-orientation photograph, 2:3 aspect ratio, taller than it is wide.

A full-body photograph with a plain seamless deep-charcoal backdrop, shot on a medium format camera with an 85mm lens at f/8, a single hard key light raking in from one side, sharp focus from head to toe, realistic photographic grain — a real photograph, not an illustration, not CGI, not a render.

Subject: {block}

Footwear: Extreme platform heels, the surface blending all painted patterns following the same soft transitions as her skin.

Background & Lighting: the blended painted patterns reading crisp against her skin, the hard raking light carving every fold and curve.

Vertical 2:3 portrait-orientation full-body photograph, taller than it is wide. portrait 2:3 vertical."""
    else:
        blocks = []
        for i in range(gsize):
            idx = slot_base + i
            bodykey = VOLBODY[idx % 6]
            makeup = MAKEUP[idx % 18]
            crafts = [CRAFTS[(idx*3+j) % len(CRAFTS)] for j in range(mixn)]
            blocks.append(person_block_full(idx, bodykey, makeup, crafts, label=LABELS3[i]))
        body = "\n\n".join(blocks)
        return f"""Image format: a landscape-orientation photograph, {ASPECT[gsize]} aspect ratio.

A photograph of {NUM_WORD[gsize]} women standing side by side on a plain seamless deep-charcoal backdrop, nothing else in the frame, 50mm lens at f/8, a single hard key light raking across all of them from one side, sharp focus head to toe on each — a real photograph, not an illustration, not CGI, not a render.

{body}

Composition: each woman's own pose, inner arms not crossing her neighbours, all faces toward the camera.

Lighting: the blended painted patterns reading crisp against each woman's skin, the hard raking light carving every fold and curve. Shot on a Hasselblad X2D, {ASPECT[gsize]} 8K."""

OUT = []
slot = 0
GNAME = {1:"솔로",2:"듀오",3:"트리오"}
for mixn in [2,3,4]:
    for gsize in [1,2,3]:
        for v in range(2):
            p = build(gsize, mixn, slot)
            slot += gsize
            check(f"bpvol_{mixn}_{gsize}_{v}", p)
            OUT.append((f"{mixn}개 공예섞기 {GNAME[gsize]} #{v+1}", p))

for label,p in OUT:
    print(label, len(p.split()))

L = ["# LumineX · 바디페인팅 공예 2/3/4개 섞기 × 솔로/듀오/트리오 각 2개 (부피 큰 체형, 북엔드 구조)\n"]
for label,p in OUT:
    L.append(f"## {label}\n"); L.append("```"); L.append(p); L.append("```\n")
open("/tmp/rep_out/LumineX_Bodypaint_VoluminousMix_18.md","w",encoding="utf-8").write("\n".join(L))
print("saved", len(OUT))
