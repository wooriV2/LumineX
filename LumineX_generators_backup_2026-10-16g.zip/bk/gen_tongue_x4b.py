# -*- coding: utf-8 -*-
import random, re
import cjk_face_lib as C
F, MK = C.load(); MK.update(C.BLACK_MK)
NAT = {"한국": "Korean", "중국": "Chinese", "일본": "Japanese"}
LEN = "stuck out to a natural, realistic length with the tip reaching just below the lower lip"
SPLIT = "the tongue split deeply from the tip back about two-thirds of its length, the two halves clearly separated and curling slightly apart, each half ending in a pointed tip"
RING = "a small matching metal ring through the tip of each half"
CHAIN = "a fine matching chain linking the ring in each tip, hanging in a short curve between the two halves"
SIDE = "three small matching rings along the outer edge of each half"
TRI = "the tongue split into three narrow pointed strands, each about two-thirds of the way back, fanned slightly apart, a small matching ring through the tip of each strand"
def src(lv, jew): return [x for x in F if x["meta"]["piercing"] == lv and (("Jewelry:" in x["prompt"]) == jew)][0]
EY = {"광기": "eyes opened extremely wide with the whites showing all around the irises, a fixed unblinking stare, a wide stretched grin with her mouth open and her tongue ",
      "관능": "heavy-lidded eyes looking straight into the camera, lips parted wide with her tongue ",
      "도발": "heavy-lidded eyes with a provocative stare straight into the camera, mouth wide open with her tongue ",
      "발랄": "wide bright eyes, cheeks lifted by a cheeky grin, mouth wide open with her tongue "}
EN = {"광기": "a manic, unhinged expression", "관능": "a sultry, teasing expression", "도발": "a defiant, provocative expression", "발랄": "a playful, mischievous expression"}
CASES = [(1, "한국", "20대", "광기", f"{LEN}, {SPLIT}, {RING}, {CHAIN}", None, ("P100", True), "깊게 갈라진 혀 + 끝 링 사이 체인"),
         (2, "일본", "30대", "관능", f"{LEN}, {SPLIT}, {RING}", None, ("P150", False), "깊게 갈라진 혀 + 끝 링 (현실적 길이)"),
         (4, "한국", "아이돌", "발랄", f"{LEN}, {SPLIT}, {SIDE}", None, ("P50", True), "깊게 갈라진 혀 + 가장자리 링 3개씩"),
         (6, "중국", "30대", "도발", f"{LEN}, {TRI}", None, ("P100", False), "3갈래 혀 + 갈래마다 링")]
o = ["# 갈라진 혀 극단 표현 새 버전 4개 (1·2·4·6번 대체, 현실적인 길이)\n", "혀 길이를 입 밖으로 아랫입술 아래까지만 나오게 하고, 갈라짐은 깊게(뿌리의 3분의 2) 유지했습니다. 번호는 이전 시험 번호와 같습니다. 정상/이상만 알려주세요.\n"]
for n, nat, grp, ex, tg, mkn, (lv, jew), lab in CASES:
    key = f"tb{n}"; C.EXPR[key] = EY[ex] + tg + ", " + EN[ex]
    t = C.build(src(lv, jew), NAT[nat], grp, key, mkn, MK, random.Random(60 + n))
    assert not re.search(r"[가-힣]", t) and not re.search(r"\b(\w+) \1\b", t), re.findall(r".{20}\b(\w+) \1\b", t)
    o.append(f"## {n}. {nat} · {grp} · {lab} · {'메이크업 ' + mkn if mkn else '메이크업 없음'} · 피어싱 {lv}{'+쥬얼리' if jew else ''}\n\n```\n{t}\n```\n")
    print(n, C.EXPR[key][:420], "\n")
open("/mnt/user-data/outputs/LumineX_Tongue_Extreme4_v2.md", "w", encoding="utf-8").write("\n".join(o))
