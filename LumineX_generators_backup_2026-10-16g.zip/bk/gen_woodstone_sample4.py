# -*- coding: utf-8 -*-
import re, random
Z = "/tmp/claude-0/-home-claude/62db5eea-2487-540b-9935-a7df06448e2a/scratchpad/zipx2/glassface/gen_120_wax_obsidian.py"
src = open(Z, encoding="utf-8").read()
ns = {}
exec(src[:src.index("WAX_COLORS")], ns)
exec(src[src.index("NUM_WORD"):src.index("all_presets = []")], ns)
PH, HAIRS, POSES, AGES, build, check = ns["PHYSIQUES"], ns["HAIRS"], ns["POSES"], ns["AGES"], ns["build"], ns["check"]
WOODS = [("ebony", "deep jet-black ebony", "BLAZING glossy jet-black ebony grain across the full torso both legs neck to ankle", "VIVID dark-brown figure lines running between the carved sections"),
         ("walnut", "rich dark walnut", "BLAZING deep warm-brown walnut grain across the full torso both legs neck to ankle", "VIVID honey-gold highlight streaks running between the carved sections"),
         ("mahogany", "deep reddish mahogany", "BLAZING deep red-brown mahogany grain across the full torso both legs neck to ankle", "VIVID copper highlight streaks running between the carved sections"),
         ("padauk", "vivid orange-red padauk", "BLAZING vivid orange-red padauk grain across the full torso both legs neck to ankle", "VIVID deep burgundy figure lines running between the carved sections"),
         ("purpleheart", "deep violet purpleheart", "BLAZING deep violet purpleheart grain across the full torso both legs neck to ankle", "VIVID lilac highlight streaks running between the carved sections"),
         ("zebrawood", "pale golden zebrawood", "BLAZING pale golden zebrawood grain across the full torso both legs neck to ankle", "VIVID dark-brown zebra stripes running between the carved sections")]
STONES = [("white marble", "polished white marble", "BLAZING pale white marble surface across the full torso both legs neck to ankle", "VIVID golden vein striations flowing through every section"),
          ("black granite", "polished black granite", "BLAZING deep charcoal-black granite surface across the full torso both legs neck to ankle", "VIVID silver mineral fleck detail glinting through every section"),
          ("jade", "polished jade-green stone", "BLAZING deep jade-green stone surface across the full torso both legs neck to ankle", "VIVID pale-green cloudy vein striations flowing through every section"),
          ("lapis lazuli", "polished lapis lazuli", "BLAZING deep royal-blue lapis surface across the full torso both legs neck to ankle", "VIVID golden pyrite flecks scattered through every section"),
          ("malachite", "polished banded malachite", "BLAZING deep emerald-green malachite surface across the full torso both legs neck to ankle", "VIVID pale-green concentric banding swirling through every section"),
          ("rhodonite", "polished rhodonite", "BLAZING rich rose-pink rhodonite surface across the full torso both legs neck to ankle", "VIVID black manganese vein striations flowing through every section")]
def wood_fn(pick):
    nm, desc, base, acc = pick
    def f(label, idx):
        phy_name, phy_detail = PH[idx % 8]; age = AGES[idx % 8]; hair = HAIRS[idx % 8]; pose = POSES[idx % 7]
        mat = (f"full body {desc} wood carved directly over her own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not a printed pattern, this is solid carved wood curving to follow her body's true three-dimensional shape, divided into dozens of fitted carved sections whose grain changes direction from one section to the next, each joint standing in a thin raised ridge catching its own soft glint and casting its own small shadow, nothing lying flat. Dense fitted sections — {base}, {acc}, polished to a warm satin sheen, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
        p = f"{label}: " if label else ""
        return (f"{p}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {hair} — {mat}. Pose: {pose} — most extreme {phy_name} silhouette ever displayed.\n"
                f"{p}extreme platform boots carved from the same {nm} wood, extra long nails in matching polished {nm} wood.")
    return f
def stone_fn(pick):
    nm, desc, base, acc = pick
    def f(label, idx):
        phy_name, phy_detail = PH[idx % 8]; age = AGES[idx % 8]; hair = HAIRS[idx % 8]; pose = POSES[idx % 7]
        mat = (f"full body {desc} fused directly to her own form covering EVERY inch of skin from neck to ankle WITHOUT EXCEPTION, both legs FULLY covered to ankles, NO bare skin below neck ANYWHERE — this is not a garment, not jewelry, not a printed pattern, this is solid stone curving to follow her body's true three-dimensional shape, divided into dozens of fitted stone sections, each joint standing in a thin raised ridge catching its own bright glint and casting its own small shadow, nothing lying flat. Dense fitted sections — {base}, {acc}, high-gloss polished, completely opaque, NO airbrush NO gradient wash, NO flat printed surface anywhere")
        p = f"{label}: " if label else ""
        return (f"{p}THE ABSOLUTE DARKEST BLACK SKIN ON EARTH blue-black void complexion darker than night sky, {age} goddess, {phy_name} physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — {phy_detail}, {hair} — {mat}. Pose: {pose} — most extreme {phy_name} silhouette ever displayed.\n"
                f"{p}extreme platform boots carved from the same {nm}, extra long nails in matching polished {nm}.")
    return f
# (소재 종류, 선택, 인원, 슬롯)
S = [("목재", WOODS[3], 1, 4), ("목재", WOODS[0], 3, 7), ("석재", STONES[3], 1, 5), ("석재", STONES[0], 2, 9)]
o = ["# 목재·석재 단독 보강 샘플 4개\n", "왁스·흑요암과 같은 틀(검은 피부, 순수 검정 배경, 전신 소재)입니다. 번호별로 정상/이상만 알려주세요.\n"]
for i, (kind, pick, n, slot) in enumerate(S, 1):
    fn = (wood_fn if kind == "목재" else stone_fn)(pick)
    t = build(fn, n, slot); check(f"s{i}", t)
    phys = ", ".join(PH[(slot * 3 + j) % 8][0] for j in range(n))
    assert not re.search(r"\b(\w+) \1\b", t), re.findall(r".{20}\b(\w+) \1\b", t)
    ti = f"{kind} {['','솔로','듀오','트리오'][n]} · {pick[0]} · 체형 {phys}"
    o.append(f"## {i}. {ti}\n\n```\n{t}\n```\n"); print(i, ti, len(t.split()))
open("/mnt/user-data/outputs/LumineX_WoodStone_Sample4.md", "w", encoding="utf-8").write("\n".join(o))
