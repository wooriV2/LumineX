import re,random,sys
sys.path.insert(0,'.')
src=open('mk_group5.py',encoding='utf-8').read()
exec(src[:src.index("R=_r.Random(20261013)")])
f6=open('gen_fs6.py',encoding='utf-8').read()
exec(f6[f6.index('TAILO='):f6.index('jobs=[]')])      # TAILO/TAILN, SW, S1, B1, CX
WT_RE=re.compile(r" All the ear weights hang from the bottoms of [^,]*,.*?(?= The face and ear jewelry)",re.S)
BIG_RE=re.compile(r"; its size does NOT shrink.*?unmistakably heavy, ",re.S)
def real2(t):
    t,nB=re.subn(re.escape(S1)+r'\.?',B1.replace('\\','\\\\'),t)
    def fix(m):
        p=m.group(0)
        if re.search(r"Bratz|Barbie|succubus|mermaid siren",p):
            for a,b in SW: p=p.replace(a,b)
            p=p.replace("..",".")
        else:
            for a,b in CX: p=p.replace(a,b)
        return p
    t=re.sub(r"(?<=\n\n#\d: ).*?(?=\n\n#\d )",fix,t,flags=re.S)
    return t,nB
def shorten(t,n):
    t,k=WT_RE.subn("",t)
    t,k2=BIG_RE.subn("; the last weight is as big and heavy-looking as the first, each chain pulled bar-straight and taut, ",t)
    w={2:"six",3:"four"}[n]
    if k:
        t=t.replace("the single iron ring carries all the weights,",f"the single iron ring carries all {w} weights,")
        t=t.replace("the three iron rings share the weights between them",f"the three iron rings share the {w} weights between them")
    return t,k,k2
def sample(R,n):
    spec=draw_spec(R,n)
    ear=R.choices(["iron","mix","one","earring"],[25,35,15,15])[0]; h=R.choices([1,2,3],[75,161,64])[0]; bg=R.choice(BGN)
    for tr in range(300):
        try: t,labs,dup=group3(R.randrange(10**7),spec,"front",ear,h,bg)
        except AssertionError: continue
        mk=[l.split(" · ")[4] for l in labs if "유형 고유 메이크업" not in l]
        if len(set(mk))<len(mk) or sum(m=="메이크업 없음" for m in mk)>1: continue
        if dup and dup.split()[0].lower() not in("had","that"): continue
        break
    else: raise SystemExit("fail")
    return spec,ear,h,bg,t,labs
if __name__=="__main__":
    R=random.Random(20261022)
    o=["# LumineX — Face Sculpt 2인·3인 줄인 샘플 4개 (2인 2 · 3인 2, 전부 랜덤 추첨)\n",
       "- 줄인 곳(문장 추가 없음): ① 인물별 문단 안의 귀 추 목록(추 모양 나열)을 삭제 — 개수와 모양은 공통 문단이 정함 ② 공통 귀 추 문단의 반복 문장(\"크기가 줄지 않는다…몇 킬로 무게…\") 한 줄로 압축 ③ 유형·일반 인물에 1인 번들과 같은 피부·사실감 문구 적용. 인물 구성·국적·메이크업·귀 스타일·배경은 번들 확률로 랜덤 추첨, 한 장면·같은 배경.",
       "- **확인할 것은 3가지만**: (1) 귀 추가 인물마다 무겁게 매달려 보이는지(추 모양이 같아 보이거나 약해지면 이상) (2) 인물들 얼굴이 서로 구분되고 눈·입술 주인공 특징이 살아 있는지 (3) 얼굴 피부가 사진처럼 보이는지(고무·마네킹 느낌이면 이상).",
       "- 정상/이상은 번호로, 이상이면 위 (1)~(3) 중 어느 것인지와 인물 #번호만 한 줄 알려주세요.\n"]
    for idx,n in enumerate([2,3,2,3],1):
        spec,ear,h,bg,t,labs=sample(R,n)
        w0=len(t.split()); t,nB=real2(t); t,k,k2=shorten(t,n)
        t=re.sub(r"  +"," ",t); assert not re.search(r"[가-힣]",t) and "{" not in t
        if ear!="earring": assert k==n,(k,n)
        earlab={"iron":"철 추","mix":"혼합 금속 추","one":"단일 금속 추","earring":"대형 귀걸이"}[ear]
        o.append(f"## {idx}. {n}인 · "+" + ".join(nm for kk,nm in spec)+f" · {earlab}"+("" if ear=="earring" else f" · 귀 구멍 {h}개")+f" · 배경 {bg}")
        for j,l in enumerate(labs,1): o.append(f"- #{j}: {l}")
        o.append(f"- 길이: 기존 방식 {w0}단어 → {len(t.split())}단어\n\n```\n{t}\n```\n"); print(idx,n,ear,h,w0,len(t.split()),"wt",k,"big",k2,"B1",nB)
    open(OUT+'LumineX_FaceSculpt_DuoTrio_Short_4.md','w',encoding='utf-8').write("\n".join(o))
