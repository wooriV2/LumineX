import re,random
src=open('gen_facesculpt.py',encoding='utf-8').read(); src=src[:src.index("rr=random.Random(20261013)")]
ns={}; exec(compile(src,'gf','exec'),ns)
lib=ns['ns']; HW2=lib['HW2']; COL2=lib['COL2']; w=lib['w']; SAFE=lib['SAFE']
exec(open('ear_styles.py',encoding='utf-8').read())
G=ns['G']; para2=ns['para2']; HENNA=ns['HENNA']; STICK=ns['STICK']; BOTH=ns['BOTH']; OUT=ns['OUT']
TH=ns['TH']; EX=ns['EX']; pick_style=ns['pick_style']; make_base=ns['make_base']
FR=lib['FR']; FR_OLD=lib['FR_OLD']
BODYS="hourglass physique THE MOST EXTREME PHYSICALLY POSSIBLE beyond all anatomy limits — most dramatic hourglass ratio ever, simultaneously maximum enormous bust AND maximum enormous hips both flaring to absolute impossible extremes while the waist is cinched to impossible minimum, "
DEPTH="Piercing depth: every bar and surface bar is embedded in the skin — its middle runs beneath the skin so only its two end studs show on the surface, the skin between them faintly raised over the hidden bar, with a small warm shadow at each end and nothing lying on top of the skin like a sticker. Every ring passes through a small healed opening in the skin, the skin visible through the loop, and every stud sits through the skin with its back hidden. Where a bar, ring or stud goes through the ear, the lip, the nostril or the brow, it passes through the real tissue with the skin wrapping snugly around it."
HAIR="Hair: her hair is swept back behind both ears, leaving both ears, her jawline and her neck fully visible so every hanging piece is in clear view."
LIGHT="Lighting: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient. A soft frontal light on her face and ears, so the glints on every piece of metal read clearly against her skin; a thin cool rim light along the hair and shoulders. 2:3 vertical 8K portrait."
THEMES={
"punk":("The pieces on her face are punk in style: instead of plain studs and rings, the small pieces are safety-pin shaped bars, sharp cone-spike studs and chunky chain-link rings.","The face and ear jewelry is real blackened steel and chrome silver, spiked and studded, with no gemstones","펑크(안전핀·가시 스터드)"),
"marine":("The pieces on her face are inspired by the sea: instead of plain studs and rings, the small pieces are round pearl studs, tiny scallop-shell and starfish charms and rings strung with small coral beads.","The face and ear jewelry is real pale gold and silver set with white pearls, mother-of-pearl and pink coral","해양(진주·조개·산호)")}
CHAINS="Fine chains link the pieces: from the upper ear hoop on each side a delicate chain swags across the cheek to the ring around the nostril wing on the same side, passing well below the eye and clear of the lips, and one more fine chain hangs in a soft curve under the jaw from one ear to the other; the chains are thin enough that every piece and her whole face stay clearly visible."
def base(rr,N,zero,minimal,deco,nw,mode="front",theme=None,chains=False):
    nat=rr.choice(list(G.NATS)); grp=rr.choice(["아이돌","20대","30대"]); expr=rr.choice(EX[grp]); v=rr.choice(["수수","화려","귀여움"])
    style=pick_style(rr,N,None)
    t,title,meta=make_base(rr,nat,grp,expr,style,N)
    metal,gems=TH[v]
    pp=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    new,tot=para2(N,nw,metal,gems,deco,random.Random(rr.randrange(10**9)),None,None,zero,minimal)
    lab_t=""
    if theme:
        s,tail,lab_t=THEMES[theme]
        new=new.replace("The left and right sides are balanced.",s+" The left and right sides are balanced.",1)
        old=f"The face and ear jewelry is real {metal} set with {gems}"; assert old in new
        new=new.replace(old,tail)
    if chains:
        assert "The left and right sides are balanced." in new
        new=new.replace("The left and right sides are balanced.",CHAINS+" The left and right sides are balanced.",1)
    t=re.sub(r'\n\nJewelry:[^\n]*','',t.replace(pp,new))
    sj=[x for x in t.split("\n\n") if x.startswith("Subject:")][0]
    sj2=sj.replace(BODYS,"").replace(". Real pores and fine skin grain on her skin, a soft sheen of natural oils, large eyes with bright real catchlights, full lips, ",", ")
    sj2=re.sub(r" — a photograph of a real (\w+) woman's face \(.*?\), not an illustration"," — a photograph of a real \\1 woman's face, not an illustration",sj2)
    t=t.replace(sj,sj2)
    t,n=re.subn(re.escape(FR_OLD),FR["sh"],t,count=1); assert n==1
    t=t.replace("\n\nLighting:","\n\n"+HAIR+"\n\nLighting:",1)
    mk=("메이크업 "+(meta.get("makeup_label") or "없음")) if style!="NONE" else "메이크업 없음"
    lab=f"{nat} · {grp} · {expr} · {mk} · P{N}({v})"
    return t,lab,lab_t,nw
def pack(i,t):
    assert not re.search(r"[가-힣]",t) and "{" not in t
    d=re.search(r"\b(\w+) \1\b",t)
    return d
rr=random.Random(555)
OUTS=[]
# 1 punk, 2 marine (theme pack), 3 chains, 4 ear study
specs=[("theme","punk",50,("tmp","brow","bri"),False),("theme","marine",25,(),False),("chain",None,25,(),False)]
for kind,th,N,zero,minimal in specs:
    for tr in range(60):
        r2=random.Random(rr.randrange(10**9))
        try:
            nw=r2.choice([8,9,10]); deco=r2.choice(["",HENNA,STICK,BOTH])
            t,lab,lt,nw=base(r2,N,zero,minimal,deco,nw,theme=th,chains=(kind=="chain"))
            p0,lab0=apply_ear(t,r2.choice(["iron","mix","mix"]),nw,random.Random(rr.randrange(10**9)),w,HW2,COL2,None,lab+f" · 귀 추 {nw}개/귀 2구멍")
        except AssertionError: continue
        if pack(0,p0): continue
        break
    else: raise SystemExit("fail")
    title={"theme":f"피어싱 테마 팩 · {lt}","chain":"체인 연결 (귀-코 체인 + 턱 아래 체인)"}[kind]
    OUTS.append((title+" · "+lab0,p0))
# 4 ear study
for tr in range(60):
    r2=random.Random(rr.randrange(10**9))
    try:
        nw=r2.choice([8,9,10])
        t,lab,lt,nw=base(r2,25,(),True,r2.choice(["",HENNA]),nw)
        t,lab4=apply_ear(t,"mix",nw,random.Random(rr.randrange(10**9)),w,HW2,COL2,None,lab+f" · 귀 추 {nw}개/귀 2구멍")
        hd=t.split("\n\n")[0]
        newhd="Professional fashion photograph, extreme close-up of one ear. ONE woman seen in a clean side profile, her head turned ninety degrees so that her left ear faces the camera, the lens close to her ear so that the ear, the earlobe and the whole hanging cluster of weights fill the frame from the top of the ear down to the level of her collarbone, with only a sliver of her cheek, jawline and the corner of her eye behind it. The metal is large and sharp."
        t=t.replace(hd,newhd,1)
        t=t.replace("A soft frontal light on her face and ears, so the glints on every piece of metal read clearly against her skin;","A soft side key light grazes across the metal so the hammered, pitted surfaces, the chain links and the different colours of each metal show their texture clearly;")
        t=t.replace("Hair: her hair is swept back behind both ears, leaving both ears, her jawline and her neck fully visible so every hanging piece is in clear view.","Hair: her hair is swept back behind her ear, leaving the ear, her jawline and her neck fully visible so every hanging piece is in clear view.")
        t=t.replace("so the weights fully hang in view","so the weights fully hang in view")
    except AssertionError: continue
    if pack(0,t): continue
    break
OUTS.append(("귀 스터디 (왼쪽 귀 옆모습 클로즈업, 혼합 금속 추) · "+lab4,t))
# 5 Indian bridal, 6 Tibetan
HDR2=lambda: "Professional fashion photograph, close-up beauty portrait. ONE woman, facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face, framed tightly from the very top of her head down to the line of her shoulders, the frame cutting off just below them, so the earrings fully hang in view. Her face is large and sharp. Early 20s."
REAL=" Her whole face, ears and neck are real living flesh with real pores and fine skin grain, real living eyes with bright catchlights and genuine depth, individual hair strands catching the light — a photograph of a real woman's face, not an illustration, not a render."
IND=HDR2()+"\n\nSubject: A real photograph of a striking adult Indian woman — warm golden-brown skin with a soft natural glow, early 20s, large dark kohl-lined eyes with bright real catchlights, defined dark brows, a deep red-maroon lip, a small red bindi at the centre of her forehead below the tikka, a serene, regal expression, her hair parted in the centre and swept back behind both ears into a sleek low bun."+REAL+"\n\nJewelry: traditional Indian bridal gold, all of it large and clearly visible: a large ornate gold nath, a wide gold nose ring about as wide as her cheek, through the left nostril, set with pearls and kundan stones, with a fine gold chain swagging from it across the cheek, well below the eye and clear of the lips, up to a hook at the top of her left ear; a gold maang tikka, a fine gold chain running along the centre parting of her hair and ending in a teardrop kundan pendant resting at the middle of her forehead; on each ear a huge gold jhumka, a dome-shaped bell earring as large as her palm with rows of tiny pearl drops hanging from its rim, hanging freely in the air down to the level of her collarbone and no lower, with a fine gold chain rising from the top of each jhumka into her hair. All of it is real yellow gold set with pearls, rubies, emeralds and kundan stones, sitting in real, calm, healthy skin — no redness, no swelling, no irritation — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain crosses the eyes.\n\n"+DEPTH+"\n\n"+LIGHT
TIB=HDR2()+"\n\nSubject: A real photograph of a striking adult Tibetan woman — honey-brown skin with a rosy high-altitude blush on the cheeks, early 20s, dark almond eyes with bright real catchlights, strong natural brows, softly tinted rose lips, a calm, proud expression, her hair parted in the centre and drawn back behind both ears into two long braids that fall behind her shoulders."+REAL+"\n\nJewelry: Tibetan-inspired silver, turquoise and coral jewelry, all of it large and clearly visible: on each ear a huge ornate silver earring inlaid with large turquoise and coral stones, a long drop as long as her hand hanging freely in the air down to the level of her collarbone and no lower; a row of large turquoise and coral beads strung across the top of her forehead along the hairline like a headband, with a round silver ornament set with a large turquoise at its centre; a small round silver stud inlaid with a coral bead on the left nostril wing. All of it is real hammered silver set with turquoise and red coral, sitting in real, calm, healthy skin — no redness, no swelling, no irritation — with a small natural warm shadow under each piece. Every piece stays at least a finger's width from the eyeballs, and no chain crosses the eyes.\n\n"+DEPTH+"\n\n"+LIGHT
for t in (IND,TIB): assert not re.search(r"[가-힣]",t)
OUTS.append(("문화권 주얼리 · 인도 신부 금 (나트·마앙티카·자므카)",IND))
OUTS.append(("문화권 주얼리 · 티베트풍 은·터키석·산호",TIB))
o=["# LumineX — 새 변주 샘플 6개 (피어싱 테마 팩 2 · 체인 연결 1 · 귀 스터디 1 · 문화권 주얼리 2)\n","- 1 펑크 테마, 2 해양 테마, 3 체인 연결, 4 귀 스터디(옆모습 클로즈업), 5 인도 신부 금 주얼리, 6 티베트풍 은·터키석·산호. 1~3은 기존 얼굴 컷 틀에 귀 스타일 축이 같이 들어 있습니다.","- 정상/이상 번호만 알려주세요.\n"]
for i,(title,p) in enumerate(OUTS,1):
    o.append(f"## {i}. {title}\n\n```\n{p}\n```\n"); print(i,len(p.split()))
open(OUT+'LumineX_NewVariations_Sample_6.md','w',encoding='utf-8').write("\n".join(o))
