import re,random
exec(open('mk_trio_arch.py',encoding='utf-8').read().split("SPECS=")[0])
ns2={}
g=open('gen_fs2.py',encoding='utf-8').read()
exec(compile(g[:g.index('if __name__=="__main__":')],'gfs2','exec'),ns2)
ns2['tusk_flag']=False
ARCHF={n:f for n,f,c in ns2['ARCH']}
R=random.Random(20261019)
it=ns2['build2'](1,'arch','브랫츠 돌',ARCHF['브랫츠 돌'],R)
s=it['prompt']
for a,b in SW: s=s.replace(a,b)
s=s.replace("..",".")
MAT="rough-cast matte yellow gold with a hammered, uneven, unpolished surface like a raw gold ingot "
BG_RE=re.compile(r"Lighting: The background is a city street.*?never bright\.")
assert MAT in s and BG_RE.search(s)
def bg(t): return BG_RE.sub("Lighting: MANDATORY pure pitch black void background only, absolutely NO studio backdrop NO texture NO grey NO gradient.",t)
def short(t):
    n=t.count(MAT); t=t.replace(MAT,"")
    c=t.count(" thick heavy chain of the same metal"); t=t.replace(" thick heavy chain of the same metal"," chain")
    t=t.replace("separate massive weights, each of a different shape:","separate massive weights, each of a different shape, all of them rough-cast matte yellow gold with a hammered, uneven, unpolished surface like raw gold ingots, each on a thick heavy chain of the same metal:",1)
    assert n==20 and c==20,(n,c)
    return t
V=[("1. 배경만 순흑",bg(s)),("2. 귀 추 묶음 문장 압축만",short(s)),("3. 둘 다",bg(short(s)))]
o=["# LumineX — 브랫츠 1인 길이·배경 비교 3개 (같은 인물)\n","- 같은 브랫츠 1인 프롬프트에서 한 가지씩만 바꿨습니다. 1: 비 오는 밤 네온 배경 → 순흑 배경. 2: 귀 추 20개 문장에서 '거친 무광 금 …' 재질 설명이 20번 반복되던 것을 한 번만 쓰도록 압축(내용은 그대로, 약 570단어 감소). 3: 둘 다.","- 이전 1인(원본)과 비교해서 피부(잔털·주름·고무 느낌)가 사실적인 순서를 알려주세요.\n"]
for h,t in V:
    assert not re.search(r"[가-힣]",t)
    o.append(f"## {h}\n\n```\n{t}\n```\n"); print(h,len(t.split()))
open(OUT+'LumineX_Bratz_LenBg_3.md','w',encoding='utf-8').write("\n".join(o))
