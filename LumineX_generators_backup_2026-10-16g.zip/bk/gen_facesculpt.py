import re,random,json,sys
src=open('random_mix5_lib.py').read(); ns={}; exec(compile(src,'lib','exec'),ns)
G=ns['G']; para2=ns['para2']; HENNA=ns['HENNA']; STICK=ns['STICK']; BOTH=ns['BOTH']; OUT=ns['OUT']; NOSES=ns['NOSES']; JAWS=ns['JAWS']; MATS=ns['MATS']; TH=ns['TH']
HDR=ns['HDR']; LIT=ns['LIT']; ANG45=ns['ANG45']; KEY=ns['KEY']; FR_OLD=ns['FR_OLD']; FR=ns['FR']
FACEPAINT={"마이코","경극","혼례(연지곤지)","둔황 비천풍"}
ALLOW=[x for x in G.STYLES if x not in FACEPAINT]
DARKLIP=["고스 블랙립","뱀파이어 다크","비주얼계 블랙립","비닐 블랙립","립온리 블랙","펑크 블랙립","잉크 블랙립"]
EX={"아이돌":["귀여운","발랄한","당황한","눈물 글썽한","몽환적인","도도한","놀란","호기심 어린"],"20대":["도도한","섹시한","귀여운","발랄한","몽환적인","당황한","눈물 글썽한","카리스마 있는","놀란","호기심 어린","광기 어린"],"30대":["고혹적인","군림하는","냉혹한","카리스마 있는","도도한","섹시한","몽환적인","놀란","광기 어린"]}
def subjs(fn):
    t=open(OUT+fn,encoding='utf-8').read()
    return [[p for p in b.split("\n\n") if p.startswith("Subject:")][0] for b in re.findall(r"```\n(.*?)\n```",t,re.S)]
def eyeclause(fn,i):
    s=subjs(fn)[i]; m=re.search(r"star of her face: (.*?)\. [A-Z]",s,re.S); assert m,(fn,i); return m.group(1)
def lipclause(fn,i):
    s=subjs(fn)[i]; m=re.search(r"star of her face: (?:she has )?(.*?)\. Her eyes are large",s,re.S); assert m,(fn,i); return m.group(1)
def lensfix(t):
    for a,b in [("silver-grey","coloured"),("luminous deep amber","luminous coloured"),("sky-blue","coloured"),("rich dark-brown","rich coloured"),("very large dark-brown","very large coloured"),("soft brown","coloured"),("violet","coloured")]:
        t=t.replace(a,b)
    return t
T10=open(OUT+'LumineX_ExtremeNext_10.md',encoding='utf-8').read()
SI=re.search(r"extreme siren eyes:.*?bright catchlights",T10,re.S).group(0)
DO=re.search(r"enormous, perfectly round, wide, innocent doe eyes.*?still sweet and beautiful",T10,re.S).group(0)
HO=re.search(r"extremely heavy-lidded, almost closed.*?bright catchlights",T10,re.S).group(0)
BC=subjs('LumineX_Eyes_BothCanthus_Big_2.md')
def bc(i):
    m=re.search(r"star of her face: (.*?)\. Slim",BC[i],re.S); assert m; return lensfix(m.group(1))
E8=bc(1); E6=bc(0)
EYEITEMS=[("애교살 초극대",lensfix(eyeclause('LumineX_Eyes_AegyoMax_1.md',0)),20),
("사이렌 눈 +1",SI,20),("도 아이 +1",lensfix(DO),20),("후디드 아이 +1",HO,20),
("애니 돌 아이 실사형",lensfix(eyeclause('LumineX_AnimeEye_Realistic_2.md',0)),10)]
CAN=[("옆트임 극단(2배)",lensfix(eyeclause('LumineX_Eyes_NewShapes_Canthus_6.md',4)),4),("옆트임 초극단(2.5배)",lensfix(eyeclause('LumineX_Eyes_NewShapes_Canthus_6.md',5)),4),("옆트임 극한(3배)",lensfix(eyeclause('LumineX_Eyes_CanthusMax_AnimeEye_3.md',0)),4),("옆트임 최극한(4배)",lensfix(eyeclause('LumineX_Eyes_CanthusMax_AnimeEye_3.md',1)),4),("양쪽 트임 6배+큰 눈",E6,7),("양쪽 트임 8배+거대한 눈",E8,7)]
LIPITEMS=[("러시안 립 과장",lipclause('LumineX_RussianLips_Strong_2.md',0),10),("러시안 립 초과장",lipclause('LumineX_RussianLips_Strong_2.md',1),10),("러시안 립 초과장+1",lipclause('LumineX_RussianLips_Beyond_2.md',0),10),("러시안 립 판타지 한계",lipclause('LumineX_RussianLips_Beyond_2.md',1),10),("러시안 립 초초과장",lipclause('LumineX_ExtremeNext_10.md',0),10),("러시안 립 극한",lipclause('LumineX_ExtremeNext_10.md',1),10),
("체리 립",lipclause('LumineX_AnimeEye_Lips45_4.md',2),15),("키홀 퓨트 +1",lipclause('LumineX_ExtremeNext_10.md',5),15),("큐피드 보우",lipclause('LumineX_Lips45_CupidFlipLift_3.md',0),10),("립 플립",lipclause('LumineX_Lips45_CupidFlipLift_3.md',1),10),("립 리프트",lipclause('LumineX_Lips45_CupidFlipLift_3.md',2),10)]
BAR=subjs('LumineX_BarbieWestern_3.md'); BZ=subjs('LumineX_FaceTypes_Bratz_IG_Elf_3.md')[0]; SC=subjs('LumineX_FaceTypes_Succubus_Femme_Siren_3.md')
def vary_bratz(s,rr):
    c=rr.choice(["bright pink","electric purple","teal","sky-blue","orange","red"]); s=s.replace("bright pink streaks",c+" streaks")
    l=rr.choice(["honey-amber","emerald-green","ice-blue","violet","hazel-gold"]); return s.replace("honey-amber",l)
def vary_succ(s,rr):
    l=rr.choice(["molten-gold","blood-red","ice-blue","violet","emerald"]); s=s.replace("molten-gold",l)
    return s.replace("jet-black hair",rr.choice(["jet-black hair","deep burgundy hair","silver-white hair","midnight-blue hair"]))
def vary_siren(s,rr):
    s=s.replace("silver-teal",rr.choice(["silver-teal","silver-pink","pearl-white","lilac-aqua","deep sea-blue"]))
    return s.replace("sea-green",rr.choice(["sea-green","aqua-blue","violet","pearl-silver"]))
ARCH=[("바비 인형(금발)",lambda rr:BAR[0],7),("바비 인형(갈색 머리)",lambda rr:BAR[1],7),("바비 인형(핑크 머리)",lambda rr:BAR[2],6),("브랫츠 돌",lambda rr:vary_bratz(BZ,rr),15),("서큐버스",lambda rr:vary_succ(SC[0],rr),12),("인어 세이렌",lambda rr:vary_siren(SC[2],rr),13)]
def make_base(rr,nat,grp,expr,style,N):
    for tr in range(80):
        try: return G.make(random.Random(rr.randrange(10**9)),nat,grp,expr,style=style,slots=["pierce","lens"],pier_level="P150" if N>=100 else ("P50" if N>=50 else "P25"))
        except AssertionError: continue
    raise SystemExit("gen fail")
def pick_style(rr,N,tusk):
    if N>=50: return rr.choice(["NONE"]+DARKLIP)
    return "NONE" if rr.random()<0.25 else rr.choice(ALLOW)
def build(idx,rr,kind,name,text):
    nat=rr.choice(list(G.NATS)); grp=rr.choice(["아이돌","20대","30대"]); expr=rr.choice(EX[grp]); v=rr.choice(["수수","화려","귀여움"]); nw=rr.choice([8,9,10])
    jaw=rr.choice(JAWS); nose=rr.choice(NOSES)
    pat=None; zero=(); minimal=False; N=25
    if kind=="eye":
        zero=("tmp","brow","bri"); N=50 if rr.random()<0.4 else 25
        if rr.random()<0.25: pat=rr.choice("ABC"); N=50
        deco=rr.choice(["",HENNA,STICK,BOTH])
    elif kind=="lip":
        minimal=True; deco=rr.choice(["",HENNA,HENNA])
    else:
        if rr.random()<0.5: minimal=True; deco=rr.choice(["",HENNA])
        else: zero=("ul","ll","tmp","brow","bri"); deco=rr.choice(["",HENNA,STICK,BOTH])
    style=pick_style(rr,N,pat)
    t,title,meta=make_base(rr,nat,grp,expr,style,N)
    mat=rr.choice(MATS) if pat else None
    metal,gems=TH[v]
    pp=[x for x in t.split("\n\n") if x.startswith("Piercings:")][0]
    new,tot=para2(N,nw,metal,gems,deco,random.Random(rr.randrange(10**9)),pat,mat,zero,minimal)
    t=re.sub(r'\n\nJewelry:[^\n]*','',t.replace(pp,new))
    sj=[x for x in t.split("\n\n") if x.startswith("Subject:")][0]
    if kind=="arch":
        t=t.replace(sj,text)
    else:
        nz=nose if name!="애니 돌 아이 실사형" else NOSES[0]
        if kind=="eye": star_s=f"her eyes are the star of her face (the shape, size and lenses described here override the eyes of her makeup, while the colours of her eyeshadow and liner follow her makeup): {text.format(lens='coloured') if '{lens}' in text else text}"
        else: star_s=f"her lips are the star of her face (the shape, size and projection described here override the lips of her makeup, while the lip colour and finish follow her makeup and ignore any lip colour named here): {text}"
        add=f" Her face has been surgically sculpted far beyond her natural look, and these changes override her natural features: {star_s}; her nose: {nz[1]}; her jawline and chin: {jaw[1]}. Every feature is exaggerated but beautiful, balanced and refined, in harmony with the rest of her face, never distorted, never grotesque."
        t=t.replace(sj,sj+add)
    fr=FR["ch"] if pat else FR["sh"]
    t,n=re.subn(re.escape(FR_OLD),fr,t,count=1); assert n==1
    if kind=="lip":
        a=ANG45 if rr.random()<0.5 else ANG45.replace("to her left","to her right")
        t=t.replace(HDR,a,1); t=t.replace(LIT,KEY,1)
    t=t.replace("\n\nLighting:","\n\nHair: her hair is swept back behind both ears, leaving both ears, her jawline and her neck fully visible so every hanging piece is in clear view.\n\nLighting:",1)
    assert not re.search(r"[가-힣]",t) and "{" not in t
    mk=meta.get("makeup_label") or "없음"
    ang="45도" if kind=="lip" else "정면"
    parts=[f"{nat} · {grp} · {expr}",name]
    if kind!="arch": parts+= [nose[0],jaw[0]]
    parts+=[ang,("유형 고유 메이크업" if kind=="arch" else (("메이크업 "+mk) if style!="NONE" else "메이크업 없음")),("귀만 피어싱" if minimal else f"P{N}({v})"),f"귀 추 {nw}개/귀 2구멍"]
    if pat: parts.append(f"엄니({mat[0]}) 패턴{pat}")
    if "Henna" in deco: parts.append("헤나")
    if "Stickers" in deco: parts.append("스티커")
    lens=meta.get("lens"); 
    if kind!="arch" and lens: parts.append("렌즈 "+lens)
    key=f"la_facesculpt_{idx:03d}"
    return dict(key=key,category="🏺 Living Artifact · Face Sculpt Formula",title=f"Face Sculpt #{idx:03d} ("+" · ".join(parts)+")",prompt=t,meta=dict(group_size=1,aspect_ratio="2:3",format="face-sculpt",kind=kind,star=name,nat=nat,age_group=grp,expression=expr,piercing=("ears" if minimal else f"P{N}"),makeup=("type-inherent" if kind=="arch" else style),tusk=pat,ear_holes=2,ear_weights=nw))
rr=random.Random(20261013)
jobs=[]
for name,text,c in EYEITEMS: jobs+= [("eye",name,text)]*c
for name,text,c in CAN: jobs+= [("eye",name,text)]*c
for name,text,c in LIPITEMS: jobs+= [("lip",name,text)]*c
for name,fn,c in ARCH: jobs+= [("arch",name,fn)]*c
print(len(jobs))
out=[]
for i,(kind,name,text) in enumerate(jobs,1):
    for tr in range(30):
        r2=random.Random(rr.randrange(10**9))
        tx=text(r2) if callable(text) else text
        try:
            it=build(i,r2,kind,name,tx)
        except AssertionError: continue
        d=re.search(r"\b(\w+) \1\b",it["prompt"])
        if d and d.group(1).lower() not in ("had","that"): continue
        out.append(it); break
    else: raise SystemExit(("fail",i,name))
print(len(out))
json.dump(out,open(OUT+'la_facesculpt_300_bundle.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
import collections
print(collections.Counter(x["meta"]["star"] for x in out))
print(collections.Counter(x["meta"]["makeup"] for x in out).most_common(8))
print(min(len(x["prompt"].split()) for x in out),max(len(x["prompt"].split()) for x in out))
