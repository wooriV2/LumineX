import sys,re,random
sys.path.insert(0,'.')
import gen_cjk_v2 as G
from cover_lib import SAFE
HEAD="Professional fashion photograph, close-up beauty portrait. ONE woman, facing the camera straight on in a perfectly frontal portrait, her head level, both ears clearly visible on either side of her face, framed tightly from the very top of her head down to the base of her neck and the tops of her collarbones, the frame cutting off there. Her face is large and sharp. Mid 20s."
HEAD_W=HEAD.replace("down to the base of her neck and the tops of her collarbones, the frame cutting off there","down to her collarbones and the tops of her shoulders, the frame cutting off there, so the earrings fully hang in view")
TAIL=" Every feature is exaggerated but beautiful, balanced and refined, in harmony with the rest of her face, never distorted, never grotesque. Real skin fine grain and a soft sheen of natural oils on her face, ears and neck, individual hair strands catching the light — a photograph of a real woman, not an illustration, not a render."
SK="The skin around every piece is real, smooth, intact and fully healed, with no tearing, no wound, no blood and no redness."
IRON="rough black cast iron with a hammered, pitted, matte surface"
def sub(txt): return "Subject: "+txt+TAIL



def eyesub(face,eyes,brows,rest):
    return sub("A real photograph of a strikingly beautiful adult woman, mid 20s, "+face+" Her eyes are the star of her face: "+eyes+" "+brows+" "+rest+" Looking straight into the camera.")
def pier(mat,desc,col):
    return ("Piercings: Exactly six piercings in total, symmetrical: on each ear a large "+desc+" hoop in the lobe and two matching studs up the rim. Each piece is large and clearly visible, and nothing else on the face is pierced. "+SK+" All jewelry is real "+mat+","+SAFE)
V=[("캣아이 — 라틴 · 날카롭게 치켜 올라간 큰 아몬드 눈·두꺼운 윙 라인 · 골드+오닉스 피어싱 6",
    eyesub("a Latin woman with warm honey-tan skin and long glossy dark waves.","big, sharp, almond-shaped cat eyes with the outer corners slanting steeply upward like a cat, the inner corners low and pointed, outlined by thick black liner with a long, thick, razor-sharp upward wing, in glowing golden-green contact lenses with a big visible iris, both eyes the same, with a round natural pupil and bright catchlights.","Thick, sharply angled, dark brows rising with the eyes.","Full lips in warm brick-rose, a straight nose and high cheekbones. A fierce, feline gaze."),
    pier("polished yellow gold set with black onyx","gold with black onyx",1)),
   ("퍼피 아이(처진 눈) — 서양인 · 바깥이 아래로 처진 크고 둥근 눈·순한 눈빛 · 은+진주 피어싱 6",
    eyesub("a Western woman with fair skin, a pink blush and long soft light-brown waves.","very large, round, puppy-dog eyes whose outer corners droop gently downward, giving a soft, sweet, pleading look, a big glossy iris with a lot of white visible below, soft brown liner drawn slightly downward at the outer corners and long lashes, in warm hazel contact lenses, both eyes the same, with a round natural pupil and bright catchlights.","Soft, gently sloping, slightly raised inner brows that make her look wistful.","Soft pink lips, a small nose and rosy cheeks. A tender, innocent gaze."),
    pier("polished sterling silver set with white pearls","silver with a white pearl",1)),
   ("무쌍 샤프 눈 — 한국 · 속쌍꺼풀 없는 길고 날카로운 눈·진한 아이라인 · 블랙 스틸 피어싱 6",
    eyesub("a Korean woman with pale skin and long, sleek jet-black hair.","long, narrow, sharp monolid eyes with no visible eyelid crease, smooth and flat upper lids, the outer corners lifted slightly, a clean, dark, sharp eyeliner line along the upper lashes ending in a long fine wing, in deep black-brown contact lenses with a big iris and a cool glossy shine, both eyes the same, with a round natural pupil and bright catchlights.","Straight, thin, sharp dark brows.","Soft red lips, a slim straight nose and a slim V-line jaw. A cold, piercing gaze."),
    pier("blackened steel","black steel",1)),
   ("하이퍼 아몬드 — 일본 · 얼굴 가로로 아주 긴 거대 아몬드 눈·긴 속눈썹 · 로즈골드+핑크 피어싱 6",
    eyesub("a Japanese woman with fair skin and a soft dark-brown bob with blunt bangs.","enormous, extra-long almond eyes stretching wide across her face, about one and a half times the usual width, with a very large, smooth, softly rounded shape, a big visible iris, a delicate double eyelid, long dense curled lashes on top and bottom, in soft grey-brown doll-eye contact lenses, both eyes the same, with a round natural pupil and bright catchlights.","Soft, thin, gently arched brows.","Soft rose lips, a small refined nose and a small chin. A calm, wide-eyed gaze."),
    pier("polished rose gold with pastel-pink enamel","rose-gold with pastel-pink enamel",1)),
   ("옆트임 극단 — 중국 · 눈 길이 2배·눈꼬리가 관자 끝까지·앞트임 분홍 코너 · 골드+제이드 피어싱 6",
    eyesub("a Chinese woman with luminous porcelain skin and long straight glossy black hair.","the most extreme surgically widened eyes: lateral canthoplasty has extended the outer corners of both eyes all the way to the edge of her temples and medial canthoplasty has fully opened the inner corners with the small pink inner corner of each eye clearly visible, so each eye opening is about twice its natural length, extremely long, wide and almond-shaped, showing a huge amount of the iris and white on both sides; a razor-sharp black eyeliner follows the whole extended shape and ends in a long, sharp point at the temple, with a clean double eyelid; the eyes are in very large dark-brown doll-eye contact lenses with a glossy shine, both eyes the same, with a round natural pupil and bright catchlights.","Slim, clean, softly arched dark brows.","Soft rose lips, a straight refined nose and a slim V-line jaw. A cool, intense gaze."),
    pier("polished yellow gold set with green jade","gold with green jade",1)),
   ("옆트임 초극단 — 한국 · 눈 길이 2.5배·눈꼬리가 관자를 넘어 헤어라인 쪽까지 · 은+아쿠아 피어싱 6",
    eyesub("a Korean woman with luminous fair skin and long sleek dark-brown hair swept behind her ears.","the most extreme eyes imaginable, beyond any real surgery but still beautiful: the outer corners of both eyes are extended far past the temples toward her hairline and the inner corners are fully opened with the small pink inner corner visible, so each eye opening is about two and a half times its natural length, a long, narrow, razor-sharp almond shape spanning most of the width of her face, showing a huge amount of iris and white; a razor-sharp black liner follows the entire shape and ends in a very long, sharp point at the hairline; the eyes are in very large silver-grey doll-eye contact lenses with a glossy shine and a big iris, both eyes the same, with a round natural pupil and bright catchlights.","Slim, high, sharply arched dark brows that follow the long eyes.","Soft rose lips, a straight refined nose and a slim V-line jaw. An icy, otherworldly gaze."),
    pier("polished sterling silver set with pale aqua gems","silver with a pale aqua gem",1))]
o=["# LumineX — 눈 모양 4종 + 옆트임 극단 2단계 (정면)\n","- 새 눈 모양: 캣아이·퍼피 아이·무쌍 샤프·하이퍼 아몬드. 옆트임: 극단(길이 2배, 눈꼬리가 관자 끝까지), 초극단(길이 2.5배, 헤어라인 쪽까지). 피어싱은 양쪽 귀 6개로 절제. 모두 성인.","- 정상/이상(+ 눈 모양 특징이 보이는지)만 번호로 알려주세요.\n"]
for i,(lab,sj,p) in enumerate(V,1):
    for tr in range(60):
        try: t,title,meta=G.make(random.Random(93000+i*100+tr),"한국","20대","도도한",style="NONE",slots=["pierce"],pier_level="P5"); break
        except AssertionError: continue
    else: raise SystemExit(i)
    ps=t.split("\n\n")
    depth=[x for x in ps if x.startswith("Piercing depth:")][0]; light=[x for x in ps if x.startswith("Lighting:")][0]
    new="\n\n".join([HEAD,sj,p,depth,light]); assert not re.search(r"[가-힣]",new)
    o.append(f"## {i}. {lab}\n\n```\n{new}\n```\n")
open('/mnt/user-data/outputs/LumineX_Eyes_NewShapes_Canthus_6.md','w',encoding='utf-8').write("\n".join(o)); print("ok")
